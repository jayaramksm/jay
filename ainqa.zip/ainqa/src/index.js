import { loadPreDataAndApp } from './helpers/helpersIndex';
loadPreDataAndApp(false);