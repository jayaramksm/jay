
import React, { Component } from 'react';
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem, Badge } from 'reactstrap';
import { withRouter } from 'react-router-dom';

// users
import user4 from '../../../images/users/user-4.jpg';

class ProfileMenu extends Component {

    constructor(props) {
        super(props);
        this.state = {
            menu: false,
        };
        this.toggle = this.toggle.bind(this);
    }

    toggle() {
        this.setState(prevState => ({
            menu: !prevState.menu
        }));
    }

    render() {
        return (
            <React.Fragment>
                <Dropdown isOpen={this.state.menu} toggle={this.toggle} className=" nav-pro-img" style={{ marginTop: "10px", textAlign: "center" }} >
                    <DropdownToggle className="nav-link arrow-none nav-user waves-effect" tag="a">
                        <img src={user4} alt="user" className="rounded-circle" />
                    </DropdownToggle>
                    <DropdownMenu className="profile-dropdown">
                        <DropdownItem tag="a" href="#"><i className="fa fa-user-circle m-r-5"></i> Profile</DropdownItem>
                        <DropdownItem tag="a" href="#"><Badge color="success" className="mt-1 float-right">11</Badge><i className="fa fa-cog m-r-5"></i> Settings</DropdownItem>
                        <DropdownItem tag="a" href="#"><i className="fa fa-lock m-r-5"></i> Lock screen</DropdownItem>
                        <div className="dropdown-divider"></div>
                        <DropdownItem tag="a" className="text-danger" href="/logout"><i className="fa fa-power-off text-danger"></i> Logout</DropdownItem>
                    </DropdownMenu>
                </Dropdown>
            </React.Fragment >
        );
    }
}


export default withRouter(ProfileMenu);
