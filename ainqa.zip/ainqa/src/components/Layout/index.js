import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

import Topbar from './Topbar';
import Sidebar from './Sidebar';
import Loading from './loading';
import LayoutAlertMessage from './LayoutAlertMessage';
import { ELayoutType } from '../../models/utilitiesModel';
import ConfirmationAction from './ConfirmationAction';

// render if Auth Layout
const AuthLayoutContent = (props) => {
  document.body.classList.remove('bg-primary');
  return <React.Fragment>
    <div id="wrapper" className={"wrapper_cont " + (props.themeName || 'theme-1')}>
      <LayoutAlertMessage />
      <ConfirmationAction />
      <Topbar />

      <div className="content-page">
        <div className="content">
          {props.children}
        </div>
      </div>
      <Loading />
      <Sidebar />
    </div>
  </React.Fragment>
}

// render if Non-Auth Layout
const NonAuthLayoutContent = (props) => {
  return <React.Fragment>
    {props.children}
  </React.Fragment>
}

class Layout extends Component {
  getRenderlayout = (value) => {
    if (value) {
      switch (value) {
        case ELayoutType.AUTH:
          return <AuthLayoutContent {...this.props} />
        default:
          return <NonAuthLayoutContent {...this.props} />;
      }
    }
    else
      return <NonAuthLayoutContent {...this.props} />;
  }
  render() {
    console.log("props=>", this.props)
    return (
      <React.Fragment>
        {this.getRenderlayout(this?.props?.layoutType)}
      </React.Fragment>
    );
  }
}


const mapStatetoProps = (state) => {
  return {
    layoutType: state.Layout?.layoutType,
    themeName: state?.SessionState?.userDto?.university?.themeInfo?.themeName || ''
  }
}
export default withRouter(connect(mapStatetoProps)(Layout));