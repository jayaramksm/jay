
import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom';
import sublogo from '../../images/main_logo.png';
import mainlogo from '../../images/Logo.png';
import { ERoutePath, ELogoutTypes } from '../../models/utilitiesModel'
import { logOutRequest, requestBase64LogoPathConvert } from '../../store/actions';

function SideNav(props) {
    const dispatch = useDispatch();
    const menuData = useSelector(state => state?.SessionState?.menuData);
    const { logoUrl: universityLogo } = useSelector(state => state?.SessionState?.userDto?.university || {});

    const universityBase64logo = useSelector(state => state?.Layout?.base64logoPath || '');
    useEffect(() => {
        if (!universityBase64logo && universityLogo)
            dispatch(requestBase64LogoPathConvert(universityLogo));
    }, [universityBase64logo]);


    console.log("universityLogo=>", { universityLogo, universityBase64logo });
    const locationcheck = () => {
        if (menuData) {
            let menuIndex = menuData.findIndex(s => '/' + s.link === props.location.pathname || s.subModules.findIndex(y => '/' + y.link === props.location.pathname) !== -1);
            if (menuIndex !== -1)
                return menuData[menuIndex].moduleName;
        }
        return 0;
    }
    const matchpath = locationcheck();
    if (!menuData)
        props.history.push(ERoutePath.default);
    const redirectPath = (path) => {
        console.log('path=>', path);

        props.history.push('/' + path)
    }
    console.log("SideNav=>", props, menuData);

    return (
        <React.Fragment>
            <nav className="main-menu ">
                <div className="side-bar">
                    <div className="logo-area">
                        <img className="small-logo" src={universityBase64logo !== 'data:' ? universityBase64logo || universityLogo || sublogo : sublogo} alt=""></img>
                        <img className="main-logo" src={universityBase64logo !== 'data:' ? universityBase64logo || universityLogo || mainlogo : mainlogo} alt=""></img>
                        {/* <img className="main-logo" src={mainlogo} alt=""></img> */}
                    </div>

                    <div className="flexLayout mt-3">
                        <div className="flexScroll" style={{ overflowX: "hidden" }}>
                            <div className="nav_items">
                                <ul>
                                    {menuData && menuData.map((x, index) => {
                                        return (
                                            <li key={index} id={x.link} className={matchpath === x.moduleName ? 'active' : ''} >
                                                <a onClick={() => redirectPath(x.link)}>
                                                    {x.icon === 'home' && <><i className="icon-Home"></i> <p>{x.moduleName}</p></>}
                                                    {x.icon === 'gla' && <><i className="icon-GLA"></i> <p>{x.moduleName}</p></>}
                                                    {x.icon === 'rla' && <><i className="icon-PLA"></i> <p>{x.moduleName}</p></>}
                                                    {x.icon === 'clinicalMeetings' && <><i className="icon-RotationalMeetings"></i> <p>{x.moduleName}</p></>}
                                                    {x.icon === 'elogbook' && <><i className="icon-Elogbook"></i> <p>{x.moduleName}</p></>}
                                                    {x.icon === 'users' && <><i className="icon-user-leftmenu"></i> <p>{x.moduleName}</p></>}
                                                    {x.icon === 'dashboard' && <><i className="icon-dashboard-leftmenu"></i> <p>{x.moduleName}</p></>}
                                                    {x.icon === 'hospital' && <><i className="icon-Hospital"></i> <p>Hospitals</p></>}
                                                    {x.icon === 'coursemanagement' && <><i className="icon-Course-Management"></i> <p>Course Management</p></>}
                                                    {x.icon === 'masterdata' && <><i className="icon-data"></i> <p>Master Data</p></>}
                                                    {x.icon === 'universities' && <><i className="icon-University"></i> <p>Master Universities</p></>}
                                                    {x.icon === 'universityadmin' && <><i className="icon-UniversityAdmin"></i> <p>University Admin</p></>}
                                                    {x.icon === 'configurations' && <><i className="icon-Configuration"></i> <p> Configurations</p></>}
                                                    {x.icon === 'FormBuilder' && <><i className="icon-FormBuilder"></i> <p> {x.moduleName}</p></>}
                                                    {x.icon === 'Evidence' && <><i className="icon-evidence"></i> <p> Evidence</p></>}

                                                </a>
                                            </li>

                                        )
                                    })}
                                </ul>
                            </div>
                        </div>
                        <div className="nav_items logout-button">
                            <ul>
                                <li>
                                    <a onClick={() => dispatch(logOutRequest(props.history, ERoutePath.default, ELogoutTypes.LOGOUT))}>
                                        <i className="icon-log_out"></i>
                                        <p>Logout</p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </React.Fragment>
    );
}
export default withRouter(SideNav);