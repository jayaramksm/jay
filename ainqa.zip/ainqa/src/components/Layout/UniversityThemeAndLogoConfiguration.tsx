import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, UncontrolledTooltip, Form, FormGroup } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { EThemeNames, EThemeIds, IUserDetails } from '../../models/utilitiesModel';
import defaultLogo from '../../images/main_logo.png';
import discardBtn from '../../images/Discard.svg';
import { ERoleDesc, EFileSizes } from '../../models/utilitiesModel';
import { updateUniversityConfigurationsRequest } from '../../store/actions';
import { getFileExtension, getFileSizeInMb } from '../../helpers/helpersIndex';

const UniversityThemeAndLogoConfiguration: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const userDto: IUserDetails = useSelector((state: any) => state?.SessionState?.userDto);
    const base64logoUrl = useSelector((state: any) => state?.Layout?.base64logoPath || '');
    const { themeName = '' } = userDto?.university?.themeInfo || {};
    let universityLogo = base64logoUrl || userDto?.university?.logoUrl || '';

    const initialState = {
        selectedThemeName: '',
        showConfigurations: false,
        selectedThemeId: '',
        extension: '',
        fileName: '',
        fileData: null,
        invalidFileError: '',
        previewLogo: ''
    }
    const [state, setState] = useState<any>(() => initialState);

    const isUniversityAdmin = userDto?.roles?.roleCode === ERoleDesc.UNIVERSITYADMIN;
    const updateThemeSelection = (themeId, themeName) => {
        setState({
            ...state,
            selectedThemeId: themeId,
            selectedThemeName: themeName
        });
    }

    const updateUniversityLogo = event => {
        const selectedLogo = event?.target?.files?.[0];

        if (selectedLogo) {
            const extension = getFileExtension(selectedLogo.name);
            const fileSize = getFileSizeInMb(selectedLogo.size);


            if (fileSize <= EFileSizes.UNIVERSITY_LOGO_MAX_SIZE) {
                if (extension === 'jpg' || extension === 'jpeg' || extension === 'png') {
                    setState({
                        ...state,
                        extension,
                        fileName: selectedLogo.name,
                        fileData: selectedLogo,
                        previewLogo: URL.createObjectURL(selectedLogo)
                    });
                }
                else
                    setState({ ...state, invalidFileError: t('Universities.invalidLogo') });
            }
            else
                setState({ ...state, invalidFileError: t('Universities.maxLogoSize') });
        }
        event.target.value = null;
    }

    const toggleConfiguration = () => {
        setState(prevState => ({
            ...state,
            showConfigurations: !prevState.showConfigurations
        }));
    }

    const clearLogoUpload = () => {
        setState({
            ...state,
            fileData: null,
            fileName: '',
            invalidFileError: '',
            extension: '',
            previewLogo: ''
        });
    }
    const discardConfigurations = () => setState(initialState);
    const saveUniversityConfigurations = () => {
        dispatch(updateUniversityConfigurationsRequest(state));
        discardConfigurations();
    };

    return (
        <>
            <li>
                {isUniversityAdmin && <>
                    <a onClick={toggleConfiguration} style={{ position: "relative" }} className="pointer">
                        <i className="icon-Theme" id="themesicon" style={{ fontSize: "20px" }}></i>
                    </a>
                    <UncontrolledTooltip color="primary" placement="bottom" target="themesicon">
                        {t('Universities.themestitle')}
                    </UncontrolledTooltip>
                </>}
                {state.showConfigurations && <div className="themeCard">
                    <div>{t('Universities.selectThemeTitle')}&nbsp;&nbsp;<span className="text-muted">({t('Universities.selectThemeNote')})</span></div>
                    <div className="themesColors my-3">
                        <div onClick={() => updateThemeSelection(EThemeIds.THEME_1, EThemeNames.THEME_1)} className={"colortheme " + (((state.selectedThemeName ? state.selectedThemeName : themeName) === EThemeNames.THEME_1 || !themeName) ? 'active' : '')} id="theme1">
                            <p style={{ background: "#00B5B4" }}></p>
                            <p style={{ background: "#00215C" }}></p>
                        </div>

                        <div onClick={() => updateThemeSelection(EThemeIds.THEME_2, EThemeNames.THEME_2)} className={"colortheme " + ((state.selectedThemeName ? state.selectedThemeName : themeName) === EThemeNames.THEME_2 ? 'active' : '')} id="theme2">
                            <p style={{ background: "#FF8A00" }}></p>
                            <p style={{ background: "#2E2E2E" }}></p>
                        </div>

                        <div onClick={() => updateThemeSelection(EThemeIds.THEME_3, EThemeNames.THEME_3)} className={"colortheme " + ((state.selectedThemeName ? state.selectedThemeName : themeName) === EThemeNames.THEME_3 ? 'active' : '')} id="theme3">
                            <p style={{ background: "#00215B" }}></p>
                            <p style={{ background: "#00215B" }}></p>
                        </div>
                    </div>
                    <hr />
                    <p className="mb-2"><strong>{t('Universities.updateLogo')}</strong></p>
                    <Row className="align-items-flex-start">
                        <Col xs="3">
                            <div className="border uploadedImg">
                                <img src={state.previewLogo || universityLogo || defaultLogo} width="35" alt="updatedlogo" />
                                {/* <img src={logoPreview || universityLogo || defaultLogo} width="35" alt="updatedlogo" /> */}
                            </div>
                        </Col>
                        <Col xs="9" className="uploadLogoSec pl-0">
                            <Form>
                                <FormGroup className="mb-0 theme-config">
                                    <input type="file" id="uploadLogo" hidden onChange={updateUniversityLogo} accept=".png, .jpg, .jpeg" />
                                    <label htmlFor="uploadLogo" className="mb-0">
                                        <div className="d-flex flex-row" id="uploadfile-chosen">
                                            <div className="text-muted"><i className="ti-folder"></i> {state.fileName ? state.fileName : 'Browse File'}
                                            </div>
                                        </div>
                                    </label>
                                </FormGroup>

                                <div className="d-flex">
                                    {/* <div className="pointer"><img src={uploadBtn} alt="" /></div> */}
                                    <div className="pointer"><img onClick={clearLogoUpload} src={discardBtn} alt="" /></div>
                                </div>

                                <div className="fileuplod-note mt-1">
                                    {state.invalidFileError ? state.invalidFileError : '*.png, .jpg, .jpeg formats only, Max size 2MB'}
                                </div>
                            </Form>
                        </Col>
                    </Row>
                    <button className="btn blue-button mr-1 mt-3" type="submit" onClick={saveUniversityConfigurations} disabled={!(state.selectedThemeName || state.previewLogo)}>{t('ActionNames.save')}</button>
                    <button className="btn btn-danger ml-1 mt-3" type="button" onClick={discardConfigurations}>{t('ActionNames.cancel')}</button>
                </div>}
            </li>
        </>
    )
}
export default React.memo(UniversityThemeAndLogoConfiguration);