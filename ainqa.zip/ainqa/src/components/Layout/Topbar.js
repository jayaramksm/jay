import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import ProfileArrow from '../../images/profile-arrow.svg';
import UniversityThemeAndLogoConfiguration from './UniversityThemeAndLogoConfiguration';
import { requestBase64ProfileLogoPathConvert } from '../../store/actions';
import { ERoleDescNames } from '../../models/utilitiesModel';

function Topbar(props) {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const locationcheck = () => props.location.pathname;
    const matchpath = locationcheck();
    const menuData = useSelector(state => state?.SessionState?.menuData);
    const { userName, userFullName, profileUrl, userType } = useSelector(state => state?.SessionState?.userDto || {});
    const profileBase64logoPath = useSelector(state => state?.Layout?.profileBase64logoPath || undefined);

    useEffect(() => {
        if (!profileBase64logoPath && profileUrl)
            dispatch(requestBase64ProfileLogoPathConvert(profileUrl));
    }, [profileBase64logoPath]);

    const subMenuData = menuData ?
        (menuData.find(x => x.subModules.findIndex(y => '/' + y.link === matchpath) !== -1))
        : undefined
    console.log('subMenuData=>', { subMenuData, menuData });

    const redirectPath = (path) => {
        if (matchpath !== '/' + path) {
            console.log('path=>', path);
            props.history.push('/' + path)
        }
    }

    let userRole = (role) => {
        switch (role) {
            case 'pa': return ERoleDescNames.pa
            case 'ua': return ERoleDescNames.ua
            case 'tr': return ERoleDescNames.tr
            case 'ms': return ERoleDescNames.ms
            case 'rs': return ERoleDescNames.rs
            case 'eds': return ERoleDescNames.eds
            case 'pc': return ERoleDescNames.pc
        }
    }

    return (
        <div className='header-parent'>
            <header className='header'>
                <div className="page-title">
                    {subMenuData && <> {t('MenuItems.' + subMenuData.moduleName)}</>}
                </div>
                <div className="user-settings">
                    <ul>
                        <UniversityThemeAndLogoConfiguration />
                        {/* <li><a onClick={() => { }}><span className="Notification-icon"><small>2</small></span></a></li> */}
                        <li><a onClick={() => { }}>
                            <div className='user-details'>
                                <h3>{userFullName || userName}
                                    <p className="userrole">{userRole(userType)}</p>
                                    <p className="viewpfltext" onClick={() => { props.history.push('/profile') }}>View My Profile
                                        <img src={ProfileArrow} width="12" className="ml-1" /> </p>
                                </h3>
                                {/* <span className="user-profile"></span> */}
                                <div className="profile-image">
                                    {/* <img src={profileBase64logoPath} alt="ProfilePhoto" style={{ width: "70px", margin: "10px" }} /> */}
                                    {profileBase64logoPath !== 'data:' && (profileBase64logoPath || profileUrl) ? <img src={profileBase64logoPath || profileUrl} alt="ProfilePhoto" style={{ height: "50px", width: "50px" }} /> : <span className="user-profile"></span>}
                                </div>
                            </div>
                        </a>
                        </li>
                    </ul>
                </div>
            </header>

            {subMenuData?.subModules?.length > 1 && <div className="tabs">
                <ul>
                    {subMenuData.subModules.map((x, index) => {
                        return (<li className={matchpath === '/' + x.link ? "active" : ""} onClick={() => redirectPath(x.link)} key={index} ><button>{t('MenuItems.' + x.subModuleName)}</button></li>)
                    })}
                </ul>
            </div>}
        </div>
    );
}
export default withRouter((React.memo(Topbar)));