import React, { Component } from 'react';

class Footer extends Component {

    render() {
        return (
            <React.Fragment>
                <div className="ftrshade"></div>
                <footer className="footer">
                    © 2020 <span className="d-none d-sm-inline-block"> Copyright version | License agreement.</span>
                </footer>
            </React.Fragment>
        );
    }
}

export default Footer;






