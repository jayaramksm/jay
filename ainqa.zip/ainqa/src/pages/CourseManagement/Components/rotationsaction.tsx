import React, { useContext } from 'react';
import { Row, Col, FormGroup, Label, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { useDispatch } from 'react-redux'
import { setCourseManagementActionTypeAndActionData, addOrEditRotationsInCourseManagementRequest } from '../../../store/actions';
import { EOprationalActions, ISessionstate, IUserDetails } from '../../../models/utilitiesModel';
import { SuperParentContext } from '../Container/coursemanagementcontext';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { MySelect, customContentValidation } from '../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import { IDenominations, IRotations } from '../../../models/courseManagementModel';


const RotationsAction: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const context = useContext(SuperParentContext);

    const actionData: IRotations = useSelector((state: any) => {
        if (state?.courseManagementReducer?.actionData)
            return state.courseManagementReducer.actionData;
        else return undefined;
    });

    const userDto: IUserDetails | any = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return (state.SessionState as ISessionstate).userDto
        else return undefined;
    });

    const actionType: number = useSelector((state: any) => {
        if (state?.courseManagementReducer?.actionType)
            return state.courseManagementReducer.actionType;
        else return EOprationalActions.UNSELECT;
    });

    const programDenominations: IDenominations[] = useSelector((state: any) => {
        if (state?.courseManagementReducer?.phaseDenominations)
            return state.courseManagementReducer.phaseDenominations;
        else return [];
    });

    let durationOptions = [
        { label: '1 month', value: '1' },
        { label: '2 months', value: '2' },
        { label: '3 months', value: '3' },
        { label: '4 months', value: '4' },
        { label: '5 months', value: '5' },
        { label: '6 months', value: '6' },
        { label: '7 months', value: '7' },
        { label: '8 months', value: '8' },
        { label: '9 months', value: '9' },
        { label: '10 months', value: '10' },
        { label: '11 months', value: '11' },
        { label: '12 months', value: '12' },
    ]

    let duration = durationOptions.find(x => x.value === actionData?.rotationDuration);
    let stage = programDenominations.find(x => x.phaseDenominationId === actionData?.phaseDenominationId);

    const rotationsInitialValues = () => ({
        rotationId: actionData?.rotationId ?? 0,
        programCode: userDto?.program?.programCode ?? '',
        programName: userDto?.program?.programName ?? '',
        rotationName: actionData?.rotationName ?? '',
        rotationCode: actionData?.rotationCode ?? '',
        duration: actionData ? duration : '',
        stage: actionData ? stage : '',
        universityName: userDto?.university?.universityName,
        universityCode: userDto?.university?.universityCode,
        iswbaModified: false,
        deletedWbaInfo: []
    });

    const goBackToList = () => dispatch(setCourseManagementActionTypeAndActionData(EOprationalActions.UNSELECT, null));

    const validationSchema = Yup.object().shape({
        rotationName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 50, 4),
        rotationCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 1),
        duration: customContentValidation(t, t('controleErrors.required')),
        stage: customContentValidation(t, t('controleErrors.required')),
    })

    return (
        <>
            <div className="breadcrumbs">
                <span className="pointer" onClick={goBackToList}>{t('CourseManagement.listOfRotations')}</span>
                <span><i className="ti-angle-right"></i></span>
                <span className="active">{t('CourseManagement.addRotations')}</span>
            </div>


            <div className="flexScroll">
                <Formik
                    initialValues={rotationsInitialValues()}
                    validationSchema={validationSchema}
                    onSubmit={(values) => {
                        let action = actionType === EOprationalActions.EDIT ? EOprationalActions.EDIT : EOprationalActions.ADD;
                        dispatch(addOrEditRotationsInCourseManagementRequest(values, action));
                        console.log('onSubmit===>', values);
                    }}
                >
                    {
                        ({ values, errors, touched, setFieldValue, setFieldTouched, dirty }) => {

                            return <Form>
                                <div className="top-section">
                                    <h2>{t('CourseManagement.rotationDetails')}</h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.programCode')}</Label>
                                                    <Field type="text" name='programCode' disabled placeholder={t('CourseManagement.programCode')} className='form-control' />
                                                    <ErrorMessage name='programCode' component='div' className='text-danger' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.programName')}</Label>
                                                    <Field type="text" name='programName' disabled placeholder={t('CourseManagement.programName')} className='form-control' />
                                                    <ErrorMessage name='programName' component='div' className='text-danger' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.rotationName')}</Label>
                                                    <Field autoComplete='off' type="text" disabled={actionType === EOprationalActions.SELECT ? true : false} name='rotationName' placeholder={t('CourseManagement.rotationName')} className='form-control' />
                                                    <ErrorMessage name='rotationName' component='div' className='text-danger' />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.rotationCode')}</Label>
                                                    <Field autoComplete='off' name='rotationCode' disabled={actionType === EOprationalActions.SELECT ? true : false} type="text" placeholder={t('CourseManagement.rotationCode')} className='form-control' />
                                                    <ErrorMessage name='rotationCode' component='div' className='text-danger' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.duration')}</Label>
                                                    <MySelect
                                                        name="roles"
                                                        placeholder={t('CourseManagement.duration')}
                                                        isDisabled={actionType === EOprationalActions.SELECT ? true : false}
                                                        value={values.duration}
                                                        onChange={(e) => { setFieldValue('duration', e ? e : ''); }}
                                                        options={durationOptions ? durationOptions : []}
                                                        // getOptionLabel={option => option.roleName}
                                                        // getOptionValue={option => option.roleId}
                                                        onBlur={() => setFieldTouched('duration', true)}
                                                        noOptionsMessage={() => 'NoDataFound'}
                                                    />
                                                    {errors.duration && touched.duration && (
                                                        <div className="text-danger">{errors.duration}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>

                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.phaseorstages')}</Label>
                                                    <MySelect
                                                        name="roles"
                                                        placeholder={t('CourseManagement.phaseorstages')}
                                                        isDisabled={actionType === EOprationalActions.SELECT ? true : false}
                                                        value={values.stage}
                                                        onChange={(e) => { setFieldValue('stage', e ? e : ''); }}
                                                        options={programDenominations}
                                                        getOptionLabel={option => option.phaseDenomitationName}
                                                        getOptionValue={option => option.phaseDenominationId}
                                                        onBlur={() => setFieldTouched('stage', true)}
                                                        noOptionsMessage={() => 'NoDataFound'}
                                                    />
                                                    {errors.stage && touched.stage && (
                                                        <div className="text-danger">{errors.stage}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.universityName')}</Label>
                                                    <Field type="text" name='universityName' disabled placeholder={t('CourseManagement.universityName')} className='form-control' />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('CourseManagement.universityCode')}</Label>
                                                    <Field type="text" name='universityCode' disabled placeholder={t('CourseManagement.universityCode')} className='form-control' />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="section-fill">
                                        <h2>{t('CourseManagement.wbaDetails')}</h2>
                                        {actionType !== EOprationalActions.SELECT && <context.addWbaDetails handleWbaModification={setFieldValue} values={values.deletedWbaInfo} />}
                                    </div>
                                </div>
                                <context.wbaTableView handleWbaModification={setFieldValue} values={values.deletedWbaInfo} isRlafiled={actionData?.isRlaFiled} />
                                <div className="sub-form-footer mr-3 mt-3">
                                    <button type='button' className="btn btn-cancel" onClick={goBackToList}>{t('ActionNames.cancel')}</button>

                                    {actionType !== EOprationalActions.SELECT && <button type='submit' disabled={actionType === EOprationalActions.EDIT ? !dirty : false} className="btn btn-submit">
                                        {actionType === EOprationalActions.EDIT ? t('ActionNames.update') : t('ActionNames.create')}
                                    </button>}
                                </div>
                            </Form>
                        }
                    }
                </Formik>
            </div>
        </>
    )
}

export default React.memo(RotationsAction);