import React from 'react';
import { Row, Col, FormGroup, Label } from 'reactstrap';
import { Formik, Field, ErrorMessage, useFormikContext } from 'formik';
import * as Yup from 'yup';
import { customContentValidation, MySelect } from '../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import { addOrEditOrDeleteWBADetailsOfRotationsRequest, setWbaActionTypeAndActionData } from '../../../store/actions';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { useSelector } from 'react-redux';
import { IWba } from 'models/courseManagementModel';

const AddWBADetails: React.FC = (props: any) => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionData: IWba = useSelector((state: any) => {
        if (state?.courseManagementReducer?.wbaActionData)
            return state.courseManagementReducer.wbaActionData;
        else return undefined;
    });

    const wbaactionType: number = useSelector((state: any) => {
        if (state?.courseManagementReducer?.wbaActionType)
            return state.courseManagementReducer.wbaActionType;
        else return EOprationalActions.ADD;
    });

    const actionType: number = useSelector((state: any) => {
        if (state?.courseManagementReducer?.actionType)
            return state.courseManagementReducer.actionType;
        else return EOprationalActions.UNSELECT;
    });

    const wbaDetails: IWba[] = useSelector((state: any) => {
        if (state?.courseManagementReducer?.wbaDetails)
            return state.courseManagementReducer.wbaDetails;
        else return [];
    });

    const wbaDetailsLength: any = useSelector((state: any) => {
        if (state?.courseManagementReducer?.wbaDetails?.length)
            return state.courseManagementReducer.wbaDetails.length;
        else return 0;
    });
    console.log('AddWBADetails==>', { wbaDetails, wbaDetailsLength });


    const wbaOptions = (() => {
        return [
            { value: 'cbd', label: 'CBD', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "cbd") },
            { value: 'cex', label: 'CEX', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "cex") },
            { value: 'msf', label: 'MSF', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "msf") },
            { value: 'dops', label: 'DOPS', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "dops") },
            { value: 'pba', label: 'PBA', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "pba") },
            { value: 'psa', label: 'PSA', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "psa") },
            { value: 'notsa', label: 'NOTSA', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "notsa") },
            { value: 'doce', label: 'DOCE', isDisabled: wbaDetails.find(x => (x.wbaName.value ?? x.wbaName) === "doce") }
        ];
    })();

    let wba = wbaOptions.find(x => x.value === actionData?.wbaName);

    const initialValues = () => ({
        wbaId: actionData?.wbaId ?? '',
        wbaName: actionData ? wba : '',
        wbaExpected: actionData?.wbaExpected ?? '',
    });

    const validationSchema = Yup.object().shape({
        wbaName: customContentValidation(t, t('controleErrors.required')),
        wbaExpected: customContentValidation(t, t('controleErrors.required'), { patternType: 'numbersWithoutZero', message: 'numberWithoutZero', spacialChar: '' }, 2, 1),
    })

    const cancleWbadetails = () => {
        dispatch(setWbaActionTypeAndActionData(EOprationalActions.ADD, undefined))
    }

    const addWBa = (submitForm, resetForm, isValid, dirty, values) => {
        submitForm();
        if (isValid && dirty) {
            let action = wbaactionType === EOprationalActions.EDIT ? EOprationalActions.EDIT : EOprationalActions.ADD;
            let data = {
                ...values,
                wbaId: props.deletedWbaInfo?.length > 0 ? props.deletedWbaInfo?.find(x => (x.wbaName?.value || x.wbaName) === (values.wbaName?.value || values.wbaName)) : values.wbaId || values.wbaId
            }
            dispatch(addOrEditOrDeleteWBADetailsOfRotationsRequest(data, action))
            resetForm();
        }
        if (actionType === EOprationalActions.EDIT) {
            props.handleWbaModification('iswbaModified', true);
        }
    }

    return (
        <>
            <div className="details-section">
                <Formik
                    enableReinitialize
                    initialValues={initialValues()}
                    validationSchema={validationSchema}
                    onSubmit={(values, { resetForm }) => {
                        console.log('onSubmit==>', values);
                    }}
                >
                    {
                        ({ dirty, resetForm, submitForm, setFieldValue, setFieldTouched, isValid, values, errors, touched }) => (
                            <>
                                <Row className="mt-3">
                                    <Col sm="6" lg="4">
                                        <FormGroup>
                                            <Label>{t('CourseManagement.wbaName')}</Label>
                                            <MySelect
                                                name="roles"
                                                placeholder={t('CourseManagement.wbaName')}
                                                isDisabled={false}
                                                value={values.wbaName}
                                                onChange={(e) => { setFieldValue('wbaName', e ? e : ''); }}
                                                options={wbaOptions}
                                                // getOptionLabel={option => option.phaseDenomitationName}
                                                // getOptionValue={option => option.phaseDenominationId}
                                                onBlur={() => setFieldTouched('wbaName', true)}
                                                noOptionsMessage={() => 'NoDataFound'}
                                            />
                                            {errors.wbaName && touched.wbaName && (
                                                <div className="text-danger">{errors.wbaName}</div>
                                            )}
                                        </FormGroup>
                                    </Col>

                                    <Col sm="6" lg="4">
                                        <FormGroup>
                                            <Label>{t('CourseManagement.wbaExpected')}</Label>
                                            <Field type="text" name='wbaExpected' placeholder={t('CourseManagement.wbaExpected')} className='form-control' />
                                            <ErrorMessage name='wbaExpected' component='div' className='text-danger' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="my-3 justify-content-center">
                                    <button type='button'
                                        disabled={wbaactionType === EOprationalActions.EDIT && (!dirty)}
                                        className="blue-button mr-3" onClick={() => addWBa(submitForm, resetForm, dirty, isValid, values)}>
                                        {wbaactionType === EOprationalActions.EDIT ? t('CourseManagement.updateWba') : t('CourseManagement.addWba')}
                                    </button>
                                    {wbaactionType === EOprationalActions.EDIT && <button type='button'
                                        className="btn btn-danger" onClick={cancleWbadetails}> {t('ActionNames.cancel')}
                                    </button>}
                                </Row>
                            </>
                        )
                    }
                </Formik>
            </div>
        </>
    )
}

export default React.memo(AddWBADetails);