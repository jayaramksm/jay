import React, { useContext, useState } from 'react';
import { ParentContext, SuperParentContext } from '../Container/coursemanagementcontext'
import { useSelector } from 'react-redux';
import { getEnvironment } from 'helpers/helpersIndex';
import { PaginationComponent } from '../../../pages/utilities/PaginationComponent';
import { useTranslation } from 'react-i18next';
import { IRotations } from '../../../models/courseManagementModel';

const RotationsViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const [currentPage, setCurrentPage] = useState(0);
    const pageSize = getEnvironment.pageSize;
    const { t } = useTranslation('translations');

    const allRotations: IRotations[] = useSelector((state: any) => state?.courseManagementReducer?.totalRotations);

    const totalRotationsLength: number = useSelector((state: any) => {
        if (state?.courseManagementReducer?.totalRotations?.length)
            return state.courseManagementReducer.totalRotations.length;
        else return 0;
    });
    console.log('totatalRotationsLength=>', totalRotationsLength);

    const searchKey: string = useSelector((state: any) => {
        if (state?.courseManagementReducer?.searchKey)
            return state.courseManagementReducer.searchKey;
        else return '';
    });

    const rotationsFilterData: any = (allRotations?.length && searchKey !== '') ? allRotations?.filter((x: any) => (
        searchKey !== '' ? x.rotationName.toLowerCase().startsWith(searchKey.toLowerCase()) ? true :
            x.rotationCode.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : allRotations;

    let pagesCount: number = Math.ceil((rotationsFilterData ? rotationsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        setCurrentPage(index)
    };

    return (
        <>
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent table-responsive">
                        <table className="w100 myTable rotationsTable table">
                            <thead>
                                <tr>
                                    <th>{t('CourseManagement.programCode')}</th>
                                    <th>{t('CourseManagement.programName')}</th>
                                    <th>{t('CourseManagement.rotationName')}</th>
                                    <th>{t('CourseManagement.rotationCode')}</th>
                                    <th>{t('CourseManagement.duration')}</th>
                                    <th>{t('CourseManagement.phaseorstages')}</th>
                                    <th className="column-center">{t('CourseManagement.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rotationsFilterData?.length > 0 &&
                                    rotationsFilterData?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                        .map((x) => {
                                            return (
                                                <ParentContext.Provider value={x.rotationId} key={x.rotationId}>
                                                    <context.rotationView />
                                                </ParentContext.Provider>
                                            )
                                        })
                                }
                            </tbody>
                        </table>
                        {(rotationsFilterData?.length === 0) && searchKey === '' && <div className="norecordsfound"><h6>{t('CourseManagement.noRotationsData')}</h6></div>}
                        {(rotationsFilterData?.length === 0) && searchKey !== '' && <div className="norecordsfound"><h6>{t('CourseManagement.noDataFound')}</h6></div>}
                    </div>
                </div>
            </div>
            {rotationsFilterData?.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}

export default React.memo(RotationsViewParent);