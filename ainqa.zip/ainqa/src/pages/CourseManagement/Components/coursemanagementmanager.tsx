import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { SuperParentContext } from '../Container/coursemanagementcontext'

const CourseManagementManager: React.FC = () => {

    const context = useContext(SuperParentContext);

    const isActionType = useSelector((state: any) => {
        if (state?.courseManagementReducer)
            return state.courseManagementReducer?.actionType === EOprationalActions.UNSELECT ? true : false
        else return true;
    });

    return (
        <>
            {isActionType && <context.rotationsFilter />}
            <div className="maincontent flexLayout">
                {isActionType ? <context.rotationsParentview /> : <context.rotationsAction />}
            </div>
        </>
    )
}

export default React.memo(CourseManagementManager);