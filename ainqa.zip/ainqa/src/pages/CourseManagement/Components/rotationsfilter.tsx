import React from 'react';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux'
import { setCourseManagementActionTypeAndActionData, setSearchKeyInCourseManagementRotations } from '../../../store/actions';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';

const RotationsFilter: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const showRotationsSearch: boolean = useSelector((state: any) => !!(state?.courseManagementReducer?.totalRotations?.length > 2));
    const addRotation = () => dispatch(setCourseManagementActionTypeAndActionData(EOprationalActions.ADD, null));
    const handleOnChange = e => dispatch(setSearchKeyInCourseManagementRotations(e.target.value));

    return (
        <>
            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title">{t('CourseManagement.listofExistingRotations')}</h3>
                </Col>
                {<div className="rgtFilter">
                    {showRotationsSearch && <div className="search-box">
                        <div className="search-text"><input type="text" placeholder={t('CourseManagement.search')} onChange={handleOnChange}></input><i className="ti-search icon"></i></div>
                    </div>}
                    <button className="addnewButn" onClick={addRotation}><i className="ti-plus"></i> {t('CourseManagement.addRotations')}</button>
                    {/* <button className="iconBtn"><img src={UploadFile} alt="" style={{width:"18px"}}></img></button> */}
                </div>}
            </Row>
        </>
    )
}
export default React.memo(RotationsFilter);