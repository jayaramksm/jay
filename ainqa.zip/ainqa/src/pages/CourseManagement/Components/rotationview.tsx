import React, { useContext } from 'react';
import EditIcon from '../../../images/Edit.svg';
import Delete from '../../../images/Delete.svg';
import { ParentContext } from '../Container/coursemanagementcontext';
import { useDispatch, useSelector } from 'react-redux'
import { setCourseManagementActionTypeAndActionData, getDeleteRotationsInCourseManagementRequest } from '../../../store/actions';
import { EOprationalActions, IProgram } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { IRotations } from '../../../models/courseManagementModel';
import viewicon from '../../../images/View.svg';


const RotationView: React.FC = () => {

    const context = useContext(ParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const rotation: IRotations = useSelector((state: any) => {
        if (state?.courseManagementReducer?.totalRotations)
            return state.courseManagementReducer.totalRotations.find(x => x.rotationId === context);
        else return undefined;
    });

    const programInfo: IProgram = useSelector((state: any) => {
        if (state?.SessionState?.userDto?.program)
            return state.SessionState.userDto.program
        else return undefined;
    });

    const editRotation = () => {
        dispatch(setCourseManagementActionTypeAndActionData(EOprationalActions.EDIT, rotation))
    };

    const viewRotation = () => {
        dispatch(setCourseManagementActionTypeAndActionData(EOprationalActions.SELECT, rotation))
    }

    // const deleteRotation = () => {
    //     let confirmMessage = t('CourseManagement.confirmMessages.CMC1');
    //     dispatch(getDeleteRotationsInCourseManagementRequest(rotation?.id, false, confirmMessage))
    // }

    return (
        <>
            {rotation && <tr>
                <td>{programInfo?.programCode}</td>
                <td>{programInfo?.programName}</td>
                <td>{rotation.rotationName}</td>
                <td>{rotation.rotationCode}</td>
                <td>{rotation.rotationDuration}</td>
                <td>{rotation.phaseDenominationName}</td>
                <td className="column-center">
                    {rotation.isRlaFiled ? '-' : <span onClick={editRotation}> <img src={EditIcon} className="actionicon pointer" alt=""></img></span>}
                    {rotation.isRlaFiled && <span><img src={viewicon} alt="view" className="actionicon pointer" onClick={viewRotation} /></span>}
                    {/* <span onClick={deleteRotation}> <img src={Delete} alt="" className="actionicon pointer"></img></span> */}
                </td>
            </tr>}
        </>
    )
}

export default React.memo(RotationView);