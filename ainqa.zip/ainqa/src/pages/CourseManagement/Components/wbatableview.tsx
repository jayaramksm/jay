import React, { useState } from 'react';
import EditIcon from '../../../images/Edit.svg';
import Delete from '../../../images/Delete.svg';
import { useSelector, useDispatch } from 'react-redux';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { PaginationComponent } from '../../../pages/utilities/PaginationComponent';
import { addOrEditOrDeleteWBADetailsOfRotationsRequest, setWbaActionTypeAndActionData } from '../../../store/actions';
import { EOprationalActions } from 'models/utilitiesModel';
import { IWba } from '../../../models/courseManagementModel';

const WBATableView: React.FC = (props: any) => {

    const [currentPage, setCurrentPage] = useState(0);
    const pageSize = getEnvironment.pageSize;
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const wbaDetails: IWba[] = useSelector((state: any) => {
        if (state?.courseManagementReducer?.wbaDetails)
            return state.courseManagementReducer.wbaDetails;
        else return [];
    });

    const wbaDetailsLength: any = useSelector((state: any) => {
        if (state?.courseManagementReducer?.wbaDetails?.length)
            return state.courseManagementReducer.wbaDetails.length;
        else return 0;
    });
    console.log('__WBATableView==>', wbaDetailsLength);

    let pagesCount: number = Math.ceil((wbaDetails ? wbaDetails.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        setCurrentPage(index)
    };

    const editWbaDetails = (wba) => {
        dispatch(setWbaActionTypeAndActionData(EOprationalActions.EDIT, wba))
    }

    const deletewbaDetails = (wba) => {
        console.log('wbaDetails==>', wba)
        props.handleWbaModification('deletedWbaInfo', [wba, ...props.values]);
        props.handleWbaModification('iswbaModified', true);
        dispatch(addOrEditOrDeleteWBADetailsOfRotationsRequest(wba, EOprationalActions.DELETE))
    }
    return (
        <>
            <div className="main-table no-border">
                <div className="tbl-parent table-responsive">
                    <table className="w100 myTable programWBATable table mt-3">
                        <thead>
                            <tr>
                                <th>{t('CourseManagement.wbaName')}</th>
                                <th>{t('CourseManagement.wbaExpected')}</th>
                                <th className="column-center">{t('CourseManagement.actions')}</th>
                            </tr>
                        </thead>
                        <tbody>

                            {wbaDetails.length > 0 &&
                                wbaDetails.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                    .map((x, i) => {
                                        return (
                                            <tr key={x.wbaName || x.wbaName?.value}>
                                                <td>{x.wbaName.value || x.wbaName}</td>
                                                <td>{x.wbaExpected}</td>
                                                <td className="column-center">
                                                    {props.isRlafiled ? '-' : <>
                                                        <span><img src={EditIcon} onClick={() => editWbaDetails(x)} className="actionicon pointer" alt=""></img></span>
                                                        <span><img src={Delete} onClick={() => deletewbaDetails(x)} alt="" className="actionicon pointer"></img></span>
                                                    </>}
                                                </td>
                                            </tr>
                                        )
                                    })
                            }
                        </tbody>
                    </table>
                    {(wbaDetails.length === 0) && <div className="norecordsfound"><h6>{t('CourseManagement.noWbaData')}</h6></div>}
                </div>
            </div>
            {wbaDetails.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}

export default React.memo(WBATableView);