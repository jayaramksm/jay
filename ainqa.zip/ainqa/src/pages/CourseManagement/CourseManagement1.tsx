import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Pagination, PaginationItem, PaginationLink } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Scrollbars } from 'react-custom-scrollbars';
import EditIcon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';

import Select from 'react-select';

class CourseManagement1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            activeTab: "1",
            fileName: "No file Choosen"
        };
        this.toggle = this.toggle.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this)
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }
    toggle = tab => {
        this.setState({ activeTab: tab })
    }
    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    handleFileChange = (event) => {
        this.setState({ fileName: event.target.files[0].name })
    }

    programCodes = [{ value: 'pg123', label: 'PG123' },
    { value: 'pg113', label: 'PG113' },
    { value: 'pg232', label: 'PG232' },
    { value: 'pg436', label: 'PG436' }];

    durationOptions = [{ value: '3months', label: '3 Months' },
    { value: '6months', label: '6 Months' },
    { value: '9months', label: '9 Months' }];

    wbaOptions = [{ value: 'cbd', label: 'CBD' },
    { value: 'cex', label: 'CEX' },
    { value: 'msf', label: 'MSF' },
    { value: 'dops', label: 'DOPS' },
    { value: 'pba', label: 'PBA' }];


    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of Existing Rotations</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box">
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Add Rotation</button>
                            {/* <button className="iconBtn"><img src={UploadFile} alt="" style={{width:"18px"}}></img></button> */}
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            <div className="main-table">
                                <div className="rotationsTable tbl-parent table-responsive">
                                    <table className="w100 myTable usersTable table">
                                        <thead>
                                            <tr>
                                                <th>Program Code</th>
                                                <th>Program Name</th>
                                                <th>Rotation Name</th>
                                                <th>Rotation Code</th>
                                                <th>Duration</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>PG123</td>
                                                <td>Family Medicine</td>
                                                <td>Rotation 1</td>
                                                <td>ROUM123</td>
                                                <td>4 Months</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>PG113</td>
                                                <td>Ortho</td>
                                                <td>Rotation 1</td>
                                                <td>ROUM123</td>
                                                <td>2 Months</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>PG232</td>
                                                <td>General Surgery</td>
                                                <td>Rotation 1</td>
                                                <td>ROUM123</td>
                                                <td>4 Months</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>PG436</td>
                                                <td>Cardiology</td>
                                                <td>Rotation 1</td>
                                                <td>ROUM123</td>
                                                <td>4 Months</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div className="pagination">
                                        <Pagination aria-label="Page navigation example">
                                            <PaginationItem>
                                                <PaginationLink first href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink previous href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    1
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    2
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    3
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    4
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    5
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink next href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink last href="#" />
                                            </PaginationItem>
                                        </Pagination>
                                    </div>
                                </div>
                            </div>

                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Rotations</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Add Rotation</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="top-section">
                                <h2>Rotation Details</h2>
                                <div className="details-section">
                                    <Row className="vhcenter mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Program Code</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.programCodes}
                                                    placeholder="Select Program"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Program Name</Label>
                                                <Input type="text" disabled placeholder="Family Medicine"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Rotation Name</Label>
                                                <Input type="text" placeholder="Rotation Name"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Rotation Code</Label>
                                                <Input type="text" placeholder="RO98"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Duration</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.durationOptions}
                                                    placeholder="Select Duration"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University Name</Label>
                                                <Input type="text" disabled placeholder="University of Malay"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University Code</Label>
                                                <Input type="text" disabled placeholder="University of Malay"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>

                                <h2>WBA Details</h2>
                                <div className="details-section">
                                    <Row className="mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>WBA Name / Type</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.wbaOptions}
                                                    placeholder="Select WBA Type"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>WBA Minimum / expected</Label>
                                                <Input type="text" placeholder="Enter Count"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4" className="upload-btn">
                                            <FormGroup>
                                                <Label>Digital Form / Attachment</Label>
                                                <input type="file" id="actual-btn" hidden onChange={(e) => this.handleFileChange(e)} />
                                                <div id="blockele">
                                                    <div className="d-flex flex-row file-chosen-sm"><div className="mr-2"><i className="ti-folder"></i> </div><div className="fu-fileName-sm">{this.state.fileName}</div></div>
                                                    <label htmlFor="actual-btn" className="choose">Upload File</label>
                                                </div>
                                            </FormGroup>

                                        </Col>
                                    </Row>

                                    <Row className="main-form-footer mt-3">
                                        <button className="submit-button">Add WBA</button>
                                    </Row>
                                </div>
                            </div>

                            <div className="main-table">
                                <div className="programWBATable tbl-parent table-responsive">
                                    <table className="w100 myTable usersTable table">
                                        <thead>
                                            <tr>
                                                <th>WBA Name / Type</th>
                                                <th>WBA Minimum / Expected</th>
                                                <th>Digital Form / Attachment</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>CBD</td>
                                                <td>02</td>
                                                <td><span className="fileName">File01.jpg</span></td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>CEX</td>
                                                <td>03</td>
                                                <td><span className="fileName">File_21.jpg</span></td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div className="pagination">
                                        <Pagination aria-label="Page navigation example">
                                            <PaginationItem>
                                                <PaginationLink first href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink previous href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    1
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    2
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    3
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    4
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    5
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink next href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink last href="#" />
                                            </PaginationItem>
                                        </Pagination>
                                    </div>

                                    <Row className="sub-form-footer mt-3 mr-2">
                                        <button className="btn btn-cancel mr-3">Cancel</button>
                                        <button className="btn btn-submit">Submit</button>
                                    </Row>

                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(CourseManagement1));