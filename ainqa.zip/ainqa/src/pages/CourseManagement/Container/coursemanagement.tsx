import React, { Component } from 'react';
import { connect } from 'react-redux';
import { SuperParentContext } from './coursemanagementcontext';
import { activateAuthLayout, getAllRotationsAndPhaseDenominationsDetailsRequest, setResetCourseManagementStateRequest, cancelAllCourseManagementApiRequests } from '../../../store/actions';
import {
    CourseManagementManager,
    RotationsViewParent,
    RotationView,
    RotationsAction,
    RotationsFilter,
    AddWBADetails,
    WBATableView
} from './coursemanagementindex';

interface IProps {
    activateAuthLayout: any;
    getAllRotationsAndPhaseDenominationsDetailsRequest: any;
    setResetCourseManagementStateRequest: any;
    cancelAllCourseManagementApiRequests: any;

}

export class CourseManagement extends Component<IProps, any> {
    constructor(props) {
        super(props)

        this.state = {
            managerParent: {
                rotationsParentview: RotationsViewParent,
                rotationView: RotationView,
                rotationsAction: RotationsAction,
                rotationsFilter: RotationsFilter,
                addWbaDetails: AddWBADetails,
                wbaTableView: WBATableView
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetCourseManagementStateRequest();
        this.props.getAllRotationsAndPhaseDenominationsDetailsRequest();
    }

    componentWillUnmount() {
        this.props.setResetCourseManagementStateRequest();
        this.props.cancelAllCourseManagementApiRequests();
    }

    render() {
        return (
            <div className='flexLayout pr-0'>
                <SuperParentContext.Provider value={this.state.managerParent}>
                    <CourseManagementManager />
                </SuperParentContext.Provider>
            </div>
        )
    }
}

export default connect(null, { activateAuthLayout, getAllRotationsAndPhaseDenominationsDetailsRequest, setResetCourseManagementStateRequest, cancelAllCourseManagementApiRequests })(CourseManagement)