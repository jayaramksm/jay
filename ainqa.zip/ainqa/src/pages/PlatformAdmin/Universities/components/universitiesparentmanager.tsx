import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../container/universitiescontext';
import { EOprationalActions } from 'models/utilitiesModel';

const UniversitiesParentManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const showListView: boolean = useSelector((state: any) => {
        if (state?.universitiesReducer?.actionType)
            return state.universitiesReducer.actionType === EOprationalActions.UNSELECT;
        else return true;
    });

    return (
        <div className="maincontent flexLayout pr-0">
            {showListView ? (
                <>
                    <context.universityFilterComponent />
                    <context.universitiesListComponent />
                </>
            ) : <context.createOrEditComponent />}
        </div>
    )
}
export default UniversitiesParentManager;