import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col } from 'reactstrap';
import { setUniversitiesActionData, setUniversitiesSearchKey } from '../../../../store/actions';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';

const UniversityFilter: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const showSearch: boolean = useSelector((state: any) => {
        if (state?.universitiesReducer?.universitiesList?.length)
            return state.universitiesReducer.universitiesList.length > 2;
        else return false;
    });

    const addUniversity = () => dispatch(setUniversitiesActionData(EOprationalActions.ADD, null));
    const updateSearchKey = event => dispatch(setUniversitiesSearchKey(event.target.value));

    return (
        <Row className="compHeading">
            <Col>
                <h3 className="page-header header-title"> {t('Universities.listofUniversities')} </h3>
            </Col>
            <div className="rgtFilter">
                {showSearch && <div className="search-box">
                    <div className="search-text">
                        <input onChange={updateSearchKey} type="text" placeholder="Search" />
                        <i className="ti-search icon" />
                    </div>
                </div>}
                <button className="addnewButn" onClick={addUniversity}>
                    <i className="ti-plus" />
                    {t('Universities.addUniversity')}

                </button>
            </div>
        </Row>
    )
}
export default React.memo(UniversityFilter);