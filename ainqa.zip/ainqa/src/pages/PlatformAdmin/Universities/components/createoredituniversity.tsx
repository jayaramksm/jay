import React from 'react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, FormGroup, Label, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { MySelect, defultContentValidate, customContentValidation, emailContentValidate } from '../../../../helpers/helpersIndex';
import { createOrEditSingleUniversitiesRequest, setUniversitiesActionData } from '../../../../store/actions';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IUniversitiesModal } from '../../../../models/universitiesModal';

const countryOptions = [
    { value: 'MYS', label: 'Malaysia, Vinnence' },
    { value: 'IND', label: 'India, Telangana' },
    { value: 'IDN', label: 'Indonesia, Mali' }
];

function CreateOrEditUniversity() {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionType = useSelector((state: any) => {
        if (state && state.universitiesReducer && state.universitiesReducer.actionType)
            return (state.universitiesReducer as IUniversitiesModal).actionType;
        else
            return EOprationalActions.UNSELECT;
    });
    const actionData = useSelector((state: any) => state?.universitiesReducer?.actionData);
    const showUniversities = () => dispatch(setUniversitiesActionData(EOprationalActions.UNSELECT, null));

    const initialValues = () => ({
        universityName: actionData ? actionData.universityName : "",
        universityCode: actionData ? actionData.universityCode : "",
        universityCountry: actionData ? countryOptions.find(x => x.value === actionData.country) : "",
        universityLocation: actionData ? actionData.location : "",
        pincode: actionData ? actionData.pincode : "",
        contactName: actionData ? actionData.cname : "",
        email: actionData ? actionData.email : "",
        websiteAddress: actionData ? actionData.website : "",
        primaryContactName: actionData ? actionData.primaryName : "",
        primaryContactDesignation: actionData ? actionData.primaryContactDesignation : "",
        primaryContactNumber: actionData ? actionData.primaryContact : "",
        primaryContactEmailId: actionData ? actionData.primaryContactEmailId : "",
        secondaryContactName: actionData ? actionData.secondaryName : "",
        secondaryContactDesignation: actionData ? actionData.secondaryContactDesignation : "",
        secondaryContactNumber: actionData ? actionData.secondaryContact : "",
        secondaryContactEmailId: actionData ? actionData.secondaryContactEmailId : "",
        universityId: actionData ? actionData.universityId : ""
    });
    const validationSchema = Yup.object().shape({
        universityName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 2),
        universityCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 20, 2),
        universityCountry: defultContentValidate(t('controleErrors.required')),
        universityLocation: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'arabicnumaricspecial', spacialChar: '' }, 250, 2),
        pincode: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 10, 6),
        primaryContactName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 2),
        primaryContactDesignation: Yup.lazy((value) => {
            if (value !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 2)
            else return defultContentValidate('');
        }),
        // primaryContactDesignation: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 4),
        primaryContactNumber: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 12, 10),
        primaryContactEmailId: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        secondaryContactName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 2),
        secondaryContactDesignation: Yup.lazy((value) => {
            if (value !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 2)
            else return defultContentValidate('');
        }),
        // secondaryContactDesignation: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 4),
        secondaryContactNumber: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 12, 10),
        secondaryContactEmailId: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
    });

    return (
        <>
            <div className="breadcrumbs">
                <span className="pointer" onClick={showUniversities}> {t('Universities.listofUniversities')}</span>
                <span><i className="ti-angle-right"></i></span>
                <span className="active">{actionType === EOprationalActions.ADD ? t('Universities.addUniversity') : t('Universities.editUniversity')} </span>
            </div>
            <div className="flexLayout">
                <div className="flexScroll mydocuments">
                    <div className="maincontent paglayout">
                        <div className="top-section">

                            <Formik
                                initialValues={initialValues()}
                                validationSchema={validationSchema}
                                onSubmit={(values) => {
                                    dispatch(createOrEditSingleUniversitiesRequest(values, actionType));
                                    console.log("SubmitedValues==>", values);
                                }}>
                                {({ errors, setFieldValue, setFieldTouched, values, touched }) => (
                                    <Form>
                                        <h2> {t('Universities.universityDetails')}</h2>
                                        <div className="details-section">



                                            <Row className="vhcenter mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.universityName')}</Label>
                                                        <Field placeholder={t('Universities.universityName')} name="universityName" className={'form-control ' + (errors.universityName && touched.universityName ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="universityName" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.universityCode')}</Label>
                                                        <Field placeholder={t('Universities.universityCode')} name="universityCode" className={'form-control ' + (errors.universityCode && touched.universityCode ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="universityCode" component="div" className="invalid-feedback" />

                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.universityCountryandState')}</Label>
                                                        <MySelect
                                                            name="universityCountry"
                                                            placeholder={t('Universities.universityCountryandState')}
                                                            value={values.universityCountry}
                                                            onChange={(e) => setFieldValue('universityCountry', e ? e : '')}
                                                            options={countryOptions ? countryOptions : []}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            onBlur={() => setFieldTouched('universityCountry', true)}
                                                            noOptionsMessage={() => 'NoDataFound'}
                                                        />
                                                        {errors.universityCountry && touched.universityCountry && (
                                                            <div className="text-danger">{errors.universityCountry}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row>
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.universityLocation')}</Label>
                                                        <Field placeholder={t('Universities.universityLocation')} name="universityLocation" className={'form-control ' + (errors.universityLocation && touched.universityLocation ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="universityLocation" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.pincode')}</Label>
                                                        <Field placeholder={t('Universities.pincode')} name="pincode" className={'form-control ' + (errors.pincode && touched.pincode ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="pincode" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.websiteAddress')}</Label>
                                                        <Field placeholder={t('Universities.websiteAddress')} name="websiteAddress" className={'form-control ' + (errors.websiteAddress && touched.websiteAddress ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="websiteAddress" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                        <hr />
                                        <h2> {t('Universities.primaryContactDetails')} </h2>
                                        <div className="details-section">
                                            <Row className="vhcenter mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.primaryContactName')}</Label>
                                                        <Field placeholder={t('Universities.primaryContactName')} name="primaryContactName" className={'form-control ' + (errors.primaryContactName && touched.primaryContactName ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="primaryContactName" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.primaryContactDesignation')}</Label>
                                                        <Field placeholder={t('Universities.primaryContactDesignation')} name="primaryContactDesignation" className={'form-control ' + (errors.primaryContactDesignation && touched.primaryContactDesignation ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="primaryContactDesignation" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>

                                                        <Label>{t('Universities.primaryContactNumber')}</Label>
                                                        <Field placeholder={t('Universities.primaryContactNumber')} name="primaryContactNumber" className={'form-control ' + (errors.primaryContactNumber && touched.primaryContactNumber ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="primaryContactNumber" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row>
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.primaryContactEmailId')}</Label>
                                                        <Field placeholder={t('Universities.primaryContactEmailId')} name="primaryContactEmailId" className={'form-control ' + (errors.primaryContactEmailId && touched.primaryContactEmailId ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="primaryContactEmailId" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                            </Row>
                                        </div>
                                        <hr />
                                        <h2> {t('Universities.secondaryContactDetails')}</h2>
                                        <div className="details-section">
                                            <Row className="vhcenter mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.secondaryContactName')}</Label>
                                                        <Field placeholder={t('Universities.secondaryContactName')} name="secondaryContactName" className={'form-control ' + (errors.secondaryContactName && touched.secondaryContactName ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="secondaryContactName" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.secondaryContactDesignation')}</Label>
                                                        <Field placeholder={t('Universities.secondaryContactDesignation')} name="secondaryContactDesignation" className={'form-control ' + (errors.secondaryContactDesignation && touched.secondaryContactDesignation ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="secondaryContactDesignation" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>

                                                        <Label>{t('Universities.secondaryContactNumber')}</Label>
                                                        <Field placeholder={t('Universities.secondaryContactNumber')} name="secondaryContactNumber" className={'form-control ' + (errors.secondaryContactNumber && touched.secondaryContactNumber ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="secondaryContactNumber" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row>
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Universities.secondaryContactEmailId')}</Label>
                                                        <Field placeholder={t('Universities.secondaryContactEmailId')} name="secondaryContactEmailId" className={'form-control ' + (errors.secondaryContactEmailId && touched.secondaryContactEmailId ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="secondaryContactEmailId" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                            </Row>


                                            <div className="sub-form-footer mt-3">
                                                <button onClick={showUniversities} className="cancel-button">{t('Universities.cancel')}</button>
                                                <button className="blue-button">  {actionType === EOprationalActions.ADD ? t('Universities.create') : t('Universities.update')}</button>
                                            </div>
                                        </div>
                                    </Form>
                                )
                                }
                            </Formik>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(CreateOrEditUniversity);