import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import EditIcon from '../../../../images/Edit.svg';
import Approved from '../../../../images/Approved.svg';
import { IUniversity } from '../../../../models/universitiesModal';
import { ParentContext } from '../container/universitiescontext';
import { setUniversitiesActionData } from '../../../../store/actions';
import { EOprationalActions } from '../../../../models/utilitiesModel';
// import Delete from '../../../../images/Delete.svg';
// import Deactive from '../../../../images/Deactive.svg';

const UniversityListItem: React.FC = () => {
    const dispatch = useDispatch();
    const universityId = useContext(ParentContext);

    const universityItem: IUniversity | any = useSelector((state: any) => {
        if (state?.universitiesReducer?.universitiesList)
            return (state.universitiesReducer.universitiesList as IUniversity[]).find(university => university.universityId === universityId);
        else return undefined;
    });

    // const deactivateUniversity = () => { }
    const editUniversity = () => dispatch(setUniversitiesActionData(EOprationalActions.EDIT, universityItem));
    // const deleteUniversity = () => { }

    return (
        <tr>
            <td>{universityItem.universityName}</td>
            <td>{universityItem.universityCode}</td>
            <td>{universityItem.country}</td>
            <td>{universityItem.primaryName}</td>
            <td>{universityItem.secondaryName}</td>
            <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
            <td className="column-center">
                {/* <img onClick={deactivateUniversity} src={Deactive} className="actionicon pointer" alt="Deactive University"></img> */}
                <img onClick={editUniversity} src={EditIcon} className="actionicon pointer" alt="Edit University"></img>
                {/* <img onClick={deleteUniversity} src={Delete} className="actionicon pointer" alt="Delete University"></img> */}
            </td>
        </tr>
    )
}
export default React.memo(UniversityListItem);