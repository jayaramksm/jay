import React, { useContext, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { SuperParentContext, ParentContext } from '../container/universitiescontext';
import { IUniversity } from '../../../../models/universitiesModal';
import { PaginationComponent } from '../../../../pages/utilities/PaginationComponent';
import { getEnvironment, getFilteredDataAfterSearch } from '../../../../helpers/helpersIndex';
import { setUniversitiesPagination } from '../../../../store/actions';

const filterKeys = [];
const UniversitiesList: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const context: any = useContext(SuperParentContext);
    const pageSize = getEnvironment.pageSize;

    const universitiesList: IUniversity[] = useSelector((state: any) => state?.universitiesReducer?.universitiesList);
    const currentPage: number = useSelector((state: any) => state?.universitiesReducer?.currentPage || 0);
    const searchKey = useSelector((state: any) => state?.universitiesReducer?.searchKey || '');

    const universitiesData: IUniversity[] = (universitiesList?.length && searchKey !== '') ? universitiesList?.filter((x: IUniversity) => (
        searchKey !== '' ? x.universityName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : universitiesList;

    // const universitiesData = useMemo(() => {
    //     if (universitiesList.length && searchKey)
    //         return getFilteredDataAfterSearch(universitiesList, filterKeys, searchKey);
    //     return universitiesList;
    // }, [searchKey, universitiesList.length]);

    let pagesCount: number = Math.ceil((universitiesData ? universitiesData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setUniversitiesPagination(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_UniversitiesList_pagination_index=>', index);
        dispatch(setUniversitiesPagination(index));
    };
    console.log("_UniversitiesList=>", { universitiesList, universitiesData, currentPage, searchKey });

    return (
        <div className="flexLayout">
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent table-responsive">
                        <table className="w100 myTable universitiesTable table">
                            <thead>
                                <tr>
                                    <th> {t('Universities.universityName')}</th>
                                    <th> {t('Universities.universityCode')}</th>
                                    <th> {t('Universities.universityCountryandState')}</th>
                                    <th> {t('Universities.primaryContactName')}</th>
                                    <th> {t('Universities.secondaryContactName')}</th>
                                    <th className="column-center"> {t('Universities.activeStatus')}</th>
                                    <th className="column-center"> {t('Universities.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {universitiesData && universitiesData.length > 0 &&
                                    universitiesData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                        .map(university => (
                                            <React.Fragment key={university.universityId}>
                                                <ParentContext.Provider value={university.universityId}>
                                                    <context.universityListItemComponent />
                                                </ParentContext.Provider>
                                            </React.Fragment>
                                        ))}
                            </tbody>
                        </table>
                    </div>
                </div>
                {(universitiesData?.length === 0) && <div className="norecordsfound"><h6>{t('Universities.noUniversityFound')}</h6></div>}
            </div>
            {
                universitiesData && universitiesData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </div >
    )
}
export default React.memo(UniversitiesList);