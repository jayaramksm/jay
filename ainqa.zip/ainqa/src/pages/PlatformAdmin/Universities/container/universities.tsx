import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    UniversitiesParentManager,
    CreateOrEditUniversity,
    UniversitiesList,
    UniversityFilter,
    UniversityListItem
} from '../container/universitiesindex';
import { SuperParentContext } from '../container/universitiescontext';
import { activateAuthLayout, setResetForUniversities, getUniversitiesListRequest, cancelAllPendingUniversitiesRequest } from '../../../../store/actions';

interface IProps {
    activateAuthLayout: any;
    setResetForUniversities: any;
    getUniversitiesListRequest: any;
    cancelAllPendingUniversitiesRequest: any;
}
class Universities extends Component<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            manager: {
                createOrEditComponent: CreateOrEditUniversity,
                universitiesListComponent: UniversitiesList,
                universityFilterComponent: UniversityFilter,
                universityListItemComponent: UniversityListItem
            }
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForUniversities();
        this.props.getUniversitiesListRequest();
    }

    componentWillUnmount() {
        this.props.setResetForUniversities();
        this.props.cancelAllPendingUniversitiesRequest();
    }

    render() {
        return (
            <SuperParentContext.Provider value={this.state.manager}>
                <UniversitiesParentManager />
            </SuperParentContext.Provider>
        );
    }
}
export default connect(null, { activateAuthLayout, setResetForUniversities, getUniversitiesListRequest, cancelAllPendingUniversitiesRequest })(Universities);