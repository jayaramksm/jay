export { default as UniversitiesParentManager } from '../components/universitiesparentmanager';
export { default as CreateOrEditUniversity } from '../components/createoredituniversity';
export { default as UniversitiesList } from '../components/universitieslist';
export { default as UniversityFilter } from '../components/universityfilter';
export { default as UniversityListItem } from '../components/universitylistitem';