import React, { useState, useEffect } from 'react';
import PDFViewer from 'pdf-viewer-reactjs';
import { getAndConvertBase64String } from '../../helpers/helpersIndex';

interface IProps {
    path: string;
};
const PdfViewer: React.FC<IProps> = (props) => {
    const [base64path, setBase64path] = useState('');

    useEffect(() => {
        if (props.path)
            getAndConvertBase64String(props.path, setBase64path, 'odata');
    }, [props.path]);

    return (
        <>
            {base64path && <PDFViewer document={base64path === 'data:' ? { url: props.path } : { base64: base64path }} />}
        </>
    )
};
export default React.memo(PdfViewer);