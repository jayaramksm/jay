import React, { useRef } from 'react';
import { Row, Col, FormGroup, Label } from 'reactstrap';
// import uploadhistory from '../../images/History.svg';
import { EBulkUploadComponentNames, EBulkUploadStatus } from '../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { Formik, Form } from 'formik';
import Papa from 'papaparse';
import { DownloadCsv, ValueContainer, MySelect, Option, customContentValidation, defultContentValidate } from '../../helpers/helpersIndex';
import * as Yup from 'yup';
import { alertActionRequest } from '../../store/actions';
import { useDispatch } from 'react-redux';
import orderBy from 'lodash/orderBy';
import download from '../../images/Download.svg';


interface IProps {
  headers: any;
  sampleData: any;
  validationSchema: any;
  goBackToList: any;
  viewBulkUploadHistory: any;
  name: string;
  bulkuploadOnSumbit: any;
  options?: any[]
}


const BulkUpload: React.FC<IProps> = (props) => {
  const { headers, sampleData, validationSchema, goBackToList, viewBulkUploadHistory, name, bulkuploadOnSumbit, options } = props;
  const { t } = useTranslation('translations');
  const dispatch = useDispatch();
  let { current: validData } = useRef<any>([]);
  let { current: invalidData } = useRef<any>([]);

  const downloadSampleCsvFile = () => {
    const res = DownloadCsv(null, '', [{ ...sampleData }], name, '');
    console.log('DownloadCsvRequest=>', res);
  }

  const initialValues = () => ({
    fileName: '',
    extension: '',
    invalidFileError: '',
    fileData: '',
    fileVerification: '',
    phaseDistribution: '',
    denomination: "",
    denominationOptions: [],
    deptName: '',
    isFileValidFlag: ''
  })

  const startFileVerification = (setFieldValue, file) => {
    console.log('_startFileVerification_start', { file });
    if (file) {
      Papa.parse(file, {
        skipEmptyLines: 'greedy',
        delimiter: ',', header: true, newline: '\r\n',
        beforeFirstChunk: (chunk: string) => {
          var rows = chunk.split(/\r\n|\r|\n/);
          let headings = rows[0].split(',');
          console.log("chunk=>", chunk, headings);

          let missedHeadings = Object.keys(sampleData).filter(x => !(headings.some(y => y.toLowerCase() === x.toLowerCase())));
          if (missedHeadings.length > 0) {
            setFieldValue('invalidFileError', `${missedHeadings.join(',')} ${t('controleErrors.headersMissing')}`);
            console.log(headings, missedHeadings);
            return 'Missed Headings'
          } else {
            let index3 = headings.findIndex(x => x === null || (x + '').trim() === "");
            if (index3 !== -1) {
              setFieldValue('invalidFileError', t('controleErrors.emptyHeaders'));
              return "empty";
            }
          }
          // let duplicates = headings.filter((v, i, a) => a.findIndex(y => y.toLowerCase() === v.toLowerCase()) !== i)
          // console.log('duplicatesData==>', duplicates);
          let uniqueDuplicates = headings.reduce((duplicates: string[], header, ind, arr) => {
            if (arr.findIndex(y => (y + '').trim().toLowerCase() === (header + '').trim().toLowerCase()) !== ind)
              if (!duplicates.includes(header)) return [...duplicates, header.toLowerCase()];
            return duplicates;
          }, []);

          // let index4 = _.uniq(_.filter(headings, (v, i, a) => a.findIndex(x => (v + '').trim() === (x + '').trim()) !== i));
          if (uniqueDuplicates.length > 0) {
            setFieldValue('invalidFileError', `${uniqueDuplicates.join(',')} ${t('controleErrors.duplicateHeaders')}`);
            return "duplicate";
          }
          return chunk
        },
        complete: (results, file) => {
          console.log("results=>", { results, file });
          if (results.data.length > 0) {
            let _fileText = results.data;
            _fileText.forEach(async (x, ind) => {
              try {
                let result = await validationSchema.validate(x, { abortEarly: false })
                if (result) validData.push(result);
                console.log(`Result${ind}==>`, { result, validData })
              } catch (e) {
                let errorObj = {};
                let failureReason = e?.inner?.length > 0 ?
                  e.inner.reduce((totalErrorMsg, error) => {
                    errorObj[error.path] = `${errorObj[error.path]?.startsWith(error.path) ? '' : `${error.path}=>`}${errorObj[error.path] ? errorObj[error.path] : ''} ${error.message};`;
                    return Object.values(errorObj);
                  }, []).join(' ') : `${e.path}=> ${e.message}`;
                invalidData.push({ ...e.value, failedReason: failureReason });

                console.log(`errors=>${ind}`, e);
                console.log(`errors=>${ind}1`, invalidData);
              }
            });
            setTimeout(() => {
              if (!(validData.length > 0)) {
                console.log('invalidData==>', invalidData)
                DownloadCsv(undefined, undefined, invalidData, `invalidData_${name}`, undefined, '');
                console.log("onSubmit==>", { validData, invalidData });
                let alertMessagedata = {
                  message: t(`controleErrors.invalidData`),
                  status: false,
                  tranId: Date.now(),
                }
                dispatch(alertActionRequest(alertMessagedata));
              }

              if (validData?.length > 0)
                setFieldValue('isFileValidFlag', 'true');
            }, 0);
          }
          setFieldValue('fileVerification', EBulkUploadStatus.FILE_VALIDATED);
        }
      });
    }
    console.log('_startFileVerification_end', { validData, invalidData });
  }

  const uploadFileData = (e, setFieldValue) => {
    const fileList: FileList = e.target.files;
    console.log("frmData=>1", e.target.files);
    if (fileList.length > 0) {
      setFieldValue('extension', '');
      setFieldValue('fileName', '');
      setFieldValue('invalidFileError', '');
      setFieldValue('fileData', '');
      setFieldValue('fileVerification', '');
      setFieldValue('isFileValidFlag', '');

      // dispatch(setProgressOfTheFileValidation(0));
      validData = [];
      invalidData = [];

      const file: File = fileList[0];
      console.log("File", file);
      let extension = (file.name as string).split('.').pop();
      let fileSize = file.size / 1024 / 1024;

      if (fileSize < 5) {
        if (extension === 'csv') {
          setFieldValue('extension', extension);
          setFieldValue('fileName', fileList[0].name);
          setFieldValue('fileData', file);
        }
        else
          setFieldValue('invalidFileError', t('UsersManagement.bulkUploadInvalidFormat'));
        e.target.value = null;
      }
      else
        setFieldValue('invalidFileError', t('controleErrors.maxFileSize'));
    }
  }

  const selectPhaseDistribution = (setFieldValue, e) => {
    setFieldValue('phaseDistribution', e ? e : '');
    setFieldValue('denomination', '');

    const orderedDenominations = orderBy(e?.phaseDenominations || [], 'phaseDenomitationName');
    setFieldValue('denominationOptions', orderedDenominations);
  }

  const handleInvalidData = (fileData) => {
    if ((validData.length === 0) && fileData) {
      let alertMessagedata = {
        message: t(`controleErrors.invalidData`),
        status: false,
        tranId: Date.now(),
      }
      dispatch(alertActionRequest(alertMessagedata));
    }
  }

  return (
    <>
      <div className="maincontent paglayout">
        <div className="top-section mt-3">
          <div className="details-section">
            <Formik
              initialValues={initialValues()}
              validationSchema={Yup.object().shape({
                // phaseDistribution: customContentValidation(t, t('controleErrors.required'))
                isFileValidFlag: customContentValidation(t, t('controleErrors.validFile')),
                deptName: Yup.lazy(() => {
                  if (name === EBulkUploadComponentNames.HODS)
                    return customContentValidation(t, t('controleErrors.required'));
                  else
                    return defultContentValidate('');
                }),
                phaseDistribution: Yup.lazy(() => {
                  if (name === EBulkUploadComponentNames.PROGRAMS)
                    return customContentValidation(t, t('controleErrors.required'));
                  else
                    return defultContentValidate('');
                }),
                denomination: Yup.lazy(() => {
                  if (name === EBulkUploadComponentNames.PROGRAMS)
                    return customContentValidation(t, t('controleErrors.required'));
                  else
                    return defultContentValidate('');
                })

              })}
              onSubmit={(values) => {
                if (validData.length > 0)
                  bulkuploadOnSumbit(validData, invalidData, values);
                else {
                  console.log('enteringIntoOnSubmitElse')
                  handleInvalidData(values.fileData);
                }
              }}
            >
              {({ values, setFieldValue, errors, touched, setFieldTouched }) => (
                <Form>
                  {console.log('___bulkUpload', { errors, values })}
                  <Row>
                    {(name === EBulkUploadComponentNames.PROGRAMS) && <><Col lg="4" sm="12" xs="12">
                      <FormGroup>
                        <Label>{t('Programs.phaseDistribution')}</Label>
                        <MySelect
                          name="phaseDistribution"
                          isMulti={false}
                          placeholder={t('Programs.phaseDistribution')}
                          options={options ? options : []}
                          value={values.phaseDistribution ? values.phaseDistribution : ''}
                          onChange={(e) => selectPhaseDistribution(setFieldValue, e)}
                          hideSelectedOptions={false}
                          removeSelected={false}
                          closeMenuOnSelect={true}
                          getOptionLabel={option => option.phaseDistribution}
                          getOptionValue={option => option.phaseDistributionId}
                          valueKey="phaseDistributionId"
                          backspaceRemovesValue={false}
                          isSearchable={true}
                          allowSelectAll={false}
                          onBlur={() => setFieldTouched('phaseDistribution', true)}
                          noOptionsMessage={() => t('Programs.noPhasesFound')}
                        />
                        {errors.phaseDistribution && touched.phaseDistribution && (
                          <div className="text-danger">{errors.phaseDistribution}</div>
                        )}
                      </FormGroup>
                    </Col>

                      <Col lg="4" sm="12" xs="12">
                        <FormGroup>
                          <Label>{t('Programs.phaseDenomination')}</Label>
                          <MySelect
                            name="denomination"
                            allOption={{
                              phaseDenomitationName: "Select All phaseDistribution",
                              phaseDenominationId: 0
                            }}
                            isMulti={true}
                            placeholder={t('Programs.phaseDenomination')}
                            options={values.denominationOptions}
                            value={values.denomination ? values.denomination : []}
                            onChange={(e) => setFieldValue('denomination', e ? e : '')}
                            getOptionLabel={option => option.phaseDenomitationName}
                            getOptionValue={option => option.phaseDenominationId}
                            valueKey="phaseDenominationId"
                            components={{ Option, ValueContainer }}
                            hideSelectedOptions={false}
                            removeSelected={false}
                            closeMenuOnSelect={false}
                            backspaceRemovesValue={false}
                            isSearchable={true}
                            allowSelectAll={false}
                            onBlur={() => setFieldTouched('denomination', true)}
                            noOptionsMessage={() => t('Programs.noPhasesFound')}
                          />
                          {errors.denomination && touched.denomination && (
                            <div className="text-danger">{errors.denomination}</div>
                          )}
                        </FormGroup>
                      </Col>
                    </>
                    }

                    {(name === EBulkUploadComponentNames.HODS) && <Col sm="6" lg="4">
                      <FormGroup>
                        <Label> {t('Hods.departmentName')}</Label>
                        <MySelect
                          allOption={{
                            departmentName: "Select All",
                            departmentId: ""
                          }}
                          isMulti={true}
                          name="deptName"
                          placeholder={t('Hods.selectDept')}
                          value={values.deptName}
                          onChange={(e) => setFieldValue('deptName', e ? e : '')}
                          options={options}
                          getOptionLabel={option => option.departmentName}
                          getOptionValue={option => option.departmentId}
                          valueKey="departmentId"
                          onBlur={() => setFieldTouched('deptName', true)}
                          noOptionsMessage={() => { t('Hods.NoDataFound') }}
                          components={{ Option, ValueContainer }}
                          hideSelectedOptions={false}
                          removeSelected={false}
                          closeMenuOnSelect={false}
                          backspaceRemovesValue={false}
                          isSearchable={true}
                          allowSelectAll={false}
                        />
                        {errors.deptName && touched.deptName && (
                          <div className="text-danger">{errors.deptName}</div>
                        )}
                      </FormGroup>
                    </Col>}
                  </Row>
                  {(name === EBulkUploadComponentNames.PROGRAMS || (name === EBulkUploadComponentNames.PROGRAMS) || name === EBulkUploadComponentNames.HODS) && <hr/>}

                  <Row className="compHeading">
                    <Col lg="9" sm="7" xs="12">
                      <h2>{t("Programs.fileUpload")}</h2>
                    </Col>
                    {/* <Col lg="3" sm="5" xs="12" className="text-right filehistory">
                      <div onClick={viewBulkUploadHistory} className="pointer">
                        <img src={uploadhistory} alt="" />
                        {t("Programs.fileUploadsHistory")}
                      </div>
                    </Col> */}
                  </Row>

                  <div className="mt-3">
                    <Row>
                      <Col lg="7" sm="10" className="upload-btn d-flex">
                        <Col sm="10">
                          <FormGroup style={{ float: "left" }}>
                            <Label>
                              {t("Programs.browseFile")}
                            </Label>
                            <input
                              type="file"
                              hidden
                              id="actual-btn"
                              onChange={(e) => uploadFileData(e, setFieldValue)}
                            />
                            <div id="blockele">
                              <div className="d-flex flex-row" id="file-chosen">
                                <div className="mr-2 fu-fileName">
                                  <i className="ti-folder"></i>&nbsp;
                                  {values.fileName
                                    ? values.fileName
                                    : t("Programs.selectFile")}
                                </div>
                              </div>
                              <label htmlFor="actual-btn" className="choose">
                                {t("Programs.uploadFile")}
                              </label>
                              <div className="sampledownloadFile mt-1 pointer" onClick={downloadSampleCsvFile}>
                                <img src={download} alt="" />
                                {t("Programs.downloadSampleFile")}
                              </div><br/>
                              {values.invalidFileError === "" &&
                                values.fileData && !values.fileVerification && (
                                  <div className="verify-sec">
                                    <Row>
                                      <Col sm="12" className="text-center mb-1"><span>{t('UsersManagement.verifyupload')}</span> </Col>
                                      <Col className="text-center">
                                      <button
                                    className="btn blue-button verifyBtn"
                                    type="button"
                                    onClick={() => {
                                      setFieldValue('fileVerification', EBulkUploadStatus.PROCESSING);
                                      // setFieldTouched('isFileValidFlag', true);
                                      startFileVerification(
                                        setFieldValue,
                                        values.fileData
                                      )
                                    }
                                    }

                                  >
                                    {t("ActionNames.verify")}
                                  </button>
                                      </Col>
                                    </Row>
                                   
                                  
                                  </div>
                                )}
                              {(values.isFileValidFlag) && <div className="verify-sec"><i className="icon-verified-icon mr-1" style={{  fontSize: '15px', color: 'green' }} />{t('UsersManagement.verifysuccess')}</div>}
                              {(values.fileVerification === EBulkUploadStatus.PROCESSING) && (
                                <>
                                  {/* <button type="button" onClick={cancelFileProcessing}>{t('ActionNames.cancel')}</button> */}
                                  <h3 className="processMsg">{t('UsersManagement.validatingCsvMsg')}</h3>
                                </>
                              )}
                              {values.invalidFileError && (
                                <div className="text-danger verify-sec">
                                  {values.invalidFileError}
                                </div>
                              )}
                              {errors.isFileValidFlag && touched.isFileValidFlag && <div className='text-danger verify-sec'>{errors.isFileValidFlag}</div>}
                            </div>
                          </FormGroup>
                        </Col>
                        
                      </Col>
                    </Row>
                    <div className="sub-form-footer mt-3">
                      <button
                        className="cancel-button"
                        onClick={goBackToList}
                      >
                        {t("ActionNames.cancel")}
                      </button>
                      <button
                        type="submit"
                        className='blue-button'
                      >
                        {t("ActionNames.create")}
                      </button>
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </>
  );
}

export default React.memo(BulkUpload);