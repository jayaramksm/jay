import React from 'react';
import { Pagination, PaginationItem, PaginationLink } from 'reactstrap';
import { useTranslation } from 'react-i18next';
export interface IProps {
    currentPage: number;
    handleClick: any;
    pagesCount: number;
    pageSize: number;
}

export const PaginationComponent: React.FC<IProps> = (props) => {
    const { t } = useTranslation("translations");
    console.log("PaginationComponent==>", props)
    return (
        <>
            <Pagination className="pagination">
                <span className="mr-3" style={{ fontSize: "13px" }}>Pages Count:&nbsp;{props.pagesCount}</span>

                {/* <span className='mr-3'>{t('Utilities.itemsperpage')} {props.pageSize}</span> */}
                {/* <span className='mr-3'>{t('Utilities.noofpages')} {props.pagesCount}</span> */}


                <PaginationItem disabled={props.currentPage <= 0}>
                    <PaginationLink
                        onClick={e => props.handleClick(e, 0)}
                        first
                    />
                </PaginationItem>

                <PaginationItem disabled={props.currentPage <= 0}>
                    <PaginationLink
                        onClick={e => props.handleClick(e, props.currentPage - 1)}
                        previous
                    />
                </PaginationItem>

                <PaginationItem>
                    <PaginationLink disabled={true} >
                        {props.currentPage + 1}
                    </PaginationLink>
                </PaginationItem>




                {/* {[...Array((props.pagesCount))].map((page, i) => {
                    if (i < 4 && props.currentPage < 4) {
                        return <> <PaginationItem active={i === props.currentPage} key={i}>
                            <PaginationLink onClick={e => props.handleClick(e, i)}  >
                                {(i + 1)}
                            </PaginationLink>
                        </PaginationItem> {i === 3 ? '....' : ''} </>
                    }
                    else if (props.currentPage >= 4 && i < 4) {
                        return <><PaginationItem active={i === props.currentPage} key={i}>
                            <PaginationLink onClick={e => props.handleClick(e, i)}  >
                                {((props.currentPage - 2) + i)}
                            </PaginationLink>
                        </PaginationItem> {i === 3 ? '....' : ''}</>
                    }
                    else if (i === (props.pagesCount - 1)) {
                        return <PaginationItem active={i === props.currentPage} key={i}>
                            <PaginationLink onClick={e => props.handleClick(e, i)}  >
                                {(props.pagesCount - 1)}
                            </PaginationLink>
                        </PaginationItem>
                    }
                    return 

                }
                )} */}

                <PaginationItem disabled={props.currentPage >= props.pagesCount - 1}>
                    <PaginationLink
                        onClick={e => props.handleClick(e, props.currentPage + 1)}
                        next
                    />
                </PaginationItem>

                <PaginationItem disabled={props.currentPage >= props.pagesCount - 1}>
                    <PaginationLink
                        onClick={e => props.handleClick(e, 0 + (props?.pagesCount - 1))}
                        last
                    />
                </PaginationItem>

            </Pagination>
        </>
    );
}