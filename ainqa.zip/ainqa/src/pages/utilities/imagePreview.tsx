import React, { useState, useEffect } from 'react';
import { getAndConvertBase64String, imageDownloader } from '../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';

interface IProps {
    path: string;
    fileName?: string;
    allowDownload?: boolean;
}
const ImagePreview: React.FC<IProps> = (props) => {
    const { t } = useTranslation('translations');
    const [base64path, setBase64path] = useState('');
    useEffect(() => {
        if (props.path)
            getAndConvertBase64String(props.path, setBase64path);
    }, [props.path]);

    return (
        <>
         <div className="mcarousel">
            {(base64path || props.path) && <img src={base64path || props.path} alt="Image" className="w-100"/>}
            </div>
            {!!props.allowDownload && <div className="d-flex justify-content-center my-3"><div className="btn download-btn" onClick={() => imageDownloader(props.fileName || 'image', base64path || props.path)}><i className="icon-download"></i>&nbsp;&nbsp;{t('ActionNames.download')}</div></div>}
        </>
    )
};
export default React.memo(ImagePreview);