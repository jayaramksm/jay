import React from 'react';
import { UncontrolledCollapse, Modal, ModalHeader, ModalBody, Button } from 'reactstrap';
import DownToggle from '../../../../images/down_toggle.svg';
import { useTranslation } from 'react-i18next';
import { portfolioAssessmentFormModelOpenOrClose } from '../../../../store/actions';
import { useDispatch, useSelector } from 'react-redux'
import { IPortfolioMOdel } from '../../../../models/portfolioModel';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { FormRendererParent, ViewForm } from "form-configurator";

const PorfolioAssessmentForms: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const formModelData = useSelector((state: any) => {
        if (state?.portfoliosReducer?.actionType) {
            return (state.portfoliosReducer as IPortfolioMOdel)?.formModelData
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const formModelclose = () => {
        const data = { isOpen: false, title: '' }
        dispatch(portfolioAssessmentFormModelOpenOrClose(data));
    };


    let id = formModelData?.formInfo?.portfolioFormMappings?.traineeForm ? JSON.parse(formModelData?.formInfo?.portfolioFormMappings?.traineeForm) : null;
    const evaluatorForm = formModelData?.formInfo?.portfolioFormMappings?.evaluatorForm ? JSON.parse(formModelData?.formInfo?.portfolioFormMappings?.evaluatorForm) : null;
    console.log('PorfolioAssessmentForms==>', { formModelData, evaluatorForm, id })
    return (
        <React.Fragment>
            <Modal className="modal-lg glamodal" isOpen={true} style={{ margin: "0 auto" }}>
                <ModalHeader style={{ position: "sticky", top: 0, zIndex: 3, background: "#ffffff", borderRadius: "0" }}>
                    <div className="text-center">{formModelData?.title}</div>
                    <div className="modal-close"><button className="btn btn-danger" onClick={() => formModelclose()}><i className="ti-close"></i></button></div>
                </ModalHeader>
                <ModalBody className="formbuilder">


                    {formModelData?.actionType !== EOprationalActions.SELECT ? <FormRendererParent
                        onSaveForm={(formData) => {
                            formModelData?.setFieldValue('formdata', formData)
                            formModelData?.setFieldValue('isFormDataDraft', false)
                            const data = { isOpen: false }
                            dispatch(portfolioAssessmentFormModelOpenOrClose(data));
                            console.log('___formData', formData, JSON.stringify(formData));
                        }}
                        id={id?.form_id}
                        answer={formModelData?.actionData?.answer || {}}
                    />
                        :
                        <ViewForm answer={formModelData?.actionData?.answer} formName={formModelData?.actionData?.name} className="viewform" />}
                    <div className="mt-4 viewfbdetails">
                        <a href="#" id="feedback-details" className="feedback-link">{t('Portfolio.feedbackDetails')} <i className="ti-angle-right smallicon"></i> </a>
                        <UncontrolledCollapse toggler="#feedback-details" className="pt-2">
                            <div className="form-expander mb-2">
                                <h6>{t('Portfolio.normal')}</h6> <img src={DownToggle} />
                            </div>
                            {formModelData?.evaluatorFormData ? formModelData?.evaluatorFormData?.map(x => {
                                const evaluatorFormData = x?.evaluatorFormData ? JSON.parse(x?.evaluatorFormData) : '';

                                return <ViewForm answer={evaluatorFormData?.answer} formName={evaluatorFormData?.name} />
                            })
                                : t('Portfolio.noFeedbackDetails')}

                        </UncontrolledCollapse>
                        {/* <div className="text-right mt-3"><button onClick={formModelclose} className="btn back-button">{t('Portfolio.back')}</button></div> */}

                    </div>


                </ModalBody>
            </Modal>
        </React.Fragment>
    )
}

export default React.memo(PorfolioAssessmentForms);