import React, { useContext } from 'react'
import { createOrEditPortfolioDataRequest, portfolioAssessmentFormModelOpenOrClose, portfolioDocumentUploadDataRequest, portfolioFormDataRemoveConfirmationModel, portfolioRemainderToEvaluatorsRequest, setPortfolioActionTypeData } from '../../../../store/actions';
import { EApprovelActions, EOprationalActions, ICurrentDateAndTime } from '../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, defultContentObjectValidate } from '../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import DatePicker from "react-datepicker";
import deleteIcon from '../../../../images/Delete.svg';
import EditIcon from '../../../../images/Edit.svg';
import View from '../../../../images/View.svg';
import { ECodeOptions, EEvaluatorFeedBack, EFieldNames, ESubCode, IPortfilo, IPortfolioForm, IPortfolioMOdel, IRotations } from '../../../../models/portfolioModel';
import { SuperParentContext } from '../Container/portfolioContext'
import groupBy from 'lodash/groupBy';

const codeOptions = [{ value: 'WBA', label: 'WBA -  Workplace Based Assessments' },
{ value: 'SURLOG', label: 'SURLOG-Surgical log book ' }];


const PortfolioAction: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const context: any = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.portfoliosReducer?.actionType) {
            return (state.portfoliosReducer as IPortfolioMOdel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const studyPlanRotation: IRotations[] | undefined = useSelector((state: any) => {
        if (state?.portfoliosReducer?.studyPlanRotationsData) {
            return (state.portfoliosReducer as IPortfolioMOdel).studyPlanRotationsData
        } else {
            return undefined
        }
    });
    const studyPlanRotationsData = studyPlanRotation ? groupBy(studyPlanRotation, 'stageName') : {};
    const portfolioFormData: IPortfolioForm[] | undefined = useSelector((state: any) => {
        if (state?.portfoliosReducer?.portfolioFormData) {
            return (state.portfoliosReducer as IPortfolioMOdel).portfolioFormData
        } else {
            return undefined
        }
    });

    // const portfoliosData: IPortfilo[] = useSelector((state: any) => {
    //     if (state?.portfoliosReducer?.portfoliosData)
    //         return (state.portfoliosReducer as IPortfolioMOdel)?.portfoliosData;
    //     else return [];
    // });
    // const createdOnDate: any = useSelector((state: any) => {
    //     if (state?.portfoliosReducer?.createdOnDate)
    //         return (state.portfoliosReducer as IPortfolioMOdel)?.createdOnDate;
    //     else return [];
    // });
    const currentDate: ICurrentDateAndTime = useSelector((state: any) => {
        if (state?.portfoliosReducer?.currentDate) {
            return (state.portfoliosReducer as any).currentDate
        } else {
            return undefined
        }
    });
    const actionData: IPortfilo = useSelector((state: any) => {
        if (state?.portfoliosReducer?.actionData) {
            return (state.portfoliosReducer as any).actionData
        } else {
            return undefined
        }
    });

    const stageOptions = () => {
        const stageData = Object.keys(studyPlanRotationsData)?.map(x => ({ value: x, label: x }));
        return stageData
    };

    const rotationOptions = (stageValue) => {
        const rotationsOptions = studyPlanRotationsData[stageValue];
        return rotationsOptions || []
    }

    const stageOnchange = (setFieldValue, e, values) => {
        console.log("stageOnchange==>", values)
        if (values.formdata) {
            const confirmMessage = t('Portfolio.confirmMessages.PFOC2');
            dispatch(portfolioFormDataRemoveConfirmationModel(setFieldValue, false, confirmMessage, e, EFieldNames.STAGE, rotationOptions, portfolioFormData, patchSubCodeOptions, subCodeSurlogOptions, getWbsFullName, getWbaNameAndId, values));
        }
        else {
            setFieldValue('stage', e);
            setFieldValue('rotation', '');
            setFieldValue('subCode', '');
            setFieldValue('wbaFullName', '');
            setFieldValue('subCodeOptions', '');
            rotationOptions(e.value)
        }
    };
    const patchSubCodeOptions = (rotation) => {
        const rotationWbas = rotation.wbas?.filter(x => x.wbaName !== ESubCode.PBA);

        let subCodeOptions = portfolioFormData?.filter(x => rotationWbas?.findIndex(y => x.code.toLowerCase() === y?.wbaName) !== -1);
        if (rotation.wbas?.length !== rotationWbas?.length) {
            const pbaOption: any = {
                code: "PBA",
                formName: "PBA",
                portfolioFormId: "0",
                portfolioFormMappings: null
            }
            subCodeOptions?.push(pbaOption)

        }
        return subCodeOptions
    }

    const rotationOnchange = (setFieldValue, e, values) => {
        if (values.formdata) {
            const confirmMessage = t('Portfolio.confirmMessages.PFOC2');
            dispatch(portfolioFormDataRemoveConfirmationModel(setFieldValue, false, confirmMessage, e, EFieldNames.ROTATION, rotationOptions, portfolioFormData, patchSubCodeOptions, subCodeSurlogOptions, getWbsFullName, getWbaNameAndId, values));
        } else {
            setFieldValue('rotation', e);
            setFieldValue('subCode', '');
            setFieldValue('code', '');
            setFieldValue('formdata', '');
            const rotationWbas = e.wbas?.filter(x => x.wbaName !== ESubCode.PBA);

            let subCodeOptions = portfolioFormData?.filter(x => rotationWbas?.findIndex(y => x.code.toLowerCase() === y?.wbaName) !== -1);
            if (e.wbas?.length !== rotationWbas?.length) {
                const pbaOption: any = {
                    code: "PBA",
                    formName: "PBA",
                    portfolioFormId: "0",
                    portfolioFormMappings: null
                }
                subCodeOptions?.push(pbaOption)

            }
            setFieldValue('subCodeOptions', patchSubCodeOptions(e));
            console.log('rotationOnchange==>', { pba: (e.wbas?.length !== rotationWbas?.length), subCodeOptions })
        }
    }
    const uploadDocuments = (file, setFieldValue, values) => {
        if (values.file) {
            dispatch(portfolioDocumentUploadDataRequest(file, setFieldValue, 'files', values.files));
            setFieldValue('spinners', true)
        }
    };



    const initialValues = () => ({
        stage: actionData?.stageName ? stageOptions()?.find(x => actionData?.stageName === x?.value) : '',
        rotation: actionData?.stageName ? rotationOptions(actionData?.stageName)?.find(x => actionData?.rotationId === x?.rotationId) : '',
        code: actionData?.code ? codeOptions?.find(x => actionData?.code === x?.value) : '',
        subCode: actionData?.stageName ? patchSubCodeOptions(rotationOptions(actionData?.stageName)?.find(x => actionData?.rotationId === x?.rotationId))?.find(x => actionData?.wbaName === x.code.toLowerCase()) : '',
        isPartOfAssessed: actionData ? actionData?.isAssessed : true,
        completedDate: actionData?.completedDate ? new Date(actionData?.completedDate) : null,
        dueDate: actionData?.dueDate ? new Date(actionData?.dueDate) : null,
        // rotationsOptions: [],
        files: actionData?.fileData ? actionData?.fileData : [],
        file: "",
        formdata: actionData?.formData ? JSON.parse(actionData?.formData) : '',
        spinners: false,
        subCodeOptions: actionData?.stageName ? patchSubCodeOptions(rotationOptions(actionData?.stageName)?.find(x => actionData?.rotationId === x?.rotationId)) : '',
        portfolioId: actionData?.portfolioId || '',
        wbaFullName: actionData ? (actionData?.code === ECodeOptions.SURLOG ? getWbsFullName(actionData?.code?.toLowerCase()) : getWbsFullName(actionData?.wbaName)) : '',
        isFormDataDraft: false,
        subCategoryName: actionData?.stageName ? patchSubCodeOptions(rotationOptions(actionData?.stageName)?.find(x => actionData?.rotationId === x?.rotationId))?.find(x => actionData?.wbaName === x.code.toLowerCase())?.code?.toLowerCase() === ESubCode.PBA ? portfolioFormData?.filter(x => x.code.toLowerCase() === ESubCode.PBA)?.find(y => y.subCategoryName === actionData?.subCategoryName) : '' : '',
        subCategoryOptions: actionData?.stageName ? patchSubCodeOptions(rotationOptions(actionData?.stageName)?.find(x => actionData?.rotationId === x?.rotationId))?.find(x => actionData?.wbaName === x.code.toLowerCase())?.code?.toLowerCase() === ESubCode.PBA ? portfolioFormData?.filter(x => x.code.toLowerCase() === ESubCode.PBA) : '' : '',
        wbaData: actionData?.stageName ? getWbaNameAndId(rotationOptions(actionData?.stageName)?.find(x => actionData?.rotationId === x?.rotationId)?.wbas, patchSubCodeOptions(rotationOptions(actionData?.stageName)?.find(x => actionData?.rotationId === x?.rotationId))?.find(x => actionData?.wbaName === x.code.toLowerCase())?.code?.toLowerCase()) : '',
        evaluatorFormData: actionData?.evaluatorFeedBack
    });
    const validationSchema = Yup.object().shape({
        stage: defultContentValidate(t('controleErrors.required')),
        dueDate: defultContentValidate(t('controleErrors.required')),
        completedDate: defultContentValidate(t('controleErrors.required')),
        code: defultContentObjectValidate(t('controleErrors.required')),
        rotation: defultContentValidate(t('controleErrors.required')),
        subCode: Yup.object().when('code', {
            is: (code) => (code?.value !== ECodeOptions.SURLOG),
            then: defultContentObjectValidate(t('controleErrors.required')),
            otherwise: defultContentObjectValidate('')
        }),
        formdata: Yup.object().when(['code', 'subCode'], {
            is: (code, subCode) => (subCode),
            // is: (subCategoryName, subCode) => (subCode && subCode?.code?.toLowerCase() === ESubCode.PBA ? subCategoryName?.portfolioFormMappings : subCode?.portfolioFormMappings),
            then: defultContentObjectValidate(t('controleErrors.required')),
            otherwise: defultContentObjectValidate('')
        }),
        subCategoryName: Yup.object().when('subCode', {
            is: (subCode) => (subCode?.code?.toLowerCase() === ESubCode.PBA),
            then: defultContentObjectValidate(t('controleErrors.required')),
            otherwise: defultContentObjectValidate('')
        })

    });

    const cancel = () => {
        dispatch(setPortfolioActionTypeData(EOprationalActions.UNSELECT, null));
    };
    const saveAsDraft = (values) => {
        dispatch(createOrEditPortfolioDataRequest(values, EOprationalActions.DRAFT));
    };

    const deletFile = (files, setFieldValue, index) => {
        files.splice(index, 1);
        setFieldValue("files", files);
    }

    const handlecompletedDate = (completedDate: any, setFieldValue: any) => setFieldValue("completedDate", completedDate);
    const handledueDate = (dueDate: any, setFieldValue: any) => setFieldValue("dueDate", dueDate);

    const formModelOpen = (setFieldValue, values, type) => {
        const formInfo = values?.subCode?.code?.toLowerCase() === ESubCode.PBA ? values?.subCategoryName : values.subCode
        const data = { isOpen: true, title: values.wbaFullName, formInfo: formInfo, setFieldValue: setFieldValue, actionData: values.formdata, actionType: type, evaluatorFormData: values.evaluatorFormData }
        dispatch(portfolioAssessmentFormModelOpenOrClose(data));
    };
    const getWbsFullName = (value) => {
        let wbaFullName: string = '';
        switch (value) {
            case ESubCode.CBD:
                wbaFullName = t('Portfolio.cbd');

                break;
            case ESubCode.DOPS:

                wbaFullName = t('Portfolio.dops');
                break;
            case ESubCode.CEX:
                wbaFullName = t('Portfolio.cex');
                break;
            case ESubCode.DOCE:
                wbaFullName = t('Portfolio.doce');
                break;
            case ESubCode.MSF:
                wbaFullName = t('Portfolio.msf');
                break;
            case ESubCode.PBA:
                wbaFullName = t('Portfolio.pba');
                break;
            case ESubCode.PSA:
                wbaFullName = t('Portfolio.psa');
                break;
            case ESubCode.NOTSA:
                wbaFullName = t('Portfolio.notsa');
                break;
            case ESubCode.SURLOG:
                wbaFullName = t('Portfolio.surlog');
                break;

        }
        return wbaFullName
    }
    const remainderSend = (values) => {
        console.log("remainderSend==>", values)
        dispatch(portfolioRemainderToEvaluatorsRequest(values));
    }

    const getWbaNameAndId = (wbas, code) => {
        const wbadata = wbas?.find(x => x.wbaName === code);
        return wbadata
    }
    const evaluatorFeedBack = actionData?.evaluatorFeedBack ? actionData?.evaluatorFeedBack?.every(x => x?.status === EEvaluatorFeedBack.APPROVED) : false;
    const approvelStatus = ((actionData?.firstRotationSupervisor?.status === EApprovelActions.PENDING && (actionData?.secondRotationSupervisor?.status ? actionData?.secondRotationSupervisor?.status === EApprovelActions.PENDING : true)));

    const subCodeSurlogOptions: any = portfolioFormData?.filter(x => x.code === ECodeOptions.SURLOG);

    console.log("PortfolioAction==>", { portfolioFormData, actionData, actionType, studyPlanRotationsData, approvelStatus, check: actionType !== EOprationalActions.ADD ? approvelStatus : true });

    return (

        <>
            {/* <Breadcrumb>
                <BreadcrumbItem><span onClick={cancel}> {t('Portfolio.listofEntries')}</span></BreadcrumbItem>
                <BreadcrumbItem className="subMenu-Active"> {t('Portfolio.addEntry')}</BreadcrumbItem>
            </Breadcrumb> */}
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="maincontent pr-3">
                        <div className="breadcrumbs">
                            <span className="pointer" onClick={cancel}> {t('Portfolio.listofEntries')}</span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="active">
                                {t('Portfolio.addEntry')}
                            </span>
                        </div>
                        <Formik
                            enableReinitialize
                            initialValues={initialValues()}
                            validationSchema={validationSchema}
                            onSubmit={(values) => {
                                if (!values?.isFormDataDraft)
                                    dispatch(createOrEditPortfolioDataRequest(values, actionType));

                                console.log("SubmitedValues==>", actionType, actionData, values);
                            }}>
                            {({ errors, setFieldValue, setFieldTouched, values, touched, dirty }) => (
                                <Form>
                                    <div className="top-section">
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.stage')}</Label>
                                                        <MySelect
                                                            name="stage"
                                                            placeholder={t('Portfolio.stage')}
                                                            isDisabled={(actionType === EOprationalActions.SELECT)}
                                                            value={values.stage}
                                                            onChange={(e) => stageOnchange(setFieldValue, e, values)}
                                                            options={stageOptions() ? stageOptions() : []}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            // valueKey='userId'
                                                            onBlur={() => setFieldTouched('stage', true)}
                                                            noOptionsMessage={() => { t('Portfolio.noDataFound') }}
                                                        />
                                                        {errors.stage && touched.stage && (
                                                            <div className="text-danger">{errors.stage}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.rotation')}</Label>
                                                        <MySelect
                                                            placeholder={t('Portfolio.rotation')}
                                                            name="rotation"
                                                            isDisabled={(actionType === EOprationalActions.SELECT)}
                                                            value={values.rotation}
                                                            onChange={(e) => rotationOnchange(setFieldValue, e, values)}
                                                            options={rotationOptions((values?.stage as any)?.value)}
                                                            getOptionLabel={option => option.rotationName}
                                                            getOptionValue={option => option.rotationId}
                                                            valueKey='rotationId'
                                                            onBlur={() => setFieldTouched('rotation', true)}
                                                            noOptionsMessage={() => { t('Portfolio.noDataFound') }}
                                                        />
                                                        {errors.rotation && touched.rotation && (
                                                            <div className="text-danger">{errors.rotation}</div>
                                                        )}

                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.hospital')}</Label>
                                                        <Input type="text" value={values.rotation ? ((values.rotation as any)?.hospitalName ? (values.rotation as any)?.hospitalName : `Other - ${(values.rotation as any)?.otherHospitalName}`) : ''} name="hospital" disabled id="hospital"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.code')}</Label>
                                                        <MySelect
                                                            placeholder={t('Portfolio.code')}
                                                            name="code"
                                                            isDisabled={(actionType === EOprationalActions.SELECT)} value={values.code}
                                                            onChange={(e) => {
                                                                if (values.formdata) {
                                                                    const confirmMessage = t('Portfolio.confirmMessages.PFOC2');
                                                                    dispatch(portfolioFormDataRemoveConfirmationModel(setFieldValue, false, confirmMessage, e, EFieldNames.CODE, rotationOptions, portfolioFormData, patchSubCodeOptions, subCodeSurlogOptions, getWbsFullName, getWbaNameAndId, values));
                                                                } else {
                                                                    setFieldValue('code', e ? e : '');
                                                                    setFieldValue('subCode', '');
                                                                    setFieldValue('wbaFullName', '');
                                                                    setFieldValue('formdata', '');
                                                                    if (e.value === ECodeOptions.SURLOG) {
                                                                        if (subCodeSurlogOptions?.length > 1)
                                                                            setFieldValue('subCodeOptions', subCodeSurlogOptions);
                                                                        else {
                                                                            setFieldValue('subCode', subCodeSurlogOptions[0]);
                                                                            setFieldValue('wbaFullName', getWbsFullName(subCodeSurlogOptions[0]?.code.toLowerCase()));
                                                                            // setFieldValue('subCodeOptions', '');
                                                                        }
                                                                        setFieldValue('isPartOfAssessed', false);
                                                                    }
                                                                    else setFieldValue('isPartOfAssessed', true)
                                                                }
                                                            }}
                                                            options={codeOptions}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            // valueKey='userId'
                                                            onBlur={() => setFieldTouched('code', true)}
                                                            noOptionsMessage={() => { t('Portfolio.noDataFound') }}
                                                        />
                                                        {errors.code && touched.code && (
                                                            <div className="text-danger">{errors.code}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                                {values.code && values.subCodeOptions && ((values.code as any)?.value === ECodeOptions.SURLOG ? (subCodeSurlogOptions?.length > 1) : true) && <>
                                                    <Col lg="4" sm="6" xs="12">
                                                        <FormGroup>
                                                            <Label>  {t('Portfolio.subCode')}</Label>
                                                            <MySelect
                                                                placeholder={t('Portfolio.subCode')}
                                                                name="subCode"
                                                                isDisabled={(actionType === EOprationalActions.SELECT)} value={values.subCode}
                                                                onChange={(e) => {
                                                                    if (values.formdata) {
                                                                        const confirmMessage = t('Portfolio.confirmMessages.PFOC2');
                                                                        dispatch(portfolioFormDataRemoveConfirmationModel(setFieldValue, false, confirmMessage, e, EFieldNames.SUBCODE, rotationOptions, portfolioFormData, patchSubCodeOptions, subCodeSurlogOptions, getWbsFullName, getWbaNameAndId, values));
                                                                    } else {
                                                                        setFieldValue('subCode', e ? e : '');
                                                                        setFieldValue('formdata', '');
                                                                        setFieldValue('subCategoryName', '');
                                                                        setFieldValue('wbaData', getWbaNameAndId(values?.rotation?.wbas, e.code.toLowerCase()))
                                                                        if (e.code?.toLowerCase() === ESubCode.PBA) {
                                                                            const subCategoryOptions = portfolioFormData?.filter(x => x.code.toLowerCase() === ESubCode.PBA);
                                                                            setFieldValue('subCategoryOptions', subCategoryOptions);
                                                                        } else setFieldValue('wbaFullName', getWbsFullName(e.code.toLowerCase()));
                                                                    }
                                                                }}
                                                                options={values.subCodeOptions ? values.subCodeOptions : []}
                                                                getOptionLabel={option => option.formName}
                                                                getOptionValue={option => option.portfolioFormId}
                                                                valueKey='portfolioFormId'
                                                                onBlur={() => setFieldTouched('subCode', true)}
                                                                noOptionsMessage={() => { t('Portfolio.noDataFound') }}
                                                            />
                                                            {errors.subCode && touched.subCode && (
                                                                <div className="text-danger">{errors.subCode}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>

                                                    {values.subCode && (values.subCode as any)?.formName?.toLowerCase() === ESubCode.PBA && <Col lg="4" sm="6" xs="12">
                                                        <FormGroup>
                                                            <Label>  {t('Portfolio.subCategoryName')}</Label>
                                                            <MySelect
                                                                placeholder={t('Portfolio.subCategoryName')}
                                                                name="subCategoryName"
                                                                isDisabled={(actionType === EOprationalActions.SELECT)}
                                                                value={values.subCategoryName}
                                                                onChange={(e) => {
                                                                    if (values.formdata) {
                                                                        const confirmMessage = t('Portfolio.confirmMessages.PFOC2');
                                                                        dispatch(portfolioFormDataRemoveConfirmationModel(setFieldValue, false, confirmMessage, e, EFieldNames.SUBCATEGOTYNAME, rotationOptions, portfolioFormData, patchSubCodeOptions, subCodeSurlogOptions, getWbsFullName, getWbaNameAndId, values));
                                                                    } else {
                                                                        setFieldValue('subCategoryName', e ? e : '');
                                                                        setFieldValue('formdata', '');
                                                                        setFieldValue('wbaFullName', getWbsFullName(e.code.toLowerCase()));
                                                                    }
                                                                }}
                                                                options={values.subCategoryOptions}
                                                                getOptionLabel={option => option.subCategoryName}
                                                                getOptionValue={option => option.portfolioFormId}
                                                                valueKey='portfolioFormId'
                                                                onBlur={() => setFieldTouched('subCategoryName', true)}
                                                                noOptionsMessage={() => { t('Portfolio.noDataFound') }}
                                                            />
                                                            {errors.subCategoryName && touched.subCategoryName && (
                                                                <div className="text-danger">{errors.subCategoryName}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>}


                                                    {(values.isPartOfAssessed) && <>
                                                        <Col lg="4" sm="6" xs="12">
                                                            <FormGroup>
                                                                <Label>{t('Portfolio.1stRotationalSupervisor')}</Label>
                                                                <Input type="text" value={(values.rotation as any)?.firstRotationSupervisor?.supervisorName || ''} name="rsupervisorone" disabled></Input>
                                                            </FormGroup>
                                                        </Col>

                                                        <Col lg="4" sm="6" xs="12">
                                                            <FormGroup>
                                                                <Label>{t('Portfolio.2ndRotationalSupervisor')}</Label>
                                                                <Input type="text" value={(values.rotation as any)?.secondRotationSupervisor?.supervisorName || ''} name="rsupervisortwo" disabled></Input>
                                                            </FormGroup>
                                                        </Col>
                                                    </>
                                                    }
                                                </>}
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.dueDate')}</Label>

                                                        <DatePicker
                                                            placeholderText={t('Portfolio.dueDate')}
                                                            className="w100 datepickerIcon form-control"
                                                            name="dueDate"
                                                            popperPlacement="bottom"
                                                            autoComplete="off"
                                                            popperModifiers={{
                                                                flip: {
                                                                    behavior: ["top"],
                                                                },
                                                                preventOverflow: {
                                                                    enabled: false,
                                                                },
                                                            }}
                                                            disabled={(actionType === EOprationalActions.SELECT)}
                                                            selected={values.dueDate}
                                                            onChange={(e) => handledueDate(e, setFieldValue)}
                                                            dateFormat={"dd-MM-yyyy"}
                                                            // minDate={values.startDate}
                                                            onBlur={() => setFieldTouched("dueDate", true)}
                                                            showMonthDropdown
                                                            showYearDropdown
                                                            dropdownMode="select"
                                                        />
                                                        {errors.dueDate && touched.dueDate && (
                                                            <div className="text-danger">{errors.dueDate}</div>
                                                        )}

                                                    </FormGroup>
                                                </Col>

                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.completedDate')}</Label>
                                                        <DatePicker
                                                            placeholderText={t('Portfolio.completedDate')}
                                                            className="w100 datepickerIcon form-control"
                                                            name="completedDate"
                                                            popperPlacement="bottom"
                                                            autoComplete="off"
                                                            popperModifiers={{
                                                                flip: {
                                                                    behavior: ["top"],
                                                                },
                                                                preventOverflow: {
                                                                    enabled: false,
                                                                },
                                                            }}
                                                            selected={values.completedDate}
                                                            onChange={(e) => handlecompletedDate(e, setFieldValue)}
                                                            dateFormat={"dd-MM-yyyy"}
                                                            showMonthDropdown
                                                            showYearDropdown
                                                            dropdownMode="select"
                                                            maxDate={new Date(currentDate?.date)}
                                                            disabled={(actionType === EOprationalActions.SELECT)} onBlur={() => setFieldTouched("completedDate", true)}
                                                        />
                                                        {errors.completedDate && touched.completedDate && (
                                                            <div className="text-danger">{errors.completedDate}</div>)}
                                                    </FormGroup>
                                                </Col>
                                                {values.code && (values.code as any)?.value !== ECodeOptions.SURLOG && <Col sm="12" xs="12">
                                                    <FormGroup check className="assessed pl-0">
                                                        <Label check>
                                                            <Field disabled={(actionType === EOprationalActions.SELECT)} type='checkbox' name='isPartOfAssessed' />{' '}
                                                            {t('Portfolio.thiswillbepartofAssessed')}
                                                        </Label>
                                                    </FormGroup>
                                                </Col>}
                                            </Row>
                                        </div>
                                    </div>
                                    <hr />

                                    {!values.formdata && values.code && <> <div className="top-section">
                                        {(actionType !== EOprationalActions.SELECT) &&
                                            <div className="details-section mt-3">
                                                <h2> {t('Portfolio.workplacebasedAssessmentDetails')}</h2>
                                                {(values?.subCode && (((values.subCode as any)?.portfolioFormMappings && (values.subCode as any)?.code?.toLowerCase() !== ESubCode.PBA) || ((values.subCategoryName && (values.subCategoryName as any)?.portfolioFormMappings)))) ? <div className="add-button mt-3" onClick={() => formModelOpen(setFieldValue, values, EOprationalActions.ADD)}>
                                                    <div className="button-text"> {values?.wbaFullName}  </div>
                                                    <div className="note">*  {t('Portfolio.pleasefilltheformdetails')}</div>
                                                </div> : <div className='text-danger'> {t('Portfolio.noFormsAvailable')}</div>}
                                            </div>}
                                    </div>
                                        {errors.formdata && (
                                            <div className="text-danger ml-3">{errors.formdata}</div>
                                        )}
                                        <hr />
                                    </>}

                                    {(values?.code as any)?.value === ECodeOptions.WBA &&
                                        <>
                                            <div className="top-section">
                                                <h2>  {t('Portfolio.artifactUploads')}</h2>
                                                <div className="details-section mt-3">
                                                    {(actionType !== EOprationalActions.SELECT) && <Row>
                                                        <div className="upload-btn py-0" style={{ height: "50px" }}>
                                                            <FormGroup>
                                                                <input type="file" id="actual-btn" hidden onChange={(e) => setFieldValue("file", e.target.files)} />
                                                                <div id="blockele">
                                                                    <div className="d-flex flex-row" id="file-chosen"><div className="mr-2 d-flex align-items-center"><i className="ti-folder mr-2"></i> {values?.file ? <span className="filename">{(values.file as any)?.[0]?.name}</span> : t('Portfolio.selectFile')} </div></div>
                                                                    <label htmlFor="actual-btn" className="choose"> {t('Portfolio.uploadFile')}</label>
                                                                </div>
                                                                {/* <div className="fileuplod-note">* jpg, jpeg, png File only</div> */}
                                                            </FormGroup>
                                                        </div>
                                                        <Col className="NewDelBtn ml-3"><span onClick={() => uploadDocuments(values.file, setFieldValue, values)}>{values?.spinners ? <div className="spinner-border"></div> : <> <i className="ti-plus"></i> {t('Portfolio.addFile')}</>}  </span></Col>
                                                    </Row>
                                                    }
                                                    {values.files?.map((x: any, i) => (
                                                        <Row key={i}>
                                                            <div className="ArtifactName">
                                                                <span>{x?.fileName}</span>
                                                            </div>
                                                            {(actionType !== EOprationalActions.SELECT) && <Col className="NewDelBtn text-danger"><span onClick={() => deletFile(values?.files, setFieldValue, i)}><i className="ti-trash"></i>  {t('Portfolio.delete')}</span></Col>}
                                                        </Row>
                                                    ))}

                                                </div>
                                            </div>
                                            <hr />
                                        </>}

                                    {values.formdata && <div className="tbl-parent table-responsive">
                                        <table className="w100 myTable cbdform-table table">
                                            <thead>
                                                <tr>
                                                    <th> {t('Portfolio.workplacebasedAssessmentName')} </th>
                                                    <th className="column-center"> {t('Portfolio.actions')} </th>
                                                    {actionType !== EOprationalActions.ADD && approvelStatus &&
                                                        <th></th>
                                                    }
                                                    {/* <th>&nbsp;</th> */}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>{values?.wbaFullName}  </td>
                                                    <td className="column-center">
                                                        <img src={View} onClick={() => formModelOpen(setFieldValue, values, EOprationalActions.SELECT)} className="actionicon pointer" alt=""></img>
                                                        {actionType !== EOprationalActions.SELECT && <img src={EditIcon} onClick={() => formModelOpen(setFieldValue, values, EOprationalActions.EDIT)} className="actionicon pointer" alt=""></img>}
                                                        {actionType !== EOprationalActions.SELECT && <img src={deleteIcon} onClick={() => setFieldValue('formdata', '')} className="actionicon pointer" alt=""></img>}
                                                    </td>
                                                    {actionType !== EOprationalActions.ADD && approvelStatus && <td>
                                                        {/* <button type="button" disabled={(evaluatorFeedBack)} onClick={() => remainderSend(values)} className="btn reminder-button"> {t('Portfolio.reminder')}</button> */}
                                                        <span><context.portfolioTimer remainderMethod={() => remainderSend(values)} portfolioId={actionData?.portfolioId} /></span>
                                                    </td>}
                                                </tr>
                                            </tbody>
                                        </table>
                                        {/* {values?.isFormDataDraft && <div className='text-danger'>{t('Portfolio.formDataisDraft')}</div>} */}
                                    </div>
                                    }

                                    {(actionType === EOprationalActions.SELECT && values.isPartOfAssessed) && <div className="top-section">
                                        <Row className="mr-3 align-items-center">
                                            <Col sm="6" xs="12">
                                                <h2 className="mt-0"> {t('Portfolio.approvalDetails')}</h2>
                                            </Col>
                                        </Row>
                                        <div className="details-section mt-3">
                                            <Row>
                                                <Col sm="6" xs="12">
                                                    <h2 className="mt-0"> {t('Portfolio.1stRotationalSupervisor')}</h2>
                                                </Col>
                                                <Col sm="6" xs="12" className="text-right">
                                                    <span className="approvedDate"> {actionData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? t('Portfolio.rejectOn') : t('Portfolio.approvedon')} <span className="date">
                                                        {actionData?.firstRotationSupervisor?.approvedOn || '-'}
                                                    </span></span>
                                                </Col>
                                            </Row>
                                            <Row className="mt-3">

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.approvalStatus')}</Label>
                                                        <Input type="text" value={actionData?.firstRotationSupervisor?.status || ''} disabled></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label> {t('Portfolio.approverName')}</Label>
                                                        <Input type="text" value={actionData?.firstRotationSupervisor?.supervisorName || ''} disabled></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Portfolio.comments')}</Label>
                                                        <textarea value={actionData?.firstRotationSupervisor?.comments || ''} disabled className="comments" rows={1}></textarea>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            {actionData?.secondRotationSupervisor?.supervisorName && <>
                                                <Row>
                                                    <Col sm="6" xs="12">
                                                        <h2 className="mt-0"> {t('Portfolio.2ndRotationalSupervisor')}</h2>
                                                    </Col>
                                                    <Col sm="6" xs="12" className="text-right">
                                                        <span className="approvedDate"> {actionData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? t('Portfolio.rejectOn') : t('Portfolio.approvedon')} <span className="date">
                                                            {actionData?.secondRotationSupervisor?.approvedOn || '-'}
                                                        </span></span>
                                                    </Col>
                                                </Row>
                                                <Row className="mt-3">

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('Portfolio.approvalStatus')}</Label>
                                                            <Input type="text" value={actionData?.secondRotationSupervisor?.status || ''} disabled></Input>
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('Portfolio.approverName')}</Label>
                                                            <Input type="text" value={actionData?.secondRotationSupervisor?.supervisorName || ''} disabled></Input>
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label> {t('Portfolio.comments')}</Label>
                                                            <textarea value={actionData?.secondRotationSupervisor?.comments || ''} disabled className="comments" rows={1}></textarea>
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </>}
                                        </div>
                                    </div>
                                    }
                                    <Row className="sub-form-footer mt-3 mr-3">
                                        {(actionType !== EOprationalActions.SELECT) && <>    <button type="button" disabled={!dirty} onClick={() => saveAsDraft(values)} className="btn feedback-button-main"> {t('Portfolio.saveasDraft')}</button>&nbsp;
                                            <button type="submit" disabled={actionType === EOprationalActions.EDIT ? !dirty : false} className="blue-button">{actionType === EOprationalActions.ADD ? t('ActionNames.create') : t('ActionNames.update')}</button>
                                        </>}
                                        <button type="button" onClick={cancel} className="cancel-button"> {t('ActionNames.cancel')}</button>&nbsp;
                                    </Row>

                                </Form>
                            )
                            }
                        </Formik>
                    </div>
                </div>
            </div>
        </>

    )
}

export default React.memo(PortfolioAction)