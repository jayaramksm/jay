import React from 'react';
import { Row, Col } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { setPortfolioActionTypeData, setSearchPortfolioData } from '../../../../store/actions';
import { EOprationalActions } from '../../../../models/utilitiesModel';

const PortfolioFilter: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const portfoliosData: any[] | any = useSelector((state: any) => {
        if (state?.portfoliosReducer?.portfoliosData)
            return (state.portfoliosReducer as any)?.portfoliosData;
        else return undefined;
    });
    const actionType = useSelector((state: any) => {
        if (state?.portfoliosReducer?.actionType) {
            return (state.portfoliosReducer as any).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const addPortfolio = () => {
        dispatch(setPortfolioActionTypeData(EOprationalActions.ADD, null));

    };

    const setSearchKey = e => {
        dispatch(setSearchPortfolioData(e.target.value));
    };
    const submittedPortfolios = () => {
        dispatch(setPortfolioActionTypeData(EOprationalActions.UNSELECT, null));

    };
    const draftsPortfolios = () => {
        dispatch(setPortfolioActionTypeData(EOprationalActions.DRAFT, null));

    };
    return (
        <>
            <Row className="compHeading">
                <Col className="draftsheading">
                    <h3 className="page-header header-title">{t('Portfolio.listofEntries')}</h3>
                    <div className="entry-actions"><span onClick={submittedPortfolios} className={actionType === EOprationalActions.UNSELECT ? "action-active pointer" : 'pointer'}> {t('Portfolio.submitted')}</span>  &nbsp;| &nbsp; <span className={actionType === EOprationalActions.DRAFT ? "action-active pointer" : 'pointer'} onClick={draftsPortfolios}>{t('Portfolio.drafts')} </span></div>
                </Col>
                <div className="rgtFilter">
                    {portfoliosData?.length > 2 && <div className="search-box filtericon">
                        <div className="search-text"><input type="text" onChange={setSearchKey} placeholder="Search"></input><i className="ti-search icon"></i></div>
                    </div>}
                    <button className="addnewButn" onClick={addPortfolio}><i className="ti-plus"></i>  {t('Portfolio.addNewEntry')}</button>
                </div>
            </Row>
        </>
    )
}

export default React.memo(PortfolioFilter)
