import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/portfolioContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { IPortfilo, IPortfolioMOdel } from '../../../../models/portfolioModel';
import { setpoarfolioPaginationCurrentPageValue } from '../../../../store/actions';

const PortfoliosViewManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const dispatch = useDispatch();

    const { t } = useTranslation('translations');

    const portfoliosData: IPortfilo[] | undefined = useSelector((state: any) => {
        if (state?.portfoliosReducer?.portfoliosData)
            return (state.portfoliosReducer as IPortfolioMOdel)?.portfoliosData;
        else return undefined;
    });

    const currentPage: number = useSelector((state: any) => {
        if (state?.portfoliosReducer?.paginationCurrentPage)
            return (state.portfoliosReducer as IPortfolioMOdel).paginationCurrentPage;
        else return 0;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.portfoliosReducer?.searchKey)
            return state.portfoliosReducer.searchKey;
        else return ''
    });

    const portfoliosFilterData: IPortfilo[] | undefined = (portfoliosData?.length && searchKey !== '') ? portfoliosData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName?.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : portfoliosData;

    let pagesCount: number = Math.ceil((portfoliosFilterData ? portfoliosFilterData.length : 0) / 15);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setpoarfolioPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setpoarfolioPaginationCurrentPageValue(index));
    };

    console.log("gPortfoliosViewManager==>", 15, portfoliosData, context, portfoliosFilterData);

    return (
        <div className="tbl-parent table-responsive">
            <table className="w100 myTable portfolioTable table">
                <thead>
                    <tr>
                        <th> {t('Portfolio.stage')}</th>
                        <th>  {t('Portfolio.rotations')}</th>
                        <th>  {t('Portfolio.code')}</th>
                        <th>  {t('Portfolio.subCode')}</th>
                        {/* <th> {t('Portfolio.ELAEPA')}</th> */}
                        <th>  {t('Portfolio.AssessedNon-Assessed')}</th>
                        <th>  {t('Portfolio.1stRotationalSupervisor')}</th>
                        <th>  {t('Portfolio.1stSupervisorApprovalStatus')}</th>
                        <th>  {t('Portfolio.2ndRotationalSupervisor')}</th>
                        <th>  {t('Portfolio.2ndSupervisorApprovalStatus')}</th>
                        <th>  {t('Portfolio.finalApprovalDate')}</th>
                        <th>  {t('Portfolio.actions')}</th>
                    </tr>
                </thead>
                <tbody>
                    {portfoliosFilterData && portfoliosFilterData.slice((currentPage * 15), ((currentPage + 1) * 15)).map((x) => (
                        <ParentContext.Provider value={x.portfolioId} key={x.portfolioId}>
                            <context.portfoliosViewView />
                        </ParentContext.Provider>
                    ))}
                </tbody>
            </table>
            {(portfoliosFilterData && portfoliosFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('Portfolio.noDataFound')}</h6></div>}
            {portfoliosFilterData && portfoliosFilterData.length > 15 &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={15} handleClick={handleClick} />
                </div>}
        </div>
    )
}
export default React.memo(PortfoliosViewManager);