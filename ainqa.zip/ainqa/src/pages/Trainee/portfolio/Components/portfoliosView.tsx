import React, { useContext } from 'react';
import { ParentContext } from '../Container/portfolioContext';
import EditIcon from '../../../../images/Edit.svg';
import { EApprovelActions, EOprationalActions } from '../../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import Approved from '../../../../images/Approved.svg';
import Pending from '../../../../images/Pending.svg';
import reject from '../../../../images/Reject.svg';
import View from '../../../../images/View.svg';
import { setPortfolioActionTypeData, getCurrentDateAndTimeRequest } from '../../../../store/actions';
import { IPortfilo, IPortfolioMOdel, IRotations } from '../../../../models/portfolioModel';
import { useTranslation } from 'react-i18next';


const PortfoliosView: React.FC = () => {
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);
    const { t } = useTranslation('translations');

    const portfoliosData: IPortfilo | undefined = useSelector((state: any) => {
        if (state?.portfoliosReducer?.portfoliosData?.length) {
            let portfolioData = (state.portfoliosReducer as IPortfolioMOdel).portfoliosData;
            return portfolioData.find(x => x.portfolioId === context);
        } else
            return undefined;
    });
    const studyPlanRotation: IRotations[] | undefined = useSelector((state: any) => {
        if (state?.portfoliosReducer?.studyPlanRotationsData) {
            return (state.portfoliosReducer as IPortfolioMOdel).studyPlanRotationsData
        } else {
            return undefined
        }
    });

    const editPortfolio = () => {
        dispatch(setPortfolioActionTypeData(EOprationalActions.EDIT, portfoliosData));
        // dispatch(setPortfolioActionTypeData(portfoliosData?.portfolioId, true));
    };
    const ViewPortfolio = () => {
        dispatch(setPortfolioActionTypeData(EOprationalActions.SELECT, portfoliosData));
        const approvelStatus = ((portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.PENDING && (portfoliosData?.secondRotationSupervisor?.status ? portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.PENDING : true)));
        if (approvelStatus)
            dispatch(getCurrentDateAndTimeRequest());
    };

    const showEdit = ((portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED || portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED));
    const rotationIsActive = studyPlanRotation?.some(x => x.rotationName === portfoliosData?.rotationName)
    console.log("PortfoliosView==>", portfoliosData);

    return (
        <>
            <tr>
                <td>{portfoliosData?.stageName}</td>
                <td>{portfoliosData?.rotationName}</td>
                <td> {portfoliosData?.code}</td>
                <td> {portfoliosData?.wbaName}</td>
                {/* <td>{portfoliosData ? '-' : '-'}</td> */}
                <td> {portfoliosData?.isAssessed ? t('Portfolio.assessed') : t('Portfolio.nonAssessed')}</td>
                <td> {portfoliosData?.isAssessed ? portfoliosData?.firstRotationSupervisor?.supervisorName : '-'}</td>
                <td className="column-center">{portfoliosData?.isAssessed ? portfoliosData?.firstRotationSupervisor?.status ? (portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-' : '-'}</td>
                <td> {portfoliosData?.isAssessed ? (portfoliosData?.secondRotationSupervisor?.supervisorName || '-') : '-'}</td>
                <td className="column-center">{portfoliosData?.isAssessed ? portfoliosData?.secondRotationSupervisor?.status ? (portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-' : '-'}</td>
                <td>{portfoliosData?.isAssessed ? (portfoliosData?.secondRotationSupervisor?.approvedOn && portfoliosData?.firstRotationSupervisor?.approvedOn) ? ((portfoliosData?.secondRotationSupervisor?.approvedOn > portfoliosData?.firstRotationSupervisor?.approvedOn) ? portfoliosData?.secondRotationSupervisor?.approvedOn : portfoliosData?.firstRotationSupervisor?.approvedOn) : (portfoliosData?.secondRotationSupervisor?.approvedOn || portfoliosData?.firstRotationSupervisor?.approvedOn || '-') : '-'}</td>
                {rotationIsActive ? <td>
                    <img src={View} onClick={ViewPortfolio} className="actionicon pointer" alt=""></img>
                    {showEdit &&
                        <img src={EditIcon} onClick={editPortfolio} className="actionicon pointer" alt="Edit" />}
                </td> : <td className="column-center"> - </td>
                    // </td> : <td className="column-center"> this rotation status pending</td>
                }
            </tr>

        </>

    )
}
export default React.memo(PortfoliosView);