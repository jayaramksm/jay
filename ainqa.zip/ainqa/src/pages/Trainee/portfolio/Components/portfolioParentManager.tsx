import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/portfolioContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IPortfolioMOdel } from '../../../../models/portfolioModel';


const PortfolioParentManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.portfoliosReducer?.actionType) {
            return (state.portfoliosReducer as IPortfolioMOdel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });
    const formModelData = useSelector((state: any) => {
        if (state?.portfoliosReducer?.actionType) {
            return (state.portfoliosReducer as IPortfolioMOdel)?.formModelData
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    return (
        <>
            {(actionType === EOprationalActions.UNSELECT || actionType === EOprationalActions.DRAFT) && <context.portfolioFilter />}
                <div className="flexLayout pr-0">
                    {actionType === EOprationalActions.UNSELECT && <context.portfoliosViewManager />}
                    {actionType === EOprationalActions.DRAFT && <context.portfolioDraftViewManager />}
                    {(actionType === EOprationalActions.ADD || actionType === EOprationalActions.EDIT || actionType === EOprationalActions.SELECT) && <context.portfolioAction />}
                    {formModelData?.isOpen && <context.porfolioAssessmentForms />}
                </div>
        </>
    )
}
export default React.memo(PortfolioParentManager);