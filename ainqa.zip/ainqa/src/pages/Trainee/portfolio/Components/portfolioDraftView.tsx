import React, { useContext } from 'react';
import { ParentContext } from '../Container/portfolioContext';
import EditIcon from '../../../../images/Edit.svg';
import deleteIcon from '../../../../images/Delete.svg';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import { deletePortfolioDrastDataRequest, setPortfolioActionTypeData } from '../../../../store/actions';
import { IPortfilo, IPortfolioMOdel, IRotations } from '../../../../models/portfolioModel';
import { useTranslation } from 'react-i18next';


const PortfolioDraftView: React.FC = () => {
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);
    const { t } = useTranslation('translations');


    const portfolioDraftData: IPortfilo | undefined = useSelector((state: any) => {
        if (state?.portfoliosReducer?.portfolioDraftData?.length) {
            let portfolioDraftsData = (state.portfoliosReducer as IPortfolioMOdel).portfolioDraftData;
            return portfolioDraftsData?.find(x => x.portfolioId === context);
        } else
            return undefined;
    });
    const editPortfolioDraft = () => {
        dispatch(setPortfolioActionTypeData(EOprationalActions.ADD, portfolioDraftData));

    };
    const deletePortfolioDraft = () => {
        const confirmMessage = t('Portfolio.confirmMessages.PFOC1');
        dispatch(deletePortfolioDrastDataRequest(portfolioDraftData?.portfolioId, false, confirmMessage));
    };

    const studyPlanRotation: IRotations[] | undefined = useSelector((state: any) => {
        if (state?.portfoliosReducer?.studyPlanRotationsData) {
            return (state.portfoliosReducer as IPortfolioMOdel).studyPlanRotationsData
        } else {
            return undefined
        }
    });

    const rotationIsActive = portfolioDraftData?.rotationName ? studyPlanRotation?.some(x => x.rotationName === portfolioDraftData?.rotationName) : true

    console.log("PortfolioDraftView==>", { portfolioDraftData });

    return (
        <>
            <tr>
                <td> {portfolioDraftData?.stageName || '-'}</td>
                <td> {portfolioDraftData?.rotationName || '-'}</td>
                <td> {portfolioDraftData?.code || '-'}</td>
                <td> {portfolioDraftData?.wbaName || '-'}</td>
                {/* <td> {'-'}</td> */}
                <td> {portfolioDraftData?.isAssessed ? t('Portfolio.assessed') : t('Portfolio.nonAssessed')}</td>
                <td> {portfolioDraftData?.firstRotationSupervisor?.supervisorName || '-'}</td>
                <td> {portfolioDraftData?.secondRotationSupervisor?.supervisorName || '-'}</td>
                {rotationIsActive ? <td className="column-center">
                    <img src={EditIcon} onClick={editPortfolioDraft} className="actionicon pointer" alt=""></img>
                    <img src={deleteIcon} onClick={deletePortfolioDraft} className="actionicon pointer" alt=""></img>
                </td>
                    : <td>-</td>}
            </tr>

        </>

    )
}
export default React.memo(PortfolioDraftView);