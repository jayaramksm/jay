import React, { useState, useEffect, useRef } from 'react';
import moment from 'moment';
import { useSelector } from 'react-redux'
import { EEvaluatorFeedBack, ICurrentDateAndTime, IPortfilo, IPortfolioMOdel } from '../../../../models/portfolioModel';
import { useTranslation } from 'react-i18next';
import { getAppsetting } from '../../../../helpers/helpersIndex';


interface IProps {
    remainderMethod: any;
    portfolioId: any;
}
let subscription;
const PortfolioTimer: React.FC<IProps> = (props) => {
    const { t } = useTranslation('translations');

    let [timer, setTimer] = useState('') as any;
    let [preTime, setPreTime] = useState('') as any;
    let timerMilliseconds = getAppsetting()?.portfolioTimer || 7200000;

    const createdOnDate: IPortfilo = useSelector((state: any) => {
        if (state?.portfoliosReducer?.createdOnDate)
            return (state.portfoliosReducer as IPortfolioMOdel).createdOnDate?.find(x => x.portfolioId === props.portfolioId);
        else return undefined;
    });


    const currentDateTime: ICurrentDateAndTime = useSelector((state: any) => {
        if (state?.portfoliosReducer?.currentDate)
            return (state.portfoliosReducer as any).currentDate
        else return undefined
    });
    // dateTime

    console.log('createdOn===>', props.portfolioId)


    const hoursAndMinutesAndSeconds = (seconds) => {
        if (typeof seconds !== 'string') {
            let sec = Math.floor(seconds % 60)
            let minutes = Math.floor(seconds / 60);
            let min = Math.floor(minutes % 60);
            let hours = Math.floor(minutes / 60);
            let hoursAndMinutesAndSeconds = `${hours < 10 ? `0${hours}` : hours}:${min < 10 ? `0${min}` : min}: ${sec < 10 ? `0${sec}` : sec}`
            return hoursAndMinutesAndSeconds;
        } else return '00 : 00 : 00'
    }

    useEffect(() => {
        if (!preTime && currentDateTime) {
            let timerDate = createdOnDate?.updatedOn
            setPreTime(timerDate)
            let date = new Date(timerDate).getTime() + timerMilliseconds;
            let oldDate = new Date(currentDateTime?.dateTime).getTime()
            console.log('timerRunner0===>', preTime, timerDate)
            if (date > oldDate) {
                console.log('timerRunner1===>', preTime)
                let diffData = Math.round(((date - oldDate) / 1000));
                setTimer(diffData)
                subscription = setInterval(() => {
                    setTimer(preState => preState - 1);
                }, 1000)
            }
        }
        else if (preTime) {
            console.log('timerRunner2===>', preTime)
            setTimer(timerMilliseconds / 1000);
            // setPreTime('');
            subscription = setInterval(() => {
                setTimer(preState => preState - 1);
            }, 1000)
        }
    }, [createdOnDate, currentDateTime])

    useEffect(() => {
        console.log('PortfolioTimer==>')
        return () => {
            console.log('clearingSubscription==>', subscription)
            if (subscription) {
                clearInterval(subscription);
            }
        }
    }, [])

    useEffect(() => {
        if (timer === 0) {
            setTimer('');
            // setPreTime('')
            if (subscription)
                clearInterval(subscription)
        }
    }, [timer])

    const evaluatorFeedBack = createdOnDate?.evaluatorFeedBack ? createdOnDate?.evaluatorFeedBack?.every(x => x?.status === EEvaluatorFeedBack.APPROVED) : false;
    console.log("PortfolioTimer==>", createdOnDate?.evaluatorFeedBack)
    return (
        <>
            {currentDateTime && <div>

                <button className='btn reminder-button' type='button' onClick={props.remainderMethod} disabled={evaluatorFeedBack || (typeof timer === 'string' ? false : true)} >
                    {!evaluatorFeedBack && <span>
                        {hoursAndMinutesAndSeconds(timer)}
                    </span>}
                    <br />{t('Portfolio.reminder')}</button>
            </div>}
        </>
    )
}
export default React.memo(PortfolioTimer);