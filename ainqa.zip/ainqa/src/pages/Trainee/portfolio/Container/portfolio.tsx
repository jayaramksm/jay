import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, cancelAllPendingPortfolioRequest, resetAllPortfolioStateRequest, getPortfolioDataRequest } from '../../../../store/actions';
import { SuperParentContext } from './portfolioContext';
import {
    PortfolioParentManager, PortfoliosViewManager, PortfoliosView, PortfolioFilter, PortfolioDraftViewManager,
    PortfolioDraftView, PortfolioAction, PorfolioAssessmentForms, PortfolioTimer
} from './portfolioIndex';
interface IProps {
    activateAuthLayout;
    cancelAllPendingPortfolioRequest;
    resetAllPortfolioStateRequest;
    getPortfolioDataRequest;
}
class Portfolio extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            portfoliosViewManager: PortfoliosViewManager,
            portfoliosViewView: PortfoliosView,
            portfolioFilter: PortfolioFilter,
            portfolioDraftViewManager: PortfolioDraftViewManager,
            portfolioDraftView: PortfolioDraftView,
            portfolioAction: PortfolioAction,
            porfolioAssessmentForms: PorfolioAssessmentForms,
            portfolioTimer: PortfolioTimer
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllPortfolioStateRequest();
        this.props.getPortfolioDataRequest();
    }
    componentWillUnmount() {
        this.props.resetAllPortfolioStateRequest();
        this.props.cancelAllPendingPortfolioRequest();

    }
    render() {
        return (
            <div className="flexLayout">

                <SuperParentContext.Provider value={this.state}>
                    <PortfolioParentManager />
                </SuperParentContext.Provider>
            </div>
        )
    }
}


export default connect(null, { activateAuthLayout, cancelAllPendingPortfolioRequest, resetAllPortfolioStateRequest, getPortfolioDataRequest })(Portfolio);