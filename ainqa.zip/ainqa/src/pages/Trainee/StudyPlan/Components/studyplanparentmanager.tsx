import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/studyplancontext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../models/utilitiesModel';


const StudyPlanParentManager: React.FC = () => {

    const context = useContext(SuperParentContext);

    const actionType: number = useSelector((state: any) => {
        if (state?.studyPlanReducer?.actionType)
            return state?.studyPlanReducer?.actionType;
        else return EOprationalActions.UNSELECT;
    })
    return (
        <React.Fragment >
            {actionType === EOprationalActions.UNSELECT && <context.studyPlanActionComponent />}
            {(actionType === EOprationalActions.EDIT) && <context.addorEditRotationsInStudyPlan />}
            {(actionType === EOprationalActions.SELECT) && <context.studyPlanView />}
            {(actionType === EOprationalActions.CHARTVIEW) && <context.chartView />}
            {(actionType === EOprationalActions.STUDY_PLAN_STAGES_VIEW) && <context.studyPlanStagesView />}
            {(actionType === EOprationalActions.STUDY_PLAN_ROTATIONS_VIEW) && <context.studyPlanStagesRotationsView />}
        </React.Fragment>
    )
}

export default React.memo(StudyPlanParentManager);
