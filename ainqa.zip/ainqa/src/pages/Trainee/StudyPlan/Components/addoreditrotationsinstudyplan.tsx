import React from 'react';
import { Formik, Field, Form, FieldArray } from 'formik';
import { useTranslation } from 'react-i18next';
import { FormGroup, Row, Col } from 'reactstrap';
import { MySelect } from '../../../../helpers/helpersIndex';
import { useSelector, useDispatch } from 'react-redux';
import * as Yup from 'yup';
import { customContentValidation, defultContentObjectValidate, defultContentValidate, getEnvironment } from '../../../../helpers/helpersIndex';
import { alertActionRequest, getAddOrEditStudyPlanRequest, setStudyPlanActionType } from '../../../../store/actions';
import { EApprovelActions, EOprationalActions } from '../../../../models/utilitiesModel';
import Reject from '../../../../images/Reject.svg';
import pending from '../../../../images/Pending.svg';
import approved from '../../../../images/Approved.svg';
import { EStudyPlanStatus, IHospital, IRotation, IPredefinedRotations, IStudyPlan } from '../../../../models/studyPlanModel';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import isEqual from 'lodash/isEqual';
import maxBy from 'lodash/maxBy';
import active from '../../../../images/Active_icon.svg';

const AddOrEditRotationsInStudyPlan: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const rotationsData: IPredefinedRotations[] = useSelector((state: any) => {
        if (state?.studyPlanReducer?.predefinedRotations)
            return state.studyPlanReducer.predefinedRotations
        else return []
    });

    const actionData: IStudyPlan = useSelector((state: any) => {
        if (state?.studyPlanReducer?.actionData)
            return state.studyPlanReducer.actionData
        else return undefined
    });

    const hospitalsData: IHospital[] = useSelector((state: any) => {
        if (state?.studyPlanReducer?.hospitalsData)
            return state.studyPlanReducer.hospitalsData
        else return []
    });

    const actionType: number = useSelector((state: any) => {
        if (state?.studyPlanReducer?.actionType)
            return state.studyPlanReducer.actionType
        else return EOprationalActions.ADD
    });

    let failedRotationsOptions;
    let studyPlanRotations;
    let rotations;
    let otherHospital = { hospitalName: 'Other', hospitalId: 0 }
    rotations = rotationsData.map((x, ind) => ({
        sequence: ind + 1,
        stage: '',
        rotation: '',
        hospital: '',
        otherHospital: '',
        duration: ''
    }));

    if (actionData) {
        let duplicatesFilteredData: IRotation[] = []
        actionData?.rotations?.forEach((x, ind, a) => {
            let index = a.findIndex(y => y.rotationId === x.rotationId);
            if (index === ind) {
                duplicatesFilteredData.push(x);
            } else {
                let i = duplicatesFilteredData.findIndex(z => z.rotationId === x.rotationId);
                if (duplicatesFilteredData[i].rotationStatus === 'failed') {
                    duplicatesFilteredData.splice(i, 1, x)
                }
            }
        });
        let failedRotations = duplicatesFilteredData.filter(x => x.rotationStatus === EStudyPlanStatus.FAILED);

        let newRotations: any = [...actionData.rotations] || []

        failedRotations?.forEach((x) => {
            let seq = maxBy(newRotations, data => +(data.rotationSequence || data.sequence))
            newRotations.push({
                sequence: +(seq.rotationSequence || seq.sequence) + 1,
                stage: '',
                rotation: '',
                hospital: '',
                otherHospital: '',
                duration: ''
            })
        });
        console.log('newlyaddedFailedRotations==>', newRotations)

        failedRotationsOptions = rotationsData.filter(x => failedRotations.some(y => x.rotationId === y.rotationId))

        studyPlanRotations = newRotations.map(x => ({
            sequence: x.rotationSequence || x.sequence,
            stage: x.rotationStageName,
            rotation: rotationsData.find(y => y.rotationId === x.rotationId) || '',
            hospital: hospitalsData.find(y => y.hospitalId === x.hospitalId) || (x.spRotationId ? otherHospital : ''),
            otherHospital: x.otherHospitalName || '',
            duration: x.rotationDuration,
            spRotationId: x.spRotationId,
            rotationComments: x.rotationComments,
            rotationStatus: x.rotationStatus
        }))
        console.log('rotationsData==>', rotations, studyPlanRotations)
    }

    const selectRotation = (setFieldValue, e, ind, event, rotation, values) => {
        console.log('eventData==>', e, event);
        setFieldValue(`rotations.${ind}.rotation`, e ? e : '');
        setFieldValue(`rotations.${ind}.stage`, e?.phaseDenominationName || '');
        setFieldValue(`rotations.${ind}.duration`, e?.rotationDuration || '');

        if (e) {
            let rotationOptions = values?.rotationOptions?.filter(x => x.rotationId !== e.rotationId);
            if (rotation)
                rotationOptions = [rotation, ...rotationOptions];
            setFieldValue('rotationOptions', rotationOptions)
        }
        else if (event?.action === 'clear') {
            let rotationOptions = [rotation, ...values?.rotationOptions];
            setFieldValue('rotationOptions', rotationOptions)
        }
    }
    const selectHospital = (setFieldValue, e, ind) => {
        setFieldValue(`rotations.${ind}.hospital`, e ? e : '');
        setFieldValue(`rotations.${ind}.otherHospital`, '')
    }

    const goBackToStudyPlan = (resetForm) => {
        resetForm()
        dispatch(setStudyPlanActionType(EOprationalActions.UNSELECT));
    }

    const goBackStages = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.STUDY_PLAN_STAGES_VIEW, { ...(actionData || {}) }));
    }

    const viewStudyPlan = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.SELECT, null));
    }

    const goToChartView = () => {
        if (actionData?.approvalStatus !== EStudyPlanStatus.APPROVED) {
            const alertMessageData = {
                message: t('StudyPlan.studyPlanApproveStatus'),
                status: false,
                tranId: Date.now()
            };
            dispatch(alertActionRequest(alertMessageData));
        } else
            dispatch(setStudyPlanActionType(EOprationalActions.CHARTVIEW, { ...(actionData || {}), chartPath: EOprationalActions.SELECT }));
    }
    return (
        <div className="maincontent flexLayout pr-0" >
            {actionData && !(actionData.isUpdateFromView) &&
                <div className='compheading d-flex justify-content-between'>
                    <div className="breadcrumbs m-0">
                        <h3 className="page-header header-title">{t('StudyPlan.updateStudyPlan')}</h3>
                        {/* {failedRotationsOptions && failedRotationsOptions.length > 0 && <span className='text-danger mx-2'>{t('StudyPlan.failedRotations')}</span>} */}
                    </div>
                </div>
            }
            {
                actionData?.isUpdateFromView && <Row className='compHeading'>
                    <Col className="breadcrumbs">
                        <div> <span className='pointer' onClick={goBackStages}>{t('StudyPlan.programStages')}</span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="pointer" onClick={viewStudyPlan}>{t('StudyPlan.viewStudyPlan')}</span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="active">{t('StudyPlan.updateStudyPlan')}</span>
                        </div>
                    </Col>
                    {/* <Col>
                        {failedRotationsOptions && failedRotationsOptions.length > 0 && <span className='text-danger'>{t('StudyPlan.failedRotations')}</span>}
                    </Col> */}
                    <div className="rgtFilter">
                        <div>
                            <button type='button' className='btn link-button' onClick={goToChartView}> {t('StudyPlan.viewChart')}</button>
                        </div>
                    </div>
                </Row>
            }
            {
                <Formik
                    enableReinitialize
                    initialValues={{
                        rotations: actionData ? (studyPlanRotations ?? []) : rotations ? rotations : [],
                        rotationOptions: actionData ? (failedRotationsOptions || []) : rotationsData ? rotationsData : [],
                        currentPage: 0
                    }}
                    validationSchema={Yup.object().shape({
                        rotations: Yup.array().of(
                            Yup.object().shape({
                                rotation: customContentValidation(t, t('controleErrors.required')),
                                hospital: defultContentObjectValidate(t('controleErrors.required')),
                                otherHospital: Yup.string().when('hospital', {
                                    is: (hospital) => hospital?.hospitalName === "Other",
                                    then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 100, 4),
                                    otherwise: defultContentValidate(''),
                                })
                            })
                        )
                    })}
                    onSubmit={values => {
                        dispatch(getAddOrEditStudyPlanRequest(actionType, values.rotations))
                        console.log('onSubmit==>', values)
                    }}
                >
                    {
                        ({ values, errors, touched, setFieldTouched, setFieldValue, dirty, resetForm }) => {

                            // let pagesCount: number = Math.ceil((values?.rotations ? values?.rotations?.length : 0) / pageSize);

                            // if (values.currentPage >= pagesCount && pagesCount !== 0)
                            //     setFieldValue('currentPage', 0);

                            // const handleClick = (e, index) => {
                            //     e.preventDefault();
                            //     console.log('_pagination_index', index);
                            //     setFieldValue('currentPage', index);
                            // };

                            return <Form className="flexLayout">
                                <div className="flexScroll">
                                    <div className="main-table no-border">
                                        <div className="tbl-parent">
                                            <table className="myTable studyplanRotationsTable table">
                                                <thead>
                                                    <tr>
                                                        <th>{t('StudyPlan.sequence')}</th>
                                                        <th>{t('StudyPlan.stage')}</th>
                                                        <th>{t('StudyPlan.rotation')}</th>
                                                        <th>{t('StudyPlan.hospitalName')}</th>
                                                        <th>{t('StudyPlan.otherHospitalName')}</th>
                                                        <th>
                                                            {t('StudyPlan.duration')}
                                                            <small className="d-block">({t('StudyPlan.inMonths')})</small>
                                                        </th>
                                                        {actionType === EOprationalActions.EDIT && <th className="column-center">
                                                            {t('StudyPlan.completionStatus')}
                                                        </th>}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <FieldArray
                                                        name='rotations'
                                                    >
                                                        {
                                                            () => {

                                                                return <>
                                                                    {
                                                                        (values?.rotations as any)?.map((x, ind) => {
                                                                            // .slice((values.currentPage * pageSize), ((values.currentPage + 1) * pageSize))?
                                                                            // let ind = (values?.rotations as any)?.findIndex(y => y.sequence === x.sequence);
                                                                            const rotationError = errors?.rotations?.length && ((errors?.rotations[ind] as any)?.rotation || '');
                                                                            const rotationTouched = touched.rotations && ((touched?.rotations[ind] as any)?.rotation || '');

                                                                            const hospitalError = errors?.rotations?.length && ((errors?.rotations[ind] as any)?.hospital || '');
                                                                            const hospitalTouched = touched.rotations && ((touched?.rotations[ind] as any)?.hospital || '');

                                                                            const otherHospitalError = errors?.rotations?.length && ((errors?.rotations[ind] as any)?.otherHospital || '');
                                                                            const otherHospitalTouched = touched.rotations && ((touched?.rotations[ind] as any)?.otherHospital || '');

                                                                            return <React.Fragment key={x.sequence}>
                                                                                <tr>
                                                                                    <td>
                                                                                        <div>{x.rotationSequence || x.sequence}</div>
                                                                                    </td>
                                                                                    <td>
                                                                                        <div>{x.rotationStageName || x.stage || '-'}</div>
                                                                                    </td>
                                                                                    <td>
                                                                                        <MySelect
                                                                                            name="rotation"
                                                                                            placeholder={t('StudyPlan.selectRotation')}
                                                                                            isDisabled={(x.rotationStatus === EStudyPlanStatus.FAILED || x.rotationStatus === EStudyPlanStatus.COMPLETED || x?.isWbaFiled) ? true : false}
                                                                                            value={x.rotation}
                                                                                            onChange={(e, event) => selectRotation(setFieldValue, e, ind, event, x.rotation, values)}
                                                                                            options={values.rotationOptions ? values.rotationOptions : []}
                                                                                            isClearable={true}
                                                                                            getOptionLabel={option => option.rotationName}
                                                                                            getOptionValue={option => option.rotationId}
                                                                                            valueKye="name"
                                                                                            onBlur={() => setFieldTouched(`rotations.${ind}.rotation`, true)}
                                                                                            noOptionsMessage={() => 'NoDataFound'}
                                                                                            isOptionDisabled={(option) => option.isDisabled}
                                                                                        />
                                                                                        {rotationError && rotationTouched && (
                                                                                            <div className="text-danger small">{rotationError}</div>
                                                                                        )}
                                                                                    </td>
                                                                                    <td>
                                                                                        <MySelect
                                                                                            name="hospital"
                                                                                            placeholder={t('StudyPlan.selectHospital')}
                                                                                            value={x.hospital}
                                                                                            isDisabled={(x.rotationStatus === EStudyPlanStatus.FAILED || x.rotationStatus === EStudyPlanStatus.COMPLETED) ? true : false}
                                                                                            onChange={(e) => selectHospital(setFieldValue, e, ind)}
                                                                                            options={hospitalsData ? hospitalsData : []}
                                                                                            getOptionLabel={option => option.hospitalName}
                                                                                            getOptionValue={option => option.hospitalId}
                                                                                            valueKye="name"
                                                                                            onBlur={() => setFieldTouched(`rotations.${ind}.hospital`, true)}
                                                                                            noOptionsMessage={() => 'NoDataFound'}
                                                                                            isOptionDisabled={(option) => option.isDisabled}
                                                                                        />
                                                                                        {hospitalError && hospitalTouched && (
                                                                                            <div className="text-danger small">{hospitalError}</div>
                                                                                        )}
                                                                                    </td>
                                                                                    <td>
                                                                                        <Field type='text' name={`rotations.${ind}.otherHospital`} disabled={(x.rotationStatus === EStudyPlanStatus.FAILED || x.rotationStatus === EStudyPlanStatus.COMPLETED) ? true : (x.hospital as any)?.hospitalName === 'Other' ? false : true}
                                                                                            placeholder={t('StudyPlan.enterHospitalName')} className='form-control' />
                                                                                        {otherHospitalError && otherHospitalTouched && (
                                                                                            <div className="text-danger small">{otherHospitalError}</div>
                                                                                        )}
                                                                                    </td>

                                                                                    <td>
                                                                                        <div>{x.duration || x.rotationDuration || 'N/A'}</div>
                                                                                    </td>
                                                                                    {actionType === EOprationalActions.EDIT && <td className="column-center">
                                                                                        {
                                                                                            x.rotationStatus === EApprovelActions.COMPLETED ? <img src={approved} alt="" className="icon"></img> :
                                                                                                x.rotationStatus === EApprovelActions.FAILED ? <img src={Reject} alt="rejectLogo" /> : x.rotationStatus === EApprovelActions.ACTIVE ? <img src={active} alt="" className="icon"></img> : x.rotationStatus === EApprovelActions.PENDING ? <img src={pending} alt="pending" className="icon"></img> : ''
                                                                                        }
                                                                                    </td>}
                                                                                </tr>
                                                                            </React.Fragment>
                                                                        })

                                                                    }

                                                                </>
                                                            }
                                                        }
                                                    </FieldArray>
                                                </tbody>
                                            </table>
                                            {/* {(values?.rotations?.length > pageSize) &&
                                                <div className="pagination">
                                                    <PaginationComponent currentPage={values.currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                                                </div>
                                            } */}
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-2 text-right mr-2">
                                    <button type="button" className="btn cancel-button" onClick={() => goBackToStudyPlan(resetForm)}>{t('ActionNames.cancel')}</button>
                                    <button type="submit" className="btn blue-button ml-2" disabled={actionType === EOprationalActions.EDIT ? !dirty : false} >{actionType === EOprationalActions.EDIT ? t('ActionNames.update') : t('ActionNames.submit')}</button>
                                </div>
                            </Form>
                        }
                    }
                </Formik>
            }
        </div>
    )
}

export default React.memo(AddOrEditRotationsInStudyPlan);