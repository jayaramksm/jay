import React, { useState } from 'react';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { alertActionRequest, setStudyPlanActionType } from '../../../../store/actions';
import Reject from '../../../../images/Reject.svg';
import pending from '../../../../images/Pending.svg';
import approved from '../../../../images/Approved.svg';
import active from '../../../../images/Active_icon.svg';
import { EStudyPlanStatus, IStudyPlan } from '../../../../models/studyPlanModel';
import { Row, Col } from 'reactstrap';
// import { getEnvironment } from '../../../../helpers/helpersIndex';
// import { PaginationComponent } from '../../../utilities/PaginationComponent';


const StudyPlanStagesRotationsView: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    // const pageSize = getEnvironment.pageSize;
    // const [currentPage, setCurrentPage] = useState(0);

    const actionData: IStudyPlan = useSelector((state: any) => {
        if (state?.studyPlanReducer?.rotationsActionData)
            return state.studyPlanReducer.rotationsActionData
        else return undefined
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    const goBackStages = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.STUDY_PLAN_STAGES_VIEW, { ...(actionData?.studyplan || {}) }));
    }

    const viewStudyPlan = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.SELECT, null));
    }

    const goToChartView = () => {
        if (actionData?.studyplan?.approvalStatus !== EStudyPlanStatus.APPROVED) {
            const alertMessageData = {
                message: t('StudyPlan.studyPlanApproveStatus'),
                status: false,
                tranId: Date.now()
            };
            dispatch(alertActionRequest(alertMessageData));
        } else
            dispatch(setStudyPlanActionType(EOprationalActions.CHARTVIEW, { ...(actionData?.studyplan || {}), chartPath: EOprationalActions.STUDY_PLAN_STAGES_VIEW }));
    }

    // let pagesCount: number = Math.ceil((actionData?.rotations ? actionData?.rotations?.length : 0) / pageSize);

    // if (currentPage >= pagesCount && pagesCount !== 0)
    //     setCurrentPage(0);

    // const handleClick = (e, index) => {
    //     e.preventDefault();
    //     console.log('_pagination_index', index);
    //     setCurrentPage(index);
    // };

    return (

        <React.Fragment>
            <div className="maincontent flexLayout pr-0">
                <Row className="compHeading">
                    <Col>
                        <div className="breadcrumbs">
                            <div> <span className='pointer' onClick={goBackStages}>{t('StudyPlan.programStages')}</span>
                                <span><i className="ti-angle-right"></i></span>
                                <span className="active">{actionData?.stage}</span>
                            </div>
                        </div>
                    </Col>

                    <div className="rgtFilter">
                        <button type='button' className='btn link-button mr-1' onClick={goToChartView}> {t('StudyPlan.viewChart')}</button>
                        <button type='button' className='btn btn-green ml-2' onClick={viewStudyPlan}>{t('StudyPlan.viewStudyPlan')}</button>
                    </div>
                </Row>

                <div className="flexLayout">
                    <div className="flexScroll">
                        <div className="main-table no-border">
                            <div className="tbl-parent table-responsive">
                                <table className="myTable table stagerotationTable">
                                    <thead>
                                        <tr>
                                            <th>{t('StudyPlan.sequence')}</th>
                                            <th>{t('StudyPlan.rotation')}</th>
                                            <th>{t('StudyPlan.stage')}</th>
                                            <th> {t('StudyPlan.university')}</th>
                                            <th>{t('StudyPlan.hospitalName')}</th>
                                            <th>
                                                {t('StudyPlan.duration')}
                                                <small className="d-block">({t('StudyPlan.inMonths')})</small>
                                            </th>
                                            <th className="column-center">{t('StudyPlan.rotationStatus')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            // .slice((currentPage * pageSize), ((currentPage + 1) * pageSize))?
                                            actionData?.rotations?.map(x => (
                                                <tr key={x.spRotationId}>
                                                    <td>{x.rotationSequence}</td>
                                                    <td>{x.rotation}</td>
                                                    <td>{x.rotationStageName}</td>
                                                    <td>{userDto?.university?.universityName}</td>
                                                    <td>{x.hospitalName || `Other-${x.otherHospitalName}`}</td>
                                                    <td>{x.rotationDuration}</td>
                                                    <td className="column-center">{
                                                        x.rotationStatus === EApprovelActions.COMPLETED ? <img src={approved} alt="" className="icon"></img> :
                                                            x.rotationStatus === EApprovelActions.FAILED ? <img src={Reject} alt="rejectLogo" /> : x.rotationStatus === EApprovelActions.ACTIVE ? <img src={active} alt="" className="icon"></img> : x.rotationStatus === EApprovelActions.PENDING ? <img src={pending} alt="pending" className="icon"></img> : ''
                                                    }</td>
                                                </tr>
                                            ))
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                {/* {(actionData?.rotations?.length > pageSize) &&
                    <div className="pagination">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                } */}
            </div>
        </React.Fragment>
    )
}

export default React.memo(StudyPlanStagesRotationsView);