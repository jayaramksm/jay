import React, { useContext } from 'react';
import { Row, Col } from 'reactstrap';
import editicon from '../../../../images/Edit.svg';
import viewicon from '../../../../images/View.svg';
import pending from '../../../../images/Pending.svg';
import { useSelector, useDispatch } from 'react-redux';
import { alertActionRequest, setStudyPlanActionType } from '../../../../store/actions';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { EStudyPlanStatus, IStudyPlan } from '../../../../models/studyPlanModel';
import approved from '../../../../images/Approved.svg';
import Reject from '../../../../images/Reject.svg';
import { SuperParentContext } from '../Container/studyplancontext';

const StudyPlanAction: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const context = useContext(SuperParentContext);


    const studyPlansData: IStudyPlan[] = useSelector((state: any) => {
        if (state?.studyPlanReducer?.studyPlansData)
            return state?.studyPlanReducer?.studyPlansData;
        else return undefined;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    const isRotationsDefined: boolean = useSelector((state: any) => {
        if (state?.studyPlanReducer?.predefinedRotations)
            return state.studyPlanReducer.predefinedRotations.length > 0;
        else return false;
    });

    const editStudyPlan = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.EDIT, studyPlansData?.[0]));
    }

    const handlestudyPlanChartView = (approvalStatus) => {
        if (approvalStatus !== EStudyPlanStatus.APPROVED) {
            const alertMessageData = {
                message: t('StudyPlan.studyPlanApproveStatus'),
                status: false,
                tranId: Date.now()
            };
            dispatch(alertActionRequest(alertMessageData));
        } else
            dispatch(setStudyPlanActionType(EOprationalActions.CHARTVIEW, studyPlansData?.[0]));
    }

    const goToStudyPlanStages = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.STUDY_PLAN_STAGES_VIEW, studyPlansData?.[0]));
    }
    console.log("studyPlanAction==>", { userDto, studyPlansData });

    return (
        <>
            <div className="maincontent flexLayout pr-0">
                {isRotationsDefined && studyPlansData && !(studyPlansData.length > 0) && <>
                    <h3 className="page-header">{t('StudyPlan.rotationsofProgram')} <span className="note-inline">* {t('StudyPlan.addAllRotations')}</span></h3>
                    <context.addorEditRotationsInStudyPlan />
                </>}
                {(!isRotationsDefined && studyPlansData) && <h5 className="text-danger">{t('StudyPlan.noDefinedRotations')}</h5>}

                {studyPlansData && studyPlansData.length > 0 && <>
                    <Row className='compHeading'>
                        <Col>
                            <h3 className="page-header header-title">{t('StudyPlan.studyPlan')}</h3>
                        </Col>
                    </Row>
                    <div className="flexLayout">
                        <div className="flexScroll">
                            <div className="main-table no-border"></div>
                            <div className="tbl-parent table-responsive">
                                <table className="myTable studyplanTable table">
                                    <thead>
                                        <tr>
                                            <th>{t('StudyPlan.studyPlan')}</th>
                                            <th>{t('StudyPlan.approvalDate')}</th>
                                            <th className="column-center">{t('StudyPlan.approvalStatus')}</th>
                                            <th>{t('StudyPlan.comment')}</th>
                                            <th>{t('StudyPlan.ganttChart')}</th>
                                            <th className="column-center">{t('StudyPlan.actions')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="ActionStatus pointer" onClick={goToStudyPlanStages}>{t('ActionNames.view')}</td>
                                            <td>{studyPlansData?.[0]?.approvedDate || "-"}</td>
                                            <td className="column-center">
                                                {studyPlansData?.[0]?.approvalStatus === EStudyPlanStatus.APPROVED ? <img src={approved} alt="" className="icon"></img> :
                                                    studyPlansData?.[0]?.approvalStatus === EStudyPlanStatus.REJECTED ? <img src={Reject} alt="" className="icon"></img> : studyPlansData?.[0]?.approvalStatus === EApprovelActions.ACTIVE ? 'Active' :
                                                        studyPlansData?.[0]?.approvalStatus === EApprovelActions.PENDING ? <img src={pending} alt="" className="icon"></img> : ''}
                                            </td>
                                            <td>{studyPlansData?.[0]?.approvalComments || "-"}</td>
                                            <td><span className="viewChart pointer" onClick={() => handlestudyPlanChartView(studyPlansData?.[0]?.approvalStatus)}> {t('StudyPlan.viewChart')}</span></td>
                                            <td className="column-center">{<span onClick={editStudyPlan}> <img src={editicon} alt="" className="actionicon pointer"></img></span>}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </>}
            </div>
        </>
    )
}

export default React.memo(StudyPlanAction);
