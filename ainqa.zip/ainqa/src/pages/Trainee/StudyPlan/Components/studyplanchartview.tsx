import React, { useEffect } from 'react';
import * as echarts from 'echarts';
import { useDispatch, useSelector } from 'react-redux';
import { setStudyPlanActionType } from '../../../../store/actions';
import { EApprovelActions, EOprationalActions } from '../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import moment from 'moment';
import { EStudyPlanStatus, ICurrentDateAndTime, IStudyPlan } from '../../../../models/studyPlanModel';
import orderBy from 'lodash/orderBy';


const StudyPlanChartView: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    let labelMsg = true;
    const graphHeight = '400px';

    const actionData: IStudyPlan = useSelector((state: any) => {
        if (state?.studyPlanReducer?.actionData)
            return state.studyPlanReducer.actionData
        else return undefined
    });

    const currentDateAndTime: ICurrentDateAndTime = useSelector((state: any) => {
        if (state?.studyPlanReducer?.currentDateAndTime)
            return state.studyPlanReducer.currentDateAndTime
        else return undefined
    });

    let orderedRotations = orderBy(actionData?.rotations, (data) => +(data.rotationSequence))?.filter(x => x.rotationStatus !== EApprovelActions.FAILED)
    console.log('StudyPlanChartView_rotationsInOrder=>', orderedRotations)

    let data: any[] = [];
    let startDate = "";
    let endDate = "";

    if (actionData && orderedRotations) {
        (orderedRotations)?.forEach((x, ind) => {
            if ((x.rotationStartDate)) {
                if (x.rotationStatus === EStudyPlanStatus.ACTIVE) {
                    labelMsg = false;
                }
                startDate = moment(x.rotationStartDate).format('YYYY-MM-DD');
                endDate = x.rotationEndDate || moment(startDate).add(+x.rotationDuration, 'M').format('YYYY-MM-DD');
                data.push([x.rotationSequence, `${x.rotation}/${x.rotationStageName}`, startDate, endDate])
                // data.push([x.rotation, `${x.rotationStageName}`, startDate, endDate])
            } else if (!(x.rotationStartDate) && ind === 0) {
                startDate = moment(currentDateAndTime?.date).format('YYYY-MM-DD');
                endDate = moment(startDate).add(+x.rotationDuration, 'M').format('YYYY-MM-DD');
                data.push([x.rotationSequence, `${x.rotation}/${x.rotationStageName}`, startDate, endDate])
                console.log(`dates${ind}==>`, startDate, endDate, currentDateAndTime?.date)
                // data.push([x.rotation, `${x.rotationStageName}`, startDate, endDate])

            } else if (!(x.rotationStartDate)) {
                startDate = moment(endDate).add(1, 'd').format('YYYY-MM-DD');
                endDate = moment(startDate).add(+x.rotationDuration, 'M').format('YYYY-MM-DD');
                data.push([x.rotationSequence, `${x.rotation}/${x.rotationStageName}`, startDate, endDate])
                // data.push([x.rotation, `${x.rotationStageName}`, startDate, endDate])
            }
        })
    }
    console.log('StudyPlanChartView_chartData===>', data)
    // data = [
    //     [
    //         "1",
    //         "child Rotation/Stage 4",
    //         "2021-09-26",
    //         "2028-10-26"
    //     ],
    //     [
    //         "2",
    //         "Medical Rotation/Stage 1",
    //         "2021-08-28",
    //         "2021-09-28"
    //     ]
    // ]
    const renderChart = () => {
        var chartDom = document.getElementById('main') as HTMLElement;
        var myChart = echarts.init(chartDom);
        // var data = [
        //     ['Rotation1', 'Year I', '2020-01-01', '2020-04-10'],
        //     ['Rotation2', 'Year I', '2020-04-20', '2020-08-10'],
        //     ['Rotation3', 'Year I', '2020-08-05', '2020-12-01'],
        //     ['Rotation4', 'Year II', '2020-12-10', '2021-03-14'],
        //     ['Rotation5', 'Year II', '2021-03-15', '2021-07-01'],
        //     ['Rotation6', 'Year II', '2021-07-15', '2021-12-01'],
        //     ['Rotation7', 'Year III', '2021-12-15', '2022-04-01'],
        //     ['Rotation8', 'Year III', '2022-04-15', '2022-09-01'],
        //     ['Rotation9', 'Year III', '2022-09-15', '2022-12-01'],
        //     ['Rotation10', 'Year IV', '2022-12-15', '2023-04-01'],
        //     ['Rotation11', 'Year IV', '2023-04-15', '2023-08-01'],
        //     ['Rotation12', 'Year IV', '2023-08-15', '2023-12-01']
        // ]
        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var optionObj: any = {
            yAxisData2: [],
            yAxisData: [],
            seriesData_01: [],
            seriesData_02: [],
        }

        for (let item of data.values()) {
            optionObj.yAxisData.push(item[0]);
            optionObj.yAxisData2.push(item[1]);
            optionObj.seriesData_01.push(new Date(item[2]));
            optionObj.seriesData_02.push(new Date(item[3]));
        }
        var LabelsList = {};
        var option = {
            width: "56%",
            media: [
                {
                    query:
                    {
                        minWidth: 1367,
                    },
                    option: {
                        width: "66%",
                    }
                },
                {
                    query:
                    {
                        maxWidth: 768,
                    },
                    option: {
                        width: "35%",
                    }
                },
                {
                    query:
                    {
                        minWidth: 769,
                        maxWidth: 1024
                    },
                    option: {
                        width: "38%",
                    }
                }
            ],
            tooltip: {
                trigger: 'axis',
                backgroundColor: "#ffffff",
                textStyle: { color: "#333333" },
                formatter: function (params) {
                    return params[0]?.axisValue + '<br/>' + "StartDate: " + echarts.format.formatTime('yyyy/MM/dd', params[0]?.value, false) + '<br/>' + "EndDate: " + echarts.format.formatTime('yyyy/MM/dd', params[1]?.value, false);
                },
            },
            grid: {
                containLabel: false,
                show: false,
                left: "auto",
                right: 12,
            },
            xAxis: {
                type: "time",
                position: 'top',
                minInterval: 3600 * 1000 * 744,
                axisLine: {
                    show: true,
                    onZero: false,
                    lineStyle: {
                        color: '#fff'
                    }
                },
                splitLine: {
                    show: true,
                },
                axisTick: {
                    show: false,
                    lineStyle: {
                        color: '#fff'
                    }
                },
                // max: function (value, index) {
                //     console.log("value.max=>", value.max);

                //     return (1664150400000) + (3600 * 1000 * 744);//(value.max > 1664150400000 ? value.max : 1664150400000) + (3600 * 250000);
                // },
                axisLabel: {
                    show: true,
                    showMinLabel: true,
                    showMaxLabel: true,
                    color: '#0048b3',
                    padding: [10, 10, 10, 10],
                    fontWeight: 600,
                    left: 60,
                    fontSize: 12,
                    formatter: (value, index) => {
                        var date = new Date(value);
                        var texts = [date.getFullYear(), months[(date.getMonth())]];
                        if (!LabelsList[texts.join("\r\n")]) {
                            LabelsList[texts.join("\r\n")] = true;
                            return texts.join("\r\n");
                        }
                        else {
                            return null;
                        }
                    }
                }
            },
            yAxis: [
                {
                    name: "Sequence",
                    nameLocation: 'start',
                    nameTextStyle: {
                        align: 'right',
                        fontWeight: "bold",
                        fontSize: '14',
                        fontFamily: "ROBOTO",
                        padding: [0, 460, 0, 0],
                        color: '#fd7d00',
                    },
                    nameGap: 10,
                    inverse: true,
                    axisTick: {
                        show: true,
                        length: 455,
                        lineStyle: { color: '#efeeef' }
                    },
                    axisLine: {
                        lineStyle: { color: '#333333' },
                    },
                    axisLabel: { margin: 200, padding: [0, 280, 0, 0] },

                    data: optionObj.yAxisData,

                }, {
                    name: "Rotations / Stage ",
                    nameLocation: 'start',
                    nameTextStyle: {
                        align: 'right',
                        fontWeight: "bold",
                        fontSize: '14',
                        fontFamily: "ROBOTO",
                        padding: [0, -350, 0, 0],
                        color: '#fd7d00',
                    },
                    nameGap: 10,
                    inverse: true,
                    splitLine: {
                        show: true
                    },
                    axisTick: {
                        show: true,
                        length: 70,
                        lineStyle: { color: '#efeeef' }
                    },
                    axisLine: {
                        lineStyle: { color: '#2a4350' },

                    },
                    axisLabel: {
                        padding: [0, -450, 0, 0]
                    },

                    data: optionObj.yAxisData2,
                    position: 'left',
                    offset: 455
                },
                {
                    axisLine: {
                        onZero: false,
                        show: true
                    },
                    position: 'left',
                    offset: 525
                }
            ],
            series: [
                {
                    name: "StartDate",
                    type: "bar",
                    stack: "duration",
                    itemStyle: {
                        color: "#ffffff",
                    },
                    emphasis: {
                        itemStyle: {
                            color: "#ffffff",
                        }
                    },
                    barWidth: 20,
                    zlevel: -1,
                    z: 3,
                    data: optionObj.seriesData_01
                },
                {
                    name: "EndDate",
                    type: "bar",
                    stack: "duration",
                    label: {
                        show: true
                    },
                    itemStyle: {
                        color: "#0048b3",
                        borderColor: "#ffffff",
                        borderWidth: 2,
                    },
                    emphasis: {
                        itemStyle: {
                            color: "#0048b3",
                            borderColor: "#ffffff",
                            borderWidth: 2,
                        }
                    },
                    barWidth: 20,
                    zlevel: -1,
                    data: optionObj.seriesData_02
                },
            ]
        };
        option && myChart.setOption(option);
    }

    useEffect(() => {
        renderChart();
    }, []);

    const openChartView = () => {
        // this.setState({ openChart: true });
        // setTimeout(() => {
        //     this.renderChart();

        // }, 5000);
    };

    const goBackToStudyPlan = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.UNSELECT));
    }

    const goBackToStages = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.STUDY_PLAN_STAGES_VIEW, actionData));
    }

    const viewStudyPlan = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.SELECT, null));
    }

    return (
        <>
            <div className="flexLayout maincontent mr-3">
                <div className="breadcrumbs">
                    {!(actionData.chartPath) && <div>
                        <span className='pointer' onClick={goBackToStudyPlan}>{t('StudyPlan.studyPlan')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{t('StudyPlan.chartView')}</span>
                    </div>}
                    {actionData.chartPath === EOprationalActions.STUDY_PLAN_STAGES_VIEW && <div>
                        <span className='pointer' onClick={goBackToStages}>{t('StudyPlan.programStages')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{t('StudyPlan.chartView')}</span>
                    </div>}

                    {actionData.chartPath === EOprationalActions.SELECT && <div>
                        <span className='pointer' onClick={goBackToStages}>{t('StudyPlan.programStages')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="pointer" onClick={viewStudyPlan}>{t('StudyPlan.viewStudyPlan')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{t('StudyPlan.chartView')}</span>
                    </div>}
                </div>
                {labelMsg && <div className='text-danger'> * {t('StudyPlan.illustrationPurposeChartMsg')}</div>}

                <div style={{ overflowY: 'scroll', height: '100%', padding: '0' }}>
                    <div id="main" style={{ width: "100%", height: orderedRotations?.length <= 10 ? graphHeight : (orderedRotations?.length * 30) + 'px' }}></div>
                </div>

            </div>
        </>
    )
}

export default React.memo(StudyPlanChartView);
