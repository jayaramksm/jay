import React from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import groupBy from 'lodash/groupBy';
import { EStudyPlanStatus, IStudyPlan } from '../../../../models/studyPlanModel';
import Reject from '../../../../images/Reject.svg';
import pending from '../../../../images/Pending.svg';
import approved from '../../../../images/Approved.svg';
import active from '../../../../images/Active_icon.svg';

import { alertActionRequest, setStudyPlanActionType, setStudyPlanRotationActionTypeData } from '../../../../store/actions';
import { EApprovelActions, EOprationalActions } from '../../../../models/utilitiesModel';
import { Row, Col } from 'reactstrap';

const StudyPlanStagesView: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionData: IStudyPlan = useSelector((state: any) => {
        if (state?.studyPlanReducer?.actionData)
            return state.studyPlanReducer.actionData
        else return undefined
    });

    let groupedRotationData = groupBy(actionData?.rotations, 'rotationStageName')
    console.log('GroupedrotationsData==>', groupedRotationData)

    let stages = Object.entries(groupedRotationData);

    const sumRotationsDuration = (rotations) => {
        return rotations?.reduce((acc, x) => acc + (+x.rotationDuration), 0)
    }

    const goToStageRotations = (stage, rotations) => {
        dispatch(setStudyPlanActionType(EOprationalActions.STUDY_PLAN_ROTATIONS_VIEW, actionData));
        dispatch(setStudyPlanRotationActionTypeData({ stage: stage, rotations, studyplan: actionData }))
    }

    const viewStudyPlan = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.SELECT, actionData));
    }

    const goBackToStudyPlan = () => {
        dispatch(setStudyPlanActionType(EOprationalActions.UNSELECT, null));
    }

    const goToChartView = () => {
        if (actionData?.approvalStatus !== EStudyPlanStatus.APPROVED) {
            const alertMessageData = {
                message: t('StudyPlan.studyPlanApproveStatus'),
                status: false,
                tranId: Date.now()
            };
            dispatch(alertActionRequest(alertMessageData));
        } else
            dispatch(setStudyPlanActionType(EOprationalActions.CHARTVIEW, { ...actionData, chartPath: EOprationalActions.STUDY_PLAN_STAGES_VIEW }));
    }

    return (
        <>
            <React.Fragment>
                <div className="maincontent flexLayout pr-0">
                    <Row className='compHeading'>
                        <Col>
                            <h3 className="page-header">{t('StudyPlan.programStages')}</h3>
                        </Col>
                        <div className="rgtFilter">
                            <button type='button' className='btn link-button mr-1' onClick={goToChartView}> {t('StudyPlan.viewChart')}</button>
                            <button type='button' className='btn btn-green ml-2' onClick={viewStudyPlan}>{t('StudyPlan.viewStudyPlan')}</button>
                        </div>
                    </Row>

                    <div className="flexLayout">
                        <div className="flexScroll">
                            <div className="main-table no-border">
                                <div className="tbl-parent table-responsive">
                                    <table className="myTable pointof-contact-table table">
                                        <thead>
                                            <tr>
                                                <th>{t('StudyPlan.stage')}</th>
                                                <th> {t('StudyPlan.rotationCount')}</th>
                                                <th>
                                                    {t('StudyPlan.duration')}
                                                    <small className="d-block">({t('StudyPlan.inMonths')})</small>
                                                </th>
                                                <th className="column-center">{t('StudyPlan.completionStatus')}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                stages?.map((x: [string, any], ind) => (
                                                    <tr key={ind}>
                                                        <td className='ActionStatus pointer' onClick={() => goToStageRotations(x[0], x[1])}>{x[0]}</td>
                                                        <td>{x[1]?.length || 0}</td>
                                                        <td>{sumRotationsDuration(x[1])}</td>
                                                        <td className="column-center">
                                                            {
                                                                x[1][0]?.stageStatus === EApprovelActions.COMPLETED ? <img src={approved} alt="" className="icon"></img> :
                                                                    x[1][0]?.stageStatus === EApprovelActions.FAILED ? <img src={Reject} alt="rejectLogo" /> : x[1][0]?.stageStatus === EApprovelActions.ACTIVE ? <img src={active} alt="" className="icon"></img> : x[1][0]?.stageStatus === EApprovelActions.PENDING ? <img src={pending} alt="pending" className="icon"></img> : ''
                                                            }
                                                        </td>
                                                    </tr>
                                                ))
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="pagination">
                        <button type='button' onClick={goBackToStudyPlan} className='btn blue-button'>{t('StudyPlan.back')}</button>
                    </div>
                </div>
            </React.Fragment>
        </>
    )
}

export default React.memo(StudyPlanStagesView);