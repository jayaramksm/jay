import React, { Component } from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, setResetStudyPlanStateRequest, getAllStudyPlanPredefinedRotationsDataStagesYearsHospitalsDataRequest, cancelAllPendingStudyPlanRequest } from '../../../../store/actions';
import { SuperParentContext } from './studyplancontext';
import {
    StudyPlanAction,
    StudyPlanParentManager,
    StudyPlanChartView,
    AddOrEditRotationInStudyPlan,
    StudyPlanStagesView,
    StudyPlanStagesRotationsView,
    StudyPlanView
} from './studyplanindex';

interface IProps {
    activateAuthLayout: any;
    cancelAllPendingStudyPlanRequest: any;
    setResetStudyPlanStateRequest: any;
    getAllStudyPlanPredefinedRotationsDataStagesYearsHospitalsDataRequest: any;
}

export class StudyPlan extends Component<IProps, any> {
    constructor(props) {
        super(props)

        this.state = {
            manager: {
                studyPlanActionComponent: StudyPlanAction,
                chartView: StudyPlanChartView,
                addorEditRotationsInStudyPlan: AddOrEditRotationInStudyPlan,
                studyPlanStagesView: StudyPlanStagesView,
                studyPlanStagesRotationsView: StudyPlanStagesRotationsView,
                studyPlanView: StudyPlanView
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getAllStudyPlanPredefinedRotationsDataStagesYearsHospitalsDataRequest();
    }

    componentWillUnmount() {
        this.props.setResetStudyPlanStateRequest();
        this.props.cancelAllPendingStudyPlanRequest();
    }

    render() {
        return (
            <>
                <SuperParentContext.Provider value={this.state.manager}>
                    <StudyPlanParentManager />
                </SuperParentContext.Provider>
            </>
        )
    }
}
export default connect(null, { activateAuthLayout, getAllStudyPlanPredefinedRotationsDataStagesYearsHospitalsDataRequest, cancelAllPendingStudyPlanRequest, setResetStudyPlanStateRequest })(StudyPlan);