import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    RotationalMeetingView, RotationalMeetingsListParent, RotationalMeetingsFilter,
    RotationalMeetingsListView, RotationalMeetingsAction, RotationalMeetingsManager
} from './rotationalmeetingsindex';
import { SuperParentContext } from './rotationalmeetingscontext';
import { activateAuthLayout } from '../../../../store/actions';
import { setResetRotationalMeetingsStateRequest, cancelAllRotationalMeetingsApiRequest, getAllRotationalMeetingsHodsAndRotationsAndRotationalSupervisorsDetailsRequest } from '../../../../store/actions';

interface IProps {
    activateAuthLayout: any;
    setResetRotationalMeetingsStateRequest: any;
    cancelAllRotationalMeetingsApiRequest: any;
    getAllRotationalMeetingsHodsAndRotationsAndRotationalSupervisorsDetailsRequest: any;
}

export class ClinicalMeetings extends Component<IProps, any> {
    constructor(props) {
        super(props)

        this.state = {
            manager: {
                rotationalMeetingsListParent: RotationalMeetingsListParent,
                rotationalMeetingsFilter: RotationalMeetingsFilter,
                rotationalMeetingView: RotationalMeetingView,
                rotationalMeetingsListView: RotationalMeetingsListView,
                rotationalMeetingsAction: RotationalMeetingsAction,
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetRotationalMeetingsStateRequest();
        this.props.getAllRotationalMeetingsHodsAndRotationsAndRotationalSupervisorsDetailsRequest();
    }
    componentWillUnmount() {
        this.props.setResetRotationalMeetingsStateRequest();
        this.props.cancelAllRotationalMeetingsApiRequest();
    }

    render() {
        return (
            <>
                <SuperParentContext.Provider value={this.state.manager}>
                    <RotationalMeetingsManager />
                </SuperParentContext.Provider>
            </>
        )
    }
}
export default connect(null, { activateAuthLayout, setResetRotationalMeetingsStateRequest, cancelAllRotationalMeetingsApiRequest, getAllRotationalMeetingsHodsAndRotationsAndRotationalSupervisorsDetailsRequest })(ClinicalMeetings);
