import React from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useTranslation } from 'react-i18next';
import { MySelect, defultContentValidate, customContentValidation, defultContentObjectValidate } from '../../../../helpers/helpersIndex';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import * as Yup from 'yup';
import { useSelector, useDispatch } from 'react-redux';
import groupBy from 'lodash/groupBy';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../../models/utilitiesModel';
import { EMeetingType, IClinicalMeetings, ICurrentDateAndTime, IHod, IRotationalSupervisors, IRotations } from '../../../../models/clinicalMeetingsModel';
import { getAddOrEditRotationalMeetingsRequest, setRotationalMeetingsActionTypeAndActionData, isFinalMeetingCheckBoxCheckedInRotationalMeeting } from '../../../../store/actions';
import maxBy from 'lodash/maxBy';
import moment from 'moment';

const RotationalMeetingsAction: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const hodsData: IHod[] = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.hodsData)
            return state.clinicalMeetingsReducer.hodsData
        else return []
    });

    const actionData: IClinicalMeetings = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.actionData)
            return state.clinicalMeetingsReducer.actionData
        else return undefined
    });

    const studyPlanRotationsData: IRotations[] = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.studyPlanRotationsData)
            return state.clinicalMeetingsReducer.studyPlanRotationsData?.filter(x => x.rotationStatus !== EApprovelActions.FAILED)
        else return []
    });


    const rotationalMeetings: IClinicalMeetings[] | undefined = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.allClinicalMeetingsData)
            return state.clinicalMeetingsReducer.allClinicalMeetingsData
        else return undefined;
    });

    let groupedRotationalMeetings = groupBy(rotationalMeetings, 'rotationId');

    let completedRotations = rotationalMeetings?.filter(x => (x.meetingType === EMeetingType.FinalMeeting));

    let rotationsOptions = studyPlanRotationsData?.reduce((totalRotations: any, rotation) => {
        if (completedRotations?.some(x => x.rotationId === rotation.rotationId))
            return [...totalRotations, { ...rotation, isDisabled: true }];
        else return [...totalRotations, rotation]
    }, [])

    const actionType: number = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.actionType)
            return state.clinicalMeetingsReducer.actionType
        else return EOprationalActions.UNSELECT;
    });

    const rotationalSupervisorsData: IRotationalSupervisors[] = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.rotationalSupervisorsData)
            return state.clinicalMeetingsReducer.rotationalSupervisorsData
        else return []
    });

    const currentDateTime: ICurrentDateAndTime = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.currentDateAndTime)
            return state.clinicalMeetingsReducer.currentDateAndTime
        else return undefined
    });


    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    const meetingTypeOptions = [
        { label: 'Initial Meeting', value: 'Initial Meeting', isdisabled: false },
        { label: 'Interim Meeting', value: 'Interim Meeting', isdisabled: false },
        { label: 'Final Meeting', value: 'Final Meeting', isdisabled: false }
    ]

    let hod = hodsData?.find(x => x.hodId === actionData?.hodId);
    // let stage = stageOptions?.find(x => x.value === actionData?.stage);
    // let rotationsOptions = groupedRotationsData?.[actionData?.stage];
    let rotation = studyPlanRotationsData?.find(x => x.rotationId === actionData?.rotationId);
    let firstRotationSupervisor = rotationalSupervisorsData?.find(x => x.userId === actionData?.firstRotationSupervisor?.supervisorId);
    let secondRotationSupervisor = rotationalSupervisorsData?.find(x => x.userId === actionData?.secondRotationSupervisor?.supervisorId);
    let meetingType = meetingTypeOptions?.find(x => x.value === actionData?.meetingType);

    const initialValues = () => ({
        rotationMeetingId: actionData ? actionData?.rotationalMeetingId : 0,
        hod: actionData ? hod : '',
        stage: actionData ? rotation?.rotationStageName : '-',
        rotation: actionData ? rotation : '',
        firstRotationalSupervisor: actionData ? firstRotationSupervisor : '',
        secondRotationalSupervisor: actionData ? secondRotationSupervisor : '',
        meetingType: actionData ? meetingType : '',
        isFinalMeeting: actionData ? actionData?.isFinalMeeting : false,
        meetingStartDate: actionData ? new Date(actionData?.meetingDateTime) : '',
        agreedNextMeetingDate: actionData ? new Date(actionData?.nextMeetingDate) : '',
        traineeRemarks: actionData ? actionData?.traineeComments : '',
        rotationsOptions: rotationsOptions ? rotationsOptions : '',
        hospitalName: actionData ? actionData?.hospitalName ? actionData.hospitalName : `Other-${actionData.otherHospitalName}` : '-',
        rotationDuration: actionData ? actionData?.rotationDuration : '-',
        meetingTypeOptions: meetingTypeOptions,
        isRotationLastMeetingApproved: true,
        isCurrentDateSelected: false
    });

    const validationSchema = Yup.object().shape({
        hod: defultContentValidate(t('controleErrors.required')),
        // stage: defultContentValidate(t('controleErrors.required')),
        rotation: defultContentValidate(t('controleErrors.required')),
        firstRotationalSupervisor: defultContentValidate(t('controleErrors.required')),
        meetingType: defultContentObjectValidate(t('controleErrors.required')),
        meetingStartDate: defultContentValidate(t('controleErrors.required')),
        agreedNextMeetingDate: Yup.string().when('meetingType', {
            is: (meetingType) => meetingType?.value !== EMeetingType.FinalMeeting,
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate(''),
        }),
        traineeRemarks: Yup.lazy((value) => {
            if (value) return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4)
            else return defultContentValidate('')
        }),
        isRotationLastMeetingApproved: Yup.boolean().oneOf([true], 'your Rotation Previous Meeting is not approved')
    });

    const firstRotationalSupervisorOptions = (values) => {
        return rotationalSupervisorsData?.filter(
            (user) => user.userId !== values.secondRotationalSupervisor?.userId
        );
    };

    const secondRotationalSupervisorOptions = (values) => {
        return rotationalSupervisorsData?.filter(
            (user) => user.userId !== values.firstRotationalSupervisor?.userId
        );
    };

    const selectRotation = async (e, values, setFieldValue) => {
        await setFieldValue('rotation', e ? e : '');

        let rotationalMeetings = groupedRotationalMeetings?.[e?.rotationId] || [];
        let lastCreatedMeeting: IClinicalMeetings = maxBy(rotationalMeetings, (data) => +(new Date(data.createdOn)));

        if (rotationalMeetings.length === 0) {
            await setFieldValue('isRotationLastMeetingApproved', true)
        }
        else if (lastCreatedMeeting?.firstRotationSupervisor?.status === EApprovelActions.APPROVED && (lastCreatedMeeting?.secondRotationSupervisor?.status ? lastCreatedMeeting?.secondRotationSupervisor?.status === EApprovelActions.APPROVED : true)) {
            await setFieldValue('isRotationLastMeetingApproved', true)
        }
        else {
            await setFieldValue('isRotationLastMeetingApproved', false)
        }

        let options = meetingTypeOptions.map(x => {
            if (rotationalMeetings.length === 0 && x.value === EMeetingType.InitialMeeting) {
                return { ...x, isdisabled: false }
            } else if (rotationalMeetings.length > 0 && x.value === EMeetingType.InterimMeeting && !rotationalMeetings.some(x => (x.isFinalMeeting))) {
                return { ...x, isdisabled: false }
            }
            else if (rotationalMeetings.length > 0 && x.value === EMeetingType.FinalMeeting && rotationalMeetings?.some(x => (x.meetingType === EMeetingType.InterimMeeting && x.isFinalMeeting))) {
                return { ...x, isdisabled: false }
            }
            else return { ...x, isdisabled: true }
        });
        await setFieldValue('meetingTypeOptions', options);

        setFieldValue('hospitalName', e ? e.hospitalName ? e.hospitalName : `Other-${e.otherHospitalName}` : '');
        setFieldValue('rotationDuration', e ? e.rotationDuration : '');
        setFieldValue('stage', e ? e.rotationStageName : '');

        await setFieldValue('meetingType', '');
        await setFieldValue('meetingStartDate', '');
        await setFieldValue('agreedNextMeetingDate', '');
        await setFieldValue('isFinalMeeting', false);
    }


    const handleCancle = () => {
        dispatch(setRotationalMeetingsActionTypeAndActionData(EOprationalActions.UNSELECT, null))
    }

    const selectCheckBox = (e, setFieldValue, values) => {
        if (values.isFinalMeeting) {
            setFieldValue('isFinalMeeting', e.target.checked);
        } else {
            console.log('checkboxtype=>', e.target.checked)
            let confirmMessage = { title: t('RotationalMeetings.confirmMessages.CMCM1'), subtitle: t('RotationalMeetings.confirmMessages.CMCM2') };
            dispatch(isFinalMeetingCheckBoxCheckedInRotationalMeeting(setFieldValue, false, confirmMessage));
        }
    }

    const selectStartDate = (e, setFieldValue) => {
        if (+new Date(moment(e).format('YYYY-MM-DD')) === +new Date(currentDateTime?.date)) {
            setFieldValue('isCurrentDateSelected', true);
            // console.log('currentDateSelected')
        } else {
            setFieldValue('isCurrentDateSelected', false);
            // console.log('currentDatenotSelected=>', moment(new Date()).set('h', 23), e, new Date(currentDateTime?.date), +new Date(e), +new Date(currentDateTime?.date))
        }
        setFieldValue('meetingStartDate', e);
    }

    return (
        <>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="maincontent pr-3">
                        <div className="breadcrumbs">
                            <span className="pointer" onClick={handleCancle}>{t('RotationalMeetings.clinicalMeetings')}</span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="active">
                                {actionType === EOprationalActions.EDIT ? t('RotationalMeetings.editMeeting') : t('RotationalMeetings.addMeeting')}
                            </span>
                        </div>

                        <Formik
                            initialValues={initialValues()}
                            validationSchema={validationSchema}
                            onSubmit={values => {
                                let requestType = actionType === EOprationalActions.ADD ? true : false
                                dispatch(getAddOrEditRotationalMeetingsRequest(requestType, values))
                                console.log('onSubmit==>', values, new Date(values.meetingStartDate).toLocaleDateString());
                            }}
                        >
                            {
                                ({ errors, touched, setFieldValue, setFieldTouched, values, dirty }) => {
                                    return <Form>

                                        <div className="top-section">
                                            <h2>{t('RotationalMeetings.programDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.programName')}</Label>
                                                            <Field name='programName' type="text" disabled value={userDto?.program?.programName} className='form-control' />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.educationalSupervisor')}</Label>
                                                            <Field name='educationalSupervisor' type="text" disabled value={userDto?.trainee?.esName} className='form-control' />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        {/* <FormGroup>
                                                <Label>{t('RotationalMeetings.headofTheDepartment')}</Label>
                                                <Input type="text" placeholder={t('RotationalMeetings.selectHod')} disabled value="Dr. Ramesh"></Input>
                                            </FormGroup> */}
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.headofTheDepartment')}</Label>
                                                            <MySelect
                                                                name="roles"
                                                                placeholder={t('RotationalMeetings.selectHod')}
                                                                isDisabled={false}
                                                                value={values.hod ? values.hod : ''}
                                                                onChange={(e) => { setFieldValue('hod', e ? e : ''); }}
                                                                options={hodsData ? hodsData : []}
                                                                getOptionLabel={option => option.hodFullName}
                                                                getOptionValue={option => option.hodId}
                                                                onBlur={() => setFieldTouched('hod', true)}
                                                                noOptionsMessage={() => t('RotationalMeetings.noDataFound')}
                                                            />
                                                            {errors.hod && touched.hod && (
                                                                <div className="text-danger">{errors.hod}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <hr />

                                        <div className="top-section">
                                            <h2>{t('RotationalMeetings.rotationDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.universityName')}</Label>
                                                            <Field name='universityName' type="text" placeholder={t('RotationalMeetings.universityName')} disabled value={userDto?.university?.universityName} className='form-control' />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.stage')}</Label>
                                                            <Field name='stage' type="text" placeholder={t('RotationalMeetings.stage')} disabled className='form-control' />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.rotation')}</Label>
                                                            <MySelect
                                                                name="rotation"
                                                                placeholder={t('RotationalMeetings.selectRotation')}
                                                                isDisabled={actionType === EOprationalActions.EDIT ? true : false}
                                                                value={values.rotation}
                                                                onChange={(e) => { selectRotation(e, values, setFieldValue) }}
                                                                options={values.rotationsOptions ? values.rotationsOptions : studyPlanRotationsData}
                                                                getOptionLabel={option => option.rotation}
                                                                getOptionValue={option => option.rotationId}
                                                                onBlur={() => { setFieldTouched('rotation', true); setFieldTouched('isRotationLastMeetingApproved', true) }}
                                                                noOptionsMessage={() => t('RotationalMeetings.noDataFound')}
                                                            />
                                                            {errors.rotation && touched.rotation && (
                                                                <div className="text-danger">{errors.rotation}</div>
                                                            )}
                                                            {errors.isRotationLastMeetingApproved && touched.isRotationLastMeetingApproved && (
                                                                <div className="text-danger">{errors.isRotationLastMeetingApproved}</div>
                                                            )}
                                                            {/* {JSON.stringify(errors)} */}
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.hospitalName')} </Label>
                                                            <Field type="text" name='hospitalName' placeholder={t('RotationalMeetings.hospitalName')} disabled className='form-control' />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.rotationDuration')}</Label>
                                                            <Field type="text" name='rotationDuration' placeholder={t('RotationalMeetings.rotationDuration')} disabled className='form-control' />
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <hr />

                                        <div className="top-section">
                                            <h2>{t('RotationalMeetings.supervisorDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.firstRotationalSupervisor')}</Label>
                                                            <MySelect
                                                                name="rotation"
                                                                placeholder={t('RotationalMeetings.selectRotationalSupervisor')}
                                                                isDisabled={false}
                                                                value={values.firstRotationalSupervisor ? values.firstRotationalSupervisor : ''}
                                                                onChange={(e) => { setFieldValue('firstRotationalSupervisor', e ? e : ''); }}
                                                                options={firstRotationalSupervisorOptions(values) || []}
                                                                getOptionLabel={option => option.userFullName}
                                                                getOptionValue={option => option.userId}
                                                                onBlur={() => setFieldTouched('firstRotationalSupervisor', true)}
                                                                noOptionsMessage={() => t('RotationalMeetings.noDataFound')}
                                                            />
                                                            {errors.firstRotationalSupervisor && touched.firstRotationalSupervisor && (
                                                                <div className="text-danger">{errors.firstRotationalSupervisor}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.secondRotationalSupervisor')}</Label>
                                                            <MySelect
                                                                name="rotation"
                                                                placeholder={t('RotationalMeetings.selectRotationalSupervisor')}
                                                                isDisabled={false}
                                                                value={values.secondRotationalSupervisor ? values.secondRotationalSupervisor : ''}
                                                                onChange={(e) => { setFieldValue('secondRotationalSupervisor', e ? e : ''); }}
                                                                options={secondRotationalSupervisorOptions(values) || []}
                                                                isClearable={true}
                                                                getOptionLabel={option => option.userFullName}
                                                                getOptionValue={option => option.userId}
                                                                onBlur={() => setFieldTouched('secondRotationalSupervisor', true)}
                                                                noOptionsMessage={() => t('RotationalMeetings.noDataFound')}
                                                            />
                                                            {errors.secondRotationalSupervisor && touched.secondRotationalSupervisor && (
                                                                <div className="text-danger">{errors.secondRotationalSupervisor}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <hr />
                                        <div className="top-section">
                                            <h2>{t('RotationalMeetings.meetingDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm='4'>
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.meetingType')}</Label>
                                                            <MySelect
                                                                name="rotation"
                                                                placeholder={t('RotationalMeetings.selectMeetingType')}
                                                                isDisabled={actionType === EOprationalActions.EDIT ? true : false}
                                                                value={values.meetingType ? values.meetingType : ''}
                                                                onChange={(e) => { setFieldValue('meetingType', e ? e : ''); }}
                                                                options={values.meetingTypeOptions ? values.meetingTypeOptions : []}
                                                                getOptionLabel={option => option.label}
                                                                getOptionValue={option => option.value}
                                                                onBlur={() => setFieldTouched('meetingType', true)}
                                                                isOptionDisabled={(option) => option.isdisabled}
                                                                noOptionsMessage={() => t('RotationalMeetings.noDataFound')}
                                                            />
                                                            {errors.meetingType && touched.meetingType && (
                                                                <div className="text-danger">{errors.meetingType}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.meetingStartDate')}</Label>
                                                            <DatePicker placeholderText={t('RotationalMeetings.meetingStartDate')} className="w100 datepickerIcon form-control" name="meetingStartDate"
                                                                popperPlacement="top"
                                                                popperModifiers={{
                                                                    flip: {
                                                                        behavior: ["top"]
                                                                    },
                                                                    preventOverflow: {
                                                                        enabled: false
                                                                    }
                                                                }}
                                                                autoComplete="off"
                                                                selected={values.meetingStartDate || ''}
                                                                onChange={(e) => selectStartDate(e, setFieldValue)}
                                                                onSelect={(e) => { console.log('onSelectIsfiring=>', e) }}
                                                                timeIntervals='1'
                                                                showTimeSelect
                                                                dateFormat='dd-MM-yyyy h:mm aa'
                                                                maxDate={new Date()}
                                                                maxTime={values.isCurrentDateSelected ? new Date() : new Date().setHours(23, 59, 59)}
                                                                minTime={new Date().setHours(23, 59, 60)}
                                                                onBlur={() => setFieldTouched('meetingStartDate', true)}
                                                                showMonthDropdown
                                                                showYearDropdown
                                                                dropdownMode="select"
                                                            />
                                                            {errors.meetingStartDate && touched.meetingStartDate && (
                                                                <div className="text-danger">{errors.meetingStartDate}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                    {(values.meetingType as any).value !== EMeetingType.FinalMeeting && <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.agreedNextMeetingDate')}</Label>
                                                            <DatePicker placeholderText={t('RotationalMeetings.agreedNextMeetingDate')} className="w100 datepickerIcon form-control" name="agreedNextMeetingDate"
                                                                popperPlacement="top"
                                                                popperModifiers={{
                                                                    flip: {
                                                                        behavior: ["top"]
                                                                    },
                                                                    preventOverflow: {
                                                                        enabled: false
                                                                    }
                                                                }}
                                                                autoComplete="off"
                                                                selected={values.agreedNextMeetingDate || ''}
                                                                onChange={(e) => { setFieldValue('agreedNextMeetingDate', e) }}
                                                                dateFormat={'dd-MM-yyyy'}
                                                                minDate={new Date()}
                                                                // maxDate={''}
                                                                onBlur={() => setFieldTouched('agreedNextMeetingDate', true)}
                                                                showMonthDropdown
                                                                showYearDropdown
                                                                dropdownMode="select"
                                                            />
                                                            {errors.agreedNextMeetingDate && touched.agreedNextMeetingDate && (
                                                                <div className="text-danger">{errors.agreedNextMeetingDate}</div>
                                                            )}
                                                            {
                                                                <div className="mt-2 mb-1">
                                                                    {/* <Label>{t('RotationalMeetings.finalMeeting')}</Label> */}
                                                                    {values.meetingType && (values.meetingType as any).value === EMeetingType.InterimMeeting && <> <Field type="checkbox" name='isFinalMeeting' onChange={(e) => selectCheckBox(e, setFieldValue, values)} />{t('RotationalMeetings.isthisFinalMeeting')}</>}
                                                                </div>}
                                                            <span className="text-danger">Note : </span><span> {t('RotationalMeetings.agreedMeetingNote')}</span>
                                                        </FormGroup>
                                                    </Col>}
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('RotationalMeetings.traineeRemarks')}</Label>
                                                            <Field as='textarea' name='traineeRemarks' placeholder={t('RotationalMeetings.writeDownHere')} className="comments" rows={1} />
                                                            <ErrorMessage name='traineeRemarks' component='div' className='text-danger' />
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <Row className="sub-form-footer my-3 mr-5">
                                            <button className="btn cancel-button" type='button' onClick={handleCancle}>{t('ActionNames.cancel')}</button>
                                            <button className="btn blue-button" type='submit' disabled={actionType === EOprationalActions.EDIT ? !dirty : false}>{
                                                actionType === EOprationalActions.EDIT ? t('ActionNames.update') : t('ActionNames.submit')
                                            }</button>
                                        </Row>
                                    </Form>
                                }
                            }
                        </Formik>
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(RotationalMeetingsAction);
