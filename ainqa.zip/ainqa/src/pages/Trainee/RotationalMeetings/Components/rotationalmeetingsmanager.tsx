import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/rotationalmeetingscontext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IstudyPlanStaus } from '../../../../models/clinicalMeetingsModel';


const RotationalMeetingsManager: React.FC = () => {

    const context = useContext(SuperParentContext);

    const actionType: number = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.actionType)
            return state.clinicalMeetingsReducer.actionType
        else return EOprationalActions.UNSELECT
    })

    const studyPlanStatus: IstudyPlanStaus | undefined = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.studyPlanstatus)
            return state.clinicalMeetingsReducer.studyPlanstatus
        else return undefined
    })


    return (
        <>
            {studyPlanStatus && studyPlanStatus?.status ? <React.Fragment>
                {actionType === EOprationalActions.UNSELECT && <div className="flexLayout">
                    <context.rotationalMeetingsFilter />
                    <context.rotationalMeetingsListParent />
                </div>}
                {(actionType === EOprationalActions.ADD || actionType === EOprationalActions.EDIT) && <context.rotationalMeetingsAction />}
                {actionType === EOprationalActions.SELECT && <context.rotationalMeetingView />}
            </React.Fragment> : <div className='text-danger'>{studyPlanStatus?.messages}</div>
            }
        </>
    )
}

export default React.memo(RotationalMeetingsManager)
