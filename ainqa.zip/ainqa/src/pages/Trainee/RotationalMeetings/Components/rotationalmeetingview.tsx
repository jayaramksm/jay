import React from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { EMeetingType, IClinicalMeetings } from '../../../../models/clinicalMeetingsModel';
import { EOprationalActions, IUserDetails } from '../../../../models/utilitiesModel';
import { setRotationalMeetingsActionTypeAndActionData } from '../../../../store/actions';


const RotationalMeetingView: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionData: IClinicalMeetings = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.actionData)
            return state.clinicalMeetingsReducer.actionData
        else return undefined
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    const goBackToMeetings = () => {
        dispatch(setRotationalMeetingsActionTypeAndActionData(EOprationalActions.UNSELECT, null))
    }

    return (
        <>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="maincontent pr-3">
                        <div className="breadcrumbs">
                            <span  className="pointer" onClick={goBackToMeetings}>{t('RotationalMeetings.clinicalMeetings')}</span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="active">
                                {t('ActionNames.view')}
                            </span>
                        </div>

                        <div className="top-section">
                            <h2>{t('RotationalMeetings.programDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.programName')}</Label>
                                            <Input name='programName' type="text" disabled value={actionData?.programName || '-'} className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.educationalSupervisor')}</Label>
                                            <Input name='educationalSupervisor' value={actionData?.esName || '-'} type="text" disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        {/* <FormGroup>
                                                <Label>{t('RotationalMeetings.headofTheDepartment')}</Label>
                                                <Input type="text" placeholder={t('RotationalMeetings.selectHod')} disabled value="Dr. Ramesh"></Input>
                                            </FormGroup> */}
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.headofTheDepartment')}</Label>
                                            <Input value={actionData?.hodName || '-'} type="text" disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />

                        <div className="top-section">
                            <h2>{t('RotationalMeetings.rotationDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.universityName')}</Label>
                                            <Input name='universityName' value={userDto?.university?.universityName || '-'} type="text" placeholder={t('RotationalMeetings.universityName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.stage')}</Label>
                                            <Input name='stage' value={actionData?.stage || '-'} type="text" placeholder={t('RotationalMeetings.universityName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.rotation')}</Label>
                                            <Input name='rotation' value={actionData?.rotationName || '-'} type="text" placeholder={t('RotationalMeetings.universityName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.hospitalName')} </Label>
                                            <Input type="text" name='hospitalName' value={actionData?.hospitalName ? actionData?.hospitalName : ''} placeholder={t('RotationalMeetings.hospitalName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.rotationDuration')}</Label>
                                            <Input type="text" name='rotationDuration' value={actionData?.rotationDuration || '-'} placeholder={t('RotationalMeetings.rotationDuration')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />

                        <div className="top-section">
                            <h2>{t('RotationalMeetings.supervisorDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.firstRotationalSupervisor')}</Label>
                                            <Input type="text" name='firstRotationalSupervisor' value={actionData?.firstRotationSupervisor?.supervisorName || '-'} placeholder={t('RotationalMeetings.firstRotationalSupervisor')} disabled className='form-control' />

                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.secondRotationalSupervisor')}</Label>
                                            <Input type="text" name='secondRotationalSupervisor' value={actionData?.secondRotationSupervisor?.supervisorName || '-'} placeholder={t('RotationalMeetings.secondRotationalSupervisor')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <h2>{t('RotationalMeetings.meetingDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm='4'>
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.meetingType')}</Label>
                                            <Input type="text" name='meetingType' value={actionData?.meetingType || '-'} placeholder={t('RotationalMeetings.meetingType')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.meetingDateandTime')}</Label>
                                            <Input type="text" name='meetingStartDate' value={actionData?.meetingDateTime || '-'} placeholder={t('RotationalMeetings.meetingStartDate')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    {actionData?.meetingType !== EMeetingType.FinalMeeting && <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.agreedNextMeetingDate')}</Label>
                                            <Input type="text" name='agreedNextMeetingDate' value={actionData?.nextMeetingDate || '-'} placeholder={t('RotationalMeetings.agreedNextMeetingDate')} disabled className='form-control' />
                                            {actionData?.meetingType === EMeetingType.InterimMeeting && <div className="mt-2 ml-3">
                                                {/* <Label>{t('RotationalMeetings.finalMeeting')}</Label> */}
                                                <Input type="checkbox" checked={actionData?.isFinalMeeting} disabled name='isFinalMeeting' />{t('RotationalMeetings.isthisFinalMeeting')}
                                            </div>}
                                        </FormGroup>
                                    </Col>}
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.traineeRemarks')}</Label>
                                            <Input as='textarea' name='traineeRemarks' disabled value={actionData?.traineeComments || '-'} placeholder={t('RotationalMeetings.writeDownHere')} className="comments" rows={1} />
                                            {/* <ErrorMessage name='traineeRemarks' component='div' className='text-danger' /> */}
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <div className="details-section">
                                <Row className="vhcenter">
                                    <Col sm="6" xs="12">
                                        <h2>{t('RotationalMeetings.firstRotationalSupervisor')}</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate">{t('RotationalMeetings.approvedOn')} : <span className="date">{actionData?.firstRotationSupervisor?.approvedOn || '-'}</span></span>
                                    </Col>
                                </Row>
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.approvalStatus')}</Label>
                                            <Input type="text" name='approvalStatus' value={actionData?.firstRotationSupervisor?.status || '-'} placeholder={t('RotationalMeetings.approvalStatus')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.remarks')}</Label>
                                            <Input as='textarea' name='remarks' disabled value={actionData?.firstRotationSupervisor?.comments || '-'} placeholder={t('RotationalMeetings.writeDownHere')} className="comments" rows={1} />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <div className="details-section">
                                <Row className="vhcenter">
                                    <Col sm="6" xs="12">
                                        <h2>{t('RotationalMeetings.secondRotationalSupervisor')}</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate">{t('RotationalMeetings.approvedOn')} : <span className="date">{actionData?.secondRotationSupervisor?.approvedOn || '-'}</span></span>
                                    </Col>
                                </Row>
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.approvalStatus')}</Label>
                                            <Input type="text" name='approvalStatus' value={actionData?.secondRotationSupervisor?.status || '-'} placeholder={t('RotationalMeetings.approvalStatus')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('RotationalMeetings.remarks')}</Label>
                                            <Input as='textarea' name='remarks' disabled value={actionData?.secondRotationSupervisor?.comments || '-'} placeholder={t('RotationalMeetings.writeDownHere')} className="comments" rows={1} />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <Row className="sub-form-footer my-3 mr-5">
                            <button className="btn blue-button mr-3" type='button' onClick={goBackToMeetings}>{t('RotationalMeetings.back')}</button>
                        </Row>

                    </div>
                </div>
            </div>


        </>
    )
}

export default React.memo(RotationalMeetingView)
