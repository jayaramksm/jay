import React, { useContext } from 'react';
import approved from '../../../../images/Approved.svg';
import pending from '../../../../images/Pending.svg';
import Rejected from '../../../../images/Reject.svg';
import View from '../../../../images/View.svg';
import EditIcon from '../../../../images/Edit.svg';
import { IClinicalMeetings } from '../../../../models/clinicalMeetingsModel';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext } from '../Container/rotationalmeetingscontext';
import { EApprovelActions, EOprationalActions } from '../../../../models/utilitiesModel';
import { setRotationalMeetingsActionTypeAndActionData } from '../../../../store/actions';


const RotationalMeetingsListView: React.FC = () => {

    const context = useContext(ParentContext);
    const dispatch = useDispatch();

    const rotationalMeetings: IClinicalMeetings = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.allClinicalMeetingsData)
            return state.clinicalMeetingsReducer.allClinicalMeetingsData?.find(x => x.rotationalMeetingId === context);
        else return undefined;
    });

    const editMeeting = () => {
        dispatch(setRotationalMeetingsActionTypeAndActionData(EOprationalActions.EDIT, rotationalMeetings))
    };

    const viewMeeting = () => {
        dispatch(setRotationalMeetingsActionTypeAndActionData(EOprationalActions.SELECT, rotationalMeetings))
    }

    const showRotationalMeetingEdit = (rotationalMeetings?.firstRotationSupervisor?.status !== EApprovelActions.APPROVED ||
        rotationalMeetings?.secondRotationSupervisor?.status === EApprovelActions.REJECTED) &&
        ((rotationalMeetings?.secondRotationSupervisor?.status ? rotationalMeetings?.secondRotationSupervisor?.status !== EApprovelActions.APPROVED : true) ||
            rotationalMeetings?.firstRotationSupervisor?.status === EApprovelActions.REJECTED);

    return (
        <>
            {rotationalMeetings && <tr>
                <td>{rotationalMeetings.stage}</td>
                <td>{rotationalMeetings.rotationName}</td>
                <td>{rotationalMeetings.firstRotationSupervisor?.supervisorName || '-'}</td>
                <td className="text-center">
                    {rotationalMeetings.firstRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={approved} alt="approved" /> :
                        rotationalMeetings.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} alt='rejected' /> :
                            rotationalMeetings.firstRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={pending} alt="" /> : '-'
                    }
                </td>
                <td>{rotationalMeetings.secondRotationSupervisor?.supervisorName || '-'}</td>
                <td className="text-center">
                    {rotationalMeetings.secondRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={approved} alt="approved" /> :
                        rotationalMeetings.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} alt='rejected' /> :
                            rotationalMeetings.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={pending} alt="" /> : '-'
                    }
                </td>
                <td>{rotationalMeetings.meetingType}</td>
                <td>{rotationalMeetings.meetingDateTime}</td>
                <td className="ActionStatus">
                    <img src={View} onClick={viewMeeting} alt="View Icon" className="actionicon pointer" />
                    {showRotationalMeetingEdit && <img src={EditIcon} alt="edit Icon" onClick={editMeeting} className="actionicon pointer" />}
                </td>
            </tr>}
        </>
    )
}

export default React.memo(RotationalMeetingsListView)
