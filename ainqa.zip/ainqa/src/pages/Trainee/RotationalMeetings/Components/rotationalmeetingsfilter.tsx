import React from 'react';
import { Row, Col } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import { setRotationalMeetingsActionTypeAndActionData, setSearchKeyInRotationalMeetingsRequest } from '../../../../store/actions';
import { EOprationalActions } from '../../../../models/utilitiesModel';

const RotationalMeetingsFilter: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const addClinicalMeeting = () => {
        dispatch(setRotationalMeetingsActionTypeAndActionData(EOprationalActions.ADD, null))
    }

    const setSearchKey = e => {
        dispatch(setSearchKeyInRotationalMeetingsRequest(e.target.value))
    }

    return (
        <>
            <Row className="compHeading">
                <Col>
                    <h2>{t('RotationalMeetings.clinicalMeetings')}</h2>
                </Col>
                <div className="rgtFilter pr-3">
                    <div className="search-box filtericon">
                        <div className="search-text"><input type="text" onChange={setSearchKey} placeholder={t('RotationalMeetings.search')}></input><i className="ti-search icon"></i></div>
                    </div>
                    <button className="addnewButn" id='rlaTooltipExample' onClick={addClinicalMeeting}><i className="ti-plus"></i> {t('RotationalMeetings.addMeeting')}</button>
                </div>
            </Row>
        </>
    )
}

export default React.memo(RotationalMeetingsFilter)
