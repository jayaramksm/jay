import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/rotationalmeetingscontext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { IClinicalMeetings } from '../../../../models/clinicalMeetingsModel';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setRotationalMeetingsPaginationCurrentPageValue } from '../../../../store/actions';



const RotationalMeetingsListParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const rotationalMeetings: IClinicalMeetings[] | undefined = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.allClinicalMeetingsData)
            return state.clinicalMeetingsReducer.allClinicalMeetingsData.sort(function (a, b) {
                var c: any = new Date(a.createdOn);
                var d: any = new Date(b.createdOn);
                return d - c;
            });
        else return undefined;
    });


    const searchKey: string = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.searchkey)
            return state.clinicalMeetingsReducer.searchkey;
        else return '';
    });
    const currentPage: number = useSelector((state: any) => {
        if (state?.clinicalMeetingsReducer?.paginationCurrentPage)
            return state.clinicalMeetingsReducer.paginationCurrentPage;
        else return 0;
    });


    const rotationalMeetingsFilterData: any = (rotationalMeetings?.length && searchKey !== '') ? rotationalMeetings?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : rotationalMeetings;

    let pagesCount: number = Math.ceil((rotationalMeetingsFilterData ? rotationalMeetingsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setRotationalMeetingsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setRotationalMeetingsPaginationCurrentPageValue(index));
    };

    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <div className="tbl-parent table-responsive">
                        <table className="myTable rmtable table">
                            <thead>
                                <tr>
                                    <th>{t('RotationalMeetings.stage')}</th>
                                    <th>{t('RotationalMeetings.rotation')}</th>
                                    <th>{t('RotationalMeetings.firstRotationalSupervisor')}</th>
                                    <th className="text-center">{t('RotationalMeetings.approvalStatus')}</th>
                                    <th>{t('RotationalMeetings.secondRotationalSupervisor')}</th>
                                    <th className="text-center">{t('RotationalMeetings.approvalStatus')}</th>
                                    <th>{t('RotationalMeetings.meetingType')}</th>
                                    <th>{t('RotationalMeetings.meetingDateandTime')}</th>
                                    <th>{t('RotationalMeetings.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    rotationalMeetings && rotationalMeetingsFilterData.length > 0 && rotationalMeetingsFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x: IClinicalMeetings, ind) => (
                                        <ParentContext.Provider value={x.rotationalMeetingId} key={x.rotationalMeetingId}>
                                            <context.rotationalMeetingsListView />
                                        </ParentContext.Provider>
                                    ))
                                }
                            </tbody>
                        </table>
                        {rotationalMeetings && (rotationalMeetingsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('RotationalMeetings.noDataFound')}</h6></div>}
                    </div>
                    {rotationalMeetingsFilterData && rotationalMeetingsFilterData.length > pageSize &&
                        <div className="pagination">
                            <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                        </div>
                    }
                </div>
            </div>
        </>
    )
}

export default React.memo(RotationalMeetingsListParent)
