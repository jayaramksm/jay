import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/glaContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { IGla, IGlasModel } from '../../../../models/glasModel';
import { setGlaPaginationCurrentPageValue, setGlasActionTypeData } from '../../../../store/actions';
import { EOprationalActions, IUserDetails } from '../../../../models/utilitiesModel';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { EPathwayTags } from '../../../../models/userManagementModel';
import { Row, Col } from 'reactstrap';

const GlasViewManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const { t } = useTranslation('translations');

    const glasData: IGla[] | any = useSelector((state: any) => {
        if (state?.glasReducer?.glasData)
            return (state.glasReducer as IGlasModel)?.glasData;
        else return undefined;
    });

    const addGla = () => {
        dispatch(setGlasActionTypeData(EOprationalActions.ADD, null));
    };

    const currentPage: number = useSelector((state: any) => {
        if (state?.glasReducer?.paginationCurrentPage)
            return (state.glasReducer as IGlasModel).paginationCurrentPage;
        else return 0;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return {};
    })

    let pagesCount: number = Math.ceil((glasData ? glasData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setGlaPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setGlaPaginationCurrentPageValue(index));
    };

    const selectedPathwayTag = userDto?.trainee?.pathwayTag || '';
    console.log("glasmanager==>", glasData, context);

    return (

        <div className="maincontent flexLayout pr-0">
            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title">{t('Gla.generalLearningAgreements')}</h3>
                </Col>
            </Row>

            {glasData?.length === 0 && <div onClick={addGla} className="add-button" >
                <div className="button-text"> {t('Gla.addGeneralLearningAgreement')}</div>
                <div className="note"> {t('Gla.PleaseAddagreement')}</div>
            </div>}

            {glasData?.length > 0 && <div className="flexLayout">
                <div className="flexScroll">
                    <div className="main-table">
                        <div className="tbl-parent table-responsive mr-3">
                            <table className="myTable genl-agreements-table table">
                                <thead>
                                    <tr>
                                        <th>{t('Gla.agreementDate')}</th>
                                        <th> {t('Gla.eduSupervisorName')}</th>
                                        <th className="column-center">{t('Gla.approvalStatus')}</th>
                                        <th>{selectedPathwayTag === EPathwayTags.CLOSED ? t('Gla.coeducationalSupervisor') : t('Gla.mOHSupervisorName')}</th>
                                        <th className="column-center">{t('Gla.approvalStatus')}</th>
                                        <th> {t('Gla.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {glasData && glasData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((gla) => (
                                        <ParentContext.Provider value={gla.glaId} key={gla.glaId}>
                                            <context.glasViewComponent />
                                        </ParentContext.Provider>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        {(glasData && glasData?.length === 0) && <div className="norecordsfound"><h6>{t('Gla.noDataFound')}</h6></div>}
                        {glasData && glasData.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>}
                    </div>
                </div></div>}
        </div>

    )
}
export default React.memo(GlasViewManager);