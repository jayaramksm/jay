import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/glaContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IGlasModel } from '../../../../models/glasModel';

const GlaParentManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const isGlasListActionType = useSelector((state: any) => {
        if (state?.glasReducer)
            return (state.glasReducer as IGlasModel)?.actionType === EOprationalActions.UNSELECT;
        else return false;
    });
    return (
        <>
            {isGlasListActionType ? <context.glasViewManager /> : <context.glaAction />}
        </>
    )
}
export default React.memo(GlaParentManager);