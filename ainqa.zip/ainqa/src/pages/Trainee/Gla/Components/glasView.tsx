import React, { useContext } from 'react';
import { ParentContext } from '../Container/glaContext';
import EditIcon from '../../../../images/Edit.svg';
import { EApprovelActions, EOprationalActions } from 'models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import Approved from '../../../../images/Approved.svg';
import pending from '../../../../images/Pending.svg';
import reject from '../../../../images/Reject.svg';
import View from '../../../../images/View.svg';
import { EActiveStatus, IGla, IGlasModel } from '../../../../models/glasModel';
import { isEditGlasRequest, setGlasActionTypeData } from '../../../../store/actions';
import Replace from '../../../../images/Replace.svg';

const GlasView: React.FC = () => {
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);


    const glasData: IGla | any = useSelector((state: any) => {
        if (state?.glasReducer?.glasData?.length) {
            let glasData = (state.glasReducer as IGlasModel).glasData;
            return glasData.find(gla => gla.glaId === context);
        } else
            return undefined;
    });
    const editGla = () => {
        dispatch(setGlasActionTypeData(EOprationalActions.EDIT, glasData));
        dispatch(isEditGlasRequest(glasData?.glaId, true));

    };
    const ViewGla = () => {
        dispatch(setGlasActionTypeData(EOprationalActions.SELECT, glasData));
    };
    const replaceGla = () => {
        dispatch(setGlasActionTypeData(EOprationalActions.REPLACE, glasData));
    };
    const showGlaEdit = ((glasData?.esStatus !== EApprovelActions.APPROVED || glasData?.mohStatus === EApprovelActions.REJECTED) && ((glasData?.mohStatus ? (glasData?.mohStatus !== EApprovelActions.APPROVED) : true) || glasData?.esStatus === EApprovelActions.REJECTED));
    const showGlaReplace = glasData?.esStatus !== EApprovelActions.PENDING && (glasData?.mohStatus ? (glasData?.mohStatus !== EApprovelActions.PENDING) : true);

    console.log("GlasView==>", { glasData, showGlaEdit, status: glasData?.status });

    return (
        <>
            <tr>
                <td>{glasData?.agreementDate}</td>
                <td>{glasData?.esUserName}</td>
                <td className="column-center"> {(glasData?.esStatus === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (glasData?.esStatus === EApprovelActions.PENDING ? <img src={pending} className="icon" alt="" /> : glasData?.esStatus === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "")}</td>
                <td>{glasData?.mohUserName || '-'}</td>
                <td className="column-center">{glasData?.mohStatus ? (glasData?.mohStatus === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (glasData?.mohStatus === EApprovelActions.PENDING ? <img src={pending} className="icon" alt="" /> : glasData?.mohStatus === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-'}</td>
                <td>
                    <span><img onClick={ViewGla} src={View} className="actionicon pointer" alt="View" /></span>
                    {glasData?.status === EActiveStatus.TRUE && <>{showGlaReplace && <span><img src={Replace} onClick={replaceGla} className="actionicon pointer" alt="Replace" /></span>}
                        <span><img src={EditIcon} onClick={editGla} className="actionicon pointer" alt="Edit" /></span>
                    </>}
                </td>
            </tr>

        </>

    )
}
export default React.memo(GlasView);