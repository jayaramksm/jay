import React from 'react'
import { alertActionRequest, createOrEditOrReplaceGlasRequest, isEditGlasRequest, setGlasActionTypeData } from '../../../../store/actions';
import { EOprationalActions, ERoleDesc, EStatusEnum, IUserDetails } from '../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, ValueContainer, Option, customContentValidation } from '../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { Row, Col, Label, FormGroup, Input, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { IGla, IGlasModel, IUser } from '../../../../models/glasModel';
import { EPathwayTags } from '../../../../models/userManagementModel';


const CommunicationOptions = [
    { value: 'Email', label: 'Email' },
    { value: 'Phone', label: 'Phone' },
    { value: 'Skype', label: 'Skype' },
    { value: 'Teams', label: 'Teams' },
    { value: 'Video', label: 'Video' }
];

const periodOptions = [{ value: 'Daily', label: 'Daily' },
{ value: 'Weekly', label: 'Weekly' },
{ value: 'Fortnightly', label: 'Fortnightly' },
{ value: 'Monthly', label: 'Monthly' },
{ value: 'Bi-Monthly', label: 'Bi-Monthly' },
{ value: 'Quarterly', label: 'Quarterly' },
{ value: 'Half-yearly', label: 'Half-yearly' }
];

const GlaAction: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionType = useSelector((state: any) => {
        if (state?.glasReducer?.actionType) {
            return (state.glasReducer as IGlasModel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const actionData: IGla = useSelector((state: any) => {
        if (state?.glasReducer?.actionData) {
            return (state.glasReducer as IGlasModel).actionData
        } else {
            return undefined
        }
    });

    const supervisorsData: IUser[] | any = useSelector((state: any) => {
        if (state?.glasReducer?.usersDta) {
            return (state.glasReducer as IGlasModel).usersDta
        } else {
            return undefined
        }
    });


    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return {};
    });



    let formatLabel


    const getEdSupervisorOptions = (values) => {
        const selectedCoedSupervisor = values?.coeducationalSupervisor?.userId || '';
        return supervisorsData?.filter(user => user.userType === ERoleDesc.EDUCATIONALSUPERVISOR && user.userId !== selectedCoedSupervisor);
    }


    const getCoEdSupervisorOptions = (values) => {
        const selectedPathwayTag = userDto?.trainee?.pathwayTag || '';
        const selectededSupervisor = values?.educationalSupervisor?.userId || '';

        if (selectedPathwayTag) {
            if (selectedPathwayTag === EPathwayTags.CLOSED)
                return getEdSupervisorOptions(values)?.filter(user => user.userId != selectededSupervisor);
            else if (selectedPathwayTag === EPathwayTags.OPEN || selectedPathwayTag === EPathwayTags.HYBRID)
                return supervisorsData?.filter(user => user.userType === ERoleDesc.MOHSUPERVISOR);
            else return [];
        }
        else return [];
    };


    const formatGroupByShowOrNot = (value) => {
        let groupLabel = value ? 'formatGroupLabel' : '';
        formatLabel = {
            [groupLabel]: option => option.glabel
        }
        return formatLabel;
    }
    const patchCommunications = () => {
        const communication = actionData.communication?.split(',');
        let communicationdata = CommunicationOptions.filter(x => communication?.findIndex(y => y === x.value) !== -1);
        if (communicationdata?.length === CommunicationOptions?.length)
            communicationdata.unshift({ label: "Select All", value: "" });
        return communicationdata;
    }

    const initialValues = () => ({
        agreedperiod: actionData ? periodOptions.find(x => x.value === actionData?.period) : "",
        Communication: actionData ? patchCommunications() : [],
        educationalSupervisor: actionData ? supervisorsData?.find(x => x.userId === actionData?.esId) : supervisorsData?.find(x => x.userId === userDto?.trainee?.educationalSupervisor),
        coeducationalSupervisor: actionData ? supervisorsData?.find(x => x.userId === actionData?.mohId) : supervisorsData?.find(x => x.userId === userDto?.trainee?.coEducationalSupervisor),
        check: false,
        glaId: actionData ? actionData.glaId : '',
        matricNumber: actionData ? actionData?.matricNumber : "",
        trainee: userDto?.trainee,
        oldEsId: actionData?.esId,
        oldMohId: actionData?.mohId

    });
    const validationSchema = Yup.object().shape({
        educationalSupervisor: defultContentValidate(t('controleErrors.required')),
        agreedperiod: defultContentValidate(t('controleErrors.required')),
        Communication: defultContentValidate(t('controleErrors.required')),
        check: (actionType !== EOprationalActions.SELECT) ? Yup.boolean().oneOf([true], t('controleErrors.required')) : defultContentValidate(''),
        matricNumber: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 20, 3),

        coeducationalSupervisor: Yup.string().when('trainee', {
            is: (trainee) => (trainee?.trMohUser === EStatusEnum?.NACTIVE_STR && trainee?.pathwayTag === EPathwayTags.OPEN),
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        })
    });

    const cancel = () => {
        if (actionType === EOprationalActions.EDIT)
            dispatch(isEditGlasRequest(actionData.glaId, false));
        dispatch(setGlasActionTypeData(EOprationalActions.UNSELECT, null));
    };

    console.log("GlaAddOrEditAgreement==>", { userDto, actionData, supervisorsData, actionType }, actionData?.communication?.split(','));

    return (

        <>

            <Modal className="modal-lg glamodal" isOpen={true} style={{ margin: "0 auto" }}>
                <ModalHeader style={{ position: "sticky", top: 0, zIndex: 3, background: "#ffffff", borderRadius: "0" }}>
                    <div className="text-center"> {t('Gla.learningAgreementForAcademicSupervision')}</div>
                    <div className="modal-close"><button className="btn btn-danger" onClick={cancel}><i className="ti-close"></i></button></div>
                </ModalHeader>
                <ModalBody>
                    <div className="px-4">
                        <h6> {t('Gla.thisLatterofUndertakingDefinesTheRelationshipBetween')}</h6>

                        <Formik
                            enableReinitialize
                            initialValues={initialValues()}
                            validationSchema={validationSchema}
                            onSubmit={(values) => {

                                if (actionType === EOprationalActions.REPLACE) {
                                    if (actionData?.esId !== values?.educationalSupervisor?.userId || actionData?.mohId !== values?.coeducationalSupervisor?.userId) {
                                        dispatch(createOrEditOrReplaceGlasRequest(values, actionType));
                                    } else {
                                        const alertMessageData = {
                                            message: t('Gla.selectReplaceSupervisors'),
                                            status: false,
                                            tranId: Date.now()
                                        };
                                        dispatch(alertActionRequest(alertMessageData));
                                    }
                                }
                                else dispatch(createOrEditOrReplaceGlasRequest(values, actionType));

                                if (actionType === EOprationalActions.EDIT)
                                    dispatch(isEditGlasRequest(actionData.glaId, false));

                                console.log("SubmitedValues==>", actionType, actionData, values);
                            }}>
                            {({ errors, setFieldValue, setFieldTouched, values, touched, dirty }) => (
                                <Form>

                                    <Row>
                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>{t('Gla.educationalSupervisor')} </Label>

                                                <MySelect
                                                    name="educationalSupervisor"
                                                    placeholder={t('Gla.educationalSupervisor')}
                                                    isDisabled={(actionType !== EOprationalActions.ADD && actionType !== EOprationalActions.REPLACE)}
                                                    value={values.educationalSupervisor}
                                                    onChange={(e) => setFieldValue('educationalSupervisor', e ? e : '')}
                                                    options={getEdSupervisorOptions(values) ? getEdSupervisorOptions(values) : []}
                                                    getOptionLabel={option => option.userFullName}
                                                    getOptionValue={option => option.userId}
                                                    valueKey='userId'
                                                    onBlur={() => setFieldTouched('educationalSupervisor', true)}
                                                    noOptionsMessage={() => { t('Gla.noDataFound') }}
                                                />
                                                {errors.educationalSupervisor && touched.educationalSupervisor && (
                                                    <div className="text-danger">{errors.educationalSupervisor}</div>
                                                )}
                                            </FormGroup>
                                        </Col>

                                        {/* {userDto?.trainee?.trMohUser == EStatusEnum?.NACTIVE && */}
                                        <Col sm="6">
                                            <FormGroup>
                                                <Label> {userDto?.trainee?.pathwayTag === EPathwayTags.CLOSED ? t('Gla.coeducationalSupervisor') : t('Gla.mOHSupervisorName')}</Label>
                                                <MySelect
                                                    name="coeducationalSupervisor"
                                                    placeholder={userDto?.trainee?.pathwayTag === EPathwayTags.CLOSED ? t('Gla.coeducationalSupervisor') : t('Gla.mOHSupervisorName')}
                                                    isDisabled={(actionType !== EOprationalActions.ADD && actionType !== EOprationalActions.REPLACE)}
                                                    value={values.coeducationalSupervisor}
                                                    onChange={(e) => setFieldValue('coeducationalSupervisor', e ? e : '')}
                                                    options={getCoEdSupervisorOptions(values) ? getCoEdSupervisorOptions(values) : []}
                                                    isClearable={true}
                                                    getOptionLabel={option => option.userFullName}
                                                    getOptionValue={option => option.userId}
                                                    isdisabled={actionType === EOprationalActions.SELECT}
                                                    valueKey='userId'
                                                    onBlur={() => setFieldTouched('coeducationalSupervisor', true)}
                                                    noOptionsMessage={() => { t('Gla.noDataFound') }}
                                                />
                                            </FormGroup>
                                        </Col>
                                        {/* } */}
                                    </Row>

                                    <Row>
                                        <Col sm="11" xs="12" className="flexone">
                                            <p className="mr-4 alone"> {t('Gla.and')}</p>
                                            <FormGroup className="flexone-item flexone-item-inline">
                                                <Label> {t('Gla.nameofTrainee')}</Label>
                                                <Input type="text" value={userDto?.userFullName || ''} disabled></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="8" className="flexone">
                                            <p className="mr-4 alone">  {t('Gla.fortheprogramof')}</p>
                                            <FormGroup className="flexone-item">
                                                <Label>  {t('Gla.nameofProgram')}</Label>
                                                <Input type="text" value={userDto?.program?.programName || ''} disabled></Input>
                                            </FormGroup>


                                            <FormGroup className="flexone-item">
                                                <Label>{t('Gla.matricNumber')}</Label>
                                                <Field type="text" placeholder={t('Gla.matricNumber')} name='matricNumber' className='form-control' disabled={actionType === EOprationalActions.SELECT} />
                                                <ErrorMessage name='matricNumber' component='div' className='text-danger' />
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="6" className="flexone">
                                            <p className="mr-4 alone"> {t('Gla.at')}</p>
                                            <FormGroup className="flexone-item">
                                                <Label>{t('Gla.nameofAcademy/Institute/Faculty/Centre ')}</Label>
                                                <Input type="text" value={userDto?.university?.universityName || ''} disabled></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <p className="mt-4">
                                        {t('Gla.academicSupervisionOne')}<br /><br />

                                        {t('Gla.academicSupervisionTwo')} <br /><br />

                                        {t('Gla.academicSupervisionThree')}
                                    </p>
                                    <div className="roles">
                                        <h1>{t('Gla.rOLESANDRESPONSIBILITIESOFTHETRAINEE')}  </h1>
                                        <div className="mx-1 roles-pad">
                                            <h2 className="line-through"><span> {t('Gla.general')}</span></h2>
                                            <ol>
                                                <li> {t('Gla.traineeAgreemant1')} </li>

                                                <li className="tmargin">  {t('Gla.traineeAgreemant2')}&nbsp;
                                                    <div className="period">
                                                        <MySelect
                                                            name="agreedperiod"
                                                            placeholder={t('Gla.AgreedperiodtoMeet')}
                                                            value={values.agreedperiod}
                                                            onChange={(e) => setFieldValue('agreedperiod', e ? e : '')}
                                                            options={periodOptions ? periodOptions : []}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            isDisabled={actionType === EOprationalActions.SELECT}
                                                            onBlur={() => setFieldTouched('agreedperiod', true)}
                                                            noOptionsMessage={() => { t('Hods.NoDataFound') }}
                                                        />
                                                        {errors.agreedperiod && touched.agreedperiod && (
                                                            <div className="text-danger">{errors.agreedperiod}</div>
                                                        )}
                                                    </div>
                                                    {t('Gla.traineeAgreemant3')}&nbsp;
                                                    <div className="moc">
                                                        {actionType === EOprationalActions.SELECT ?
                                                            <Input type="text" value={values.Communication?.filter(x => x.value !== '')?.map(y => y.value)?.toString()} disabled></Input>
                                                            : <>   <MySelect
                                                                allOption={{
                                                                    label: "Select All",
                                                                    value: ""
                                                                }}
                                                                isMulti={true}
                                                                placeholder={t('Gla.modeofCommunication')}
                                                                options={CommunicationOptions ? CommunicationOptions : []}
                                                                value={values.Communication ? values.Communication : []}
                                                                onChange={(e) => setFieldValue('Communication', e ? e : [])}
                                                                getOptionLabel={option => option.label}
                                                                getOptionValue={option => option.value}
                                                                // valueKey="floorId"
                                                                components={{ Option, ValueContainer }}
                                                                hideSelectedOptions={false}
                                                                removeSelected={false}
                                                                closeMenuOnSelect={false}
                                                                backspaceRemovesValue={false}
                                                                isSearchable={true}
                                                                allowSelectAll={true}
                                                                // allowSelectAll={filterElgible((CommunicationOptions ? CommunicationOptions : []), "") > 2 ? true : false}
                                                                onBlur={() => setFieldTouched('Communication', true)}
                                                                noOptionsMessage={() => t('Gla.noDataFound')}
                                                                {...formatGroupByShowOrNot(false)}

                                                            />
                                                                {errors.Communication && touched.Communication && (
                                                                    <div className="text-danger">{errors.Communication}</div>
                                                                )}
                                                            </>}
                                                    </div>
                                                </li>

                                                <li>{t('Gla.traineeAgreemant4')}</li>


                                                <li>{t('Gla.traineeAgreemant5')}</li>

                                                <li> {t('Gla.traineeAgreemant6')}</li>

                                                <li> {t('Gla.traineeAgreemant7')}
                                                    <ol className="sublist">
                                                        <li>  {t('Gla.traineeAgreemant8')}</li>
                                                        <li>  {t('Gla.traineeAgreemant9')} </li>
                                                        <li>  {t('Gla.traineeAgreemant10')}</li>
                                                        <li> {t('Gla.traineeAgreemant11')}</li>
                                                        <li>  {t('Gla.traineeAgreemant12')} </li>
                                                        <li> {t('Gla.traineeAgreemant13')}</li>
                                                        <li>  {t('Gla.traineeAgreemant14')}</li>
                                                    </ol>
                                                </li>

                                                <li>{t('Gla.traineeAgreemant15')}</li>
                                            </ol>
                                        </div>
                                    </div>
                                    <p className="py-4">{t('Gla.traineeAgreemant16')} </p>
                                    <div className="roles">
                                        <h1> {t('Gla.supervisorAgreement')}</h1>
                                        <div className="mx-1 roles-pad">
                                            <h2 className="line-through"><span> {t('Gla.general')}</span></h2>
                                            <ol>
                                                <li> {t('Gla.supervisorAgreement1')} </li>
                                                <li> {t('Gla.supervisorAgreement2')} </li>

                                                <li> {t('Gla.supervisorAgreement3')} </li>

                                                <li>  {t('Gla.supervisorAgreement4')} </li>

                                                <li className="tmargin"> {t('Gla.supervisorAgreement5')}&nbsp;
                                                    <div className="period">
                                                        <Input type="text" value={values.agreedperiod ? (values.agreedperiod as any)?.value : ''} disabled></Input>
                                                    </div>
                                                    {t('Gla.supervisorAgreement6')}&nbsp;
                                                    <div className="moc">
                                                        <Input type="text" value={values.Communication?.filter(x => x.value !== '')?.map(y => y.value)?.toString()} disabled></Input>
                                                    </div>
                                                </li>

                                                <li>   {t('Gla.supervisorAgreement7')} </li>

                                                <li> {t('Gla.supervisorAgreement8')} </li>

                                                <li> {t('Gla.supervisorAgreement9')} </li>

                                                <li> {t('Gla.supervisorAgreement10')} </li>

                                                <li> {t('Gla.supervisorAgreement11')} </li>

                                                <li> {t('Gla.supervisorAgreement12')} </li>

                                                <li> {t('Gla.supervisorAgreement13')} </li>

                                                <li> {t('Gla.supervisorAgreement14')} </li>
                                            </ol>
                                            <h2 className="line-through"><span> {t('Gla.supervisorAgreement15')}  </span></h2>
                                            <ol>
                                                <li> {t('Gla.supervisorAgreement16')} </li>

                                                <li> {t('Gla.supervisorAgreement17')} </li>

                                                <li> {t('Gla.supervisorAgreement18')} </li>
                                            </ol>
                                        </div>
                                    </div>
                                    <div className="mt-3">
                                        {(actionType !== EOprationalActions.SELECT) && <FormGroup check>
                                            <Label check>
                                                <Field type='checkbox' name='check' />
                                                {t('Gla.checkTitle')}
                                                <ErrorMessage name="check" component="div" className="text-danger" />
                                            </Label>
                                        </FormGroup>
                                        }

                                        {actionType === EOprationalActions.SELECT &&
                                            <Row>
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('Gla.educationalSupervisor')} </Label>
                                                        <Input type="text" value={actionData?.esStatus} disabled></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col sm='4'>
                                                    <FormGroup >
                                                        <Label>  {t('Gla.comments')}</Label>
                                                        <Input type="text" value={actionData?.esComments || ''} placeholder={t('Gla.comments')} disabled></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col sm='4'>
                                                    <FormGroup >
                                                        <Label>  {t('Gla.signature')}</Label>
                                                        <Input type="text" value={actionData?.esSignature || ''} placeholder={t('Gla.signature')} disabled></Input>
                                                    </FormGroup>
                                                </Col>
                                                {actionData?.mohStatus && <>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label> {t('Gla.coeducationalSupervisor')}</Label>
                                                            <Input type="text" value={actionData?.mohStatus} disabled></Input>
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm='4'>
                                                        <FormGroup >
                                                            <Label>  {t('Gla.comments')}</Label>
                                                            <Input type="text" value={actionData?.mohComments || ''} placeholder={t('Gla.comments')} disabled></Input>
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm='4'>
                                                        <FormGroup >
                                                            <Label>  {t('Gla.signature')}</Label>
                                                            <Input type="text" value={actionData?.mohSignature || ''} placeholder={t('Gla.signature')} disabled></Input>
                                                        </FormGroup>
                                                    </Col>
                                                </>}
                                            </Row>
                                        }

                                        {actionType !== EOprationalActions.SELECT ? <div className="text-center mb-4"><button disabled={(actionType === EOprationalActions.EDIT || actionType === EOprationalActions.REPLACE) ? !(dirty) : false} className="btn mt-3 modal-submit-button">{(actionType === EOprationalActions.ADD || actionType === EOprationalActions.REPLACE) ? t('ActionNames.create') : t('ActionNames.update')}</button> </div> : <div> <button className="btn mt-3 modal-submit-button" onClick={cancel}> {t('ActionNames.cancel')}</button></div>}
                                    </div>

                                </Form>
                            )
                            }
                        </Formik>
                    </div>
                </ModalBody>
            </Modal>
        </>

    )
}

export default React.memo(GlaAction)