import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../../store/actions';
import { SuperParentContext } from './glaContext';
import { resetAllGlasStateRequest, cancelAllPendingGlasRequest, getGlasDataRequest, isEditGlasRequest } from '../../../../store/actions'
import {
    GlaParentManager, GlaViewManager, GlasView, GlaAction
} from './glaIndex';
interface IProps {
    activateAuthLayout;
    getGlasDataRequest;
    resetAllGlasStateRequest;
    cancelAllPendingGlasRequest;
    isEditGlasRequest;
    glaId: string;
}
class Glas extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            glasViewManager: GlaViewManager,
            glasViewComponent: GlasView,
            glaAction: GlaAction,
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllGlasStateRequest();
        this.props.getGlasDataRequest();
    }
    componentWillUnmount() {
        if (this.props.glaId)
            this.props.isEditGlasRequest(this.props.glaId, false);
        this.props.resetAllGlasStateRequest();
        this.props.cancelAllPendingGlasRequest();

    }
    render() {
        return (
            <>
                <SuperParentContext.Provider value={this.state}>
                    <GlaParentManager />
                </SuperParentContext.Provider>
            </>
        )
    }
}

const mapStateToProps = state => ({
    glaId: state?.glasReducer?.actionData?.glaId || ''
});
export default connect(mapStateToProps, { activateAuthLayout, cancelAllPendingGlasRequest, resetAllGlasStateRequest, getGlasDataRequest, isEditGlasRequest })(Glas);