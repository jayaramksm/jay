import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, cancelAllPendingRlaRequest, resetAllRlaStateRequest, getRlaDataRequest, isEditRlasRequest } from '../../../../store/actions';
import { SuperParentContext } from './rlaContext';
import { RlaParentManager, RlaView, RlaAction, RlaFilter, RlaViewManager } from './rlaIndex';

interface IProps {
    activateAuthLayout;
    getRlaDataRequest;
    resetAllRlaStateRequest;
    cancelAllPendingRlaRequest;
    isEditRlasRequest;
    rlaId: string;
}
class RotationsandLearningAgreements extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            rlaViewManager: RlaViewManager,
            rlaView: RlaView,
            rlaAction: RlaAction,
            rlaFilter: RlaFilter
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllRlaStateRequest();
        this.props.getRlaDataRequest();
    }
    componentWillUnmount() {
        if (this.props.rlaId)
            this.props.isEditRlasRequest(this.props.rlaId, false);
        this.props.resetAllRlaStateRequest();
        this.props.cancelAllPendingRlaRequest();

    }
    render() {
        return (
                <SuperParentContext.Provider value={this.state}>
                    <RlaParentManager />
                </SuperParentContext.Provider>
        )
    }
}
const mapStateToProps = state => ({
    rlaId: state?.rlaReducer?.actionData?.rlaId || ''
});

export default connect(mapStateToProps, { activateAuthLayout, cancelAllPendingRlaRequest, isEditRlasRequest, resetAllRlaStateRequest, getRlaDataRequest })(RotationsandLearningAgreements);