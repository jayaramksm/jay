import React, { useContext } from "react";
import { ParentContext } from "../Container/rlaContext";
import EditIcon from "../../../../images/Edit.svg";
import { EApprovelActions, EOprationalActions } from "models/utilitiesModel";
import { useDispatch, useSelector } from "react-redux";
import Approved from "../../../../images/Approved.svg";
import pending from "../../../../images/Pending.svg";
import reject from "../../../../images/Reject.svg";
import View from "../../../../images/View.svg";
import { IRla, IRlaModel } from "../../../../models/rlaModel";
import { isEditRlasRequest, setRlaActionTypeData } from "../../../../store/actions";

const RlaView: React.FC = () => {
  const dispatch = useDispatch();
  const context: any = useContext(ParentContext);

  const rlaData: IRla | undefined = useSelector((state: any) => {
    if (state?.rlaReducer?.rlaData?.length) {
      let rlasData = (state.rlaReducer as IRlaModel).rlaData;
      return rlasData.find((rla) => rla.rlaId === context);
    } else return undefined;
  });

  const editRla = () => {
    dispatch(setRlaActionTypeData(EOprationalActions.EDIT, rlaData));
    dispatch(isEditRlasRequest(rlaData?.rlaId, true));

  };
  const ViewRla = () => {
    dispatch(setRlaActionTypeData(EOprationalActions.SELECT, rlaData));
  };
  const showRlaEdit =
    (rlaData?.firstRotationalSupervisor?.status !==
      EApprovelActions.APPROVED ||
      rlaData?.secondRotationSupervisor?.status ===
      EApprovelActions.REJECTED) &&
    ((rlaData?.secondRotationSupervisor?.status
      ? rlaData?.secondRotationSupervisor?.status !==
      EApprovelActions.APPROVED
      : true) ||
      rlaData?.firstRotationalSupervisor?.status ===
      EApprovelActions.REJECTED);

  console.log("RlaView==>", rlaData);

  return (
    <>
      <tr>
        <td>{rlaData?.stageName}</td>
        <td> {rlaData?.rotationName}</td>
        <td> {rlaData?.firstRotationalSupervisor?.supervisorName || '-'}</td>
        <td className="column-center">
          {rlaData?.firstRotationalSupervisor?.status ===
            EApprovelActions.APPROVED ? (
            <img src={Approved} className="icon" alt="" />
          ) : rlaData?.firstRotationalSupervisor?.status ===
            EApprovelActions.PENDING ? (
            <img src={pending} className="icon" alt="" />
          ) : rlaData?.firstRotationalSupervisor?.status ===
            EApprovelActions.REJECTED ? (
            <img src={reject} className="icon" alt="" />
          ) : (
            "-"
          )}
        </td>
        <td>{rlaData?.secondRotationSupervisor?.supervisorName || '-'}</td>
        <td className="column-center">
          {rlaData?.secondRotationSupervisor?.status ===
            EApprovelActions.APPROVED ? (
            <img src={Approved} className="icon" alt="" />
          ) : rlaData?.secondRotationSupervisor?.status ===
            EApprovelActions.PENDING ? (
            <img src={pending} className="icon" alt="" />
          ) : rlaData?.secondRotationSupervisor?.status ===
            EApprovelActions.REJECTED ? (
            <img src={reject} className="icon" alt="" />
          ) : (
            "-"
          )}
        </td>
        <td>{rlaData?.rotationStartDate}</td>
        <td>{rlaData?.rotationEndDate}</td>
        <td>
          <span>
            <img
              onClick={ViewRla}
              src={View}
              className="actionicon pointer"
              alt="View"
            />
          </span>

          {rlaData?.rlaStatus !== EApprovelActions.COMPLETED && <span>
            <img
              src={EditIcon}
              onClick={editRla}
              className="actionicon pointer"
              alt="Edit"
            />
          </span>}
        </td>
      </tr>
    </>
  );
};
export default React.memo(RlaView);
