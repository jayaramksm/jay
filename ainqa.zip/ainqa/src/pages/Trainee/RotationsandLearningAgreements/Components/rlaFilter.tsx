
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { setRlaActionTypeData, setSearchRlaData } from '../../../../store/actions';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IRla, IRlaModel } from '../../../../models/rlaModel';

const RlaFilter: React.FC = () => {
    const { t } = useTranslation('translations');

    const dispatch = useDispatch();
    const onSearchChange = e => {
        dispatch(setSearchRlaData(e.target.value));
    };
    const addRla = () => {
        dispatch(setRlaActionTypeData(EOprationalActions.ADD, null));
    };
    const rlasData: IRla[] = useSelector((state: any) => {
        if (state?.rlaReducer?.rlaData)
            return (state.rlaReducer as IRlaModel)?.rlaData;
        else return [];
    });

    return (
        <Row className="compHeading">
            <Col>
                <h3 className="page-header header-title"> {t('Rla.placementofRotationsandLearningAgreements')}</h3>
            </Col>
            <div className="rgtFilter">
                {rlasData?.length > 2 && <div className="search-box filtericon">
                    <div className="search-text"><input type="text" onChange={onSearchChange} placeholder="Search"></input><i className="ti-search icon"></i></div>
                </div>}
                {rlasData?.length > 0 && <button onClick={addRla} className="addnewButn"><i className="ti-plus mr-2"></i>{t('Rla.createNewRLA')} </button>}
            </div>
        </Row>

    )
}
export default React.memo(RlaFilter);