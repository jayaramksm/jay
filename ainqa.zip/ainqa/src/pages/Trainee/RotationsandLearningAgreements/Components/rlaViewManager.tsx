import React, { useContext } from "react";
import { ParentContext, SuperParentContext } from "../Container/rlaContext";
import { useSelector, useDispatch } from "react-redux";
import { useTranslation } from "react-i18next";
import { IRla, IRlaModel } from "../../../../models/rlaModel";
import {
  setRlaPaginationCurrentPageValue,
  setRlaActionTypeData,
} from "../../../../store/actions";
import { EOprationalActions } from "../../../../models/utilitiesModel";
import { getEnvironment } from "../../../../helpers/helpersIndex";
import { PaginationComponent } from "../../../utilities/PaginationComponent";

const RlaViewManager: React.FC = () => {
  const context: any = useContext(SuperParentContext);
  const dispatch = useDispatch();
  const pageSize = getEnvironment.pageSize;

  const { t } = useTranslation("translations");

  const rlasData: IRla[] = useSelector((state: any) => {
    if (state?.rlaReducer?.rlaData)
      return (state.rlaReducer as IRlaModel)?.rlaData;
    else return [];
  });

  const currentPage: number = useSelector((state: any) => {
    if (state?.rlaReducer?.paginationCurrentPage)
      return (state.rlaReducer as IRlaModel).paginationCurrentPage;
    else return 0;
  });

  const addRla = () => {
    dispatch(setRlaActionTypeData(EOprationalActions.ADD, null));
  };
  const searchKey: string = useSelector((state: any) => {
    if (state?.rlaReducer?.searchKey)
      return (state.rlaReducer as IRlaModel).searchKey;
    else return "";
  });

  const rlaFilterData: IRla[] | undefined =
    rlasData && searchKey !== ""
      ? rlasData?.filter((x: IRla) =>
        searchKey !== ""
          ? x?.rotationName
            ?.toLowerCase()
            ?.startsWith(searchKey.toLowerCase())
          : true
      )
      : rlasData;

  let pagesCount: number = Math.ceil(
    (rlaFilterData ? rlaFilterData.length : 0) / pageSize
  );

  if (currentPage >= pagesCount && pagesCount !== 0)
    dispatch(setRlaPaginationCurrentPageValue(0));

  const handleClick = (e, index) => {
    e.preventDefault();
    dispatch(setRlaPaginationCurrentPageValue(index));
  };
  console.log("rlasmanager==>", rlasData, context);

  return (
    <>
      {rlasData?.length === 0 && (
        <div onClick={addRla} className="add-button">
          <div className="button-text">
            {" "}
            {t("Rla.addRotationsandLearningAgreements")}
          </div>
          <div className="note"> {t("Rla.PleaseAddagreementForRotation")}</div>
        </div>
      )}

      {rlasData?.length > 0 && (
      <div className="flexScroll">
        <div className="main-table no-border no-gaps">
          <div className="tbl-parent table-responsive">
            <table className="myTable pla-table rla-table table">
              <thead>
                <tr>
                  <th> {t("Rla.stage")}</th>
                  <th> {t("Rla.rotations")}</th>

                  <th> {t("Rla.1stRotationSupervisor")}</th>
                  <th className="column-center"> {t("Rla.approvalStatus")}</th>
                  <th> {t("Rla.2ndRotationSupervisor")}</th>
                  <th className="column-center"> {t("Rla.approvalStatus")}</th>
                  <th> {t("Rla.StartDate")}</th>
                  <th> {t("Rla.endDate")}</th>
                  <th> {t("Rla.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {rlaFilterData &&
                  rlaFilterData
                    ?.slice(
                      currentPage * pageSize,
                      (currentPage + 1) * pageSize
                    )
                    .map((rla) => (
                      <ParentContext.Provider value={rla.rlaId} key={rla.rlaId}>
                        <context.rlaView />
                      </ParentContext.Provider>
                    ))}
              </tbody>
            </table>
          </div>
          {rlaFilterData && rlaFilterData?.length === 0 && (
            <div className="norecordsfound">
              <h6>{t("Rla.noDataFound")}</h6>
            </div>
          )}
          {rlaFilterData && rlaFilterData.length > pageSize && (
            <div className="pagination">
              <PaginationComponent
                currentPage={currentPage}
                pagesCount={pagesCount}
                pageSize={pageSize}
                handleClick={handleClick}
              />
            </div>
          )}
        </div>
      </div>
      )}
    </>
  );
};
export default React.memo(RlaViewManager);
