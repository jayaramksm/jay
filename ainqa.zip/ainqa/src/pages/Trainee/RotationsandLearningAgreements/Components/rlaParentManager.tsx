import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/rlaContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IRlaModel, IstudyPlanStaus } from '../../../../models/rlaModel';

const RlaParentManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const isRlaListActionType = useSelector((state: any) => {
        if (state?.rlaReducer)
            return (state.rlaReducer as IRlaModel)?.actionType === EOprationalActions.UNSELECT;
        else return false;
    });

    const studyPlanStaus: IstudyPlanStaus | any = useSelector((state: any) => {
        if (state?.rlaReducer?.studyPlanStaus)
            return (state.rlaReducer as IRlaModel)?.studyPlanStaus;
        else return undefined;
    });
    console.log("RlaParentManager==>", isRlaListActionType);

    return (
        <>{studyPlanStaus?.status ?
            <div className="maincontent flexLayout pr-3">
                {isRlaListActionType ? <>
                    <context.rlaFilter />
                    <context.rlaViewManager /> </>
                    : <context.rlaAction />}
            </div>
            : <div className='text-danger'>{studyPlanStaus?.messages} </div>}
        </>
    )
}
export default React.memo(RlaParentManager);