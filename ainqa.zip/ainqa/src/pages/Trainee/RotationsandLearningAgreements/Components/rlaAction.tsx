import React, { useRef } from "react";
import {
  setRlaActionTypeData,
  createOrEditRlaRequest,
  isEditRlasRequest,
} from "../../../../store/actions";
import {
  EApprovelActions,
  EOprationalActions,
  ICurrentDateAndTime,
  IUserDetails,
} from "../../../../models/utilitiesModel";
import { useSelector, useDispatch } from "react-redux";
import { ErrorMessage, Field, Form, Formik, FieldArray } from "formik";
import * as Yup from "yup";
import {
  MySelect,
  defultContentValidate,
  customContentValidation,
  defultContentObjectValidate,
} from "../../../../helpers/helpersIndex";
import { useTranslation } from "react-i18next";
import {
  IHod,
  IRla,
  IRlaModel,
  IRotation,
  IWba,
} from "../../../../models/rlaModel";
import { IUser } from "../../../../models/rlaModel";
import {
  Row,
  Col,
  Input,
  FormGroup,
  Label,
  UncontrolledTooltip,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
} from "reactstrap";
import DatePicker from "react-datepicker";
import moment from "moment";
import Approved from "../../../../images/Approved.svg";
import pending from "../../../../images/Pending.svg";
import reject from "../../../../images/Reject.svg";
import cloneDeep from 'lodash/cloneDeep'

const RlaAction: React.FC = () => {
  const { t } = useTranslation("translations");
  const dispatch = useDispatch();
  let wbaFormik = useRef(null) as any;

  const actionType = useSelector((state: any) => {
    if (state?.rlaReducer?.actionType) {
      return (state.rlaReducer as IRlaModel).actionType;
    } else {
      return EOprationalActions.UNSELECT;
    }
  });
  const rlasData: IRla[] | undefined = useSelector((state: any) => {
    if (state?.rlaReducer?.rlaData)
      return (state.rlaReducer as IRlaModel)?.rlaData;
    else return undefined;
  });

  const totalRotationSupervisor: IUser[] = useSelector((state: any) => {
    if (state?.rlaReducer?.totalRotationSupervisor) {
      return (state.rlaReducer as IRlaModel).totalRotationSupervisor;
    } else {
      return [];
    }
  });

  const studyplanRotationsWithWbas: IRotation[] = useSelector((state: any) => {
    if (state?.rlaReducer?.studyplanRotationsWithWbas) {
      return (state.rlaReducer as IRlaModel).studyplanRotationsWithWbas;
    } else {
      return [];
    }
  });

  const rotationOptions = () => {
    const existingRotations = rlasData?.map((x) => x.rotationId);
    const checkRlaStatusPending = (id) => {
      return rlasData?.filter((x) => x.rotationId === id).some(y => (y.secondRotationSupervisor?.status === EApprovelActions.PENDING || y.firstRotationalSupervisor?.status === EApprovelActions.PENDING));
    }
    let rotationsData: any[] = studyplanRotationsWithWbas?.filter(
      (x) => (!existingRotations?.includes(x.rotationId) && (x.rotationStatus === EApprovelActions.PENDING))
    );
    if (actionType === EOprationalActions.EDIT)
      rotationsData.unshift(
        studyplanRotationsWithWbas.find(
          (x) => x.rotationId === actionData?.rotationId
        )
      );
    return rotationsData || [];
  };

  const hodsData: IHod[] = useSelector((state: any) => {
    if (state?.rlaReducer?.hodsData) {
      return (state.rlaReducer as IRlaModel).hodsData;
    } else {
      return [];
    }
  });

  const currentDateAndTime: ICurrentDateAndTime = useSelector(
    (state: any) => state?.rlaReducer?.currentDate
  );

  const actionData: IRla = useSelector((state: any) => {
    if (state?.rlaReducer?.actionData) {
      return (state.rlaReducer as IRlaModel).actionData;
    } else {
      return undefined;
    }
  });

  console.log('deeplplyClonedObje==>', cloneDeep(actionData?.expectedWbas))

  const userDto: IUserDetails = useSelector((state: any) => {
    if (state?.SessionState?.userDto) return state.SessionState.userDto;
    else return {};
  });

  const initialValues = () => ({
    startDate: actionData ? new Date(actionData.rotationStartDate) : null,
    endDate: actionData ? new Date(actionData?.rotationEndDate) : null,
    firstRotationSupervisor: actionData
      ? totalRotationSupervisor?.find(
        (x) =>
          x?.userId === actionData?.firstRotationalSupervisor?.supervisorId
      )
      : "",
    secondRotationSupervisor: actionData
      ? totalRotationSupervisor?.find(
        (x) =>
          x?.userId ===
          actionData?.secondRotationSupervisor?.supervisorId
      )
      : "",
    rotation: actionData
      ? studyplanRotationsWithWbas?.find(
        (x) => x.rotationId === actionData?.rotationId
      )
      : "",
    hospitalName: actionData ? actionData.hospitalName ? actionData.hospitalName : `Other-${actionData.otherHospitalName}` : '',
    exceptedWbas: '',
    placementAimsandobjective: actionData
      ? actionData?.placementAmisObject
      : "",
    plannedAbsences: actionData ? actionData?.plannedAbsencesConferences : "",
    check: actionData?.traineeSignature === 'true' ? true : false,
    educationalSupervisorId: userDto?.trainee?.educationalSupervisor,
    mohSupervisorId: userDto?.trainee?.coEducationalSupervisor,
    hod: actionData ? hodsData?.find((x) => x.hodId === actionData?.hodId) : "",
    rlaId: actionData ? actionData?.rlaId : 0,
    spRotationId: actionData ? actionData.spRotationId : '',
    stageId: actionData ? actionData.stage : '',
    oldFirstRsSup: totalRotationSupervisor?.find(
      (x) =>
        x?.userId === actionData?.firstRotationalSupervisor?.supervisorId
    ),
    oldSecondRsSup: totalRotationSupervisor?.find(
      (x) =>
        x?.userId === actionData?.secondRotationSupervisor?.supervisorId
    ),
    endDateMax: "",
    secondRotationSupervisorSignature: actionData?.secondRotationSupervisor?.signature || '',
    firstRotationSupervisorSignature: actionData?.firstRotationalSupervisor?.signature || '',
    isMainFormTouched: actionData ? cloneDeep(actionData?.expectedWbas) : ''
  });

  const validationSchema = Yup.object().shape({
    check: Yup.boolean().oneOf([true], t("controleErrors.required")),
    startDate: defultContentValidate(t("controleErrors.required")),
    endDate: defultContentValidate(t("controleErrors.required")),
    firstRotationSupervisor: defultContentValidate(
      t("controleErrors.required")
    ),
    rotation: defultContentValidate(t("controleErrors.required")),
    plannedAbsences: Yup.lazy((value) => {
      if (value) return customContentValidation(
        t,
        t("controleErrors.required"),
        {
          patternType: "alphanumericspacesp",
          message: "alphanumericspace",
          spacialChar: "",
        },
        200,
        4
      )
      else return defultContentValidate('')

    }),
    placementAimsandobjective: customContentValidation(
      t,
      t("controleErrors.required"),
      {
        patternType: "alphanumericspacesp",
        message: "alphanumericspace",
        spacialChar: "",
      },
      200,
      4
    ),
  });


  const wbaValidationSchema = Yup.object().shape({
    exceptedWbas: Yup.array().of(
      Yup.object().shape({
        planned: Yup.lazy((planned) => {
          if (planned) {
            let expected
            return Yup.string().when('wbaExpected', {
              is: (expectedval) => {
                expected = +expectedval
                // console.log('plannedadnExpected==>', +planned, +expected)
                return +planned >= +expectedval
              },
              then: customContentValidation(t, t("controleErrors.required"), { patternType: 'numbersWithoutZero', message: 'numberWithoutZero', spacialChar: '' }, 2, 1),
              otherwise: Yup.string().test({
                name: 'PlannedWba',
                message: t("Rla.plannedPBAErrorsMsg"),
                test: (value) => +value >= expected
              }),
            })
          }
          else return defultContentValidate(t("controleErrors.required"))
        }),
      })
    ),
  })

  const firstRotationSupervisorOptions = (values) => {
    const secondRotationSupervisor =
      values?.secondRotationSupervisor?.userId || "";
    return totalRotationSupervisor?.filter(
      (user) => user.userId !== secondRotationSupervisor
    );
  };

  const secondRotationSupervisorOptions = (values) => {
    const firstRotationSupervisor =
      values?.firstRotationSupervisor?.userId || "";
    return totalRotationSupervisor?.filter(
      (user) => user.userId !== firstRotationSupervisor
    );
  };

  const selectRotation = async (setFieldValue, e, values, setFieldTouched) => {
    await setFieldValue("rotation", e ? e : "");
    await setFieldValue('hospitalName', e?.hospitalName ? e?.hospitalName : `Other-${e?.otherHospitalName}`)
    console.log('rotationadded===>', e);

    if (actionType === EOprationalActions.EDIT) {
      const endDate = new Date(moment(new Date(actionData.rotationStartDate)).add(+(e as any).rotationDuration, "M").format("YYYY-MM-DD")
      );
      setFieldValue("endDate", endDate);
    } else {
      setFieldValue("endDate", "");
      setFieldValue("startDate", "");
    }
  };

  const handleStartDateFromDate = (
    selectedstartDate: any,
    setFieldValue: any,
    values
  ) => {
    setFieldValue("startDate", selectedstartDate);
    const endDate = new Date(
      moment(selectedstartDate)
        .add(+(values.rotation as any).rotationDuration, "M")
        .format("YYYY-MM-DD")
    );
    setFieldValue("endDate", endDate);
  };
  const handleEndDate = (selectedendDate: any, setFieldValue: any) =>
    setFieldValue("endDate", selectedendDate);

  const cancel = () => {
    if (actionType === EOprationalActions.EDIT)
      dispatch(isEditRlasRequest(actionData?.rlaId, false));

    dispatch(setRlaActionTypeData(EOprationalActions.UNSELECT, null));

  };

  const saveOrUpdateRla = (isValid, dirty, values, submitForm) => {
    submitForm();
    wbaFormik.current?.submitForm();
    console.log('wbaFormikValues==>', wbaFormik.current?.values.exceptedWbas, wbaFormik.current)

    if (actionType === EOprationalActions.ADD && (isValid && dirty) && (wbaFormik.current?.isValid && wbaFormik.current?.dirty)) {
      let data = { ...values, exceptedWbas: wbaFormik.current?.values.exceptedWbas }

      const confirmMessage = t("Rla.confirmMessages.RLA1");
      dispatch(createOrEditRlaRequest(data, actionType, false, confirmMessage));
    }
    else if (actionType === EOprationalActions.EDIT && (isValid) && wbaFormik.current?.isValid) {

      let data = { ...values, exceptedWbas: wbaFormik.current?.values.exceptedWbas }

      const confirmMessage = t("Rla.confirmMessages.RLA1");
      dispatch(createOrEditRlaRequest(data, actionType, false, confirmMessage));

      dispatch(isEditRlasRequest(actionData?.rlaId, false));
      console.log("SubmitedValues==>", values);
    }
  }

  console.log("RlaAddOrEditAgreement==>", {
    totalRotationSupervisor,
    userDto,
    studyplanRotationsWithWbas,
    actionData,
    currentDateAndTime,
    rlasData
  });
  return (
    <>
      <Col className="breadcrumbs pl-0">
        <div>
          <span className='pointer' onClick={cancel}>{t('Rla.rla')}</span>
          <span><i className="ti-angle-right"></i></span>
          {actionType === EOprationalActions.ADD && <span className="active">{t('ActionNames.add')}</span>}
          {actionType === EOprationalActions.EDIT && <span className="active">{t('Rla.edit')}</span>}
          {actionType === EOprationalActions.SELECT && <span className="active">{t('ActionNames.view')}</span>}
        </div>
      </Col>
      <div className="flexScroll">
        <Formik
          enableReinitialize
          initialValues={initialValues()}
          validationSchema={validationSchema}
          onSubmit={(values) => {
            // const confirmMessage = t("Rla.confirmMessages.RLA1");
            // dispatch(
            //   createOrEditRlaRequest(values, actionType, false, confirmMessage)
            // );

            // if (actionType === EOprationalActions.EDIT)
            //   dispatch(isEditRlasRequest(actionData?.rlaId, false));
            console.log("SubmitedValues==>", values);
          }}
        >
          {({
            errors,
            setFieldValue,
            setFieldTouched,
            values,
            touched,
            dirty,
            isValid,
            submitForm
          }) => (
            <Form>
              <div className="top-section">
                <h2>
                  <div> {t("Rla.aggrementDetails")}</div>
                </h2>
                <div className="details-section">
                  <Row className="mt-3">
                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.traineeName")}</Label>
                        <Input
                          type="text"
                          placeholder={t("Rla.traineeName")}
                          disabled
                          value={userDto?.userFullName}
                        ></Input>
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.programmeName")}</Label>
                        <Input
                          type="text"
                          placeholder={t("Rla.programmeName")}
                          disabled
                          value={userDto?.program?.programName}
                        ></Input>
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.headoftheDepartment")}</Label>
                        <MySelect
                          name="hod"
                          placeholder={t("Rla.headoftheDepartment")}
                          value={values.hod}
                          onChange={(e) => setFieldValue("hod", e)}
                          options={hodsData ? hodsData : []}
                          getOptionLabel={(option) => option.hodFullName}
                          getOptionValue={(option) => option.hodId}
                          isDisabled={(actionType === EOprationalActions.SELECT || actionType === EOprationalActions.EDIT)}
                          valueKey="hodId"
                          onBlur={() => setFieldTouched("hod", true)}
                          noOptionsMessage={() => {
                            t("Rla.noDataFound");
                          }}
                        />

                        {errors.hod && touched.hod && (
                          <div className="text-danger">{errors.hod}</div>
                        )}
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.educationalSupervisor")}</Label>
                        <Input
                          type="text"
                          placeholder={t("Rla.educationalSupervisor")}
                          disabled
                          value={userDto?.trainee?.esName}
                        ></Input>
                      </FormGroup>
                    </Col>

                    {userDto?.trainee?.educationalSupervisor && (
                      <Col sm="4">
                        <FormGroup>
                          <Label> {t("Rla.mOHSupervisor")}</Label>
                          <Input
                            type="text"
                            placeholder={t("Rla.mOHSupervisor")}
                            disabled
                            value={userDto?.trainee?.mohName}
                          ></Input>
                        </FormGroup>
                      </Col>
                    )}
                  </Row>
                </div>
              </div>
              <hr />
              <div className="top-section">
                <h2>
                  <div> {t("Rla.rotationDetails")}</div>
                </h2>
                <div className="details-section">
                  <Row className="mt-3">
                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.universityName")}</Label>
                        <Input
                          type="text"
                          placeholder={t("Rla.universityName")}
                          disabled
                          value={userDto?.university?.universityName || ""}
                        ></Input>
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.stage")}</Label>
                        <Input
                          type="text"
                          placeholder={t("Rla.stage")}
                          disabled
                          value={(values?.rotation as any)?.rotationStageName || ""}
                        ></Input>
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.rotation")}</Label>
                        <MySelect
                          name="rotation"
                          placeholder={t("Rla.rotation")}
                          value={values.rotation}
                          onChange={(e) => selectRotation(setFieldValue, e, values, setFieldTouched)}
                          options={rotationOptions()}
                          getOptionLabel={(option) => option.rotation}
                          getOptionValue={(option) => option.rotationId}
                          isDisabled={(actionType === EOprationalActions.SELECT || actionType === EOprationalActions.EDIT)}
                          valueKey="rotationId"
                          onBlur={() => {
                            setFieldTouched("rotation", true)
                            console.log('rotationData=>', values.rotation)

                          }}
                          noOptionsMessage={() => {
                            t("Rla.noDataFound");
                          }}
                        />
                        {errors.rotation && touched.rotation && (
                          <div className="text-danger">{typeof (errors.rotation) === 'string' ? errors.rotation : ''}</div>
                        )}
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row className="mt-3">
                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.rotationstartDate")}</Label>
                        <DatePicker
                          placeholderText={t("Rla.rotationstartDate")}
                          className="w100 datepickerIcon form-control"
                          name="startDate"
                          popperPlacement="bottom"
                          popperModifiers={{
                            flip: {
                              behavior: ["bottom"],
                            },
                            preventOverflow: {
                              enabled: false,
                            },
                          }}
                          disabled={
                            actionType === EOprationalActions.SELECT || actionData?.isWbaFiled
                            //  ||
                            // (actionType === EOprationalActions.EDIT &&
                            //   values.exceptedWbas?.length > 0)
                          }
                          autoComplete="off"
                          selected={values.startDate}
                          onChange={(e) =>
                            handleStartDateFromDate(e, setFieldValue, values)
                          }
                          dateFormat={"dd-MM-yyyy"}
                          minDate={new Date(currentDateAndTime?.date)}
                          // maxDate={values.endDate}
                          onBlur={() => setFieldTouched("startDate", true)}
                          showMonthDropdown
                          showYearDropdown
                          dropdownMode="select"
                        />
                        {errors.startDate && touched.startDate && (
                          <div className="text-danger">{errors.startDate}</div>
                        )}
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.rotationEndDate")}</Label>
                        <DatePicker
                          placeholderText={t("Rla.rotationEndDate")}
                          className="w100 datepickerIcon form-control"
                          name="endDate"
                          popperPlacement="top"
                          autoComplete="off"
                          popperModifiers={{
                            flip: {
                              behavior: ["top"],
                            },
                            preventOverflow: {
                              enabled: false,
                            },
                          }}
                          selected={values.endDate}
                          onChange={(e) => handleEndDate(e, setFieldValue)}
                          dateFormat={"dd-MM-yyyy"}
                          minDate={values.startDate}
                          disabled={
                            values.endDate
                              ? new Date(currentDateAndTime?.date) >
                                values.endDate
                                ? false
                                : true
                              : true
                          }
                          // maxDate={
                          //   new Date(
                          //     moment(values.startDate || new Date())
                          //       .add(
                          //         +(values.rotation as any).rotationDuration,
                          //         "M"
                          //       )
                          //       .format("YYYY-MM-DD")
                          //   )
                          // }
                          onBlur={() => setFieldTouched("endDate", true)}
                          showMonthDropdown
                          showYearDropdown
                          dropdownMode="select"
                        />
                        {errors.endDate && touched.startDate && (
                          <div className="text-danger">{errors.endDate}</div>
                        )}
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.rotationDuration")}</Label>
                        <Input
                          type="text"
                          placeholder={t("Rla.rotationDuration")}
                          disabled
                          value={
                            (values?.rotation as any)?.rotationDuration || ""
                          }
                        ></Input>
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row className="mt-3">
                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.hosptialName")}
                        </Label>
                        <Field
                          name='hospitalName'
                          type="text"
                          disabled
                          className='form-control'
                          placeholder={t("Rla.hosptialName")}
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row>
                    <Col sm="4">
                      <FormGroup>
                        <Label>{t("Rla.placementAimsandobjective")}</Label>
                        <Field
                          placeholder={t("Rla.placementAimsandobjective")}
                          disabled={actionType === EOprationalActions.SELECT || actionType === EOprationalActions.EDIT}
                          className={
                            "form-control " +
                            (touched.placementAimsandobjective &&
                              errors.placementAimsandobjective
                              ? " is-invalid"
                              : "")
                          }
                          name="placementAimsandobjective"
                        />
                        <ErrorMessage
                          name="placementAimsandobjective"
                          component="div"
                          className="text-danger"
                        />
                      </FormGroup>
                    </Col>

                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.plannedAbsences&Conferences")}</Label>
                        <Field
                          placeholder={t("Rla.plannedAbsences&Conferences")}
                          disabled={actionType === EOprationalActions.SELECT || actionType === EOprationalActions.EDIT}
                          className={
                            "form-control " +
                            (touched.placementAimsandobjective &&
                              errors.placementAimsandobjective
                              ? " is-invalid"
                              : "")
                          }
                          name="plannedAbsences"
                        />
                        <ErrorMessage
                          name="plannedAbsences"
                          component="div"
                          className="text-danger"
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                </div>
              </div>
              <hr />

              <div className="top-section">
                <h2> {t("Rla.rotationSupervisorDetails")}</h2>
                <div className="details-section">
                  <Row className="mt-3">
                    <Col sm="4">
                      <FormGroup>
                        <Label> {t("Rla.1stRotationSupervisor")}</Label>
                        <MySelect
                          name="firstRotationSupervisor"
                          placeholder={t("Rla.1stRotationSupervisor")}
                          value={values.firstRotationSupervisor}
                          onChange={(e) =>
                            setFieldValue("firstRotationSupervisor", e ? e : "")
                          }
                          options={
                            firstRotationSupervisorOptions(values)
                              ? firstRotationSupervisorOptions(values)
                              : []
                          }
                          getOptionLabel={(option) => option.userFullName}
                          getOptionValue={(option) => option.userId}
                          isDisabled={actionType === EOprationalActions.SELECT}
                          valueKey="userId"
                          onBlur={() =>
                            setFieldTouched("firstRotationSupervisor", true)
                          }
                          noOptionsMessage={() => {
                            t("Rla.noDataFound");
                          }}
                        />

                        {errors.firstRotationSupervisor &&
                          touched.firstRotationSupervisor && (
                            <div className="text-danger">
                              {errors.firstRotationSupervisor}
                            </div>
                          )}
                      </FormGroup>
                    </Col>

                    {totalRotationSupervisor?.length > 1 && (
                      <Col sm="4">
                        <FormGroup>
                          <Label> {t("Rla.2ndRotationSupervisor")}</Label>
                          <MySelect
                            name="secondRotationSupervisor"
                            placeholder={t("Rla.2ndRotationSupervisor")}
                            value={values.secondRotationSupervisor}
                            isClearable={true}
                            onChange={(e) =>
                              setFieldValue(
                                "secondRotationSupervisor",
                                e ? e : ""
                              )
                            }
                            options={
                              secondRotationSupervisorOptions(values)
                                ? secondRotationSupervisorOptions(values)
                                : []
                            }
                            getOptionLabel={(option) => option.userFullName}
                            getOptionValue={(option) => option.userId}
                            isDisabled={actionType === EOprationalActions.SELECT}
                            valueKey="userId"
                            onBlur={() =>
                              setFieldTouched("secondRotationSupervisor", true)
                            }
                            noOptionsMessage={() => {
                              t("Rla.noDataFound");
                            }}
                          />

                          {errors.secondRotationSupervisor &&
                            touched.secondRotationSupervisor && (
                              <div className="text-danger">
                                {errors.secondRotationSupervisor}
                              </div>
                            )}
                        </FormGroup>
                      </Col>
                    )}
                  </Row>
                </div>
              </div>
              <hr />
              <div className="top-section">
                <Formik
                  enableReinitialize
                  initialValues={{
                    exceptedWbas: actionData ? cloneDeep(actionData?.expectedWbas) : (values.rotation as any)?.wbas
                  }}
                  validationSchema={wbaValidationSchema}
                  onSubmit={values => console.log('onSubmit=>', values)}
                  innerRef={wbaFormik}
                >
                  {
                    (wbaFormikValues) => {
                      return <>
                        <h2>
                          <div> {t("Rla.expectedWBADetails")}</div>
                        </h2>
                        <div className="details-section section-border mt-3 table-responsive">
                          <table className="details-table wba-table table">
                            <thead>
                              <tr>
                                <th> {t("Rla.name")}</th>
                                <th> {t("Rla.expected")}</th>
                                <th> {t("Rla.planned")}</th>
                                <th> {t("Rla.completed")} </th>
                              </tr>
                            </thead>
                            <tbody>
                              <FieldArray name="exceptedWbas">
                                {() => {
                                  return <>
                                    {wbaFormikValues.values?.exceptedWbas?.length > 0 && (wbaFormikValues.values.exceptedWbas as any)?.map((wba: IWba, index) => {
                                      const planned = `exceptedWbas[${index}].planned`;
                                      const error = (wbaFormikValues.errors?.exceptedWbas?.[index] as any)?.planned;
                                      // const touch = getIn(touched, planned);
                                      const touch = (wbaFormikValues.touched?.exceptedWbas?.[index] as any)?.planned;
                                      return (
                                        <tr key={wba?.wbaId}>
                                          <td>{wba?.wbaName}</td>
                                          <td>
                                            <Input className="column-center"
                                              type="text"
                                              value={wba?.wbaExpected}
                                              disabled
                                            />
                                          </td>
                                          <td>
                                            <Field disabled={actionType === EOprationalActions.SELECT}
                                              onChange={(e) => {
                                                wbaFormikValues.setFieldValue(planned, e.target.value)
                                                console.log('updatedWbavalue==>', e.target.value)
                                                if (actionType === EOprationalActions.EDIT && actionData.expectedWbas[index].planned === e.target.value)
                                                  setFieldValue(`isMainFormTouched[${index}].planned`, actionData.expectedWbas[index].planned)
                                                else setFieldValue(`isMainFormTouched[${index}].planned`, e.target.value)
                                              }}
                                              placeholder="Enter Count"
                                              value={wbaFormikValues.values.exceptedWbas[index].planned}
                                              className={
                                                "form-control is-invalid column-center"
                                                // (touch && error ? " is-invalid" : "")
                                              }
                                              name={planned}
                                            />
                                            {actionType === EOprationalActions.ADD &&
                                              error &&
                                              touch && (
                                                <div className="text-danger mt-1">{error}</div>
                                              )}
                                            {actionType === EOprationalActions.EDIT &&
                                              error && (
                                                <div className="text-danger mt-1">{error}</div>
                                              )}
                                          </td>
                                          <td>
                                            <Input className="column-center" type="text" value={wba?.completed || '0'} disabled />
                                          </td>
                                        </tr>
                                      );
                                    })}
                                  </>
                                }}
                              </FieldArray>
                            </tbody>
                          </table>
                        </div>
                        <hr />
                      </>
                    }
                  }
                </Formik>

                {actionType !== EOprationalActions.SELECT && (
                  <div className="details-section">
                    <Row className="mt-3">
                      <Col sm="4">
                        <FormGroup>
                          <Label> {t("Rla.traineeSignature")}</Label><br />
                          <Field type="checkbox" name="check" />
                          {t("Rla.acceptanceofAgreement")}
                          <ErrorMessage
                            name="check"
                            component="div"
                            className="text-danger"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>
                )}
                {actionType === EOprationalActions.SELECT && (
                  <>
                    <div className="top-section">
                      <div className="details-section">
                        <Row className="vhcenter">
                          <Col sm="8" xs="12">
                            <h2> {t("Rla.1stRotationSupervisorDetails")}</h2>
                          </Col>
                          <Col sm="4" xs="12" className="column-center">
                            <span className="approvedDate">

                              {t("Rla.approvedon")}{" "}
                              <span className="date">
                                {
                                  actionData?.firstRotationalSupervisor
                                    ?.approvedOn
                                }
                              </span>
                            </span>
                          </Col>
                        </Row>
                        <div className="details-section">
                          <Row className="mt-3">
                            <Col sm="4">
                              <FormGroup>
                                <Label> {t("Rla.approvalStatus")}</Label>
                                <InputGroup className="disabled-item">
                                  <Input
                                    disabled
                                    value={
                                      actionData?.firstRotationalSupervisor
                                        ?.status
                                    }
                                  />
                                  <InputGroupAddon addonType="append">
                                    <InputGroupText>
                                      {actionData?.firstRotationalSupervisor
                                        ?.status ===
                                        EApprovelActions.APPROVED ? (
                                        <img
                                          src={Approved}
                                          className="icon"
                                          alt=""
                                        />
                                      ) : actionData?.firstRotationalSupervisor
                                        ?.status ===
                                        EApprovelActions.PENDING ? (
                                        <img
                                          src={pending}
                                          className="icon"
                                          alt=""
                                        />
                                      ) : actionData?.firstRotationalSupervisor
                                        ?.status ===
                                        EApprovelActions.REJECTED ? (
                                        <img src={reject} className="icon" alt="" />
                                      ) : (
                                        ""
                                      )}
                                    </InputGroupText>
                                  </InputGroupAddon>
                                </InputGroup>
                              </FormGroup>
                            </Col>

                            <Col sm="4">
                              <FormGroup>
                                <Label> {t("Rla.remarks")}</Label>
                                <Input
                                  placeholder={t("Rla.remarks")}
                                  type="text"
                                  disabled
                                  value={
                                    actionData?.firstRotationalSupervisor
                                      ?.comments
                                  }
                                ></Input>
                              </FormGroup>
                            </Col>

                            <Col sm="4">
                              <FormGroup>
                                <Label className="mr-2"> {t("Rla.signature")}</Label>
                                <Field type="checkbox" disabled name="firstRotationSupervisorSignature" />
                              </FormGroup>
                            </Col>
                          </Row>
                        </div>
                      </div>
                    </div>
                    <hr />

                    <div className="top-section">
                      <div className="details-section">
                        <Row className="vhcenter">
                          <Col sm="8" xs="12">
                            <h2> {t("Rla.2ndRotationSupervisorDetails")}</h2>
                          </Col>
                          <Col sm="4" xs="12" className="column-center">
                            <span className="approvedDate">
                              {t("Rla.approvedon")}{" "}
                              <span className="date">
                                {
                                  actionData?.secondRotationSupervisor
                                    ?.approvedOn
                                }
                              </span>
                            </span>
                          </Col>
                        </Row>
                        <div className="details-section">
                          <Row className="mt-3">
                            <Col sm="4">
                              <FormGroup>
                                <Label>{t("Rla.approvalStatus")}</Label>
                                <InputGroup className="disabled-item">
                                  <Input
                                    disabled
                                    value={
                                      actionData?.secondRotationSupervisor
                                        ?.status || '-'
                                    }
                                  />
                                  <InputGroupAddon addonType="append">
                                    <InputGroupText>

                                      {actionData?.secondRotationSupervisor
                                        ?.status ===
                                        EApprovelActions.APPROVED ? (
                                        <img
                                          src={Approved}
                                          className="icon"
                                          alt=""
                                        />
                                      ) : actionData?.secondRotationSupervisor
                                        ?.status ===
                                        EApprovelActions.PENDING ? (
                                        <img
                                          src={pending}
                                          className="icon"
                                          alt=""
                                        />
                                      ) : actionData?.secondRotationSupervisor
                                        ?.status ===
                                        EApprovelActions.REJECTED ? (
                                        <img src={reject} className="icon" alt="" />
                                      ) : (
                                        "-"
                                      )}
                                    </InputGroupText>
                                  </InputGroupAddon>
                                </InputGroup>
                              </FormGroup>
                            </Col>

                            <Col sm="4">
                              <FormGroup>
                                <Label>{t("Rla.remarks")}</Label>
                                <Input
                                  type="text"
                                  disabled
                                  placeholder={t("Rla.remarks")}
                                  value={
                                    actionData?.secondRotationSupervisor
                                      ?.comments
                                  }
                                ></Input>
                              </FormGroup>
                            </Col>

                            <Col sm="4">
                              <FormGroup>
                                <Label className="mr-2">{t("Rla.signature")}</Label>
                                <Field type="checkbox" disabled name="secondRotationSupervisorSignature" />
                              </FormGroup>
                            </Col>
                          </Row>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                <Row className="sub-form-footer mt-3 mr-3">
                  <div>

                    <button
                      className="btn cancel-button"
                      type="button"
                      onClick={cancel}
                    >

                      {t("ActionNames.cancel")}
                    </button>
                  </div>
                  {actionType !== EOprationalActions.SELECT && (
                    <div className="text-center mb-4">
                      <button
                        type='button'
                        onClick={() => saveOrUpdateRla(isValid, dirty, values, submitForm)}
                        disabled={actionType === EOprationalActions.EDIT ? !(dirty) : false}
                        className="btn blue-button"
                      >
                        {actionType === EOprationalActions.ADD ? t("ActionNames.create") : t("ActionNames.update")}
                      </button>
                    </div>
                  )}
                </Row>
              </div>
            </Form>

          )}
        </Formik>
      </div>
    </>
  );
};

export default React.memo(RlaAction);
