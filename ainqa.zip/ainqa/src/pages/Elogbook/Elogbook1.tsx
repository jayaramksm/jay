import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Pagination, PaginationItem, PaginationLink, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import DatePicker from "react-datepicker";
import EditIcon from '../../images/Edit.svg';
import Approved from '../../images/Approved.svg';
import Pending from '../../images/Pending.svg';
import View from '../../images/View.svg';
import Select from 'react-select';

class Elogbook1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            fileName: "No file Choosen",
            datevalue: new Date()
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this)
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    handleFileChange = (event) => {
        this.setState({ fileName: event.target.files[0].name })
    }

    yearOptions = [{ value: 'year1', label: 'Year 1' },
    { value: 'year2', label: 'Year 2' },
    { value: 'year3', label: 'Year 3' },
    { value: 'year4', label: 'Year 4' }];

    stageOptions = [{ value: 'stage1', label: 'StageI' },
    { value: 'stage2', label: 'StageII' },
    { value: 'stage3', label: 'StageIII' }];

    rotationOptions = [{ value: 'rotation1', label: 'Rotation1' },
    { value: 'rotation2', label: 'Rotation2' },
    { value: 'rotation3', label: 'Rotation3' },
    { value: 'rotation4', label: 'Rotation4' }];

    typeOptions = [{ value: 'formative', label: 'Formative' },
    { value: 'summative', label: 'Summative' }];

    subTypeOptions = [{ value: 'clinical', label: 'Clinical' },
    { value: 'technical', label: 'Technical' },
    { value: 'nontechnical', label: 'Non-Technical' }];

    hospitalOptions = [{ value: 'hospital1', label: 'Hospital 1' },
    { value: 'hospital2', label: 'Hospital 2' },
    { value: 'hospital3', label: 'Hospital 3' },
    { value: 'Other', label: 'Other' }];

    codeOptions = [{ value: 'WBA', label: 'WBA' },
    { value: 'FFMT', label: 'FFMT' },
    { value: 'CPD', label: 'CPD' },
    { value: 'CRS', label: 'CRS' }];

    subCodeOptions = [{ value: 'CBD', label: 'CBD' },
    { value: 'CEX', label: 'CEX' },
    { value: 'FFMT', label: 'FFMT' },
    { value: 'CTRF', label: 'CTRF' }];

    approvalOptions = [{ value: 'approve', label: 'Approve' },
    { value: 'reject', label: 'Reject' }];

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of Entries</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box">
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Add New Entry</button>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-2">
                            {/* View Entries */}
                            <div className="tbl-parent table-responsive">
                                <table className="w100 myTable elogbookTable table">
                                    <thead>
                                        <tr>
                                            <th>Year</th>
                                            <th>Stage</th>
                                            <th>Rotations</th>
                                            <th>Type</th>
                                            <th>Sub Type</th>
                                            <th>Code</th>
                                            <th>Sub Code</th>
                                            <th>Due Date</th>
                                            <th>Completed Date</th>
                                            <th>Approver Name</th>
                                            <th className="column-center">Approval Status</th>
                                            <th>Approval Date</th>
                                            <th className="column-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Year1</td>
                                            <td>StageI</td>
                                            <td>Rotation1</td>
                                            <td>Formative</td>
                                            <td>Clinical</td>
                                            <td>WBA</td>
                                            <td>CBD</td>
                                            <td>05-06-2021</td>
                                            <td>05-06-2021 15:03</td>
                                            <td>Dr.Andrew</td>
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                            <td>05-06-2021</td>
                                            <td className="column-center">
                                                <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Year2</td>
                                            <td>StageI</td>
                                            <td>Rotation2</td>
                                            <td>Summative</td>
                                            <td>Technical</td>
                                            <td>FFMT</td>
                                            <td>CEX</td>
                                            <td>06-06-2021</td>
                                            <td>06-06-2021 13:03</td>
                                            <td>Dr.Marque</td>
                                            <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                            <td>06-06-2021</td>
                                            <td className="column-center">
                                                <img src={View} className="actionicon pointer" alt=""></img>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="pagination">
                                <Pagination aria-label="Page navigation example">
                                    <PaginationItem>
                                        <PaginationLink first href="#" />
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink previous href="#" />
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink href="#">
                                            1
                                        </PaginationLink>
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink href="#">
                                            2
                                        </PaginationLink>
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink href="#">
                                            3
                                        </PaginationLink>
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink next href="#" />
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink last href="#" />
                                    </PaginationItem>
                                </Pagination>
                            </div>
                            {/* View Entries End */}
                            {/* Add Entry */}
                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Entries</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Add Entry</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="top-section">
                                <div className="details-section">
                                    <Row className="mt-3">
                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Year</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.yearOptions}
                                                    placeholder="Select Year"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Stage</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.stageOptions}
                                                    placeholder="Select Stage"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Rotation</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.rotationOptions}
                                                    placeholder="Select Rotation"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Select Hospital</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.hospitalOptions}
                                                    placeholder="Select Hospital"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label for="otherhospital" >Other Hospital</Label>
                                                <Input type="text" value="-" placeholder="Enter Hospital Name" name="otherhospital" disabled id="otherhospital">
                                                </Input>
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Type</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.typeOptions}
                                                    placeholder="Select Type"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Sub Type</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.subTypeOptions}
                                                    placeholder="Select Sub Type"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Code</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.codeOptions}
                                                    placeholder="Select Code"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Sub Code</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.subCodeOptions}
                                                    placeholder="Select Sub Code"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Completed Date</Label>
                                                <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Due Date</Label>
                                                <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Remarks</Label>
                                                <textarea rows={1} className="comments" placeholder="Write down here"></textarea>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                            </div>
                            <hr />
                            <div className="top-section">
                                <h2>Artifact Uploads</h2>
                                <div className="details-section mt-3">
                                    <Row>
                                        <div className="upload-btn w400">
                                            <FormGroup>
                                                <input type="file" id="actual-btn" hidden onChange={(e) => this.handleFileChange(e)} />
                                                <div id="blockele">
                                                    <div className="d-flex flex-row" id="file-chosen"><div className="mr-2"><i className="ti-folder"></i> Select File</div></div>
                                                    <label htmlFor="actual-btn" className="choose">Upload File</label>
                                                </div>
                                                <div className="fileuplod-note">* jpg, jpeg, png File only</div>
                                            </FormGroup>
                                        </div>
                                        <Col className="NewDelBtn"><span><i className="ti-plus"></i> Add New</span></Col>
                                    </Row>
                                    <Row>
                                        <div className="ArtifactName w400">
                                            <span>Operation procedure_WBA-01.jpg </span>
                                        </div>
                                        <Col className="NewDelBtn text-danger"><span><i className="ti-trash"></i> Delete</span></Col>
                                    </Row>
                                </div>
                            </div>
                            <hr />
                            {/* Approvar View */}
                            <div className="top-section">
                                <Row className="mr-3 align-items-center">
                                    <Col sm="6" xs="12">
                                        <h2 className="mt-0">Approval Details</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate">Approved on : <span className="date">10/06/2021</span></span>
                                    </Col>
                                </Row>
                                <div className="details-section mt-3">
                                    <Row className="mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Approval Status</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.approvalOptions}
                                                    placeholder="Select Approval" />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Remarks</Label>
                                                <textarea placeholder="Write down here" className="comments" rows={1}></textarea>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row className="sub-form-footer mt-3">
                                        <button className="cancel-button">Cancel</button>&nbsp;<button className="blue-button">Create</button>
                                    </Row>
                                </div>
                            </div>
                            {/* Approvar View End */}

                            {/* Add Entry end */}
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(Elogbook1));