import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Pagination, PaginationItem, PaginationLink, UncontrolledCollapse, Modal, ModalHeader, ModalBody, Button, CustomInput } from 'reactstrap';
import { activateNonAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import DatePicker from "react-datepicker";
import DownToggle from '../../images/down_toggle.svg';
import Select from 'react-select';
import '../../scss/feedback.scss';
import FeedbackLogo from '../../images/Logo.png';


class EvaluatorFeedback1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            fileName: "No file Choosen",
            datevalue: new Date(),
            isFeedback:false,
            isModel: false
        };
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.props.activateNonAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    handleClick = (e: any) => {
        this.setState({ isFeedback: !this.state.isFeedback });
    };

      render() {
        return (
            <React.Fragment>
                 <Modal className="modal-md feedbackmodal" isOpen={this.state.isModel}>
                    <ModalHeader style={{border:"0"}}>
                        <div className="modal-close"><button className="btn btn-danger" onClick={() => this.setState({ isModel: !this.state.isModel })}><i className="ti-close"></i></button></div>
                    </ModalHeader>
                    <ModalBody>
                    <div className="text-center">
                        <div>Do you want to proceed to submit ?</div>
                        <div className="fbmodal-footer">
                            <div className="fbmodal-buttons"><button className="btn fb-cancel-button-border">Cancel</button><button className="btn fb-proceed-button">Submit</button></div>
                            <div className="fbmodal-note">* Once submitted, the feedback form can't be edited and link will not work !</div>
                        </div>
                    </div>
                    </ModalBody>
                </Modal>
               <div className="container-fluid p-0" style={{height: "100%"}}>
                   <Row style={{height: "100%"}}>
                   <Col>
                    <div className="feeback-logo">
                        <img src={FeedbackLogo} alt="" width="170" />
                    </div>
                    <div className="student-details">
                        <dl>
                            <dt>Trainee Name</dt>
                            <dd>Johnny Depp</dd>
                        </dl>
                        <dl>
                            <dt>Program</dt>
                            <dd>Family Medicine</dd>
                        </dl>
                        <dl>
                            <dt>Stage</dt>
                            <dd>Stage II</dd>
                        </dl>
                        <dl>
                            <dt>Rotation</dt>
                            <dd>Rotation 01</dd>
                        </dl>
                        <dl>
                            <dt>Form Type</dt>
                            <dd>Case Based Discussion form</dd>
                        </dl>
                    </div>
                   </Col>

                   <Col className="d-flex align-items-center">
                   <div className="form-view">
                       <div className="form-view-header">
                        <h1>{this.state.isFeedback ? "Evaluator Feedback Form" : "Case Based Discussion Form" }</h1>
                        <span onClick={this.handleClick} className="header-link"><i className="ti-angle-left"></i>&nbsp;{this.state.isFeedback ? "Trainee Form" : "Feedback Form" }</span>
                       </div>
                       <div className="form-view-content">
                           <div className="form-view-pad pb-4">
                           
                           <div className="px-4 mt-2">
                           {!this.state.isFeedback &&
                            <div>
                            <div className="form-expander">
                                <h6>Assessment Details</h6> <img src={DownToggle} id="assessment-details" />
                            </div>
                            <UncontrolledCollapse toggler="#assessment-details" className="pt-2" defaultOpen>
                                <Row>
                                    <Col sm="6">
                                        <FormGroup className="dp100">
                                            <Label>Assessment Date</Label>
                                            <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />                                          
                                        </FormGroup>
                                    </Col>

                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Evaluator</Label>
                                            <Input disabled type="text" placeholder="info@gmail.com"></Input>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Hospital</Label>
                                            <Input disabled type="text" placeholder="Montec Hospital"></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Patient Registration ID</Label>
                                            <Input disabled type="text" placeholder="R1232323"></Input>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Clinical Setting</Label>
                                            <Input disabled type="text" placeholder=""></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Emergency / Elective</Label>
                                            <Input disabled type="text" placeholder="Effective"></Input>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="my-3">
                                    <Col sm="12">
                                        <span className="highlight">Performed in a simulated setting or on a Workshop ?</span>  
                                        <div className="float-right">
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                        </div>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>Summary of the problem / case (Please ensure confidentiality of patient information)</Label>
                                            <textarea disabled className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>Topics Covered</Label>
                                            <textarea disabled className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </UncontrolledCollapse>

                            <div className="form-expander"><h6>Trainee Reflections</h6><img src={DownToggle} id="trainee-reflections" /></div>
                            <UncontrolledCollapse toggler="#trainee-reflections" className="pt-2" defaultOpen>
                                <Row className="mt-2">
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What did I learn from this experience ?</Label>
                                            <textarea disabled className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What did I do Well ?</Label>
                                            <textarea disabled className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What do I need to imporve or change? How will I achieve it ?</Label>
                                            <textarea disabled className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row className="my-3">
                                    <Col>
                                       <span className="highlight">Can this WBA be associated with the Entrusted Professional Activities (EPA)?</span>
                                    </Col>
                                    <div  className="text-right pr-3">
                                           <FormGroup check inline>
                                        <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </div>
                                </Row>

                                <Row className="pl-2">
                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Please Select the Component</Label>
                                            <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Component"
                                                isDisabled={true}
                                            />
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row>
                                <Col>Please Select atleast one domain form the given:</Col>
                                </Row>
                                    <Row className="mt-2">
                                    <Col>
                                        <span className="highlight">a) Cognitive (Knowledge: Facts and Information)</span>
                                    </Col>
                                    <div className="text-right pr-3">
                                        <FormGroup check inline>
                                            <Label check >
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </div>
                                    </Row>
                                    <Row className="mt-2">
                                    <Col sm="12">
                                        <FormGroup>
                                            <span>What are the cognitive components you have demonstrated or learnt from this case ?</span>
                                            <textarea disabled className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                    </Row>
                                    <Row className="mt-2">
                                    <Col>
                                    <span className="highlight">b) Psychomotor (Do: Practical, technical skills)</span>
                                    </Col>
                                    <div className="text-right pr-3">
                                    <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </div>
                                    </Row>

                                    <Row className="mt-2">
                                    <Col>
                                    <span className="highlight"> c) Affective (Feel: Attitudes and values, behaviours displaying underlying values)</span> 
                                    </Col>
                                    <div className="text-right pr-3">
                                    <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </div>
                                    </Row>

                                    <Row className="mt-2">
                                    <Col sm="12">
                                        <FormGroup>
                                            <span>What are the affective components you have demonstrated or learnt from this case ?</span>
                                            <textarea disabled className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </UncontrolledCollapse>
                            </div>
      }
                              
                            {this.state.isFeedback &&
                              <div className="mt-4">
                                     <div className="form-expander">
                                        <h6>Normal</h6> <img src={DownToggle} />
                                    </div>
                                    <Row className="mt-3">
                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>General</Label>
                                                <Input type="text" placeholder="Write here"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>Strengths</Label>
                                                <Input type="text" placeholder="Good Attitued, Quick Learner"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>Development Needs</Label>
                                                <Input type="text" placeholder="Write here"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>Recommended Actions</Label>
                                                <Input type="text" placeholder="Write here"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <div className="form-expander">
                                        <h6>Ratings <small className="ratings-information">(Not Observed / Assessed - <strong>N</strong> or Unsatisfactory - <strong>U</strong> or Satisfactory - <strong>S</strong>)</small></h6> <img src={DownToggle} id="ratings" />
                                    </div>
                                    <UncontrolledCollapse toggler="#ratings" className="pt-2 ratings" defaultOpen>
                                        <Row>
                                            <Col></Col>
                                            <div className="ratings-heading mr-4">
                                                <span>N</span>
                                                <span>U</span>
                                                <span>S</span>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Clinical assessment? *</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-assessment" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-assessment" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-assessment" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Diagnostic skills and underlying knowledge base ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="diagnostic-skill" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="diagnostic-skill" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="diagnostic-skill" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Management and follow-up planning ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="mgmt-followup" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="mgmt-followup" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="mgmt-followup" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Clinical judgement and decision making ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-judgement" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-judgement" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-judgement" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Leadership skills ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="leadership-skills" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="leadership-skills" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="leadership-skills" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Reflective practice/writing ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="reflective-practice" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="reflective-practice" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="reflective-practice" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Medical record keeping ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="medical-record" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="medical-record" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="medical-record" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                    </UncontrolledCollapse>

                                    <div className="form-expander mt-3">
                                        <h6>Global Summary of Performance</h6> <img src={DownToggle} id="global-summary" />
                                    </div>
                                    <UncontrolledCollapse toggler="#global-summary" className="pt-2 fb-global-summary" defaultOpen>
                                        <ul>
                                            <li>
                                                <CustomInput type="switch" id="knowledge-level" name="knowledge-level" label="Knowledge Level" />
                                            </li>
                                            <li>
                                                <CustomInput type="switch" id="skill-level" name="skill-level" label="Skill Level" />
                                            </li>
                                            <li>
                                                <CustomInput type="switch" id="professional-behaviours" name="professional-behaviours" label="Professional Behaviours" />
                                                <ul>
                                                    <li className="light-text">Select the applicable Options</li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Poor - <span className="light-text">endangered, or potentially endangered patient safety, serious remediation required</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Marginal - <span className="light-text">cause for concern, considerable improvement needed</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Accpetable - <span className="light-text">satisfactory, could be improved</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Good - <span className="light-text">consistently high standard, enhanced patient safety, example to others</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </UncontrolledCollapse>
                            </div>
                        }
                        </div>
                           </div>
                       </div>
                       <div className="form-view-footer">
                            {!this.state.isFeedback &&
                           <button className="btn fb-button" onClick={this.handleClick}>Provide Feedback</button>
                            }
                            {this.state.isFeedback &&
                            <div className="action-buttons">
                           <button className="btn fb-cancel-button" onClick={this.handleClick}>Cancel</button>
                           <button className="btn fb-proceed-button" onClick={() => this.setState({ isModel: !this.state.isModel })}>Submit</button>
                           </div>
                            }
                       </div>
                   </div>
                   </Col>
                   </Row>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateNonAuthLayout })(EvaluatorFeedback1));