import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Pagination, PaginationItem, PaginationLink, UncontrolledCollapse, Modal, ModalHeader, ModalBody, Button, CustomInput } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import DatePicker from "react-datepicker";
import EditIcon from '../../images/Edit.svg';
import Approved from '../../images/Approved.svg';
import Pending from '../../images/Pending.svg';
import View from '../../images/View.svg';
import DownToggle from '../../images/down_toggle.svg';
import deleteIcon from '../../images/Delete.svg';
import Select from 'react-select';

class Portfolio1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            fileName: "No file Choosen",
            datevalue: new Date(),
            isModel: false
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this)
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    handleFileChange = (event) => {
        this.setState({ fileName: event.target.files[0].name })
    }

    yearOptions = [{ value: 'year1', label: 'Year 1' },
    { value: 'year2', label: 'Year 2' },
    { value: 'year3', label: 'Year 3' },
    { value: 'year4', label: 'Year 4' }];

    stageOptions = [{ value: 'stage1', label: 'StageI' },
    { value: 'stage2', label: 'StageII' },
    { value: 'stage3', label: 'StageIII' }];

    rotationOptions = [{ value: 'rotation1', label: 'Rotation1' },
    { value: 'rotation2', label: 'Rotation2' },
    { value: 'rotation3', label: 'Rotation3' },
    { value: 'rotation4', label: 'Rotation4' }];

    typeOptions = [{ value: 'formative', label: 'Formative' },
    { value: 'summative', label: 'Summative' }];

    subTypeOptions = [{ value: 'clinical', label: 'Clinical' },
    { value: 'technical', label: 'Technical' },
    { value: 'nontechnical', label: 'Non-Technical' }];

    hospitalOptions = [{ value: 'hospital1', label: 'Hospital 1' },
    { value: 'hospital2', label: 'Hospital 2' },
    { value: 'hospital3', label: 'Hospital 3' },
    { value: 'Other', label: 'Other' }];

    codeOptions = [{ value: 'WBA', label: 'WBA' },
    { value: 'FFMT', label: 'FFMT' },
    { value: 'CPD', label: 'CPD' },
    { value: 'CRS', label: 'CRS' }];

    subCodeOptions = [{ value: 'CBD', label: 'CBD' },
    { value: 'CEX', label: 'CEX' },
    { value: 'FFMT', label: 'FFMT' },
    { value: 'CTRF', label: 'CTRF' }];

    approvalOptions = [{ value: 'approve', label: 'Approve' },
    { value: 'reject', label: 'Reject' }];

    render() {
        return (
            <React.Fragment>
                {/* cbd Form starts */}
                <Modal className="modal-lg glamodal" isOpen={this.state.isModel} style={{ margin: "0 auto" }}>
                    <ModalHeader style={{ position: "sticky", top: 0, zIndex: 3, background: "#ffffff", borderRadius: "0" }}>
                        <div className="text-center">Case Based Discussion (CBD) Form</div>
                        <div className="modal-close"><button className="btn btn-danger" onClick={() => this.setState({ isModel: !this.state.isModel })}><i className="ti-close"></i></button></div>
                    </ModalHeader>
                    <ModalBody>
                        <div className="px-4">
                            <div className="form-expander">
                                <h6>Assessment Details</h6> <img src={DownToggle} id="assessment-details" />
                            </div>
                            <UncontrolledCollapse toggler="#assessment-details" className="pt-2" defaultOpen>
                                <Row>
                                    <Col sm="6">
                                        <FormGroup className="dp100">
                                            <Label>Assessment Date</Label>
                                            <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />                                          
                                        </FormGroup>
                                    </Col>

                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Evaluator</Label>
                                            <Input type="text" placeholder=""></Input>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Hospital</Label>
                                            <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Hospital"
                                            />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Patient Registration ID</Label>
                                            <Input type="text" placeholder=""></Input>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Clinical Setting</Label>
                                            <Input type="text" placeholder=""></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Emergency / Elective</Label>
                                            <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Emergency"
                                            />
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="my-3">
                                    <Col sm="12">
                                        <span className="highlight">Performed in a simulated setting or on a Workshop ?</span>  <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>Summary of the problem / case (Please ensure confidentiality of patient information)</Label>
                                            <textarea className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>Topics Covered</Label>
                                            <textarea className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </UncontrolledCollapse>

                            <div className="form-expander"><h6>Trainee Reflections</h6><img src={DownToggle} id="trainee-reflections" /></div>
                            <UncontrolledCollapse toggler="#trainee-reflections" className="pt-2" defaultOpen>
                                <Row className="mt-2">
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What did I learn from this experience ?</Label>
                                            <textarea className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What did I do Well ?</Label>
                                            <textarea className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What do I need to imporve or change? How will I achieve it ?</Label>
                                            <textarea className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row className="my-3">
                                    <Col sm="12">
                                       <span className="highlight">Can this WBA be associated with the Entrusted Professional Activities (EPA) ?</span><FormGroup check inline className="ml-3">
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row className="pl-2">
                                    <Col sm="6">
                                        <FormGroup>
                                            <Label>Please Select the Component</Label>
                                            <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Component"
                                            />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="12" className="mt-2">
                                        <span>Please Select atleast one domain form the given:</span><br />
                                        <span className="highlight">a) Cognitive (Knowledge: Facts and Information)</span><FormGroup check inline className="ml-3">
                                            <Label check >
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </Col>
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What are the cognitive components you have demonstrated or learnt from this case ?</Label>
                                            <textarea className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                    <Col sm="12" className="mt-2">
                                    <span className="highlight">b) Psychomotor (Do: Practical, technical skills)</span><FormGroup check inline className="ml-3">
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </Col>
                                    <Col sm="12" className="mt-2">
                                    <span className="highlight"> c) Affective (Feel: Attitudes and values, behaviours displaying underlying values)</span> <FormGroup check inline className="ml-3">
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} Yes
                                            </Label>
                                        </FormGroup>
                                        <FormGroup check inline>
                                            <Label check>
                                                <Input type="radio" name="simulatedsetting" />{' '} No
                                            </Label>
                                        </FormGroup>
                                    </Col>
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label>What are the affective components you have demonstrated or learnt from this case ?</Label>
                                            <textarea className="comments form-control" rows={1} placeholder="Write here"></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </UncontrolledCollapse>
                            <div className="form-footer text-right mt-3">
                                <button className="btn feedback-button">Save as Draft</button>
                                <button className="btn cancel-button">Cancel</button>
                                <button className="btn proceed-button">Proceed</button>
                            </div>

                            <div className="mt-4">
                                <a href="#" id="feedback-details">View Feedback Details &gt; </a>
                                <UncontrolledCollapse toggler="#feedback-details" className="pt-2">
                                    <div className="form-expander">
                                        <h6>Normal</h6> <img src={DownToggle} />
                                    </div>
                                    <Row className="mt-3">
                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>General</Label>
                                                <Input type="text" placeholder="Write here" disabled></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>Strengths</Label>
                                                <Input type="text" placeholder="Good Attitued, Quick Learner" disabled></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>Development Needs</Label>
                                                <Input type="text" placeholder="Write here" disabled></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>Recommended Actions</Label>
                                                <Input type="text" placeholder="Write here" disabled></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <div className="form-expander">
                                        <h6>Ratings <small className="ratings-information">(Not Observed / Assessed - <strong>N</strong> or Unsatisfactory - <strong>U</strong> or Satisfactory - <strong>S</strong>)</small></h6> <img src={DownToggle} id="ratings" />
                                    </div>
                                    <UncontrolledCollapse toggler="#ratings" className="pt-2 ratings" defaultOpen>
                                        <Row>
                                            <Col></Col>
                                            <div className="ratings-heading mr-4">
                                                <span>N</span>
                                                <span>U</span>
                                                <span>S</span>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Clinical assessment? *</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-assessment" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-assessment" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-assessment" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Diagnostic skills and underlying knowledge base ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="diagnostic-skill" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="diagnostic-skill" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="diagnostic-skill" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Management and follow-up planning ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="mgmt-followup" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="mgmt-followup" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="mgmt-followup" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Clinical judgement and decision making ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-judgement" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-judgement" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="clinical-judgement" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Leadership skills ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="leadership-skills" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="leadership-skills" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="leadership-skills" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Reflective practice/writing ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="reflective-practice" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="reflective-practice" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="reflective-practice" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                        <Row>
                                            <Col>Medical record keeping ?</Col>
                                            <div>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="medical-record" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="medical-record" />{' '}
                                                    </Label>
                                                </FormGroup>
                                                <FormGroup check inline>
                                                    <Label check>
                                                        <Input type="radio" name="medical-record" />{' '}
                                                    </Label>
                                                </FormGroup>
                                            </div>
                                        </Row>
                                    </UncontrolledCollapse>

                                    <div className="form-expander mt-3">
                                        <h6>Global Summary of Performance</h6> <img src={DownToggle} id="global-summary" />
                                    </div>
                                    <UncontrolledCollapse toggler="#global-summary" className="pt-2 global-summary" defaultOpen>
                                        <ul>
                                            <li>
                                                <CustomInput type="switch" id="knowledge-level" name="knowledge-level" label="Knowledge Level" />
                                            </li>
                                            <li>
                                                <CustomInput type="switch" id="skill-level" name="skill-level" label="Skill Level" />
                                            </li>
                                            <li>
                                                <CustomInput type="switch" id="professional-behaviours" name="professional-behaviours" label="Professional Behaviours" />
                                                <ul>
                                                    <li className="light-text">Select the applicable Options</li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Poor - <span className="light-text">endangered, or potentially endangered patient safety, serious remediation required</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Marginal - <span className="light-text">cause for concern, considerable improvement needed</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Accpetable - <span className="light-text">satisfactory, could be improved</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                    <li>
                                                    <FormGroup check>
                                                    <Label check>
                                                        <Input type="radio" name="pbehaviours" />{' '}
                                                        Good - <span className="light-text">consistently high standard, enhanced patient safety, example to others</span>
                                                    </Label>
                                                </FormGroup>    
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    
                                    </UncontrolledCollapse>

                                </UncontrolledCollapse>
<div className="text-right mt-3"><Button className="bluebutton">Back</Button></div>
                            </div>
                        </div>
                    </ModalBody>
                </Modal>
                {/* cbd Form ends */}

                {/* Portfolio layout starts */}
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col className="draftsheading">
                            <h3 className="page-header header-title">List of Entries</h3>
                            <div className="entry-actions"><span className="action-active">Submitted</span>  &nbsp;| &nbsp;  Drafts</div>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Add New Entry</button>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-2">
                            {/* View Entries */}
                            <div className="tbl-parent table-responsive">
                                <table className="w100 myTable elogbookTable table">
                                    <thead>
                                        <tr>
                                            <th>Stage</th>
                                            <th>Rotations</th>
                                            <th>Code</th>
                                            <th>Sub Code</th>
                                            <th>ELA/EPA</th>
                                            <th>Assessed/Non-Assessed</th>
                                            <th>1st Rotational Supervisor</th>
                                            <th>1st Supervisor Approval Status</th>
                                            <th>2nd Rotational Supervisor</th>
                                            <th>2nd Supervisor Approval Status</th>
                                            <th>Final Approval Date</th>
                                            <th className="column-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>StageI</td>
                                            <td>Rotation1</td>
                                            <td>WBA</td>
                                            <td>CBD</td>
                                            <td>Initial..</td>
                                            <td>Assessed</td>
                                            <td>Aisha</td>
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                            <td>Dr.Andrew</td>
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                            <td>05-06-2021</td>
                                            <td className="column-center">
                                                <img src={View} className="actionicon pointer" alt=""></img>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>StageI</td>
                                            <td>Rotation2</td>
                                             <td>WBA</td>
                                            <td>CBD</td>
                                            <td>Initial</td>
                                            <td>Non Assessed</td>
                                            <td>Irfan</td>
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                            <td>Dr.Marque</td>
                                            <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                            <td>06-06-2021</td>
                                            <td className="column-center">
                                                <img src={View} className="actionicon pointer" alt=""></img>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="pagination">
                                <Pagination aria-label="Page navigation example">
                                    <PaginationItem>
                                        <PaginationLink first href="#" />
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink previous href="#" />
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink href="#">
                                            1
                                        </PaginationLink>
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink href="#">
                                            2
                                        </PaginationLink>
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink href="#">
                                            3
                                        </PaginationLink>
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink next href="#" />
                                    </PaginationItem>
                                    <PaginationItem>
                                        <PaginationLink last href="#" />
                                    </PaginationItem>
                                </Pagination>
                            </div>
                            {/* View Entries End */}

                            {/* Drafts Table */}
                            <div className="tbl-parent table-responsive">
                                <table className="w100 myTable elogbookTable table">
                                    <thead>
                                        <tr>
                                            <th>Stage</th>
                                            <th>Rotations</th>
                                            <th>Code</th>
                                            <th>Sub Code</th>
                                            <th>ELA/EPA</th>
                                            <th>Assessed/Non-Assessed</th>
                                            <th>1st Rotational Supervisor</th>
                                            <th>2nd Rotational Supervisor</th>
                                            <th className="column-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>StageI</td>
                                            <td>Rotation1</td>
                                            <td>WBA</td>
                                            <td>CBD</td>
                                            <td>Initial..</td>
                                            <td>Assessed</td>
                                            <td>Aisha</td>
                                           <td>Dr.Andrew</td>
                                            <td className="column-center">
                                                <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>StageI</td>
                                            <td>Rotation2</td>
                                             <td>WBA</td>
                                            <td>CBD</td>
                                            <td>Initial</td>
                                            <td>Non Assessed</td>
                                            <td>Irfan</td>
                                            <td>Dr.Marque</td>
                                            <td className="column-center">
                                                <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            {/* Drafts Table End */}
                            {/* Add Entry */}
                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Entries</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Add Entry</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="top-section">
                                <div className="details-section">
                                    <Row className="mt-3">
                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Stage</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.stageOptions}
                                                    placeholder="Select Stage"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Rotation</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.rotationOptions}
                                                    placeholder="Select Rotation"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Hospital</Label>
                                                <Input type="text" value="Montek Hospital" name="hospital" disabled id="hospital"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Code</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.codeOptions}
                                                    placeholder="Select Code"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Sub Code</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.subCodeOptions}
                                                    placeholder="Select Sub Code"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Due Date</Label>
                                                <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>Completed Date</Label>
                                                <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                            </FormGroup>
                                        </Col>


                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>1st Rotational Supervisor</Label>
                                                <Input type="text" value="Irfan" name="rsupervisorone" disabled></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup>
                                                <Label>2nd Rotational Supervisor</Label>
                                                <Input type="text" value="Aisha" name="rsupervisortwo" disabled></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col lg="4" sm="6" xs="12">
                                            <FormGroup check className="assessed">
                                                    <Label check>
                                                        <Input type="checkbox" />{' '}
                                                        This will be part of Assessed
                                                    </Label>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                            </div>
                            <hr />
                            <div className="top-section">
                                <h2>Artifact Uploads</h2>
                                <div className="details-section mt-3">
                                    <Row>
                                        <div className="upload-btn w400">
                                            <FormGroup>
                                                <input type="file" id="actual-btn" hidden onChange={(e) => this.handleFileChange(e)} />
                                                <div id="blockele">
                                                    <div className="d-flex flex-row" id="file-chosen"><div className="mr-2"><i className="ti-folder"></i> Select File</div></div>
                                                    <label htmlFor="actual-btn" className="choose">Upload File</label>
                                                </div>
                                                <div className="fileuplod-note">* jpg, jpeg, png File only</div>
                                            </FormGroup>
                                        </div>
                                        <Col className="NewDelBtn"><span><i className="ti-plus"></i> Add File</span></Col>
                                    </Row>
                                    <Row>
                                        <div className="ArtifactName w400">
                                            <span>Operation procedure_WBA-01.jpg </span>
                                        </div>
                                        <Col className="NewDelBtn text-danger"><span><i className="ti-trash"></i> Delete</span></Col>
                                    </Row>
                                </div>
                            </div>
                            <hr />
                            <div className="top-section">
                                <div className="details-section mt-3">
                                    <h2>Workplace based assessment Details</h2>
                                    <div className="add-button mt-3" onClick={() => this.setState({ isModel: !this.state.isModel })}>
                                        <div className="button-text">Case Based Discussion Form</div>
                                        <div className="note">* Please fill the form details</div>
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div className="tbl-parent table-responsive">
                                <table className="w100 myTable cbdform-table table">
                                    <thead>
                                        <tr>
                                            <th>Workplace based Assessment Name</th>
                                            <th className="column-center">Actions</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Case Based Discussion (CBD) Form</td>
                                              <td className="column-center">
                                                <img src={View} className="actionicon pointer" alt=""></img>
                                                <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                <img src={deleteIcon} className="actionicon pointer" alt=""></img>
                                            </td>
                                            <td>
                                                <button className="btn reminder-button">Reminder</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            {/* Approvar View */}
                            <div className="top-section">
                                <Row className="mr-3 align-items-center">
                                    <Col sm="6" xs="12">
                                        <h2 className="mt-0">Approval Details</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate">Approved on : <span className="date">10/06/2021</span></span>
                                    </Col>
                                </Row>
                                <div className="details-section mt-3">
                                    <Row className="mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Approval Status</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.approvalOptions}
                                                    placeholder="Select Approval" />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Approver Name</Label>
                                                <Input type="text" placeholder="Irfan" disabled></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Comments</Label>
                                                <textarea placeholder="Write down here" className="comments" rows={1}></textarea>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row className="sub-form-footer mt-3">
                                        <button className="cancel-button">Cancel</button>&nbsp;<button className="blue-button">Create</button>
                                    </Row>
                                </div>
                            </div>
                            {/* Approvar View End */}

                            {/* Add Entry end */}

                             {/* Rotational Supervisor Trainee names list table start */}
                             <div className="tbl-parent table-responsive">
                                <table className="w100 myTable elogbookTable table">
                                    <thead>
                                        <tr>
                                            <th>Trainee Name</th>
                                            <th>Program Name</th>
                                            <th>Stage</th>
                                            <th>Rotations</th>
                                            <th className="column-center">Approval Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><a href="#" className="ActionStatus">Johnny Depp</a></td>
                                            <td>Family Medicine</td>
                                            <td>Stage I</td>
                                            <td>Rotation 01</td>                                            
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                        </tr>
                                        <tr>
                                             <td><a href="#" className="ActionStatus">Bunni</a></td>
                                            <td>General Surgery</td>
                                            <td>Stage II</td>
                                            <td>Rotation 01</td>                                            
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            {/* Rotational Supervisor Trainee names list table End */}

                             {/* Rotational Supervisor each Trainee drilldown list table start */}
                             <div className="tbl-parent table-responsive">
                             <table className="w100 myTable elogbookTable table">
                                    <thead>
                                        <tr>
                                            <th>Stage</th>
                                            <th>Rotations</th>
                                            <th>Code</th>
                                            <th>Sub Code</th>
                                            <th className="column-center">Feedback Status</th>
                                            <th className="column-center">Approval Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Stage I</td>
                                            <td>Rotation 01</td>
                                            <td>WBA</td>
                                            <td>CBD</td>
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                            <td>
                                                <a href="#" className="actiontext">View</a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Stage II</td>
                                            <td>Rotation 01</td>
                                            <td>WBA</td>
                                            <td>CBD</td>
                                            <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                            <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                            <td>
                                                <a href="#" className="actiontext">View</a>&nbsp;&nbsp;&nbsp;&nbsp;
                                                <a href="#" className="actiontext">Mark Status</a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            {/* Rotational Supervisor each Trainee drilldown list table End */}
                        </div>
                    </div>
                </div>
                 {/* Portfolio layout ends */}
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(Portfolio1));