import React, { Component } from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

class PointofContact1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {

        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    render() {

        return (
            <React.Fragment>
                <div className="flexLayout">
                    <div className="flexScroll">
                            <div className="mydocuments pr-3">
                                <h3 className="page-header">Contact Details</h3>

                                <div className="tbl-parent table-responsive">
                                    <table className="myTable pointof-contact-table table">
                                        <thead>
                                            <tr>
                                                <th>Name of Role</th>
                                                <th> Name of Supervisor</th>
                                                <th>Email ID</th>
                                                <th>Contact Number</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Education Supervisor</td>
                                                <td>Aisha</td>
                                                <td><a className="file-name" href='#'> aisha@eportpolio.com</a></td>
                                                <td>9857545875</td>

                                            </tr>
                                            <tr>
                                                <td>MOH Supervisor</td>
                                                <td>Azman</td>
                                                <td><a className="file-name" href='#'> azman@eportpolio.com</a></td>
                                                <td>9857545876</td>
                                            </tr>
                                            <tr>
                                                <td>Clinical Supervisor</td>
                                                <td>Irfan</td>
                                                <td><a className="file-name" href='#'> irfan@eportpolio.com</a></td>
                                                <td>9857545878</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                </div>

            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(PointofContact1));