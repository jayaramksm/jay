import * as React from 'react';
import {Row, Col} from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import studyimg from '../../images/study-img.svg';

class Dashboard1 extends React.Component<any, any>{
    constructor(props: any) {
        super(props);
        this.state = {
            showUpcoming: false,
            showOverdue: false,
        };
        this.showUpcoming = this.showUpcoming.bind(this);
        this.showOverdue = this.showOverdue.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    showUpcoming() {
        this.setState({ showUpcoming: !this.state.showUpcoming })
        this.setState({ showOverdue: false })
    }

    showOverdue() {
        this.setState({ showOverdue: !this.state.showOverdue })
        this.setState({ showUpcoming: false })
    }

    render() {

        return (
            <React.Fragment>
                <Row className="dashboarparent">
                    <Col sm="9" xs="12" className="user-details-dashboard">
                        <div className="welcome-note">
                            <div className="student-note">
                                <h4>Hi, Johnny Dep</h4>
                                <h2>Welcome Back</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad</p>
                            </div>
                            <div className="background-img">
                                <img src={studyimg} alt="" />
                            </div>
                        </div>
                    </Col>
                    <Col sm="3" xs="12" className="tasks-parent pl-0">
                        <div className="accordion-parent upcoming">
                            <div className="btn btn-green accordion"><h6>Upcoming Tasks</h6> <div className="pointer" onClick={this.showUpcoming}>{this.state.showUpcoming ? "View Less": "View More"}&nbsp; <span><i className={this.state.showUpcoming===true? 'ti-angle-down': 'ti-angle-right'} style={{fontSize: "10px"}}></i></span></div></div>
                            <div className={"panel " + (this.state.showUpcoming ? "CollapseLarge" : this.state.showOverdue ? "CollapseSmall" : '')}>
                                <ul>
                                    <li className="open">
                                        <div className="task-date">
                                            <h3>02</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                    <li>
                                        <div className="task-date">
                                            <h3>03</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                    <li>
                                        <div className="task-date">
                                            <h3>04</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                    <li>
                                        <div className="task-date">
                                            <h3>05</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="accordion-parent overdue">
                            <div className="btn btn-green  accordion danger"><h6>Overdue Tasks</h6> <div className="pointer" onClick={this.showOverdue}>{this.state.showOverdue ? "View Less": "View More"}&nbsp; <span><i className={this.state.showOverdue===true? 'ti-angle-down': 'ti-angle-right'} style={{fontSize: "10px"}}></i></span></div></div>
                            <div className={"panel " + (this.state.showOverdue ? "CollapseLarge" : this.state.showUpcoming ? "CollapseSmall" : '')}>
                                <ul>
                                    <li>
                                        <div className="task-date">
                                            <h3>02</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                    <li className="open">
                                        <div className="task-date">
                                            <h3>03</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                    <li>
                                        <div className="task-date">
                                            <h3>04</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                    <li>
                                        <div className="task-date">
                                            <h3>05</h3>
                                            <h5>Apr</h5>
                                        </div>
                                        <div className="task-details">
                                            <h6 className="task-title">Add Study Plan</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </Col>
                </Row>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(Dashboard1));