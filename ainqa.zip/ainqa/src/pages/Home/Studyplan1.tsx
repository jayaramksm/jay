import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, Form, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import editicon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';
import pending from '../../images/Pending.svg';
import viewicon from '../../images/View.svg';
import Select from 'react-select';
import Approved from '../../images/Approved.svg';
import * as echarts from 'echarts'

class Studyplan1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {

        };
        this.handleChange = this.handleChange.bind(this);
        this.openChartView = this.openChartView.bind(this);
    }

    renderChart() {
        var chartDom = document.getElementById('main') as HTMLElement;
        var myChart = echarts.init(chartDom);
        var data = [
            ['Rotation1', 'Year I', '2020-01-01', '2020-04-10'],
            ['Rotation2', 'Year I', '2020-04-20', '2020-08-10'],
            ['Rotation3', 'Year I', '2020-08-05', '2020-12-01'],
            ['Rotation4', 'Year II', '2020-12-10', '2021-03-14'],
            ['Rotation5', 'Year II', '2021-03-15', '2021-07-01'],
            ['Rotation6', 'Year II', '2021-07-15', '2021-12-01'],
            ['Rotation7', 'Year III', '2021-12-15', '2022-04-01'],
            ['Rotation8', 'Year III', '2022-04-15', '2022-09-01'],
            ['Rotation9', 'Year III', '2022-09-15', '2022-12-01'],
            ['Rotation10', 'Year IV', '2022-12-15', '2023-04-01'],
            ['Rotation11', 'Year IV', '2023-04-15', '2023-08-01'],
            ['Rotation12', 'Year IV', '2023-08-15', '2023-12-01']
        ]
        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var optionObj: any = {
            yAxisData2: [],
            yAxisData: [],
            seriesData_01: [],
            seriesData_02: [],
        }

        for (let item of data.values()) {
            optionObj.yAxisData.push(item[0]);
            optionObj.yAxisData2.push(item[1]);
            optionObj.seriesData_01.push(new Date(item[2]));
            optionObj.seriesData_02.push(new Date(item[3]));

        }

        var option = {
            // backgroundColor: "#0f2e4d",
            tooltip: {
                trigger: 'axis',
                backgroundColor: "#333333",
                textStyle: { color: "#ffffff" },

                formatter: function (params) {
                    return params[0].axisValue + '<br/>' + "StartDate: " + echarts.format.formatTime('yyyy/MM/dd', params[0].value, false) + '<br/>' + "EndDate: " + echarts.format.formatTime('yyyy/MM/dd', params[1].value, false);
                },
            },
            grid: {
                containLabel: true,
                show: false,
                right: 130,
                left: 20,
                bottom: 40,
                top: 90
            },
            xAxis: {
                type: "time",
                position: 'top',
                axisLine: {
                    show: true,
                    onZero: false,
                    lineStyle: {
                        color: '#fff'
                    }
                },
                splitLine: { show: true },
                axisTick: {
                    lineStyle: {
                        color: '#fff'
                    }
                },
                axisLabel: {
                    show: true,
                    showMinLabel: true,
                    showMaxLabel: true,
                    color: '#000000',
                    left: 60,
                    fontSize: 12,
                    formatter: (value, index) => {
                        var date = new Date(value);
                        var texts = [date.getFullYear(), months[(date.getMonth())]];
                        return texts.join("\r\n");
                    }
                },

            },
            yAxis: [
                {
                    name: "Rotations       ",
                    nameLocation: 'start',
                    nameTextStyle: {
                        align: 'right',
                        fontWeight: "bold",
                        fontSize: '14',
                        fontFamily: "ROBOTO"
                    },
                    inverse: true,
                    splitLine: {
                        show: true
                    },
                    axisTick: {
                        show: true,
                        length: 75,
                        lineStyle: { color: '#000' }
                    },
                    axisLine: {
                        lineStyle: { color: '#000' }
                    },
                    axisLabel: { margin: 10, },

                    data: optionObj.yAxisData
                }, {

                    nameLocation: 'start',
                    nameTextStyle: {
                        fontWeight: 'bold',
                        background: "#dfe324"
                    },
                    position: 'left',
                    offset: 75,
                    axisLine: {
                        onZero: false,
                        show: true
                    },
                    axisTick: {
                        length: 70,
                        inside: false,
                        lineStyle: { color: '#000' }
                    },
                    axisLabel: {
                        inside: false,
                        color: "#39B2B1",
                        rotate: 90,
                        fontWeight: 'bold',


                    },
                    inverse: true,
                    data: [...new Set(optionObj.yAxisData2)]
                },
                {
                    axisLine: {
                        onZero: false,
                        show: true
                    },
                    position: 'left',
                    offset: 108,
                }
            ],
            series: [
                {
                    name: "StartDate",
                    type: "bar",
                    stack: "duration",
                    itemStyle: {
                        color: "#ffffff",

                    },
                    emphasis: {
                        itemStyle: {
                            color: "#ffffff",

                        }
                    },
                    barWidth: 20,
                    zlevel: -1,
                    z: 3,
                    data: optionObj.seriesData_01
                },
                {
                    name: "EndDate",
                    type: "bar",
                    stack: "duration",
                    label: {
                        show: true
                    },
                    itemStyle: {
                        color: "#39B2B1",
                        borderColor: "#ffffff",
                        borderWidth: 2,
                    },
                    emphasis: {
                        itemStyle: {
                            color: "#39B2B1",
                            borderColor: "#ffffff",
                            borderWidth: 2,


                        }
                    },
                    barWidth: 20,
                    zlevel: -1,

                    data: optionObj.seriesData_02
                },

            ]
        };
        option && myChart.setOption(option);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.renderChart();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    openChartView() {
        this.setState({ openChart: true });
        setTimeout(() => {
            this.renderChart();

        }, 5000);
    };

    yearOptions = [{ value: 'year1', label: 'Year 1' },
    { value: 'year2', label: 'Year 2' },
    { value: 'year3', label: 'Year 3' },
    { value: 'year4', label: 'Year 4' }];

    stageOptions = [{ value: 'stage1', label: 'Stage 1' },
    { value: 'stage2', label: 'Stage 2' },
    { value: 'stage3', label: 'Stage 3' },
    { value: 'stage4', label: 'Stage 4' }];

    rotationOptions = [{ value: 'rotation1', label: 'Rotation 1' },
    { value: 'rotation2', label: 'Rotation 2' },
    { value: 'rotation3', label: 'Rotation 3' },
    { value: 'rotation4', label: 'Rotation 4' }];

    sequenceOptions = [{ value: 'sequence1', label: 'Secquence 1' },
    { value: 'sequence2', label: 'Secquence 2' },
    { value: 'sequence3', label: 'Secquence 3' },
    { value: 'sequence4', label: 'Secquence 4' }];

    periodOptions = [{ value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' }];

    universityOptions = [{ value: 'university1', label: 'University 1' },
    { value: 'university2', label: 'University 2' },
    { value: 'university3', label: 'University 3' },
    { value: 'university4', label: 'University 4' }];

    hospitalOptions = [{ value: 'hospital1', label: 'Hospital 1' },
    { value: 'hospital2', label: 'Hospital 2' },
    { value: 'hospital3', label: 'Hospital 3' },
    { value: 'hospital4', label: 'Hospital 4' }];

    supervisorOptions = [{ value: 'sup1', label: 'Supervisor 1' },
    { value: 'sup2', label: 'Supervisor 2' },
    { value: 'sup3', label: 'Supervisor 3' },
    { value: 'sup4', label: 'Supervisor 4' }];

    render() {

        return (
            <React.Fragment >
                <div className="flexLayout maincontent">
                    <div className="flexScroll">
                        <div className="mydocuments pr-3">

                            {/* Initial View  */}
                            <h3 className="page-header">Programme Details </h3>
                            <Form >
                                <Row>
                                    <Col lg={4} md={6} sm={12}>
                                        <FormGroup>
                                            <Label for="Programme ID">Programme ID</Label>
                                            <Input type="email" name="Programme ID" id="Programme-ID" value="PGFM" disabled placeholder="Programme ID" readOnly />
                                        </FormGroup>
                                    </Col>

                                    <Col lg={4} md={6} sm={12}>
                                        <FormGroup>
                                            <Label for="Programme Name">Programme Name</Label>
                                            <Input type="email" name="Programme Name" value="Family Medicine" id="Programme_Name" disabled placeholder="Programme Name" readOnly />
                                        </FormGroup>
                                    </Col>

                                </Row>

                            </Form>
                            <hr />
                        </div>

                        <div className="maincontent mr-3">
                            <h3 className="page-header">Study Plan</h3>
                            <div className="add-button mt-3">
                                <div className="button-text">Add your Study Plan</div>
                                <div className="note">* Please Add all Rotations of your Entire Programme</div>
                            </div>

                            {/* Initial View end */}


                            <Row>
                                <Col>
                                    <h3 className="page-header header-title">Study Plan</h3>
                                </Col>
                                <div>
                                    <button className="addnewButn mr-3"><i className="ti-plus"></i> Add Rotation</button>
                                </div>
                            </Row>

                            <div className="tbl-parent table-responsive">
                                <table className="myTable studyplanTable table">
                                    <thead>
                                        <tr>
                                            <th>Study Plan</th>
                                            <th>Approval Date</th>
                                            <th className="column-center">Approval Status</th>
                                            <th>Comment</th>
                                            <th>Gant Chart</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="ActionStatus">PG Study Plan</td>
                                            <td>-</td>
                                            <td className="column-center">
                                                <img src={pending} alt="" className="icon"></img>
                                            </td>
                                            <td>-</td>
                                            <td><a href="#" className="file-name ActionStatus">View Chart</a></td>
                                            <td><span> <img src={editicon} alt="" className="actionicon pointer"></img></span>
                                                <span> <img src={viewicon} alt="" className="actionicon pointer"></img></span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            {/* Add Rotation */}
                            <div className="breadcrumbs">
                                <div> Study Plan
                                    {!this.state.viewDetails &&
                                        <>
                                            <span><i className="ti-angle-right"></i></span>
                                            <span className="active">Add Rotations</span>
                                        </>
                                    }
                                    {this.state.viewDetails &&
                                        <>
                                            <span><i className="ti-angle-right"></i></span>
                                            <span className="active">View Study Plan</span>
                                        </>
                                    }
                                </div>
                            </div>

                            <div className="main-form">
                                <Form >
                                    <Row>
                                        <Col lg={4} md={6} sm={12}>
                                            <FormGroup  >
                                                <Label for="exampleSelect" >Rotation</Label>
                                                <Col className="input-parent" >
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.periodOptions}
                                                        placeholder="Select Rotation" />
                                                </Col>
                                            </FormGroup>
                                        </Col>
                                        <Col lg={4} md={6} sm={12}>
                                            <FormGroup  >
                                                <Label for="exampleSelect" >Year</Label>
                                                <Col className="input-parent" >
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.yearOptions}
                                                        placeholder="Select Year" />
                                                </Col>
                                            </FormGroup>
                                        </Col>
                                        <Col lg={4} md={6} sm={12}>
                                            <FormGroup  >
                                                <Label for="exampleSelect" >Stage</Label>
                                                <Col className="input-parent" >
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.stageOptions}
                                                        placeholder="Select Stage" />
                                                </Col>
                                            </FormGroup>
                                        </Col>
                                        <Col lg={4} md={6} sm={12}>
                                            <FormGroup  >
                                                <Label>University Name</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.universityOptions}
                                                    placeholder="Select Stage" />
                                            </FormGroup>
                                        </Col>
                                        <Col lg={4} md={6} sm={12}>
                                            <FormGroup  >
                                                <Label for="exampleSelect" >Hospital Name</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.hospitalOptions}
                                                    placeholder="Select Hospital" />
                                            </FormGroup>
                                        </Col>
                                        <Col lg={4} md={6} sm={12}>
                                            <FormGroup>
                                                <Label for="exampleSelect" >Other Hospital Name</Label>
                                                <Col className="input-parent" >
                                                    <Input type="text" value="-" name="select" disabled className="input-form" id="exampleSelect">
                                                    </Input>
                                                </Col>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row className="main-form-footer mt-3">
                                        <button type="button" className="btn-sm submit-button">Add Rotation</button>
                                    </Row>
                                </Form>
                            </div>
                            <hr />

                            {/*Add Rotation end */}


                            {/* Rotation View */}
                            <div>
                                <h3 className="page-header">Rotations of Programme <span className="note-inline">* Please Add All Rotations of Entire Programme</span></h3>

                                <div className="tbl-parent table-responsive">
                                    <table className="myTable rop-table table">
                                        <thead>
                                            <tr>
                                                <th>Sequence</th>
                                                <th>Rotation</th>
                                                <th>Year</th>
                                                <th>Stage</th>
                                                <th>University</th>
                                                <th>Hospital Name</th>
                                                <th>Other Hospital Name</th>
                                                <th className="tbl-text-wrap">Duration <p className="mb-0"><small>(in Months)</small></p></th>

                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>03</td>
                                                <td>Rotation 03</td>
                                                <td>Year III</td>
                                                <td>Stage III</td>
                                                <td>UM</td>
                                                <td>Malaya</td>
                                                <td>-</td>
                                                <td>3</td>
                                                <td>
                                                    <div className="flex">
                                                        <div> <img src={editicon} alt="" className="actionicon"></img></div>
                                                        <div> <img src={Delete} alt="" className="actionicon"></img></div>
                                                    </div>
                                                </td>

                                            </tr>
                                            <tr>
                                                <td>02</td>
                                                <td>Rotation 02</td>
                                                <td>Year II</td>
                                                <td>Stage II</td>
                                                <td>UM</td>
                                                <td>Malaya</td>
                                                <td>-</td>
                                                <td>2</td>
                                                <td>
                                                    <div className="flex">
                                                        <div> <img src={editicon} alt="" className="actionicon"></img></div>
                                                        <div> <img src={Delete} alt="" className="actionicon"></img></div>
                                                    </div>
                                                </td>

                                            </tr>
                                            <tr>
                                                <td>01</td>
                                                <td>Rotation 01</td>
                                                <td>Year I</td>
                                                <td>Stage I</td>
                                                <td>UM</td>
                                                <td>Malaya</td>
                                                <td>Montech Hospital</td>
                                                <td>1</td>
                                                <td>
                                                    <div className="flex">
                                                        <div> <img src={editicon} alt="" className="actionicon"></img></div>
                                                        <div> <img src={Delete} alt="" className="actionicon"></img></div>
                                                    </div>
                                                </td>

                                            </tr>

                                        </tbody>
                                    </table>
                                </div>

                                <Row className="sub-form-footer my-3 mr-1">
                                    <button className="cancel-button">Cancel</button>
                                    <button className="submit-button">Submit for Approval</button>
                                </Row>
                            </div>

                            {/* Rotation View End */}


                            <div className="top-section mr-3">
                                <hr />
                                <Row className="vhcenter">
                                    <Col sm="6">
                                        <h2>Educational Supervisor Details</h2>
                                    </Col>
                                    <Col sm="6" className="text-right">
                                        <span className="approvedDate">Approved on : <span className="date">07/03/2021</span></span>
                                    </Col>
                                </Row>
                                <div className="details-section mt-2">
                                    <Row className="mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Approval Status</Label>
                                                <InputGroup className="disabled-item">
                                                    <Input disabled value="Approved" />
                                                    <InputGroupAddon addonType="append">
                                                        <InputGroupText><img src={Approved} className="contorlicon" alt="" /></InputGroupText>
                                                    </InputGroupAddon>
                                                </InputGroup>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Comments</Label>
                                                <textarea disabled className="w100" value="1" rows={1} onChange={() => { }}></textarea>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Signature</Label>
                                                <Input type="text" disabled value="Karteek"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                                <Row className="sub-form-footer mt-3 mr-3">
                                    <button className="back-button">Back</button>
                                </Row>
                            </div>

                            <div className="breadcrumbs">
                                <div> Study Plan
                                    <span>
                                        <i className="ti-angle-right"></i></span>
                                    <span className="active">Chart View</span>
                                </div>
                            </div>
                            <div id="main" style={{ width: '100%', height: '400px' }}></div>
                        </div>
                    </div>
                </div>
            </React.Fragment >
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(Studyplan1));