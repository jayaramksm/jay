import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, Form } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Approved from '../../images/Approved.svg';
import Reject from '../../images/Reject.svg';
import EditIcon from '../../images/Edit.svg';
import uploadImg from '../../images/Upload.svg';
import closeIcon from '../../images/Close.svg';

import Select from 'react-select';

class MyDocument1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            adddocument: false,
            selectedOption: null
        };
        this.newDocument = this.newDocument.bind(this);
        this.closeAddrow = this.closeAddrow.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    newDocument() {
        this.setState({ adddocument: true })
    }

    closeAddrow() {
        this.setState({ adddocument: false })
    }
    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    doctypeOptions = [{ value: 'residenceproof', label: 'Rresidenceproof' },
    { value: 'pan', label: 'PAN' },
    { value: 'passport', label: 'Passport' },
    { value: 'other', label: 'Other' }];

    render() {

        return (
            <React.Fragment>
                <div className="flexLayout">
                    <div className="flexScroll">
                            <div className="mydocuments pr-3">
                                <h3 className="page-header">Programme Details</h3>
                                <Row className="mt-2">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>Programme ID</Label>
                                            <Input type="text" value='PGFM' disabled placeholder="Enter Programme ID">
                                            </Input>
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>Programme Name</Label>
                                            <Input type="text" value='Family Medicine' disabled placeholder="Enter Programme Name">
                                            </Input>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <hr />
                                <Row className="compHeading">
                                    <Col sm="7" xs="12">
                                        <h3 className="page-header header-title">Statutory Documents</h3>
                                    </Col>
                                    <Col sm="5" xs="12" className="pr-3 text-right">
                                        <button className="addnewButn" onClick={this.newDocument}><i className="ti-plus"></i> Add Document</button>
                                    </Col>
                                </Row>
                                <div className="main-table">
                                    <div className="mydocumentTable tbl-parent table-responsive">
                                        <table className="w100 myTable mydocuments table">
                                            <thead>
                                                <tr>
                                                    <th>Document Type</th>
                                                    <th>Document Name</th>
                                                    <th>File Name</th>
                                                    <th className="column-center">Approval Status</th>
                                                    <th>Approval Comments</th>
                                                    <th className="w12">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {this.state.adddocument &&
                                                    <tr>
                                                        <td colSpan={6} className="documents">
                                                            <Form>
                                                                <Row>
                                                                    <Col sm={2}>
                                                                        <FormGroup>
                                                                            <Select
                                                                                onChange={(e) => this.handleChange(e)}
                                                                                options={this.doctypeOptions}
                                                                                placeholder="Select Type"
                                                                            />
                                                                        </FormGroup>
                                                                    </Col>
                                                                    <Col sm={2}>
                                                                        <FormGroup>
                                                                            <Input type="text" name="marksmemo" id="marksmemo" placeholder="File Name" />
                                                                        </FormGroup>
                                                                    </Col>
                                                                    <Col sm={3}>
                                                                        <FormGroup>
                                                                            <Label htmlFor="files" className="btn btn-sm uploadFileText"><img src={uploadImg} alt="" />Upload File</Label>
                                                                            <input type="file" id="files" name="files" style={{ display: 'none' }} />
                                                                            {/* <span>File name</span> */}
                                                                        </FormGroup>
                                                                    </Col>
                                                                    <Col sm={3}>

                                                                    </Col>
                                                                    <Col sm={2} className="text-right">
                                                                        <FormGroup style={{ marginRight: "18px" }}>
                                                                            <button type="button" className="btn btn-primary" onClick={this.closeAddrow}>Save</button>
                                                                            <button type="button" className="btn btn-danger ml-2" onClick={this.closeAddrow}><img src={closeIcon} alt="" style={{ width: "22px" }} /></button>
                                                                        </FormGroup>
                                                                    </Col>
                                                                </Row>
                                                            </Form>
                                                        </td>
                                                    </tr>
                                                }
                                                <tr>
                                                    <td>Profile Evidence</td>
                                                    <td>Driving License</td>
                                                    <td className="w18"><a href='#' className="fileName pointer">Address.png</a></td>
                                                    <td className="column-center"><img src={Reject} alt="" /></td>
                                                    <td>No Clarity image</td>
                                                    <td className="w8 ActionStatus"><img src={EditIcon} className="actionicon" /></td>
                                                </tr>
                                                <tr>
                                                    <td>Profile Evidence</td>
                                                    <td>Driving License</td>
                                                    <td className="w18"><a href='#' className="fileName pointer">DL_01.jpg</a></td>
                                                    <td className="column-center"><img src={Approved} alt="" /></td>
                                                    <td>-</td>
                                                    <td className="w8">-</td>
                                                </tr>
                                                <tr>
                                                    <td>Profile Evidence</td>
                                                    <td>Driving License</td>
                                                    <td className="w18"><a href='#' className="fileName pointer">Address1.png</a></td>
                                                    <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                    <td>-</td>
                                                    <td className="w8">-</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(MyDocument1));