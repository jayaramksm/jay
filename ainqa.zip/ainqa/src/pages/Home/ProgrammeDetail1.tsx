import React, { Component } from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

class ProgrammeDetail1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {

        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    render() {

        return (
            <React.Fragment>
                <div className="flexLayout">
                    <div className="flexScroll">
                            <div className="mydocuments pr-3">
                                <h3 className="page-header">Programme Details</h3>
                                <div className="tbl-parent table-responsive">
                                    <table className="myTable programme-details-table table">
                                        <thead>
                                            <tr>
                                                <th>University Name</th>
                                                <th>Department</th>
                                                <th>Programme</th>
                                                <th>Enrolled Year</th>
                                                <th>Current Stage</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>UM</td>
                                                <td>Medical</td>
                                                <td>Family Medicine</td>
                                                <td>2019</td>
                                                <td>Stage 1</td>
                                            </tr>
                                            <tr>
                                                <td>UMK</td>
                                                <td>Medical</td>
                                                <td>Family Medicine</td>
                                                <td>2020</td>
                                                <td>Stage 2</td>
                                            </tr>
                                            <tr>
                                                <td>UMd</td>
                                                <td>Medical</td>
                                                <td>Family Medicine</td>
                                                <td>2019</td>
                                                <td>Stage 3</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(ProgrammeDetail1));