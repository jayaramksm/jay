import React, { Component } from 'react';
import { Row, Col, Label, Input, FormGroup, UncontrolledDropdown, DropdownToggle, DropdownItem, DropdownMenu } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Scrollbars } from 'react-custom-scrollbars';
import approved from '../../images/Approved.svg';
import pending from '../../images/Pending.svg';
import filter from '../../images/filter.svg';
import closeIcon from '../../images/Close.svg';
import Select from 'react-select';


class ApproveStatutoryDocuments1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
           
        };
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    addApprove() {
        this.setState({ showApprove: !this.state.showApprove })
    }
    approvalOptions = [{ value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' }];

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                <Row className="compHeading">
                                            <Col>
                                                <h2>Approve Statutory Documents</h2>
                                            </Col>
                                            <div className="rgtFilter">
                                                <div className="search-box filtericon">
                                                    <UncontrolledDropdown>
                                                        <DropdownToggle id="Filter">
                                                        <i className="icon-filter"></i>
                                                        </DropdownToggle>
                                                        <DropdownMenu>
                                                            <DropdownItem>All</DropdownItem>
                                                            <DropdownItem>Pending</DropdownItem>
                                                            <DropdownItem>Approved</DropdownItem>
                                                            <DropdownItem>Rejected</DropdownItem>
                                                        </DropdownMenu>
                                                    </UncontrolledDropdown>
                                                    <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                                                </div>
                                            </div>
                                        </Row>
                    <div className="flexScroll">
                                <div className="maincontent pr-3">
                                    <div className="tbl-parent table-responsive">
                                        <table className="myTable approve-statutory table">
                                            <thead>
                                                <tr>
                                                    <th>Trainee Name</th>
                                                    <th>Programee Name</th>
                                                    <th className="column-center">Approval Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Margret</td>
                                                    <td>Cardiology</td>
                                                    <td className="column-center"><img src={approved} alt="" style={{ margin: "0 auto" }} /></td>
                                                    <td><div className="ActionStatus pointer">View</div></td>
                                                </tr>
                                                <tr>
                                                    <td>JohnyDeep</td>
                                                    <td>Family Medicine</td>
                                                    <td className="column-center"><img src={pending} alt="" style={{ margin: "0 auto" }} /></td>
                                                    <td><div className="ActionStatus pointer">Approve</div></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="maincontent pr-3">
                                    <div className="breadcrumbs pointer">
                                            <div> Approve Statutory Documents
                                            <span>
                                                <i className="ti-angle-right"></i></span>
                                                        <span className="active">Johny Depp</span>
                                            </div>
                                        </div>

                                    <div className="tbl-parent table-responsive">
                                        <table className="myTable documenttypes table">
                                            <thead>
                                                <tr>
                                                    <th>Document Type</th>
                                                    <th>Document Name</th>
                                                    <th>File Name</th>
                                                    <th>Approval Status</th>
                                                    <th>Approval Comments</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Profile Evidence</td>
                                                    <td>Driving License</td>
                                                    <td><div className="fileName pointer">DL_01.jpeg</div></td>
                                                    <td><img src={approved} alt="" style={{ margin: "0 auto" }} /></td>
                                                    <td>-</td>
                                                    <td>-</td>
                                                </tr>
                                                <tr>
                                                    <td>Residence Proof</td>
                                                    <td>Aadhar</td>
                                                    <td><div className="fileName pointer">Address.png</div></td>
                                                    <td><FormGroup>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.approvalOptions}
                                                        placeholder="Select Approval"
                                                    />
                                                    </FormGroup></td>
                                                    <td><FormGroup>
                                                        <Input type="text" name="comment" value="No clarity in image" onChange={() => { }}></Input>
                                                    </FormGroup></td>
                                                    <td><button className="btn btn-primary mr-3">Save</button><button className="btn btn-danger"><img src={closeIcon} alt="" style={{width:"22px"}} /></button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(ApproveStatutoryDocuments1));