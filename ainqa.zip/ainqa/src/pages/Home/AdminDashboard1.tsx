import React, { Component } from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import AdminDashboard from '../../images/admin-db.jpg';

class AdminDashboard1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {

        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    render() {

        return (
            <React.Fragment>
                <div className="flexLayout">
                    <div className="flexScroll">
                            <div>
                                  <img src={AdminDashboard} className=" fit-image" alt=""></img>
                            </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(AdminDashboard1));