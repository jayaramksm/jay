import React, { Component } from 'react';
import { Row, Col, FormGroup, Label, UncontrolledDropdown, DropdownToggle, DropdownItem, DropdownMenu } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import approved from '../../images/Approved.svg';
import pending from '../../images/Pending.svg';
import Select from 'react-select';
import * as echarts from 'echarts';

class ApproveStudyPlan1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {

        };
        this.handleChange = this.handleChange.bind(this);
        this.openChartView = this.openChartView.bind(this);
    }

    renderChart() {
        var chartDom = document.getElementById('main') as HTMLElement;
        var myChart = echarts.init(chartDom);
        var data = [
            ['Rotation1', 'Year I', '2020-01-01', '2020-04-10'],
            ['Rotation2', 'Year I', '2020-04-20', '2020-08-10'],
            ['Rotation3', 'Year I', '2020-08-05', '2020-12-01'],
            ['Rotation4', 'Year II', '2020-12-10', '2021-03-14'],
            ['Rotation5', 'Year II', '2021-03-15', '2021-07-01'],
            ['Rotation6', 'Year II', '2021-07-15', '2021-12-01'],
            ['Rotation7', 'Year III', '2021-12-15', '2022-04-01'],
            ['Rotation8', 'Year III', '2022-04-15', '2022-09-01'],
            ['Rotation9', 'Year III', '2022-09-15', '2022-12-01'],
            ['Rotation10', 'Year IV', '2022-12-15', '2023-04-01'],
            ['Rotation11', 'Year IV', '2023-04-15', '2023-08-01'],
            ['Rotation12', 'Year IV', '2023-08-15', '2023-12-01']
        ]
        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var optionObj: any = {
            yAxisData2: [],
            yAxisData: [],
            seriesData_01: [],
            seriesData_02: [],
        }

        for (let item of data.values()) {
            optionObj.yAxisData.push(item[0]);
            optionObj.yAxisData2.push(item[1]);
            optionObj.seriesData_01.push(new Date(item[2]));
            optionObj.seriesData_02.push(new Date(item[3]));

        }

        var option = {
            // backgroundColor: "#0f2e4d",
            tooltip: {
                trigger: 'axis',
                backgroundColor: "#333333",
                textStyle: { color: "#ffffff" },

                formatter: function (params) {
                    return params[0].axisValue + '<br/>' + "StartDate: " + echarts.format.formatTime('yyyy/MM/dd', params[0].value, false) + '<br/>' + "EndDate: " + echarts.format.formatTime('yyyy/MM/dd', params[1].value, false);
                },
            },
            grid: {
                containLabel: true,
                show: false,
                right: 130,
                left: 20,
                bottom: 40,
                top: 90
            },
            xAxis: {
                type: "time",
                position: 'top',
                axisLine: {
                    show: true,
                    onZero: false,
                    lineStyle: {
                        color: '#fff'
                    }
                },
                splitLine: { show: true },
                axisTick: {
                    lineStyle: {
                        color: '#fff'
                    }
                },
                axisLabel: {
                    show: true,
                    showMinLabel: true,
                    showMaxLabel: true,
                    color: '#000000',
                    left: 60,
                    fontSize: 12,
                    formatter: (value, index) => {
                        var date = new Date(value);
                        var texts = [date.getFullYear(), months[(date.getMonth())]];
                        return texts.join("\r\n");
                    }
                },

            },
            yAxis: [
                {
                    name: "Rotations       ",
                    nameLocation: 'start',
                    nameTextStyle: {
                        align: 'right',
                        fontWeight: "bold",
                        fontSize: '14',
                        fontFamily: "ROBOTO"
                    },
                    inverse: true,
                    splitLine: {
                        show: true
                    },
                    axisTick: {
                        show: true,
                        length: 75,
                        lineStyle: { color: '#000' }
                    },
                    axisLine: {
                        lineStyle: { color: '#000' }
                    },
                    axisLabel: { margin: 10, },

                    data: optionObj.yAxisData
                }, {

                    nameLocation: 'start',
                    nameTextStyle: {
                        fontWeight: 'bold',
                        background: "#dfe324"
                    },
                    position: 'left',
                    offset: 75,
                    axisLine: {
                        onZero: false,
                        show: true
                    },
                    axisTick: {
                        length: 70,
                        inside: false,
                        lineStyle: { color: '#000' }
                    },
                    axisLabel: {
                        inside: false,
                        color: "#39B2B1",
                        rotate: 90,
                        fontWeight: 'bold',


                    },
                    inverse: true,
                    data: [...new Set(optionObj.yAxisData2)]
                },
                {
                    axisLine: {
                        onZero: false,
                        show: true
                    },
                    position: 'left',
                    offset: 108,
                }
            ],
            series: [
                {
                    name: "StartDate",
                    type: "bar",
                    stack: "duration",
                    itemStyle: {
                        color: "#ffffff",

                    },
                    emphasis: {
                        itemStyle: {
                            color: "#ffffff",

                        }
                    },
                    barWidth: 20,
                    zlevel: -1,
                    z: 3,
                    data: optionObj.seriesData_01
                },
                {
                    name: "EndDate",
                    type: "bar",
                    stack: "duration",
                    label: {
                        show: true
                    },
                    itemStyle: {
                        color: "#39B2B1",
                        borderColor: "#ffffff",
                        borderWidth: 2,
                    },
                    emphasis: {
                        itemStyle: {
                            color: "#39B2B1",
                            borderColor: "#ffffff",
                            borderWidth: 2,


                        }
                    },
                    barWidth: 20,
                    zlevel: -1,

                    data: optionObj.seriesData_02
                },

            ]
        };
        option && myChart.setOption(option);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.renderChart();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    openChartView() {
        this.setState({ openChart: true });
        setTimeout(() => {
            this.renderChart();

        }, 5000);
    };

    approvalOptions = [{ value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' }];

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h2>Approve Study Plans</h2>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <UncontrolledDropdown>
                                    <DropdownToggle id="Filter">
                                        <i className="icon-filter"></i>
                                    </DropdownToggle>
                                    <DropdownMenu>
                                        <DropdownItem>All</DropdownItem>
                                        <DropdownItem>Pending</DropdownItem>
                                        <DropdownItem>Approved</DropdownItem>
                                        <DropdownItem>Rejected</DropdownItem>
                                    </DropdownMenu>
                                </UncontrolledDropdown>
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            <div className="tbl-parent table-responsive">
                                <table className="myTable approveStdPlan table">
                                    <thead>
                                        <tr>
                                            <th className="w35">Trainee Name</th>
                                            <th className="w35">Programee Name</th>
                                            <th className="w18 text-center">Approval Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="w35">JohnyDeep</td>
                                            <td className="w35">Family Medicine</td>
                                            <td className="w18 text-center"><img src={pending} alt="" style={{ margin: "0 auto" }} /></td>
                                            <td><div className="ActionStatus pointer">Approve</div></td>
                                        </tr>
                                        <tr>
                                            <td className="w35">Margret</td>
                                            <td className="w35">Cardiology</td>
                                            <td className="w18 text-center"><img src={approved} alt="" style={{ margin: "0 auto" }} /></td>
                                            <td><div className="ActionStatus pointer">View</div></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="maincontent studyplanTable pr-3">
                            <div className="breadcrumbs pointer">
                                <div> Approve Study Plans
                                    <span>
                                        <i className="ti-angle-right"></i></span>
                                    <span className="active">Johny Depp</span>
                                </div>
                            </div>

                            <Row className="compHeading">
                                <Col sm="6">
                                    <h2>Rotations of Programme</h2>
                                </Col>
                                <Col sm="6" className="text-right charthead">
                                    <span className="pointer">View Gantt Chart</span>
                                </Col>
                            </Row>

                            <div className="tbl-parent table-responsive">
                                <table className="myTable rop-stdplan table">
                                    <thead>
                                        <tr>
                                            <th>Sequence</th>
                                            <th>Rotation</th>
                                            <th>Year</th>
                                            <th>Stage</th>
                                            <th>University</th>
                                            <th>Hospital Name</th>
                                            <th>Other Hospital Name</th>
                                            <th>Duration<p className="mb-0" style={{ fontSize: "10px" }}>(In Months)</p></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>03</td>
                                            <td>Rotation 03</td>
                                            <td>Year I</td>
                                            <td>Stage I</td>
                                            <td>UM</td>
                                            <td>MALAY</td>
                                            <td>-</td>
                                            <td>7</td>
                                        </tr>
                                        <tr>
                                            <td>02</td>
                                            <td>Rotation 02</td>
                                            <td>Year II</td>
                                            <td>Stage II</td>
                                            <td>UM</td>
                                            <td>MALAY</td>
                                            <td>-</td>
                                            <td>3</td>
                                        </tr>
                                        <tr>
                                            <td>01</td>
                                            <td>Rotation 01</td>
                                            <td>Year III</td>
                                            <td>Stage III</td>
                                            <td>UMK</td>
                                            <td>OTHER</td>
                                            <td>-</td>
                                            <td>2</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <Row className="mt-4">
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>Approval Status</Label>
                                        <Select
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.approvalOptions}
                                            placeholder="Select Approval"
                                        />
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>Comments</Label>
                                        <textarea rows={1} className="comments" placeholder="Enter Comments"></textarea>                                            </FormGroup>
                                </Col>
                            </Row>

                            <Row className="sub-form-footer mt-3 mr-3">
                                <button className="cancel-button">Cancel</button>
                                <button className="btn submit-button">Submit</button>
                            </Row>
                        </div>

                        <div className="maincontent studyplanTable pr-3">
                            <div className="breadcrumbs pointer">
                                <div> Approve Study Plans
                                    <span>
                                        <i className="ti-angle-right"></i></span>
                                    <span>Johny Depp</span>
                                    <span>
                                        <i className="ti-angle-right"></i></span>
                                    <span className="active">Gantt Chart</span>
                                </div>
                            </div>
                            <div id="main" style={{ width: '100%', height: '400px' }}></div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(ApproveStudyPlan1));