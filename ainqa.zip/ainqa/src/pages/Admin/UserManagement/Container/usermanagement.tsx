import React, { Component } from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, getAllUsersDataRequest, cancelAllPendingUsersRequest, resetAllUserStateRequest } from '../../../../store/actions';
import {
    UserManagementParentManager,
    UserManagementView,
    SingleUserCreationOrEdit,
    UserManagementAction,
    UserManagementFilter,
    UserManagementManager,
    BulkUploadManager,
    BulkUpload,
    BulkUploadView
} from '../Container/usermanagementindex';
import { SuperParentContext } from './usermanagementcontext';

interface IProps {
    activateAuthLayout: any;
    getAllUsersDataRequest: any;
    resetAllUserStateRequest: any;
    cancelAllPendingUsersRequest: any;
}

class UserManagement extends Component<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            manager: {
                managerComponent: UserManagementManager,
                viewComponent: UserManagementView,
                actionComponent: UserManagementAction,
                filterComponent: UserManagementFilter,
                userCreationOrEditComponent: SingleUserCreationOrEdit,
                bulkUploadManagerComponent: BulkUploadManager,
                bulkUploadComponent: BulkUpload,
                BulkUploadViewComponent: BulkUploadView
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllUserStateRequest();
        this.props.getAllUsersDataRequest();
    }

    componentWillUnmount() {
        this.props.resetAllUserStateRequest();
        this.props.cancelAllPendingUsersRequest();
    }

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout maincontent pr-0">
                    <SuperParentContext.Provider value={this.state.manager}>
                        <UserManagementParentManager />
                    </SuperParentContext.Provider>
                </div>
            </React.Fragment>
        )
    }
}

export default connect(null, { activateAuthLayout, getAllUsersDataRequest, resetAllUserStateRequest, cancelAllPendingUsersRequest })(UserManagement);
