import React, { useRef } from 'react';
import { FormGroup, Row, Col, Label } from 'reactstrap';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import Papa from 'papaparse';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import * as _ from 'lodash';
import { useDispatch } from 'react-redux';
import { EBulkUploadStatus, IRoles, IUserManagementModel, EPathwayTags, IProgram } from '../../../../models/userManagementModel';
import { MySelect, defultContentValidate, customContentValidation, emailContentValidate, DownloadCsv, defultContentObjectValidate, getModifiedDate, getFileSizeInMb, getFileExtension, Option, ValueContainer } from '../../../../helpers/helpersIndex';
import { EFileSizes, EOprationalActions, ERoleDesc } from '../../../../models/utilitiesModel';
import { bulkUploadUsersDataRequest, setUsersActionTypeData, alertActionRequest } from '../../../../store/actions';
import download from '../../../../images/Download.svg';

const pathwayTagOptions = [
    { label: 'Open', value: 'open' },
    { label: 'Closed', value: 'closed' },
    { label: 'Hybrid', value: 'hybrid' },
];

let headers = {
    // common to all
    fullName: 'User FullName *',
    eportfolioEmailId: 'Eportfolio Email Id *',
    personalEmailId: 'Personal Email Id*',
    gender: 'Gender *',
    mobileno1: 'Mobile no1 *',
    mobileno2: 'Mobile no2 *',
    dob: 'DOB *',
    permenentAddress: 'Correspondent Address *',
    permenentCountry: 'Correspondent Country *',
    isSameAddress: 'isSameAddress',
    residentialAddress: 'Residential Address *',
    residentialCountry: 'Residential Country *',
    mmcno: "MMC No *",
    employeeId: 'Employee Id *',  // common to pc,Es,Mh, Rs
    userName: "User Name *",
    nsrNo: "NSR No",
    ammNo: "AMM No *",
    activeFromDate: "Active From Date *",
    activeToDate: "Active To Date",
    remarks: "Remarks",
    icNo: 'IC No *',
    legacyCode: 'LegacyCode',
    resourceCode: "Resource Code",
    mohId: "MOH Id *",
    // departmentCode: "Department Code *",
    // departmentName: "Department Name *",
    // programCode: 'Program Code *',
}

let csvHeaders = {
    [headers.fullName]: '',
    [headers.userName]: '',
    [headers.gender]: '',
    [headers.dob]: '',
    [headers.mobileno1]: '',
    [headers.mobileno2]: '',
    [headers.eportfolioEmailId]: '',
    [headers.personalEmailId]: '',
    [headers.residentialAddress]: '',
    [headers.residentialCountry]: '',
    [headers.isSameAddress]: '',
    [headers.permenentAddress]: '',
    [headers.permenentCountry]: '',
    [headers.mmcno]: '',
}

const yyyymmddPattern = new RegExp(/^\d{4}\-(0?[1-9]|1[012])\-(0?[1-9]|[12][0-9]|3[01])$/);
const BulkUpload: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    let { current: validData } = useRef<any>([]);
    let { current: invalidData } = useRef<any>([]);
    let { current: fromDate } = useRef<any>('');
    let { current: validationError } = useRef<any>('');

    const roleOptions: IRoles[] = useSelector((state: any) => {
        if (state?.userManagementReducer?.rolesData?.length)
            return (state.userManagementReducer as IUserManagementModel).rolesData;
        else return [];
    });

    const allUserData: any[] = useSelector((state: any) => {
        if (state?.userManagementReducer?.usersData?.length)
            return (state.userManagementReducer as IUserManagementModel).usersData;
        else return [];
    });

    const programeCodes: any = useSelector((state: any) => {
        if (state?.userManagementReducer?.programmeCodeDetailsList) {
            return (state.userManagementReducer as IUserManagementModel).programmeCodeDetailsList;
        } else return {}
    });

    const deptDetails: any = useSelector((state: any) => {
        if (state?.userManagementReducer?.deptsData?.length)
            return (state.userManagementReducer as IUserManagementModel).deptsData;
        else return undefined
    });
    const programsOptions: IProgram[] | any = useSelector((state: any) => state?.userManagementReducer?.programsData || []);

    const currentDateTimeFromApi = useSelector((state: any) => state?.userManagementReducer?.currentDate?.date || '');
    console.log('_codes=>', { currentDateTimeFromApi, programeCodes, deptDetails });

    let sampleData = {};
    const selectUserRole = (e, setFieldValue) => {
        setFieldValue('role', e ? e : '');
        setFieldValue('pathwayTag', '');
        setFieldValue('eduSupervisor', '');
        setFieldValue('coeduSupervisor', '');
        setFieldValue('isFileValidFlag', '');
        setFieldValue('fileVerification', EBulkUploadStatus.DEFAULT);
        setFieldValue('invalidFileError', '');

        if (e) {
            if (e.roleCode === ERoleDesc.Traninee)
                sampleData = {
                    ...csvHeaders,
                    // [headers.programCode]: '',
                    [headers.ammNo]: '',
                    [headers.nsrNo]: '',
                    [headers.activeFromDate]: '',
                    [headers.activeToDate]: '',
                    [headers.legacyCode]: '',
                    [headers.icNo]: '',
                    [headers.remarks]: ''
                }
            else if (e.roleCode === ERoleDesc.MOHSUPERVISOR)
                sampleData = {
                    [headers.mohId]: '',
                    ...csvHeaders
                }
            else if (e.roleCode === ERoleDesc.PROGRAMCOORDINATOR || e.roleCode === ERoleDesc.ROTATIONSUPERVISOR || e.roleCode === ERoleDesc.EDUCATIONALSUPERVISOR)
                sampleData = {
                    [headers.employeeId]: '',
                    // [headers.programCode]: '',
                    ...csvHeaders
                }
            // else if (e.roleCode === ERoleDesc.ROTATIONSUPERVISOR || e.roleCode === ERoleDesc.EDUCATIONALSUPERVISOR)
            //     sampleData = {
            //         [headers.employeeId]: '',
            //         [headers.departmentCode]: '',
            //         ...csvHeaders,
            //     }
        }
    }

    const DownloadCsvRequest = (role) => {
        const res = DownloadCsv(null, '', [sampleData], role?.roleName, '');
        console.log('DownloadCsvRequest=>', res);
    }

    const initialValues = {
        role: '',
        pathwayTag: '',
        eduSupervisor: '',
        coeduSupervisor: '',
        extension: '',
        fileName: '',
        invalidFileError: '',
        fileData: '',
        validData: '',
        invalidData: '',
        fileVerification: '',
        isFileValidFlag: '',
        departmentIds: [],
        programId: ''
    }

    const clearFileSelection = (setFieldValue) => {
        setFieldValue('extension', '');
        setFieldValue('fileName', '');
        setFieldValue('fileData', '');
        setFieldValue('invalidFileError', '');
    }

    const validationSchema = (role) => Yup.object({
        //commonFields
        userFullName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 100, 4),
        userName: Yup.string().when('roleCode', {
            is: roleCode => roleCode === ERoleDesc.Traninee,
            then: Yup.string().required(t('controleErrors.required')).oneOf([Yup.ref('mmcno'), null], t('UsersManagement.trUsernameMMC')),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 4)
        }),
        gender: customContentValidation(t, t('controleErrors.required'), { patternType: 'customWords', message: 'customWords', spacialChar: 'M|F|T' }, 1, 1),
        dob: Yup.string().test({
            name: 'dob',
            test: function (value) {
                if (yyyymmddPattern.test(value)) {
                    if ((new Date(value).getTime()) > new Date(currentDateTimeFromApi).getTime())
                        return this.createError({ message: t('controleErrors.dob'), path: 'dob' })
                    else return true
                } else return this.createError({ message: t('controleErrors.dateFormat'), path: 'dob', })
            }
        }),
        mobileno1: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1),
        mobileno2: Yup.lazy((value) => {
            if (value)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1);
            else return defultContentValidate('');
        }),
        eportfolioEmailId: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', "50") }, t('controleErrors.emailInvalid')),
        personalEmailId: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        correspondentAddress: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: '' }, 250, 4),
        correspondentCountry: customContentValidation(t, t('controleErrors.required'), { patternType: 'customWords', message: 'customWords', spacialChar: 'IND|IDN|MYS' }, 3, 3),
        isSameAddress: '',
        residentialAddress: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: '' }, 250, 4),
        residentialCountry: customContentValidation(t, t('controleErrors.required'), { patternType: 'customWords', message: 'customWords', spacialChar: 'IND|IDN|MYS' }, 3, 3),
        mmcno: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 4),
        // programId: Yup.string().when('userType', {
        //     is: (roleCode) => roleCode === ERoleDesc.Traninee || roleCode === ERoleDesc.PROGRAMCOORDINATOR,
        //     then: Yup.string().test({
        //         name: 'ProgramCode',
        //         test: function (value) {
        //             console.log('valuesComming==>', programeCodes[value])
        //             if (programeCodes[value]) {
        //                 console.log('valuesComming==>', programeCodes[value])
        //                 return true
        //             } else return this.createError({ message: `${value ? value : 'ProgramCode'} is Invalid`, path: 'ProgramCodes', })
        //         }
        //     }),
        //     otherwise: defultContentValidate('')
        // }),
        // trainee Fields
        ...((role) => {
            switch (role) {
                case ERoleDesc.Traninee: return {
                    trainee: Yup.object().shape({
                        anmno: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 1),
                        nsrno: Yup.lazy((NsrNumber) => {
                            if (NsrNumber)
                                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 1);
                            else return defultContentValidate('');
                        }),
                        trActiveFrom: Yup.string().test({
                            name: 'activeFromDate',
                            test: function (value) {
                                if (yyyymmddPattern.test(value)) {
                                    if ((new Date(value).getTime()) >= new Date(currentDateTimeFromApi).getTime())
                                        return true;
                                    else return this.createError({ message: t('controleErrors.fromDate'), path: 'activeFromDate' })
                                } else return this.createError({ message: t('controleErrors.dateFormat'), path: 'activeFromDate', })
                            }
                        }),
                        trActiveTo: Yup.lazy(trActiveToVal => {
                            if (trActiveToVal)
                                return Yup.string().when('trActiveFrom', {
                                    is: (fromdate) => { fromDate = fromdate; return (fromdate && trActiveToVal) ? true : false },
                                    then: Yup.string().test({
                                        name: 'activeToDate',
                                        test: function (value) {
                                            if (yyyymmddPattern.test(value)) {
                                                if (((new Date(value).getTime()) >= new Date(currentDateTimeFromApi).getTime() && (new Date(value).getTime()) >= (new Date(fromDate).getTime())))
                                                    return true;
                                                else return this.createError({ message: t('controleErrors.toDate'), path: 'activeToDate' })
                                            } else return this.createError({ message: t('controleErrors.dateFormat'), path: 'activeToDate', })
                                        }
                                    }),
                                    otherwise: defultContentValidate('')
                                })
                            else return defultContentValidate('');
                        }),
                        remark: Yup.lazy((remarks) => {
                            if (remarks) {
                                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumaricandspace', spacialChar: '' }, 255, 1);
                            }
                            else return defultContentValidate('');
                        }),
                        trIcNo: customContentValidation(t, t('controleErrors.required'), { patternType: 'traineeIcNumber', message: 'traineeIcNumber', spacialChar: '' }, 14, 14),
                        trLegacyCode: Yup.lazy((legacyCode) => {
                            if (legacyCode) {
                                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: '' }, 25, 1)
                            }
                            else return defultContentValidate('');
                        }),
                    })
                }
                case ERoleDesc.EDUCATIONALSUPERVISOR:
                case ERoleDesc.ROTATIONSUPERVISOR: return {
                    employeeId: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: '' }, 20, 1),
                    // departmentIds: Yup.mixed().test({
                    //     name: 'departmentCodes',
                    //     test: function (value) {
                    //         if (Array.isArray(value)) {
                    //             return true
                    //         } else return this.createError({ message: `${value ? value : 'departmentCode'} is Invalid`, path: 'departmentCodes', })
                    //     }
                    // }),
                }
                case ERoleDesc.PROGRAMCOORDINATOR: return {
                    employeeId: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: '' }, 20, 1),
                }
                case ERoleDesc.MOHSUPERVISOR: return {
                    mohId: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: '' }, 20, 1),
                }
                default: return {}
            }
        })(role),
    })

    const getDuplicatesData = (csvRecords) => {
        const uniqueData: any[] = [], duplicateData: any[] = [];
        _.forEach(csvRecords, (record, idx, a) => {
            let index, failedReason;
            index = a.findIndex(x => record['userName'] == x['userName']);
            if (index !== idx) {
                if (record['userName'])
                    failedReason = t('controleErrors.userName');
            }
            if (failedReason)
                duplicateData.push({ ...record, failedReason });
            else
                uniqueData.push(record);
        });
        return [uniqueData, duplicateData];
    }

    const verifyCsvData = (csvRecords, setFieldValue, values) => {
        const { role: { roleCode, roleName, roleId }, coeduSupervisor, eduSupervisor, pathwayTag } = values

        let records = csvRecords.map((x) => {
            const isSameAddressSelected = +(x[headers['isSameAddress']]) === 1;
            return {
                userFullName: x[headers.fullName],
                userName: x[headers.userName],
                gender: x[headers.gender],
                dob: getModifiedDate(x[headers.dob], true),
                mobileno1: x[headers.mobileno1],
                mobileno2: x[headers.mobileno2],
                eportfolioEmailId: x[headers.eportfolioEmailId],
                personalEmailId: x[headers.personalEmailId],
                residentialAddress: x[headers.residentialAddress],
                residentialCountry: x[headers.residentialCountry],
                isSameAddress: x[headers.isSameAddress],
                correspondentAddress: isSameAddressSelected ? x[headers.residentialAddress] : x[headers.permenentAddress],
                correspondentCountry: isSameAddressSelected ? x[headers.residentialCountry] : x[headers.permenentCountry],
                mmcno: x[headers.mmcno],

                employeeId: x[headers.employeeId] ?? '',
                mohId: x[headers.mohId] ?? '',
                resourceCode: x[headers.resourceCode] ?? '',
                departmentIds: (roleCode === ERoleDesc.EDUCATIONALSUPERVISOR || roleCode === ERoleDesc.ROTATIONSUPERVISOR) ? (values?.departmentIds?.map(x => x.departmentId)) : [],
                programId: values?.programId?.programId || '',

                roleId,
                roleCode,
                roleName,
                userType: roleCode,
                isMohSupervisor: roleCode === ERoleDesc.MOHSUPERVISOR ? true : false,

                trainee: roleCode === ERoleDesc.Traninee ? {
                    anmno: x[headers.ammNo] ?? '',
                    nsrno: x[headers.nsrNo] ?? '',
                    remark: x[headers.remarks] ?? '',
                    trActiveFrom: getModifiedDate(x[headers.activeFromDate], true) ?? '',
                    trActiveTo: getModifiedDate(x[headers.activeToDate], true) ?? '',
                    trIcNo: x[headers.icNo] ?? '',
                    trLegacyCode: x[headers.legacyCode] ?? '',
                    coEducationalSupervisor: coeduSupervisor?.userId ?? "",
                    educationalSupervisor: eduSupervisor?.userId ?? "",
                    pathwayTag: pathwayTag?.value ?? "",
                    trMohUser: roleCode === ERoleDesc.Traninee ? (pathwayTag?.value === EPathwayTags.CLOSED ? '0' : coeduSupervisor ? '1' : '0') : '0',
                    trStatus: "A"
                } : null
            }
        });

        let [uniqueData, duplicateData] = getDuplicatesData(records);

        uniqueData.forEach(async (record, ind) => {
            try {
                let result = await validationSchema(values.role?.roleCode).validate(record, { abortEarly: false })
                if (result) validData.push(result);
                console.log(`Result${ind}==>`, JSON.stringify(result), validData)
            } catch (e) {
                let errorObj = {};
                let failedReason = e.inner?.length > 0 ?
                    e.inner.reduce((totalErrorMsg, error) => {
                        if (error.path.includes('anmno')) {
                            error.path = error.path.replace('anmno', 'ammno')
                        }
                        errorObj[error.path] = `${errorObj[error.path]?.startsWith(error.path) ? '' : `${error.path}=>`}${errorObj[error.path] ? errorObj[error.path] : ''} ${error.message};`;
                        return Object.values(errorObj);
                    }, []).join(' ') : `${e.path}=> ${e.message}`;
                invalidData.push({ ...e.value, failedReason });
                console.log(`Error${ind}==>`, invalidData, e)
            }
        });
        invalidData.push(...duplicateData);

        setTimeout(() => {
            if (validData?.length === 0 && invalidData?.length) {
                console.timeEnd('_UsersbulkUpload');
                setFieldValue('fileVerification', EBulkUploadStatus.DEFAULT);
                downloadInvalidData();
            }
            if (validData?.length > 0) {
                console.timeEnd('_UsersbulkUpload');
                setFieldValue('isFileValidFlag', 'true');
            }
        }, 0);

        setFieldValue('fileVerification', EBulkUploadStatus.FILE_VALIDATED);
        console.timeEnd('_validationResults=>');
        console.log('result=>', { validData, invalidData });
    }

    const startFileVerification = (setFieldValue, file, values) => {
        console.log('_startFileVerification_start', { file });
        if (file) {
            Papa.parse(file, {
                skipEmptyLines: 'greedy',
                delimiter: ',', header: true, newline: '\r\n',
                beforeFirstChunk: (chunk: string) => {
                    var rows = chunk.split(/\r\n|\r|\n/);
                    let headings = rows[0].split(',');
                    console.log("chunk=>", chunk, headings);
                    let missedHeadings = Object.keys(sampleData).filter(x => !(headings.some(y => y.toLowerCase() === x.toLowerCase())));
                    if (missedHeadings.length > 0) {
                        validationError = missedHeadings;
                        setFieldValue('invalidFileError', `${missedHeadings.join(',')} ${t('controleErrors.headersMissing')}`);
                        setFieldValue('fileVerification', EBulkUploadStatus.DEFAULT)
                        console.log(headings, missedHeadings);
                        return 'Missed Headings'
                    } else {
                        let index3 = headings.findIndex(x => x === null || (x + '').trim() === "");
                        if (index3 !== -1) {
                            validationError = index3
                            setFieldValue('invalidFileError', t('controleErrors.emptyHeaders'));
                            setFieldValue('fileVerification', EBulkUploadStatus.DEFAULT)
                            return "empty";
                        } else setFieldValue('fileVerification', EBulkUploadStatus.HEADERS_MATCHED)
                    }
                    let index4 = _.uniq(_.filter(headings, (v, i, a) => a.findIndex(x => (v + '').trim() === (x + '').trim()) !== i));
                    if (index4.length > 0) {
                        console.log('duplicateheaders===>', index4)
                        validationError = index4
                        setFieldValue('invalidFileError', `${index4.join(',')} ${t('controleErrors.duplicateHeaders')}`);
                        setFieldValue('fileVerification', EBulkUploadStatus.DEFAULT)
                        return "duplicate";
                    }
                    return chunk
                },
                complete: (results) => {
                    console.log("results=>", { results, file });
                    if (results.data.length === 0 && !validationError) {
                        setFieldValue('invalidFileError', t('controleErrors.enterfileData'))
                    }
                    else if (results.data.length > 0) {
                        let _fileText = results.data;
                        verifyCsvData(_fileText, setFieldValue, values);
                    }
                }
            });
        }
        console.log('_startFileVerification_end');
    }

    const uploadFileData = (e, setFieldValue) => {
        const fileList: FileList = e.target.files;
        console.log("frmData=>1", e.target.files);
        if (fileList.length > 0) {
            setFieldValue('extension', '');
            setFieldValue('fileName', '');
            setFieldValue('invalidFileError', '');
            setFieldValue('fileData', '');
            setFieldValue('validData', '');
            setFieldValue('invalidData', '');
            setFieldValue('fileVerification', '');
            setFieldValue('isFileValidFlag', '');
            validData = [];
            invalidData = [];
            validationError = ''
            const file: File = fileList[0];
            console.log("File", file);
            const extension = getFileExtension(file.name);
            const fileSize = getFileSizeInMb(file.size);

            if (fileSize <= EFileSizes.USER_MANAGEMENT_BULK_UPLOAD_MAX_FILE_SIZE) {
                if (extension === 'csv') {
                    setFieldValue('extension', extension);
                    setFieldValue('fileName', fileList[0].name);
                    setFieldValue('fileData', file);
                }
                else
                    setFieldValue('invalidFileError', t('UsersManagement.bulkUploadInvalidFormat'));
                e.target.value = null;
            }
            else
                setFieldValue('invalidFileError', t('controleErrors.maxFileSize'));
        }
    }
    const cancelUserCreationAction = () => dispatch(setUsersActionTypeData(EOprationalActions.UNSELECT, null));

    const selectPathwayTag = (e, setFieldValue) => {
        setFieldValue('pathwayTag', e ? e : '');
        setFieldValue('eduSupervisor', '');
        setFieldValue('coeduSupervisor', '');
    }

    const getEdSupervisorOptions = (values) => {
        const selectedCoedSupervisor = values?.coeduSupervisor?.userId || '';
        return allUserData?.filter(user => user.userType === ERoleDesc.EDUCATIONALSUPERVISOR && user.userId != selectedCoedSupervisor);
    }

    const getCoEdSupervisorOptions = (values) => {
        const selectedPathwayTag = values?.pathwayTag?.value || '';
        const selectededSupervisor = values?.eduSupervisor?.userId || '';

        if (selectedPathwayTag) {
            if (selectedPathwayTag === EPathwayTags.CLOSED)
                return getEdSupervisorOptions(values)?.filter(user => user.userId != selectededSupervisor);
            else if (selectedPathwayTag === EPathwayTags.OPEN || selectedPathwayTag === EPathwayTags.HYBRID)
                return allUserData?.filter(user => user.userType === ERoleDesc.MOHSUPERVISOR);
            else return [];
        }
        else return [];
    };

    const headerColumnMapping = {
        eportfolioEmailId: headers['eportfolioEmailId'],
        gender: headers['gender'],
        mobileno1: headers['mobileno1'],
        mobileno2: headers['mobileno2'],
        userFullName: headers['fullName'],
        userName: headers['userName'],
        anmno: headers['ammNo'],
        dob: headers['dob'],
        isSameAddress: headers['isSameAddress'],
        mmcno: headers['mmcno'],
        nsrno: headers['nsrNo'],
        correspondentAddress: headers['permenentAddress'],
        correspondentCountry: headers['permenentCountry'],
        remark: headers['remarks'],
        residentialAddress: headers['residentialAddress'],
        residentialCountry: headers['residentialCountry'],
        trActiveFrom: headers['activeFromDate'],
        trActiveTo: headers['activeToDate'],
        trIcNo: headers['icNo'],
        trLegacyCode: headers['legacyCode'],
        personalEmailId: headers['personalEmailId'],
        resourceCode: headers['resourceCode'],
        employeeId: headers['employeeId'],
        mohId: headers['mohId']
        // departmentIds: headers['departmentCode'],
        // programId: headers['programCode'],  
    };

    const showInvalidDataAlert = () => {
        // dispatch alert
        const alertMessageData = {
            message: t('controleErrors.invalidData'),
            status: false,
            tranId: Date.now()
        };
        dispatch(alertActionRequest(alertMessageData));
    }

    const downloadInvalidData = () => {
        let invalidUserFileData = invalidData?.map(x => {
            const {
                employeeId, resourceCode, trainee, failedReason,
                roleId, roleCode, roleName, userType, universityId, universityName, isMohSupervisor, mohId, dob, departmentIds, programId, ...rest
            } = x;
            const { coEducationalSupervisor, educationalSupervisor, pathwayTag, trMohUser, trActiveFrom, trActiveTo, trStatus, ...trRest } = trainee ?? {};
            switch (x.userType) {
                case ERoleDesc.Traninee: return { ...rest, dob: getModifiedDate(dob, false), trActiveFrom: getModifiedDate(trActiveFrom, false), trActiveTo: getModifiedDate(trActiveTo, false), ...trRest, failedReason }
                case ERoleDesc.MOHSUPERVISOR: return { mohId, ...rest, dob: getModifiedDate(dob, false), failedReason }
                case ERoleDesc.PROGRAMCOORDINATOR: return { ...rest, dob: getModifiedDate(dob, false), employeeId, failedReason };
                case ERoleDesc.ROTATIONSUPERVISOR:
                case ERoleDesc.EDUCATIONALSUPERVISOR: return {
                    ...rest,
                    dob: getModifiedDate(dob, false),
                    employeeId,
                    failedReason
                }
            }
        });

        console.log('__invalidUserFileData=>', { invalidData, invalidUserFileData });

        showInvalidDataAlert();
        DownloadCsv(undefined, undefined, invalidUserFileData, 'invalidUserData', undefined, headerColumnMapping);
    }

    return (
        <>
            <div className="maincontent paglayout flexScroll">
                <Formik
                    initialValues={initialValues}
                    validationSchema={Yup.object().shape({
                        isFileValidFlag: customContentValidation(t, t('controleErrors.validFile')),
                        role: defultContentObjectValidate(t('controleErrors.required')),
                        pathwayTag: Yup.object().when('role', {
                            is: (role) => role?.roleCode === ERoleDesc.Traninee,
                            then: defultContentObjectValidate(t('controleErrors.required')),
                            otherwise: defultContentObjectValidate(''),
                        }),
                        eduSupervisor: Yup.string().when('role', {
                            is: (role) => role?.roleCode === ERoleDesc.Traninee,
                            then: defultContentValidate(t('controleErrors.required')),
                            otherwise: defultContentValidate(''),
                        }),
                        coeduSupervisor: Yup.string().when(['role', 'pathwayTag'], {
                            is: (role, tag) => role?.roleCode === ERoleDesc.Traninee && tag?.value === EPathwayTags.OPEN,
                            then: defultContentValidate(t('controleErrors.required')),
                            otherwise: defultContentValidate(''),
                        }),
                        departmentIds: Yup.string().when('role', {
                            is: (selectedRole) => (selectedRole?.roleCode === ERoleDesc.ROTATIONSUPERVISOR || selectedRole?.roleCode === ERoleDesc.EDUCATIONALSUPERVISOR),
                            then: defultContentValidate(t('controleErrors.required')),
                            otherwise: defultContentValidate('')
                        }),
                        programId: Yup.string().when('role', {
                            is: (selectedRole) => (selectedRole?.roleCode === ERoleDesc.Traninee || selectedRole?.roleCode === ERoleDesc.PROGRAMCOORDINATOR),
                            then: customContentValidation(t, t('controleErrors.required')),
                            otherwise: defultContentValidate('')
                        }),
                    })}
                    onSubmit={values => {
                        console.log('onSubmit===>', values);

                        if (validData.length > 0) {
                            console.log('_onSubmitvalidData=>', { validData, invalidData });
                            dispatch(bulkUploadUsersDataRequest(values.role, validData, invalidData, headerColumnMapping));
                        }
                        else
                            showInvalidDataAlert();
                    }
                    }
                >
                    {
                        ({ values, setFieldValue, setFieldTouched, errors, touched, handleSubmit }) => {
                            const isTraineeUser = values.role?.['roleCode'] === ERoleDesc.Traninee;
                            const isRotationsupervisor = values.role?.['roleCode'] === ERoleDesc.ROTATIONSUPERVISOR;
                            const isProgramCoordinator = values.role?.['roleCode'] === ERoleDesc.PROGRAMCOORDINATOR;
                            const isEducationalSupervisor = values.role?.['roleCode'] === ERoleDesc.EDUCATIONALSUPERVISOR;

                            return <Form onSubmit={handleSubmit}>
                                <div className="top-section">
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col lg="4" md="6">
                                                <FormGroup>
                                                    <Label>
                                                        {t('UsersManagement.selectRole')}

                                                    </Label>
                                                    <MySelect
                                                        menuPlacement="bottom"
                                                        name="role"
                                                        placeholder={t('UsersManagement.selectRole')}
                                                        value={values.role}
                                                        onChange={(e) => {
                                                            selectUserRole(e, setFieldValue);
                                                        }}
                                                        options={roleOptions}
                                                        getOptionLabel={option => option.roleName}
                                                        getOptionValue={option => option.roleId}
                                                        onBlur={() => setFieldTouched('role', true)}
                                                        noOptionsMessage={() => 'NoDataFound'}
                                                    />
                                                    {errors.role && touched.role ? <div className="text-danger">{errors.role}</div> : ''}
                                                </FormGroup>
                                            </Col>
                                            {(values.role as any).roleCode === ERoleDesc.Traninee && <>
                                                <Col lg="4" md="6">
                                                    <FormGroup>
                                                        <Label>{t('UsersManagement.pathwayTag')}</Label>
                                                        <MySelect
                                                            name="pathwayTag"
                                                            placeholder={t('UsersManagement.pathwayTag')}
                                                            value={values.pathwayTag}
                                                            onChange={(e) => {
                                                                // clearFileSelection(setFieldValue);
                                                                selectPathwayTag(e, setFieldValue);
                                                            }}
                                                            options={pathwayTagOptions}
                                                            onBlur={() => setFieldTouched('pathwayTag', true)}
                                                            noOptionsMessage={() => 'NoDataFound'}
                                                        />
                                                        {errors.pathwayTag && touched.pathwayTag ? <div className="text-danger">{errors.pathwayTag}</div> : ''}
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" md="6">
                                                    <FormGroup>
                                                        <Label>{t('UsersManagement.eduSupervisor')}</Label>
                                                        <MySelect
                                                            name="eduSupervisor"
                                                            placeholder={t('UsersManagement.eduSupervisor')}
                                                            value={values.eduSupervisor}
                                                            onChange={(e) => {
                                                                // clearFileSelection(setFieldValue);
                                                                setFieldValue('eduSupervisor', e ? e : '');
                                                            }}
                                                            options={getEdSupervisorOptions(values)}
                                                            getOptionLabel={option => option.userFullName}
                                                            getOptionValue={option => option.userId}
                                                            onBlur={() => setFieldTouched('eduSupervisor', true)}
                                                            noOptionsMessage={() => 'NoDataFound'}
                                                        />
                                                        {errors.eduSupervisor && touched.eduSupervisor ? <div className="text-danger">{errors.eduSupervisor}</div> : ''}
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" md="6">
                                                    <FormGroup>
                                                        <Label>{t('UsersManagement.coeduSupervisor')}</Label>
                                                        <MySelect
                                                            name="coeduSupervisor"
                                                            placeholder={t('UsersManagement.coeduSupervisor')}
                                                            value={values.coeduSupervisor}
                                                            onChange={(e) => {
                                                                // clearFileSelection(setFieldValue);
                                                                setFieldValue('coeduSupervisor', e ? e : '');
                                                            }}
                                                            options={getCoEdSupervisorOptions(values)}
                                                            isClearable={true}
                                                            getOptionLabel={option => option.userFullName}
                                                            getOptionValue={option => option.userId}
                                                            onBlur={() => setFieldTouched('coeduSupervisor', true)}
                                                            noOptionsMessage={() => 'NoDataFound'}
                                                        />
                                                        {errors.coeduSupervisor && touched.coeduSupervisor ? <div className="text-danger">{errors.coeduSupervisor}</div> : ''}
                                                    </FormGroup>
                                                </Col>
                                            </>}

                                            {(isRotationsupervisor || isEducationalSupervisor) &&
                                                <Col md="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t('UsersManagement.dept')}</Label>
                                                        <MySelect
                                                            name="departmentIds"
                                                            allOption={{
                                                                departmentName: "Select All Departments",
                                                                departmentId: 0
                                                            }}
                                                            isMulti={true}
                                                            placeholder={t('UsersManagement.dept')}
                                                            options={deptDetails || []}
                                                            value={values.departmentIds ? values.departmentIds : []}
                                                            onChange={(e) => setFieldValue('departmentIds', e ? e : '')}
                                                            getOptionLabel={option => option.departmentName}
                                                            getOptionValue={option => option.departmentId}
                                                            valueKey="departmentId"
                                                            components={{ Option, ValueContainer }}
                                                            hideSelectedOptions={false}
                                                            removeSelected={false}
                                                            closeMenuOnSelect={false}
                                                            backspaceRemovesValue={false}
                                                            isSearchable={true}
                                                            allowSelectAll={false}
                                                            onBlur={() => setFieldTouched('levels', true)}
                                                            noOptionsMessage={() => t('UsersManagement.noDeptsFound')}
                                                        />
                                                        {errors.departmentIds && touched.departmentIds && (
                                                            <div className="text-danger">{errors.departmentIds}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>}


                                            {(isProgramCoordinator || isTraineeUser) && <Col md="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('UsersManagement.selectProgrameeCode')}</Label>
                                                    <MySelect
                                                        name="programId"
                                                        placeholder={t('UsersManagement.selectProgrameeCode')}
                                                        value={values.programId}
                                                        onChange={(e) => setFieldValue('programId', e ? e : '')}
                                                        options={programsOptions}
                                                        getOptionLabel={option => option.programName}
                                                        getOptionValue={option => option.programId}
                                                        onBlur={() => setFieldTouched('programId', true)}
                                                        noOptionsMessage={() => 'NoDataFound'}
                                                    />
                                                    {errors.programId && touched.programId && (
                                                        <div className="text-danger">{errors.programId}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>}
                                        </Row>
                                        <hr />
                                    </div>
                                </div>

                                <div className="top-section">
                                    {values.role && <h2>{t('UsersManagement.fileUpload')}</h2>}
                                    <div className="details-section mt-3">
                                        {values.role && <Row>
                                            <Col lg="7" md="10" className="upload-btn d-flex">
                                                <Col md="10">
                                                    <FormGroup style={{ float: "left" }}>
                                                        <Label>{t('UsersManagement.browseFile')}</Label><br />
                                                        <input type="file" placeholder={t('UsersManagement.browseFile')} id="actual-btn" hidden onChange={(e) => uploadFileData(e, setFieldValue)} />
                                                        <div id="blockele">
                                                            <div className="d-flex flex-row" id="file-chosen"><div className="mr-2"><i className="ti-folder"></i> </div><div className="fu-fileName">{values.fileName}</div></div>
                                                            <label htmlFor="actual-btn" className="choose">{t('UsersManagement.selectFile')}</label>
                                                            <div className="sampledownloadFile mt-1 pointer" onClick={() => DownloadCsvRequest((values.role as any))}>
                                                                <img src={download} alt="" />
                                                                {t('UsersManagement.sampleFiles')}
                                                            </div><br />


                                                            {((values.fileData || values.fileVerification === EBulkUploadStatus.HEADERS_MATCHED) && !values.fileVerification) &&
                                                                <div className="verify-sec">
                                                                    <Row>
                                                                        <Col sm="12" className="text-center mb-1"><span>{t('UsersManagement.verifyupload')}</span> </Col>
                                                                        <Col className="text-center">
                                                                            <button type="button"
                                                                                className='btn blue-button verifyBtn ml-3'
                                                                                disabled={!values.role || !values.fileData}
                                                                                // disabled={((values.role as any)?.roleCode === ERoleDesc.Traninee) ? (!values.pathwayTag || !values.eduSupervisor) : false}
                                                                                onClick={() => {
                                                                                    console.time('_UsersbulkUpload');
                                                                                    setFieldValue('fileVerification', EBulkUploadStatus.PROCESSING);
                                                                                    setFieldTouched('isFileValidFlag', true);
                                                                                    startFileVerification(setFieldValue, values.fileData, values);
                                                                                }}>
                                                                                {t('ActionNames.verify')}
                                                                            </button>
                                                                        </Col>

                                                                    </Row>

                                                                </div>
                                                            }

                                                            {(values.isFileValidFlag) && <div className="verify-sec"><i className="icon-verified-icon mr-1" style={{ fontSize: '15px', color: 'green' }} />{t('UsersManagement.verifysuccess')}</div>}

                                                            {values.fileVerification === EBulkUploadStatus.PROCESSING && (
                                                                <>
                                                                    {/* <button type="button" onClick={cancelFileProcessing}>{t('ActionNames.cancel')}</button> */}
                                                                    <h3 className="processMsg">{t('UsersManagement.validatingCsvMsg')}</h3>
                                                                </>
                                                            )}
                                                        </div>
                                                        <div>
                                                            {!values.invalidFileError && <div className="fileuplod-note verify-sec">{t('UsersManagement.extentionError')}</div>}
                                                            {values.invalidFileError && <div className="fileuplod-note verify-sec">{values.invalidFileError}</div>}

                                                            {(errors.isFileValidFlag && touched.isFileValidFlag) && (
                                                                <div className="text-danger verify-sec">{errors.isFileValidFlag}</div>
                                                            )}
                                                        </div>
                                                    </FormGroup>
                                                </Col>
                                            </Col>
                                        </Row>}
                                        <div className="sub-form-footer mt-3">
                                            <button className="cancel-button" type='button' onClick={cancelUserCreationAction}>{t('ActionNames.cancel')}</button>
                                            <button type='submit' className='btn blue-button'>{t('ActionNames.create')}</button>
                                            {/* <button type='submit' disabled={values.fileVerification !== EBulkUploadStatus.FILE_VALIDATED} className='btn blue-button'>{t('ActionNames.create')}</button> */}
                                        </div>
                                    </div>
                                </div>
                            </Form>
                        }
                    }
                </Formik>
            </div>
        </>
    )
}
export default React.memo(BulkUpload);