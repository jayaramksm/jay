import { EOprationalActions, ERoleDesc } from '../../../../models/utilitiesModel';
import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { IUserManagementModel } from '../../../../models/userManagementModel';
import { Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { ParentContext, SuperParentContext } from '../Container/usermanagementcontext';
import classnames from 'classnames';
import { setUsersActionTypeData } from '../../../../store/actions';
import { Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { useTranslation } from 'react-i18next';

const UserManagementAction: React.FC = () => {
    const context = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const actionType = useSelector((state: any) => {
        if (state && state.userManagementReducer && state.userManagementReducer.actionType)
            return (state.userManagementReducer as IUserManagementModel).actionType;
        else
            return EOprationalActions.UNSELECT;
    });
    const loggedInRoleCode = useSelector((state: any) => state?.SessionState?.userDto?.roles?.roleCode || '');
    console.log("UserManagementAction=>", { loggedInRoleCode, actionType, context });

    const handleChange = () => dispatch(setUsersActionTypeData(EOprationalActions.UNSELECT, null));
    const showBulkUpload = () => dispatch(setUsersActionTypeData(EOprationalActions.BULKUPLOAD, null));
    const showCreateUser = () => {
        if (actionType !== EOprationalActions.EDIT)
            dispatch(setUsersActionTypeData(EOprationalActions.ADD, null));
    };

    return (
        <>
            <div className="breadcrumbs">
                <span className="pointer" onClick={handleChange}>{t('UsersManagement.usersRoles')}</span>
                <span><i className="ti-angle-right"></i></span>
                <span className="active">{actionType === EOprationalActions.ADD ? t('UsersManagement.createUser') : actionType === EOprationalActions.EDIT ? t('UsersManagement.editUser') : t('UsersManagement.bulkUpload')}</span>
            </div>
            <div className="uploadTabs flexLayout pr-0">
                <Nav tabs>
                    <NavItem>
                        <NavLink onClick={showCreateUser}
                            className={classnames({ active: actionType === EOprationalActions.ADD })}>
                            <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                            <span className="d-none d-sm-block">{actionType === EOprationalActions.EDIT ? t('UsersManagement.editUser') : t('UsersManagement.createUser')}</span>
                        </NavLink>
                    </NavItem>

                    {(actionType !== EOprationalActions.EDIT && loggedInRoleCode !== ERoleDesc.PLATFORMADMIN) && < NavItem >
                        <NavLink onClick={showBulkUpload} className={classnames({ active: actionType === EOprationalActions.BULKUPLOAD })}>
                            <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                            <span className="d-none d-sm-block">{t('UsersManagement.bulkUpload')}</span>
                        </NavLink>
                    </NavItem>}


                </Nav>
                <TabContent className="flexLayout pr-0">
                    {((actionType === EOprationalActions.ADD) || (actionType === EOprationalActions.EDIT)) && <TabPane className="flexLayout pr-0">
                        <context.userCreationOrEditComponent />
                    </TabPane>}
                    {(actionType === EOprationalActions.BULKUPLOAD && loggedInRoleCode !== ERoleDesc.PLATFORMADMIN) && <TabPane className="flexLayout pr-0">
                        <ParentContext.Provider value={{ bulkUploadComponent: context.bulkUploadComponent, bulkUploadViewComponent: context.bulkUploadViewComponent }}>
                            <context.bulkUploadManagerComponent />
                        </ParentContext.Provider>
                    </TabPane>}
                </TabContent>
            </div>
        </>
    )
}

export default React.memo(UserManagementAction)