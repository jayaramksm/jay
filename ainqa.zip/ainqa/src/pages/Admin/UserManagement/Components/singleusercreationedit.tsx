import React from 'react';
import { Row, Col, Input, FormGroup, Label, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import DatePicker from "react-datepicker";
import { useSelector, useDispatch } from 'react-redux';
import { EPathwayTags, IDepartment, IProgram, IRoles, IUser, IUserManagementModel } from '../../../../models/userManagementModel';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { createOrEditSingleUsersRequest, setUsersActionTypeData } from '../../../../store/actions';
import { EOprationalActions, ERoleDesc, ERoleId, ERoleNames, ICurrentDateAndTime, IUniversity } from '../../../../models/utilitiesModel';
import { MySelect, defultContentValidate, customContentValidation, emailContentValidate, defultContentObjectValidate, ValueContainer, Option } from '../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import isEmpty from 'lodash/isEmpty';
import "react-datepicker/dist/react-datepicker.css";

const pathwayTags = [
    { value: 'open', label: 'Open' },
    { value: 'closed', label: 'Closed' },
    { value: 'hybrid', label: 'Hybrid' }
];
const countryOptions = [
    { value: 'MYS', label: 'Malaysia' },
    { value: 'IND', label: 'India' },
    { value: 'IDN', label: 'Indonesia' }
];
const genderOptions = [{ value: 'M', label: 'Male' }, { value: 'F', label: 'Female' }, { value: 'T', label: 'Transgender' }];

const SingleUserCreationOrEdit: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const isPlatformAdmin = useSelector((state: any) => state?.SessionState?.userDto?.roles?.roleCode === ERoleDesc.PLATFORMADMIN || false);
    const usersData: IUser[] = useSelector((state: any) => state?.userManagementReducer?.usersData);
    const rolesData: IRoles[] = useSelector((state: any) => state?.userManagementReducer?.rolesData);
    const departmentOptions: IDepartment[] | any = useSelector((state: any) => state?.userManagementReducer?.deptsData || []);
    const programsOptions: IProgram[] | any = useSelector((state: any) => state?.userManagementReducer?.programsData || []);
    const universitiesData: IUniversity[] = useSelector((state: any) => state?.userManagementReducer?.universitiesData || []);
    const actionData: IUser = useSelector((state: any) => state?.userManagementReducer?.actionData);
    const actionType: number = useSelector((state: any) => {
        if (state && state.userManagementReducer)
            return (state && state.userManagementReducer as IUserManagementModel).actionType;
        else return EOprationalActions.UNSELECT;
    });
    const { universityName, universityCode, universityId } = useSelector((state: any) => state?.SessionState?.userDto?.university || {});
    console.log("_SingleUserCreationOrEdit=>", { usersData, rolesData, actionData, departmentOptions, programsOptions });

    const currentDateAndTime: ICurrentDateAndTime = useSelector((state: any) => state?.userManagementReducer?.currentDate);
    const handleDateofBirthChange = (selectedDate: any, setFieldValue: any) => setFieldValue('dob', selectedDate);
    const handletraineeActiveFromDate = (selectedFromDate: any, setFieldValue: any) => setFieldValue('trActiveFrom', selectedFromDate);
    const handletraineeActiveToDate = (selectedToDate: any, setFieldValue: any) => setFieldValue('trActiveTo', selectedToDate);
    const handleAddress = async (isChecked, setFieldValue, values) => {
        setFieldValue('isSameAddress', isChecked);
        if (isChecked) {
            await setFieldValue('correspondentCountry', values.residentialCountry);
            await setFieldValue('correspondentAddress', values.residentialAddress);
        } else {
            await setFieldValue('correspondentAddress', '');
            await setFieldValue('correspondentCountry', '');
        }
    };
    const handleChange = (setFieldTouched, values, setFieldValue) => {
        setFieldTouched('residentialAddress', true);
        if (values.isSameAddress && values.residentialAddress !== values.correspondentAddress)
            setFieldValue('correspondentAddress', values.residentialAddress);
    };
    const handleCountryChange = (setFieldTouched, values, setFieldValue) => {
        setFieldTouched('residentialCountry', true);
        if (values.isSameAddress && values.residentialCountry !== values.correspondentCountry)
            setFieldValue('correspondentCountry', values.residentialCountry);
    };
    const handleEportfolioEmail = (setFieldTouched) => {
        setFieldTouched('eportfolioEmailId', true);
    };

    const patchRole = (actionData) => {
        if (isPlatformAdmin)
            return { roleCode: ERoleDesc.PLATFORMADMIN, roleId: ERoleId.PLATFORMADMIN, roleName: ERoleNames.PLATFORMADMIN };
        else {
            if (actionData)
                return rolesData?.find(x => x.roleId == actionData?.roleId);
            else return '';
        }
    }

    const initialValues = () => ({
        userId: actionData?.userId || '',
        roles: patchRole(actionData),
        correspondentAddress: actionData?.correspondentAddress || '',
        correspondentCountry: actionData ? countryOptions.find(x => x.value === actionData?.correspondentCountry) : '',
        departmentIds: (actionData?.departmentIds?.length) ? (departmentOptions?.filter(x => actionData.departmentIds.includes(x.departmentId))) : [],
        dob: actionData?.dob ? new Date(actionData.dob) : '',
        employeeId: actionData?.employeeId || '',
        eportfolioEmailId: actionData?.eportfolioEmailId || '',
        gender: actionData?.gender ? genderOptions.find(x => x.value === actionData?.gender) : '',
        isMohSupervisor: actionData ? !!(actionData?.isMohSupervisor) : false,
        isSameAddress: actionData ? (actionData?.isSameAddress === 1) : false,
        mmcno: actionData?.mmcno || '',
        mobileno1: actionData?.mobileno1 || '',
        mobileno2: actionData?.mobileno2 || '',
        mohId: actionData?.mohId || '',
        personalEmailId: actionData?.personalEmailId || '',
        programId: (actionData?.programId) ? programsOptions?.find(x => x.programId == actionData?.programId) : '',
        residentialAddress: actionData?.residentialAddress || '',
        residentialCountry: actionData ? countryOptions?.find(x => x.value === actionData?.residentialCountry) : '',
        resourceCode: '',
        universityId,
        universityName,
        universityCode,
        userFullName: actionData?.userFullName || '',
        userName: actionData?.userName || '',
        userType: actionData?.userType || '',

        anmno: actionData?.trainee?.anmno || '',
        coEducationalSupervisor: (actionData?.trainee?.coEducationalSupervisor) ? (usersData?.find(user => user.userId == actionData?.trainee?.coEducationalSupervisor)) : '',
        educationalSupervisor: (actionData?.trainee?.educationalSupervisor) ? (usersData?.find(user => user.userId == actionData?.trainee?.educationalSupervisor)) : '',
        nsrno: actionData?.trainee?.nsrno || '',
        trIcNo: actionData?.trainee?.trIcNo || '',
        trLegacyCode: actionData?.trainee?.trLegacyCode || '',
        trStatus: "A",
        // trStatus: (actionData && actionData?.trainee) ? "A" : "",
        remark: actionData?.trainee?.remark || '',
        trActiveTo: actionData?.trainee?.trActiveTo ? new Date(actionData.trainee.trActiveTo) : null,
        trActiveFrom: actionData?.trainee?.trActiveFrom ? new Date(actionData.trainee.trActiveFrom) : null,
        trId: actionData?.trainee?.trId || '',
        trMohUser: (actionData?.trainee?.pathwayTag !== EPathwayTags.CLOSED) ? (actionData?.trainee?.coEducationalSupervisor ? "1" : "0") : "0",
        pathwayTag: (actionData?.trainee?.pathwayTag) ? (pathwayTags.find(x => x.value === actionData.trainee.pathwayTag)) : '',
        university: (isPlatformAdmin && actionData?.universityId) ? (universitiesData?.find(x => x.universityId == actionData?.universityId)) : '',
        designation: actionData?.designation || ''
    });

    const validationSchema = Yup.object().shape({
        roles: defultContentObjectValidate(t('controleErrors.required')),
        correspondentAddress: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: '' }, 250, 4),
        }),
        correspondentCountry: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: defultContentValidate(t('controleErrors.required')),
        }),
        departmentIds: Yup.string().when('roles', {
            is: (selectedRole) => (selectedRole?.roleCode === ERoleDesc.ROTATIONSUPERVISOR || selectedRole?.roleCode === ERoleDesc.EDUCATIONALSUPERVISOR),
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        dob: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: defultContentValidate(t('controleErrors.required')),
        }),
        employeeId: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.Traninee || selectedRole?.roleCode === ERoleDesc.MOHSUPERVISOR || selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 20, 1)
        }),
        eportfolioEmailId: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        gender: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: defultContentValidate(t('controleErrors.required')),
        }),
        mmcno: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 4)
        }),
        // mobileno1: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 10, 10),
        mobileno1: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1),
        }),
        mobileno2: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1),
            otherwise: Yup.lazy((value) => {
                if (!value)
                    return defultContentValidate('');
                else return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1)
            }),
        }),
        mohId: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.MOHSUPERVISOR,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 20, 1),
            otherwise: defultContentValidate('')
        }),
        personalEmailId: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        programId: Yup.string().when('roles', {
            is: (selectedRole) => (selectedRole?.roleCode === ERoleDesc.Traninee || selectedRole?.roleCode === ERoleDesc.PROGRAMCOORDINATOR),
            then: customContentValidation(t, t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        residentialAddress: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: '' }, 250, 4),
        }),
        residentialCountry: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(''),
            otherwise: defultContentValidate(t('controleErrors.required')),
        }),
        userFullName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 100, 4),
        userName: Yup.string().when('roles', {
            is: selectedRole => selectedRole?.roleCode === ERoleDesc.Traninee,
            then: Yup.string().required(t('controleErrors.required')).oneOf([Yup.ref('mmcno'), null], t('UsersManagement.trUsernameMMC')),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 4)
        }),
        anmno: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.Traninee,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 1),
            otherwise: defultContentValidate('')
        }),
        coEducationalSupervisor: Yup.string().when(['roles', 'pathwayTag'], {
            is: (selectedRole, selectedPathwayTag) => selectedRole?.roleCode === ERoleDesc.Traninee && selectedPathwayTag?.value === EPathwayTags.OPEN,
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        educationalSupervisor: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.Traninee,
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        nsrno: Yup.lazy((NsrNumber) => {
            if (NsrNumber !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 1);
            else return defultContentValidate('');
        }),
        trIcNo: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.Traninee,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'traineeIcNumber', message: 'traineeIcNumber', spacialChar: '' }, 14, 14),
            otherwise: defultContentValidate('')
        }),
        trLegacyCode: Yup.lazy((trLegacyCode) => {
            if (trLegacyCode !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 25, 1)
            else return defultContentValidate('');
        }),
        remark: Yup.lazy((remarks) => {
            if (remarks !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumaricandspace', spacialChar: '' }, 255, 1);
            else return defultContentValidate('');
        }),
        trActiveTo: Yup.lazy(trActiveToVal => {
            if (trActiveToVal)
                return defultContentValidate(t('controleErrors.required'))
            else return defultContentValidate('');
        }),
        trActiveFrom: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.Traninee,
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        pathwayTag: Yup.mixed().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.Traninee,
            then: defultContentObjectValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        university: Yup.string().when('roles', {
            is: (selectedRole) => selectedRole?.roleCode === ERoleDesc.PLATFORMADMIN,
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        designation: Yup.lazy((value) => {
            if (!value)
                return defultContentValidate('');
            else return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 50, 1)
        })
    });

    const cancelUserCreationAction = () => {
        dispatch(setUsersActionTypeData(EOprationalActions.UNSELECT, null));
    };

    const getEdSupervisorOptions = (values) => {
        const selectedCoedSupervisor = values?.coEducationalSupervisor?.userId || '';
        return usersData?.filter(user => user.userType === ERoleDesc.EDUCATIONALSUPERVISOR && user.userId != selectedCoedSupervisor);
    }

    const getCoEdSupervisorOptions = (values) => {
        const selectedPathwayTag = values?.pathwayTag?.value || '';
        const selectededSupervisor = values?.educationalSupervisor?.userId || '';

        if (selectedPathwayTag) {
            if (selectedPathwayTag === EPathwayTags.CLOSED)
                return getEdSupervisorOptions(values)?.filter(user => user.userId != selectededSupervisor);
            else if (selectedPathwayTag === EPathwayTags.OPEN || selectedPathwayTag === EPathwayTags.HYBRID)
                return usersData?.filter(user => user.userType === ERoleDesc.MOHSUPERVISOR);
            else return [];
        }
        else return [];
    };

    const handlePathwayTagSelection = (e, setFieldValue) => {
        setFieldValue('pathwayTag', e || '');
        setFieldValue('educationalSupervisor', '');
        setFieldValue('coEducationalSupervisor', '');
    }

    return (
        <div className="mydocuments flexLayout">
            <div className="paglayout flexScroll">
                <div className="maincontent mt-3">
                    <Formik
                        initialValues={initialValues()}
                        validationSchema={validationSchema}
                        onSubmit={(values) => {
                            console.log("SubmitedValues==>", values);
                            dispatch(createOrEditSingleUsersRequest(values, actionType, isPlatformAdmin));
                        }}>
                        {({ errors, setFieldValue, dirty, setFieldTouched, values, touched, resetForm }) => {
                            const isTraineeUser = values.roles?.['roleCode'] === ERoleDesc.Traninee;
                            const isRotationsupervisor = values.roles?.['roleCode'] === ERoleDesc.ROTATIONSUPERVISOR;
                            const isProgramCoordinator = values.roles?.['roleCode'] === ERoleDesc.PROGRAMCOORDINATOR;
                            const isEducationalSupervisor = values.roles?.['roleCode'] === ERoleDesc.EDUCATIONALSUPERVISOR;
                            const isMohEducationalSupervisor = values.roles?.['roleCode'] === ERoleDesc.MOHSUPERVISOR;
                            const isEditActionType = actionType === EOprationalActions.EDIT;
                            const isRoleSelected = !isEmpty(values?.roles?.['roleCode']);

                            return (
                                <Form>
                                    <div className="top-section">
                                        <div className="details-section">
                                            {isPlatformAdmin && <Row>
                                                <Col md="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t('UsersManagement.selectUniversity')}</Label>
                                                        <MySelect
                                                            name="university"
                                                            placeholder={t('UsersManagement.selectUniversity')}
                                                            isDisabled={isEditActionType}
                                                            value={values.university}
                                                            onChange={(e) => {
                                                                setFieldValue('university', e || '');
                                                            }}
                                                            options={universitiesData}
                                                            getOptionLabel={option => option.universityName}
                                                            getOptionValue={option => option.universityId}
                                                            onBlur={() => setFieldTouched('university', true)}
                                                            noOptionsMessage={() => { t('UsersManagement.noDataFound') }}
                                                        />
                                                        {errors.university && touched.university && (
                                                            <div className="text-danger">{errors.university}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                                {values.university && <Col md="6" lg="4">
                                                    <Label>
                                                        {t('UsersManagement.selectUnivercityCode')}

                                                    </Label>
                                                    <Field disabled={true} className="form-control" value={(values.university as any)?.universityCode} />
                                                </Col>}

                                                <Col md="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t('UsersManagement.adminDesignation')}</Label>
                                                        <Field placeholder={t('UsersManagement.adminDesignation')} name="designation" className={'form-control ' + (errors.designation && touched.designation ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="designation" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>}
                                            {!isPlatformAdmin && <>
                                                <Row>
                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.selectRole')}</Label>
                                                            <MySelect
                                                                name="roles"
                                                                placeholder={t('UsersManagement.selectRole')}
                                                                isDisabled={isEditActionType}
                                                                value={values.roles}
                                                                onChange={(e) => {
                                                                    resetForm();
                                                                    setFieldValue('roles', e ? e : '');
                                                                }}
                                                                options={rolesData ? rolesData : []}
                                                                getOptionLabel={option => option.roleName}
                                                                getOptionValue={option => option.roleId}
                                                                onBlur={() => setFieldTouched('roles', true)}
                                                                noOptionsMessage={() => { t('UsersManagement.noDataFound') }}
                                                            />
                                                            {errors.roles && touched.roles && (
                                                                <div className="text-danger">{errors.roles}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                                {isTraineeUser && <Row>
                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label> {t('UsersManagement.pathwayTag')}</Label>
                                                            <MySelect
                                                                name="pathwayTag"
                                                                isDisabled={isEditActionType}
                                                                placeholder={t('UsersManagement.pathwayTag')}
                                                                value={values.pathwayTag}
                                                                onChange={(e) => handlePathwayTagSelection(e, setFieldValue)}
                                                                options={pathwayTags}
                                                                getOptionLabel={option => option.label}
                                                                getOptionValue={option => option.value}
                                                                onBlur={() => setFieldTouched('pathwayTag', true)}
                                                                noOptionsMessage={() => { t('UsersManagement.noDataFound') }}
                                                            />
                                                            {errors.pathwayTag && touched.pathwayTag && (
                                                                <div className="text-danger">{errors.pathwayTag}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.eduSupervisor')}</Label>

                                                            <MySelect
                                                                name="educationalSupervisor"
                                                                isDisabled={isEditActionType}
                                                                placeholder={t('UsersManagement.eduSupervisor')}
                                                                value={values.educationalSupervisor}
                                                                onChange={(e) => setFieldValue('educationalSupervisor', e ? e : '')}
                                                                options={getEdSupervisorOptions(values)}
                                                                getOptionLabel={option => option.userFullName}
                                                                getOptionValue={option => option.userId}
                                                                onBlur={() => setFieldTouched('educationalSupervisor', true)}
                                                                noOptionsMessage={() => { t('UsersManagement.noDataFound') }}
                                                            />
                                                            {errors.educationalSupervisor && touched.educationalSupervisor && (
                                                                <div className="text-danger">{errors.educationalSupervisor}</div>
                                                            )}

                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.coeduSupervisor')}</Label>
                                                            <MySelect
                                                                name="coEducationalSupervisor"
                                                                isDisabled={isEditActionType}
                                                                placeholder={t('UsersManagement.coeduSupervisor')}
                                                                value={values.coEducationalSupervisor}
                                                                onChange={(e) => setFieldValue('coEducationalSupervisor', e ? e : '')}
                                                                options={getCoEdSupervisorOptions(values)}
                                                                isClearable={true}
                                                                getOptionLabel={option => option.userFullName}
                                                                getOptionValue={option => option.userId}
                                                                onBlur={() => setFieldTouched('coEducationalSupervisor', true)}
                                                                noOptionsMessage={() => { t('Hods.NoDataFound') }}
                                                            />
                                                            {errors.coEducationalSupervisor && touched.coEducationalSupervisor && (
                                                                <div className="text-danger">{errors.coEducationalSupervisor}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                </Row>}
                                            </>}
                                        </div>
                                    </div>

                                    {isRoleSelected && <>
                                        <div className="top-section">
                                            <h2><div>{t('UsersManagement.userPersonalDetails')}</div></h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.userFullName')}</Label>
                                                            <Field placeholder={t('UsersManagement.userFullName')} name="userFullName" className={'form-control ' + (errors.userFullName && touched.userFullName ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="userFullName" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>
                                                    {!isPlatformAdmin && <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.dob')}</Label>

                                                            <DatePicker className="w100 datepickerIcon form-control" placeholderText={t('UsersManagement.dob')} name="dob"
                                                                popperPlacement="bottom"
                                                                popperModifiers={{
                                                                    flip: {
                                                                        behavior: ["bottom"]
                                                                    },
                                                                    preventOverflow: {
                                                                        enabled: false
                                                                    }
                                                                }}
                                                                selected={values.dob || ''}
                                                                onChange={(e) => handleDateofBirthChange(e, setFieldValue)}
                                                                dateFormat={'dd-MM-yyyy'}
                                                                maxDate={new Date(currentDateAndTime?.date)}
                                                                onBlur={() => setFieldTouched('dob', true)}
                                                                autoComplete="off"
                                                                showMonthDropdown
                                                                showYearDropdown
                                                                dropdownMode="select"
                                                            />
                                                            {errors.dob && touched.dob && (
                                                                <div className="text-danger">{errors.dob}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>}
                                                    {!isPlatformAdmin && <>
                                                        <Col md="6" lg="4">
                                                            <FormGroup>
                                                                <Label>{t('UsersManagement.gender')}</Label>
                                                                <MySelect
                                                                    name="gender"
                                                                    placeholder={t('UsersManagement.gender')}
                                                                    value={values.gender}
                                                                    onChange={(e) => setFieldValue('gender', e ? e : '')}
                                                                    options={genderOptions ? genderOptions : []}
                                                                    getOptionLabel={option => option.label}
                                                                    getOptionValue={option => option.value}
                                                                    onBlur={() => setFieldTouched('gender', true)}
                                                                    noOptionsMessage={() => 'NoDataFound'}
                                                                />
                                                                {errors.gender && touched.gender && (
                                                                    <div className="text-danger">{errors.gender}</div>
                                                                )}
                                                            </FormGroup>
                                                        </Col>
                                                        {(!isTraineeUser && !isMohEducationalSupervisor && !isPlatformAdmin) && <Col md="6" lg="4">
                                                            <FormGroup>
                                                                <Label>{t('UsersManagement.empId')}</Label>
                                                                <Field placeholder={t('UsersManagement.empId')} name="employeeId" className={'form-control ' + (errors.employeeId && touched.employeeId ? 'is-invalid' : '')} />
                                                                <ErrorMessage name="employeeId" component="div" className="invalid-feedback" />
                                                            </FormGroup>
                                                        </Col>}
                                                        {isMohEducationalSupervisor && <Col md="6" lg="4">
                                                            <FormGroup>
                                                                <Label>{t('UsersManagement.mohId')}</Label>
                                                                <Field placeholder={t('UsersManagement.mohId')} name="mohId" className={'form-control ' + (errors.mohId && touched.mohId ? 'is-invalid' : '')} />
                                                                <ErrorMessage name="mohId" component="div" className="invalid-feedback" />
                                                            </FormGroup>
                                                        </Col>}
                                                    </>}
                                                </Row>
                                            </div>
                                            <hr />
                                        </div>

                                        <div className="top-section">
                                            <h2><div>{t('UsersManagement.userContactDetails')}</div></h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.contact1')}</Label>
                                                            <Field placeholder={t('UsersManagement.contact1')} name="mobileno1" className={'form-control ' + (errors.mobileno1 && touched.mobileno1 ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="mobileno1" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.contact2')}

                                                            </Label>
                                                            <Field placeholder={t('UsersManagement.contact2')} name="mobileno2" className={'form-control ' + (errors.mobileno2 && touched.mobileno2 ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="mobileno2" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>


                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.emailID')}</Label>
                                                            <Field placeholder={t('UsersManagement.emailID')} name="personalEmailId" className={'form-control ' + (errors.personalEmailId && touched.personalEmailId ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="personalEmailId" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                            <hr />
                                        </div>

                                        {!isPlatformAdmin && <><div className="top-section">
                                            <h2><div>{t('UsersManagement.userAddressDetails')}</div></h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label> {t('UsersManagement.residentialaddress')}</Label>
                                                            <Field placeholder={t('UsersManagement.residentialaddress')} onBlur={() => handleChange(setFieldTouched, values, setFieldValue)} name="residentialAddress" className={'form-control ' + (errors.residentialAddress && touched.residentialAddress ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="residentialAddress" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.selectResidentalCountry')}</Label>
                                                            <MySelect
                                                                name="residentialCountry"
                                                                placeholder={t('UsersManagement.selectResidentalCountry')}
                                                                value={values.residentialCountry}
                                                                onChange={(e) => setFieldValue('residentialCountry', e ? e : '')}
                                                                options={countryOptions ? countryOptions : []}
                                                                getOptionLabel={option => option.label}
                                                                getOptionValue={option => option.value}
                                                                onBlur={() => handleCountryChange(setFieldTouched, values, setFieldValue)}
                                                                noOptionsMessage={() => 'NoDataFound'}
                                                            />
                                                            {errors.residentialCountry && touched.residentialCountry && (
                                                                <div className="text-danger">{errors.residentialCountry}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.correspondentAddress')}</Label>
                                                            <FormGroup check>
                                                                <Label check>
                                                                    <Input type="checkbox" checked={values.isSameAddress} onChange={(e) => handleAddress(e.target.checked, setFieldValue, values)} />{' '}{t('UsersManagement.sameCorrespondentAddress')}</Label>
                                                            </FormGroup>
                                                        </FormGroup>
                                                    </Col>
                                                </Row>

                                                <Row className="mt-3">
                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.correspondentAddress')}</Label>
                                                            <Field disabled={values.isSameAddress === true} placeholder={t('UsersManagement.correspondentAddress')} name="correspondentAddress" className={'form-control ' + (errors.correspondentAddress && touched.correspondentAddress ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="correspondentAddress" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.selectParmanentCountry')}</Label>
                                                            <MySelect
                                                                name="correspondentCountry"
                                                                placeholder={t('UsersManagement.selectParmanentCountry')}
                                                                value={values.correspondentCountry}
                                                                isDisabled={values.isSameAddress === true}
                                                                onChange={(e) => setFieldValue('correspondentCountry', e ? e : '')}
                                                                options={countryOptions ? countryOptions : []}
                                                                getOptionLabel={option => option.label}
                                                                getOptionValue={option => option.value}
                                                                onBlur={() => setFieldTouched('correspondentCountry', true)}
                                                                noOptionsMessage={() => 'NoDataFound'}
                                                            />
                                                            {errors.correspondentCountry && touched.correspondentCountry && (
                                                                <div className="text-danger">{errors.correspondentCountry}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                            <hr />
                                        </div>
                                        </>}

                                        <div className="top-section">
                                            <h2><div>{t('UsersManagement.umDetails')}</div></h2>
                                            <div className="details-section">
                                                <Row className="mt-3">

                                                    {(isRotationsupervisor || isEducationalSupervisor) &&
                                                        <Col md="6" lg="4">
                                                            <FormGroup>
                                                                <Label>{t('UsersManagement.dept')}</Label>
                                                                <MySelect
                                                                    name="departmentIds"
                                                                    allOption={{
                                                                        departmentName: "Select All Departments",
                                                                        departmentId: 0
                                                                    }}
                                                                    isMulti={true}
                                                                    placeholder={t('UsersManagement.dept')}
                                                                    options={departmentOptions ? departmentOptions : []}
                                                                    value={values.departmentIds ? values.departmentIds : []}
                                                                    onChange={(e) => setFieldValue('departmentIds', e ? e : '')}
                                                                    getOptionLabel={option => option.departmentName}
                                                                    getOptionValue={option => option.departmentId}
                                                                    valueKey="departmentId"
                                                                    components={{ Option, ValueContainer }}
                                                                    hideSelectedOptions={false}
                                                                    removeSelected={false}
                                                                    closeMenuOnSelect={false}
                                                                    backspaceRemovesValue={false}
                                                                    isSearchable={true}
                                                                    allowSelectAll={false}
                                                                    onBlur={() => setFieldTouched('levels', true)}
                                                                    noOptionsMessage={() => t('UsersManagement.noDeptsFound')}
                                                                />
                                                                {errors.departmentIds && touched.departmentIds && (
                                                                    <div className="text-danger">{errors.departmentIds}</div>
                                                                )}
                                                            </FormGroup>
                                                        </Col>
                                                    }

                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>
                                                                {t('UsersManagement.mmcNumber')}

                                                            </Label>
                                                            <Field disabled={isTraineeUser && isEditActionType} placeholder={t('UsersManagement.mmcNumber')} name="mmcno" className={'form-control ' + (errors.mmcno && touched.mmcno ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="mmcno" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>

                                                    {(isProgramCoordinator || isTraineeUser) && <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.selectProgrameeCode')}</Label>
                                                            <MySelect
                                                                name="programId"
                                                                placeholder={t('UsersManagement.selectProgrameeCode')}
                                                                value={values.programId}
                                                                onChange={(e) => setFieldValue('programId', e ? e : '')}
                                                                options={programsOptions}
                                                                getOptionLabel={option => option.programName}
                                                                getOptionValue={option => option.programId}
                                                                onBlur={() => setFieldTouched('programId', true)}
                                                                noOptionsMessage={() => 'NoDataFound'}
                                                                isDisabled={isEditActionType ? isProgramCoordinator ? false : true : false}
                                                            />
                                                            {errors.programId && touched.programId && (
                                                                <div className="text-danger">{errors.programId}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>}
                                                    {isTraineeUser &&
                                                        <>
                                                            <Col md="6" lg="4">
                                                                <FormGroup>
                                                                    <Label>{t('UsersManagement.trLegacyCode')}</Label>
                                                                    <Field placeholder={t('UsersManagement.trLegacyCode')} name="trLegacyCode" className={'form-control ' + (errors.trLegacyCode && touched.trLegacyCode ? 'is-invalid' : '')} />
                                                                    <ErrorMessage name="trLegacyCode" component="div" className="invalid-feedback" />
                                                                </FormGroup>
                                                            </Col>

                                                            <Col md="6" lg="4">
                                                                <FormGroup>
                                                                    <Label>{t('UsersManagement.icNumber')}</Label>
                                                                    <Field placeholder={t('UsersManagement.icNumber')} name="trIcNo" className={'form-control ' + (errors.trIcNo && touched.trIcNo ? 'is-invalid' : '')} />
                                                                    <ErrorMessage name="trIcNo" component="div" className="invalid-feedback" />
                                                                </FormGroup>
                                                            </Col>
                                                            <Col md="6" lg="4">
                                                                <FormGroup>
                                                                    <Label>{t('UsersManagement.ammNumber')}</Label>
                                                                    <Field placeholder={t('UsersManagement.ammNumber')} name="anmno" className={'form-control ' + (errors.anmno && touched.anmno ? 'is-invalid' : '')} />
                                                                    <ErrorMessage name="anmno" component="div" className="invalid-feedback" />
                                                                </FormGroup>
                                                            </Col>

                                                            <Col md="6" lg="4">
                                                                <FormGroup>
                                                                    <Label>{t('UsersManagement.nsrNumber')}</Label>
                                                                    <Field placeholder={t('UsersManagement.nsrNumber')} name="nsrno" className={'form-control ' + (errors.nsrno && touched.nsrno ? 'is-invalid' : '')} />
                                                                    <ErrorMessage name="nsrno" component="div" className="invalid-feedback" />
                                                                </FormGroup>
                                                            </Col>
                                                        </>}
                                                </Row>
                                            </div>
                                        </div>
                                        <hr />
                                    </>}

                                    <div className="top-section">
                                        {isRoleSelected && <h2><div>{t('UsersManagement.userLoginDetails')}</div></h2>}
                                        <div className="details-section">
                                            {isRoleSelected && <Row className="mt-3">
                                                <Col md="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t(('UsersManagement.eportfolioEmailId'))}</Label>
                                                        <InputGroup>
                                                            <Field placeholder={t(('UsersManagement.eportfolioEmailId'))} name="eportfolioEmailId" onBlur={() => handleEportfolioEmail(setFieldTouched)} className={'form-control ' + (errors.eportfolioEmailId && touched.eportfolioEmailId ? 'is-invalid' : '')} />

                                                            <ErrorMessage name="eportfolioEmailId" component="div" className="invalid-feedback" />
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>

                                                <Col md="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t('UsersManagement.userName')}</Label>
                                                        <Field disabled={isEditActionType} placeholder={t('UsersManagement.userName')} name="userName" className={'form-control ' + (errors.userName && touched.userName ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="userName" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>}

                                            {isTraineeUser &&
                                                <Row className="mt-3">
                                                    <>
                                                        <Col md="6" lg="4">
                                                            <FormGroup>
                                                                <Label>{t('UsersManagement.activeFromDate')}</Label>
                                                                <DatePicker placeholderText={t('UsersManagement.activeFromDate')} className="w100 datepickerIcon form-control" name="trActiveFrom"
                                                                    popperPlacement="top"
                                                                    popperModifiers={{
                                                                        flip: {
                                                                            behavior: ["top"]
                                                                        },
                                                                        preventOverflow: {
                                                                            enabled: false
                                                                        }
                                                                    }}
                                                                    autoComplete="off"
                                                                    selected={values.trActiveFrom}
                                                                    onChange={(e) => handletraineeActiveFromDate(e, setFieldValue)}
                                                                    dateFormat={'dd-MM-yyyy'}
                                                                    minDate={new Date(currentDateAndTime?.date)}
                                                                    maxDate={values.trActiveTo}
                                                                    onBlur={() => setFieldTouched('trActiveFrom', true)}
                                                                    showMonthDropdown
                                                                    showYearDropdown
                                                                    dropdownMode="select"
                                                                />
                                                                {errors.trActiveFrom && touched.trActiveFrom && (
                                                                    <div className="text-danger">{errors.trActiveFrom}</div>
                                                                )}
                                                            </FormGroup>
                                                        </Col>

                                                        <Col md="6" lg="4">
                                                            <FormGroup>
                                                                <Label>{t('UsersManagement.activeToDate')} </Label>
                                                                <DatePicker
                                                                    placeholderText={t('UsersManagement.activeToDate')}
                                                                    className="w100 datepickerIcon form-control"
                                                                    name="trActiveTo"
                                                                    popperPlacement="top"
                                                                    autoComplete="off"
                                                                    popperModifiers={{
                                                                        flip: {
                                                                            behavior: ["top"]
                                                                        },
                                                                        preventOverflow: {
                                                                            enabled: false
                                                                        }
                                                                    }}
                                                                    selected={values.trActiveTo}
                                                                    onChange={(e) => handletraineeActiveToDate(e, setFieldValue)}
                                                                    dateFormat={'dd-MM-yyyy'}
                                                                    minDate={values.trActiveFrom}
                                                                    onBlur={() => setFieldTouched('trActiveTo', true)}
                                                                    showMonthDropdown
                                                                    showYearDropdown
                                                                    dropdownMode="select"
                                                                />
                                                                {errors.trActiveTo && (
                                                                    <div className="text-danger">{errors.trActiveTo}</div>
                                                                )}
                                                            </FormGroup>
                                                        </Col>
                                                    </>
                                                </Row>
                                            }
                                            {isTraineeUser &&
                                                <Row className="mt-3">
                                                    <Col md="6" lg="4">
                                                        <FormGroup>
                                                            <Label>{t('UsersManagement.remarks')}</Label>
                                                            <Field placeholder={t('UsersManagement.remarks')} name="remark" className={'form-control ' + (errors.remark && touched.remark ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="remark" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            }
                                            <div className="sub-form-footer mt-3">
                                                <button className="cancel-button" onClick={cancelUserCreationAction}>{t('ActionNames.cancel')}</button>&nbsp;
                                                <button className="btn blue-button" disabled={isEditActionType && !(dirty)} >{actionType === EOprationalActions.ADD ? t('ActionNames.create') : t('ActionNames.update')}</button>
                                            </div>
                                        </div>
                                    </div>
                                </Form>
                            )
                        }}
                    </Formik>
                </div>
            </div>
        </div >
    )
}
export default React.memo(SingleUserCreationOrEdit);