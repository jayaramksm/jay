import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { IUserManagementModel } from '../../../../models/userManagementModel';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { SuperParentContext } from '../Container/usermanagementcontext';
import '../Container/usermanagement.css';

const UserManagementParentManager: React.FC = () => {
    const context = useContext(SuperParentContext);
    const isUsersListActionType = useSelector((state: any) => {
        if (state?.userManagementReducer?.actionType)
            return (state.userManagementReducer as IUserManagementModel).actionType === EOprationalActions.UNSELECT;
        else return true;
    });

    return (
        <>
            {isUsersListActionType && <context.filterComponent />}

            <div className="flexLayout">
                {isUsersListActionType ? <context.managerComponent /> : <context.actionComponent />}
            </div>

        </>
    )
}
export default React.memo(UserManagementParentManager);