import React, { useContext } from 'react'
import { ParentContext } from '../Container/usermanagementcontext'

const  BulkUploadManager: React.FC = () => {
    const context = useContext(ParentContext)
    return (
        <div className="flexLayout">
            <context.bulkUploadComponent />
        </div>
    )
}

export default React.memo(BulkUploadManager)