import React from 'react';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { EOprationalActions, ERoleDesc } from '../../../../models/utilitiesModel';
import { setSearchUsersData, setUsersActionTypeData } from '../../../../store/actions';
import UploadFile from '../../../../images/upload-file.svg';
import { useTranslation } from 'react-i18next';
// import filter from '../../../../images/filter.svg';

const UserManagementFilter: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const showFilter: boolean = useSelector((state: any) => !!(state?.userManagementReducer?.usersData?.length > 2));
    const loggedInRoleCode = useSelector((state: any) => state?.SessionState?.userDto?.roles?.roleCode || '');

    const singleUserCreate = () => dispatch(setUsersActionTypeData(EOprationalActions.ADD, null));
    const bulkuploadusers = () => dispatch(setUsersActionTypeData(EOprationalActions.BULKUPLOAD, null));
    const onSearchChange = e => dispatch(setSearchUsersData(e?.target?.value));

    return (
        <>
            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title">{t('UsersManagement.existingUsers')}</h3>
                </Col>
                <div className="rgtFilter">
                    {showFilter && <div className="search-box filtericon">
                        {/* <UncontrolledDropdown>
                        <DropdownToggle id="Filter">
                            <img src={filter} alt="" />

                        </DropdownToggle>
                        <DropdownMenu>
                            <DropdownItem>All</DropdownItem>
                            <DropdownItem>Pending</DropdownItem>
                            <DropdownItem>Approved</DropdownItem>
                            <DropdownItem>Rejected</DropdownItem>
                        </DropdownMenu>
                    </UncontrolledDropdown> */}
                        <div className="search-text">
                            <input type="text" placeholder="Search" onChange={onSearchChange} /><i className="ti-search icon"></i></div>
                    </div>}

                    <button className="addnewButn" onClick={singleUserCreate}><i className="ti-plus" ></i> {t('ActionNames.create')}</button>
                    {loggedInRoleCode !== ERoleDesc.PLATFORMADMIN && <button className="iconBtn" onClick={bulkuploadusers}><img src={UploadFile} alt="upload-icon" style={{ width: "18px" }} ></img></button>}
                </div>
            </Row>
        </>
    )
}
export default React.memo(UserManagementFilter);