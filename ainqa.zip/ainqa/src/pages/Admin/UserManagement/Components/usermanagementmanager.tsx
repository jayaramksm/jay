import React, { useContext, useMemo } from 'react';
import { ChildContext, SuperParentContext } from '../Container/usermanagementcontext';
import { useSelector, useDispatch } from 'react-redux';
import { IRoles, IUser } from '../../../../models/userManagementModel';
import { EUserManagementFilterKeys } from '../../../../models/utilitiesModel';
import { setPaginationCurrentPageValue } from '../../../../store/actions';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { useTranslation } from 'react-i18next';
import { getFilteredDataAfterSearch, getEnvironment } from '../../../../helpers/helpersIndex';
import '../Container/usermanagement.css';

// const filterKeys = [EUserManagementFilterKeys.USER_ID, EUserManagementFilterKeys.USERNAME, EUserManagementFilterKeys.RESOURCE_CODE, EUserManagementFilterKeys.USER_TYPE];
const UserManagementManager: React.FC = () => {
    const context = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const pageSize = getEnvironment.pageSize;

    const usersData: IUser[] = useSelector((state: any) => state?.userManagementReducer?.usersData);
    const searchKey: string = useSelector((state: any) => state?.userManagementReducer?.searchKey || '');
    const rolesData: IRoles[] = useSelector((state: any) => state?.userManagementReducer?.rolesData || []);
    const currentPage: number = useSelector((state: any) => state?.userManagementReducer?.paginationCurrentPage || 0);

    const userRolesObj = useMemo(() => {
        const roles = {};
        if (rolesData.length) {
            rolesData.forEach(role => {
                if (!roles[role.roleCode])
                    roles[role.roleCode] = role.roleName;
            });
        }
        return roles;
    }, [rolesData.length]);

    const usersFilterData: IUser[] = (usersData?.length && searchKey !== '') ? usersData?.filter((x: IUser) => (
        searchKey !== '' ? x.userFullName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : usersData;

    // const usersFilterData = useMemo(() => {
    //     if (usersData.length && searchKey)
    //         return getFilteredDataAfterSearch(usersData, filterKeys, searchKey, userRolesObj);
    //     return usersData;
    // }, [searchKey, usersData.length]);

    let pagesCount: number = Math.ceil((usersFilterData ? usersFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setPaginationCurrentPageValue(index));
    };
    console.log("_UserManagementManager_=>", { usersData, usersFilterData, rolesData, userRolesObj });

    return (
        <>
            <div className="flexScroll">
                {(usersData && usersData.length > 0) &&
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable usersTable table">
                                <thead>
                                    <tr>
                                        <th>{t('UsersManagement.userId')}</th>
                                        {/* <th>{t('UsersManagement.userCode')}</th> */}
                                        <th>{t('UsersManagement.userFullName')}</th>
                                        <th>{t('UsersManagement.userType')}</th>
                                        <th className="column-center">{t('UsersManagement.status')}</th>
                                        <th>{t('UsersManagement.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {usersFilterData && usersFilterData.length > 0 &&
                                        usersFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                            .map(user => {
                                                return (
                                                    <ChildContext.Provider key={user.userId} value={{ userId: user.userId, userType: userRolesObj[user.userType] }}>
                                                        <context.viewComponent />
                                                    </ChildContext.Provider>
                                                )
                                            })
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                }
                {(usersFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('UsersManagement.noUserFound')}</h6></div>}
            </div>
            {usersFilterData && usersFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}
export default React.memo(UserManagementManager);