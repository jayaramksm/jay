import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { ChildContext } from '../Container/usermanagementcontext';
import Approved from '../../../../images/Approved.svg';
import EditIcon from '../../../../images/Edit.svg';
import Delete from '../../../../images/Delete.svg';
// import Inactive from '../../../../images/Inactive.svg';
// import inactiveIcon from '../../../../images/Deactive.svg';
import { deleteUserDataRequest, setUsersActionTypeData } from '../../../../store/actions';
import { EOprationalActions, ERoleDesc, ERoleNames } from '../../../../models/utilitiesModel';
import { IUser } from '../../../../models/userManagementModel';
import { useTranslation } from 'react-i18next';

const UserManagementView: React.FC = () => {
    const { t } = useTranslation('translations');
    const { userId, userType } = useContext(ChildContext);
    const dispatch = useDispatch();

    let userItemData: IUser | any = useSelector((state: any) => {
        if (state?.userManagementReducer?.usersData?.length)
            return (state.userManagementReducer.usersData as IUser[]).find(x => x.userId === userId);
        else return undefined;
    });

    const isPlatformAdminRole = useSelector((state: any) => state?.SessionState?.userDto?.roles?.roleCode === ERoleDesc.PLATFORMADMIN);
    const editAction = () => dispatch(setUsersActionTypeData(EOprationalActions.EDIT, userItemData));

    const deleteAction = () => {
        const confirmMessage = t('UsersManagement.confirmMessages.EUM1').replace('{name}', userItemData?.userName);
        dispatch(deleteUserDataRequest(userItemData?.userId, false, confirmMessage, userItemData?.trainee?.trId));
    };

    // const isUserActive = userItemData?.isActive === EStatusEnum.NACTIVE;

    return (
        <>
            <tr>
                <td>{userItemData?.userId}</td>
                {/* <td>{userItemData?.resourceCode || 'N/A'}</td> */}
                <td>{userItemData?.userFullName}</td>
                <td>{isPlatformAdminRole ? `${ERoleNames.UNIVERSITYADMIN}` : userType}</td>
                <td className="column-center">
                    <img src={Approved} className="icon" alt="user-status" />
                    {/* <img src={isUserActive ? Approved : Inactive} className="icon" alt="user-status" /> */}
                </td>
                <td>
                    {/* <span><img src={inactiveIcon} className="actionicon pointer" alt="status-btn"></img></span> */}
                    <span><img src={EditIcon} onClick={editAction} className="actionicon pointer" alt="edit-btn"></img></span>
                    <span><img src={Delete} onClick={deleteAction} alt="delete-btn" className="actionicon pointer"></img></span>
                </td>
            </tr>
        </>
    )
}
export default React.memo(UserManagementView);