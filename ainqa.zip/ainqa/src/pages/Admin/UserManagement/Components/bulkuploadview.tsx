import React from 'react'

const BulkUploadView: React.FC = () => {
    return (
        <div>
            <div>BulkuploadpageView</div>
        </div>
    )
}

export default React.memo(BulkUploadView)