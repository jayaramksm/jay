import React from 'react';
import { useDispatch } from 'react-redux';
import * as Yup from 'yup';
import { EBulkUploadComponentNames, EBulkUploadUsers, EOprationalActions } from '../../../../../models/utilitiesModel';
import { setActionTypeInDepartments, getFileUploadsHistoryInDepartmentsRequest, createBulkUploadDepartmentsDataRequest } from '../../../../../store/actions';
import { useTranslation } from 'react-i18next';
import BulkUpload from '../../../../utilities/bulkupload';
import { getBulkUploadCsvHeaders, customContentValidation, defultContentValidate } from '../../../../../helpers/helpersIndex';

const DepartmentsBulkUpload: React.FC = () => {
    const headers: any = getBulkUploadCsvHeaders(EBulkUploadUsers.DEPARTMENTS);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const goBackToList = () => dispatch(setActionTypeInDepartments(EOprationalActions.UNSELECT));

    const viewBulkUploadHistory = () => {
        // set actionType to file_history in the request action itself, instead of dispatching multiple actions
        dispatch(setActionTypeInDepartments(EOprationalActions.BULK_UPLOAD_FILE_HISTORY));
        dispatch(getFileUploadsHistoryInDepartmentsRequest());
    }

    const bulkuploadOnSumbit = (validData, invalidData) => {
        dispatch(createBulkUploadDepartmentsDataRequest(validData, invalidData, headers));
    }

    const sampleData = {
        [headers.departmentName]: '',
        [headers.departmentCode]: '',
        [headers.location]: ''
    }
    const validationSchema = Yup.object().shape({
        [headers.departmentName]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 50, 4),
        [headers.departmentCode]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 50, 2),
        [headers.location]: Yup.lazy((value) => {
            if (value)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 50, 4)
            else return defultContentValidate('')
        })
    });

    return (
        <div className="flexLayout">
            <div className="maincontent paglayout flexScroll">
                <BulkUpload
                    name={EBulkUploadComponentNames.DEPARTMENTS}
                    headers={headers}
                    sampleData={sampleData}
                    validationSchema={validationSchema}
                    viewBulkUploadHistory={viewBulkUploadHistory}
                    goBackToList={goBackToList}
                    bulkuploadOnSumbit={bulkuploadOnSumbit}
                />
            </div>
        </div>
    )
}
export default React.memo(DepartmentsBulkUpload);