import React, { useContext } from 'react';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/departmentscontext'

const DepartmentsManagerParent: React.FC = () => {

    const context = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.departmentsReducer?.actionType)
            return state.departmentsReducer.actionType
        else return EOprationalActions.UNSELECT
    });


    return (
        <>
            {actionType === EOprationalActions.UNSELECT && <context.departmentsFilter />}

            <div className="flexLayout maincontent">
                {actionType === EOprationalActions.UNSELECT && <context.departmentsViewParent />}
                {(actionType === EOprationalActions.EDIT || (actionType === EOprationalActions.ADD || actionType === EOprationalActions.BULKUPLOAD)) && <context.departmentsAction />}
                {actionType === EOprationalActions.BULK_UPLOAD_FILE_HISTORY && <context.bulkUploadFileHistory />}
            </div>
        </>
    )
}

export default React.memo(DepartmentsManagerParent);