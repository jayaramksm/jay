import React, { useContext } from 'react';
import EditIcon from '../../../../../images/Edit.svg';
import Delete from '../../../../../images/Delete.svg';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext } from '../Container/departmentscontext';
import { getDeleteDepartmentFromDepartmentsDetailsRequest, setActionTypeInDepartments } from '../../../../../store/actions';
import { useTranslation } from 'react-i18next';
import { EOprationalActions } from '../../../../../models/utilitiesModel';

const DepartmentView: React.FC = () => {
    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const departmentDetails = useSelector((state: any) => {
        if (state?.departmentsReducer?.departmentsDetails?.length > 0)
            return state.departmentsReducer.departmentsDetails.find(x => x.departmentId === context);
        else return undefined;
    });

    const university: any = useSelector((state: any) => state?.SessionState?.userDto?.university);

    const handleDepartmentDelete = () => {
        let confirmMessage = t('Departments.confirmMessages.DM1').replace('{name}', departmentDetails?.departmentName)
        dispatch(getDeleteDepartmentFromDepartmentsDetailsRequest(departmentDetails.departmentId, false, confirmMessage))
    }
    const hadleDepartmentEdit = () => dispatch(setActionTypeInDepartments(EOprationalActions.EDIT, departmentDetails))


    return (
        <>
            {departmentDetails && <tr>
                <td>{departmentDetails.departmentName}</td>
                <td>{departmentDetails.departmentCode}</td>
                <td>{university?.universityName || ''}</td>
                <td>{university?.universityCode || ''}</td>
                <td>{departmentDetails.location}</td>
                <td className="ActionStatus column-center">
                    <span onClick={hadleDepartmentEdit}><img src={EditIcon} className="actionicon pointer" alt="edit-btn"></img></span>
                    <span onClick={handleDepartmentDelete}><img src={Delete} alt="delete-btn" className="actionicon pointer"></img></span>
                </td>
            </tr>}

        </>
    )
}

export default React.memo(DepartmentView);
