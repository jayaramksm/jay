import React, { useContext } from 'react';
import { Breadcrumb, BreadcrumbItem, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { setActionTypeInDepartments } from '../../../../../store/actions';
import { SuperParentContext } from '../Container/departmentscontext';
import { useTranslation } from 'react-i18next';


const DepartmentsAction: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');

    const actionType = useSelector((state: any) => {
        if (state?.departmentsReducer?.actionType)
            return state.departmentsReducer.actionType
        else return EOprationalActions.UNSELECT
    });

    const goBackToList = () => dispatch(setActionTypeInDepartments(EOprationalActions.UNSELECT));

    const singleCreation = () => {
        if (actionType === EOprationalActions.EDIT) return
        dispatch(setActionTypeInDepartments(EOprationalActions.ADD));
    }

    const bulkUpload = () => dispatch(setActionTypeInDepartments(EOprationalActions.BULKUPLOAD));

    return (
        <>
            <div className="breadcrumbs">
                <span className="pointer" onClick={goBackToList}>{t("Departments.listOfDepartments")}</span>
                <span><i className="ti-angle-right"></i></span>
                <span className="active">
                    {actionType === EOprationalActions.EDIT ? t('Departments.updateDepartmentDetails') : actionType === EOprationalActions.BULKUPLOAD ? t("Departments.bulkUpload") : t("Departments.createDepartment")}
                </span>
            </div>

            <div className="uploadTabs flexLayout pr-0">
                <Nav tabs>
                    <NavItem>
                        <NavLink className={(actionType === EOprationalActions.ADD || actionType === EOprationalActions.EDIT) ? "active" : ''}>
                            <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                            <span className="d-none d-sm-block" onClick={singleCreation}>
                                {actionType === EOprationalActions.EDIT ? t('Departments.updateDepartmentDetails') : t("Departments.createDepartment")}
                            </span>
                        </NavLink>
                    </NavItem>

                    {actionType !== EOprationalActions.EDIT && <NavItem>
                        <NavLink className={actionType === EOprationalActions.BULKUPLOAD ? "active" : ''}>
                            <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                            <span className="d-none d-sm-block" onClick={bulkUpload}>{t("Departments.bulkUpload")}</span>
                        </NavLink>
                    </NavItem>}
                </Nav>
                <TabContent className="flexLayout pr-0" activeTab={actionType}>
                    {((actionType === EOprationalActions.ADD) || (actionType === EOprationalActions.EDIT)) &&
                        <TabPane tabId={actionType === EOprationalActions.ADD ? EOprationalActions.ADD : EOprationalActions.EDIT} className="flexLayout pr-0">
                            <context.singleDepartmentCreationOrEdit />
                        </TabPane>
                    }
                    {(actionType === EOprationalActions.BULKUPLOAD) &&
                        <TabPane tabId={EOprationalActions.BULKUPLOAD} className="flexLayout pr-0">
                            <context.departmentsBulkUpload />
                        </TabPane>
                    }
                </TabContent>
            </div>
        </>
    )
}

export default React.memo(DepartmentsAction);
