import React from 'react';
import { Row, Col, Input, FormGroup, Label } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { setActionTypeInDepartments, getAddOrEditDepartmentRquest } from '../../../../../store/actions';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { customContentValidation, defultContentValidate } from '../../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';

const SingleDepartmentCreationOrEdit: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const actionType = useSelector((state: any) => {
        if (state?.departmentsReducer?.actionType)
            return state.departmentsReducer.actionType;
        else return EOprationalActions.UNSELECT
    });

    const actionData = useSelector((state: any) => {
        if (state?.departmentsReducer?.actionData)
            return state.departmentsReducer.actionData;
        else return undefined;
    })

    const university: any = useSelector((state: any) => state?.SessionState?.userDto?.university);


    const goBackToList = () => dispatch(setActionTypeInDepartments(EOprationalActions.UNSELECT))

    const initialValues = () => ({
        id: actionData?.departmentId || 0,
        deptName: actionData?.departmentName || '',
        deptCode: actionData?.departmentCode || '',
        location: actionData?.location || '',
        universityName: university?.universityName || '',
        universityCode: university?.universityCode || ''
    })

    const validationSchema = Yup.object().shape({
        deptName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 50, 4),
        deptCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 50, 2),
        location: Yup.lazy((value) => {
            if (value !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 50, 4)
            else return defultContentValidate('')
        })
    })
    return (
        <>
            <div className="flexScroll mydocuments">
                <div className="maincontent paglayout">
                    <div className="top-section">
                        <div className="details-section mt-3">
                            <h2>{t("Departments.departmentDetails")}</h2>
                            <Formik
                                initialValues={initialValues()}
                                validationSchema={validationSchema}
                                onSubmit={values => {
                                    dispatch(getAddOrEditDepartmentRquest(values, actionType))
                                    console.log('onSubmit===>', values)
                                }}
                            >
                                {
                                    ({ dirty }) => (
                                        <Form>
                                            <Row className="mt-3">
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Departments.departmentName")}</Label>
                                                        <Field type="text" placeholder={t("Departments.departmentName")} name="deptName" className='form-control' />
                                                        <ErrorMessage name='deptName' component='div' className='text-danger' />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Departments.departmentCode")}</Label>
                                                        <Field type="text" placeholder={t("Departments.departmentCode")} name="deptCode" className='form-control' />
                                                        <ErrorMessage name='deptCode' component='div' className='text-danger' />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Departments.universityName")}</Label>
                                                        <Field type="text" name='universityName' disabled className='form-control' />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Departments.universityCode")}</Label>
                                                        <Field type="text" name='universityCode' disabled className='form-control' />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Departments.locationOrCenter")}</Label>
                                                        <Field type="text" placeholder={t("Departments.locationOrCenter")} name="location" className='form-control' />
                                                        <ErrorMessage name='location' component='div' className='text-danger' />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <div className="sub-form-footer mt-3">
                                                <button className="cancel-button" onClick={goBackToList}>{t("ActionNames.cancel")}</button>
                                                <button type='submit' className="btn blue-button" disabled={actionType === EOprationalActions.EDIT ? !dirty : false}>
                                                    {actionType === EOprationalActions.EDIT ? t('ActionNames.update') : t('ActionNames.create')}
                                                </button>
                                            </div>
                                        </Form>
                                    )
                                }

                            </Formik>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(SingleDepartmentCreationOrEdit);
