import React from 'react';
import { Row, Col, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { setActionTypeInDepartments } from '../../../../../store/actions';
import { useTranslation } from 'react-i18next';


const BulkUploadFileHistory: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const fileUploadsHistory: any = useSelector((state: any) => {
        if (state?.departmentsReducer?.fileUploadHistory)
            return state.departmentsReducer.fileUploadHistory;
        else return [];
    });

    const goBackToListOrBulkUpload = (type) => dispatch(setActionTypeInDepartments(type === EOprationalActions.UNSELECT ? EOprationalActions.UNSELECT : EOprationalActions.BULKUPLOAD))

    return (
        <>
            <Breadcrumb>
                <BreadcrumbItem><span onClick={() => goBackToListOrBulkUpload(EOprationalActions.UNSELECT)}>{t("Departments.listOfDepartments")}</span></BreadcrumbItem>
                <BreadcrumbItem><span onClick={() => goBackToListOrBulkUpload(EOprationalActions.BULKUPLOAD)} >{t("Departments.bulkUpload")}</span></BreadcrumbItem>
                <BreadcrumbItem className="subMenu-Active">{t("Departments.fileUploadsHistory")}</BreadcrumbItem>
            </Breadcrumb>

            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title">{t("Departments.fileUploadsHistory")}</h3>
                </Col>
                <div className="rgtFilter">
                    <button className="addnewButn" onClick={() => goBackToListOrBulkUpload(EOprationalActions.BULKUPLOAD)}>{t("Departments.uploadNewFile")}</button>
                </div>
            </Row>

            <div className="historyTable">
                <table className="myTable table">
                    <thead>
                        <tr>
                            <th>{t("Departments.uploadedFile")}</th>
                            <th>{t("Departments.sheetCount")}</th>
                            <th>{t("Departments.dateAndTime")}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {fileUploadsHistory?.length > 0 && fileUploadsHistory.map(x => (
                            <tr key={x.id}>
                                <td className="fileName">{x.uploadedFileName}</td>
                                <td>{x.sheetCount}</td>
                                <td>{x.dateAndTime}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {fileUploadsHistory?.length == 0 && <div className='norecordsfound'><h6>{t('Departments.noDataFound')}</h6></div>}
            </div>


        </>
    )
}

export default React.memo(BulkUploadFileHistory);
