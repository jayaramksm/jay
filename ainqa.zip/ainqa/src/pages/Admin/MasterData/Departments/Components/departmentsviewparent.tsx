import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/departmentscontext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { getEnvironment } from '../../../../../helpers/helpersIndex';
import { setPaginationCurrentPageValueInDepartments } from '../../../../../store/actions';
import { PaginationComponent } from '../../../../utilities/PaginationComponent';
import { IDepartments } from '../../../../../models/departmentsModel';



const DepartmentsViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const departmentsDetails: IDepartments[] = useSelector((state: any) => state?.departmentsReducer?.departmentsDetails);

    const departmentsLength: number = useSelector((state: any) => {
        if (state?.departmentsReducer?.departmentsDetails?.length)
            return state.departmentsReducer.departmentsDetails.length;
        else return 0;
    });
    console.log('DepartmentsViewParent=>', departmentsLength);

    const searchKey: string = useSelector((state: any) => {
        if (state?.departmentsReducer?.searchKey)
            return state.departmentsReducer.searchKey;
        else return '';
    });

    const currentPage: number = useSelector((state: any) => {
        if (state?.departmentsReducer?.paginationCurrentPage)
            return state.departmentsReducer.paginationCurrentPage;
        else return 0;
    });

    const departmentsFilterData: any = (departmentsDetails?.length && searchKey !== '') ? departmentsDetails?.filter((x: any) => (
        searchKey !== '' ? x.departmentName.toLowerCase().startsWith(searchKey.toLowerCase()) ? true :
            x.departmentCode.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : departmentsDetails;

    let pagesCount: number = Math.ceil((departmentsFilterData ? departmentsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setPaginationCurrentPageValueInDepartments(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setPaginationCurrentPageValueInDepartments(index));
    };
    console.log("DepartmentsViewParent", departmentsFilterData);


    return (
        <>
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent table-responsive">
                        <table className="myTable table dept-table">
                            <thead>
                                <tr>
                                    <th>{t("Departments.departmentName")}</th>
                                    <th>{t("Departments.departmentCode")}</th>
                                    <th>{t("Departments.universityName")}</th>
                                    <th>{t("Departments.universityCode")}</th>
                                    <th>{t("Departments.locationOrCenter")}</th>
                                    <th className="column-center">{t("Departments.actions")}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {departmentsFilterData?.length > 0 &&
                                    departmentsFilterData?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                        .map((x) => {
                                            return (
                                                <ParentContext.Provider value={x.departmentId} key={x.departmentId}>
                                                    <context.departmentsView />
                                                </ParentContext.Provider>
                                            )
                                        })
                                }
                            </tbody>
                        </table>
                    </div>
                    {(departmentsFilterData?.length === 0) && searchKey === '' && <div className="norecordsfound"><h6>{t('Departments.noDepartmentsData')}</h6></div>}
                    {(departmentsFilterData?.length === 0) && searchKey !== '' && <div className="norecordsfound"><h6>{t('Departments.noDepartmentsFound')}</h6></div>}
                </div>
            </div>
            {departmentsFilterData?.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}

export default React.memo(DepartmentsViewParent);
