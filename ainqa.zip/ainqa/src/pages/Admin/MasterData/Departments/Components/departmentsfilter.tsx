import React from 'react';
import UploadFile from '../../../../../images/upload-file.svg';
import { Row, Col } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { setActionTypeInDepartments, setSearchKeyInDepartments } from '../../../../../store/actions';
import { useTranslation } from 'react-i18next';

const DepartmentsFilter: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const showDepartmentsSearch: boolean = useSelector((state: any) => !!(state?.departmentsReducer?.departmentsDetails?.length > 2));
    const createDepartment = (createType) => dispatch(setActionTypeInDepartments(createType === EOprationalActions.ADD ? EOprationalActions.ADD : EOprationalActions.BULKUPLOAD));
    const handleOnChange = (e) => dispatch(setSearchKeyInDepartments(e.target.value));

    return (
        <>
            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title">{t("Departments.listofExistingDepartments")}</h3>
                </Col>
                <div className="rgtFilter">
                    {showDepartmentsSearch && <div className="search-box filtericon">
                        <div className="search-text">
                            <input type="text" onChange={handleOnChange} placeholder={t("Departments.search")} /><i className="ti-search icon"></i>
                        </div>
                    </div>
                    }
                    <button className="addnewButn" onClick={() => createDepartment(EOprationalActions.ADD)}><i className="ti-plus"></i> {t("ActionNames.create")}</button>
                    <button className="iconBtn" onClick={() => createDepartment(EOprationalActions.BULKUPLOAD)}><img src={UploadFile} alt="upload-icon" style={{ width: "18px" }} ></img></button>
                </div>
            </Row>
        </>
    )
}

export default React.memo(DepartmentsFilter);
