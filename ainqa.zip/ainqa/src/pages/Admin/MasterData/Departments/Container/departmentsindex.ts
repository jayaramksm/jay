export { default as BulkUploadFileHistory } from '../Components/bulkuploadfilehistory';
export { default as DepartmentsAction } from '../Components/departmentsaction';
export { default as DepartmentsBulkUpload } from '../Components/departmentsbulkupload';
export { default as DepartmentsFilter } from '../Components/departmentsfilter';
export { default as DepartmentsManagerParent } from '../Components/departmentsmanagerparent';
export { default as DepartmentsViewParent } from '../Components/departmentsviewparent';
export { default as DepartmentsView } from '../Components/departmentview';
export { default as SingleDepartmentCreationOrEdit } from '../Components/singledepartmentcreationoredit';