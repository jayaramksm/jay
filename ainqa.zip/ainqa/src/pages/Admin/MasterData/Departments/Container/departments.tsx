import React, { Component } from 'react';
import { activateAuthLayout, setResetMasterDataDepartmentsStateRequest, getAllDepartmentsDetailsRequest, cancelAllPendingDepartmentsRequest } from '../../../../../store/actions';
import { connect } from 'react-redux';
import {
    BulkUploadFileHistory,
    DepartmentsAction,
    DepartmentsBulkUpload,
    DepartmentsFilter,
    DepartmentsManagerParent,
    DepartmentsViewParent,
    DepartmentsView,
    SingleDepartmentCreationOrEdit
} from './departmentsindex';
import { SuperParentContext } from './departmentscontext';

interface IProps {
    activateAuthLayout: any;
    setResetMasterDataDepartmentsStateRequest: any;
    getAllDepartmentsDetailsRequest: any;
    cancelAllPendingDepartmentsRequest: any;
}

export class Departments extends Component<IProps, any> {

    constructor(props) {
        super(props)

        this.state = {
            managerParent: {
                bulkUploadFileHistory: BulkUploadFileHistory,
                departmentsAction: DepartmentsAction,
                departmentsBulkUpload: DepartmentsBulkUpload,
                departmentsFilter: DepartmentsFilter,
                departmentsViewParent: DepartmentsViewParent,
                departmentsView: DepartmentsView,
                singleDepartmentCreationOrEdit: SingleDepartmentCreationOrEdit
            }
        }
    }


    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getAllDepartmentsDetailsRequest(true);
    }

    componentWillUnmount() {
        this.props.setResetMasterDataDepartmentsStateRequest();
        this.props.cancelAllPendingDepartmentsRequest();
    }
    render() {
        return (
            <div className='flexLayout pr-0'>
                <SuperParentContext.Provider value={this.state.managerParent}>
                    <DepartmentsManagerParent />
                </SuperParentContext.Provider>
            </div>
        )
    }
}

export default connect(null, { activateAuthLayout, setResetMasterDataDepartmentsStateRequest, getAllDepartmentsDetailsRequest, cancelAllPendingDepartmentsRequest })(Departments)
