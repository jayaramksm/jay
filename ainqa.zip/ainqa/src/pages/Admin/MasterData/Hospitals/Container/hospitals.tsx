import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, getHospitalsDataRequest, resetAllHospitalsStateRequest, cancelAllPendingHospitalsRequest } from '../../../../../store/actions';
import { SuperParentContext } from './hospitalsContext';
import {
    HospitalsParentManager, HospitalsViewManager, HospitalsView, HospitalsFilter,
    HospitalsBulkuploadFilesHistory, HospitalsBulkupload, HospitalsActionManager, HospitalsCreationOrEditComponent
} from './hospitalsIndex';
interface IProps {
    activateAuthLayout;
    getHospitalsDataRequest;
    resetAllHospitalsStateRequest;
    cancelAllPendingHospitalsRequest;
}
class Hospitals extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            hospitalsViewManager: HospitalsViewManager,
            hospitalsViewComponent: HospitalsView,
            actionManagerComponent: HospitalsActionManager,
            filterComponent: HospitalsFilter,
            bulkUploadComponent: HospitalsBulkupload,
            bulkuploadFilesHistoryComponent: HospitalsBulkuploadFilesHistory,
            hospitalsCreationOrEditComponent: HospitalsCreationOrEditComponent

        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllHospitalsStateRequest();
        this.props.getHospitalsDataRequest();


    }
    componentWillUnmount() {
        this.props.resetAllHospitalsStateRequest();
        this.props.cancelAllPendingHospitalsRequest();

    }
    render() {
        return (
            <div className="flexLayout pr-0">
                <SuperParentContext.Provider value={this.state}>
                    <HospitalsParentManager />
                </SuperParentContext.Provider>
            </div>
        )
    }
}


export default connect(null, { activateAuthLayout, getHospitalsDataRequest, resetAllHospitalsStateRequest, cancelAllPendingHospitalsRequest })(Hospitals);