export { default as HospitalsParentManager } from '../Components/hospitalsParentManager';
export { default as HospitalsViewManager } from '../Components/hospitalsViewManager';
export { default as HospitalsView } from '../Components/hospitalsView';
export { default as HospitalsFilter } from '../Components/hospitalsFilter';
export { default as HospitalsBulkuploadFilesHistory } from '../Components/hospitalsBulkuploadFilesHistory';
export { default as HospitalsBulkupload } from '../Components/hospitalsBulkupload';
export { default as HospitalsActionManager } from '../Components/hospitalsActionManager';
export { default as HospitalsCreationOrEditComponent } from '../Components/hospitalsCreationOrEditComponent';
