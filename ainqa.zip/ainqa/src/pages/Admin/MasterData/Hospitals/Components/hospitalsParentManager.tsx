import { IHospaitalsModel } from 'models/hospaitalsModel';
import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/hospitalsContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';

const HospitalsParentManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const isHospitalsListActionType = useSelector((state: any) => {
        if (state?.hospitalsReducer)
            return (state.hospitalsReducer as IHospaitalsModel)?.actionType === EOprationalActions.UNSELECT;
        else return false;
    });
    return (
        <div className="flexLayout maincontent pr-0">
            {isHospitalsListActionType ?
                <ParentContext.Provider value={{ hospitalsViewComponent: context.hospitalsViewComponent, filterComponent: context.filterComponent }}>
                    <context.hospitalsViewManager />
                </ParentContext.Provider>
                :
                <ParentContext.Provider value={{ bulkuploadFilesHistoryComponent: context.bulkuploadFilesHistoryComponent, hospitalsCreationOrEditComponent: context.hospitalsCreationOrEditComponent, bulkUploadComponent: context.bulkUploadComponent }}>
                    <context.actionManagerComponent />
                </ParentContext.Provider>
            }
        </div>
    )
}
export default React.memo(HospitalsParentManager);