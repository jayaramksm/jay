
import React, { useContext } from 'react'
import { Row, Col, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { setHospitalsActionTypeData } from '../../../../../store/actions';
import { useDispatch, useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { IHospaitalsModel } from '../../../../../models/hospaitalsModel';

const HospitalsBulkuploadFilesHistory: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const fileUploadsHistory = useSelector((state: any) => {
        if (state?.hospitalsReducer?.uploadedFilesInfo) {
            return (state.hospitalsReducer as IHospaitalsModel).uploadedFilesInfo
        } else {
            return undefined
        }
    });

    const uploadFile = () => {
        dispatch(setHospitalsActionTypeData(EOprationalActions.BULKUPLOAD, null));
    };
    const handleChange = () => {
        dispatch(setHospitalsActionTypeData(EOprationalActions.UNSELECT, null))
    };
    return (
        <>

            <Breadcrumb>
                <BreadcrumbItem><span onClick={handleChange}>   {t('Hospitals.listOfHospital')}</span></BreadcrumbItem>
                <BreadcrumbItem><span onClick={uploadFile}>{t('Hospitals.bulkUpload')}</span></BreadcrumbItem>
                <BreadcrumbItem className="subMenu-Active">{t('Hospitals.fileUploadsHistory')}</BreadcrumbItem>
            </Breadcrumb>

            <Row className="compHeading">
                <Col sm="6" xs="12">
                    <h3 className="page-header header-title">{t('Hospitals.fileUploadsHistory')}</h3>
                </Col>
                <Col sm="6" xs="12">
                    <div className="text-right">
                        <button onClick={uploadFile} className="addnewButn">{t('Hospitals.uploadNewFile')}</button>
                    </div>
                </Col>
            </Row>


            <div className="historyTable">
                <table className="myTable table">
                    <thead>
                        <tr>
                            <th>{t('Hospitals.uploadFile')}</th>
                            <th>{t('Hospitals.sheetCount')}</th>
                            <th>{t('Hospitals.dateandTime')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {fileUploadsHistory && fileUploadsHistory.map((x, i) => (
                            <tr>
                                <td className="fileName">{x.fileName}</td>
                                <td>{x.sheetCount}</td>
                                <td>{x.dateandTime}</td>
                            </tr>
                        ))}


                    </tbody>
                </table>
                {(!fileUploadsHistory || fileUploadsHistory?.length === 0) && <div className="norecordsfound"><h6>{t('Hospitals.noHodsFound')}</h6></div>}

            </div>
        </>
    )
}

export default React.memo(HospitalsBulkuploadFilesHistory)