import React, { useContext } from 'react';
import { Row, Col } from 'reactstrap';
import { ParentContext, ChildContext } from '../Container/hospitalsContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setHospitalsPaginationCurrentPageValue } from '../../../../../store/actions';
import { IHospital } from '../../../../../models/hospaitalsModel';
import { getEnvironment } from '../../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../../utilities/PaginationComponent';

const HospitalsViewManager: React.FC = () => {
    const context: any = useContext(ParentContext);
    const pageSize = getEnvironment.pageSize;
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const hospitalsData: IHospital[] = useSelector((state: any) => state?.hospitalsReducer?.HospitalsData);
    const searchKey: string = useSelector((state: any) => state?.hospitalsReducer?.searchKey || '');

    const hospitalssFilterData: IHospital[] = (hospitalsData && searchKey !== '') ? hospitalsData?.filter((x: any) => (
        searchKey !== '' ? x.hospitalName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : hospitalsData;

    const currentPage: number = useSelector((state: any) => state?.hospitalsReducer?.paginationCurrentPage || 0);
    let pagesCount: number = Math.ceil((hospitalssFilterData ? hospitalssFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setHospitalsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setHospitalsPaginationCurrentPageValue(index));
    };
    console.log("Hospitalsmanager==>", { hospitalsData, context, searchKey, hospitalssFilterData });

    return (
        <>
            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title"> {t('Hospitals.listofExistingHospitals')}</h3>
                </Col>
                <context.filterComponent />
            </Row>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="w100 myTable hospitalTable table">
                                <thead>
                                    <tr>
                                        <th> {t('Hospitals.hospitalName')}</th>
                                        <th> {t('Hospitals.hospitalIDorCode')}</th>
                                        <th>{t('Hospitals.hospitalLocation')}</th>
                                        <th>{t('Hospitals.pointofContactName')}</th>
                                        <th>{t('Hospitals.pOCContactNumber')}</th>
                                        <th>{t('Hospitals.pOCEmailAddress')}</th>
                                        <th className="column-center">{t('Hospitals.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {hospitalssFilterData && hospitalssFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                        .map((x, i) => (<ChildContext.Provider value={x.hospitalId} key={x.hospitalId}>
                                            <context.hospitalsViewComponent />
                                        </ChildContext.Provider>
                                        ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    {hospitalssFilterData?.length === 0 && <div className="norecordsfound"><h6>{t('Hospitals.noHsptlsFound')}</h6></div>}
                </div>
                {
                    hospitalssFilterData && hospitalssFilterData.length > pageSize &&
                    <div className="pagination">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                }
            </div>
        </>
    )
}
export default React.memo(HospitalsViewManager);