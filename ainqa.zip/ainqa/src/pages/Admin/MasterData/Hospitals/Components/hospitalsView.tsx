import React, { useContext } from 'react';
import { ChildContext } from '../Container/hospitalsContext';
import EditIcon from '../../../../../images/Edit.svg';
import Delete from '../../../../../images/Delete.svg';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { deleteHospitalDataRequest, setHospitalsActionTypeData } from '../../../../../store/actions';
import { useDispatch, useSelector } from 'react-redux'
import { IHospaitalsModel, IHospital } from '../../../../../models/hospaitalsModel';
import { useTranslation } from 'react-i18next';

const HospitalsView: React.FC = () => {
    const context: any = useContext(ChildContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');


    const hospitalsData: IHospital | any = useSelector((state: any) => {
        if (state?.hospitalsReducer?.HospitalsData) {
            let hospitalsDatas = (state.hospitalsReducer as IHospaitalsModel)?.HospitalsData;
            let index = hospitalsDatas?.findIndex(x => x.hospitalId === context);
            if (index !== -1)
                return (state.hospitalsReducer as IHospaitalsModel).HospitalsData[index];
            else return undefined;
        } else {
            return undefined
        }
    });
    const editHospital = () => {
        dispatch(setHospitalsActionTypeData(EOprationalActions.EDIT, hospitalsData));
    };
    const deleteAction = () => {
        const confirmMessage = t('Hospitals.confirmMessages.HOS1').replace('{name}', hospitalsData?.hospitalName);
        dispatch(deleteHospitalDataRequest(hospitalsData?.hospitalId, false, confirmMessage));
    };
    console.log("HospitalsView", hospitalsData);

    return (
        <tr>
            <td>{hospitalsData?.hospitalName}</td>
            <td>{hospitalsData?.hospitalCode}</td>
            <td>{hospitalsData?.location}</td>
            <td>{hospitalsData?.contactName}</td>
            <td>{hospitalsData?.contactNum}</td>
            <td>{hospitalsData?.emailId}</td>
            <td className="column-center">
                <img onClick={editHospital} src={EditIcon} className="actionicon pointer" alt=""></img>
                <img onClick={deleteAction} src={Delete} alt="" className="actionicon pointer"></img>
            </td>
        </tr>


    )
}
export default React.memo(HospitalsView);