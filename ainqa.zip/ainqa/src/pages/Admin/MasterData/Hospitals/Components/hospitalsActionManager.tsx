import React, { useContext } from 'react'
import { ParentContext } from '../Container/hospitalsContext'
import { Breadcrumb, BreadcrumbItem, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { IHospaitalsModel } from '../../../../../models/hospaitalsModel';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setHospitalsActionTypeData } from '../../../../../store/actions';

const HospitalsActionManager: React.FC = () => {
    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionType = useSelector((state: any) => {
        if (state && state.hospitalsReducer && state.hospitalsReducer.actionType) {
            return (state.hospitalsReducer as IHospaitalsModel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const handleChange = () => {
        dispatch(setHospitalsActionTypeData(EOprationalActions.UNSELECT, null))
    };

    const showBulkUpload = () => {
        dispatch(setHospitalsActionTypeData(EOprationalActions.BULKUPLOAD, null));
    };

    const showCreateHospital = () => {
        if (actionType !== EOprationalActions.EDIT)
            dispatch(setHospitalsActionTypeData(EOprationalActions.ADD, null));
    };

    return (
        <>
            {actionType === EOprationalActions.BULK_UPLOAD_FILE_HISTORY ? <context.bulkuploadFilesHistoryComponent />
                : <>
                    <div className="breadcrumbs">
                        <span className="pointer" onClick={handleChange}>{t('Hospitals.listOfHospital')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{actionType === EOprationalActions.ADD ? t('Hospitals.AddHospital') : actionType === EOprationalActions.EDIT ? t('Hospitals.editHospital') : t('Hospitals.bulkUpload')}</span>
                    </div>

                    <div className="uploadTabs flexLayout pr-0">
                        <Nav tabs>
                            <NavItem>
                                <NavLink onClick={showCreateHospital} className={actionType === EOprationalActions.ADD ? 'active' : ''}>
                                    <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                                    <span className="d-none d-sm-block">{actionType === EOprationalActions.EDIT ? t('Hospitals.editHospital') : t('Hospitals.AddHospital')}</span>
                                </NavLink>
                            </NavItem>

                            {actionType !== EOprationalActions.EDIT && <NavItem>
                                <NavLink onClick={showBulkUpload} className={actionType === EOprationalActions.BULKUPLOAD ? 'active' : ''}>
                                    <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                                    <span className="d-none d-sm-block">{t('Hospitals.bulkUpload')}</span>
                                </NavLink>
                            </NavItem>
                            }
                        </Nav>
                        <TabContent className="flexLayout pr-0">
                            {((actionType === EOprationalActions.ADD) || (actionType === EOprationalActions.EDIT)) && <TabPane className="flexLayout pr-0">
                                <context.hospitalsCreationOrEditComponent />
                            </TabPane>}
                            {actionType === EOprationalActions.BULKUPLOAD && <TabPane className="flexLayout pr-0">
                                <context.bulkUploadComponent />
                            </TabPane>}


                        </TabContent>
                    </div>
                </>}
        </>
    )
}

export default React.memo(HospitalsActionManager)