import React from 'react'
import { Row, Col, FormGroup, Label } from 'reactstrap';
import { createOrEditSingleHospitalsRequest, setHospitalsActionTypeData } from '../../../../../store/actions';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { customContentValidation, emailContentValidate, defultContentValidate } from '../../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { IHospaitalsModel } from '../../../../../models/hospaitalsModel';

const HospitalsCreationOrEditComponent: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const cancelHospitalsrCreationAction = () => {
        dispatch(setHospitalsActionTypeData(EOprationalActions.UNSELECT, null));
    };

    const actionType = useSelector((state: any) => {
        if (state && state.hospitalsReducer && state.hospitalsReducer.actionType) {
            return (state.hospitalsReducer as IHospaitalsModel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });
    const actionData = useSelector((state: any) => {
        if (state?.hospitalsReducer?.actionData) {
            return (state.hospitalsReducer as IHospaitalsModel).actionData
        } else {
            return undefined
        }
    });
    const handleEmail = (values, setFieldValue, setFieldTouched) => {
        setFieldTouched('email', true);
    };


    const initialValues = () => ({
        hospName: actionData ? actionData.hospitalName : "",
        hospCode: actionData ? actionData.hospitalCode : "",
        location: actionData?.location || "",
        contactNumber: actionData ? actionData.contactNum : "",
        contactName: actionData ? actionData.contactName : "",
        email: actionData ? actionData?.emailId : "",
        id: actionData ? actionData?.hospitalId : 0
    });
    const validationSchema = Yup.object().shape({
        hospName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 4),
        hospCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 20, 2),

        location: Yup.lazy((val) => {
            if (val)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'arabicnumaricspecial', spacialChar: '' }, 250, 4);
            else return defultContentValidate('');
        }),

        contactNumber: Yup.lazy((val) => {
            if (val)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 10, 10);
            else return defultContentValidate('');
        }),

        contactName: Yup.lazy((val) => {
            if (val)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 50, 4);

            else return defultContentValidate('');
        }),

        email: Yup.lazy((val) => {
            if (val)
                return emailContentValidate(t('controleErrors.required'), { value: 5, message: t('controleErrors.min').replace('{min}', '5') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid'));
            else return defultContentValidate('')
        })
    });
    console.log("HospitalsCreationOrEditComponent==>", actionData);

    return (
        <div className="flexLayout">
            <div className="flexScroll mydocuments">
                <div className="maincontent paglayout">
                    <div className="top-section">
                        <h2>{t('Hospitals.hospitalDetails')} </h2>
                        <div className="details-section">
                            <Formik
                                initialValues={initialValues()}
                                validationSchema={validationSchema}
                                onSubmit={(values) => {
                                    dispatch(createOrEditSingleHospitalsRequest(values, actionType));
                                    console.log("SubmitedValues==>", values);
                                }}>
                                {({ errors, setFieldValue, dirty, setFieldTouched, values, touched, resetForm, isValid }) => (
                                    <Form>
                                        <Row className="mt-3">
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('Hospitals.hospitalName')}</Label>
                                                    <Field placeholder={t('Hospitals.hospitalName')} name="hospName" className={'form-control ' + (errors.hospName && touched.hospName ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="hospName" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hospitals.hospitalIDorCode')}</Label>
                                                    <Field placeholder={t('Hospitals.hospitalIDorCode')} name="hospCode" className={'form-control ' + (errors.hospCode && touched.hospCode ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="hospCode" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hospitals.hospitalLocation')} </Label>
                                                    <Field placeholder={t('Hospitals.hospitalLocation')} name="location" className={'form-control ' + (errors.location && touched.location ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="location" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hospitals.pointofContactName')} </Label>
                                                    <Field placeholder={t('Hospitals.pointofContactName')} name="contactName" className={'form-control ' + (errors.contactName && touched.contactName ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="contactName" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('Hospitals.pOCContactNumber')} </Label>
                                                    <Field placeholder={t('Hospitals.pOCContactNumber')} name="contactNumber" className={'form-control ' + (errors.contactNumber && touched.contactNumber ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="contactNumber" component="div" className="invalid-feedback" />                                        </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('Hospitals.pOCEmailAddress')} </Label>
                                                    <Field placeholder={t('Hospitals.pOCEmailAddress')} name="email" onBlur={(e) => handleEmail(values, setFieldValue, setFieldTouched)} className={'form-control ' + (errors.email && touched.email ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="email" component="div" className="invalid-feedback" />

                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <div className="sub-form-footer mt-3">
                                            <button className="cancel-button" onClick={cancelHospitalsrCreationAction}>{t('ActionNames.cancel')}</button>
                                            <button disabled={actionType === EOprationalActions.EDIT ? !(dirty) : false} className="btn blue-button" >{actionType === EOprationalActions.ADD ? t('ActionNames.create') : t('ActionNames.update')}</button>
                                        </div>
                                    </Form>
                                )
                                }
                            </Formik>
                        </div>
                    </div>
                </div>
            </div>
            {/* Hospitals Single Add End */}
        </div>
    )
}

export default React.memo(HospitalsCreationOrEditComponent)