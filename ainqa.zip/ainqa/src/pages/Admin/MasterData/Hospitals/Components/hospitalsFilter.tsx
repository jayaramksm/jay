import React from 'react';
import UploadFile from '../../../../../images/upload-file.svg';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setHospitalsActionTypeData, setSearchHospitalsData } from '../../../../../store/actions';
import { EOprationalActions } from '../../../../../models/utilitiesModel';


const HospitalsFilter: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const hospitalsCreate = () => dispatch(setHospitalsActionTypeData(EOprationalActions.ADD, null));
    const bulkuploadHospitals = () => dispatch(setHospitalsActionTypeData(EOprationalActions.BULKUPLOAD, null));
    const onSearchChange = e => {
        const searchInput = e.target.value;
        dispatch(setSearchHospitalsData(searchInput));
    };
    const showHospitalsSearch: boolean = useSelector((state: any) => !!(state?.hospitalsReducer?.HospitalsData?.length > 2));

    return (
        <div className="rgtFilter">
            {showHospitalsSearch && <div className="search-box">
                <div className="search-text"><input type="text" placeholder={t('Hospitals.search')} onChange={onSearchChange}></input><i className="ti-search icon"></i></div>
            </div>}
            <button className="addnewButn" onClick={hospitalsCreate}><i className="ti-plus"></i> {t('Hospitals.addHospital')}</button>
            <button className="iconBtn" onClick={bulkuploadHospitals}><img src={UploadFile} alt="" style={{ width: "18px" }}></img></button>
        </div>
    )
}
export default React.memo(HospitalsFilter);