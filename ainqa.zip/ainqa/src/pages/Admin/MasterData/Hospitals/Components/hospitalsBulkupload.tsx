import React from 'react'
import { useTranslation } from 'react-i18next';
import { createBulkUploadHospitalsDataRequest, getHospitalBulkuploadFileHisrotyRequest, setHospitalsActionTypeData } from '../../../../../store/actions';
import { useDispatch } from 'react-redux';
import { getBulkUploadCsvHeaders, customContentValidation, defultContentValidate, emailContentValidate } from '../../../../../helpers/helpersIndex';
import BulkUpload from '../../../../utilities/bulkupload';
import { EBulkUploadComponentNames, EBulkUploadUsers, EOprationalActions } from '../../../../../models/utilitiesModel';
import * as Yup from 'yup';

const HospitalsBulkupload: React.FC = () => {
    const headers: any = getBulkUploadCsvHeaders(EBulkUploadUsers.HOSPITALS);

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const goBackToList = () => dispatch(setHospitalsActionTypeData(EOprationalActions.UNSELECT, null));


    const viewBulkUploadHistory = () => {
        // set actionType to file_history in the request action itself, instead of dispatching multiple actions
        dispatch(getHospitalBulkuploadFileHisrotyRequest());
        dispatch(setHospitalsActionTypeData(EOprationalActions.BULK_UPLOAD_FILE_HISTORY, null));
    }

    const bulkuploadOnSumbit = (validData, invalidData) => {
        dispatch(createBulkUploadHospitalsDataRequest(validData, invalidData, headers));
    }

    const sampleData = {
        [headers.hospitalName]: '',
        [headers.hospitalCode]: '',
        [headers.contactName]: '',
        [headers.contactNum]: '',
        [headers.emailId]: '',
        [headers.location]: ''
    }
    const validationSchema = Yup.object().shape({
        [headers.hospitalName]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 4),

        [headers.hospitalCode]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 20, 1),
        [headers.location]: Yup.lazy((val) => {
            if (val)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'arabicnumaricspecial', spacialChar: '' }, 250, 2);
            else return defultContentValidate('');
        }),
        [headers.contactNum]: Yup.lazy((val) => {
            if (val)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 10, 10);
            else return defultContentValidate('');
        }),

        [headers.contactName]:
            Yup.lazy((val) => {
                if (val)
                    return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 50, 4);
                else return defultContentValidate('');
            }),
        [headers.emailId]:
            Yup.lazy((val) => {
                if (val)
                    return emailContentValidate(t('controleErrors.required'), { value: 2, message: t('controleErrors.min').replace('{min}', '2') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid'));
                else return defultContentValidate('');
            })
    });

    return (
        <div className="flexLayout">
            <div className="maincontent paglayout flexScroll">
                <BulkUpload
                    name={EBulkUploadComponentNames.HOSPITALS}
                    headers={headers}
                    sampleData={sampleData}
                    validationSchema={validationSchema}
                    viewBulkUploadHistory={viewBulkUploadHistory}
                    goBackToList={goBackToList}
                    bulkuploadOnSumbit={bulkuploadOnSumbit}
                />
            </div>
        </div>
    )
}

export default React.memo(HospitalsBulkupload)