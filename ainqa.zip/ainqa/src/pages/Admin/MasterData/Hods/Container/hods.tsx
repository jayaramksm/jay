import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, getHodsAndDepaermentsDataRequest, resetAllHodsStateRequest, cancelAllPendingHodsRequest } from '../../../../../store/actions';
import { SuperParentContext } from './hodsContext';
import {
    HodsParentManager, HodsViewManager, HodsView, HodsFilter,
    HodsBulkuploadFilesHistory, HodsBulkupload, HodsActionManager, HodsCreationOrEditComponent
} from './hodsIndex';
interface IProps {
    activateAuthLayout;
    getHodsAndDepaermentsDataRequest;
    resetAllHodsStateRequest;
    cancelAllPendingHodsRequest
}
class Hods extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            hodsViewmanagerComponent: HodsViewManager,
            hodsViewComponent: HodsView,
            actionManagerComponent: HodsActionManager,
            filterComponent: HodsFilter,
            bulkUploadComponent: HodsBulkupload,
            bulkuploadFilesHistoryComponent: HodsBulkuploadFilesHistory,
            hodsCreationOrEditComponent: HodsCreationOrEditComponent

        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllHodsStateRequest();
        this.props.getHodsAndDepaermentsDataRequest();


    }
    componentWillUnmount() {
        this.props.resetAllHodsStateRequest();
        this.props.cancelAllPendingHodsRequest();

    }
    render() {
        return (
            <div className='flexLayout pr-0'>
                <SuperParentContext.Provider value={this.state}>
                    <HodsParentManager />
                </SuperParentContext.Provider>
            </div>
        )
    }
}


export default connect(null, { activateAuthLayout, getHodsAndDepaermentsDataRequest, resetAllHodsStateRequest, cancelAllPendingHodsRequest })(Hods);