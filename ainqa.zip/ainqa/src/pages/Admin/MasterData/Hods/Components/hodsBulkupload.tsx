import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
// import uploadhistory from '../../../../../images/History.svg';
import { createBulkUploadHodsDataRequest, getHodBulkuploadFileHisrotyRequest, setHodsActionTypeData } from '../../../../../store/actions';
import { EBulkUploadComponentNames, EBulkUploadUsers, EOprationalActions } from '../../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import BulkUpload from '../../../../utilities/bulkupload';
import { getBulkUploadCsvHeaders, customContentValidation, defultContentValidate, emailContentValidate } from '../../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { IDepartment } from '../../../../../models/hodsModel';

const HodsBulkupload: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();


    const goBackToList = () => {
        dispatch(setHodsActionTypeData(EOprationalActions.UNSELECT, null));
    };
    const viewBulkUploadHistory = () => {
        dispatch(getHodBulkuploadFileHisrotyRequest());
        dispatch(setHodsActionTypeData(EOprationalActions.BULK_UPLOAD_FILE_HISTORY, null));
    };

    const bulkuploadOnSumbit = (validData, invalidData, values) => {
        console.log('datawhenUpload===>', { validData, invalidData, headers, values })
        dispatch(createBulkUploadHodsDataRequest(validData, invalidData, headers, values))
    }

    const deptOptions: IDepartment[] = useSelector((state: any) => state?.hodsReducer?.departmentData || []);

    let headers: any = getBulkUploadCsvHeaders(EBulkUploadUsers.HOD);

    let sampleData = {
        [headers.umId]: '',
        [headers.hodFullName]: '',
        [headers.gender]: '',
        [headers.eportfolioEmailId]: '',
        [headers.contactNo]: '',
        [headers.mmcNo]: ''
    }

    const validationSchema = Yup.object().shape({
        [headers.hodFullName]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 4),
        [headers.umId]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 20, 2),
        [headers.mmcNo]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 50, 2),
        [headers.contactNo]: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1),
        [headers.eportfolioEmailId]: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        [headers.gender]: customContentValidation(t, t('controleErrors.required'), { patternType: 'customWords', message: 'customWords', spacialChar: 'M|F|T' }, 1, 1)
    });

    return (
        <div className="flexLayout">
            <div className="maincontent paglayout flexScroll">
                <BulkUpload
                    name={EBulkUploadComponentNames.HODS}
                    headers={headers}
                    sampleData={sampleData}
                    validationSchema={validationSchema}
                    viewBulkUploadHistory={viewBulkUploadHistory}
                    goBackToList={goBackToList}
                    bulkuploadOnSumbit={bulkuploadOnSumbit}
                    options={deptOptions}
                />
            </div>
        </div>
    )
}
export default React.memo(HodsBulkupload);