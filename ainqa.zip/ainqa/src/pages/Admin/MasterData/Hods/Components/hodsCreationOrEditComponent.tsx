import React from 'react'
import { Row, Col, Input, FormGroup, Label, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { EOprationalActions, IUserDetails } from '../../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { createOrEditSingleHodsRequest, setHodsActionTypeData } from '../../../../../store/actions';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, customContentValidation, ValueContainer, Option, emailContentValidate } from '../../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { IDepartment, IHodsModel } from '../../../../../models/hodsModel';

const HodCreationOrEditComponent: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');


    const cancelHodsrCreationAction = () => {
        dispatch(setHodsActionTypeData(EOprationalActions.UNSELECT, null));
    };
    const deptOptions: IDepartment[] = useSelector((state: any) => {
        if (state?.hodsReducer?.departmentData) {
            return (state.hodsReducer as IHodsModel).departmentData
        } else {
            return undefined
        }
    });
    const actionType = useSelector((state: any) => {
        if (state?.hodsReducer?.actionType) {
            return (state.hodsReducer as IHodsModel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const actionData = useSelector((state: any) => {
        if (state?.hodsReducer?.actionData) {
            return (state.hodsReducer as IHodsModel).actionData
        } else {
            return undefined
        }
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return {};
    });

    const genderOptions = [{ value: 'M', label: 'male' }, { value: 'F', label: 'female' }, { value: 'T', label: 'transgender' }];

    const handleEmail = (values, setFieldValue, setFieldTouched) => {
        setFieldTouched('email', true);
    };

    const initialValues = () => ({
        hodName: actionData ? actionData.hodFullName : "",
        umid: actionData ? actionData.umId : "",
        deptName: actionData?.departments || "",
        // deptName: actionData ? patchDepts() : "",
        mmcNo: actionData ? actionData.mmcNo : "",
        cNumber: actionData ? actionData.contactNo : "",
        // email: getEportfolioEmailId(actionData?.eportfolioEmailId),
        email: actionData ? actionData.eportfolioEmailId : "",
        gender: actionData ? genderOptions.find(x => x.value === actionData.gender) : "",
        hodId: actionData ? actionData.hodId : 0
    });
    const validationSchema = Yup.object().shape({
        hodName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 100, 4),
        umid: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 20, 2),
        deptName: defultContentValidate(t('controleErrors.required')),
        mmcNo: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 50, 2),
        cNumber: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1),
        email: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        gender: defultContentValidate(t('controleErrors.required'))
    });

    console.log("DepartmentCreationOrEditComponent==>", actionData, actionType);

    return (
        <div className="flexLayout">
            <div className="flexScroll mydocuments">
                <div className="maincontent paglayout">
                    <div className="top-section">
                        <div className="details-section mt-3">
                            <h2 className="mb-3">{t('Hods.HODDetails')} </h2>
                            <Formik
                                initialValues={initialValues()}
                                validationSchema={validationSchema}
                                onSubmit={(values) => {
                                    dispatch(createOrEditSingleHodsRequest(values, actionType));

                                    console.log("SubmitedValues==>", values);
                                }}>
                                {({ errors, setFieldValue, dirty, setFieldTouched, values, touched, resetForm, isValid }) => (
                                    <Form>
                                        {console.log("errors", errors)}
                                        <Row className="mt-3">
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.HODFullName')}</Label>
                                                    <Field placeholder={t('Hods.enterHODName')} name="hodName" className={'form-control ' + (errors.hodName && touched.hodName ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="hodName" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label>{t('Hods.UMID')}</Label>
                                                    <Field placeholder={t('Hods.enterUMID')} name="umid" className={'form-control ' + (errors.umid && touched.umid ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="umid" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.departmentName')}</Label>
                                                    <MySelect
                                                        allOption={{
                                                            departmentName: "Select All",
                                                            departmentId: ""
                                                        }}
                                                        isMulti={true}
                                                        name="deptName"
                                                        placeholder={t('Hods.selectDept')}
                                                        value={values.deptName}
                                                        onChange={(e) => setFieldValue('deptName', e ? e : '')}
                                                        options={deptOptions ? deptOptions : []}
                                                        getOptionLabel={option => option.departmentName}
                                                        getOptionValue={option => option.departmentId}
                                                        valueKey="departmentId"
                                                        onBlur={() => setFieldTouched('deptName', true)}
                                                        noOptionsMessage={() => { t('Hods.NoDataFound') }}
                                                        components={{ Option, ValueContainer }}
                                                        hideSelectedOptions={false}
                                                        removeSelected={false}
                                                        closeMenuOnSelect={false}
                                                        backspaceRemovesValue={false}
                                                        isSearchable={true}
                                                        allowSelectAll={false}
                                                    />
                                                    {errors.deptName && touched.deptName && (
                                                        <div className="text-danger">{errors.deptName}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>


                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.MMCNumber')}</Label>
                                                    <Field placeholder={t('Hods.enterMMCNo')} name="mmcNo" className={'form-control ' + (errors.mmcNo && touched.mmcNo ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="mmcNo" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.contactNumber')}</Label>
                                                    <Field placeholder={t('Hods.enterContactNumber')} name="cNumber" className={'form-control ' + (errors.cNumber && touched.cNumber ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="cNumber" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.ePortfolioEmailID')}</Label>
                                                    <InputGroup>
                                                        <Field placeholder={t('Hods.enterePortfolioEmailID')} name="email" onBlur={(e) => handleEmail(values, setFieldValue, setFieldTouched)} className={'form-control ' + (errors.email && touched.email ? 'is-invalid' : '')} />
                                                    </InputGroup>
                                                    {errors.email && touched.email && (
                                                        <div className="text-danger">{errors.email}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.Gender')}</Label>
                                                    <MySelect
                                                        name="gender"
                                                        placeholder={t('Hods.Gender')}
                                                        value={values.gender}
                                                        onChange={(e) => setFieldValue('gender', e ? e : '')}
                                                        options={genderOptions ? genderOptions : []}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onBlur={() => setFieldTouched('gender', true)}
                                                        noOptionsMessage={() => { t('Hods.NoDataFound') }}
                                                    />
                                                    {errors.gender && touched.gender && (
                                                        <div className="text-danger">{errors.gender}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.UniversityName')}</Label>
                                                    <Input type="text" disabled value={userDto.university?.universityName} ></Input>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="6" lg="4">
                                                <FormGroup>
                                                    <Label> {t('Hods.UniversityCode')}</Label>
                                                    <Input type="text" disabled value={userDto.university?.universityCode} ></Input>

                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <div className="sub-form-footer mt-3">
                                            <button className="cancel-button" onClick={cancelHodsrCreationAction}>{t('ActionNames.cancel')}</button>
                                            <button disabled={actionType === EOprationalActions.EDIT ? !(dirty) : false} className="btn blue-button" > {actionType === EOprationalActions.ADD ? t('ActionNames.create') : t('ActionNames.update')}</button>

                                        </div>
                                    </Form>
                                )
                                }
                            </Formik>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default React.memo(HodCreationOrEditComponent)