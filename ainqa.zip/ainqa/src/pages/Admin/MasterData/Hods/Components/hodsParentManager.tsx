import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/hodsContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { IHodsModel } from '../../../../../models/hodsModel';

const HodsParentManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const isHospitalsListActionType = useSelector((state: any) => {
        if (state?.hodsReducer)
            return (state.hodsReducer as IHodsModel)?.actionType === EOprationalActions.UNSELECT;
        else return false;
    });

    return (
        <div className="flexLayout maincontent pr-0">
            {isHospitalsListActionType ?
                <ParentContext.Provider value={{ hodsViewComponent: context.hodsViewComponent, filterComponent: context.filterComponent }}>
                    <context.hodsViewmanagerComponent />
                </ParentContext.Provider>
                :
                <ParentContext.Provider value={{ bulkuploadFilesHistoryComponent: context.bulkuploadFilesHistoryComponent, hodsCreationOrEditComponent: context.hodsCreationOrEditComponent, bulkUploadComponent: context.bulkUploadComponent }}>
                    <context.actionManagerComponent />
                </ParentContext.Provider>
            }
        </div>
    )
}
export default React.memo(HodsParentManager);