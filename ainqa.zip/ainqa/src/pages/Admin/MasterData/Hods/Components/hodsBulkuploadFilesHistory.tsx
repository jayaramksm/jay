
import React, { useContext } from 'react'
import { ParentContext } from '../Container/hodsContext'
import { Row, Col, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { setHodsActionTypeData } from '../../../../../store/actions';
import { useDispatch, useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { IHodsModel } from '../../../../../models/hodsModel';

const HodsBulkuploadFilesHistory: React.FC = () => {
    const context = useContext(ParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const fileUploadsHistory = useSelector((state: any) => {
        if (state?.hodsReducer?.uploadedFilesInfo) {
            return (state.hodsReducer as IHodsModel).uploadedFilesInfo
        } else {
            return undefined
        }
    });

    const uploadFile = () => {
        dispatch(setHodsActionTypeData(EOprationalActions.BULKUPLOAD, null));
    };
    const handleChange = () => {
        dispatch(setHodsActionTypeData(EOprationalActions.UNSELECT, null))
    };
    return (
        <>
            <Breadcrumb>
                <BreadcrumbItem><span onClick={handleChange}>{t('Hods.listOfHods')}</span></BreadcrumbItem>
                <BreadcrumbItem><span onClick={uploadFile}>{t('Hods.bulkUpload')}</span></BreadcrumbItem>
                <BreadcrumbItem className="subMenu-Active"> {t('Hods.fileUploadsHistory')}</BreadcrumbItem>
            </Breadcrumb>

            <Row className="compHeading">
                <Col sm="6" xs="12">
                    <h3 className="page-header header-title"> {t('Hods.fileUploadsHistory')}</h3>
                </Col>
                <Col sm="6" xs="12">
                    <div className="text-right">
                        <button onClick={uploadFile} className="addnewButn">{t('Hods.uploadNewFile')}</button>
                    </div>
                </Col>
            </Row>


            <div className="historyTable">
                <table className="myTable table">
                    <thead>
                        <tr>
                            <th>{t('Hods.uploadFile')}</th>
                            <th>{t('Hods.sheetCount')}</th>
                            <th>{t('Hods.dateandTime')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {fileUploadsHistory && fileUploadsHistory.map((x, i) => (
                            <tr key={i}>
                                <td className="fileName">{x.fileName}</td>
                                <td>{x.sheetCount}</td>
                                <td>{x.dateandTime}</td>
                            </tr>
                        ))}


                    </tbody>
                </table>
                {(!fileUploadsHistory || fileUploadsHistory?.length === 0) && <div className="norecordsfound"><h6>{t('Hods.noHodsFound')}</h6></div>}

            </div>
        </>
    )
}

export default React.memo(HodsBulkuploadFilesHistory)