import React from 'react';
import UploadFile from '../../../../../images/upload-file.svg';
import { useTranslation } from 'react-i18next';
import { setHodsActionTypeData, setSearchHodsData } from '../../../../../store/actions';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';

const HodsFilter: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const showHodsSearch: boolean = useSelector((state: any) => !!(state?.hodsReducer?.hodsData?.length > 2));
    const HodsCreate = () => dispatch(setHodsActionTypeData(EOprationalActions.ADD, null));
    const bulkuploadHods = () => dispatch(setHodsActionTypeData(EOprationalActions.BULKUPLOAD, null));
    const onSearchChange = e => {
        const searchInput = e?.target?.value;
        dispatch(setSearchHodsData(searchInput));
    };
    return (
        <>
            {showHodsSearch && <div className="search-box filtericon">
                <div className="search-text">
                    <input type="text" onChange={onSearchChange} placeholder={t('Hods.search')} /><i className="ti-search icon"></i>
                </div>
            </div>
            }
            <button onClick={HodsCreate} className="addnewButn"><i className="ti-plus"></i> {t('ActionNames.create')}</button>
            <button onClick={bulkuploadHods} className="iconBtn"><img src={UploadFile} alt="upload-icon" style={{ width: "18px" }} ></img></button>
        </>
    )
}
export default React.memo(HodsFilter);