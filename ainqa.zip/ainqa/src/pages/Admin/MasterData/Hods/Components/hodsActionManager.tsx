import React, { useContext } from 'react'
import { ParentContext } from '../Container/hodsContext'
import { Breadcrumb, BreadcrumbItem, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setHodsActionTypeData } from '../../../../../store/actions';
import { IHodsModel } from '../../../../../models/hodsModel';

const HodsActionManager: React.FC = () => {
    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionType = useSelector((state: any) => {
        if (state?.hodsReducer?.actionType) {
            return (state.hodsReducer as IHodsModel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const handleChange = () => {
        dispatch(setHodsActionTypeData(EOprationalActions.UNSELECT, null))
    };

    const showBulkUpload = () => {
        dispatch(setHodsActionTypeData(EOprationalActions.BULKUPLOAD, null));
    };

    const showCreateHospital = () => {
        if (actionType !== EOprationalActions.EDIT)
            dispatch(setHodsActionTypeData(EOprationalActions.ADD, null));
    };

    return (
        <>
            {actionType === EOprationalActions.BULK_UPLOAD_FILE_HISTORY ? <context.bulkuploadFilesHistoryComponent /> :
                <>
                    <div className="breadcrumbs">
                        <span className="pointer" onClick={handleChange}>{t('Hods.ListofHOD')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{actionType === EOprationalActions.ADD ? t('Hods.AddHods') : actionType === EOprationalActions.EDIT ? t('Hods.editHods') : t('Hods.bulkUpload')}</span>
                    </div>

                    <div className="uploadTabs flexLayout pr-0">
                        <Nav tabs>
                            <NavItem>
                                <NavLink onClick={showCreateHospital} className={actionType === EOprationalActions.ADD ? 'active' : ''}>
                                    <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                                    <span className="d-none d-sm-block">{actionType === EOprationalActions.EDIT ? t('Hods.editHods') : t('Hods.AddHods')}</span>
                                </NavLink>
                            </NavItem>

                            {actionType !== EOprationalActions.EDIT && <NavItem>
                                <NavLink onClick={showBulkUpload} className={actionType === EOprationalActions.BULKUPLOAD ? 'active' : ''}>
                                    <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                                    <span className="d-none d-sm-block">{t('Hods.bulkUpload')}</span>
                                </NavLink>
                            </NavItem>
                            }
                        </Nav>
                        <TabContent className="flexLayout pr-0">
                            {((actionType === EOprationalActions.ADD) || (actionType === EOprationalActions.EDIT)) && <TabPane className="flexLayout pr-0">
                                <context.hodsCreationOrEditComponent />
                            </TabPane>}
                            {actionType === EOprationalActions.BULKUPLOAD && <TabPane className="flexLayout pr-0">
                                <context.bulkUploadComponent />
                            </TabPane>}


                        </TabContent>
                    </div>
                </>
            }
        </>
    )
}

export default React.memo(HodsActionManager)