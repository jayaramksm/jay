import React, { useContext } from 'react';
import { ChildContext } from '../Container/hodsContext';
import EditIcon from '../../../../../images/Edit.svg';
import Delete from '../../../../../images/Delete.svg';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { deleteHodDataRequest, setHodsActionTypeData } from '../../../../../store/actions';
import { IHod, IHodsModel } from '../../../../../models/hodsModel';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';

const HodsView: React.FC = () => {
    const context: any = useContext(ChildContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const hodData: IHod | any = useSelector((state: any) => {
        if (state?.hodsReducer?.hodsData?.length > 0) {
            let hodsDatas = (state.hodsReducer as IHodsModel).hodsData;
            return hodsDatas.find(hod => hod.hodId === context);
        } else
            return undefined;
    });

    const editHod = () => dispatch(setHodsActionTypeData(EOprationalActions.EDIT, hodData));
    const deleteAction = () => {
        const confirmMessage = t('Hods.confirmMessages.HOD1').replace('{name}', hodData?.hodFullName);
        dispatch(deleteHodDataRequest(hodData?.hodId, false, confirmMessage));
    };

    const university: any = useSelector((state: any) => state?.SessionState?.userDto?.university);
    console.log("HodsView==>", hodData);

    return (
        <>
            <tr>
                <td>{hodData?.hodFullName}</td>
                <td>{hodData?.umId}</td>
                <td>{hodData?.departments?.map(x => x.departmentName).toString()}</td>
                <td>{hodData?.departments?.map(x => x.departmentCode).toString()}</td>
                <td>{university?.universityName}</td>
                <td>{university?.universityCode}</td>

                <td className="column-center">
                    <span><img onClick={editHod} src={EditIcon} className="actionicon pointer" alt=""></img></span>
                    <span><img onClick={deleteAction} src={Delete} alt="" className="actionicon pointer"></img></span>
                </td>
            </tr>
        </>
    )
}
export default React.memo(HodsView);