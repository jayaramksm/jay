import React, { useContext } from 'react';
import { Row, Col } from 'reactstrap';
import { ChildContext, ParentContext } from '../Container/hodsContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setHodsPaginationCurrentPageValue } from '../../../../../store/actions';
import { IHodsModel, IHod } from '../../../../../models/hodsModel';
import { getEnvironment } from '../../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../../utilities/PaginationComponent';


const HodsViewManager: React.FC = () => {
    const context: any = useContext(ParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;
    const hodsData: IHod[] = useSelector((state: any) => state?.hodsReducer?.hodsData);
    const searchKey: string = useSelector((state: any) => {
        if (state?.hodsReducer?.searchKey)
            return (state.hodsReducer as IHodsModel).searchKey;
        else return "";
    });
    const hodsFilterData: any[] = (hodsData && searchKey !== '') ? hodsData?.filter((x: any) => (
        searchKey !== '' ? x.hodFullName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : hodsData;

    const currentPage: number = useSelector((state: any) => {
        if (state?.hodsReducer?.paginationCurrentPage)
            return (state.hodsReducer as IHodsModel).paginationCurrentPage;
        else return 0;
    });



    let pagesCount: number = Math.ceil((hodsFilterData ? hodsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setHodsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setHodsPaginationCurrentPageValue(index));
    };


    console.log("Hodsmanager==>", hodsData);
    return (
        <>
            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title"> {t('Hods.listofExistingHOD')}</h3>
                </Col>
                <div className="rgtFilter">
                    <context.filterComponent />
                </div>

            </Row>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table hod_table">
                                <thead>
                                    <tr>
                                        <th>{t('Hods.HODFullName')}</th>
                                        <th>{t('Hods.UMID')}</th>
                                        <th>{t('Hods.departmentName')}</th>
                                        <th> {t('Hods.departmentCode')}</th>
                                        <th> {t('Hods.UniversityName')}</th>
                                        <th>{t('Hods.UniversityCode')}</th>
                                        <th className="column-center">{t('Hods.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {hodsFilterData && hodsFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                        .map((x, i) => (
                                            <ChildContext.Provider value={x.hodId} key={x.hodId}>
                                                <context.hodsViewComponent />
                                            </ChildContext.Provider>
                                        ))}

                                </tbody>
                            </table>
                        </div>
                        {hodsFilterData?.length === 0 && <div className="norecordsfound"><h6>{t('Hods.noHodsFound')}</h6></div>}
                    </div>
                </div>
                {hodsFilterData && hodsFilterData.length > pageSize &&
                    <div className="pagination">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>}
            </div>
        </>
    )
}
export default React.memo(HodsViewManager);