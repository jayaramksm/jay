import React from 'react';
import { Row, Col, FormGroup, Label } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import { setActionTypeInPrograms } from '../../../../../store/actions';
import { EOprationalActions, IUserDetails } from '../../../../../models/utilitiesModel';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import { MySelect, customContentValidation, defultContentValidate, Option, ValueContainer } from '../../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { getAddOrEditProgramRquest } from '../../../../../store/actions'
import { IPhase } from '../../../../../models/programsModel';
import orderBy from 'lodash/orderBy';

const SingleProgramCreationOrEdit: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const actionType = useSelector((state: any) => {
        if (state?.programsReducer?.actionType)
            return state.programsReducer.actionType;
        else return EOprationalActions.UNSELECT
    });

    const actionData = useSelector((state: any) => {
        if (state?.programsReducer?.actionData)
            return state.programsReducer.actionData;
        else return undefined;
    });
    const phases: IPhase[] = useSelector((state: any) => {
        if (state?.programsReducer?.phaseDistribution)
            return state.programsReducer.phaseDistribution;
        else return undefined;
    });


    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return {};
    });
    const goBackToList = () => dispatch(setActionTypeInPrograms(EOprationalActions.UNSELECT));

    const patchPhaseDistribution = () => {
        let PhaseDistributionValue = phases?.filter(x => x.phaseDistributionId === actionData?.phaseDistributionId);
        console.log("SingleProgramCreationOrEdit11==>", PhaseDistributionValue?.[0]);
        return PhaseDistributionValue?.[0]
    }


    const patchPhaseDenomination = (PhaseDistributionValue) => {
        let phaseDenominationValues = PhaseDistributionValue?.phaseDenominations?.filter(x => (actionData?.phaseDenominationIds?.findIndex(y => y === x.phaseDenominationId) !== -1));

        return phaseDenominationValues
    }

    const initialValues = () => ({
        programName: actionData?.programName || '',
        programCode: actionData?.programCode || '',
        universityName: userDto.university?.universityName || '',
        universityCode: userDto.university?.universityCode || '',
        programId: actionData?.programId || 0,
        phaseDistribution: actionData?.phaseDistributionId ? patchPhaseDistribution() : "",
        denomination: actionData?.phaseDenominationIds ? patchPhaseDenomination(patchPhaseDistribution()) : "",
        denominationOptions: patchPhaseDistribution() ? patchPhaseDistribution()?.phaseDenominations : []
        // phaseDistribution: (actionData?.phaseDistribution) ? (phaseDistributionOptions.filter(x => actionData.phaseDistribution.includes(x.phaseId))) : []
    });

    const validationSchema = Yup.object().shape({
        programName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 50, 4),
        programCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 15, 2),
        phaseDistribution: defultContentValidate(t('controleErrors.required')),
        denomination: defultContentValidate(t('controleErrors.required'))
    });

    const selectPhaseDistribution = (setFieldValue, e) => {
        setFieldValue('phaseDistribution', e ? e : '');
        setFieldValue('denomination', '');

        const orderedDenominations = orderBy(e?.phaseDenominations || [], 'phaseDenomitationName');
        setFieldValue('denominationOptions', orderedDenominations);
    }

    console.log("SingleProgramCreationOrEdit==>", phases, actionData, "ydydy", phases?.filter(x => x.phaseDistributionId === actionData?.phaseDistributionId));

    return (
        <>
            <div className="flexScroll mydocuments">
                <div className="maincontent paglayout">
                    <div className="top-section">
                        <div className="details-section mt-3">
                            <h2 className="mb-3">{t("Programs.programDetails")}</h2>
                            <Formik
                                enableReinitialize
                                initialValues={initialValues()}
                                validationSchema={validationSchema}
                                onSubmit={values => {
                                    dispatch(getAddOrEditProgramRquest(values, actionType))
                                    console.log('onSubmit===>', values)
                                }}
                            >
                                {
                                    ({ values, setFieldTouched, setFieldValue, errors, touched, dirty }) => (
                                        <Form>
                                            <Row>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Programs.pgProgramName")}</Label>
                                                        <Field type="text" placeholder={t("Programs.pgProgramName")} name="programName" className='form-control' />
                                                        <ErrorMessage name='programName' component='div' className='text-danger' />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Programs.pgProgramCode")}</Label>
                                                        <Field type="text" placeholder={t("Programs.pgProgramCode")} name="programCode" className='form-control' />
                                                        <ErrorMessage name='programCode' component='div' className='text-danger' />
                                                    </FormGroup>
                                                </Col>

                                                <Col lg="4" sm="12" xs="12">
                                                    <FormGroup>
                                                        <Label>{t('Programs.phaseDistribution')}</Label>
                                                        <MySelect
                                                            name="phaseDistribution"
                                                            isMulti={false}
                                                            placeholder={t('Programs.phaseDistribution')}
                                                            options={phases}
                                                            value={values.phaseDistribution ? values.phaseDistribution : ''}
                                                            onChange={(e) => selectPhaseDistribution(setFieldValue, e)}
                                                            hideSelectedOptions={false}
                                                            removeSelected={false}
                                                            closeMenuOnSelect={true}
                                                            getOptionLabel={option => option.phaseDistribution}
                                                            getOptionValue={option => option.phaseDistributionId}
                                                            valueKey="phaseDistributionId"
                                                            backspaceRemovesValue={false}
                                                            isSearchable={true}
                                                            allowSelectAll={false}
                                                            onBlur={() => setFieldTouched('phaseDistribution', true)}
                                                            noOptionsMessage={() => t('Programs.noPhasesFound')}
                                                        />
                                                        {errors.phaseDistribution && touched.phaseDistribution && (
                                                            <div className="text-danger">{errors.phaseDistribution}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>


                                                <Col lg="4" sm="12" xs="12">
                                                    <FormGroup>
                                                        <Label>{t('Programs.phaseDenomination')}</Label>
                                                        <MySelect
                                                            name="denomination"
                                                            allOption={{
                                                                phaseDenomitationName: "Select All phaseDistribution",
                                                                phaseDenominationId: 0
                                                            }}
                                                            isMulti={true}
                                                            placeholder={t('Programs.phaseDenomination')}
                                                            options={values.denominationOptions}
                                                            value={values.denomination ? values.denomination : []}
                                                            onChange={(e) => setFieldValue('denomination', e ? e : '')}
                                                            getOptionLabel={option => option.phaseDenomitationName}
                                                            getOptionValue={option => option.phaseDenominationId}
                                                            valueKey="phaseDenominationId"
                                                            components={{ Option, ValueContainer }}
                                                            hideSelectedOptions={false}
                                                            removeSelected={false}
                                                            closeMenuOnSelect={false}
                                                            backspaceRemovesValue={false}
                                                            isSearchable={true}
                                                            allowSelectAll={false}
                                                            onBlur={() => setFieldTouched('denomination', true)}
                                                            noOptionsMessage={() => t('Programs.noPhasesFound')}
                                                        />
                                                        {errors.denomination && touched.denomination && (
                                                            <div className="text-danger">{errors.denomination}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>



                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Programs.universityName")}</Label>
                                                        <Field type="text" name='universityName' disabled className='form-control' />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>{t("Programs.universityCode")}</Label>
                                                        <Field type="text" name='universityCode' disabled className='form-control' />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <div className="sub-form-footer mt-3">
                                                <button className="cancel-button" onClick={goBackToList}>{t("ActionNames.cancel")}</button>
                                                <button type='submit' className="btn blue-button" disabled={actionType === EOprationalActions.EDIT ? !dirty : false}>
                                                    {actionType === EOprationalActions.EDIT ? t("ActionNames.update") : t("ActionNames.create")}
                                                </button>
                                            </div>
                                        </Form>
                                    )
                                }

                            </Formik>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(SingleProgramCreationOrEdit);
