import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/programscontext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';


const ProgramsManagerParent: React.FC = () => {

    const context = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.programsReducer?.actionType)
            return state.programsReducer.actionType;
        else return EOprationalActions.UNSELECT
    })

    return (
        <>

            {actionType === EOprationalActions.UNSELECT && <context.programsFilter />}

            <div className="flexLayout maincontent">
                {actionType === EOprationalActions.UNSELECT && <context.programsViewParent />}
                {((actionType === EOprationalActions.EDIT) || (actionType === EOprationalActions.ADD || actionType === EOprationalActions.BULKUPLOAD)) && <context.programsAction />}
                {actionType === EOprationalActions.BULK_UPLOAD_FILE_HISTORY && <context.bulkUploadFileHistory />}
            </div>
        </>
    )
}

export default React.memo(ProgramsManagerParent);