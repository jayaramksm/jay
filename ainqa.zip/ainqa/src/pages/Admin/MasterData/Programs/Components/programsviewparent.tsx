import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/programscontext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { getEnvironment } from '../../../../../helpers/helpersIndex';
import { setPaginationCurrentPageValueInPrograms } from '../../../../../store/actions';
import { PaginationComponent } from '../../../../utilities/PaginationComponent';
import { IProgram } from '../../../../../models/programsModel';



const ProgramsViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;


    const programsDetails: IProgram[] = useSelector((state: any) => state?.programsReducer?.programsDetails);

    const programsLength: number = useSelector((state: any) => {
        if (state?.programsReducer?.programsDetails?.length)
            return state.programsReducer.programsDetails.length;
        else return 0;
    });
    console.log('programsLength=>', programsLength);

    const searchKey: string = useSelector((state: any) => {
        if (state?.programsReducer?.searchKey)
            return state.programsReducer.searchKey;
        else return '';
    });

    const currentPage: number = useSelector((state: any) => {
        if (state?.programsReducer?.paginationCurrentPage)
            return state.programsReducer.paginationCurrentPage;
        else return 0;
    });

    const programsFilterData: IProgram[] = (programsDetails?.length && searchKey !== '') ? programsDetails?.filter((x: any) => (
        searchKey !== '' ? x.programName.toLowerCase().startsWith(searchKey.toLowerCase()) ? true :
            x.programCode.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : programsDetails;

    let pagesCount: number = Math.ceil((programsFilterData ? programsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setPaginationCurrentPageValueInPrograms(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setPaginationCurrentPageValueInPrograms(index));
    };


    return (
        <>
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent table-responsive">
                        <table className="myTable table prgrm-table">
                            <thead>
                                <tr>
                                    <th>{t("Programs.pgProgramName")}</th>
                                    <th>{t("Programs.pgProgramCode")}</th>
                                    <th>{t("Programs.phaseDistribution")}</th>
                                    <th>{t("Programs.universityName")}</th>
                                    <th>{t("Programs.universityCode")}</th>
                                    <th className="column-center">{t("Programs.actions")}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {programsFilterData?.length > 0 &&
                                    programsFilterData?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                        .map((x) => {
                                            return (
                                                <ParentContext.Provider value={x.programId} key={x.programId}>
                                                    <context.programsView />
                                                </ParentContext.Provider>
                                            )
                                        })
                                }
                            </tbody>
                        </table>
                    </div>
                    {(programsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('Programs.noProgramsData')}</h6></div>}
                </div>
            </div>

            {programsFilterData?.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}

export default React.memo(ProgramsViewParent);
