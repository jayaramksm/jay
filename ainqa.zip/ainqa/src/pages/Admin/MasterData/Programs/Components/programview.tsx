import React, { useContext } from 'react';
import EditIcon from '../../../../../images/Edit.svg';
import Delete from '../../../../../images/Delete.svg';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext } from '../Container/programscontext';
import { getDeleteProgramFromProgramsDetailsRequest, setActionTypeInPrograms } from '../../../../../store/actions';
import { useTranslation } from 'react-i18next';
import { EOprationalActions, IUserDetails } from '../../../../../models/utilitiesModel';
import { IPhase, IProgram } from '../../../../../models/programsModel';

const ProgramView: React.FC = () => {
    const dispatch = useDispatch();
    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');

    const programDetails: any = useSelector((state: any) => {
        if (state?.programsReducer?.programsDetails?.length > 0)
            return state.programsReducer.programsDetails.find(x => x.programId === context);
        else return undefined;
    });


    const handleProgramDelete = () => {
        let confirmMessage = t('Programs.confirmMessages.PM1').replace('{name}', programDetails?.programName)
        dispatch(getDeleteProgramFromProgramsDetailsRequest(programDetails.programId, false, confirmMessage))
    }
    const hadleProgramEdit = () => dispatch(setActionTypeInPrograms(EOprationalActions.EDIT, programDetails))

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return {};
    });
    const phases: IPhase[] = useSelector((state: any) => {
        if (state?.programsReducer?.phaseDistribution)
            return state.programsReducer.phaseDistribution;
        else return undefined;
    });

    const displayPhaseNames = () => phases?.filter(x => x.phaseDistributionId === programDetails?.phaseDistributionId);
    // const displayPhaseNames = () => phaseDistributionOptions.filter(x => programDetails?.phaseDistribution?.includes(x.phaseId))?.map(x => x.phase)?.toString();

    return (
        <>
            {programDetails && <tr>
                <td>{programDetails?.programName}</td>
                <td>{programDetails?.programCode}</td>
                <td>{displayPhaseNames()?.[0]?.phaseDistribution}</td>
                <td>{userDto.university?.universityName}</td>
                <td>{userDto.university?.universityCode}</td>
                <td className="ActionStatus column-center">
                    <span onClick={hadleProgramEdit}><img src={EditIcon} className="actionicon pointer" alt="edit-btn"></img></span>
                    <span onClick={handleProgramDelete}><img src={Delete} alt="delete-btn" className="actionicon pointer"></img></span>
                </td>
            </tr>}
        </>
    )
}

export default React.memo(ProgramView);
