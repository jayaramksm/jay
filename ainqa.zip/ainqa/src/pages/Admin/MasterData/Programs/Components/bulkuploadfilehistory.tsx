import React from 'react';
import { Row, Col, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import { setActionTypeInPrograms } from '../../../../../store/actions';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';


const BulkUploadFileHistory: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const fileUplaodsHistory: any = useSelector((state: any) => {
        if (state?.programsReducer?.fileUploadHistory)
            return state.programsReducer.fileUploadHistory;
        else return []
    });

    const goBackToListOrBulkUpload = (type) => dispatch(setActionTypeInPrograms(type === EOprationalActions.UNSELECT ? EOprationalActions.UNSELECT : EOprationalActions.BULKUPLOAD))

    return (
        <>
            <Breadcrumb>
                <BreadcrumbItem><span onClick={() => goBackToListOrBulkUpload(EOprationalActions.UNSELECT)}>{t('Programs.listOfPrograms')}</span></BreadcrumbItem>
                <BreadcrumbItem><span onClick={() => goBackToListOrBulkUpload(EOprationalActions.BULKUPLOAD)}>{t("Programs.bulkUpload")}</span></BreadcrumbItem>
                <BreadcrumbItem className="subMenu-Active">{t("Programs.fileUploadsHistory")}</BreadcrumbItem>
            </Breadcrumb>

            <Row className="compHeading">
                <Col sm="6" xs="12">
                    <h3 className="page-header header-title">{t("Programs.fileUploadsHistory")}</h3>
                </Col>
                <Col sm="6" xs="12">
                    <div className="text-right">
                        <button className="addnewButn" onClick={() => goBackToListOrBulkUpload(EOprationalActions.BULKUPLOAD)}>{t("Programs.uploadNewFile")}</button>
                    </div>
                </Col>
            </Row>

            <div className="historyTable">
                <table className="myTable table">
                    <thead>
                        <tr>
                            <th>{t("Programs.uploadedFile")}</th>
                            <th>{t("Programs.sheetCount")}</th>
                            <th>{t("Programs.dateAndTime")}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            fileUplaodsHistory?.length > 0 && fileUplaodsHistory.map(x => (
                                <tr key={x.id}>
                                    <td className="fileName">{x.uploadedFileName}</td>
                                    <td>{x.sheetCount}</td>
                                    <td>{x.dateAndTime}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
                {fileUplaodsHistory?.length == 0 && <div className='norecordsfound'><h6>{t('Programs.noDataFound')}</h6></div>}
            </div>

        </>
    )
}

export default React.memo(BulkUploadFileHistory);
