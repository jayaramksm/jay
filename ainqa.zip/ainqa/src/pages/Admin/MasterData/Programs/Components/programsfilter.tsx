import React from 'react';
import UploadFile from '../../../../../images/upload-file.svg';
import { Row, Col } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import { setActionTypeInPrograms, setSearchKeyInPrograms } from '../../../../../store/actions';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';

const ProgramsFilter: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const showProgramsSearch: boolean = useSelector((state: any) => !!(state?.programsReducer?.programsDetails?.length > 2));
    const createProgram = (createType) => dispatch(setActionTypeInPrograms(createType === EOprationalActions.ADD ? EOprationalActions.ADD : EOprationalActions.BULKUPLOAD));
    const handleOnChange = (e) => dispatch(setSearchKeyInPrograms(e.target.value));

    return (
        <>
            <Row className="compHeading">
                <Col>
                    <h3 className="page-header header-title">{t("Programs.listofExistingPrograms")}</h3>
                </Col>
                <div className="rgtFilter">
                    {showProgramsSearch && <div className="search-box filtericon">
                        <div className="search-text">
                            <input type="text" placeholder="Search" onChange={handleOnChange} /><i className="ti-search icon"></i>
                        </div>
                    </div>}
                    <button className="addnewButn" onClick={() => createProgram(EOprationalActions.ADD)}><i className="ti-plus"></i> {t("ActionNames.create")}</button>
                    <button className="iconBtn" onClick={() => createProgram(EOprationalActions.BULKUPLOAD)}><img src={UploadFile} alt="upload-icon" style={{ width: "18px" }} ></img></button>
                </div>
            </Row>
        </>
    )
}

export default React.memo(ProgramsFilter);
