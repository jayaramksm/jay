import React, { useContext } from 'react';
import { Breadcrumb, BreadcrumbItem, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { SuperParentContext } from '../Container/programscontext';
import { useSelector, useDispatch } from 'react-redux';
import { EOprationalActions } from '../../../../../models/utilitiesModel';
import { setActionTypeInPrograms } from '../../../../../store/actions';
import { useTranslation } from 'react-i18next';


const ProgramsAction: React.FC = () => {
    const context = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const actionType = useSelector((state: any) => {
        if (state?.programsReducer?.actionType)
            return state.programsReducer.actionType;
        else return EOprationalActions.UNSELECT
    });

    const goBackToList = () => {
        dispatch(setActionTypeInPrograms(EOprationalActions.UNSELECT));
    }

    const handleOnClick = () => {
        if (actionType === EOprationalActions.EDIT) return
        dispatch(setActionTypeInPrograms(EOprationalActions.ADD))
    }

    return (
        <>
            <div className="breadcrumbs">
                <span  className="pointer" onClick={goBackToList}>{t("Programs.listOfPrograms")}</span>
                <span><i className="ti-angle-right"></i></span>
                <span className="active">
                    {actionType === EOprationalActions.EDIT ? t('Programs.updateProgramDetails') : actionType === EOprationalActions.ADD ? t('Programs.createProgram') : t('Programs.bulkUpload')}
                </span>
            </div>

            <div className="uploadTabs flexLayout pr-0">
                <Nav tabs>
                    <NavItem>
                        <NavLink className={(actionType === EOprationalActions.ADD || actionType === EOprationalActions.EDIT) ? "active" : ''}>
                            <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                            <span className="d-none d-sm-block"
                                onClick={handleOnClick}>
                                {actionType === EOprationalActions.EDIT ? t('Programs.updateProgramDetails') : t('Programs.createProgram')}
                            </span>
                        </NavLink>
                    </NavItem>

                    {actionType !== EOprationalActions.EDIT && <NavItem>
                        <NavLink className={actionType === EOprationalActions.BULKUPLOAD ? "active" : ''}>
                            <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                            <span className="d-none d-sm-block" onClick={() => dispatch(setActionTypeInPrograms(EOprationalActions.BULKUPLOAD))}>{t('Programs.bulkUpload')}</span>
                        </NavLink>
                    </NavItem>}
                </Nav>
                <TabContent className="flexLayout pr-0" activeTab={actionType}>
                    {((actionType === EOprationalActions.ADD) || (actionType === EOprationalActions.EDIT)) &&
                        <TabPane tabId={(actionType === EOprationalActions.EDIT ? EOprationalActions.EDIT : EOprationalActions.ADD)} className="flexLayout pr-0" >
                            <context.singleProgramCreationOrEdit />
                        </TabPane>
                    }
                    {(actionType === EOprationalActions.BULKUPLOAD) &&
                        <TabPane tabId={EOprationalActions.BULKUPLOAD} className="flexLayout pr-0" >
                            <context.programsBulkUpload />
                        </TabPane>
                    }
                </TabContent>
            </div>
        </>
    )
}

export default React.memo(ProgramsAction);
