import React from 'react';
import { getBulkUploadCsvHeaders, customContentValidation } from '../../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { EBulkUploadComponentNames, EBulkUploadUsers, EOprationalActions } from '../../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import BulkUpload from '../../../../utilities/bulkupload';
import { setActionTypeInPrograms, getFileUploadsHistoryInProgramsRequest, createBulkUploadProgramsDataRequest } from '../../../../../store/actions';
import { useDispatch, useSelector } from 'react-redux';


const ProgramsBulkUpload: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();


    const phases = useSelector((state: any) => {
        if (state?.programsReducer?.phaseDistribution)
            return state.programsReducer.phaseDistribution;
        else return undefined;
    });

    const goBackToList = () => {
        dispatch(setActionTypeInPrograms(EOprationalActions.UNSELECT));
    }

    const viewBulkUploadHistory = () => {
        dispatch(setActionTypeInPrograms(EOprationalActions.BULK_UPLOAD_FILE_HISTORY));
        dispatch(getFileUploadsHistoryInProgramsRequest())
    }
    let headers: any = getBulkUploadCsvHeaders(EBulkUploadUsers.PROGRAMS);

    const bulkuploadOnSumbit = (validData, invalidData, values) => {
        console.log('datawhenUpload===>', { validData, invalidData, headers, values })
        dispatch(createBulkUploadProgramsDataRequest(validData, invalidData, headers, values))
    }

    let sampleData = {
        [headers.programName]: '',
        [headers.programCode]: '',
    }

    const validationSchema = Yup.object().shape({
        [headers.programName]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: '' }, 50, 2),
        [headers.programCode]: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaric', spacialChar: '' }, 15, 2),
    });

    return (
        <div className="flexLayout">
            <div className="maincontent paglayout flexScroll">
                <BulkUpload
                    name={EBulkUploadComponentNames.PROGRAMS}
                    headers={headers}
                    sampleData={sampleData}
                    validationSchema={validationSchema}
                    viewBulkUploadHistory={viewBulkUploadHistory}
                    goBackToList={goBackToList}
                    bulkuploadOnSumbit={bulkuploadOnSumbit}
                    options={phases}
                />
            </div>
        </div>
    )
}

export default React.memo(ProgramsBulkUpload);