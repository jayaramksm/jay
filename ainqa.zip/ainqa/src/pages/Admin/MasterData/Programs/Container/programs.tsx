import React, { Component } from 'react'
import {
    activateAuthLayout,
    setResetMasterDataProgramsStateRequest,
    getAllProgramsDetailsAndPhaseDistributionRequest,
    cancelAllPendingProgramsRequest
} from '../../../../../store/actions';
import { connect } from 'react-redux';
import {
    BulkUploadFileHistory,
    ProgramsAction,
    ProgramsBulkUpload,
    ProgramsFilter,
    ProgramsManagerParent,
    ProgramsViewParent,
    ProgramsView,
    SingleProgramCreationOrEdit
} from './programsindex';
import { SuperParentContext } from './programscontext';

interface IProps {
    activateAuthLayout: any;
    setResetMasterDataProgramsStateRequest: any;
    getAllProgramsDetailsAndPhaseDistributionRequest: any;
    cancelAllPendingProgramsRequest: any;
}

export class Programs extends Component<IProps, any> {
    constructor(props) {
        super(props)

        this.state = {
            managerParent: {
                bulkUploadFileHistory: BulkUploadFileHistory,
                programsAction: ProgramsAction,
                programsBulkUpload: ProgramsBulkUpload,
                programsFilter: ProgramsFilter,
                programsViewParent: ProgramsViewParent,
                programsView: ProgramsView,
                singleProgramCreationOrEdit: SingleProgramCreationOrEdit
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getAllProgramsDetailsAndPhaseDistributionRequest();
    }
    componentWillUnmount() {
        this.props.setResetMasterDataProgramsStateRequest();
        this.props.cancelAllPendingProgramsRequest();
    }
    render() {
        return (
            <div className='flexLayout pr-0'>
                <SuperParentContext.Provider value={this.state.managerParent}>
                    <ProgramsManagerParent />
                </SuperParentContext.Provider>
            </div>
        )
    }
}

export default connect(null, { activateAuthLayout, setResetMasterDataProgramsStateRequest, getAllProgramsDetailsAndPhaseDistributionRequest, cancelAllPendingProgramsRequest })(Programs)
