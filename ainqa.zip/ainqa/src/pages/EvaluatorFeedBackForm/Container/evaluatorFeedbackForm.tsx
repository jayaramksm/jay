import React, { Component } from 'react';
import { connect } from 'react-redux';
import { SuperParentContext } from './evaluatorFeedbackFormContext';
import { activateAuthLayout, getAllEvaluatorFeedbackFormDataRequest, cancelAllPendingEvaluatorsFeedbackRequest, resetAllEvaluatorsFeedbackStateRequest } from '../../../store/actions';
import { EvaluatorFeedbackForm, EvaluatorFormError, EvaluatorFeedbackSuccessInvalidLink } from './evaluatorFeedbackFormIndex'
import { withRouter } from 'react-router-dom';
import { ItraineeFormData, EFeedbackSumbitedStatus } from '../../../models/evaluatorFeedbackFormModel';

interface IProps {
    activateAuthLayout: any;
    location: any;
    feedbackformData: ItraineeFormData[];
    loading: boolean;
    getAllEvaluatorFeedbackFormDataRequest: any;
    resetAllEvaluatorsFeedbackStateRequest: any;
    cancelAllPendingEvaluatorsFeedbackRequest: any;
}

export class EvaluatorFeedBackForm extends Component<IProps, any> {

    constructor(props) {
        super(props)

        this.state = {
            uniqueId: new URLSearchParams(this.props.location.search).get('uniqueId')
        }
    }

    componentDidMount() {
        // this.props.activateAuthLayout();
        if (this.state.uniqueId)
            this.props.getAllEvaluatorFeedbackFormDataRequest(this.state.uniqueId);
    }

    componentWillUnmount() {
        this.props.resetAllEvaluatorsFeedbackStateRequest();
        this.props.cancelAllPendingEvaluatorsFeedbackRequest();
    }

    render() {
        return (
            <div className='flexLayout pr-0'>
                {this.props.loading && < div className="appLoading">Loading <div className="lds-ring"><div></div><div></div><div></div><div></div></div></div>}
                {
                    !this.props.loading && this.state.uniqueId && this.props.feedbackformData?.[0]?.status === EFeedbackSumbitedStatus.NOTSUBMITED && <SuperParentContext.Provider value={this.state}>
                        <EvaluatorFeedbackForm />
                    </SuperParentContext.Provider>
                }
                {!this.props.loading && this.state.uniqueId && this.props.feedbackformData?.[0]?.status === EFeedbackSumbitedStatus.SUBMITED && <EvaluatorFeedbackSuccessInvalidLink status={EFeedbackSumbitedStatus.SUBMITED} />}
                {!this.props.loading && this.state.uniqueId && this.props.feedbackformData?.[0]?.status === EFeedbackSumbitedStatus.INVALIDLINK && <EvaluatorFeedbackSuccessInvalidLink status={EFeedbackSumbitedStatus.INVALIDLINK} />
                }
                {!this.props.loading && (!this.state.uniqueId || !(this.props.feedbackformData?.length > 0)) && <EvaluatorFormError />}
            </div >
        )
    }
}

const mapToStateProps = (state) => {
    return {
        feedbackformData: state?.evaluatorFeedbackFormReducer?.feedbackFormData,
        loading: state?.Layout?.loading
    }
}

export default withRouter(connect(mapToStateProps, { activateAuthLayout, getAllEvaluatorFeedbackFormDataRequest, resetAllEvaluatorsFeedbackStateRequest, cancelAllPendingEvaluatorsFeedbackRequest })(EvaluatorFeedBackForm))