import React, { Component, useState, useRef } from 'react';
import { Row, Col, Modal, ModalHeader, ModalBody, Container, Card, CardBody } from 'reactstrap';
import { closeEvaluatorFeedbackFormModel, updateEvaluatorFeedbackFormDataRequest } from '../../../store/actions';
import '../../../scss/feedback.scss';
import FeedbackLogo from '../../../images/Logo.png';
import { Formik, Form, Field } from 'formik';
import { useSelector, useDispatch } from 'react-redux';
import { FormRendererParent, SelectForms, ViewForm } from "form-configurator";
import { ESubCode, ItraineeFormData } from '../../../models/evaluatorFeedbackFormModel';
import { useTranslation } from 'react-i18next';



const EvaluatorFeedbackForm: React.FC = () => {

    const [formStataus, setFormStatus] = useState(false);
    const [isModelOpen, setModelStatus] = useState({
        isModelOpen: false,
        formData: ''
    });
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const traineeFormData: ItraineeFormData[] | undefined = useSelector((state: any) => {
        if (state?.evaluatorFeedbackFormReducer?.feedbackFormData)
            return state.evaluatorFeedbackFormReducer.feedbackFormData
        else return undefined
    });

    const evaluatorFeedbackFormData: any = useSelector((state: any) => {
        if (state?.evaluatorFeedbackFormReducer?.updateFeedbackFormData)
            return state.evaluatorFeedbackFormReducer.updateFeedbackFormData
        else return undefined
    });



    let traineeViewFormData: any = traineeFormData?.[0]?.formData ? JSON.parse(traineeFormData?.[0]?.formData) : ''
    // let traineeViewFormData: any = obje;

    const submitFeedbackFormData = () => {
        dispatch(updateEvaluatorFeedbackFormDataRequest({
            evaluatorFeedbackId: traineeFormData?.[0].evaluatorFeedbackId || '',
            feedbackFormData: isModelOpen.formData
        }))
    }

    const getWbsFullName = (value) => {
        let wbaFullName: string = '';
        switch (value) {
            case ESubCode.CBD:
                wbaFullName = t('EvaluatorFeedbackForm.cbd')
                break;
            case ESubCode.DOPS:
                wbaFullName = t('EvaluatorFeedbackForm.dops')
                break;
            case ESubCode.CEX:
                wbaFullName = t('EvaluatorFeedbackForm.cex')
                break;
            case ESubCode.DOCE:
                wbaFullName = t('EvaluatorFeedbackForm.doce')
                break;
            case ESubCode.MSF:
                wbaFullName = t('EvaluatorFeedbackForm.msf')
                break;
            case ESubCode.PBA:
                wbaFullName = t('EvaluatorFeedbackForm.pba')
                break;
            case ESubCode.PSA:
                wbaFullName = t('EvaluatorFeedbackForm.psa')
                break;
            case ESubCode.NOTSA:
                wbaFullName = t('EvaluatorFeedbackForm.notsa')
                break;
            case ESubCode.SURLOG:
                wbaFullName = t('EvaluatorFeedbackForm.surlog');
                break;
        }
        return wbaFullName
    }
    return (
        <>
            <React.Fragment>
                <Modal className="modal-md feedbackmodal" isOpen={isModelOpen.isModelOpen}>
                    <ModalHeader style={{ border: "0" }}>
                        <div className="modal-close"><button className="btn btn-danger" onClick={() => setModelStatus(state => ({ ...state, isModelOpen: false }))}><i className="ti-close"></i></button></div>
                    </ModalHeader>
                    <ModalBody>
                        <div className="text-center">
                            <div>{t('EvaluatorFeedbackForm.doyouWanttoProceed')}</div>
                            <div className="fbmodal-footer">
                                <div className="fbmodal-buttons">
                                    <button className="btn fb-cancel-button-border" type='button' onClick={() => setModelStatus(state => ({ ...state, isModelOpen: false }))}>{t('EvaluatorFeedbackForm.cancel')}</button>
                                    <button className="btn fb-proceed-button" type='button' onClick={submitFeedbackFormData}>{t('EvaluatorFeedbackForm.submit')}</button></div>
                                <div className="fbmodal-note">{t('EvaluatorFeedbackForm.feedbackFormedited')}</div>
                            </div>
                        </div>
                    </ModalBody>
                </Modal>
                {!evaluatorFeedbackFormData && <div className="container-fluid p-0" style={{ height: "100%" }}>
                    <Row style={{ height: "100%" }}>
                        <Col>
                            <div className="feeback-logo">
                                <img src={FeedbackLogo} alt="" width="170" />
                            </div>
                            <div className="student-details">
                                <dl>
                                    <dt>{t('EvaluatorFeedbackForm.traineeName')}</dt>
                                    <dd>{traineeFormData?.[0]?.traineeName}</dd>
                                </dl>
                                <dl>
                                    <dt>{t('EvaluatorFeedbackForm.program')}</dt>
                                    <dd>{traineeFormData?.[0]?.programName}</dd>
                                </dl>
                                <dl>
                                    <dt>{t('EvaluatorFeedbackForm.stage')}</dt>
                                    <dd>{traineeFormData?.[0]?.stageName}</dd>
                                </dl>
                                <dl>
                                    <dt>{t('EvaluatorFeedbackForm.rotation')}</dt>
                                    <dd>{traineeFormData?.[0]?.rotationName}</dd>
                                </dl>
                                <dl>
                                    <dt>{t('EvaluatorFeedbackForm.formType')}</dt>
                                    <dd>{traineeFormData?.[0]?.wbaName}</dd>
                                </dl>
                            </div>
                        </Col>

                        <Col className="d-flex align-items-center">
                            <div className="form-view">
                                <div className="form-view-header">
                                    <h1>{formStataus ? t('EvaluatorFeedbackForm.evaluatorFeedbackForm') : getWbsFullName(traineeFormData?.[0].wbaName.toLowerCase())}</h1>
                                    <span onClick={() => { setFormStatus(state => !state) }} className="header-link">{formStataus && <i className="ti-angle-left"></i>}&nbsp;{formStataus ? t('EvaluatorFeedbackForm.traineeForm') : null}</span>                                </div>
                                <div className="form-view-content">
                                    <div className="form-view-pad pb-4">
                                        <div className="px-2 mt-2 formbuilder evaluator">
                                            {!formStataus && traineeViewFormData &&
                                                <ViewForm answer={traineeViewFormData?.answer} formName={traineeViewFormData?.name} />
                                            }
                                            {formStataus && traineeFormData?.[0]?.evaluatorFormId && <FormRendererParent
                                                onSaveForm={(formData) => {
                                                    console.log('___formData', formData);
                                                    setModelStatus(state => ({
                                                        ...state,
                                                        isModelOpen: true,
                                                        formData: formData
                                                    }))
                                                }}
                                                id={traineeFormData?.[0]?.evaluatorFormId}
                                            // answer={state.actionData || {}}
                                            />
                                            }
                                        </div>
                                    </div>
                                </div>
                                <div className="form-view-footer">
                                    {!formStataus &&
                                        <button className="btn fb-button" type='button' onClick={() => { setFormStatus(true) }}>{t('EvaluatorFeedbackForm.provideFeedback')}</button>
                                    }
                                    {formStataus &&
                                        <div className="action-buttons">
                                            <button className="btn fb-cancel-button" type='button' onClick={() => { setFormStatus(false) }}>{t('EvaluatorFeedbackForm.cancel')}</button>
                                            {/* <button className="btn fb-proceed-button" onClick={() => { dispatch(closeEvaluatorFeedbackFormModel(true)) }}>Submit</button> */}
                                        </div>
                                    }
                                </div>
                            </div>
                        </Col>
                    </Row>
                </div>}

                {evaluatorFeedbackFormData && evaluatorFeedbackFormData?.status && <React.Fragment>
                    <div className="ex-pages">
                        <div className="content-center">
                            <div className="content-desc-center">
                                <Container>
                                    <Card className="mo-mt-2">
                                        <CardBody>
                                            <Row className="align-items-center">
                                                <Col lg={{ size: 4, offset: 1 }}>
                                                    <div className="ex-page-content">
                                                        <h5>{t('EvaluatorFeedbackForm.feedbackFormSubmit')}</h5>
                                                    </div>
                                                </Col>
                                            </Row>
                                        </CardBody>
                                    </Card>
                                </Container>
                            </div>
                        </div>
                    </div>
                </React.Fragment>}
                {evaluatorFeedbackFormData && !evaluatorFeedbackFormData?.status && <React.Fragment>
                    <div className="ex-pages">
                        <div className="content-center">
                            <div className="content-desc-center">
                                <Container>
                                    <Card className="mo-mt-2">
                                        <CardBody>
                                            <Row className="align-items-center">
                                                <Col lg={{ size: 4, offset: 1 }}>
                                                    <div className="ex-page-content">
                                                        <h5>{t('EvaluatorFeedbackForm.feedbackSubmitFail')}</h5>
                                                    </div>
                                                </Col>
                                            </Row>
                                        </CardBody>
                                    </Card>
                                </Container>
                            </div>
                        </div>
                    </div>
                </React.Fragment>}
            </React.Fragment>
        </>
    )
}

export default React.memo(EvaluatorFeedbackForm);


