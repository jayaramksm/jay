import React from 'react';
import { Container, Row, Col, Card, CardBody } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { EFeedbackSumbitedStatus } from '../../../models/evaluatorFeedbackFormModel';
interface IProps {
    status: any;
}

const EvaluatorFeedbackSuccessInvalidLink: React.FC<IProps> = (props: any) => {

    const { t } = useTranslation('translations');
    console.log("EvaluatorFeedbackSuccessInvalidLink", props)

    return (
        <React.Fragment>
            <div className="ex-pages">
                <div className="content-center">
                    <div className="content-desc-center">
                        <Container>
                            <Card className="mo-mt-2">
                                <CardBody>
                                    <Row className="align-items-center">
                                        <Col lg={{ size: 4, offset: 1 }}>
                                            <div className="ex-page-content">
                                                {props.status === EFeedbackSumbitedStatus.SUBMITED && <h5>{t('EvaluatorFeedbackForm.feedbackSuccess')}</h5>}
                                                {props.status === EFeedbackSumbitedStatus.INVALIDLINK && <h5>{t('EvaluatorFeedbackForm.invalidLink')}</h5>}
                                            </div>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>

                        </Container>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}

export default React.memo(EvaluatorFeedbackSuccessInvalidLink);