import React from 'react';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { IPortfolio } from '../../../models/approvePortfolioModel';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { setApprovePortfolioActionTypeAndActionData, setSearchApprovePortfolioData } from '../../../store/actions';
import { useTranslation } from 'react-i18next';

const ApprovePortfolioFilter: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionData)
            return state.approvePortfoliosReducer.actionData;
        else return undefined;
    });

    const goBackToTraineeView = () => {
        dispatch(setApprovePortfolioActionTypeAndActionData(EOprationalActions.UNSELECT, null, null))
    }

    const updateSearchKey = (e) => {
        dispatch(setSearchApprovePortfolioData(e?.target?.value))
    };
    const showFilter = useSelector((state: any) => !!(state?.approvePortfoliosReducer?.portfoliosData?.length > 2));

    return (
        <>
            <Row className="compHeading">
                {!actionData && <Col className="draftsheading">
                    <h2 className="page-header header-title">  {t('ApprovePortfolio.listofEntries')}</h2>
                </Col>}
                {actionData && <Col className="breadcrumbs">
                    <div>
                        <span onClick={goBackToTraineeView} className='pointer'>{t('ApprovePortfolio.listofEntries')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{actionData?.[0].traineeName}</span>
                    </div>
                </Col>}
                {showFilter && <div className="rgtFilter">
                    <div className="search-box filtericon">
                        <div className="search-text"><input type="text" onChange={updateSearchKey} placeholder="Search"></input><i className="ti-search icon"></i></div>
                    </div>
                </div>}
            </Row>
        </>
    )
}

export default React.memo(ApprovePortfolioFilter)
