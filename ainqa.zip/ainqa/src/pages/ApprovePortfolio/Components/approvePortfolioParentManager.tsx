import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/approvePortfolioContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../models/utilitiesModel';


const ApprovePortfolioParentManager: React.FC = () => {

    const context: any = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionType)
            return state.approvePortfoliosReducer.actionType
        else return EOprationalActions.UNSELECT
    });
    const formModelData = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.assessmentModelData) {
            return (state.approvePortfoliosReducer)?.assessmentModelData
        } else {
            return EOprationalActions.UNSELECT
        }
    });
    return (
        <>
        <div className="flexLayout maincontent pr-2">
            {(actionType === EOprationalActions.UNSELECT || actionType === EOprationalActions.ADD) && <context.approvePortfolioFilter />}
            <div className="flexScroll"> 
                    {actionType === EOprationalActions.UNSELECT && <context.approvePortfoliosTraineeViewParent />}
                    {actionType === EOprationalActions.ADD && <context.approvePortfolioRotationViewParent />}
                    {(actionType === EOprationalActions.EDIT || actionType === EOprationalActions.SELECT) && <context.approvePortfolioAction />}
                    {formModelData?.isOpen && <context.approvePorfolioAssessmentForms />}
                </div>
            </div>
        </>
    )
}
export default React.memo(ApprovePortfolioParentManager);