import React, { useContext } from 'react';
import { PaginationComponent } from '../../utilities/PaginationComponent';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { setApprovePortfolioPaginationCurrentPageValue } from '../../../store/actions';
import { SuperParentContext, ParentContext } from '../Container/approvePortfolioContext';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { IPortfolio } from '../../../models/approvePortfolioModel';


const ApprovePortfolioRotationViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const actionData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionData)
            return state.approvePortfoliosReducer.actionData;
        else return undefined
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.searchKey)
            return state.approvePortfoliosReducer.searchKey;
        else return ''
    });

    const currentPage: number = useSelector((state: any) => state?.approvePortfoliosReducer?.paginationCurrentPage || 0);

    const approvePortfolioFilterData: IPortfolio[] | undefined = (actionData?.length && searchKey !== '') ? actionData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : actionData;

    let pagesCount: number = Math.ceil((approvePortfolioFilterData ? approvePortfolioFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setApprovePortfolioPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setApprovePortfolioPaginationCurrentPageValue(index));
    };
    console.log("ApprovePortfolioRotationViewParent==>", approvePortfolioFilterData)
    return (
        <>
            <div className="tbl-parent table-responsive">
                <table className="w100 myTable approvePortfolio-RotationTable table">
                    <thead>
                        <tr>
                            <th> {t('ApprovePortfolio.stage')}</th>
                            <th> {t('ApprovePortfolio.rotations')}</th>
                            <th>  {t('ApprovePortfolio.code')}</th>
                            <th> {t('ApprovePortfolio.subCode')}</th>
                            <th className="column-center"> {t('ApprovePortfolio.feedbackStatus')}</th>
                            <th className="column-center"> {t('ApprovePortfolio.approvalStatus')}</th>
                            <th> {t('ApprovePortfolio.actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            approvePortfolioFilterData && approvePortfolioFilterData?.length > 0 && approvePortfolioFilterData?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                                <ParentContext.Provider value={x.portfolioId} key={x.portfolioId}>
                                    <context.approvePortfolioRotationView />
                                </ParentContext.Provider>
                            ))
                        }

                    </tbody>
                </table>
                {actionData && (approvePortfolioFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('ApproveRla.noDataFound')}</h6></div>}
            </div>
            {approvePortfolioFilterData && approvePortfolioFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}
export default React.memo(ApprovePortfolioRotationViewParent);