import React, { useContext } from 'react';
import Approved from '../../../images/Approved.svg';
import pending from '../../../images/Pending.svg';
import reject from '../../../images/Reject.svg';
import { useDispatch, useSelector } from 'react-redux';
import { ParentContext } from '../Container/approvePortfolioContext';
import { IPortfolio } from '../../../models/approvePortfolioModel';
import groupBy from 'lodash/groupBy';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { setApprovePortfolioActionTypeAndActionData } from '../../../store/actions';


const ApprovePortfoliosTraineeView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);

    const apporvePortfolioData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.portfoliosData)
            return state.approvePortfoliosReducer.portfoliosData;
        else return undefined
    });

    const approvePortfolioGroupedData = groupBy(apporvePortfolioData, 'traineeId');

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const goToTraineeRotationsRlaView = () => {
        dispatch(setApprovePortfolioActionTypeAndActionData(EOprationalActions.ADD, approvePortfolioGroupedData[context], null))
    };
    const isFirstRotationalSupervisor = (approvePortfolioGroupedData[context][0]?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? true : false;

    const isFirstRotationalSupervisorPendingStatus = approvePortfolioGroupedData[context]?.some(x => x.firstRotationSupervisor?.status === EApprovelActions.PENDING);
    const isFirstRotationalSupervisorApproveStatus = approvePortfolioGroupedData[context]?.every(x => x.firstRotationSupervisor?.status === EApprovelActions.APPROVED);

    const isSecondRotationSupervisorPendingStatus = approvePortfolioGroupedData[context]?.some(x => x.secondRotationSupervisor?.status === EApprovelActions.PENDING);
    const isSecondRotationSupervisorApproveStatus = approvePortfolioGroupedData[context]?.every(x => x.secondRotationSupervisor?.status === EApprovelActions.APPROVED);
    console.log('ApprovePortfoliosTraineeView', { userId: approvePortfolioGroupedData[context][0]?.firstRotationSupervisor?.supervisorId, apporvePortfolioData, approvePortfolioGroupedData, context, isFirstRotationalSupervisor, isSecondRotationSupervisorPendingStatus, isSecondRotationSupervisorApproveStatus })

    return (
        <>
            {apporvePortfolioData && approvePortfolioGroupedData && <tr>
                <td onClick={goToTraineeRotationsRlaView} className='pointer'><span className="pointer ActionStatus">{approvePortfolioGroupedData[context][0]?.traineeName}</span></td>
                <td>{approvePortfolioGroupedData[context][0]?.programName}</td>
                <td>{approvePortfolioGroupedData[context][approvePortfolioGroupedData[context]?.length - 1]?.stageName}</td>
                <td>{approvePortfolioGroupedData[context][approvePortfolioGroupedData[context]?.length - 1]?.rotationName}</td>
                <td className="column-center">
                    {isFirstRotationalSupervisor && <>{(isFirstRotationalSupervisorApproveStatus) ? <img src={Approved} className="icon" alt="" /> : (isFirstRotationalSupervisorPendingStatus ? <img src={pending} className="icon" alt="" /> : <img src={reject} className="icon" alt="" />)}</>}
                    {!isFirstRotationalSupervisor && <>{(isSecondRotationSupervisorApproveStatus) ? <img src={Approved} className="icon" alt="" /> : (isSecondRotationSupervisorPendingStatus ? <img src={pending} className="icon" alt="" /> : <img src={reject} className="icon" alt="" />)}</>}
                </td>
            </tr>}
        </>
    )
}
export default React.memo(ApprovePortfoliosTraineeView);