import React from 'react';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, customContentValidation, defultContentObjectValidate } from '../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import View from '../../../images/View.svg';
import { ESubCode, IPortfolio } from '../../../models/approvePortfolioModel';
import { approvrPortfolioAssessmentFormModelOpenOrClose, setApprovePortfolioActionTypeAndActionData, setapprovrPortfolioStatusRequest } from '../../../store/actions';


const approvalOptions = [{ value: 'approved', label: 'Approved' },
{ value: 'rejected', label: 'Rejected' }];

const ApprovePortfolioAction: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const portfolioActionData: IPortfolio = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.portfolioActionData)
            return state.approvePortfoliosReducer.portfolioActionData;
        else return undefined
    });
    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionData)
            return state.approvePortfoliosReducer.actionData;
        else return undefined
    });

    const actionType = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionType)
            return state.approvePortfoliosReducer.actionType;
        else return undefined
    });

    const getWbsFullName = (value) => {
        let wbaFullName: string = '';
        switch (value) {
            case ESubCode.CBD:
                wbaFullName = t('ApprovePortfolio.cbd')
                break;
            case ESubCode.DOPS:
                wbaFullName = t('ApprovePortfolio.dops')
                break;
            case ESubCode.CEX:
                wbaFullName = t('ApprovePortfolio.cex')
                break;
            case ESubCode.DOCE:
                wbaFullName = t('ApprovePortfolio.doce')
                break;
            case ESubCode.MSF:
                wbaFullName = t('ApprovePortfolio.msf')
                break;
            case ESubCode.PBA:
                wbaFullName = t('ApprovePortfolio.pba')
                break;
            case ESubCode.PSA:
                wbaFullName = t('ApprovePortfolio.psa')
                break;
            case ESubCode.NOTSA:
                wbaFullName = t('ApprovePortfolio.notsa')
                break;
            case ESubCode.SURLOG:
                wbaFullName = t('Portfolio.surlog');
                break;
        }
        return wbaFullName
    }

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return {};
    });

    const initialValues = () => ({
        portfolioActionData: portfolioActionData,
        stage: portfolioActionData?.stageName || '',
        programName: portfolioActionData?.programName,
        rotation: portfolioActionData ? portfolioActionData?.rotationName : '',
        code: portfolioActionData ? portfolioActionData?.code : '',
        subCode: portfolioActionData ? portfolioActionData?.wbaName : '',
        isPartOfAssessed: portfolioActionData ? portfolioActionData?.isAssessed : false,
        files: portfolioActionData ? portfolioActionData?.fileData : [],
        formdata: portfolioActionData?.formData ? JSON.parse(portfolioActionData?.formData) : '',
        portfolioId: portfolioActionData?.portfolioId || '',
        wbaFullName: portfolioActionData ? getWbsFullName(portfolioActionData?.wbaName) : '',
        approvelStatus: portfolioActionData ? ((portfolioActionData?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? approvalOptions.find(x => x.value === portfolioActionData?.firstRotationSupervisor?.status) : approvalOptions.find(x => x.value === portfolioActionData?.secondRotationSupervisor?.status)) : '',
        comments: portfolioActionData ? ((portfolioActionData?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? portfolioActionData?.firstRotationSupervisor?.comments || '' : portfolioActionData?.secondRotationSupervisor?.comments || '') : '',
        signatures: portfolioActionData ? ((portfolioActionData?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? portfolioActionData?.firstRotationSupervisor?.supervisorId || '' : portfolioActionData?.secondRotationSupervisor?.supervisorId || '') : '',
        userId: userDto?.userId,
        evaluatorFormData: portfolioActionData?.evaluatorFeedBack ? portfolioActionData?.evaluatorFeedBack : ''
    })

    const formModelOpen = (setFieldValue, values, type) => {
        const data = { isOpen: true, title: values.wbaFullName, setFieldValue: setFieldValue, portfolioActionData: values.formdata, actionType: type, evaluatorFormData: values.evaluatorFormData }
        dispatch(approvrPortfolioAssessmentFormModelOpenOrClose(data));
    };

    const setApprovalStatus = (e, setFieldValue) => {
        // if (e?.value === EApprovelActions?.REJECTED) {
        //     setFieldValue('signatures', '');
        // }
        setFieldValue('approvelStatus', e);
    }

    const validationSchema = Yup.object().shape({
        approvelStatus: defultContentObjectValidate(t("controleErrors.required")),
        comments: Yup.string().when('approvelStatus', {
            is: (approvelStatus) => approvelStatus?.value === EApprovelActions.REJECTED,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4),
            otherwise: Yup.lazy((val) => {
                if (val)
                    return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4)
                else return defultContentValidate(t(''));
            })
        }),
        // signature: Yup.mixed().when('approvelStatus', {
        //     is: (approvelStatus) => approvelStatus?.value === EApprovelActions.APPROVED,
        //     then: Yup.boolean().oneOf([true], t('controleErrors.required')),
        //     otherwise: defultContentValidate(t('')),
        // })
    });

    const goBackToRotationsPortfolioView = () => {
        dispatch(setApprovePortfolioActionTypeAndActionData(EOprationalActions.ADD, actionData, null));
    }

    console.log('ApprovePortfolioAction==>', portfolioActionData)
    return (

        <>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="maincontent pr-3">
                        {/* <Breadcrumb>
                <BreadcrumbItem><span onClick={goBackToRotationsPortfolioView}>  {portfolioActionData?.traineeName}
                    {/* {t('ApprovePortfolio.listofEntries')} 
                </span></BreadcrumbItem>
                <BreadcrumbItem className="subMenu-Active"> {t('ApprovePortfolio.addEntry')}</BreadcrumbItem>
            </Breadcrumb> */}
                        <div className="breadcrumbs">
                            <span className="pointer" onClick={goBackToRotationsPortfolioView}>  {portfolioActionData?.traineeName}
                                {/* {t('ApprovePortfolio.listofEntries')} */}
                            </span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="active">
                                {t('ApprovePortfolio.addEntry')}
                            </span>
                        </div>
                        <Formik
                            enableReinitialize
                            initialValues={initialValues()}
                            validationSchema={validationSchema}
                            onSubmit={(values) => {
                                dispatch(setapprovrPortfolioStatusRequest(values));
                                console.log("SubmitedValues==>", values);
                            }}>
                            {({ errors, setFieldValue, setFieldTouched, values, touched, dirty }) => (
                                <Form>
                                    <div className="top-section">
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('ApprovePortfolio.stage')}</Label>
                                                        <Input type="text" value={portfolioActionData?.stageName || '-'} disabled className='form-control'></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('ApprovePortfolio.rotation')}</Label>
                                                        <Input type="text" value={portfolioActionData?.rotationName || '-'} disabled className='form-control'></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('ApprovePortfolio.hospital')}</Label>
                                                        <Input type="text" value={(portfolioActionData?.hospitalName ? portfolioActionData?.hospitalName : `Other - ${portfolioActionData?.otherHospitalName}`)} name="hospital" disabled id="hospital"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('ApprovePortfolio.code')}</Label>
                                                        <Input type="text" value={portfolioActionData?.code || ''} name="hospital" disabled id="hospital"></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label>  {t('ApprovePortfolio.subCode')}</Label>
                                                        <Input type="text" value={portfolioActionData?.wbaName || ''} name="hospital" disabled id="hospital"></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label>{t('ApprovePortfolio.1stRotationalSupervisor')}</Label>
                                                        <Input type="text" value={portfolioActionData?.firstRotationSupervisor?.supervisorName || ''} name="rsupervisorone" disabled></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label>{t('ApprovePortfolio.2ndRotationalSupervisor')}</Label>
                                                        <Input type="text" value={portfolioActionData?.secondRotationSupervisor?.supervisorName || ''} name="rsupervisortwo" disabled></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('ApprovePortfolio.dueDate')}</Label>
                                                        <Input type="text" disabled value={portfolioActionData?.dueDate || null} ></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup>
                                                        <Label> {t('ApprovePortfolio.completedDate')}</Label>
                                                        <Input type="text" disabled value={portfolioActionData?.completedDate || null} ></Input>
                                                    </FormGroup>
                                                </Col>
                                                <Col lg="4" sm="6" xs="12">
                                                    <FormGroup check className="assessed pl-0">
                                                        <Label check>
                                                            <Field type='checkbox' disabled name='isPartOfAssessed' />{' '}
                                                            {t('ApprovePortfolio.thiswillbepartofAssessed')}
                                                        </Label>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>
                                    <hr />
                                    <div className="top-section">
                                        <h2>  {t('ApprovePortfolio.artifactUploads')}</h2>
                                        <div className="details-section mt-3">
                                            {portfolioActionData?.fileData && portfolioActionData?.fileData?.map((x: any, i) => (
                                                <Row key={i}>
                                                    <div className="ArtifactName w400">
                                                        <span>{x?.fileName}</span>
                                                    </div>
                                                </Row>
                                            ))}
                                        </div>
                                    </div>
                                    <hr />

                                    {values.formdata && <div className="tbl-parent table-responsive">
                                        <table className="w100 myTable cbdform-table table">
                                            <thead>
                                                <tr>
                                                    <th> {t('ApprovePortfolio.workplacebasedAssessmentName')} </th>
                                                    <th className="column-center"> {t('ApprovePortfolio.actions')} </th>
                                                    {/* <th>&nbsp;</th> */}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>{values?.wbaFullName}  </td>
                                                    <td className="column-center">
                                                        <img src={View} onClick={() => formModelOpen(setFieldValue, values, EOprationalActions.SELECT)} className="actionicon pointer" alt=""></img>
                                                    </td>
                                                    {/* <td>
                                                <button className="btn reminder-button">Reminder</button>
                                            </td> */}
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    }


                                    <div className="top-section">
                                        <Row className="compHeading">
                                            <Col sm="8" xs="12">
                                                <h2>{t('ApprovePortfolio.approvelDetails')}</h2>
                                            </Col>
                                            <Col sm="4" className="column-center">
                                                <span className="approvedDate">   {(values.approvelStatus as any)?.value === EApprovelActions.REJECTED ? t('ApprovePortfolio.rejectOn') : t('ApprovePortfolio.approvedon')} <span className="date">{(portfolioActionData?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? portfolioActionData?.firstRotationSupervisor?.approvedOn : portfolioActionData?.secondRotationSupervisor?.approvedOn}</span></span>
                                            </Col>
                                        </Row>
                                        <div className="details-section">
                                            <Row>
                                                <Col sm='4'>
                                                    <FormGroup >
                                                        <Label>  {t('ApprovePortfolio.approvelStatus')}</Label>
                                                        <MySelect
                                                            name='approvelStatus'
                                                            value={values.approvelStatus}
                                                            placeholder={t('ApprovePortfolio.approvelStatus')}
                                                            onChange={(e) => setApprovalStatus(e, setFieldValue)}
                                                            options={approvalOptions ? approvalOptions : []}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            isDisabled={actionType === EOprationalActions.SELECT}
                                                            onBlur={() => setFieldTouched('approvelStatus', true)}
                                                            noOptionsMessage={() => { t('ApprovePortfolio.noDataFound') }}
                                                        />
                                                        {errors.approvelStatus && touched.approvelStatus && (
                                                            <div className="text-danger">{errors.approvelStatus}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                                <Col sm='8'>
                                                    <FormGroup >
                                                        <Label>  {t('ApprovePortfolio.comments')}</Label>
                                                        <Field as="textarea" rows={1} placeholder={t('ApprovePortfolio.comments')} disabled={actionType === EOprationalActions.SELECT} name='comments' className='form-control' />
                                                        <ErrorMessage name='comments' component='div' className='text-danger' />
                                                    </FormGroup>
                                                </Col>

                                                {/* <Col sm='6'>
                                    <FormGroup >
                                        <Label>{t('ApproveRla.signature')}</Label>
                                        <div className="terms"><Field type="checkbox" name='signature' disabled={((values.approvelStatus as any)?.value !== EApprovelActions.APPROVED || (values.approvelStatus as any)?.value === EApprovelActions.REJECTED) ? true : (values.approvelStatus as any)?.value !== EApprovelActions.APPROVED} /></div><ErrorMessage name='signatures' component='div' className='text-danger' />
                                    </FormGroup>
                                </Col> */}
                                            </Row>
                                        </div>
                                    </div>
                                    <div className="text-center mb-4">
                                        <Row className="sub-form-footer mt-3 mr-3">
                                            <button className="cancel-button" type='button' onClick={goBackToRotationsPortfolioView}>{t('ActionNames.cancel')}</button>
                                            {actionType !== EOprationalActions.SELECT && <button className="btn blue-button">{t('ActionNames.submit')} </button>}
                                        </Row></div>

                                </Form>
                            )
                            }
                        </Formik>
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(ApprovePortfolioAction)