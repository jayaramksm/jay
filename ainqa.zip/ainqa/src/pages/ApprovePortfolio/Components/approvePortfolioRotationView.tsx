import React, { useContext } from 'react';
import Approved from '../../../images/Approved.svg';
import Pending from '../../../images/Pending.svg';
import { useDispatch, useSelector } from 'react-redux';
import { ParentContext } from '../Container/approvePortfolioContext';
import { useTranslation } from 'react-i18next';
import { EEvaluatorFeedBack, ESubCode, IPortfolio } from '../../../models/approvePortfolioModel';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { setApprovePortfolioActionTypeAndActionData } from '../../../store/actions'
import reject from '../../../images/Reject.svg';


const ApprovePortfolioRotationView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');

    const approvePortfolioData: IPortfolio = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionData)
            return state.approvePortfoliosReducer.actionData?.find(x => x.portfolioId === context);
        else return undefined
    });

    const actionData: IPortfolio[] = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionData)
            return state.approvePortfoliosReducer.actionData;
        else return undefined
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const goToMarkRotationPortfolioStatus = (actionType) => {
        dispatch(setApprovePortfolioActionTypeAndActionData(actionType, actionData, approvePortfolioData))
    }
    const isFirstRotationalSupervisor = (approvePortfolioData?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? true : false;
    const evaluatorFeedBack = approvePortfolioData?.evaluatorFeedBack?.filter(x => x?.status === EEvaluatorFeedBack.APPROVED);
    const evaluatorFeedBackStatus = approvePortfolioData?.wbaName !== ESubCode.MSF ? evaluatorFeedBack?.length > 0 : evaluatorFeedBack?.length > 1
    console.log("ApprovePortfolioRotationView==>", { approvePortfolioData, evaluatorFeedBackStatus, evaluatorFeedBack })
    return (
        <>
            {approvePortfolioData && <tr>
                <td>{approvePortfolioData.stageName}</td>
                <td>{approvePortfolioData.rotationName}</td>
                <td>{approvePortfolioData.code}</td>
                <td>{approvePortfolioData.wbaName}</td>
                <td className="column-center">
                    {evaluatorFeedBackStatus ? <img src={Approved} className="icon" alt="" /> : <img src={Pending} className="icon" alt="" />}
                </td>
                <td className="column-center"> {isFirstRotationalSupervisor ? approvePortfolioData.firstRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                    approvePortfolioData.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> :
                        approvePortfolioData.firstRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-'
                    :
                    approvePortfolioData.secondRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                        approvePortfolioData.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> :
                            approvePortfolioData.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-'}
                </td>
                <td>
                    {isFirstRotationalSupervisor && <>{(approvePortfolioData?.isAssessed
                        && evaluatorFeedBackStatus
                        && (approvePortfolioData.firstRotationSupervisor?.status === EApprovelActions.PENDING)) ? <span className="pointer ActionStatus" onClick={() => goToMarkRotationPortfolioStatus(EOprationalActions.EDIT)}> {t('ApproveRla.markStatus')} </span> : <span className="pointer ActionStatus" onClick={() => goToMarkRotationPortfolioStatus(EOprationalActions.SELECT)}>{t('ActionNames.view')}  </span>}</>}
                    {!isFirstRotationalSupervisor && <>{(approvePortfolioData?.isAssessed
                        && evaluatorFeedBackStatus
                        && (approvePortfolioData.secondRotationSupervisor?.status === EApprovelActions.PENDING)) ? <span className="pointer ActionStatus" onClick={() => goToMarkRotationPortfolioStatus(EOprationalActions.EDIT)}>  {t('ApproveRla.markStatus')} </span> : <span className="pointer ActionStatus" onClick={() => goToMarkRotationPortfolioStatus(EOprationalActions.SELECT)}> {t('ActionNames.view')} </span>}</>}
                </td>
            </tr>}

        </>

    )
}
export default React.memo(ApprovePortfolioRotationView);