import React, { useContext } from 'react';
import groupBy from 'lodash/groupBy';
import { PaginationComponent } from '../../utilities/PaginationComponent';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { setApprovePortfolioPaginationCurrentPageValue } from '../../../store/actions';
import { SuperParentContext, ParentContext } from '../Container/approvePortfolioContext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { IPortfolio } from '../../../models/approvePortfolioModel';



const ApprovePortfoliosTraineeViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;


    const apporvePortfolioData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.portfoliosData)
            return state.approvePortfoliosReducer.portfoliosData;
        else return undefined
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.searchKey)
            return state.approvePortfoliosReducer.searchKey;
        else return ''
    });

    const currentPage: number = useSelector((state: any) => state?.approvePortfoliosReducer?.paginationCurrentPage || 0);

    const approvePortfolioGroupedData = Object.entries(groupBy(apporvePortfolioData, 'traineeId'));

    const approvePortfolioGroupedFilterData: any = (approvePortfolioGroupedData?.length && searchKey !== '') ? approvePortfolioGroupedData?.filter((x: any) => (
        searchKey !== '' ? x?.[1][0].traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : approvePortfolioGroupedData;

    let pagesCount: number = Math.ceil((approvePortfolioGroupedFilterData ? approvePortfolioGroupedFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setApprovePortfolioPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setApprovePortfolioPaginationCurrentPageValue(index));
    };

    console.log('approvePortfolioGroupedFilterData', { approvePortfolioGroupedFilterData, apporvePortfolioData })

    return (
        <>
            <div className="tbl-parent table-responsive">
                <table className="w100 myTable approvePortfolioTable table">
                    <thead>
                        <tr>
                            <th> {t('ApprovePortfolio.traineeName')}</th>
                            <th> {t('ApprovePortfolio.programName')}</th>
                            <th> {t('ApprovePortfolio.stage')}</th>
                            <th> {t('ApprovePortfolio.rotations')}</th>
                            <th className="column-center"> {t('ApprovePortfolio.approvalStatus')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            apporvePortfolioData && approvePortfolioGroupedFilterData?.length > 0 && approvePortfolioGroupedFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                                <ParentContext.Provider value={x[0]} key={x[0]}>
                                    <context.approvePortfoliosTraineeView />
                                </ParentContext.Provider>
                            ))
                        }
                    </tbody>
                </table>
                {apporvePortfolioData && (approvePortfolioGroupedFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('ApprovePortfolio.noDataFound')}</h6></div>}
            </div>
            {approvePortfolioGroupedFilterData && approvePortfolioGroupedFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}
export default React.memo(ApprovePortfoliosTraineeViewParent);