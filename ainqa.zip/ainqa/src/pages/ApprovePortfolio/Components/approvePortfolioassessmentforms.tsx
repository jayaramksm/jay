import React from 'react';
import { Modal, ModalHeader, ModalBody, Button, UncontrolledCollapse } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { approvrPortfolioAssessmentFormModelOpenOrClose } from '../../../store/actions';
import { useDispatch, useSelector } from 'react-redux'
import { FormRendererParent, ViewForm } from "form-configurator";
import DownToggle from '../../../images/down_toggle.svg';

const ApprovePorfolioAssessmentForms: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const formModelData = useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.assessmentModelData) {
            return (state.approvePortfoliosReducer)?.assessmentModelData
        } else {
            return undefined
        }
    });

    useSelector((state: any) => {
        if (state?.approvePortfoliosReducer?.actionType)
            return state.approvePortfoliosReducer.actionType;
        else return undefined
    });

    const formModelclose = () => {
        const data = { isOpen: false, title: '' }
        dispatch(approvrPortfolioAssessmentFormModelOpenOrClose(data));
    };
    console.log('PorfolioAssessmentForms==>', formModelData)
    return (
        <React.Fragment>
            <Modal className="modal-lg glamodal" isOpen={true} style={{ margin: "0 auto" }}>
                <ModalHeader style={{ position: "sticky", top: 0, zIndex: 3, background: "#ffffff", borderRadius: "0" }}>
                    <div className="text-center">{formModelData?.title}</div>
                    <div className="modal-close"><button className="btn btn-danger" onClick={() => formModelclose()}><i className="ti-close"></i></button></div>
                </ModalHeader>
                <ModalBody className="formbuilder">
                    <ViewForm answer={formModelData?.portfolioActionData?.answer} formName={formModelData?.portfolioActionData?.name} />

                    <div className="mt-4 viewfbdetails">
                        <a href="#" id="feedback-details" className="feedback-link">{t('ApprovePortfolio.feedbackDetails')} <i className="ti-angle-right smallicon"></i> </a>
                        <UncontrolledCollapse toggler="#feedback-details" className="pt-2">
                            <div className="form-expander mb-2">
                                <h6>{t('ApprovePortfolio.normal')}</h6> <img src={DownToggle} />
                            </div>
                            {formModelData?.evaluatorFormData ? formModelData?.evaluatorFormData?.map(x => {
                                const evaluatorFormData = x?.evaluatorFormData ? JSON.parse(x?.evaluatorFormData) : '';
                                return <ViewForm answer={evaluatorFormData?.answer} formName={evaluatorFormData?.name} />
                            })
                                : t('ApprovePortfolio.noFeedbackDetails')}


                        </UncontrolledCollapse>
                    </div>
                    {/* <div className="text-right mt-3"><Button onClick={formModelclose} className="back-button">{t('ApprovePortfolio.back')}</Button></div> */}
                </ModalBody>
            </Modal>
        </React.Fragment>
    )
}

export default React.memo(ApprovePorfolioAssessmentForms);