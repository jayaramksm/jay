import React from 'react';

export const SuperParentContext = React.createContext<any>(null);
export const ParentContext = React.createContext<any>(null);
