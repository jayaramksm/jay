import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, resetAllApprovePortfolioStateRequest, cancelAllPendingApprovePortfolioRequest, getAllApprovePortfolioEntriesDataRequest } from '../../../store/actions';
import { SuperParentContext } from './approvePortfolioContext';
import {
    ApprovePortfolioParentManager,
    ApprovePortfoliosTraineeViewParent,
    ApprovePortfoliosTraineeView,
    ApprovePortfolioFilter,
    ApprovePortfolioRotationViewParent,
    ApprovePortfolioRotationView,
    ApprovePortfolioAction,
    ApprovePorfolioAssessmentForms
} from './approvePortfolioIndex';
interface IProps {
    activateAuthLayout;
    resetAllApprovePortfolioStateRequest;
    cancelAllPendingApprovePortfolioRequest;
    getAllApprovePortfolioEntriesDataRequest;
}
class ApprovePortfolio extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            approvePortfoliosTraineeViewParent: ApprovePortfoliosTraineeViewParent,
            approvePortfoliosTraineeView: ApprovePortfoliosTraineeView,
            approvePortfolioFilter: ApprovePortfolioFilter,
            approvePortfolioRotationViewParent: ApprovePortfolioRotationViewParent,
            approvePortfolioRotationView: ApprovePortfolioRotationView,
            approvePortfolioAction: ApprovePortfolioAction,
            approvePorfolioAssessmentForms: ApprovePorfolioAssessmentForms
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllApprovePortfolioStateRequest();
        this.props.getAllApprovePortfolioEntriesDataRequest();
    }
    componentWillUnmount() {
        this.props.resetAllApprovePortfolioStateRequest();
        this.props.cancelAllPendingApprovePortfolioRequest();
    }
    render() {
        return (
            <div className="flexLayout">

                <SuperParentContext.Provider value={this.state}>
                    <ApprovePortfolioParentManager />
                </SuperParentContext.Provider>
            </div>
        )
    }
}


export default connect(null, { activateAuthLayout, resetAllApprovePortfolioStateRequest, cancelAllPendingApprovePortfolioRequest, getAllApprovePortfolioEntriesDataRequest })(ApprovePortfolio);