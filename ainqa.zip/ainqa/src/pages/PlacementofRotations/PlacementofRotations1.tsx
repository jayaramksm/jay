import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, UncontrolledTooltip, InputGroup, InputGroupAddon, InputGroupText, UncontrolledDropdown, DropdownToggle, DropdownItem, DropdownMenu } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import EditIcon from '../../images/Edit.svg';
import Approved from '../../images/Approved.svg';
import Rejected from '../../images/Reject.svg';
import Pending from '../../images/Pending.svg';
import View from '../../images/View.svg';
import DatePicker from "react-datepicker";
import Select from 'react-select';

class PalcementOfRotations1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            datevalue: new Date()
        };
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    yearOptions = [{ value: 'year1', label: 'Year 1' },
    { value: 'year2', label: 'Year 2' },
    { value: 'year3', label: 'Year 3' },
    { value: 'year4', label: 'Year 4' }];

    stageOptions = [{ value: 'stage1', label: 'Stage 1' },
    { value: 'stage2', label: 'Stage 2' },
    { value: 'stage3', label: 'Stage 3' },
    { value: 'stage4', label: 'Stage 4' }];

    rotationOptions = [{ value: 'rotation1', label: 'Rotation 1' },
    { value: 'rotation2', label: 'Rotation 2' },
    { value: 'rotation3', label: 'Rotation 3' },
    { value: 'rotation4', label: 'Rotation 4' }];

    sequenceOptions = [{ value: 'sequence1', label: 'Secquence 1' },
    { value: 'sequence2', label: 'Secquence 2' },
    { value: 'sequence3', label: 'Secquence 3' },
    { value: 'sequence4', label: 'Secquence 4' }];

    periodOptions = [{ value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' }];

    universityOptions = [{ value: 'university1', label: 'University 1' },
    { value: 'university2', label: 'University 2' },
    { value: 'university3', label: 'University 3' },
    { value: 'university4', label: 'University 4' }];

    supervisorOptions = [{ value: 'sup1', label: 'Supervisor 1' },
    { value: 'sup2', label: 'Supervisor 2' },
    { value: 'sup3', label: 'Supervisor 3' },
    { value: 'sup4', label: 'Supervisor 4' }];

    procedureOptions = [{ value: 'Procedure1', label: 'Procedure1' },
    { value: 'Procedure2', label: 'Procedure2' },
    { value: 'Procedure3', label: 'Procedure3' },
    { value: 'Procedure4', label: 'Procedure4' }];


    render() {

        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h2>Placement of Rotations and Learning Agreements</h2>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <UncontrolledDropdown>
                                    <DropdownToggle id="Filter">
                                        <i className="icon-filter"></i>
                                    </DropdownToggle>
                                    <DropdownMenu>
                                        <DropdownItem>All</DropdownItem>
                                        <DropdownItem>Pending</DropdownItem>
                                        <DropdownItem>Approved</DropdownItem>
                                        <DropdownItem>Rejected</DropdownItem>
                                    </DropdownMenu>
                                </UncontrolledDropdown>
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Create New PLA</button>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            <div className="main-table no-border no-gaps">
                                <div className="tbl-parent table-responsive">
                                    <table className="myTable pla-table table">
                                        <thead>
                                            <tr>
                                                <th>Year</th>
                                                <th>Stage</th>
                                                <th>Rotations</th>
                                                <th>Rotation University</th>
                                                <th>Rotation Months</th>
                                                <th>1st Clinical Supervisor</th>
                                                <th className="column-center">Approval Status</th>
                                                <th>2nd Clinical Supervisor</th>
                                                <th className="column-center">Approval Status</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Year I</td>
                                                <td>Stage 1</td>
                                                <td>Rotation 01</td>
                                                <td>UM</td>
                                                <td>02</td>
                                                <td>Dr. David</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td>Dr. David</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td>05/06/21</td>
                                                <td>05/06/21</td>
                                                <td className="column-center"><img src={View} className="actionicon pointer" alt="" /></td>
                                            </tr>
                                            <tr>
                                                <td>Year I</td>
                                                <td>Stage 1</td>
                                                <td>Rotation 01</td>
                                                <td>UM</td>
                                                <td>02</td>
                                                <td>Dr. David</td>
                                                <td className="column-center"><img src={Rejected} className="icon" alt="" /></td>
                                                <td>Dr. David</td>
                                                <td className="column-center"><img src={Pending} className="icon" alt="" /></td>
                                                <td>07/06/21</td>
                                                <td>07/06/21</td>
                                                <td className="column-center"><img src={EditIcon} className="actionicon pointer" alt="" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div>
                                    <div className="top-section">
                                        <h2><div>Aggrement Details</div></h2>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Trainee Name</Label>
                                                        <Input type="text" disabled value="Johnny Dep"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Programme Name</Label>
                                                        <Input type="text" disabled value="Family Medicine"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Head of the Department</Label>
                                                        <Input type="text" disabled value="Dr. Venkat"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Educational Supervisor</Label>
                                                        <Input type="text" disabled value="Dr. Murthy"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>MOH Supervisor</Label>
                                                        <Input type="text" disabled value="Dr. David"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Agreement Start Date</Label>
                                                        <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>

                                    <hr />

                                    <div className="top-section">
                                        <h2><div>Meeting Details</div></h2>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Meeting Date Time</Label>
                                                        <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Agreed Date for Next Meeting</Label>
                                                        <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>

                                    <hr />
                                    <div className="top-section">
                                        <h2><div>Rotation Details</div></h2>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Year</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.yearOptions}
                                                            placeholder="Select Year" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Stage</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.stageOptions}
                                                            placeholder="Select Stage" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Rotation</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.rotationOptions}
                                                            placeholder="Select Rotation" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Rotation Sequence</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.sequenceOptions}
                                                            placeholder="Select Sequence" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Rotation University</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.universityOptions}
                                                            placeholder="Select University" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Rotation Duration</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.periodOptions}
                                                            placeholder="Select Duration" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Rotation start Date</Label>
                                                        <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Rotation End Date</Label>
                                                        <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Hosptial Name <i className="ti-info-alt ml-2 text-danger" style={{ fontSize: "13px" }} id="helptext"></i></Label>
                                                        <Input type="text" disabled value="Putra Medical Center"></Input>
                                                        <UncontrolledTooltip style={{ minWidth: "260px" }} color="primary" placement="top" target="helptext">
                                                            You can update hospital in Study plan
                                                        </UncontrolledTooltip>
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row>
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Placement Aims and objective</Label>
                                                        <textarea placeholder="Write down here" rows={1} className="comments"></textarea>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Planned Absences & Conferences</Label>
                                                        <textarea placeholder="Write down here" rows={1} className="comments"></textarea>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>
                                    <hr />
                                    <div className="top-section">
                                        <h2>Clinical Supervisor Details</h2>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>1st Clinical Supervisor</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.supervisorOptions}
                                                            placeholder="Select 1st Clinical Supervisor" />
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>2nd Clinical Supervisor</Label>
                                                        <Select
                                                            onChange={(e) => this.handleChange(e)}
                                                            options={this.supervisorOptions}
                                                            placeholder="Select 2nd Clinical Supervisor" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>

                                    <hr />

                                    <div className="top-section">
                                        <h2><div>Expected WBA's Details</div></h2>
                                        <div className="details-section section-border mt-3 table-responsive">
                                            <table className="details-table table">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Expected</th>
                                                        <th>Planned</th>
                                                        <th>Completed</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>CEX Count</td>
                                                        <td><Input type="text" value="02" disabled /></td>
                                                        <td><Input type="text" placeholder="Enter Count" /></td>
                                                        <td><Input type="text" value="" disabled /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>DOP Count</td>
                                                        <td><Input type="text" value="02" disabled /></td>
                                                        <td><Input type="text" placeholder="Enter Count" /></td>
                                                        <td><Input type="text" value="" disabled /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>MSF Count</td>
                                                        <td><Input type="text" value="02" disabled /></td>
                                                        <td><Input type="text" placeholder="Enter Count" /></td>
                                                        <td><Input type="text" value="" disabled /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>PBA Count</td>
                                                        <td><Input type="text" value="02" disabled /></td>
                                                        <td><Input type="text" placeholder="Enter Count" /></td>
                                                        <td><Input type="text" value="" disabled /></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <hr />

                                        <div>
                                            <div className="top-section">
                                                <Row className="align-center px-2">
                                                    <Col sm="5" xs="12" className="mb-4">
                                                        PBA Procedure
                                                    </Col>
                                                    <Col sm="7" xs="12">
                                                        <Row className="addProcedure">
                                                            <Col sm="6" xs="12" className="procedureSelect">
                                                                <Select
                                                                    onChange={(e) => this.handleChange(e)}
                                                                    options={this.procedureOptions}
                                                                    placeholder="Select Procedure"
                                                                />
                                                            </Col>
                                                            <Col sm="6" xs="12" className="ActionStatus">
                                                                Add Another Procedure
                                                            </Col>
                                                        </Row>

                                                        <Row className="addProcedure">
                                                            <Col sm="6" xs="12" className="procedureSelect">
                                                                <Select
                                                                    onChange={(e) => this.handleChange(e)}
                                                                    options={this.procedureOptions}
                                                                    placeholder="Select Procedure"
                                                                />
                                                            </Col>
                                                            <Col sm="6" xs="12" className="deleteText pointer">
                                                                Delete Procedure
                                                            </Col>
                                                        </Row>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>

                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Trainee Signature</Label>
                                                        <div className="terms"><input type="checkbox"></input>Acceptance of Agreement</div>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Trainee Comments</Label>
                                                        <textarea rows={1} className="comments" placeholder="Enter Comments"></textarea>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>

                                    <hr />

                                    <div className="top-section">
                                        <Row className="vhcenter">
                                            <Col sm="6" xs="12">
                                                <h2>1st Clinical Supervisor Details</h2>
                                            </Col>
                                            <Col sm="6" xs="12" className="text-right">
                                                <span className="approvedDate">Approved on : <span className="date">07/03/2021</span></span>
                                            </Col>
                                        </Row>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Approval Status</Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value="Approved" />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText><img src={Approved} className="icon" alt="" /></InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Remarks</Label>
                                                        <Input type="text" disabled value="-"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Signature</Label>
                                                        <Input type="text" disabled value="Prakash"></Input>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>

                                    <hr />

                                    <div className="top-section">
                                        <Row className="vhcenter">
                                            <Col sm="6" xs="12">
                                                <h2>2nd Clinical Supervisor Details</h2>
                                            </Col>
                                            <Col sm="6" xs="12" className="text-right">
                                                <span className="approvedDate">Approved on : <span className="date">07/03/2021</span></span>
                                            </Col>
                                        </Row>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Approval Status</Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value="Approved" />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText><img src={Approved} className="icon" alt="" /></InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Remarks</Label>
                                                        <Input type="text" disabled value="-"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Signature</Label>
                                                        <Input type="text" disabled value="David"></Input>
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                        </div>
                                        <Row className="sub-form-footer mt-3 mr-3">
                                            <button className="back-button">Back</button>
                                        </Row>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(PalcementOfRotations1));