import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Pagination, PaginationItem, PaginationLink, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import DatePicker from "react-datepicker";
import EditIcon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';
import Approved from '../../images/Approved.svg';
import Deactive from '../../images/Deactive.svg';

import Select from 'react-select';

class UniversityAdmin1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            activeTab: "1",
            fileName: "No file Choosen",
            datevalue: new Date()
        };
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }
    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    countryOptions = [{ value: 'malaysia', label: 'Malaysia' },
    { value: 'singapore', label: 'Singapore' },
    { value: 'india', label: 'India' }];

    genderOptions = [{ value: 'male', label: 'Male' },
    { value: 'female', label: 'Female' },
    { value: 'other', label: 'Other' }];

    universityOptions = [{ value: 'university1', label: 'University of Malaysia' },
    { value: 'university2', label: 'University of Singapore' }];


    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of University Admins</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box">
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Add Admin</button>
                            {/* <button className="iconBtn"><img src={UploadFile} alt="" style={{width:"18px"}}></img></button> */}
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            <div className="main-table">
                                <div className="tbl-parent table-responsive">
                                    <table className="w100 myTable uadminTable table">
                                        <thead>
                                            <tr>
                                                <th>Admin Name</th>
                                                <th>Admin Code</th>
                                                <th>University Name</th>
                                                <th className="column-center">Active Status</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Praha</td>
                                                <td>001</td>
                                                <td>University of Malaysia</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td className="column-center">
                                                    <img src={Deactive} className="actionicon pointer" alt="Deactive University"></img>
                                                    <img src={EditIcon} className="actionicon pointer" alt="Edit University"></img>
                                                    <img src={Delete} className="actionicon pointer" alt="Delete University"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Vishwa</td>
                                                <td>002</td>
                                                <td>University of Singapore</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td className="column-center">
                                                    <img src={Deactive} className="actionicon pointer" alt="Deactive University"></img>
                                                    <img src={EditIcon} className="actionicon pointer" alt="Edit University"></img>
                                                    <img src={Delete} className="actionicon pointer" alt="Delete University"></img>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div className="pagination">
                                        <Pagination aria-label="Page navigation example">
                                            <PaginationItem>
                                                <PaginationLink first href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink previous href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    1
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    2
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    3
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    4
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    5
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink next href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink last href="#" />
                                            </PaginationItem>
                                        </Pagination>
                                    </div>
                                </div>
                            </div>

                            <Breadcrumb>
                                <BreadcrumbItem><span>List of University Admins</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Add Admin</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="top-section">
                                <h2>University Details</h2>
                                <div className="details-section">
                                    <Row className="mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.universityOptions}
                                                    placeholder="Select University"
                                                    value={{ value: 'university1', label: 'University of Malaysia' }}
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University Code</Label>
                                                <Input type="text" disabled placeholder="001"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>

                                <hr />
                                <h2>Admin Personal Details</h2>
                                <div className="details-section">
                                    <Row className="vhcenter mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Full Name</Label>
                                                <Input type="text" placeholder="Johnny Depp"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Date of Birth</Label>
                                                <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <FormGroup>
                                                    <Label>Gender</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.genderOptions}
                                                        placeholder="Select Gender"
                                                    />
                                                </FormGroup>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>MMC Number</Label>
                                                <Input type="text" placeholder="001"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                                <hr />
                                <h2>Admin Contact Details</h2>
                                <div className="details-section">
                                    <Row className="vhcenter mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Contact No 1</Label>
                                                <Input type="text" placeholder="9876543210"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Contact No 2</Label>
                                                <Input type="text" placeholder="999887776"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Personal Email Id</Label>
                                                <Input type="text" placeholder="praha@email.com"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                                <hr />
                                <h2>Admin Address Details</h2>
                                <div className="details-section">
                                    <Row className="vhcenter mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Residential Address</Label>
                                                <Input type="text" placeholder="3/4, XYZ, Abc"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Country</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.countryOptions}
                                                    placeholder="Select Country"
                                                    value={{ value: 'malaysia', label: 'Malaysia' }}
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Correspondent Address</Label>
                                                <FormGroup check>
                                                    <Label check>
                                                        <Input type="checkbox" checked="true" />{' '}
                                                        Same as Residential Address
                                                    </Label>
                                                </FormGroup>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Correspondent Address</Label>
                                                <Input type="text" disabled placeholder="3/4, XYZ, Abc"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Country</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.countryOptions}
                                                    placeholder="Select Country"
                                                    value={{ value: 'malaysia', label: 'Malaysia' }}
                                                    isDisabled={true}
                                                />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                                <hr />
                                <h2>Login Details</h2>
                                <div className="details-section">
                                    <Row className="mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>ePortfolio Email ID</Label>
                                                <InputGroup>
                                                    <Input defaultValue="JohnnyDepp" />
                                                    <InputGroupAddon addonType="append">
                                                        <InputGroupText>@eportfolio.com</InputGroupText>
                                                    </InputGroupAddon>
                                                </InputGroup>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>

                                <Row className="sub-form-footer mt-3">
                                    <button className="cancel-button">Cancel</button>&nbsp;<button className="blue-button">Create</button>
                                </Row>

                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(UniversityAdmin1));