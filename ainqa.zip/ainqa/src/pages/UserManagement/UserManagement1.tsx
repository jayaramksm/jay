import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Form, UncontrolledDropdown, DropdownToggle, DropdownItem, DropdownMenu, Pagination, PaginationItem, PaginationLink, TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Scrollbars } from 'react-custom-scrollbars';
import Approved from '../../images/Approved.svg';
import Reject from '../../images/Reject.svg';
import EditIcon from '../../images/Edit.svg';
import uploadImg from '../../images/Upload.svg';
import closeIcon from '../../images/Close.svg';
import filter from '../../images/filter.svg';
import Delete from '../../images/Delete.svg';
import Inactive from '../../images/Inactive.svg';
import classnames from 'classnames';
import DatePicker from "react-datepicker";
import UploadFile from '../../images/upload-file.svg';

import Select from 'react-select';

class UserManagement1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            activeTab: "1",
            fileName: "No file Choosen"
        };
        this.toggle = this.toggle.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this)
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }
    toggle = tab => {
        this.setState({ activeTab: tab })
    }
    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    handleFileChange = (event) => {
        this.setState({ fileName: event.target.files[0].name })
    }

    roleOptions = [{ value: 'moh', label: 'MOH' },
    { value: 'educational', label: 'Educational' },
    { value: 'clinical', label: 'Clinical' },
    { value: 'research', label: 'Research' },
    { value: 'trainee', label: 'Trainee' }];

    countryOptions = [{ value: 'malaysia', label: 'Malaysia' },
    { value: 'india', label: 'India' },
    { value: 'indonesia', label: 'Indonesia' }];


    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of Existing Users</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <UncontrolledDropdown>
                                    <DropdownToggle id="Filter">
                                        <img src={filter} alt="" />

                                    </DropdownToggle>
                                    <DropdownMenu>
                                        <DropdownItem>All</DropdownItem>
                                        <DropdownItem>Pending</DropdownItem>
                                        <DropdownItem>Approved</DropdownItem>
                                        <DropdownItem>Rejected</DropdownItem>
                                    </DropdownMenu>
                                </UncontrolledDropdown>
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Create User</button>
                            <button className="iconBtn"><img src={UploadFile} alt="" style={{ width: "18px" }}></img></button>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <Scrollbars>
                            <div className="mydocuments pr-3">
                                <div className="main-table">
                                    <div className="mydocumentTable tbl-parent table-responsive">
                                        <table className="w100 myTable usersTable table">
                                            <thead>
                                                <tr>
                                                    <th>User ID</th>
                                                    <th>User Code</th>
                                                    <th>User Name</th>
                                                    <th>User Type</th>
                                                    <th className="column-center">Status</th>
                                                    <th className="column-center">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>12457</td>
                                                    <td>UMM123</td>
                                                    <td>Johnny Dep</td>
                                                    <td>MOH</td>
                                                    <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>45787</td>
                                                    <td>UMED123</td>
                                                    <td>Michel</td>
                                                    <td>Educational</td>
                                                    <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>12457</td>
                                                    <td>UMM321</td>
                                                    <td>Mohammed</td>
                                                    <td>Trainee</td>
                                                    <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>45787</td>
                                                    <td>UMM456</td>
                                                    <td>Ameer</td>
                                                    <td>Trainee</td>
                                                    <td className="column-center"><img src={Inactive} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>12457</td>
                                                    <td>UMT789</td>
                                                    <td>Khan</td>
                                                    <td>Trainee</td>
                                                    <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>457875</td>
                                                    <td>UMCL123</td>
                                                    <td>John</td>
                                                    <td>Clinical</td>
                                                    <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>12457</td>
                                                    <td>UMR589</td>
                                                    <td>Akram</td>
                                                    <td>Research</td>
                                                    <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>457875</td>
                                                    <td>UMCL456</td>
                                                    <td>Yusuf</td>
                                                    <td>Clinical</td>
                                                    <td className="column-center"><img src={Inactive} className="icon" alt="" /></td>
                                                    <td className="column-center">
                                                        <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                        <img src={Delete} alt="" className="actionicon pointer"></img>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>

                                        <div className="pagination">
                                            <Pagination aria-label="Page navigation example">
                                                <PaginationItem>
                                                    <PaginationLink first href="#" />
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink previous href="#" />
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink href="#">
                                                        1
                                                    </PaginationLink>
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink href="#">
                                                        2
                                                    </PaginationLink>
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink href="#">
                                                        3
                                                    </PaginationLink>
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink href="#">
                                                        4
                                                    </PaginationLink>
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink href="#">
                                                        5
                                                    </PaginationLink>
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink next href="#" />
                                                </PaginationItem>
                                                <PaginationItem>
                                                    <PaginationLink last href="#" />
                                                </PaginationItem>
                                            </Pagination>
                                        </div>
                                    </div>
                                </div>

                                <div className="uploadTabs">
                                    <Nav tabs>
                                        <NavItem>
                                            <NavLink
                                                className={classnames({ active: this.state.activeTab === '1' })}
                                                onClick={() => { this.toggle('1'); }}
                                            >
                                                Create Single User
                                            </NavLink>
                                        </NavItem>
                                        <NavItem>
                                            <NavLink
                                                className={classnames({ active: this.state.activeTab === '2' })}
                                                onClick={() => { this.toggle('2'); }}
                                            >
                                                Bulk Upload
                                            </NavLink>
                                        </NavItem>
                                    </Nav>
                                    <TabContent activeTab={this.state.activeTab}>
                                        <TabPane tabId="1">
                                            <div className="maincontent mt-3">
                                                <div className="top-section">
                                                    <div className="details-section">
                                                        <Row>
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Select User Role</Label>
                                                                    <Select
                                                                        onChange={(e) => this.handleChange(e)}
                                                                        options={this.roleOptions}
                                                                        placeholder="Select Role" />
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </div>
                                                <div className="top-section">
                                                    <h2><div>User Personal Details</div></h2>
                                                    <div className="details-section">
                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Full Name</Label>
                                                                    <Input type="text" defaultValue="JohnnyDepp"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Date of Birth</Label>
                                                                    <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Ethnicity</Label>
                                                                    <Input type="text" defaultValue="Malay"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Gender</Label>
                                                                    <Input type="text" defaultValue="Male"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </div>
                                                <hr />

                                                <div className="top-section">
                                                    <h2><div>User Contact Details</div></h2>
                                                    <div className="details-section">
                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Contact No. 1</Label>
                                                                    <Input type="text" defaultValue="9876543210"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Contact No. 2</Label>
                                                                    <Input type="text" defaultValue="9998877766"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Personal Email ID</Label>
                                                                    <Input type="text" defaultValue="Johnnydep@email.com"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </div>
                                                <hr />

                                                <div className="top-section">
                                                    <h2><div>User Address Details</div></h2>
                                                    <div className="details-section">
                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Residential Address</Label>
                                                                    <Input type="text" defaultValue="3/4, XYZ, ABC"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Country</Label>
                                                                    <Select
                                                                        onChange={(e) => this.handleChange(e)}
                                                                        options={this.countryOptions}
                                                                        placeholder="Select Country" />
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Correspondent Address</Label>
                                                                    <FormGroup check>
                                                                        <Label check>
                                                                            <Input type="checkbox" />{' '}
                                                                            Same as Residential Address
                                                                        </Label>
                                                                    </FormGroup>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Correspondent address</Label>
                                                                    <Input type="text" disabled defaultValue="3/4, XYZ, ABC"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Country</Label>
                                                                    <Select
                                                                        onChange={(e) => this.handleChange(e)}
                                                                        options={this.countryOptions}
                                                                        placeholder="Select Country" isDisabled={true} />
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </div>
                                                <hr />

                                                <div className="top-section">
                                                    <h2><div>UM Details</div></h2>
                                                    <div className="details-section">
                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Legacy Code</Label>
                                                                    <Input type="text" defaultValue="LUM2514"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Code</Label>
                                                                    <Input type="text" defaultValue="UM388"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>IC Number</Label>
                                                                    <Input type="text" defaultValue="IC-115"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>AMM Number</Label>
                                                                    <Input type="text" defaultValue="A858R4574ADS"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>MMC Number</Label>
                                                                    <Input type="text" defaultValue="48678588121BID"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>NSR Number</Label>
                                                                    <Input type="text" defaultValue="NSR000031215478"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>University Code</Label>
                                                                    <Input type="text" defaultValue="UMPG875"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Programme Code</Label>
                                                                    <Input type="text" defaultValue="PGFM2154"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </div>
                                                <hr />

                                                <div className="top-section">
                                                    <h2><div>User Login Details</div></h2>
                                                    <div className="details-section">
                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee ePortfolio Email ID</Label>
                                                                    <InputGroup>
                                                                        <Input defaultValue="JohnnyDepp" />
                                                                        <InputGroupAddon addonType="append">
                                                                            <InputGroupText>@eportfolio.com</InputGroupText>
                                                                        </InputGroupAddon>
                                                                    </InputGroup>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Login Name</Label>
                                                                    <Input type="text" defaultValue="JohnyDepp"></Input>
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Tainee Login Password</Label>
                                                                    <Input type="text" defaultValue="UMPGFM2154"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Active From Date</Label>
                                                                    <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Active To Date</Label>
                                                                    <DatePicker className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                                </FormGroup>
                                                            </Col>

                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Trainee Active Flag</Label>
                                                                    <Input type="text" defaultValue="Flag 01"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Remarks</Label>
                                                                    <Input type="text" defaultValue="Enter Remarks"></Input>
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>

                                                        <Row className="sub-form-footer mt-3">
                                                            <button className="cancel-button">Cancel</button>&nbsp;<button className="blue-button">Create</button>
                                                        </Row>
                                                    </div>
                                                </div>
                                            </div>
                                        </TabPane>
                                        <TabPane tabId="2">
                                            <div className="maincontent mt-3">
                                                <div className="top-section">
                                                    <div className="details-section">
                                                        <Row className="mt-3">
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>Select User Role</Label>
                                                                    <Select

                                                                        options={this.roleOptions}
                                                                        placeholder="Select Role"
                                                                    />
                                                                </FormGroup>
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </div>
                                                <hr />
                                                <div className="top-section">
                                                    <h2>File Upload</h2>
                                                    <div className="details-section mt-3">
                                                        <Row>
                                                            <Col sm="6" className="upload-btn">
                                                                <FormGroup>
                                                                    <Label>Browse File</Label>
                                                                    <input type="file" id="actual-btn" hidden onChange={(e) => this.handleFileChange(e)} />
                                                                    <div id="blockele">
                                                                        <div className="d-flex flex-row" id="file-chosen"><div className="mr-2"><i className="ti-folder icon-folder"></i> </div><div className="fu-fileName">{this.state.fileName}</div></div>
                                                                        <label htmlFor="actual-btn" className="choose">Upload File</label>
                                                                    </div>
                                                                    <div className="fileuplod-note">* CSV File only, Max File size is 5MB</div>
                                                                </FormGroup>

                                                            </Col>
                                                        </Row>
                                                        <Row className="sub-form-footer mt-3">
                                                            <button className="cancel-button">Cancel</button>&nbsp;<button className="blue-button">Create</button>
                                                        </Row>
                                                    </div>
                                                </div>
                                            </div>
                                        </TabPane>
                                    </TabContent>
                                </div>
                            </div>
                        </Scrollbars>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(UserManagement1));