import React, { useContext, useRef } from 'react';
import { Row, Col, FormGroup, Label, Modal } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import { uploadMyDocumentsImageRequest, myDocumentsAddOrEditRequest } from '../../../../store/actions';
import { EOprationalActions, IUserDetails } from '../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { Formik, Form, Field, FieldArray, ErrorMessage } from 'formik';
import { defultContentValidate, MySelect, customContentValidation, getEnvironment } from '../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import uploadImg from '../../../../images/Upload.svg';
import EditIcon from '../../../../images/Edit.svg';
import replaceImg from '../../../../images/Replacefile.svg';
import { EDocStatus, EDocType } from '../../../../models/myDocumentsModel';
import Reject from '../../../../images/Reject.svg';
import pending from '../../../../images/Pending.svg';
import approved from '../../../../images/Approved.svg';
import { SuperParentContext } from '../container/myDocumentContext';
import isEqual from 'lodash/isEqual';
import ImagePreview from '../../../../pages/utilities/imagePreview';
// import Delete from '../../../../images/Delete.svg';
// import { PaginationComponent } from '../../../utilities/PaginationComponent';


const UploadTraineeDocumentsAction: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const context = useContext(SuperParentContext);
    let { current: deletedDoucments } = useRef([]) as any;
    // const pageSize = getEnvironment.pageSize;

    let validExtensions = ['jpg', 'jpeg', 'png'];

    const documentTypes: any[] = useSelector((state: any) => {
        if (state?.myDocumentsReducer?.documentsTypes)
            return state?.myDocumentsReducer?.documentsTypes;
        else return [];
    });
    console.log("Doc Types", documentTypes);

    // const actionType: number = useSelector((state: any) => {
    //     if (state?.myDocumentsReducer?.actionType)
    //         return state?.myDocumentsReducer?.actionType;
    //     else return EOprationalActions.UNSELECT;
    // });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state?.SessionState?.userDto;
        else return undefined;
    });

    const documentsInfo: any[] = useSelector((state: any) => {
        if (state?.myDocumentsReducer?.documentsData)
            return state?.myDocumentsReducer?.documentsData;
        else return [];
    });

    let documents = documentsInfo.length > 0 ? documentsInfo.map(x => ({
        ...x,
        extensions: 'yes',
        docType: documentTypes?.find(y => (y.docTypeId + '') === x.docTypeId)?.docType,
        docUniqueId: +(x.docId)
    })) : [];
    console.log('____documents', documents);

    let docTypes = documentTypes.filter(x => !x.docType?.isOptional)
    let foreignStdDocs = documentTypes.filter(x => x.docType?.isOptional && x.docType?.docName !== EDocType.OTHERS)

    const handleFileUploads = async (e, values, setFieldValue, setFieldTouched, fileNameLocation) => {
        let files: any = e?.target?.files;
        console.log("FileData==>", files);
        if (e?.target && files) {
            let filesData = Array.from(e?.target?.files);
            let fileNamesAndSizes = filesData?.reduce((acc: any[], file: any) => {
                let obj = { name: '', size: 0 };
                obj.name = file?.name?.split('.').pop();
                obj.size = file?.size / 1024 / 1024
                return [...acc, obj]
            }, []);
            if (fileNamesAndSizes.every(x => validExtensions.some(y => x.name === y)) && fileNamesAndSizes.every(x => x.size < 2)) {
                setFieldValue(`${fileNameLocation}.extensions`, fileNamesAndSizes);
                setFieldTouched(`${fileNameLocation}.extensions`, true);
                dispatch(uploadMyDocumentsImageRequest(files, setFieldValue, fileNameLocation));
            }
            else {
                setFieldValue(`${fileNameLocation}.extensions`, '');
                setFieldTouched(`${fileNameLocation}.extensions`, true);
            }
        }
    }

    const cancelTraineeDocumentsData = (resetForm) => {
        resetForm({
            values: {
                documents: documentsInfo?.length > 0 ? [...documents] : [...docTypes],
                isForeignStudent: documents?.length > 0 ? documents[0].isForeigner === true : false,
                actionData: '',
                actionType: '',
                currentPage: 0
            }
        });
    }

    const getFileName = data => data.map(x => x.fileName).join(', ');

    const editDocument = (values, setFieldValue, path, ind) => {
        setFieldValue('actionData', values.documents[ind]);
        setFieldValue('actionType', EOprationalActions.EDIT);
    }

    const addDocument = (setFieldValue) => {
        setFieldValue('actionType', EOprationalActions.ADD)
        setFieldValue('actionData', '')
    }

    // const deleteDocument = (remove, ind, documents) => {
    //     deletedDoucments.push(documents)
    //     remove(ind);
    // }

    const addForeignStdDocs = (isForeignStd, setFieldValue, values, foreignStdDocs) => {
        setFieldValue('isForeignStudent', isForeignStd);
        if (isForeignStd) {
            setFieldValue('documents', [...values?.documents, ...foreignStdDocs])
        }
        else {
            let nonForeignStdDocs = values?.documents?.filter(x => (!x.docType?.isOptional || x.docType?.docName === EDocType.OTHERS));
            setFieldValue('documents', nonForeignStdDocs)
        }
    }

    const viewDocument = (filePath, setFieldValue) => {
        setFieldValue('documentBase64url', filePath);
        // dispatch(setViewBase64Path(filePath, (documentBase64url) => setFieldValue('documentBase64url', documentBase64url)));
    }

    return (
        <>
            <div className='d-flex my-2 justify-content-between align-items-center'>
                <div>{t('UserProfileManagement.traineeName')}: <strong>{userDto?.userFullName}</strong> </div>
                <div>{t('UserProfileManagement.programName')}: <strong>{userDto?.program?.programName}</strong></div>
            </div>
            {
                <Formik
                    enableReinitialize
                    initialValues={{
                        documents: documents?.length > 0 ? [...documents] : [...docTypes],
                        actionData: '',
                        actionType: EOprationalActions.UNSELECT,
                        isForeignStudent: documents?.length > 0 ? documents[0].isForeigner === true : false,
                        currentPage: 0,
                        documentBase64url: ''
                    }}
                    validationSchema={Yup.object().shape({
                        isForeignStudent: customContentValidation(t, t('controleErrors.required')),
                        documents: Yup.array().of(
                            Yup.object().shape({
                                fileData: customContentValidation(t, t('controleErrors.required')),
                                extensions: customContentValidation(t, t('MyDocuments.invalidFileExtensions')),
                                docName: Yup.string().when('docType', {
                                    is: (docType) => docType?.docName === 'Others',
                                    then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 100, 1),
                                    otherwise: defultContentValidate('')
                                })
                            })
                        ),
                    })}

                    onSubmit={values => {
                        let actionType = documentsInfo?.length > 0 ? EOprationalActions.EDIT : EOprationalActions.ADD
                        dispatch(myDocumentsAddOrEditRequest(values.documents, actionType, deletedDoucments, values.isForeignStudent));
                        deletedDoucments = [];
                    }}
                >
                    {
                        ({ values, setFieldValue, setFieldTouched, errors, touched, resetForm }) => {

                            // let pagesCount: number = Math.ceil((values?.documents ? values?.documents?.length : 0) / pageSize);

                            // if (values.currentPage >= pagesCount && pagesCount !== 0)
                            //     setFieldValue('currentPage', 0);

                            // const handleClick = (e, index) => {
                            //     e.preventDefault();
                            //     console.log('_pagination_index', index);
                            //     setFieldValue('currentPage', index);
                            // };

                            return <>
                                {values.documentBase64url && <Modal className="modal-lg h-100 mcarousel" modalClassName="overflow-hidden" isOpen={true}>
                                    <div className="text-right p-2">
                                        <button onClick={() => setFieldValue('documentBase64url', '')} className="btn btn-danger">
                                            <i className="ti-close"></i>
                                        </button>
                                    </div>
                                    {values.documentBase64url && <ImagePreview path={values.documentBase64url} allowDownload={true} />}
                                </Modal>}
                                <Form className="flexLayout pr-0">
                                    <Row className="compHeading mt-2">
                                        <Col>
                                            <h3 className="page-header header-title">{t('MyDocuments.statutoryDocuments')}</h3>
                                        </Col>
                                        <div className="pr-4">
                                            <button type='button' className="addnewButn" onClick={() => addDocument(setFieldValue)}><i className="ti-plus"></i> {t('MyDocuments.addDocument')}</button>
                                        </div>
                                    </Row>
                                    {<div className="foreign-student mb-1">
                                        <span className='text-danger'>{t('MyDocuments.foreignStudent')}</span>
                                        <Field type='radio' value={true} disabled={documentsInfo.length > 0} onChange={() => addForeignStdDocs(true, setFieldValue, values, foreignStdDocs)} name='isForeignStudent' /><span>{t('ActionNames.yes')}</span>
                                        <Field type='radio' value={false} disabled={documentsInfo.length > 0} onChange={() => addForeignStdDocs(false, setFieldValue, values, foreignStdDocs)} name='isForeignStudent' /><span>{t('ActionNames.no')}</span>
                                        <ErrorMessage name='isForeignStudent' component='div' className='text-danger' />
                                    </div>}
                                    <div className="flexLayout">
                                        <div className="flexScroll">
                                            <div className="main-table">
                                                <div className="tbl-parent table-responsive">
                                                    <table className="myTable mydocumentsTable table">
                                                        <thead>
                                                            <tr>
                                                                <th>{t('MyDocuments.documentType')}</th>
                                                                <th>{t('MyDocuments.documentName')}</th>
                                                                <th>{t('MyDocuments.fileName')}</th>
                                                                {documentsInfo.length > 0 && <>
                                                                    <th className="column-center">{t('MyDocuments.approvalStatus')}</th>
                                                                    <th>{t('MyDocuments.approvalComments')}</th>
                                                                </>}
                                                                <th>{t('MyDocuments.actions')}</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {values.actionType === EOprationalActions.ADD ?
                                                                <context.addOrEditDocument
                                                                    docTypeOptions={documentTypes}
                                                                    actionData={values.actionData}
                                                                    setParentFieldValue={setFieldValue}
                                                                    parentValues={values}
                                                                    actionType={values.actionType}
                                                                    documentInfo={documentsInfo}
                                                                    viewDocument={viewDocument}
                                                                />
                                                                : <tr></tr>
                                                            }
                                                            <FieldArray
                                                                name='documents'
                                                            >
                                                                {
                                                                    ({ remove }) => {
                                                                        return <>
                                                                            {
                                                                                (values?.documents as any)?.map((x, ind) => {

                                                                                    // ?.slice((values.currentPage * pageSize), ((values.currentPage + 1) * pageSize))
                                                                                    // let ind = values?.documents?.findIndex(y => y.docUniqueId === x.docUniqueId);

                                                                                    const fileError = errors?.documents?.length && ((errors?.documents[ind] as any)?.fileData || '');
                                                                                    const fileTouched = touched.documents && ((touched?.documents[ind] as any)?.fileData || '');

                                                                                    const fileExtension = errors?.documents?.length && ((errors?.documents[ind] as any)?.extensions || '');
                                                                                    const ExtensionTouched = touched.documents && ((touched?.documents[ind] as any)?.extensions || '');

                                                                                    const docNameError = errors?.documents?.length && ((errors?.documents[ind] as any)?.docName || '');
                                                                                    const docNameTouched = touched.documents && ((touched?.documents[ind] as any)?.docName || '');

                                                                                    return <React.Fragment key={x.docUniqueId}>
                                                                                        {(values.actionType === EOprationalActions.EDIT && (values.actionData as any)?.docUniqueId === x.docUniqueId) ?
                                                                                            <context.addOrEditDocument
                                                                                                docTypeOptions={documentTypes}
                                                                                                actionData={values.actionData}
                                                                                                setParentFieldValue={setFieldValue}
                                                                                                parentValues={values}
                                                                                                actionType={values.actionType}
                                                                                                documentInfo={documentsInfo}
                                                                                                viewDocument={viewDocument}
                                                                                            /> :

                                                                                            <tr>
                                                                                                <td>
                                                                                                    {/* <FormGroup>
                                                                                                <MySelect
                                                                                                    name="documentType"
                                                                                                    isDisabled={true}
                                                                                                    placeholder={t('MyDocuments.selectDocument')}
                                                                                                    value={values?.documents[ind]?.docType ? values?.documents[ind].docType : ''}
                                                                                                    onChange={(e) => {
                                                                                                        setFieldValue(`documents.${ind}.docType`, e ? e : '');
                                                                                                    }}
                                                                                                    options={documentTypes ? documentTypes : []}
                                                                                                    getOptionLabel={option => option.docName}
                                                                                                    getOptionValue={option => option.docTypeId}
                                                                                                    onBlur={() => setFieldTouched('docType', true)}
                                                                                                    noOptionsMessage={() => 'NoDataFound'}
                                                                                                />
                                                                                            </FormGroup> */}
                                                                                                    <div className="text-muted">{x.docType?.docName}</div>
                                                                                                </td>
                                                                                                <td>
                                                                                                    <FormGroup>
                                                                                                        <Field type="text" disabled={true} name={`documents.${ind}.docName`} id="documentName"
                                                                                                            value={x.docName || '-'}
                                                                                                            className='form-control' placeholder={t('MyDocuments.documentName')} />
                                                                                                        {docNameError && docNameTouched && (
                                                                                                            <div className="text-danger">{docNameError}</div>
                                                                                                        )}
                                                                                                    </FormGroup>
                                                                                                </td>
                                                                                                {<td>
                                                                                                    <div>
                                                                                                        {getFileName(x.fileData) || ''}
                                                                                                    </div>
                                                                                                    {((documentsInfo?.length === 0)) ? <FormGroup>
                                                                                                        <div className='d-flex'>
                                                                                                            <Label htmlFor={`documents.${ind}`} className="btn btn-sm uploadFileText p-0"><img src={x.fileData?.length > 0 ? (replaceImg) : (uploadImg)} alt="uploadImg" />{x.fileData?.length > 0 ? t('MyDocuments.replaceFile') : t('MyDocuments.uploadFile')}</Label>
                                                                                                            <input type="file" id={`documents.${ind}`} name={`documents.${ind}.fileData`} onChange={(e) => handleFileUploads(e, values, setFieldValue, setFieldTouched, `documents.${ind}`)} style={{ display: 'none' }} />
                                                                                                        </div>
                                                                                                        {(fileError && fileTouched) && <div className="text-danger">{fileError}</div>}
                                                                                                        {(fileExtension && ExtensionTouched) && <div className="text-danger small">{fileExtension}</div>}
                                                                                                    </FormGroup> : ''}
                                                                                                    {x.fileData?.[0]?.filePath && <span className="fileName pointer" onClick={() => viewDocument(x.fileData?.[0]?.filePath, setFieldValue)}>{t('ActionNames.view')}</span>}
                                                                                                </td>}
                                                                                                {documentsInfo.length > 0 && <>
                                                                                                    <td className="column-center">
                                                                                                        {
                                                                                                            x.approvalStatus === EDocStatus.APPROVED ? <img src={approved} alt="" className="icon"></img> :
                                                                                                                x.approvalStatus === EDocStatus.REJECTED ? <img src={Reject} alt="rejectLogo" /> : x.approvalStatus === EDocStatus.PENDING ? <img src={pending} alt="pending" className="icon"></img> : '-'
                                                                                                        }
                                                                                                    </td>
                                                                                                    <td>
                                                                                                        {x.approvalComments || 'N/A'}
                                                                                                    </td>
                                                                                                </>}
                                                                                                <td>
                                                                                                    {((x.approvalStatus === EDocStatus.REJECTED) && documentsInfo?.length > 0) && <span onClick={() => editDocument(values, setFieldValue, `documents.${ind}`, ind)}><img src={EditIcon} alt="editIcon" className="actionicon pointer mr-2"></img></span>}

                                                                                                    {/* {(values.documents[ind]?.docType?.docName === EDocType.OTHERS && (values.documents[ind]?.approvalStatus !== EDocStatus.APPROVED)) &&
                                                                                                <img src={Delete} onClick={() => deleteDocument(remove, ind, x)} alt="" className="actionicon pointer"></img>} */}
                                                                                                </td>
                                                                                            </tr>
                                                                                        }
                                                                                    </React.Fragment>
                                                                                })
                                                                            }
                                                                        </>
                                                                    }

                                                                }
                                                            </FieldArray>
                                                        </tbody>
                                                    </table>
                                                    {/* {(values?.documents?.length > pageSize) &&
                                                    <div className="pagination">
                                                        <PaginationComponent currentPage={values.currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                                                    </div>
                                                } */}
                                                </div>
                                            </div>
                                        </div>
                                        {documentTypes.length > 0 && <div className="text-right mr-2 mb-2 pt-3">
                                            <button type="button" className="btn cancel-button mr-2" disabled={(isEqual(values.documents, documents))} onClick={() => cancelTraineeDocumentsData(resetForm)}>{t('ActionNames.cancel')}</button>
                                            <button type="submit" className="btn blue-button" disabled={(isEqual(values.documents, documents))}>{t('MyDocuments.submitForApprvl')}</button>
                                        </div>}
                                    </div>
                                </Form>
                            </>
                        }
                    }

                </Formik>
            }
        </>
    )
}

export default React.memo(UploadTraineeDocumentsAction);
