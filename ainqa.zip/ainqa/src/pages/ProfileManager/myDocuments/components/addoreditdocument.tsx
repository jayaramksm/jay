import React from 'react';
import { FormGroup, Label } from 'reactstrap';
import { defultContentValidate, MySelect, customContentValidation } from '../../../../helpers/helpersIndex';
import { Formik, Field } from 'formik';
import uploadImg from '../../../../images/Upload.svg';
import replaceImg from '../../../../images/Replacefile.svg';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import { uploadMyDocumentsImageRequest } from '../../../../store/actions';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import * as Yup from 'yup';
import { EDocStatus, EDocType } from '../../../../models/myDocumentsModel';
import maxBy from 'lodash/maxBy';

interface IProps {
    actionData: any;
    actionType?: any;
    docTypeOptions?: any;
    setParentFieldValue: any;
    parentValues: any;
    documentInfo: any;
    viewDocument: any;
}

const AddOrEditDocument: React.FC<IProps> = (props) => {

    const { actionData, actionType, docTypeOptions, setParentFieldValue, parentValues, documentInfo, viewDocument } = props;

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    let validExtensions = ['jpg', 'jpeg', 'png'];

    const handleFileUploads = async (e, values, setFieldValue, setFieldTouched, fileNameLocation) => {
        let files: any = e?.target?.files;
        console.log("FileData==>", files);
        if (e?.target && files) {
            let filesData = Array.from(e?.target?.files);
            let fileNamesAndSizes = filesData?.reduce((acc: any[], file: any) => {
                let obj = { name: '', size: 0 };
                obj.name = file?.name?.split('.').pop();
                obj.size = file?.size / 1024 / 1024
                return [...acc, obj]
            }, []);
            console.log('fileNamesAndSizes=>', fileNamesAndSizes);
            if (fileNamesAndSizes.every(x => validExtensions.some(y => x.name === y)) && fileNamesAndSizes.every(x => x.size < 2)) {
                setFieldValue(`extensions`, fileNamesAndSizes);
                setFieldTouched(`extensions`, true);
                dispatch(uploadMyDocumentsImageRequest(files, setFieldValue, fileNameLocation));
            }
            else {
                await setFieldValue(`extensions`, '');
                await setFieldTouched(`extensions`, true);
            }
        }
    }

    const getFileName = data => data?.map(x => x.fileName).join(', ');

    const handleEdit = (values, submitForm, isValid) => {
        console.log('isValidData===>', isValid, values.fileData?.length > 0);
        submitForm();
        if ((values.fileData?.length > 0) && isValid) {

            let originalDocments = parentValues?.documents;
            if (actionType === EOprationalActions.EDIT) {
                let doc = {
                    ...actionData,
                    approvalStatus: EDocStatus.PENDING,
                    approvalComments: '',
                    docName: values.docName,
                    fileData: values.fileData,
                }

                let index = originalDocments?.findIndex(x => x.docId === actionData?.docId);
                if (index !== -1) {
                    originalDocments.splice(index, 1, doc);
                    setParentFieldValue('documents', originalDocments);
                    setParentFieldValue('actionData', '');
                    setParentFieldValue('actionType', '');

                }
            } else {
                console.log('docIdValuesFromOther', maxBy(originalDocments, 'docUniqueId'), maxBy(originalDocments, 'docUniqueId')?.docUniqueId + 1)
                let newDoc = {
                    ...values,
                    approvalStatus: '',
                    docUniqueId: maxBy(originalDocments, 'docUniqueId')?.docUniqueId + 1
                }
                originalDocments.unshift(newDoc);
                setParentFieldValue('actionType', '');
            }
        }
    }

    const handleCancel = (resetForm) => {
        setParentFieldValue('actionType', '');
        setParentFieldValue('actionData', '');
        resetForm();
    }

    return (
        <>
            <Formik
                enableReinitialize
                initialValues={{
                    docType: actionData?.docType ?? { docName: 'Other', docTypeId: 9 },
                    docName: actionData?.docName ?? '',
                    fileData: actionData?.fileData ?? [],
                    extensions: 'yes',
                }}
                validationSchema={Yup.object().shape({
                    docName: Yup.string().when('docType', {
                        is: (docType) => docType?.docName === EDocType.OTHERS,
                        then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 100, 1),
                        otherwise: defultContentValidate('')
                    }),
                    fileData: customContentValidation(t, t('controleErrors.required')),
                    extensions: customContentValidation(t, t('MyDocuments.invalidFileExtensions'))
                })}
                onSubmit={values => {
                    console.log('onSubmit==>', values)
                }}
            >
                {
                    ({ values, setFieldValue, setFieldTouched, dirty, errors, touched, submitForm, resetForm, isValid }) => {
                        return <tr>
                            <td>
                                {/* <FormGroup>
                                    <MySelect
                                        name="documentType"
                                        isDisabled={true}
                                        placeholder={t('MyDocuments.selectDocument')}
                                        value={values.docType ? values.docType : ''}
                                        onChange={(e) => {
                                            setFieldValue('docType', e ? e : '')
                                        }}
                                        options={docTypeOptions || []}
                                        getOptionLabel={option => option.docName}
                                        getOptionValue={option => option.docTypeId}
                                        onBlur={() => { }}
                                        noOptionsMessage={() => 'NoDataFound'}
                                    />
                                </FormGroup> */}
                                <div className="text-muted">{values.docType?.docName}</div>
                            </td>
                            <td>
                                <FormGroup>
                                    <Field type="text"
                                        id="documentName"
                                        name='docName'
                                        className='form-control'
                                        placeholder={t('MyDocuments.documentName')}
                                        disabled={values.docType?.docName !== "Other"}
                                    />
                                </FormGroup>
                                {errors.docName && touched.docName && <div className='text-danger'>{errors.docName}</div>}
                            </td>
                            {<td>
                                <div>
                                    {getFileName(values.fileData) || ''}
                                </div>
                                {<FormGroup>
                                    <div className='d-flex'>
                                        <Label htmlFor='doc' className="btn btn-sm uploadFileText p-0"><img src={values.fileData?.length > 0 ? (replaceImg) : (uploadImg)} alt="uploadImg" />{values.fileData?.length > 0 ? t('MyDocuments.replaceFile') : t('MyDocuments.uploadFile')}</Label>
                                        <input type="file" id='doc' name='docName' onChange={(e) => { handleFileUploads(e, values, setFieldValue, setFieldTouched, null) }} style={{ display: 'none' }} />
                                    </div>
                                </FormGroup>}
                                {values.fileData?.[0]?.filePath && <span className="fileName pointer" onClick={() => viewDocument(values.fileData?.[0]?.filePath, setParentFieldValue)}>{t('ActionNames.view')}</span>}
                                {errors.fileData && touched.fileData && <div className='text-danger'>{errors.fileData}</div>}
                                {(errors.extensions && touched.extensions) && <div className='text-danger small'>{errors.extensions}</div>}
                            </td>}
                            {documentInfo?.length > 0 && <>
                                <td></td>
                                <td></td>
                            </>}
                            <td>
                                <button type='button' disabled={!dirty} className='btn blue-button' onClick={() => handleEdit(values, submitForm, isValid)}>{t('ActionNames.save')}</button>
                                <button type='button' className='btn icon-btn ml-2' onClick={() => handleCancel(resetForm)}><i className="icon-Close"></i></button>
                            </td>
                        </tr>
                    }
                }

            </Formik>

        </>
    )
}

export default React.memo(AddOrEditDocument);