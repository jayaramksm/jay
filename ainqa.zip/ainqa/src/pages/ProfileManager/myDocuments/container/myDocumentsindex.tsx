export { default as UploadTraineeDocumentsAction } from '../components/uploadtraineedocumentsaction';
export { default as AddOrEditDocument } from '../components/addoreditdocument';