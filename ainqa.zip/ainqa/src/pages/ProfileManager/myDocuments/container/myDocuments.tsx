import React, { Component } from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, cancelAllPendingMyDocumentsRequests, setResetMyDocumentsStateRequest, getAllDocumentsandDocumentTypesRequest } from '../../../../store/actions';
import { AddOrEditDocument, UploadTraineeDocumentsAction } from './myDocumentsindex';
import { SuperParentContext } from '../container/myDocumentContext';

interface IProps {
    activateAuthLayout: any;
    cancelAllPendingMyDocumentsRequests: any;
    setResetMyDocumentsStateRequest: any;
    getAllDocumentsandDocumentTypesRequest: any;
}

class MyDocuments extends Component<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            manager: {
                actionComponent: UploadTraineeDocumentsAction,
                addOrEditDocument: AddOrEditDocument
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getAllDocumentsandDocumentTypesRequest();
    }

    componentWillUnmount() {
        this.props.setResetMyDocumentsStateRequest();
        this.props.cancelAllPendingMyDocumentsRequests();
    }

    render() {
        return (
            <React.Fragment>
                <SuperParentContext.Provider value={this.state.manager}>
                    <UploadTraineeDocumentsAction />
                </SuperParentContext.Provider>
            </React.Fragment>
        )
    }
}

export default connect(null, { activateAuthLayout, cancelAllPendingMyDocumentsRequests, setResetMyDocumentsStateRequest, getAllDocumentsandDocumentTypesRequest })(MyDocuments);
