import React, { useState, useContext } from 'react';
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap';
import { SuperParentContext } from '../Container/userprofilecontext';
import { useTranslation } from 'react-i18next';

const TraineeProfileManager: React.FC = () => {

    const [activeTab, setActiveTab] = useState("1");
    const context: any = useContext(SuperParentContext);
    const { t } = useTranslation('translations');

    return (
        <div className="maincontent uploadTabs flexLayout pr-0">
            <Nav tabs>
                <NavItem>
                    <NavLink
                        className={'pointer ' + (activeTab == "1" ? 'active' : '')}
                        onClick={() => { setActiveTab("1") }}
                    >
                        {t('UserProfileManagement.traineeDetails')}
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink
                        className={'pointer ' + (activeTab == "2" ? 'active' : '')}
                        onClick={() => { setActiveTab("2") }}
                    >
                        {t('UserProfileManagement.mydocuments')}
                    </NavLink>
                </NavItem>
            </Nav>

            <TabContent activeTab={activeTab} className="flexLayout pr-0">
                {activeTab == "1" && <TabPane tabId="1" className="flexLayout pr-0">
                    <context.userProfileAction />
                </TabPane>}
                {activeTab == "2" && <TabPane tabId="2" className="flexLayout pr-0">
                    <context.traineeDocuments />
                </TabPane>
                }
            </TabContent>
        </div>
    )
}

export default React.memo(TraineeProfileManager);