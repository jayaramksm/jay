import React from 'react';
import { Row, Col, Input, FormGroup, Label, InputGroup, } from 'reactstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useTranslation } from 'react-i18next';
import { defultContentValidate, emailContentValidate, MySelect, customContentValidation, getRoleCode, getModifiedDate } from '../../../helpers/helpersIndex';
import { useDispatch, useSelector } from 'react-redux';
import { EOprationalActions, ERoleDesc, EStatusEnum, IUserDetails } from '../../../models/utilitiesModel';
import { setUserProfileManagementAction, updateUserProfileRequest } from '../../../store/actions';
import * as Yup from 'yup';
import { IUserProfileDetails } from '../../../models/userProfileManagementModel';

const UserProfileAction: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const userProfileData: IUserProfileDetails = useSelector((state: any) => {
        if (state?.userProfileManagementReducer?.userProfileData)
            return state?.userProfileManagementReducer?.userProfileData;
        else return undefined;
    });

    const base64ProfilePath: any = useSelector((state: any) => {
        if (state?.Layout?.profileBase64logoPath)
            return state.Layout.profileBase64logoPath;
        else return undefined;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state?.SessionState?.userDto;
        else return undefined;
    });

    const actionType: number = useSelector((state: any) => {
        if (state?.userProfileManagementReducer?.actionType)
            return state?.userProfileManagementReducer?.actionType;
        else return EOprationalActions.SELECT;
    });

    const countryOptions = [
        { value: 'MYS', label: 'Malaysia' },
        { value: 'IND', label: 'India' },
        { value: 'IDN', label: 'Indonesia' }
    ];
    const genderOptions = [
        { value: 'M', label: 'male' },
        { value: 'F', label: 'female' },
        { value: 'T', label: 'transgender' }
    ];

    console.log('userProfileActionData===>', { userDto, userProfileData });

    let userStatus = userProfileData?.isActive === EStatusEnum.NACTIVE ? t('ActionNames.active') : t('ActionNames.inactive');
    let gender = genderOptions.find(x => x.value === userProfileData?.gender)?.label;
    let permanentCountry = countryOptions.find(x => x.value === userProfileData?.correspondentCountry);
    let residentialCountry = countryOptions.find(x => x.value === userProfileData?.residentialCountry);
    let isSameAddress = !!(userProfileData?.isSameAddress);

    let isTrainee = getRoleCode() === ERoleDesc.Traninee;
    let isDisabled = actionType !== EOprationalActions.EDIT;
    let idType = getRoleCode() === ERoleDesc.Traninee ? 'icNumber' : getRoleCode() === ERoleDesc.MOHSUPERVISOR ? 'mohId' : 'employeeId'

    const initialValues = () => ({
        programName: userDto?.program?.programName || '',
        roles: userProfileData?.userType || '',
        userFullName: userProfileData?.userFullName || '',
        dateofBirth: userProfileData?.dob ? getModifiedDate(userProfileData?.dob, false) : '',
        gender: gender || '',
        mobileno1: userProfileData?.mobileno1 || '',
        mobileno2: userProfileData?.mobileno2 || '',
        emailId: userProfileData?.personalEmailId || '',
        eportfolioEmailId: userProfileData?.eportfolioEmailId || '',
        permanentAddress: userProfileData?.correspondentAddress || '',
        permanentAddressCountry: permanentCountry || '',
        residentialAddress: userProfileData?.residentialAddress || '',
        residentialAddressCountry: residentialCountry || '',
        legacyCode: userProfileData?.trainee?.trLegacyCode || 'N/A',
        [idType]: userProfileData?.trainee?.trIcNo || userProfileData?.employeeId || userProfileData?.mohId || '',
        anmno: userProfileData?.trainee?.anmno || '',
        mmcno: userProfileData?.mmcno || 'N/A',
        nsrno: userProfileData?.trainee?.nsrno || 'N/A',
        userStatus: userProfileData ? userStatus : '',
        resourceCode: userProfileData?.resourceCode || 'N/A',
        isResidentialAddressSameAsPermanentAddress: isSameAddress || '',
        universityName: (userProfileData?.universityId === userDto?.university?.universityId) ? userDto?.university?.universityName : '',
        designation: userProfileData?.designation || 'N/A',

        profileData: '',
        validationError: '',
        profilePreviewUrl: '',
        profilePreviewUrlOld: userProfileData?.profileUrl || ''
    });

    const validationSchema = Yup.object().shape({

        residentialAddress: Yup.string().when('roles', {
            is: (selectedRoleCode) => (selectedRoleCode !== ERoleDesc.UNIVERSITYADMIN && selectedRoleCode !== ERoleDesc.PLATFORMADMIN),
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: '' }, 250, 4),
            otherwise: defultContentValidate('')
        }),
        residentialAddressCountry: Yup.string().when('roles', {
            is: (selectedRoleCode) => (selectedRoleCode !== ERoleDesc.UNIVERSITYADMIN && selectedRoleCode !== ERoleDesc.PLATFORMADMIN),
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        permanentAddress: Yup.string().when('roles', {
            is: (selectedRoleCode) => (selectedRoleCode !== ERoleDesc.UNIVERSITYADMIN && selectedRoleCode !== ERoleDesc.PLATFORMADMIN),
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: '' }, 250, 4),
            otherwise: defultContentValidate('')
        }),
        permanentAddressCountry: Yup.string().when('roles', {
            is: (selectedRoleCode) => (selectedRoleCode !== ERoleDesc.UNIVERSITYADMIN && selectedRoleCode !== ERoleDesc.PLATFORMADMIN),
            then: defultContentValidate(t('controleErrors.required')),
            otherwise: defultContentValidate('')
        }),
        mobileno1: Yup.string().when('roles', {
            is: (selectedRoleCode) => selectedRoleCode !== ERoleDesc.UNIVERSITYADMIN,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1)
        }),
        mobileno2: Yup.string().when('roles', {
            is: (selectedRoleCode) => selectedRoleCode !== ERoleDesc.UNIVERSITYADMIN,
            then: Yup.lazy((value) => {
                if (value !== undefined)
                    return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1);
                else return defultContentValidate('');
            }),
            otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: '' }, 50, 1)
        }),
        emailId: Yup.string().when('roles', {
            is: (selectedRoleCode) => selectedRoleCode !== ERoleDesc.PLATFORMADMIN,
            then: emailContentValidate(t('controleErrors.required'), { value: 6, message: t('controleErrors.min').replace('{min}', '6') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
            otherwise: defultContentValidate('')
        }),
    })
    console.log('roleData=>', getRoleCode())
    const handleUserProfileEdit = () => {
        dispatch(setUserProfileManagementAction(EOprationalActions.EDIT));
    }

    const cancelProfileUpdate = async (values, setFieldValue, resetForm) => {
        setFieldValue('mobileno1', userProfileData?.mobileno1 ?? '');
        setFieldValue('mobileno2', userProfileData?.mobileno2 ?? '');
        setFieldValue('emailId', userProfileData?.personalEmailId ?? '');
        setFieldValue('permanentAddress', userProfileData?.correspondentAddress ?? '');
        setFieldValue('permanentAddressCountry', permanentCountry ?? '');
        setFieldValue('isResidentialAddressSameAsPermanentAddress', isSameAddress ?? '');
        setFieldValue('profilePreviewUrl', userProfileData.profileUrl ?? '');
        await setFieldValue('residentialAddress', userProfileData?.residentialAddress ?? '');
        setFieldValue('residentialAddressCountry', residentialCountry ?? '');
        setFieldValue('profileData', '');
        resetForm();
        dispatch(setUserProfileManagementAction(EOprationalActions.SELECT));
    }

    const handleCheckBox = async (e, setFieldValue, values) => {
        setFieldValue('isResidentialAddressSameAsPermanentAddress', e?.target?.checked);
        if (e?.target?.checked) {
            await setFieldValue('residentialAddress', values?.permanentAddress);
            setFieldValue('residentialAddressCountry', values?.permanentAddressCountry);
        }
        else {
            setFieldValue('residentialAddress', '');
            setFieldValue('residentialAddressCountry', '');
        }
    }

    const handlePermanentAddress = (values, setFieldValue, setFieldTouched) => {
        setFieldTouched('permanentAddress', true);
        if (values?.isResidentialAddressSameAsPermanentAddress)
            setFieldValue('residentialAddress', values?.permanentAddress);
    }
    const handlePermanentCountry = (values, setFieldValue, setFieldTouched) => {
        setFieldTouched('permanentAddressCountry', true);
        if (values?.isResidentialAddressSameAsPermanentAddress)
            setFieldValue('residentialAddressCountry', values?.permanentAddressCountry);
    }

    const handleProfilePhoto = (e, setFieldValue) => {
        let file: File = e?.target?.files[0]
        if (file) {
            console.log('fileImage', e?.target?.files)
            console.log('profileimageData===>', e.target.files[0]);
            let extension = file?.name.split('.').pop();
            if (extension === 'jpg' || extension === 'jpeg' || extension === 'png') {
                let logoUrl = URL.createObjectURL(file);
                console.log('urlImage==>', logoUrl);

                setFieldValue('profileData', file);
                setFieldValue('profilePreviewUrl', logoUrl);
                setFieldValue('validationError', '');
            }
            else
                setFieldValue('validationError', t('UserProfileManagement.invalidImageFileExtension'));
        }
    }

    return (
        <React.Fragment>
            <Formik
                enableReinitialize
                initialValues={initialValues()}
                validationSchema={validationSchema}
                onSubmit={(values) => {
                    console.log('submitedValue==>', values)
                    dispatch(updateUserProfileRequest(values, values.profileData))
                }}
            >
                {
                    ({ values, setFieldValue, setFieldTouched, dirty, errors, touched, resetForm }) => {
                        const isSameAddress = !!(values.isResidentialAddressSameAsPermanentAddress);
                        return <Form className="flexLayout maincontent">
                            <Row className="align-items-center">
                                <Col><h6>{t('UserProfileManagement.profileDetails')}</h6></Col>
                                {isDisabled && <Col className="text-right">
                                    <button type='button' className='btn blue-button my-2' onClick={handleUserProfileEdit}><i className="ti-pencil-alt"></i> Edit Profile</button>
                                </Col>}
                            </Row>
                            <div className="flexScroll">

                                <div className="top-section">
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="8">
                                                <Row>
                                                    {getRoleCode() === ERoleDesc.PROGRAMCOORDINATOR && <Col sm="6">
                                                        <FormGroup>
                                                            <Label>{t('UserProfileManagement.programName')}</Label>
                                                            <Field placeholder={t('UserProfileManagement.programName')} disabled name="programName" className={'form-control ' + (errors.programName && touched.programName ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="programName" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>}
                                                    <Col sm="6">
                                                        <FormGroup>
                                                            <Label>{t('UserProfileManagement.userFullName')}</Label>
                                                            <Field placeholder={t('UserProfileManagement.userFullName')} disabled name="userFullName" className={'form-control ' + (errors.userFullName && touched.userFullName ? 'is-invalid' : '')} />
                                                            <ErrorMessage name="userFullName" component="div" className="invalid-feedback" />
                                                        </FormGroup>
                                                    </Col>
                                                    {getRoleCode() === ERoleDesc.UNIVERSITYADMIN && <>
                                                        <Col sm="6">
                                                            <FormGroup>
                                                                <Label>{t('UserProfileManagement.universityName')}</Label>
                                                                <Field placeholder={t('UserProfileManagement.universityName')} name="universityName" disabled className={'form-control ' + (errors.universityName && touched.universityName ? 'is-invalid' : '')} />
                                                                <ErrorMessage name="universityName" component="div" className="invalid-feedback" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6">
                                                            <FormGroup>
                                                                <Label>{t('UserProfileManagement.designation')}</Label>
                                                                <Field placeholder={t('UserProfileManagement.designation')} name="designation" disabled className={'form-control ' + (errors.designation && touched.designation ? 'is-invalid' : '')} />
                                                                <ErrorMessage name="designation" component="div" className="invalid-feedback" />
                                                            </FormGroup>
                                                        </Col>
                                                    </>}

                                                    {(getRoleCode() !== ERoleDesc.UNIVERSITYADMIN && getRoleCode() !== ERoleDesc.PLATFORMADMIN) && <>
                                                        <Col sm="6">
                                                            <FormGroup>
                                                                <Label>{t('UserProfileManagement.dob')}</Label>
                                                                <Field placeholder={t('UserProfileManagement.dob')} name="dateofBirth" disabled className={'form-control ' + (errors.dateofBirth && touched.dateofBirth ? 'is-invalid' : '')} />
                                                                <ErrorMessage name="dateofBirth" component="div" className="invalid-feedback" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6">
                                                            <FormGroup>
                                                                <Label>{t('UserProfileManagement.gender')}</Label>
                                                                <Field name="gender" placeholder={t('UserProfileManagement.gender')} disabled className={'form-control ' + (errors.gender && touched.gender ? 'is-invalid' : '')} />
                                                                <ErrorMessage name="gender" component="div" className="invalid-feedback" />

                                                            </FormGroup>
                                                        </Col>
                                                    </>}
                                                </Row>
                                            </Col>

                                            <Col sm="4">
                                                {actionType === EOprationalActions.EDIT &&
                                                    <FormGroup>
                                                        <Label>{t('UserProfileManagement.profilePicture')}</Label>
                                                        <div className="profile-pic">
                                                            <div className="profile-image">
                                                                {console.log("base64ProfilePath=>", base64ProfilePath, values.profilePreviewUrl)
                                                                }
                                                                {!values.profilePreviewUrl && <> {(base64ProfilePath !== 'data:' && (values.profilePreviewUrlOld || base64ProfilePath)) && <img src={base64ProfilePath || values.profilePreviewUrlOld} alt="ProfilePhoto" style={{ width: "70px", height: "70px", margin: "10px" }} />}</>}
                                                                {values.profilePreviewUrl && <img src={values.profilePreviewUrl} alt="ProfilePhoto" style={{ width: "70px", height: "70px", margin: "10px" }} />}
                                                            </div>
                                                            <Label for="uploadPicture"><div className="btn blue-button">{t('UserProfileManagement.uploadNewPhoto')}</div></Label>
                                                            <input type='file' id="uploadPicture" hidden onChange={(e) => handleProfilePhoto(e, setFieldValue)} />
                                                        </div>
                                                        <div className='text-danger'>{values.validationError}</div>
                                                    </FormGroup>
                                                }
                                            </Col>
                                        </Row>
                                    </div>
                                </div>

                                <div className="top-section">
                                    <h2><div>{t('UserProfileManagement.userContactDetails')}</div></h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.contact1')}</Label>
                                                    <InputGroup className="disabled-item">
                                                        <Field placeholder={t('UserProfileManagement.contact1')} name="mobileno1" disabled={isDisabled} className={'form-control ' + (errors.mobileno1 && touched.mobileno1 ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="mobileno1" component="div" className="invalid-feedback" />
                                                    </InputGroup>
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.contact2')}</Label>
                                                    <InputGroup className="disabled-item">
                                                        {!values.mobileno2 && actionType !== EOprationalActions.EDIT ? <Field placeholder={t('UserProfileManagement.contact2')} disabled={true} value="N/A" className={'form-control ' + (errors.mobileno2 && touched.mobileno2 ? 'is-invalid' : '')} /> : <Field placeholder={t('UserProfileManagement.contact2')} name="mobileno2" disabled={isDisabled} value={values.mobileno2} className={'form-control ' + (errors.mobileno2 && touched.mobileno2 ? 'is-invalid' : '')} />}
                                                        <ErrorMessage name="mobileno2" component="div" className="invalid-feedback" />
                                                    </InputGroup>
                                                </FormGroup>
                                            </Col>
                                            {getRoleCode() !== ERoleDesc.PLATFORMADMIN && <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.emailID')}</Label>
                                                    <InputGroup className="disabled-item">
                                                        <Field placeholder={t('UserProfileManagement.emailID')} name="emailId" disabled={isDisabled} className={'form-control ' + (errors.emailId && touched.emailId ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="emailId" component="div" className="invalid-feedback" />
                                                    </InputGroup>
                                                </FormGroup>
                                            </Col>}
                                        </Row>
                                    </div>
                                </div>

                                {(getRoleCode() !== ERoleDesc.UNIVERSITYADMIN && getRoleCode() !== ERoleDesc.PLATFORMADMIN) && <div className="top-section">
                                    <h2><div>{t('UserProfileManagement.userAddressDetails')}</div></h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('UserProfileManagement.permanentAddress')}</Label>
                                                    <InputGroup className="disabled-item">
                                                        <Field placeholder={t('UserProfileManagement.permanentAddress')} name="permanentAddress" onBlur={() => handlePermanentAddress(values, setFieldValue, setFieldTouched)} disabled={isDisabled} className={'form-control ' + (errors.permanentAddress && touched.permanentAddress ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="permanentAddress" component="div" className="invalid-feedback" />

                                                    </InputGroup>
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.country')}</Label>
                                                    <MySelect
                                                        name="permenentCountry"
                                                        placeholder={t('UserProfileManagement.selectCountry')}
                                                        value={values.permanentAddressCountry ? values.permanentAddressCountry : ''}
                                                        isDisabled={isDisabled}
                                                        options={countryOptions}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onChange={(e) => setFieldValue('permanentAddressCountry', e ? e : '')}
                                                        onBlur={() => handlePermanentCountry(values, setFieldValue, setFieldTouched)}
                                                        noOptionsMessage={() => 'NoDataFound'}
                                                    />
                                                    {errors.permanentAddressCountry && touched.permanentAddressCountry && (
                                                        <div className="text-danger">{errors.permanentAddressCountry}</div>
                                                    )}

                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('UserProfileManagement.residentialAddress')}</Label>
                                                    <FormGroup check>
                                                        <Label check>
                                                            <Input type="checkbox" disabled={isDisabled} onChange={(e) => handleCheckBox(e, setFieldValue, values)} checked={values.isResidentialAddressSameAsPermanentAddress} />{' '} {t('UserProfileManagement.sameAsPermanentAddress')}
                                                        </Label>
                                                    </FormGroup>
                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('UserProfileManagement.residentialAddress')}</Label>
                                                    <InputGroup className="disabled-item">
                                                        <Field placeholder={t('UserProfileManagement.residentialAddress')} name="residentialAddress" disabled={isDisabled || isSameAddress} className={'form-control ' + (errors.residentialAddress && touched.residentialAddress ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="residentialAddress" component="div" className="invalid-feedback" />
                                                    </InputGroup>
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.country')}</Label>
                                                    <MySelect
                                                        name="residentialAddressCountry"
                                                        placeholder={t('UserProfileManagement.selectCountry')}
                                                        options={countryOptions}
                                                        value={values.residentialAddressCountry ? values.residentialAddressCountry : ''}
                                                        isDisabled={isDisabled || isSameAddress}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onChange={(e) => setFieldValue('residentialAddressCountry', e ? e : '')}
                                                        onBlur={() => setFieldTouched('residentialAddressCountry', true)}
                                                        noOptionsMessage={() => 'NoDataFound'}
                                                    />
                                                    {errors.residentialAddressCountry && touched.residentialAddressCountry && (
                                                        <div className="text-danger">{errors.residentialAddressCountry}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>}

                                <div className="top-section">
                                    <h2><div>{t('UserProfileManagement.umDetails')}</div></h2>
                                    <div className="details-section">
                                        {(getRoleCode() !== ERoleDesc.UNIVERSITYADMIN && getRoleCode() !== ERoleDesc.PLATFORMADMIN) && <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t(`UserProfileManagement.${idType}`)}</Label>
                                                    <Field placeholder={t(`UserProfileManagement.${idType}`)} name={idType} disabled className={'form-control ' + (errors.mmcno && touched.mmcno ? 'is-invalid' : '')} />
                                                    <ErrorMessage name={idType} component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.mmcNumber')}</Label>
                                                    <Field placeholder={t('UserProfileManagement.mmcNumber')} name="mmcno" disabled className={'form-control ' + (errors.mmcno && touched.mmcno ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="mmcno" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>

                                            {/* <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.resourceCode')}</Label>
                                                    <Field placeholder={t('UserProfileManagement.resourceCode')} name="resourceCode" disabled className={'form-control ' + (errors.resourceCode && touched.resourceCode ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="resourceCode" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col> */}
                                        </Row>}
                                        {isTrainee && <>
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('UserProfileManagement.legacyCode')}</Label>
                                                        <Field placeholder={t('UserProfileManagement.legacyCode')} name="legacyCode" disabled className={'form-control ' + (errors.legacyCode && touched.legacyCode ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="legacyCode" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('UserProfileManagement.ammNumber')}</Label>
                                                        <Field placeholder={t('UserProfileManagement.ammNumber')} name="anmno" disabled className={'form-control ' + (errors.anmno && touched.anmno ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="anmno" component="div" className="invalid-feedback" />

                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('UserProfileManagement.nsrNumber')}</Label>
                                                        <Field placeholder={t('UserProfileManagement.nsrNumber')} name="nsrno" disabled className={'form-control ' + (errors.nsrno && touched.nsrno ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="nsrno" component="div" className="invalid-feedback" />

                                                    </FormGroup>
                                                </Col>
                                                {/* <Col sm="4">
                                                                    <FormGroup>
                                                                        <Label>{t('UserProfileManagement.icNumber')}</Label>
                                                                        <Field placeholder={t('UserProfileManagement.icNumber')} name="trIcNo" disabled className={'form-control ' + (errors.trIcNo && touched.trIcNo ? 'is-invalid' : '')} />
                                                                        <ErrorMessage name="trIcNo" component="div" className="invalid-feedback" />
                                                                    </FormGroup>
                                                                </Col> */}
                                            </Row>
                                        </>}

                                        <Row className="mt-3">
                                            {getRoleCode() === ERoleDesc.UNIVERSITYADMIN && <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('UserProfileManagement.mmcNumber')}</Label>
                                                    <Field placeholder={t('UserProfileManagement.mmcNumber')} name="mmcno" disabled className={'form-control ' + (errors.mmcno && touched.mmcno ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="mmcno" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>}
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t(('UserProfileManagement.eportfolioEmailId'))} </Label>
                                                    <Field placeholder={t(('UserProfileManagement.eportfolioEmailId'))} name="eportfolioEmailId" disabled className={'form-control ' + (errors.eportfolioEmailId && touched.eportfolioEmailId ? 'is-invalid' : '')} />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t(('UserProfileManagement.status'))}</Label>
                                                    <Field type="text" disabled name='userStatus' className={'form-control ' + (errors.userStatus && touched.userStatus ? 'is-invalid' : '')} />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        {/* {isTrainee && <><h2>Study Plan</h2>
                                                            <table className='table'>
                                                                <thead>
                                                                    <tr>
                                                                        <td>sequence</td>
                                                                        <td>Rotation</td>
                                                                        <td>Year</td>
                                                                        <td>Stage</td>
                                                                        <td>University</td>
                                                                        <td>Hospital</td>
                                                                        <td>OtherHospital</td>
                                                                        <td>Duration</td>
                                                                        <td>approval status</td>
                                                                        <td>approval date</td>
                                                                        <td>approval comments</td>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr>
                                                                        <td>Licence</td>
                                                                        <td>-</td>
                                                                        <td> app.js </td>
                                                                        <td> Approved</td>
                                                                        <td> 17/06/2021</td>
                                                                        <td> ok </td>
                                                                        <td> ok </td>
                                                                        <td> ok </td>
                                                                        <td> ok </td>
                                                                        <td> ok </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table> </>} */}
                                    </div>
                                </div>
                            </div>

                            {!isDisabled && <div className="mt-3 text-right">
                                <button type='button' onClick={() => cancelProfileUpdate(values, setFieldValue, resetForm)} className='btn cancel-button'>{t('ActionNames.cancel')}</button>
                                <button type='submit' className='btn blue-button ml-2' disabled={(!(dirty && !values.validationError))} >{t('ActionNames.update')}</button>
                            </div>}
                        </Form>
                    }
                }
            </Formik>
        </React.Fragment>
    );
}


export default React.memo(UserProfileAction);