import React, { useContext } from 'react';
import { getRoleCode } from '../../../helpers/helpersIndex';
import { ERoleDesc } from '../../../models/utilitiesModel';
import { SuperParentContext } from '../Container/userprofilecontext';

const UserProfileManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);

    return (
        <>
            {
                getRoleCode() === ERoleDesc.Traninee ? <context.traineeProfileManager /> :
                    <context.userProfileAction />
            }
        </>
    )
}

export default React.memo(UserProfileManager);