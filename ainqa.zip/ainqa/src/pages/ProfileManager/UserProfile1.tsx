import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import ProfilePic from '../../images/user-profile.svg';

class UserProfile1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            isNew: true,
            addAgreement: false,
            approvals: false,
            viewDetails: false,
        };
        this.getForm = this.getForm.bind(this);
        this.getAgreements = this.getAgreements.bind(this);
        this.getApprovals = this.getApprovals.bind(this);
        this.viewDetails = this.viewDetails.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    getForm() {
        this.setState({ isNew: false })
    }
    getAgreements() {
        this.setState({ addAgreement: true })
    }
    getApprovals() {
        this.setState({ approvals: true })
    }
    viewDetails() {
        this.setState({ viewDetails: true })
    }

    render() {

        return (
            <React.Fragment>
                <div className="flexLayout">
                    <div className="flexScroll">
                            <div className="maincontent">
                                                           
                                    <div>
                                            <div className="top-section">
                                            <h2><div>Personal Details</div></h2>
                                            <div className="details-section">
                                            <Row className="h100 mt-3">
                                                <Col sm="8">
                                                    <Row>
                                                    <Col sm="6">
                                                    <FormGroup>
                                                        <Label>Name</Label>
                                                        <Input type="text" disabled value="Johnny Dep"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="6">
                                                    <FormGroup>
                                                        <Label>Date of Birth</Label>
                                                        <Input type="text" disabled value="05/05/1995"></Input>
                                                    </FormGroup>
                                                </Col>
                                                    </Row>

                                                    <Row>
                                                    <Col sm="6">
                                                    <FormGroup>
                                                        <Label>Gender</Label>
                                                        <Input type="text" disabled value="Male"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="6">
                                                    <FormGroup>
                                                        <Label>Ethnicity</Label>
                                                        <Input type="text" disabled value="Anglo-Indian"></Input>
                                                    </FormGroup>
                                                </Col>
                                                    </Row>
                                                </Col>

                                                <Col sm="4">
                                                    <Row className="h100">
                                                        <Col sm="12" className="h100">
                                                        <FormGroup className="h100">
                                                        <Label>Profile Picture</Label>
                                                        <div className="profile-pic">
                                                           <div className="profile-image">
                                                               <img src={ProfilePic} alt="" style={{width: "70px", margin:"10px"}}></img>
                                                           </div>
                                                           <button className="back-button">Upload New Photo</button>
                                                        </div>
                                                        </FormGroup>
                                                        </Col>
                                                    </Row>
                                                </Col>
                                            </Row>
     
                                            </div>
                                            </div>

                                            <div className="top-section">
                                            <h2><div>Contact Details</div></h2>
                                            <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Contact Number</Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value="9875043210" />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText><a href="#">change</a></InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Alternate Number</Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value="9998877766" />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText><a href="#">change</a></InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Personal Email ID </Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value="johnnydepp@gemail.com" />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText><a href="#">change</a></InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                           </div>
                                            </div>

                                            <div className="top-section">
                                            <h2><div>Address</div></h2>
                                            <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Permanent Address</Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value="3/4, XYZ, ABC" />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText><a href="#">change</a></InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Country</Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value="Indian" />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText><a href="#">change</a></InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Correspondent Address</Label>
                                                        <FormGroup check>
        <Label check>
          <Input type="checkbox" />{' '}
        Same as Permanent Address
        </Label>
      </FormGroup>
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Correspondent address</Label>
                                                        <Input type="text" disabled value="3/4, XYZ, ABC"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Country</Label>
                                                        <Input type="text" disabled value="India"></Input>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                           </div>
                                            </div>

                                            <div className="top-section">
                                            <h2><div>UM Student Details</div></h2>
                                            <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Student Legacy code</Label>
                                                        <Input type="text" disabled value="LUM 2514"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Student Code</Label>
                                                    <Input type="text" disabled value="UM388"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>IC Number</Label>
                                                        <Input type="text" disabled value="IC-115"></Input>
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>AMM Number</Label>
                                                        <Input type="text" disabled value="A858R4574ADS"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>MMC Number</Label>
                                                        <Input type="text" disabled value="48678588121BID"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>NSR Number</Label>
                                                        <Input type="text" disabled value="NSR000031215478"></Input>
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>UM Email ID</Label>
                                                        <Input type="text" disabled value="johndep@eportfolio.com"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>Status</Label>
                                                        <Input type="text" disabled value="active"></Input>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                           </div>
                                            </div>
                                        
                                    </div>
                            </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(UserProfile1));