export { default as UserProfileAction } from '../Components/userprofileaction';
export { default as UserProfileManager } from '../Components/userprofilemanager';
export { default as TraineeProfileManager } from '../Components/traineeprofilemanager';
export { default as MyDocuments } from '../myDocuments/container/myDocuments';