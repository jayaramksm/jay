import React from 'react';

export const SuperParentContext = React.createContext(null) as any;