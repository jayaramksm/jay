import React, { Component } from 'react';
import { connect } from 'react-redux';
import { UserProfileAction, TraineeProfileManager, UserProfileManager, MyDocuments } from './userprofileindex';
import { activateAuthLayout, getUserProfileManagementDataRequest, setResetUserProfileMamagementRequest } from '../../../store/actions';
import { SuperParentContext } from './userprofilecontext';

interface IProps {
    activateAuthLayout: any;
    getUserProfileManagementDataRequest: any;
    setResetUserProfileMamagementRequest: any;
}

class UserProfile extends Component<IProps, any>  {

    constructor(props) {
        super(props)

        this.state = {
            manager: {
                userProfileAction: UserProfileAction,
                traineeProfileManager: TraineeProfileManager,
                traineeDocuments: MyDocuments
            }
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getUserProfileManagementDataRequest();
    }

    componentWillUnmount() {
        this.props.setResetUserProfileMamagementRequest();
    }

    render() {
        return (
            <SuperParentContext.Provider value={this.state.manager}>
                <UserProfileManager />
            </SuperParentContext.Provider>
        )
    }
}

export default connect(null, { activateAuthLayout, getUserProfileManagementDataRequest, setResetUserProfileMamagementRequest })(UserProfile);