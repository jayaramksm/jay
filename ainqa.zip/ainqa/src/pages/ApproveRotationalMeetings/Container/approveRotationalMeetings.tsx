import React from "react";
import {SuperParentContext} from './approveRotationalMeetingsContext';
import {activateAuthLayout ,getApproveRotationalMeetingsDataRequest,cancelAllPendingApproveRotationalMeetingsRequest,resetAllApproveRotationalMeetingsStateRequest} from '../../../store/actions';
import {connect} from 'react-redux';
import {ApproveRotationalMeetingsParentManager ,ApproveRotationalMeetingsofRotationsViewParent,ApproveRotationalMeetingsofRotationsView, ApproveRotationalMeetingsViewManager,ApproveRotationalMeetingsView,ApproveRotationalMeetingsAction,ApproveRotationalMeetingsFilter} from './approveRotationalMeetingsIndex'

interface IProps {
    activateAuthLayout;
    getApproveRotationalMeetingsDataRequest;
    cancelAllPendingApproveRotationalMeetingsRequest;
    resetAllApproveRotationalMeetingsStateRequest;
}

class ApproveRotationalMeetings extends React.PureComponent<IProps, any> {

    constructor(props){
super(props);
this.state={
    approveRotationalMeetingsViewManager : ApproveRotationalMeetingsViewManager,
    approveRotationalMeetingsView : ApproveRotationalMeetingsView,
    approveRotationalMeetingsAction :ApproveRotationalMeetingsAction,
    approveRotationalMeetingsFilter  :ApproveRotationalMeetingsFilter,
    approveRotationalMeetingsofRotationsView :ApproveRotationalMeetingsofRotationsView,
    approveRotationalMeetingsofRotationsViewParent : ApproveRotationalMeetingsofRotationsViewParent

}
    }

componentDidMount(){
    this.props.activateAuthLayout();
    this.props.resetAllApproveRotationalMeetingsStateRequest();
    this.props.getApproveRotationalMeetingsDataRequest();
}

componentWillUnmount() {
    this.props.cancelAllPendingApproveRotationalMeetingsRequest();
    this.props.resetAllApproveRotationalMeetingsStateRequest();

}

    render(){
        return(
            <>
<SuperParentContext.Provider value={this.state}>
    <ApproveRotationalMeetingsParentManager/>
</SuperParentContext.Provider>
        </>
        )
    }

}


export default connect(null,{activateAuthLayout,getApproveRotationalMeetingsDataRequest,cancelAllPendingApproveRotationalMeetingsRequest,resetAllApproveRotationalMeetingsStateRequest}) (ApproveRotationalMeetings)