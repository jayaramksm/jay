import React, { useContext } from 'react';
import Approved from '../../../images/Approved.svg';
import Rejected from '../../../images/Reject.svg';
import Pending from '../../../images/Pending.svg';
import { useSelector, useDispatch } from 'react-redux';
import { setApproveRotationalMeetingsActionTypeData } from '../../../store/actions';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { IRotationalMeeting } from '../../../models/approveRotationalMeetingModel';
import { ParentContext } from '../Container/approveRotationalMeetingsContext';
import { useTranslation } from 'react-i18next';


const ApproveRotationalMeetingsofRotationsView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');

    const approveRotationalMeetingData: IRotationalMeeting | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.actionData)
            return state.approveRotationalMeetingsReducer.actionData?.find(x => x.rotationalMeetingId === context);
        else return undefined
    });

    const actionData: IRotationalMeeting[] | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.actionData)
            return state.approveRotationalMeetingsReducer.actionData;
        else return undefined
    });

    const userDto: IUserDetails | undefined = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const goToMarkStatus = (type) => {
        let actionType = type === 'view' ? EOprationalActions.SELECT : EOprationalActions.EDIT
        dispatch(setApproveRotationalMeetingsActionTypeData(actionType, actionData, approveRotationalMeetingData))
    }
    console.log('ApproveRotationalMeetingsofRotationsView==>', context, approveRotationalMeetingData);

    return (
        <>
            {/* <tr>
            <td>hii</td>
        </tr> */}
            {approveRotationalMeetingData && <tr>
                <td>{approveRotationalMeetingData?.stage}</td>
                <td>{approveRotationalMeetingData?.rotationName}</td>
                <td>{userDto?.university?.universityName}</td>
                <td>{approveRotationalMeetingData.firstRotationSupervisor?.supervisorName}</td>
                <td className="column-center">
                    {approveRotationalMeetingData?.firstRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                        approveRotationalMeetingData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                            approveRotationalMeetingData?.firstRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-'
                    }</td>
                <td>{approveRotationalMeetingData.secondRotationSupervisor?.supervisorName || '-'}</td>
                <td className="column-center">
                    {approveRotationalMeetingData?.secondRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                        approveRotationalMeetingData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                            approveRotationalMeetingData?.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-'
                    }</td>
                <td>{approveRotationalMeetingData.meetingType}</td>
                <td>{approveRotationalMeetingData?.meetingDateTime}</td>
                <td className="ActionStatus">
                    {approveRotationalMeetingData?.firstRotationSupervisor?.supervisorId === userDto?.userId && <> {(approveRotationalMeetingData?.firstRotationSupervisor?.status === EApprovelActions.APPROVED || approveRotationalMeetingData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED) ? <span onClick={() => goToMarkStatus('view')}> {t('ActionNames.view')} </span> : <span onClick={() => goToMarkStatus('markStatus')}> {t('ApproveRotationalMeetings.markStatus')} </span>}<br /></>}
                    {approveRotationalMeetingData?.secondRotationSupervisor?.supervisorId === userDto?.userId && <>{(approveRotationalMeetingData?.secondRotationSupervisor?.status === EApprovelActions.APPROVED || approveRotationalMeetingData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED) ? <span onClick={() => goToMarkStatus('view')}> {t('ActionNames.view')} </span> : <span onClick={() => goToMarkStatus('markStatus')}> {t('ApproveRotationalMeetings.markStatus')} </span>}</>}
                </td>
            </tr>}
        </>
    )
}
export default React.memo(ApproveRotationalMeetingsofRotationsView);