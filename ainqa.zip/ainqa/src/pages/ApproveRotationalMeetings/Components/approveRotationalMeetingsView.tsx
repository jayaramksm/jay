import React, { useContext } from 'react';
import { ParentContext } from '../Container/approveRotationalMeetingsContext';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'react-i18next';
import { IRotationalMeeting, IApproveRotationalMeetingModel } from '../../../models/approveRotationalMeetingModel';
import groupBy from 'lodash/groupBy';
import pending from '../../../images/Pending.svg';
import reject from '../../../images/Reject.svg';
import Approved from '../../../images/Approved.svg';
import { setApproveRotationalMeetingsActionTypeData } from '../../../store/actions'

const ApproveRotationalMeetingsView: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const context: any = useContext(ParentContext);

    const approveRotationalMeetingData: IRotationalMeeting[] | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.approveRotationalMeetingData?.length) {
            let approveRotationalMeetingsData = (state.approveRotationalMeetingsReducer as IApproveRotationalMeetingModel)?.approveRotationalMeetingData;
            return approveRotationalMeetingsData
        } else
            return undefined;
    });

    const ApproveClinicalMeetingsGroupedData = groupBy(approveRotationalMeetingData, 'traineeId');
    console.log("ApproveRotationalMeetingsView==>", ApproveClinicalMeetingsGroupedData[context], approveRotationalMeetingData, context);

    const userDto: IUserDetails | undefined = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const goToRotationalMeetingTraineeRotationsView = () => {
        dispatch(setApproveRotationalMeetingsActionTypeData(EOprationalActions.ADD, ApproveClinicalMeetingsGroupedData[context], null))
    }

    const isFirstRotationalSupervisor = (ApproveClinicalMeetingsGroupedData[context][0]?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? true : false;

    let overallStatus = ApproveClinicalMeetingsGroupedData[context]?.reduce((total, meeting: IRotationalMeeting) => {
        if (meeting.firstRotationSupervisor?.supervisorId === userDto?.userId) {
            return [...total, meeting.firstRotationSupervisor?.status];
        } else {
            return [...total, meeting.secondRotationSupervisor?.status]
        }
    }, [])

    const upervisorPendingStatus = overallStatus.some(x => x === EApprovelActions.PENDING);
    const supervisorApproveStatus = overallStatus?.every(x => x === EApprovelActions.APPROVED);

    // const isFirstRotationalSupervisor = (ApproveClinicalMeetingsGroupedData[context][0]?.firstRotationSupervisor?.supervisorId === userDto?.userId) ? true : false;

    // const isFirstRotationalSupervisorPendingStatus = ApproveClinicalMeetingsGroupedData[context]?.some(x => x.firstRotationSupervisor?.status === EApprovelActions.PENDING);
    // const isFirstRotationalSupervisorApproveStatus = ApproveClinicalMeetingsGroupedData[context]?.every(x => x.firstRotationSupervisor?.status === EApprovelActions.APPROVED);
    console.log("ApproveRotationalMeetingsView==>", isFirstRotationalSupervisor);

    return (
        <>
            {ApproveClinicalMeetingsGroupedData && approveRotationalMeetingData && <tr>
                <td onClick={goToRotationalMeetingTraineeRotationsView} className='pointer ActionStatus'>{ApproveClinicalMeetingsGroupedData[context][0].traineeName}</td>
                <td className="column-center">
                    <>{(supervisorApproveStatus) ? <img src={Approved} className="icon" alt="" /> : (upervisorPendingStatus ? <img src={pending} className="icon" alt="" /> : <img src={reject} className="icon" alt="" />)}</>
                </td>
            </tr>}
        </>
    )
}

export default React.memo(ApproveRotationalMeetingsView)