import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/approveRotationalMeetingsContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setApproveGlasPaginationCurrentPageValue } from '../../../store/actions';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { PaginationComponent } from '../../utilities/PaginationComponent';
import { IApproveRotationalMeetingModel, IRotationalMeeting } from '../../../models/approveRotationalMeetingModel';
import groupBy from 'lodash/groupBy';

const ApproveRotationalMeetingsViewManager: React.FC = () => {

    const context: any = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;
    const { t } = useTranslation('translations');

    const approveRotationalMeetingsData: IRotationalMeeting[] | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.approveRotationalMeetingData)
            return (state.approveRotationalMeetingsReducer as IApproveRotationalMeetingModel)?.approveRotationalMeetingData;
        else return undefined;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.searchKey)
            return (state.approveRotationalMeetingsReducer as IApproveRotationalMeetingModel).searchKey;
        else return "";
    });


    const approveRotationalMeetingsGroupedData = Object.entries(groupBy(approveRotationalMeetingsData, 'traineeId'));

    const approveClinicalMeetingsFilterData: any = (approveRotationalMeetingsGroupedData?.length && searchKey !== '') ? approveRotationalMeetingsGroupedData?.filter((x: any) => (
        searchKey !== '' ? x?.[1][0].traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : approveRotationalMeetingsGroupedData;

    const currentPage: number = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.paginationCurrentPage)
            return (state.approveRotationalMeetingsReducer as IApproveRotationalMeetingModel).paginationCurrentPage;
        else return 0;
    });


    let pagesCount: number = Math.ceil((approveClinicalMeetingsFilterData ? approveClinicalMeetingsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setApproveGlasPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setApproveGlasPaginationCurrentPageValue(index));
    };

    console.log("ApproveRotationalMeetingsViewManager=>", approveRotationalMeetingsData, context, approveRotationalMeetingsGroupedData);

    return (
        <div className="tbl-parent table-responsive">
            <table className="myTable clinicalMTable table">
                <thead>
                    <tr>
                        <th> {t('ApproveRotationalMeetings.traineeName')}</th>
                        <th className="text-center"> {t('ApproveRotationalMeetings.approvalStatus')}</th>

                    </tr>
                </thead>
                <tbody>
                    {approveClinicalMeetingsFilterData && approveClinicalMeetingsFilterData?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                        <ParentContext.Provider value={x[0]} key={x[0]}>
                            <context.approveRotationalMeetingsView />
                        </ParentContext.Provider>
                    ))}
                </tbody>
            </table>
            {(approveRotationalMeetingsData && approveClinicalMeetingsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('ApproveRotationalMeetings.NoDataFound')}</h6></div>}
            {approveClinicalMeetingsFilterData && approveClinicalMeetingsFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>}
        </div>

    )
}

export default React.memo(ApproveRotationalMeetingsViewManager)