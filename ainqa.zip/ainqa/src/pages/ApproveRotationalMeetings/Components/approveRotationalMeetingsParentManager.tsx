import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/approveRotationalMeetingsContext';
import { useSelector } from 'react-redux'
import { EOprationalActions } from '../../../models/utilitiesModel';

const ApproveRotationalMeetingsParentManager: React.FC = () => {
    const componets = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.actionType)
            return state.approveRotationalMeetingsReducer.actionType;
        else return EOprationalActions.UNSELECT
    });

    return (
        <div className="flexLayout">
            <div className="flexScroll">
                <div className="maincontent pr-3">

                    {(actionType === EOprationalActions.UNSELECT || actionType === EOprationalActions.ADD) && <componets.approveRotationalMeetingsFilter />}
                    {actionType === EOprationalActions.UNSELECT && <componets.approveRotationalMeetingsViewManager />}
                    {actionType === EOprationalActions.ADD && <componets.approveRotationalMeetingsofRotationsViewParent />}
                    {(actionType === EOprationalActions.EDIT || actionType === EOprationalActions.SELECT) && <componets.approveRotationalMeetingsAction />}
                </div>
            </div>
        </div>
    )
}

export default React.memo(ApproveRotationalMeetingsParentManager)