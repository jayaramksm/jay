import React, { useContext } from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { IRotationalMeeting } from '../../../models/approveRotationalMeetingModel';
import { PaginationComponent } from '../../utilities/PaginationComponent';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { setApproveRotationalMeetingsPaginationCurrentPageValue } from '../../../store/actions';
import { ParentContext, SuperParentContext } from '../Container/approveRotationalMeetingsContext';

const ApproveRotationalMeetingsofRotationsViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;


    const actionData: IRotationalMeeting[] | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.actionData)
            return state.approveRotationalMeetingsReducer.actionData
        else return undefined
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.searchKey)
            return state.approveRotationalMeetingsReducer.searchKey;
        else return ''
    });

    const currentPage: number = useSelector((state: any) => state?.approveRotationalMeetingsReducer?.paginationCurrentPage || 0);

    const approveRotationalMeetingsFilterData: any = (actionData?.length && searchKey !== '') ? actionData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : actionData;

    let pagesCount: number = Math.ceil((approveRotationalMeetingsFilterData ? approveRotationalMeetingsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setApproveRotationalMeetingsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setApproveRotationalMeetingsPaginationCurrentPageValue(index));
    };
    console.log("ApproveRotationalMeetingsofRotationsViewParent==>", actionData, approveRotationalMeetingsFilterData);


    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table approve-rm-table">
                                <thead>
                                    <tr>
                                        <th>{t('ApproveRotationalMeetings.stage')}</th>
                                        <th>{t('ApproveRotationalMeetings.rotation')}</th>
                                        <th>{t('ApproveRotationalMeetings.rotationUniversity')}</th>
                                        <th>{t('ApproveRotationalMeetings.firstRotationalSupervisor')}</th>
                                        <th className="column-center">{t('ApproveRotationalMeetings.approvalStatus')}</th>
                                        <th>{t('ApproveRotationalMeetings.secondRotationalSupervisor')}</th>
                                        <th className="column-center">{t('ApproveRotationalMeetings.approvalStatus')}</th>
                                        <th>{t('ApproveRotationalMeetings.meetingType')}</th>
                                        <th>{t('ApproveRotationalMeetings.meetingDateAndTime')}</th>
                                        <th>{t('ApproveRotationalMeetings.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        actionData && approveRotationalMeetingsFilterData?.length > 0 && approveRotationalMeetingsFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x: IRotationalMeeting) => (
                                            <ParentContext.Provider value={x.rotationalMeetingId} key={x.rotationalMeetingId}>
                                                <context.approveRotationalMeetingsofRotationsView />
                                            </ParentContext.Provider>
                                        ))
                                    }
                                </tbody>
                            </table>
                            {actionData && (approveRotationalMeetingsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('ApproveRotationalMeetings.NoDataFound')}</h6></div>}
                        </div>
                        {approveRotationalMeetingsFilterData && approveRotationalMeetingsFilterData.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(ApproveRotationalMeetingsofRotationsViewParent);