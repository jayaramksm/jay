import React from 'react';
import { Row, Col, Input, FormGroup, Label, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useTranslation } from 'react-i18next';
import "react-datepicker/dist/react-datepicker.css";
import * as Yup from 'yup';
import { useSelector, useDispatch } from 'react-redux';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { MySelect, defultContentValidate, customContentValidation, defultContentObjectValidate } from '../../../helpers/helpersIndex';
import { setApproveRotationalMeetingsActionTypeData, setApproveRotationalMeetingsStatusRequest } from '../../../store/actions';
import { IRotationalMeeting } from '../../../models/approveRotationalMeetingModel';
import Approved from '../../../images/Approved.svg';
import Rejected from '../../../images/Reject.svg';
import Pending from '../../../images/Pending.svg';

const approvalOptions = [{ value: 'pending', label: 'Pending' }, { value: 'approved', label: 'Approved' },
{ value: 'rejected', label: 'Rejected' }];

const ApproveRotationalMeetingsAction: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionType = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.actionType) {
            return (state.approveRotationalMeetingsReducer as any).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const actionData: IRotationalMeeting[] | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.actionData) {
            return (state.approveRotationalMeetingsReducer as any).actionData
        } else {
            return undefined
        }
    });

    const rotationalMeetingActionData: IRotationalMeeting | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.rotationalMeetingActionData) {
            return (state.approveRotationalMeetingsReducer as any).rotationalMeetingActionData
        } else {
            return undefined
        }
    });
    const userDto: IUserDetails | undefined = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });
    const isFirstSupervisor = (userDto?.userId === rotationalMeetingActionData?.firstRotationSupervisor?.supervisorId) ? true : false;

    const initialValues = () => ({
        approvelStatus: rotationalMeetingActionData ? (isFirstSupervisor ? approvalOptions.find(x => x.value === rotationalMeetingActionData?.firstRotationSupervisor?.status) : approvalOptions.find(x => x.value === rotationalMeetingActionData?.secondRotationSupervisor?.supervisorId)) : '',
        comments: rotationalMeetingActionData ? (isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.comments : rotationalMeetingActionData?.secondRotationSupervisor?.comments) : '',
        meetingType: rotationalMeetingActionData?.meetingType || '',
        nextMeetingDate: rotationalMeetingActionData?.nextMeetingDate || '',
        programName: rotationalMeetingActionData?.programName || '',
        rotationName: rotationalMeetingActionData?.rotationName || '',
        rotationalMeetingId: rotationalMeetingActionData?.rotationalMeetingId || '',
        stage: rotationalMeetingActionData?.stage || '',
        supervisorId: isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.supervisorId : rotationalMeetingActionData?.secondRotationSupervisor?.supervisorId,
        supervisorMailId: isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.supervisorMailId : rotationalMeetingActionData?.secondRotationSupervisor?.supervisorMailId,
        supervisorName: isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.supervisorName : rotationalMeetingActionData?.secondRotationSupervisor?.supervisorName,
        traineeId: rotationalMeetingActionData?.traineeId || '',
        traineeMailId: rotationalMeetingActionData?.traineeMailId || '',
        traineeName: rotationalMeetingActionData?.traineeName || '',
        userId: userDto?.userId || '',
        isFinalMeeting: rotationalMeetingActionData?.isFinalMeeting ? true : false || ''
    })


    const goBackToRotationalMeetingOfRotationView = () => {
        dispatch(setApproveRotationalMeetingsActionTypeData(EOprationalActions.ADD, actionData, null));
    }

    const goBackToRotationalMeetingsOfTrainee = () => {
        dispatch(setApproveRotationalMeetingsActionTypeData(EOprationalActions.UNSELECT, null, null));
    }
    const setApprovalStatus = (e, setFieldValue) => {
        setFieldValue('approvalStatus', e);
        setFieldValue('comments', '');
    }
    console.log('ApproveRotationalMeetingsAction==>', actionData, rotationalMeetingActionData)
    return (
        <>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="maincontent pr-3">
                        <div className="breadcrumbs">
                            <div> <span className='pointer' onClick={goBackToRotationalMeetingsOfTrainee}>{t('ApproveRotationalMeetings.ratationalMeetings')}</span>
                                <span><i className="ti-angle-right"></i></span>
                                <span onClick={goBackToRotationalMeetingOfRotationView} className='pointer'>{rotationalMeetingActionData?.traineeName}</span>
                                <span><i className="ti-angle-right"></i></span>
                                {actionType === EOprationalActions.EDIT && <span className="active">{t('ApproveRotationalMeetings.markStatus')}</span>}
                                {actionType === EOprationalActions.SELECT && <span className="active">{t('ActionNames.view')}</span>}
                            </div>
                        </div>
                        <Formik
                            initialValues={initialValues()}
                            onSubmit={values => {
                                console.log('ApproveRotationalMeetingsAction_onSubmit==>', values, values.isFinalMeeting)
                            }
                            }>
                            {
                                ({ errors, touched, setFieldValue, setFieldTouched, values }) => {
                                    return <Form>

                                        <div className="top-section">
                                            <h2>{t('ApproveRotationalMeetings.programDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.programName')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.programName || ''}></Input>
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.headofTheDepartment')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.hodName || ''}></Input>
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.educationalSupervisor')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.esName || ''}></Input>
                                                        </FormGroup>
                                                    </Col>

                                                </Row>
                                            </div>
                                        </div>
                                        <hr />

                                        <div className="top-section">
                                            <h2>{t('ApproveRotationalMeetings.rotationDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.universityName')}</Label>
                                                            <Input type="text" placeholder={t('ApproveRotationalMeetings.universityName')} disabled value={userDto?.university?.universityName || ''}></Input>
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.stage')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.stage || ''}></Input>
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.rotation')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.rotationName || ''}></Input>
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.hospitalName')} </Label>
                                                            <Input type="text" placeholder={t('ApproveRotationalMeetings.hospitalName')} disabled value={rotationalMeetingActionData?.hospitalName ? rotationalMeetingActionData.hospitalName : `Other-${rotationalMeetingActionData?.otherHospitalName}` || ''}></Input>
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.rotationDuration')}</Label>
                                                            <Input type="text" placeholder={t('ApproveRotationalMeetings.rotationDuration')} disabled value={rotationalMeetingActionData?.rotationDuration || ''}></Input>
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <hr />

                                        <div className="top-section">
                                            <h2>{t('ApproveRotationalMeetings.supervisorDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.firstRotationalSupervisor')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.firstRotationSupervisor?.supervisorName || ''}></Input>
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.secondRotationalSupervisor')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.secondRotationSupervisor?.supervisorName || ''}></Input>
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <hr />
                                        <div className="top-section">
                                            <h2>{t('ApproveRotationalMeetings.meetingDetails')}</h2>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm='4'>
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.meetingType')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.meetingType || ''}></Input>
                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label className="mr-2">{t('ApproveRotationalMeetings.finalMeeting')}</Label>
                                                            <Field type="checkbox" disabled name='isFinalMeeting' />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.meetingStartDate')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.meetingDateTime || ''} ></Input>

                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.agreedNextMeetingDate')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.nextMeetingDate || ''} ></Input>

                                                        </FormGroup>
                                                    </Col>

                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.traineeRemarks')}</Label>
                                                            <Input type="text" disabled value={rotationalMeetingActionData?.traineeComments || '-'} ></Input>                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                    </Form>
                                }
                            }
                        </Formik>
                        <hr />
                        <Formik
                            initialValues={{
                                oldApprovalStatus: rotationalMeetingActionData ? approvalOptions.find(x => x.value === (isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.status : rotationalMeetingActionData?.secondRotationSupervisor?.status)) : '',
                                approvalStatus: rotationalMeetingActionData ? approvalOptions.find(x => x.value === (isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.status : rotationalMeetingActionData?.secondRotationSupervisor?.status)) : '',
                                comments: isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.comments : rotationalMeetingActionData?.secondRotationSupervisor?.comments,
                                rotationalMeetingActionData: rotationalMeetingActionData,
                                isFinalMeeting: rotationalMeetingActionData?.isFinalMeeting ? true : false || ''
                            }}
                            validationSchema={Yup.object().shape({
                                comments: Yup.string().when('approvalStatus', {
                                    is: (approvelStatus) => approvelStatus?.value === EApprovelActions.REJECTED,
                                    then: defultContentValidate(t("controleErrors.required")),
                                    otherwise: Yup.lazy((val) => {
                                        if (val)
                                            return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4)
                                        else return defultContentValidate(t(''));
                                    })
                                }),
                            })}
                            onSubmit={values => {
                                let confirmMessage = t('ApproveRotationalMeetings.confirmMessages.ARMC');
                                if ((values.isFinalMeeting)) {
                                    dispatch(setApproveRotationalMeetingsStatusRequest(values, actionType, false, confirmMessage))
                                }
                                else dispatch(setApproveRotationalMeetingsStatusRequest(values, actionType, true, confirmMessage))
                                console.log('ApproveRotationalMeetingsAction_onSubmit==>', values, values.isFinalMeeting)
                            }
                            }
                        >
                            {
                                ({ values, setFieldValue, setFieldTouched, errors, touched, dirty }) => {
                                    return <Form>
                                        <div className="top-section">
                                            <Row className="compHeading">
                                                <Col sm="8" xs="12">
                                                    <h2>{isFirstSupervisor ? t('ApproveRotationalMeetings.firstRotationalSupervisor') : t('ApproveRotationalMeetings.secondRotationalSupervisor')}</h2>
                                                </Col>
                                                <Col sm="4" className="column-center">
                                                    <span className="approvedDate">{t('ApproveRotationalMeetings.approvedOn')} : <span className="date">{(isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.approvedOn : rotationalMeetingActionData?.secondRotationSupervisor?.approvedOn)}</span></span>
                                                </Col>
                                            </Row>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.approvalStatus')}</Label>
                                                            <MySelect
                                                                name='approvelStatus'
                                                                isDisabled={(values.oldApprovalStatus as any)?.value !== EApprovelActions.PENDING}
                                                                value={values.approvalStatus}
                                                                placeholder={t('ApproveRotationalMeetings.approvalStatus')}
                                                                onChange={(e) => setApprovalStatus(e, setFieldValue)}
                                                                options={approvalOptions ? approvalOptions : []}
                                                                getOptionLabel={option => option.label}
                                                                getOptionValue={option => option.value}
                                                                onBlur={() => setFieldTouched('approvalStatus', true)}
                                                                noOptionsMessage={() => { t('ApproveRotationalMeetings.NoDataFound') }}
                                                            />
                                                            {errors.approvalStatus && touched.approvalStatus && (
                                                                <div className="text-danger">{errors.approvalStatus}</div>
                                                            )}
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label> {t('ApproveRotationalMeetings.remarks')}</Label>
                                                            <Field as="textarea" rows={1} placeholder={t('ApproveRotationalMeetings.remarks')} name='comments' disabled={((values.oldApprovalStatus as any)?.value === EApprovelActions.APPROVED || (values.oldApprovalStatus as any)?.value === EApprovelActions.REJECTED) ? true : (values.approvalStatus as any)?.value === EApprovelActions.PENDING} className='form-control' />
                                                            <ErrorMessage name='comments' component='div' className='text-danger' />
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <hr />
                                        <div className="top-section">
                                            <Row>
                                                <Col sm="6">
                                                    <h2>{!isFirstSupervisor ? t('ApproveRotationalMeetings.firstRotationalSupervisor') : t('ApproveRotationalMeetings.secondRotationalSupervisor')}</h2>
                                                </Col>
                                            </Row>
                                            <div className="details-section">
                                                <Row className="mt-3">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Label>{t('ApproveRotationalMeetings.approvalStatus')}</Label>
                                                            <InputGroup className="disabled-item">
                                                                <Input disabled value={!isFirstSupervisor ? rotationalMeetingActionData?.firstRotationSupervisor?.status : rotationalMeetingActionData?.secondRotationSupervisor?.status} />
                                                                <InputGroupAddon addonType="append">
                                                                    <InputGroupText>
                                                                        {!isFirstSupervisor && (rotationalMeetingActionData?.firstRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                                                                            rotationalMeetingActionData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                                                                                rotationalMeetingActionData?.firstRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-')
                                                                        }
                                                                        {isFirstSupervisor && (rotationalMeetingActionData?.secondRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                                                                            rotationalMeetingActionData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                                                                                rotationalMeetingActionData?.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-')
                                                                        }
                                                                    </InputGroupText>
                                                                </InputGroupAddon>
                                                            </InputGroup>
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </div>
                                        </div>
                                        <Row className="sub-form-footer my-3 mr-5">
                                            <button className="cancel-button" type='button' onClick={goBackToRotationalMeetingOfRotationView}>{t('ActionNames.cancel')}</button>
                                            {actionType !== EOprationalActions.SELECT && <button className="btn blue-button" type='submit' disabled={!dirty}>{t('ActionNames.submit')}</button>}
                                        </Row>
                                    </Form>
                                }
                            }
                        </Formik>
                    </div>
                </div>
            </div>

        </>
    )
}

export default React.memo(ApproveRotationalMeetingsAction)