import React from 'react';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { setApproveRotationalMeetingsActionTypeData, setSearchApproveRotationalMeetingsData } from '../../../store/actions'
import { IRotationalMeeting } from '../../../models/approveRotationalMeetingModel';
import { EOprationalActions } from '../../../models/utilitiesModel';

const ApproveRotationalMeetingsFilter: React.FC = () => {

    const { t } = useTranslation('translations');

    const dispatch = useDispatch();
    const onSearchChange = e => {
        const searchInput = e.target.value;
        dispatch(setSearchApproveRotationalMeetingsData(searchInput));
    };
    const actionData: IRotationalMeeting[] | undefined = useSelector((state: any) => {
        if (state?.approveRotationalMeetingsReducer?.actionData)
            return state.approveRotationalMeetingsReducer.actionData
        else return undefined
    });
    const goBackToTraineeView = () => {
        dispatch(setApproveRotationalMeetingsActionTypeData(EOprationalActions.UNSELECT, null, null))
    }
    const showAGlaFilter = useSelector((state: any) => !!(state?.approveRotationalMeetingsReducer?.approveRotationalMeetingData?.length > 2));

    return (
        <>
            <Row className="compHeading">
                {!actionData && <Col>
                    <h2>{t('ApproveRotationalMeetings.ratationalMeetings')}</h2>
                </Col>}
                {actionData && <Col className="breadcrumbs mb-1">
                    <div>
                        <span onClick={goBackToTraineeView} className='pointer'>{t('ApproveRotationalMeetings.ratationalMeetings')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{actionData?.[0].traineeName}</span>
                    </div>
                </Col>}

                {showAGlaFilter && <div className="rgtFilter pr-3">
                    <div className="search-box filtericon">
                        <div className="search-text"><input type="text" onChange={onSearchChange} placeholder="Search"></input><i className="ti-search icon"></i></div>
                    </div>
                </div>}
            </Row>
        </>
    )
}

export default React.memo(ApproveRotationalMeetingsFilter)