import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/formconfigurationscontext';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setFormConfigurationCurrentPageInPagination } from '../../../../store/actions';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { IFormData } from '../../../../models/formConfigurationsModel';



const FormConfigurationsactionParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const currentPage: number = useSelector((state: any) => {
        if (state?.formConfigurationsReducer?.currentPage)
            return state.formConfigurationsReducer.currentPage;
        else return 0;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.formConfigurationsReducer?.searchKey)
            return state.formConfigurationsReducer.searchKey;
        else return '';
    });
    const formData: IFormData[] | undefined = useSelector((state: any) => {
        if (state?.formConfigurationsReducer?.formData)
            return state.formConfigurationsReducer.formData
        else return undefined
    });

    const formsFilterData: any = (formData?.length && searchKey !== '') ? formData?.filter((x: any) => (
        searchKey !== '' ? x?.formName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : formData;

    let pagesCount: number = Math.ceil((formsFilterData ? formsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setFormConfigurationCurrentPageInPagination(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setFormConfigurationCurrentPageInPagination(index));
    };

    return (
        <>
            <div className="flexScroll">
                <div className="main-table h-100">
                    <div className="tbl-parent table-responsive h-100 pr-2">
                        <table className="myTable formMappingTable table">
                            <thead>
                                <tr>
                                    <th>{t('FormConfigurations.formList')}</th>
                                    <th>{t('FormConfigurations.subCategory')}</th>
                                    <th>{t('FormConfigurations.mapTraineeForm')}</th>
                                    <th>{t('FormConfigurations.mapEvaluatorForm')}</th>
                                    <th>{t('FormConfigurations.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    formData && formsFilterData.length > 0 && formsFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x: IFormData, ind) => (
                                        <ParentContext.Provider value={x.portfolioFormId} key={x.portfolioFormId}>
                                            <context.formConfigurationActionView />
                                        </ParentContext.Provider>
                                    ))
                                }
                            </tbody>
                        </table>
                        {formData && (formsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('FormConfigurations.noDataFound')}</h6></div>}
                    </div>
                </div>
            </div>
            {formsFilterData && formsFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }

        </>
    )
}

export default React.memo(FormConfigurationsactionParent);