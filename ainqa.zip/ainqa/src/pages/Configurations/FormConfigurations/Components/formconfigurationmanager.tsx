import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/formconfigurationscontext';

const FormConfigurationManager: React.FC = () => {
    const context = useContext(SuperParentContext);
    return (
        <>
            <div className="flexLayout maincontent">
                <context.formConfigurationFilter />
                <context.formConfigurationsactionParent />
            </div>
        </>
    )
}
export default React.memo(FormConfigurationManager);