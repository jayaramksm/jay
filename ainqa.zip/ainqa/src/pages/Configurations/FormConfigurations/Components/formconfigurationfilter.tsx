import React from 'react';
import { Row, Col } from 'reactstrap';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setFormConfigurationsSearchKey } from '../../../../store/actions';
import { getAppsetting } from '../../../../helpers/helpersIndex';

const FormConfigurationFilter: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const setFormSearchKey = (e) => {
        dispatch(setFormConfigurationsSearchKey(e.target.value))
    }

    return (
        <>
            <Row className="compHeading mb-2 pr-2">
                <Col>
                    <h3 className="page-header header-title">{t('FormConfigurations.formsMappingList')}</h3>
                </Col>
                <div className="rgtFilter">
                    <div className="search-box filtericon">
                        <div className="search-text">
                            <input type="text" placeholder={t('FormConfigurations.search')} onChange={setFormSearchKey} /><i className="ti-search icon"></i>
                        </div>
                    </div>
                    {getAppsetting()?.formBuilderUrl && <a href={getAppsetting()?.formBuilderUrl} target='_blank' className="addnewButn">{t('FormConfigurations.formBuilderOpener')}</a>}
                </div>
            </Row>

        </>
    )
}

export default React.memo(FormConfigurationFilter);