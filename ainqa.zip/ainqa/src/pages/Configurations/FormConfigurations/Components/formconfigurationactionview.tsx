import React, { useContext, useState } from 'react';
import { customContentValidation } from '../../../../helpers/helpersIndex';
import { Formik } from 'formik';
import EditIcon from '../../../../images/Edit.svg';
import { useTranslation } from 'react-i18next';
import { SelectForms } from "form-configurator";
import { useSelector, useDispatch } from 'react-redux';
import { IFormData } from '../../../../models/formConfigurationsModel';
import { ParentContext } from '../Container/formconfigurationscontext';
import * as Yup from 'yup';
import { createOrUpdateFormConfigurationsDataRequest } from '../../../../store/actions';



const FormConfigurationActionView: React.FC = () => {

    const { t } = useTranslation('translations');
    const context = useContext(ParentContext);
    const dispatch = useDispatch();
    const [isEditable, setEditable] = useState(false);

    const formData: IFormData = useSelector((state: any) => {
        if (state?.formConfigurationsReducer?.formData)
            return state.formConfigurationsReducer.formData?.find(x => x.portfolioFormId === context)
        else return undefined
    });

    const saveFormMappingData = (values, isValid, dirty, submitForm) => {
        submitForm();

        if (isValid && dirty) {
            console.log('values==>', values);
            dispatch(createOrUpdateFormConfigurationsDataRequest({ ...values, ...formData }));
            setEditable(false);
        }
    }

    return (
        <>
            {formData && <Formik
                initialValues={{
                    traineefeedbackForm: formData?.portfolioFormMappings ? formData?.portfolioFormMappings?.traineeForm : '',
                    evaluatorfeedbackForm: formData?.portfolioFormMappings ? formData?.portfolioFormMappings?.evaluatorForm : ''
                }}
                validationSchema={Yup.object().shape({
                    traineefeedbackForm: customContentValidation(t, t('controleErrors.required')),
                    evaluatorfeedbackForm: customContentValidation(t, t('controleErrors.required'))
                })}
                onSubmit={values => console.log('onSubmit==>', values)}
            >
                {
                    ({ values, setFieldValue, isValid, dirty, submitForm, errors, touched, resetForm }) => {
                        return <tr>
                            <td>{formData.formName}</td>
                            <td>{formData.subCategoryName || '-'}</td>
                            <td>
                                {(!formData.portfolioFormMappings || isEditable) ? <SelectForms
                                    changeState={selectedForms => {
                                        //  const value = selectedForms?.length > 0 ? selectedForms?.[selectedForms.length - 1] || '' : '';
                                        setFieldValue('traineefeedbackForm', selectedForms ? JSON.stringify(selectedForms) : '')
                                        console.log('___selectedForms', selectedForms);
                                    }}
                                    title=' '
                                    value={values.traineefeedbackForm ? JSON.parse(values.traineefeedbackForm) : ''}
                                // ismultiple={true}
                                /> : values.traineefeedbackForm ? JSON.parse(values.traineefeedbackForm)?.label : ''}
                                {errors.traineefeedbackForm && touched.traineefeedbackForm && <div className='text-danger'>{errors.traineefeedbackForm}</div>}
                            </td>
                            <td>
                                {(!formData.portfolioFormMappings || isEditable) ? <SelectForms
                                    changeState={selectedForms => {
                                        // const value = selectedForms?.length > 0 ? selectedForms?.[selectedForms.length - 1] || '' : '';
                                        setFieldValue('evaluatorfeedbackForm', selectedForms ? JSON.stringify(selectedForms) : '')
                                        console.log('___selectedForms', selectedForms);
                                    }}
                                    title=' '
                                    value={values.evaluatorfeedbackForm ? JSON.parse(values.evaluatorfeedbackForm) : ''}
                                // ismultiple={true}
                                /> : values.evaluatorfeedbackForm ? JSON.parse(values.evaluatorfeedbackForm)?.label : ''}
                                {errors.evaluatorfeedbackForm && touched.evaluatorfeedbackForm && <div className='text-danger'>{errors.evaluatorfeedbackForm}</div>}
                            </td>
                            {(formData.portfolioFormMappings && !isEditable) && <td>
                                <img src={EditIcon} alt="edit" className="actionicon pointer" onClick={() => setEditable(true)} />
                            </td>}
                            {(!formData.portfolioFormMappings || isEditable) && <td>
                                <button type='button' className='btn blue-button mr-2' disabled={isEditable ? !dirty : false} onClick={() => saveFormMappingData(values, isValid, dirty, submitForm)}>{t('ActionNames.save')}</button>
                                {isEditable && <button type='button' className='btn icon-btn' onClick={() => { resetForm(); setEditable(false) }}><i className="icon-Close"></i></button>}
                            </td>}
                        </tr>
                    }
                }
            </Formik>}
        </>
    )
}

export default React.memo(FormConfigurationActionView);