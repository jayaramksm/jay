import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import { cancelAllPendingFormConfigurationsRequest, setResetForFormConfigurations, getFormConfigurationsDataRequest } from '../../../../store/actions';
import { SuperParentContext } from './formconfigurationscontext';
import {
    FormConfigurationManager,
    FormConfigurationActionView,
    FormConfigurationsactionParent,
    FormConfigurationFilter
} from './formconfigurationsindex'

export interface IProps {
    activateAuthLayout: any;
    getFormConfigurationsDataRequest: any;
    setResetForFormConfigurations: any;
    cancelAllPendingFormConfigurationsRequest: any;
}
class FormConfigurations extends React.Component<IProps, any> {

    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            formConfigurationActionView: FormConfigurationActionView,
            formConfigurationsactionParent: FormConfigurationsactionParent,
            formConfigurationFilter: FormConfigurationFilter
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForFormConfigurations();
        this.props.getFormConfigurationsDataRequest();
    }

    componentWillUnmount() {
        this.props.setResetForFormConfigurations();
        this.props.cancelAllPendingFormConfigurationsRequest();
    }

    render() {
        return (
            <>
                <SuperParentContext.Provider value={this.state}>
                    <FormConfigurationManager />
                </SuperParentContext.Provider>
            </>
        );
    }
}

export default connect(null, { activateAuthLayout, cancelAllPendingFormConfigurationsRequest, setResetForFormConfigurations, getFormConfigurationsDataRequest })(FormConfigurations);