import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import {
    EmailAction,
    EmailParentManager
} from './emailindex';
import { cancelAllPendingConfigurationsEmailRequest, setResetForConfigurationsEmail, getConfigurationsEmailDataRequest } from '../../../../store/actions';
import { SuperParentContext } from './emailcontext';

export interface IProps {
    activateAuthLayout: any;
    getConfigurationsEmailDataRequest: any;
    setResetForConfigurationsEmail: any;
    cancelAllPendingConfigurationsEmailRequest: any;
}
class Email extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            actionComponent: EmailAction
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForConfigurationsEmail();
        this.props.getConfigurationsEmailDataRequest();
    }

    componentWillUnmount() {
        this.props.setResetForConfigurationsEmail();
        this.props.cancelAllPendingConfigurationsEmailRequest();
    }

    render() {
        return (
            <>
                    <SuperParentContext.Provider value={this.state}>
                        <EmailParentManager />
                    </SuperParentContext.Provider>
            </>
        );
    }
}

export default connect(null, { activateAuthLayout, cancelAllPendingConfigurationsEmailRequest, setResetForConfigurationsEmail, getConfigurationsEmailDataRequest })(Email);