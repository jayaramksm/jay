import { createContext } from 'react';

export const SuperParentContext = createContext<any>(null);