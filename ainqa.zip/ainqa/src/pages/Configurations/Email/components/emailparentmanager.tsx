import React, { useContext } from 'react';
import { SuperParentContext } from '../container/emailcontext';

const EmailParentManager: React.FC = () => {
    const context = useContext(SuperParentContext);
    return (
        <>
            <div className="flexLayout pb-3">
                <div className="flexScroll">
                    <context.actionComponent />
                </div>
            </div>
        </>
    )
}
export default React.memo(EmailParentManager);