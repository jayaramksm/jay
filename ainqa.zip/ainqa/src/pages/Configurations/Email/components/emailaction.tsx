import React, { useContext, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, Label } from 'reactstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { IEmail } from '../../../../models/emailModel';
import { emailContentValidate, controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { createOrUpdateConfigurationsEmailDataRequest } from '../../../../store/actions';

const EmailAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const [isTextType, setIsTextType] = useState(false);
    const emailData: IEmail = useSelector((state: any) => state?.emailReducer?.emailData?.[0]);

    const getInitialValues = () => ({
        emailAccount: emailData ? emailData.emailAccount : '',
        password: emailData ? emailData.password : '',
        port: emailData ? emailData.port : '',
        serverIp: emailData ? emailData.serverIp : '',
        serverName: emailData ? emailData.serverName : '',
        mailBoxType: emailData ? mailBoxTypeData.find((x: any) => x.value === emailData.mailBoxType) : '',
        emailSettingsId: emailData ? emailData?.emailSettingsId : 0,
        emailData: emailData
    });

    const validationSchema = Yup.object().shape({
        emailAccount: emailContentValidate(t('controleErrors.required'), { value: 5, message: t('controleErrors.min').replace('{min}', '5') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        password: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumricwithoutspaceandallspecial', message: 'alphanumricwithoutspaceandallspecial', spacialChar: null }, 50, 2),
        port: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 4, 2),
        serverIp: controleContentValidate(t('controleErrors.required'), { value: 5, message: t('controleErrors.min').replace('{min}', '5') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, { patternType: 'server', message: t('controleErrors.serverPattern') }),
        serverName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
        mailBoxType: controleContentValidate(t('controleErrors.required')).ensure().nullable(),
    });

    return (
        <>
            <Row className="mx-0">
                <Col sm="10">
                    <Formik
                        enableReinitialize
                        initialValues={getInitialValues()}
                        validationSchema={validationSchema}
                        onSubmit={(values) => {
                            dispatch(createOrUpdateConfigurationsEmailDataRequest(values));
                        }}
                    >
                        {({ errors, touched, values, dirty, setFieldValue, setFieldTouched }) => (
                            <Form>
                                <Row>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('ConfigurationsEmail.name')}</Label>
                                            <Field placeholder={t('ConfigurationsEmail.name')} name="serverName" className={'form-control ' + (errors.serverName && touched.serverName ? 'is-invalid' : '')} />
                                            <ErrorMessage name="serverName" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('ConfigurationsEmail.emailAccount')}</Label>
                                            <Field placeholder={t('ConfigurationsEmail.emailAccount')} name="emailAccount" className={'form-control ' + (errors.emailAccount && touched.emailAccount ? 'is-invalid' : '')} />
                                            <ErrorMessage name="emailAccount" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group eyepassword">
                                            <Label>{t('ConfigurationsEmail.password')}</Label>
                                            <Field type={isTextType ? 'text' : 'password'} placeholder={t('ConfigurationsEmail.password')} name="password" className={'form-control ' + (errors.password && touched.password ? 'is-invalid' : '')} />
                                            <i className={(!isTextType ? 'ti-eye' : 'ti-close')} onClick={() => setIsTextType(!isTextType)}></i>
                                            <ErrorMessage name="password" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('ConfigurationsEmail.mailBoxType')}</Label>
                                            <MySelect
                                                name="mailBoxType"
                                                value={values.mailBoxType}
                                                onChange={(e) => setFieldValue('mailBoxType', e)}
                                                options={mailBoxTypeData}
                                                getOptionLabel={option => option.label}
                                                getOptionValue={option => option.value}
                                                onBlur={() => setFieldTouched('mailBoxType', true)}
                                                noOptionsMessage={() => t('ConfigurationsEmail.noMailboxTypes')}
                                            />
                                            {errors.mailBoxType && touched.mailBoxType && (
                                                <div className="error-msg">{errors.mailBoxType}</div>
                                            )}
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('ConfigurationsEmail.serverIp')}</Label>
                                            <Field placeholder={t('ConfigurationsEmail.serverIp')} name="serverIp" className={'form-control ' + (errors.serverIp && touched.serverIp ? 'is-invalid' : '')} />
                                            <ErrorMessage name="serverIp" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('ConfigurationsEmail.port')}</Label>
                                            <Field placeholder={t('ConfigurationsEmail.port')} name="port" className={'form-control ' + (errors.port && touched.port ? 'is-invalid' : '')} />
                                            <ErrorMessage name="port" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    {/* <Col sm="4">
                                    <div className="form-group">
                                        <Label>{t('ConfigurationsEmail.checkInterval')}</Label>
                                        <Field disabled={!contextActions.edit} name="mailCheckInterval" as={(props) => CustomNumberComponent(props, errors.mailCheckInterval, touched.mailCheckInterval)} placeholder={t('ConfigurationsEmail.checkInterval')} />
                                        <ErrorMessage name="mailCheckInterval" component="div" className="invalid-feedback" />
                                    </div>
                                </Col> */}
                                </Row>


                                <div className="mt-4 mb-3 text-right">
                                    <button type="submit" className="btn blue-button" disabled={!(dirty)}>
                                        {!emailData ? t('ActionNames.save') : t('ActionNames.update')}
                                    </button>
                                    {/* <button className="btn btn-cancel ml-3">Clear</button> */}
                                </div>
                            </Form>
                        )}
                    </Formik>
                </Col>
            </Row>
        </>
    )
}
// const CustomNumberComponent = (props, errors, touched) => (
//     <input className={'form-control ' + (errors && touched ? 'is-invalid' : '')} type="number" {...props} />
// );
const mailBoxTypeData = [
    { value: '1', label: 'SMTP' },
    { value: '2', label: 'IMAP' }
];
export default React.memo(EmailAction);