import React, { Component } from 'react';
import { Container, Row, Col, Card, CardBody } from 'reactstrap';
import { activateNonAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { logOutRequest } from '../../store/actions';
import { isTokenIsAvailble } from '../../helpers/helpersIndex';
import { ELogoutTypes, ERoutePath } from '../../models/utilitiesModel';

class PageUnAuthorized extends Component {

    constructor(props) {
        super(props);
        this.state = {}
        console.log("props1=>", props);

    }

    componentDidMount() {
        this.props.activateNonAuthLayout();
    }
    reDirectToLogin = () => {
        console.log('isTokenIsAvailble=>', isTokenIsAvailble());

        if (isTokenIsAvailble())
            this.props.logOutRequest(this.props.history, ERoutePath.default, ELogoutTypes.LOGOUT403);
        else
            this.props.history.push(ERoutePath.default);
    }

    render() {

        return (
            <React.Fragment>
                <div className="ex-pages">
                    <div className="content-center">
                        <div className="content-desc-center">
                            <Container>
                                <Card className="mo-mt-2">
                                    <CardBody>
                                        <Row className="align-items-center">
                                            <Col lg={{ size: 4, offset: 1 }}>
                                                <div className="ex-page-content">
                                                    <h1 className="text-dark">403!</h1>
                                                    <h4 className="mb-4">Sorry, UnAuthorized Page</h4>
                                                    <p className="mb-5">
                                                        You are Not Authorized to View This Page
                                                    </p>
                                                    <span className="btn btn-primary mb-5 waves-effect waves-light" onClick={() => this.reDirectToLogin()}><i
                                                        className="mdi mdi-home"></i> Go to Login</span>
                                                </div>
                                            </Col>
                                        </Row>
                                    </CardBody>
                                </Card>
                            </Container>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateNonAuthLayout, logOutRequest })(PageUnAuthorized));
// export default withRouter(PageUnAuthorized);