import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Scrollbars from 'react-custom-scrollbars';
import EditIcon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';
import Select from 'react-select';
import UploadFile from '../../images/upload-file.svg';
import uploadhistory from '../../images/History.svg';

class Programs1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }


    phasevariantOptions = [{ value: 'Phase', label: 'Phase' },
    { value: 'Stage', label: 'Stage' },
    { value: 'PhaseVariant', label: 'Phase-Variant' }
    ];

    phaseOptions = [{ value: 'PhaseI', label: 'PhaseI' },
    { value: 'PhaseII', label: 'PhaseII' },
    { value: 'PhaseIII', label: 'PhaseIII' }];

    // Stage Options
    stageOptions = [{ value: 'StageI', label: 'StageI' },
    { value: 'StageII', label: 'StageII' },
    { value: 'StageIII', label: 'StageIII' },
    { value: 'StageIV', label: 'StageIV' }];

    // Phase Variant Options
    phaseVariantOptions = [{ value: 'EarlyPhase', label: 'Early Phase' },
    { value: ' IntermediatePhase', label: ' Intermediate Phase' },
    { value: 'AdvancedPhase', label: 'Advanced Phase' }];

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of Existing Programs</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <div className="search-text">
                                    <input type="text" placeholder="Search" /><i className="ti-search icon"></i>
                                </div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Create</button>
                            <button className="iconBtn"><img src={UploadFile} alt="upload-icon" style={{ width: "18px" }} ></img></button>
                        </div>
                    </Row>

                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            {/* Programs View  */}
                            <div className="main-table no-border">
                                <div className="tbl-parent table-responsive">
                                    <table className="myTable table prgrm-table">
                                        <thead>
                                            <tr>
                                                <th>PG Program Name</th>
                                                <th>PG Program Code</th>
                                                <th>Phase Distribution</th>
                                                <th>University Name</th>
                                                <th>University Code</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Family medicine</td>
                                                <td>PGFM1</td>
                                                <td>PhaseI, PhaseII, PhaseIII</td>
                                                <td>University of Malay</td>
                                                <td>UM</td>
                                                <td className="ActionStatus column-center">
                                                    <span><img src={EditIcon} className="actionicon pointer" alt="edit-btn"></img></span>
                                                    <span><img src={Delete} alt="delete-btn" className="actionicon pointer"></img></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Ortho</td>
                                                <td>PGO1</td>
                                                <td>StageI, StageII, StageIII</td>
                                                <td>University of Malay</td>
                                                <td>UM</td>
                                                <td className="ActionStatus column-center">
                                                    <span><img src={EditIcon} className="actionicon pointer" alt="edit-btn"></img></span>
                                                    <span><img src={Delete} alt="delete-btn" className="actionicon pointer"></img></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>General SUrgery</td>
                                                <td>PGGS2</td>
                                                <td>PhaseI, PhaseII</td>
                                                <td>University of Malay</td>
                                                <td>UM</td>
                                                <td className="ActionStatus column-center">
                                                    <span><img src={EditIcon} className="actionicon pointer" alt="edit-btn"></img></span>
                                                    <span><img src={Delete} alt="delete-btn" className="actionicon pointer"></img></span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            {/* Programs View End  */}

                            {/* Programs Add  */}
                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Programs</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Create Program</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="uploadTabs flexLayout pr-0">
                                <Nav tabs>
                                    <NavItem>
                                        <NavLink className="active">
                                            <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                                            <span className="d-none d-sm-block">Create Program</span>
                                        </NavLink>
                                    </NavItem>

                                    <NavItem>
                                        <NavLink className="active">
                                            <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                                            <span className="d-none d-sm-block">Bulk Upload</span>
                                        </NavLink>
                                    </NavItem>
                                </Nav>
                                <TabContent className="flexLayout pr-0">
                                    {/* Programs Single Add  */}
                                    <div className="mydocuments">
                                        <div className="maincontent paglayout">
                                            <div className="top-section">
                                                <h2>Program Details</h2>
                                                <div className="details-section mt-3">
                                                    <Row>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>PG Program Name</Label>
                                                                <Input type="text" placeholder="Enter PG Program Name" name="programName" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>PG Program Code</Label>
                                                                <Input type="text" placeholder="Enter PG Program Code" name="programCode" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>Distribution</Label>
                                                                <Select
                                                                    onChange={(e) => { }}
                                                                    defaultValue={{ value: 'Phase', label: 'Phase' }}
                                                                    options={this.phasevariantOptions}
                                                                    placeholder="Select Distribution"
                                                                />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>Denomination</Label>
                                                                <Select
                                                                    onChange={(e) => { }}
                                                                    isMulti
                                                                    options={this.phaseOptions}
                                                                    placeholder="Select Denomination"
                                                                />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>University Name</Label>
                                                                <Input type="text" disabled value="University of Malay" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>University Code</Label>
                                                                <Input type="text" disabled value="UM" />
                                                            </FormGroup>
                                                        </Col>
                                                    </Row>
                                                    <Row className="sub-form-footer mt-3 mr-3">
                                                        <button className="cancel-button">Cancel</button>
                                                        <button className="btn blue-button">Create</button>
                                                    </Row>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Programs Single Add End */}

                                    {/* Programs Bulk Add  */}
                                    <div className="mydocuments">
                                        <div className="maincontent paglayout">
                                            <div className="top-section">
                                                <Row className="mx-0 compHeading">
                                                    <Col lg="9" sm="7" xs="12">
                                                        <h2>File Upload</h2>
                                                    </Col>
                                                    <Col lg="3" sm="5" xs="12" className="text-right filehistory">
                                                        <div><img src={uploadhistory} alt="" />File Uploads History</div>
                                                    </Col>
                                                </Row>
                                                <div className="details-section mt-3">
                                                    <Row>
                                                        <Col lg="7" sm="10" className="upload-btn">
                                                            <FormGroup style={{ float: "left" }}>
                                                                <Label>Browse File</Label>
                                                                <input type="file" hidden />
                                                                <div id="blockele">
                                                                    <div className="d-flex flex-row" id="file-chosen"><div className="mr-2"><i className="ti-folder icon-folder"></i> Select File</div></div>
                                                                    <label htmlFor="actual-btn" className="choose">Upload File</label>
                                                                </div>
                                                            </FormGroup>
                                                            <div className="sampledownldText">Download Sample File</div>
                                                        </Col>
                                                    </Row>
                                                    <Row className="sub-form-footer mt-3 mr-3">
                                                        <button className="cancel-button">Cancel</button>
                                                        <button type="submit" className="blue-button">Create</button>
                                                    </Row>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Programs Bulk Add End */}

                                </TabContent>
                            </div>

                            {/* Programs Add End  */}

                            {/* Programs File History  */}
                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Programs</span></BreadcrumbItem>
                                <BreadcrumbItem><span>Bulk Upload</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">File Uploads History</BreadcrumbItem>
                            </Breadcrumb>

                            <Row className="compHeading">
                                <Col sm="6" xs="12">
                                    <h3 className="page-header header-title">File Uploads History</h3>
                                </Col>
                                <Col sm="6" xs="12">
                                    <div className="text-right">
                                        <button className="addnewButn">Upload New File</button>
                                    </div>
                                </Col>
                            </Row>


                            <div className="historyTable">
                                <table className="myTable table">
                                    <thead>
                                        <tr>
                                            <th>Uploaded File</th>
                                            <th>Sheet Count</th>
                                            <th>Date and Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="fileName">Program2Csv_01.csv</td>
                                            <td>02</td>
                                            <td>24-05-2021, 03.30pm</td>
                                        </tr>
                                        <tr>
                                            <td className="fileName">ProgramCsv41.csv</td>
                                            <td>02</td>
                                            <td>24-05-2021, 05.30pm</td>
                                        </tr>
                                        <tr>
                                            <td className="fileName">ProgramCsv_001.csv</td>
                                            <td>02</td>
                                            <td>25-05-2021, 03.30pm</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            {/* Programs File History End  */}
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }
}
export default withRouter(connect(null, { activateAuthLayout })(Programs1));
