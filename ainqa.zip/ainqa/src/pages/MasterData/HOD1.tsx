import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, InputGroup, InputGroupAddon, InputGroupText, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Scrollbars from 'react-custom-scrollbars';
import EditIcon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';
import Select from 'react-select';
import UploadFile from '../../images/upload-file.svg';
import uploadhistory from '../../images/History.svg';

class HOD1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }



    deptOptions = [{ value: 'cardiology', label: 'Cardiology' },
    { value: 'neurology', label: 'Neurology' },
    { value: 'paediatrics', label: 'Paediatrics' },
    { value: 'ortho', label: 'Ortho' }];

    genderOptions = [{ value: 'Male', label: 'Male' },
    { value: 'Female', label: 'Female' },
    { value: 'Trangender', label: 'Transgender' }];


    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of Existing HOD's</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <div className="search-text">
                                    <input type="text" placeholder="Search" /><i className="ti-search icon"></i>
                                </div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Create</button>
                            <button className="iconBtn"><img src={UploadFile} alt="upload-icon" style={{ width: "18px" }} ></img></button>
                        </div>
                    </Row>

                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            {/* HOD's View  */}
                            <div className="main-table no-border">
                                <div className="tbl-parent table-responsive">
                                    <table className="myTable table hod_table">
                                        <thead>
                                            <tr>
                                                <th>HOD Full Name</th>
                                                <th>UMID</th>
                                                <th>Department Name</th>
                                                <th>Department Code</th>
                                                <th>University Name</th>
                                                <th>University Code</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Jackson</td>
                                                <td>UM1234</td>
                                                <td>Cardiology, Neurology</td>
                                                <td>UMDEP456</td>
                                                <td>University of Malay</td>
                                                <td>UM</td>
                                                <td className="ActionStatus column-center">
                                                    <span><img src={EditIcon} className="actionicon pointer" alt="edit-btn"></img></span>
                                                    <span><img src={Delete} alt="delete-btn" className="actionicon pointer"></img></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Rajesh</td>
                                                <td>UM45</td>
                                                <td>Paediatrics</td>
                                                <td>UMDEP456</td>
                                                <td>University of Malay</td>
                                                <td>UM</td>
                                                <td className="ActionStatus column-center">
                                                    <span><img src={EditIcon} className="actionicon pointer" alt="edit-btn"></img></span>
                                                    <span><img src={Delete} alt="delete-btn" className="actionicon pointer"></img></span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            {/* HOD's View End  */}

                            {/* HOD's Add  */}
                            <Breadcrumb>
                                <BreadcrumbItem><span>List of HOD's</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Create HOD</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="uploadTabs flexLayout pr-0">
                                <Nav tabs>
                                    <NavItem>
                                        <NavLink className="active">
                                            <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                                            <span className="d-none d-sm-block">Create HOD</span>
                                        </NavLink>
                                    </NavItem>

                                    <NavItem>
                                        <NavLink className="active">
                                            <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                                            <span className="d-none d-sm-block">Bulk Upload</span>
                                        </NavLink>
                                    </NavItem>
                                </Nav>
                                <TabContent className="flexLayout pr-0">
                                    {/* HOD's Single Add  */}
                                    <div className="mydocuments">
                                        <div className="maincontent paglayout">
                                            <div className="top-section">
                                                <h2>HOD Details</h2>
                                                <div className="details-section">
                                                    <Row className="mt-3">
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>HOD Full Name</Label>
                                                                <Input type="text" placeholder="Enter HOD Name" name="hodName" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>UMID</Label>
                                                                <Input type="text" placeholder="Enter UMID" name="umid" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>Department Name</Label>
                                                                <Select
                                                                    onChange={(e) => { }}
                                                                    isMulti
                                                                    options={this.deptOptions}
                                                                    placeholder="Select Department"
                                                                />
                                                            </FormGroup>
                                                        </Col>

                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>Department Code</Label>
                                                                <Input type="text" disabled value="DEP1, DEP2" />
                                                            </FormGroup>
                                                        </Col>

                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>MMC Number</Label>
                                                                <Input type="text" defaultValue="8588121BID" />
                                                            </FormGroup>
                                                        </Col>

                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>Contact Number</Label>
                                                                <Input type="text" defaultValue="+16-2342342342" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>ePortfolio Email ID</Label>
                                                                <InputGroup>
                                                                    <Input defaultValue="JohnnyDepp" />
                                                                    <InputGroupAddon addonType="append">
                                                                        <InputGroupText>@eportfolio.com</InputGroupText>
                                                                    </InputGroupAddon>
                                                                </InputGroup>
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>Gender</Label>
                                                                <Select
                                                                    onChange={(e) => { }}
                                                                    options={this.genderOptions}
                                                                    placeholder="Select Gender"
                                                                />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>University Name</Label>
                                                                <Input type="text" disabled value="University of Malay" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col sm="6" lg="4">
                                                            <FormGroup>
                                                                <Label>University Code</Label>
                                                                <Input type="text" disabled value="UM" />
                                                            </FormGroup>
                                                        </Col>
                                                    </Row>
                                                    <Row className="sub-form-footer mt-3 mr-3">
                                                        <button className="cancel-button">Cancel</button>
                                                        <button className="btn blue-button">Create</button>
                                                    </Row>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* HOD's Single Add End */}

                                    {/* HOD's Bulk Add  */}
                                    <div className="mydocuments">
                                        <div className="maincontent paglayout">
                                            <div className="top-section">
                                                <Row className="mx-0 compHeading">
                                                    <Col lg="9" sm="7" xs="12">
                                                        <h2>File Upload</h2>
                                                    </Col>
                                                    <Col lg="3" sm="5" xs="12" className="text-right filehistory">
                                                        <div><img src={uploadhistory} alt="" />File Uploads History</div>
                                                    </Col>
                                                </Row>
                                                <div className="details-section mt-3">
                                                    <Row>
                                                        <Col lg="7" sm="10" className="upload-btn">
                                                            <FormGroup style={{ float: "left" }}>
                                                                <Label>Browse File</Label>
                                                                <input type="file" hidden />
                                                                <div id="blockele">
                                                                    <div className="d-flex flex-row" id="file-chosen"><div className="mr-2"><i className="ti-folder icon-folder"></i> Select File</div></div>
                                                                    <label htmlFor="actual-btn" className="choose">Upload File</label>
                                                                </div>
                                                            </FormGroup>
                                                            <div className="sampledownldText">Download Sample File</div>
                                                        </Col>
                                                    </Row>
                                                    <Row className="sub-form-footer mt-3 mr-3">
                                                        <button className="cancel-button">Cancel</button>
                                                        <button type="submit" className="blue-button">Create</button>
                                                    </Row>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* HOD's Bulk Add End */}

                                </TabContent>
                            </div>

                            {/* HOD's Add End  */}

                            {/* HOD File History  */}
                            <Breadcrumb>
                                <BreadcrumbItem><span>List of HOD's</span></BreadcrumbItem>
                                <BreadcrumbItem><span>Bulk Upload</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">File Uploads History</BreadcrumbItem>
                            </Breadcrumb>

                            <Row className="compHeading">
                                <Col sm="6" xs="12">
                                    <h3 className="page-header header-title">File Uploads History</h3>
                                </Col>
                                <Col sm="6" xs="12">
                                    <div className="text-right">
                                        <button className="addnewButn">Upload New File</button>
                                    </div>
                                </Col>
                            </Row>


                            <div className="historyTable">
                                <table className="myTable table">
                                    <thead>
                                        <tr>
                                            <th>Uploaded File</th>
                                            <th>Sheet Count</th>
                                            <th>Date and Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="fileName">HODCsv_01.csv</td>
                                            <td>02</td>
                                            <td>24-05-2021, 03.30pm</td>
                                        </tr>
                                        <tr>
                                            <td className="fileName">HODCsv41.csv</td>
                                            <td>02</td>
                                            <td>24-05-2021, 05.30pm</td>
                                        </tr>
                                        <tr>
                                            <td className="fileName">HODCsv_001.csv</td>
                                            <td>02</td>
                                            <td>25-05-2021, 03.30pm</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            {/* HOD File History End  */}
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }
}
export default withRouter(connect(null, { activateAuthLayout })(HOD1));
