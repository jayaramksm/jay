import React, { useEffect, useCallback, useState } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { logOutRequest } from '../../store/actions';
import { isTokenIsAvailble, getAppsetting } from '../../helpers/helpersIndex';
import { ELogoutTypes } from '../../models/utilitiesModel';
import Keycloak from 'keycloak-js';
import { setKeycloakData, removeAuthToken } from '../../store/actions';
import warning from '../../images/warning.svg';
import '../../login-styles.css';
// import loginloading from '../../images/loading.gif';

let logOut;
const Pageslogin = (props) => {
    const [loginAttempts, setLoginAttempts] = useState(1);
    const [authCheck, setAuthCheck] = useState(false);
    const [keycloakProcess, setKeycloakProcess] = useState(false);
    const { history, loginError, removeAuthToken } = props;

    const tryAgainAuthProcessInit = (val) => {
        if (logOut)
            logOut();
        else
            setLoginAttempts(val);
    }
    useEffect(() => {
        if (isTokenIsAvailble())
            props.logOutRequest(history, undefined, ELogoutTypes.RELOGIN);
        return () => {
            logOut = undefined;
        }
    }, []);

    const retryLogin = useCallback(() => {
        if (isTokenIsAvailble())
            removeAuthToken();
        setAuthCheck(false);
        setKeycloakProcess(false);
        logOut = undefined;
        let authenticate = new Promise(async (resolve, reject) => {
            if (getAppsetting()?.keyClock) {
                const keycloakInstance = Keycloak(getAppsetting()?.keyClock);
                keycloakInstance
                    .init({ onLoad: 'login-required' })
                    .then(authenticated => {
                        if (authenticated)
                            resolve(keycloakInstance);
                    })
                    .catch(e => {
                        reject(e);
                    });
            }
            else
                reject({ error: 'no keyclock configuration data' })
        });

        (async () => {
            try {
                const keycloakInstance = await authenticate;
                if (keycloakInstance && keycloakInstance.token && keycloakInstance.idTokenParsed) {
                    const keycloakUsername = (keycloakInstance.idTokenParsed.preferred_username || '').trim();
                    logOut = keycloakInstance.logout;
                    props.setKeycloakData(keycloakInstance.token, keycloakInstance.createLogoutUrl(), setAuthCheck, setKeycloakProcess, history, keycloakUsername);
                }
                else {
                    setAuthCheck(true);
                }
            }
            catch (e) {
                setAuthCheck(true);
            }
        })();
    }, []);

    useEffect(() => {
        if (isTokenIsAvailble()) {
            removeAuthToken();
        }
        retryLogin();
    }, [loginAttempts]);

    return (
        <>
            {((authCheck && keycloakProcess) || !authCheck) &&
                <div className="appLoading">Loading <div className="lds-ring"><div></div><div></div><div></div><div></div></div></div>}
            {/* <div className="loginloading">
                    <p><img src={loginloading} alt="Loading" /> Loading....</p>
                </div> */}

            {(authCheck && !keycloakProcess) &&
                <div className="loginfailed">
                    <p><img src={warning} alt="Authentication failed" /><br />Your Authentication is failed. {loginError && <span>({loginError})</span>}<br />
                        <button onClick={() => tryAgainAuthProcessInit(loginAttempts + 1)} className="btn">Try again</button>
                    </p>
                </div>}
        </>
    );
}

const mapStatetoProps = ({ Login }) => {
    const { user = null, loginError = '' } = Login || {};
    return { user, loginError };
}
export default withRouter(connect(mapStatetoProps, { logOutRequest, setKeycloakData, removeAuthToken })(Pageslogin));