import React, { useContext } from 'react';
import Approved from '../../../images/Approved.svg';
import pending from '../../../images/Pending.svg';
import reject from '../../../images/Reject.svg';
import { useDispatch, useSelector } from 'react-redux';
import { setApproveRlasActionTypeData } from '../../../store/actions';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { IRla } from '../../../models/approveRlaModel';
import { ParentContext } from '../Container/approveRlaContext';
import groupBy from 'lodash/groupBy';
import maxBy from 'lodash/maxBy';

const ApproveRLATraineeView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);

    const approveRlaData: IRla[] = useSelector((state: any) => {
        if (state?.approveRlasReducer?.approveRlasData)
            return state.approveRlasReducer.approveRlasData;
        else return undefined
    });

    const approveRlasGroupedData = groupBy(approveRlaData, 'traineeId');

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const getLatestSubmitedRla = (rlaData) => {
        return maxBy(rlaData, (data) => +(new Date(data.createdOn)))?.createdOn
    }

    console.log('ApproveRLATraineeView=>', { context, approveRlaData, approveRlasGroupedData: approveRlasGroupedData[context] });


    const goToTraineeRotationsRlaView = () => {
        dispatch(setApproveRlasActionTypeData(EOprationalActions.ADD, approveRlasGroupedData[context], null))
    }
    const isFirstRotationalSupervisor = (approveRlasGroupedData[context][0]?.firstRotationalSupervisor?.supervisorId === userDto?.userId) ? true : false;

    const isFirstRotationalSupervisorPendingStatus = approveRlasGroupedData[context]?.some(x => x.firstRotationalSupervisor?.status === EApprovelActions.PENDING);
    const isFirstRotationalSupervisorApproveStatus = approveRlasGroupedData[context]?.every(x => x.firstRotationalSupervisor?.status === EApprovelActions.APPROVED);

    const isSecondRotationSupervisorPendingStatus = approveRlasGroupedData[context]?.some(x => x.secondRotationSupervisor?.status === EApprovelActions.PENDING);
    const isSecondRotationSupervisorApproveStatus = approveRlasGroupedData[context]?.every(x => x.secondRotationSupervisor?.status === EApprovelActions.APPROVED);

    return (
        <>
            {approveRlasGroupedData && approveRlaData && <tr>
                <td onClick={goToTraineeRotationsRlaView} className='pointer ActionStatus'>{approveRlasGroupedData[context][0].traineeName}</td>
                <td>{getLatestSubmitedRla(approveRlasGroupedData[context])}</td>
                <td className="column-center">
                    {isFirstRotationalSupervisor && <>{(isFirstRotationalSupervisorApproveStatus) ? <img src={Approved} className="icon" alt="" /> : (isFirstRotationalSupervisorPendingStatus ? <img src={pending} className="icon" alt="" /> : <img src={reject} className="icon" alt="" />)}</>}
                    {!isFirstRotationalSupervisor && <>{(isSecondRotationSupervisorApproveStatus) ? <img src={Approved} className="icon" alt="" /> : (isSecondRotationSupervisorPendingStatus ? <img src={pending} className="icon" alt="" /> : <img src={reject} className="icon" alt="" />)}</>}

                    {/* {!isFirstRotationalSupervisor&& <>{(approveRlasGroupedData[context][0]?.secondRotationSupervisor?.status === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (approveRlasGroupedData[context][0]?.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={pending} className="icon" alt="" /> : approveRlasGroupedData[context][0]?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "")}</>} */}
                </td>
            </tr>}
        </>
    )
}
export default React.memo(ApproveRLATraineeView);