import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/approveRlaContext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { IRla } from '../../../models/approveRlaModel';
import { PaginationComponent } from '../../utilities/PaginationComponent';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { setApproveRlasPaginationCurrentPageValue } from '../../../store/actions';

const ApproveRLAofRotationsViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;


    const actionData: IRla[] = useSelector((state: any) => {
        if (state?.approveRlasReducer?.actionData)
            return state.approveRlasReducer.actionData?.sort(function (a, b) {
                var c: any = new Date(a.createdOn);
                var d: any = new Date(b.createdOn);
                return c - d;
            })
        // .sort((a :any,b :any)=> (new Date(b.createdOn) - new Date(a.createdOn)));
        else return undefined
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approveRlasReducer?.searchKey)
            return state.approveRlasReducer.searchKey;
        else return ''
    });

    const currentPage: number = useSelector((state: any) => state?.approveRlasReducer?.paginationCurrentPage || 0);

    const approveRlasFilterData: any = (actionData?.length && searchKey !== '') ? actionData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : actionData;

    let pagesCount: number = Math.ceil((approveRlasFilterData ? approveRlasFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setApproveRlasPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setApproveRlasPaginationCurrentPageValue(index));
    };

    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table approvepla-table">
                                <thead>
                                    <tr>
                                        <th>{t('ApproveRla.stage')}</th>
                                        <th>{t('ApproveRla.rotation')}</th>
                                        <th>{t('ApproveRla.submitedDate')}</th>
                                        <th>{t('ApproveRla.startAndEndDate')}</th>
                                        <th>{t('ApproveRla.firstRotationalSupervisor')}</th>
                                        <th className="column-center">{t('ApproveRla.approvalStatus')}</th>
                                        <th>{t('ApproveRla.secondRotationalSupervisor')}</th>
                                        <th className="column-center">{t('ApproveRla.approvalStatus')}</th>
                                        <th className="column-center">{t('ApproveRla.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        actionData && approveRlasFilterData?.length > 0 && approveRlasFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x: IRla) => (
                                            <ParentContext.Provider value={x.rlaId} key={x.rlaId}>
                                                <context.approveRLAofRotationsView />
                                            </ParentContext.Provider>
                                        ))
                                    }
                                </tbody>
                            </table>
                            {actionData && (approveRlasFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('ApproveRla.NoDataFound')}</h6></div>}
                        </div>
                        {approveRlasFilterData && approveRlasFilterData.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(ApproveRLAofRotationsViewParent);