import React, { useContext } from 'react';
import Approved from '../../../images/Approved.svg';
import Rejected from '../../../images/Reject.svg';
import Pending from '../../../images/Pending.svg';
import { useSelector, useDispatch } from 'react-redux';
import { setApproveRlasActionTypeData } from '../../../store/actions';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { IRla } from '../../../models/approveRlaModel';
import { ParentContext } from '../Container/approveRlaContext';
import { useTranslation } from 'react-i18next';


const ApproveRLAofRotationsView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');

    const approveRlaData: IRla = useSelector((state: any) => {
        if (state?.approveRlasReducer?.actionData)
            return state.approveRlasReducer.actionData?.find(x => x.rlaId === context);
        else return undefined
    });

    const actionData: IRla[] = useSelector((state: any) => {
        if (state?.approveRlasReducer?.actionData)
            return state.approveRlasReducer.actionData;
        else return undefined
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const goToMarkRotationRlaStatus = (type) => {
        let actionType = type === 'view' ? EOprationalActions.SELECT : EOprationalActions.EDIT
        dispatch(setApproveRlasActionTypeData(actionType, actionData, approveRlaData))
    }

    return (
        <>
            {approveRlaData && <tr>
                <td>{approveRlaData.stageName}</td>
                <td>{approveRlaData.rotationName}</td>
                <td>{approveRlaData.createdOn}</td>
                <td>{`${approveRlaData.rotationStartDate}-${approveRlaData.rotationEndDate}`}</td>
                <td>{approveRlaData.firstRotationalSupervisor?.supervisorName || '-'}</td>
                <td className="column-center">
                    {approveRlaData.firstRotationalSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                        approveRlaData.firstRotationalSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                            approveRlaData.firstRotationalSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-'
                    }
                </td>
                <td>{approveRlaData.secondRotationSupervisor?.supervisorName || '-'}</td>
                <td className="column-center">
                    {approveRlaData.secondRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                        approveRlaData.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                            approveRlaData.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-'
                    }
                </td>
                <td className="column-center pointer" ><span className="ActionStatus">
                    {approveRlaData?.firstRotationalSupervisor?.supervisorId === userDto?.userId && <>{(approveRlaData.firstRotationalSupervisor?.status === EApprovelActions.APPROVED || approveRlaData.firstRotationalSupervisor?.status === EApprovelActions.REJECTED) ? <span onClick={() => goToMarkRotationRlaStatus('view')}> {t('ActionNames.view')} </span> : <span onClick={() => goToMarkRotationRlaStatus('markStatus')}> {t('ApproveRla.markStatus')} </span>}</>}
                    {approveRlaData?.secondRotationSupervisor?.supervisorId === userDto?.userId && <>{(approveRlaData.secondRotationSupervisor?.status === EApprovelActions.APPROVED || approveRlaData.secondRotationSupervisor?.status === EApprovelActions.REJECTED) ? <span onClick={() => goToMarkRotationRlaStatus('view')}> {t('ActionNames.view')} </span> : <span onClick={() => goToMarkRotationRlaStatus('markStatus')}> {t('ApproveRla.markStatus')} </span>}</>}
                </span></td>
            </tr>}
        </>
    )
}
export default React.memo(ApproveRLAofRotationsView);