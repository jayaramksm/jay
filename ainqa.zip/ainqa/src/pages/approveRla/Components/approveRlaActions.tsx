import React from 'react'
import { useSelector, useDispatch } from 'react-redux';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, customContentValidation } from '../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { Row, Col, Input, FormGroup, Label, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';
import { IRla } from '../../../models/approveRlaModel';
import { EApprovelActions, EOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import Approved from '../../../images/Approved.svg';
import Rejected from '../../../images/Reject.svg';
import Pending from '../../../images/Pending.svg';
import { setApproveRlasStatusRequest, setApproveRlasActionTypeData } from '../../../store/actions';


const ApproveRLAActions: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const rlaActionData: IRla = useSelector((state: any) => {
        if (state?.approveRlasReducer?.rlaActionData)
            return state.approveRlasReducer.rlaActionData;
        else return undefined;
    });

    const actionData: IRla[] = useSelector((state: any) => {
        if (state?.approveRlasReducer?.actionData)
            return state.approveRlasReducer.actionData;
        else return undefined;
    });

    const actionType: number = useSelector((state: any) => {
        if (state?.approveRlasReducer?.actionType)
            return state.approveRlasReducer.actionType;
        else return EOprationalActions.UNSELECT;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    let isFirstSupervisor = rlaActionData?.firstRotationalSupervisor?.supervisorId === userDto?.userId ? true : false

    console.log('isFirstSupervisor==>', isFirstSupervisor)
    const initialValues = () => ({
        traineeName: rlaActionData?.traineeName || '',
        programName: rlaActionData?.programName || '',
        headoftheDepartment: rlaActionData?.hodName || '-',
        educationalSupervisor: rlaActionData?.esName || '',
        mOHSupervisor: rlaActionData?.mohName || '',
        universityName: userDto?.university?.universityName || '',
        stage: rlaActionData?.stageName || '',
        rotation: rlaActionData?.rotationName || '',
        rotationstartDate: rlaActionData?.rotationStartDate || '',
        rotationEndDate: rlaActionData?.rotationEndDate || '',
        rotationDuration: rlaActionData?.rotationDuration || '',
        hosptialName: rlaActionData?.hospitalName || 'Other',
        otherHospitalName: rlaActionData?.otherHospitalName || '-',
        placementAimsandobjective: rlaActionData?.placementAmisObject || '',
        plannedAbsencesConferences: rlaActionData?.plannedAbsencesConferences || '',
        firstRotationalSupervisor: rlaActionData?.firstRotationalSupervisor?.supervisorName || '',
        secondRotationalSupervisor: rlaActionData?.secondRotationSupervisor?.supervisorName || '',
        wbaDetails: rlaActionData?.expectedWbas || [],
        agreementStatus: rlaActionData.traineeSignature === 'true' ? true : false,
        comments: '',
    });

    const approvalOptions = [{ value: 'pending', label: 'Pending' }, { value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' }];

    const rejectedOptions = [{ value: 'Incorrect Supervisor Chosen', label: 'Incorrect Supervisor Chosen' },
    { value: 'Incorrect Rotational Agreement Details', label: 'Incorrect Rotational Agreement Details' }]


    const goBackToRotationsRlaView = () => {
        dispatch(setApproveRlasActionTypeData(EOprationalActions.ADD, actionData, null));
    }

    const selectApprovalStatus = async (e, setFieldValue) => {
        setFieldValue('approvalStatus', e ? e : '');
        await setFieldValue('signature', false);
        await setFieldValue('remarks', '');
    }

    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <Formik
                        enableReinitialize
                        initialValues={initialValues()}
                        onSubmit={(values) => {
                            console.log("SubmitedValues==>", values);
                        }}>
                        {({ values, dirty }) => (
                            <Form>
                                <div className="top-section">
                                    <h2><div> {t('ApproveRla.aggrementDetails')}</div></h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.traineeName')}</Label>
                                                    <Field name='traineeName' type="text" disabled className='form-control' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.programmeName')}</Label>
                                                    <Field type="text" name='programName' disabled className='form-control' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.headoftheDepartment')}</Label>
                                                    <Field type="text" name='headoftheDepartment' disabled className='form-control' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.educationalSupervisor')}</Label>
                                                    <Field type="text" disabled name='educationalSupervisor' className='form-control' />
                                                </FormGroup>
                                            </Col>

                                            {<Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.mOHSupervisor')}</Label>
                                                    <Field type="text" disabled name='mOHSupervisor' className='form-control' />
                                                </FormGroup>
                                            </Col>
                                            }
                                        </Row>
                                    </div>
                                </div>
                                <hr />
                                <div className="top-section">
                                    <h2><div> {t('ApproveRla.rotationDetails')}</div></h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>  {t('ApproveRla.universityName')}</Label>
                                                    <Field type="text" disabled className='form-control' name='universityName' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.stage')}</Label>
                                                    <Field type="text" disabled name='stage' className='form-control' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.rotation')}</Label>
                                                    <Field type="text" disabled name='rotation' className='form-control' />
                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.rotationstartDate')}</Label>
                                                    <Field type="text" disabled name='rotationstartDate' className='form-control' />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.rotationEndDate')}</Label>
                                                    <Field type="text" disabled name='rotationEndDate' className='form-control' />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.rotationDuration')}</Label>
                                                    <Field type="text" disabled name='rotationDuration' className='form-control' />
                                                </FormGroup>
                                            </Col>

                                        </Row>

                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.hosptialName')}</Label>
                                                    <Field type="text" disabled name='hosptialName' className='form-control' />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.otherHospitalName')}</Label>
                                                    <Field type="text" disabled placeholder={t('ApproveRla.otherHospitalName')} name='otherHospitalName' className='form-control' />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('ApproveRla.placementAimsandobjective')}</Label>
                                                    <Field as='textarea' name='placementAimsandobjective' disabled placeholder="Write down here" rows={1} className="comments form-control" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.plannedAbsences&Conferences')}</Label>
                                                    <Field as='textarea' name='plannedAbsencesConferences' disabled placeholder="Write down here" rows={1} className="comments form-control" />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                                <hr />

                                <div className="top-section">
                                    <h2> {t('ApproveRla.clinicalSupervisorDetails')}</h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <Label> {t('ApproveRla.firstRotationalSupervisor')}</Label>
                                                <Field type="text" disabled name='firstRotationalSupervisor' className='form-control' />

                                            </Col>
                                            {<Col sm="4">
                                                <FormGroup>
                                                    <Label> {t('ApproveRla.secondRotationalSupervisor')}</Label>
                                                    <Field type="text" disabled name="secondRotationalSupervisor" className='form-control' />
                                                </FormGroup>
                                            </Col>}
                                        </Row>
                                    </div>
                                </div>
                                <hr />
                                <div className="top-section">
                                    <h2><div>{t('ApproveRla.wbaDetails')}</div></h2>
                                    <div className="details-section section-border mt-3 table-responsive">
                                        <table className="details-table table">
                                            <thead>
                                                <tr>
                                                    <th>{t('ApproveRla.name')}</th>
                                                    <th>{t('ApproveRla.expected')}</th>
                                                    <th>{t('ApproveRla.planned')}</th>
                                                    <th>{t('ApproveRla.completed')}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    values.wbaDetails?.map(x => (
                                                        <tr key={x.wbaId}>
                                                            <td>{x.wbaName}</td>
                                                            <td className="column-center"><span className="wba-bg">{x.wbaExpected}</span></td>
                                                            <td className="column-center"><span className="wba-bg">{x.planned}</span></td>
                                                            <td className="column-center"><span className="wba-bg">{x.completed || 0}</span></td>
                                                        </tr>
                                                    ))
                                                }
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="details-section">
                                    <Row className="mt-3">
                                        <Col sm="5">
                                            <FormGroup>
                                                <div className="terms"><Field type="checkbox" disabled name='agreementStatus' />{t('ApproveRla.agreementStatus')}</div>
                                            </FormGroup>
                                        </Col>
                                        {/* <Col sm="4">
                                            <FormGroup>
                                                <Label> {t('ApproveRla.comments')}</Label>
                                                <Field as='textarea' rows={1} name='comments' disabled className="comments form-control" placeholder="Enter Comments" />
                                            </FormGroup>
                                        </Col> */}
                                    </Row>
                                </div>
                            </Form>
                        )}
                    </Formik>
                    <hr />

                    <Formik
                        initialValues={{
                            oldApprovalStatus: rlaActionData ? approvalOptions.find(x => x.value === (isFirstSupervisor ? rlaActionData?.firstRotationalSupervisor?.status : rlaActionData?.secondRotationSupervisor?.status)) : '',
                            approvalStatus: rlaActionData ? approvalOptions.find(x => x.value === (isFirstSupervisor ? rlaActionData?.firstRotationalSupervisor?.status : rlaActionData?.secondRotationSupervisor?.status)) : '',
                            remarks: (isFirstSupervisor ? (rlaActionData?.firstRotationalSupervisor?.status === EApprovelActions.REJECTED ? rejectedOptions.find(x => x.value === rlaActionData?.firstRotationalSupervisor?.comments) : rlaActionData?.firstRotationalSupervisor?.comments) :
                                (rlaActionData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? rejectedOptions.find(x => x.value === rlaActionData?.secondRotationSupervisor?.comments) : rlaActionData?.secondRotationSupervisor?.comments)),
                            signature: (isFirstSupervisor ? (rlaActionData?.firstRotationalSupervisor?.signature === 'true' ? true : false) : (rlaActionData?.secondRotationSupervisor?.signature === 'true' ? true : false)),
                            rlaActionData: rlaActionData
                        }}
                        validationSchema={Yup.object().shape({
                            remarks: Yup.string().when('approvalStatus', {
                                is: (approvelStatus) => approvelStatus?.value === EApprovelActions.REJECTED,
                                then: defultContentValidate(t("controleErrors.required")),
                                otherwise: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4)
                            }),
                            signature: Yup.mixed().when('approvalStatus', {
                                is: (approvelStatus) => approvelStatus?.value === EApprovelActions.APPROVED,
                                then: Yup.boolean().oneOf([true], t('controleErrors.required')),
                                otherwise: defultContentValidate(t('')),
                            })
                        })}
                        onSubmit={values => {
                            dispatch(setApproveRlasStatusRequest(values))
                            console.log('onSubmit==>', values);
                        }}
                    >
                        {
                            ({ values, setFieldValue, setFieldTouched, errors, touched, dirty }) => {
                                return <Form>
                                    <div className="top-section">
                                        <Row className="compHeading">
                                            <Col sm="8" xs="12">
                                                <h2>{isFirstSupervisor ? t('ApproveRla.firstRotationalSupervisorDetails') : t('ApproveRla.secondRotationalSupervisorDetails')}</h2>
                                            </Col>
                                            <Col sm="4" className="column-center">
                                                <span className="approvedDate">{t('ApproveRla.approvedOn')} : <span className="date">{(isFirstSupervisor ? rlaActionData?.firstRotationalSupervisor?.approvedOn : rlaActionData?.secondRotationSupervisor?.approvedOn)}</span></span>
                                            </Col>
                                        </Row>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('ApproveRla.approvalStatus')}</Label>
                                                        <MySelect
                                                            name='approvelStatus'
                                                            isDisabled={(values.oldApprovalStatus as any).value !== EApprovelActions.PENDING}
                                                            value={values.approvalStatus}
                                                            placeholder={t('ApproveRla.approvalStatus')}
                                                            onChange={(e) => selectApprovalStatus(e, setFieldValue)}
                                                            options={approvalOptions ? approvalOptions : []}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            onBlur={() => setFieldTouched('approvalStatus', true)}
                                                            noOptionsMessage={() => { t('ApproveRla.NoDataFound') }}
                                                        />
                                                        {errors.approvalStatus && touched.approvalStatus && (
                                                            <div className="text-danger">{errors.approvalStatus}</div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="4">
                                                    {(values.approvalStatus as any)?.value === EApprovelActions.REJECTED ? <FormGroup>
                                                        <Label>{t('ApproveRla.remarks')}</Label>
                                                        <MySelect
                                                            name='remarks'
                                                            isDisabled={((values.oldApprovalStatus as any)?.value === EApprovelActions.APPROVED || (values.oldApprovalStatus as any)?.value === EApprovelActions.REJECTED) ? true : (values.approvalStatus as any)?.value === EApprovelActions.PENDING}
                                                            value={values.remarks}
                                                            placeholder={t('ApproveRla.selectComments')}
                                                            onChange={(e) => setFieldValue('remarks', e ? e : '')}
                                                            options={rejectedOptions ? rejectedOptions : []}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            onBlur={() => setFieldTouched('remarks', true)}
                                                            noOptionsMessage={() => { t('ApproveRla.NoDataFound') }}
                                                        />
                                                        {errors.remarks && touched.remarks && (
                                                            <div className="text-danger">{errors.remarks}</div>
                                                        )}
                                                    </FormGroup>
                                                        : <FormGroup>
                                                            <Label>{t('ApproveRla.remarks')}</Label>
                                                            <Field placeholder={t('ApproveRla.supervisorComments')} disabled={((values.oldApprovalStatus as any)?.value === EApprovelActions.APPROVED || (values.oldApprovalStatus as any)?.value === EApprovelActions.REJECTED) ? true : (values.approvalStatus as any)?.value === EApprovelActions.PENDING} as='textarea' name='remarks' className="comments" rows={1} />
                                                            <ErrorMessage name='remarks' component='div' className='text-danger' />
                                                        </FormGroup>}
                                                </Col>
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('ApproveRla.signature')}</Label>
                                                        <div className="terms"><Field type="checkbox" name='signature' disabled={((values.oldApprovalStatus as any)?.value === EApprovelActions.APPROVED || (values.oldApprovalStatus as any)?.value === EApprovelActions.REJECTED) ? true : (values.approvalStatus as any)?.value !== EApprovelActions.APPROVED} />{t('ApproveRla.acceptanceofAgreement')}</div>
                                                        <ErrorMessage name='signature' component='div' className='text-danger' />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>
                                    <hr />
                                    <div className="top-section">
                                        <Row>
                                            <Col sm="6">
                                                <h2>{!isFirstSupervisor ? t('ApproveRla.firstRotationalSupervisorDetails') : t('ApproveRla.secondRotationalSupervisorDetails')}</h2>
                                            </Col>
                                        </Row>
                                        <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="4">
                                                    <FormGroup>
                                                        <Label>{t('ApproveRla.approvalStatus')}</Label>
                                                        <InputGroup className="disabled-item">
                                                            <Input disabled value={!isFirstSupervisor ? rlaActionData?.firstRotationalSupervisor?.status : rlaActionData?.secondRotationSupervisor?.status} />
                                                            <InputGroupAddon addonType="append">
                                                                <InputGroupText>
                                                                    {!isFirstSupervisor && (rlaActionData?.firstRotationalSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                                                                        rlaActionData?.firstRotationalSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                                                                            rlaActionData?.firstRotationalSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-')
                                                                    }
                                                                    {isFirstSupervisor && (rlaActionData?.secondRotationSupervisor?.status === EApprovelActions.APPROVED ? <img src={Approved} className="icon" alt="" /> :
                                                                        rlaActionData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={Rejected} className="icon" alt="" /> :
                                                                            rlaActionData?.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : '-')
                                                                    }
                                                                </InputGroupText>
                                                            </InputGroupAddon>
                                                        </InputGroup>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </div>
                                    <Row className="sub-form-footer mt-3 mr-3">
                                        <button className="cancel-button" type='button' onClick={goBackToRotationsRlaView}>{t('ActionNames.cancel')}</button>
                                        {actionType !== EOprationalActions.SELECT && <button className="btn blue-button" disabled={!(dirty)} type='submit'>{t('ActionNames.submit')}</button>}
                                    </Row>
                                </Form>
                            }
                        }
                    </Formik>

                </div>
            </div>

        </>
    )
}
export default React.memo(ApproveRLAActions);