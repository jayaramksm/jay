import React from 'react';
import { Row, Col } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { IRla } from '../../../models/approveRlaModel';
import { setApproveRlasActionTypeData, setSearchApproveRlasData } from '../../../store/actions';
import { EOprationalActions } from '../../../models/utilitiesModel';


const ApproveRLAFilter: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionData: IRla[] = useSelector((state: any) => {
        if (state?.approveRlasReducer?.actionData)
            return state.approveRlasReducer.actionData;
        else return undefined;
    });

    const goBackToTraineeView = () => {
        dispatch(setApproveRlasActionTypeData(EOprationalActions.UNSELECT, null, null))
    }

    const updateSearchKey = (e) => {
        dispatch(setSearchApproveRlasData(e?.target?.value))
    }

    return (
        <>
            <Row className="compHeading pr-2">
                {!actionData && <Col>
                    <h2>{t('ApproveRla.rotationalLearningAgreements')}</h2>
                </Col>}
                {actionData && <Col className="breadcrumbs">
                    <div>
                        <span onClick={goBackToTraineeView} className='pointer'>{t('ApproveRla.rotationalLearningAgreements')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{actionData?.[0].traineeName}</span>
                    </div>
                </Col>}
                <div className="rgtFilter">
                    <div className="search-box filtericon">
                        <div className="search-text"><input type="text" onChange={updateSearchKey} placeholder={t('ApproveRla.search')}></input><i className="ti-search icon"></i></div>
                    </div>
                </div>
            </Row>
        </>
    )
}
export default React.memo(ApproveRLAFilter);