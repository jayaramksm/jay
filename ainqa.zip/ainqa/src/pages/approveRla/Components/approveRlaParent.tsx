import React, { useContext } from 'react';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/approveRlaContext';

const ApproveGLAParent: React.FC = () => {

    const context = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.approveRlasReducer?.actionType)
            return state.approveRlasReducer.actionType;
        else return EOprationalActions.UNSELECT
    });

    return (
        <>
            <div className="flexLayout maincontent">
                {(actionType === EOprationalActions.UNSELECT || actionType === EOprationalActions.ADD) && <context.approveRLAFilter />}
                {actionType === EOprationalActions.UNSELECT && <context.approveRLATraineeViewParnet />}
                {actionType === EOprationalActions.ADD && <context.approveRLAofRotationsViewParent />}
                {(actionType === EOprationalActions.EDIT || actionType === EOprationalActions.SELECT) && <context.approveRLAActions />}
            </div>
        </>
    )
}

export default React.memo(ApproveGLAParent);