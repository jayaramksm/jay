import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/approveRlaContext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { IRla } from '../../../models/approveRlaModel';
import groupBy from 'lodash/groupBy';
import { PaginationComponent } from '../../utilities/PaginationComponent';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { setApproveRlasPaginationCurrentPageValue } from '../../../store/actions';


const ApproveRLATraineeViewParnet: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const approveRlasData: IRla[] = useSelector((state: any) => {
        if (state?.approveRlasReducer?.approveRlasData)
            return state.approveRlasReducer.approveRlasData;
        else return undefined
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approveRlasReducer?.searchKey)
            return state.approveRlasReducer.searchKey;
        else return ''
    });

    const currentPage: number = useSelector((state: any) => state?.approveRlasReducer?.paginationCurrentPage || 0);


    const approveRlasGroupedData = Object.entries(groupBy(approveRlasData, 'traineeId'));

    const approveRlasGroupedFilterData: any = (approveRlasGroupedData?.length && searchKey !== '') ? approveRlasGroupedData?.filter((x: any) => (
        searchKey !== '' ? x?.[1][0].traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : approveRlasGroupedData;

    let pagesCount: number = Math.ceil((approveRlasGroupedFilterData ? approveRlasGroupedFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setApproveRlasPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setApproveRlasPaginationCurrentPageValue(index));
    };

    console.log('ApproveRLATraineeViewParnet=>', approveRlasData, approveRlasGroupedFilterData);

    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table approvepla-table">
                                <thead>
                                    <tr>
                                        <th>{t('ApproveRla.traineeName')}</th>
                                        <th>{t('ApproveRla.latestRlaSubmitedDate')}</th>
                                        <th className="column-center">{t('ApproveRla.approvalStatus')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        approveRlasData && approveRlasGroupedFilterData?.length > 0 && approveRlasGroupedFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                                            <ParentContext.Provider value={x[0]} key={x[0]}>
                                                <context.approveRLATraineeView />
                                            </ParentContext.Provider>
                                        ))
                                    }
                                </tbody>
                            </table>
                            {approveRlasData && (approveRlasGroupedFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('ApproveRla.NoDataFound')}</h6></div>}
                        </div>
                        {approveRlasGroupedFilterData && approveRlasGroupedFilterData.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(ApproveRLATraineeViewParnet);