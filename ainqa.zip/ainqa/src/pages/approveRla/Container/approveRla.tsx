import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, getApproveRlasDataRequest, resetAllApproveRlasStateRequest, cancelAllPendingApproveRlasRequest } from '../../../store/actions';
import { SuperParentContext } from './approveRlaContext';
import { ApproveRLAActions, ApproveRLAParent, ApproveRLAFilter, ApproveRLAofRotationsView, ApproveRLAofRotationsViewParent, ApproveRLATraineeView, ApproveRLATraineeViewParnet } from './approveRlaIndex';
interface IProps {
    activateAuthLayout;
    getApproveRlasDataRequest;
    resetAllApproveRlasStateRequest;
    cancelAllPendingApproveRlasRequest;
}
class Rlas extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {
            approveRLAActions: ApproveRLAActions,
            approveRLAFilter: ApproveRLAFilter,
            approveRLAofRotationsView: ApproveRLAofRotationsView,
            approveRLAofRotationsViewParent: ApproveRLAofRotationsViewParent,
            approveRLATraineeView: ApproveRLATraineeView,
            approveRLATraineeViewParnet: ApproveRLATraineeViewParnet
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllApproveRlasStateRequest();
        this.props.getApproveRlasDataRequest();
    }
    componentWillUnmount() {
        this.props.cancelAllPendingApproveRlasRequest();
        this.props.resetAllApproveRlasStateRequest();
    }
    render() {
        return (

            <SuperParentContext.Provider value={this.state}>
                <ApproveRLAParent />
            </SuperParentContext.Provider>

        )
    }
}


export default connect(null, { activateAuthLayout, getApproveRlasDataRequest, resetAllApproveRlasStateRequest, cancelAllPendingApproveRlasRequest })(Rlas);