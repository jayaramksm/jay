import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Pagination, PaginationItem, PaginationLink } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import EditIcon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';
import Approved from '../../images/Approved.svg';
import Deactive from '../../images/Deactive.svg';

import Select from 'react-select';

class UniversityManagement1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            activeTab: "1",
            fileName: "No file Choosen"
        };
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    countryOptions = [{ value: 'malaysia', label: 'Abc, Malaysia' },
    { value: 'singapore', label: 'Xyz, Singapor' }];

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of Universities</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box">
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Add University</button>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            <div className="main-table">
                                <div className="tbl-parent table-responsive">
                                    <table className="w100 myTable universitiesTable table">
                                        <thead>
                                            <tr>
                                                <th>University Name</th>
                                                <th>University Code</th>
                                                <th>University Country and State</th>
                                                <th>Primary Contact Name</th>
                                                <th>Secondary Contact Name</th>
                                                <th className="column-center">Active Status</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>UM</td>
                                                <td>UM01</td>
                                                <td>Abc, Malaysia</td>
                                                <td>Abu</td>
                                                <td>Vidya</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td className="column-center">
                                                    <img src={Deactive} className="actionicon pointer" alt="Deactive University"></img>
                                                    <img src={EditIcon} className="actionicon pointer" alt="Edit University"></img>
                                                    <img src={Delete} className="actionicon pointer" alt="Delete University"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>US</td>
                                                <td>US02</td>
                                                <td>Xyz, Singapore</td>
                                                <td>Asif</td>
                                                <td>Vidya</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td className="column-center">
                                                    <img src={Deactive} className="actionicon pointer" alt="Deactive University"></img>
                                                    <img src={EditIcon} className="actionicon pointer" alt="Edit University"></img>
                                                    <img src={Delete} className="actionicon pointer" alt="Delete University"></img>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div className="pagination">
                                        <Pagination aria-label="Page navigation example">
                                            <PaginationItem>
                                                <PaginationLink first href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink previous href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    1
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    2
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    3
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    4
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    5
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink next href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink last href="#" />
                                            </PaginationItem>
                                        </Pagination>
                                    </div>
                                </div>
                            </div>

                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Universities</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Add University</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="top-section">
                                <h2>University Details</h2>
                                <div className="details-section">
                                    <Row className="vhcenter mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University Name</Label>
                                                <Input type="text" placeholder="University of Malaysia"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University Code</Label>
                                                <Input type="text" placeholder="UM01"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University Country and State</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.countryOptions}
                                                    placeholder="Select Country"
                                                    value={{ value: 'malaysia', label: 'Abc, Malaysia' }}
                                                />
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>University Location</Label>
                                                <Input type="text" placeholder="Enter Location"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>ZIP Code</Label>
                                                <Input type="text" placeholder="Enter ZIP Code"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Website Address</Label>
                                                <Input type="text" placeholder="Enter Website Address"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                                <hr />
                                <h2>Primary Contact Details</h2>
                                <div className="details-section">
                                    <Row className="vhcenter mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Primary Contact Name</Label>
                                                <Input type="text" placeholder="Enter Name"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Primary Contact Designation</Label>
                                                <Input type="text" placeholder="Enter Designation"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Primary Contact Number</Label>
                                                <Input type="text" placeholder="Enter Number"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Primary Contact Email Id</Label>
                                                <Input type="text" placeholder="Enter Email Id"></Input>
                                            </FormGroup>
                                        </Col>

                                    </Row>
                                </div>
                                <hr />
                                <h2>Secondary Contact Details</h2>
                                <div className="details-section">
                                    <Row className="vhcenter mt-3">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Secondary Contact Name</Label>
                                                <Input type="text" placeholder="Enter Name"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Secondary Contact Designation</Label>
                                                <Input type="text" placeholder="Enter Designation"></Input>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Secondary Contact Number</Label>
                                                <Input type="text" placeholder="Enter Number"></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Secondary Contact Email Id</Label>
                                                <Input type="text" placeholder="Enter Email Id"></Input>
                                            </FormGroup>
                                        </Col>

                                    </Row>


                                    <Row className="sub-form-footer mt-3">
                                        <button className="cancel-button">Cancel</button>&nbsp;<button className="blue-button">Create</button>
                                    </Row>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(UniversityManagement1));