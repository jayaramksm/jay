import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/surgicalElogbookContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { IPortfolio, IEvidenceSurgicalElogbookModel } from '../../../../models/evidenceSurgicalElogbookModel';
import { setEvidenceSurgicalElogbookPaginationCurrentPageValue } from '../../../../store/actions';
import groupBy from 'lodash/groupBy';
import { ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';



const SurgicalElogbookTraineeViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;


    const portfoliosData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.portfoliosData)
            return (state.evidenceSurgicalElogbookReducer as IEvidenceSurgicalElogbookModel)?.portfoliosData;
        else return undefined;
    });

    const currentPage: number = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.paginationCurrentPage)
            return (state.evidenceSurgicalElogbookReducer as IEvidenceSurgicalElogbookModel).paginationCurrentPage;
        else return 0;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.searchKey)
            return state.evidenceSurgicalElogbookReducer.searchKey;
        else return ''
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });
    const role = userDto?.roles?.roleCode;

    const EvidenceSurgicalElogbookGroupedData = Object.entries(groupBy(portfoliosData, 'traineeId'));

    const portfoliosFilterData: any = (EvidenceSurgicalElogbookGroupedData?.length && searchKey !== '') ? EvidenceSurgicalElogbookGroupedData?.filter((x: any) => (
        searchKey !== '' ? x?.[1][0].traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : EvidenceSurgicalElogbookGroupedData;

    let pagesCount: number = Math.ceil((portfoliosFilterData ? portfoliosFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setEvidenceSurgicalElogbookPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setEvidenceSurgicalElogbookPaginationCurrentPageValue(index));
    };

    console.log(' SurgicalElogbookTraineeViewParent', { portfoliosFilterData, portfoliosData })

    return (
        <>
            <div className="tbl-parent table-responsive">
                <table className="w100 myTable evt-table table">
                    <thead>
                        <tr>
                            <th> {t('EvidenceSurgicalElogbook.traineeName')}</th>
                            <th> {t('EvidenceSurgicalElogbook.programName')}</th>
                            {role === ERoleDesc.ROTATIONSUPERVISOR && <th> {t('EvidenceSurgicalElogbook.stage')}</th>}
                            {role === ERoleDesc.ROTATIONSUPERVISOR && <th> {t('EvidenceSurgicalElogbook.rotations')}</th>}
                        </tr>
                    </thead>
                    <tbody>
                        {
                            portfoliosData && portfoliosFilterData?.length > 0 && portfoliosFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                                <ParentContext.Provider value={x[0]} key={x[0]}>
                                    <context.surgicalElogbookTraineeView />
                                </ParentContext.Provider>
                            ))
                        }
                    </tbody>
                </table>
                {portfoliosData && (portfoliosFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('EvidenceSurgicalElogbook.noDataFound')}</h6></div>}
            </div>
            {portfoliosFilterData && portfoliosFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}
export default React.memo(SurgicalElogbookTraineeViewParent);