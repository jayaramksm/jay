import React, { useContext } from 'react';
import { ParentContext } from '../Container/surgicalElogbookContext';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import View from '../../../../images/View.svg';
import { setEvidenceSurgicalElogbookActionTypeAndActionData } from '../../../../store/actions';
import { IPortfolio, IEvidenceSurgicalElogbookModel } from '../../../../models/evidenceSurgicalElogbookModel';
import { useTranslation } from 'react-i18next';


const SurgicalElogbookView: React.FC = () => {
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);
    const { t } = useTranslation('translations');

    const portfoliosData: IPortfolio | undefined = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.portfoliosData?.length) {
            let portfolioData = (state.evidenceSurgicalElogbookReducer as IEvidenceSurgicalElogbookModel).portfoliosData;
            return portfolioData.find(x => x.portfolioId === context);
        } else
            return undefined;
    });
    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.actionData)
            return state.evidenceSurgicalElogbookReducer.actionData;
        else return undefined
    });


    const ViewPortfolio = () => {
        dispatch(setEvidenceSurgicalElogbookActionTypeAndActionData(EOprationalActions.SELECT, actionData, portfoliosData));
    };

    console.log("surgicalElogbookView==>", portfoliosData);

    return (
        <>
            <tr>
                <td>{portfoliosData?.stageName}</td>
                <td>{portfoliosData?.rotationName}</td>
                <td> {portfoliosData?.code}</td>
                {/* <td style={{ position: 'relative' }}><span className="elip-more">-</span> {false && <span className="em-icon"><i className="icon-moreicon"></i></span>}</td> */}
                <td> {portfoliosData?.isAssessed ? t('EvidenceSurgicalElogbook.assessed') : t('EvidenceSurgicalElogbook.nonAssessed')}</td>
                {/* <td> {portfoliosData?.firstRotationSupervisor?.supervisorName}</td> */}
                {/* <td className="column-center">{portfoliosData?.firstRotationSupervisor?.status ? (portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-'}</td> */}
                {/* <td> {portfoliosData?.secondRotationSupervisor?.supervisorName}</td> */}
                {/* <td className="column-center">{portfoliosData?.secondRotationSupervisor?.status ? (portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-'}</td> */}
                <td>{(portfoliosData?.completedDate)}</td>
                <td className="column-center">
                    <span><img src={View} onClick={ViewPortfolio} className="actionicon pointer" alt=""></img></span>
                </td>
            </tr>

        </>

    )
}
export default React.memo(SurgicalElogbookView);