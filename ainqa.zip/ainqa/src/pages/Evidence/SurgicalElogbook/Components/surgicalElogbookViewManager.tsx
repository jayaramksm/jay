import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/surgicalElogbookContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { IPortfolio, IEvidenceSurgicalElogbookModel } from '../../../../models/evidenceSurgicalElogbookModel';
import { setEvidenceSurgicalElogbookPaginationCurrentPageValue } from '../../../../store/actions';

const SurgicalElogbookViewManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const { t } = useTranslation('translations');
    let portfoliosData: IPortfolio[] | undefined | any;


    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.actionData)
            return state.evidenceSurgicalElogbookReducer.actionData;
        else return undefined
    });
    portfoliosData = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.portfoliosData)
            return (state.evidenceSurgicalElogbookReducer as IEvidenceSurgicalElogbookModel)?.portfoliosData;
        else return undefined;
    });
    if (actionData)
        portfoliosData = actionData


    const currentPage: number = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.paginationCurrentPage)
            return (state.evidenceSurgicalElogbookReducer as IEvidenceSurgicalElogbookModel).paginationCurrentPage;
        else return 0;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.searchKey)
            return state.evidenceSurgicalElogbookReducer.searchKey;
        else return ''
    });

    const portfoliosFilterData: IPortfolio[] | undefined = (portfoliosData?.length && searchKey !== '') ? portfoliosData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName?.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : portfoliosData;

    let pagesCount: number = Math.ceil((portfoliosFilterData ? portfoliosFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setEvidenceSurgicalElogbookPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setEvidenceSurgicalElogbookPaginationCurrentPageValue(index));
    };

    console.log("surgicalElogbookViewManager==>", portfoliosData, context, portfoliosFilterData);

    return (
        <div className="tbl-parent table-responsive h-100 pr-2">
            <table className="myTable evd-selogtable table">
                <thead>
                    <tr>
                        <th> {t('EvidenceSurgicalElogbook.stage')}</th>
                        <th>  {t('EvidenceSurgicalElogbook.rotations')}</th>
                        <th>  {t('EvidenceSurgicalElogbook.code')}</th>
                        {/* <th> {t('EvidenceSurgicalElogbook.ELAEPA')}</th> */}
                        <th>  {t('EvidenceSurgicalElogbook.AssessedNon-Assessed')}</th>
                        <th>  {t('EvidenceSurgicalElogbook.completedDate')}</th>
                        <th className="column-center">  {t('EvidenceSurgicalElogbook.actions')}</th>
                    </tr>
                </thead>
                <tbody>
                    {portfoliosFilterData && portfoliosFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                        <ParentContext.Provider value={x.portfolioId} key={x.portfolioId}>
                            <context.surgicalElogbookView />
                        </ParentContext.Provider>
                    ))}
                </tbody>
            </table>
            {(portfoliosFilterData && portfoliosFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('EvidenceSurgicalElogbook.noDataFound')}</h6></div>}
            {portfoliosFilterData && portfoliosFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>}
        </div>
    )
}
export default React.memo(SurgicalElogbookViewManager);