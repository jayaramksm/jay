import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/surgicalElogbookContext';
import { useSelector } from 'react-redux';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';


const SurgicalElogbookParentManager: React.FC = () => {

    const context: any = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.actionType)
            return state.evidenceSurgicalElogbookReducer.actionType
        else return EOprationalActions.UNSELECT
    });
    const formModelData = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.assessmentModelData) {
            return (state.evidenceSurgicalElogbookReducer)?.assessmentModelData
        } else {
            return EOprationalActions.UNSELECT
        }
    });
    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });
    const role = userDto?.roles?.roleCode;
    console.log('SurgicalElogbookParentManager==>', actionType)
    return (
        <>
            {(actionType === EOprationalActions.UNSELECT || actionType === EOprationalActions.ADD) && <context.surgicalElogbookFilter />}
            <div className="flexScroll">
                <div className="main-table h-100">
                    {((role === ERoleDesc.Traninee && actionType === EOprationalActions.UNSELECT) || actionType === EOprationalActions.ADD) && <context.surgicalElogbookViewManager />}
                    {(role === ERoleDesc.ROTATIONSUPERVISOR || role === ERoleDesc.EDUCATIONALSUPERVISOR) && actionType === EOprationalActions.UNSELECT && <context.surgicalElogbookTraineeViewParent />}
                    {(actionType === EOprationalActions.SELECT) && <context.surgicalElogbookAction />}
                    {formModelData?.isOpen && <context.surgicalElogbookAssessmentforms />}

                </div>
            </div>
        </>
    )
}
export default React.memo(SurgicalElogbookParentManager);