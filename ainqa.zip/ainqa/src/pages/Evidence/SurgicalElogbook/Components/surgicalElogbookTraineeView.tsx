import React, { useContext } from 'react';
import { ParentContext } from '../Container/surgicalElogbookContext';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import View from '../../../../images/View.svg';
import { setEvidenceSurgicalElogbookActionTypeAndActionData } from '../../../../store/actions';
import { IPortfolio, IEvidenceSurgicalElogbookModel } from '../../../../models/evidenceSurgicalElogbookModel';
import { useTranslation } from 'react-i18next';
import groupBy from 'lodash/groupBy';
import maxBy from 'lodash/maxBy';

const SurgicalElogbookTraineeView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);

    const portfolioData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.portfoliosData)
            return (state.evidenceSurgicalElogbookReducer as IEvidenceSurgicalElogbookModel)?.portfoliosData;
        else return undefined;
    });

    const portfolioGroupedData = groupBy(portfolioData, 'traineeId');

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });
    const role = userDto?.roles?.roleCode;

    const goToTraineeRotationsRlaView = () => {
        dispatch(setEvidenceSurgicalElogbookActionTypeAndActionData(EOprationalActions.ADD, portfolioGroupedData[context], null))
    };
    const getLatestSubmite = () => {
        return maxBy(portfolioGroupedData[context], (data) => +(new Date(data.updatedOn)));
    }
    console.log('SurgicalElogbookTraineeView', { userId: portfolioGroupedData[context][0]?.firstRotationSupervisor?.supervisorId, portfolioData, portfolioGroupedData, context })

    return (
        <>
            {portfolioData && portfolioGroupedData && <tr>
                <td onClick={goToTraineeRotationsRlaView} className='pointer'><span className="pointer ActionStatus">{portfolioGroupedData[context][0]?.traineeName}</span></td>
                <td>{portfolioGroupedData[context][0]?.programName || '-'}</td>
                {role === ERoleDesc.ROTATIONSUPERVISOR && <td>{getLatestSubmite()?.stageName}</td>}
                {role === ERoleDesc.ROTATIONSUPERVISOR && <td>{getLatestSubmite()?.rotationName}</td>}
            </tr>}
        </>
    )
}
export default React.memo(SurgicalElogbookTraineeView);