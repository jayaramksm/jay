import React from 'react';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { setEvidenceSurgicalElogbookActionTypeAndActionData, setSearchEvidenceSurgicalElogbookData } from '../../../../store/actions';
import { useTranslation } from 'react-i18next';
import { IPortfolio } from '../../../../models/evidenceWbaModel';
import { EOprationalActions } from 'models/utilitiesModel';

const SurgicalElogbookFilter: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const updateSearchKey = (e) => {
        dispatch(setSearchEvidenceSurgicalElogbookData(e?.target?.value))
    };
    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.actionData)
            return state.evidenceSurgicalElogbookReducer.actionData;
        else return undefined
    });
    const goBackToTraineeView = () => {
        dispatch(setEvidenceSurgicalElogbookActionTypeAndActionData(EOprationalActions.UNSELECT, null, null))
    }
    const showFilter = useSelector((state: any) => !!(state?.evidenceSurgicalElogbookReducer?.portfoliosData?.length > 2));

    return (
        <>
            <Row className="compHeading mb-2 pr-2">
                {!actionData && <Col className="draftsheading">
                    <h3 className="page-header header-title">  {t('EvidenceSurgicalElogbook.surgicalLogbook')}</h3>
                </Col>}
                {actionData && <Col className="breadcrumbs">
                    <div>
                        <span onClick={goBackToTraineeView} className='pointer'> {t('EvidenceSurgicalElogbook.surgicalLogbook')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">{actionData?.[0].traineeName}</span>
                    </div>
                </Col>}

                {showFilter && <div className="rgtFilter">
                    <div className="search-box filtericon">
                        <div className="search-text"><input type="text" onChange={updateSearchKey} placeholder="Search"></input><i className="ti-search icon"></i></div>
                    </div>
                </div>}
            </Row>
        </>
    )
}

export default React.memo(SurgicalElogbookFilter)
