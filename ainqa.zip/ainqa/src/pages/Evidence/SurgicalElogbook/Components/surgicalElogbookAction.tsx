import React from 'react';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Row, Col, Input, FormGroup, Label } from 'reactstrap';
import View from '../../../../images/View.svg';
import { ECodeOptions, ESubCode, IPortfolio } from '../../../../models/evidenceSurgicalElogbookModel';
import { evidenceSurgicalElogbookAssessmentFormModelOpenOrClose, setEvidenceSurgicalElogbookActionTypeAndActionData } from '../../../../store/actions';



const SurgicalElogbookAction: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const portfolioActionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.portfolioActionData)
            return state.evidenceSurgicalElogbookReducer.portfolioActionData;
        else return undefined
    });
    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.actionData)
            return state.evidenceSurgicalElogbookReducer.actionData;
        else return undefined
    });

    const getWbsFullName = (value) => {
        let wbaFullName: string = '';
        switch (value) {
            case ESubCode.CBD:
                wbaFullName = t('EvidenceSurgicalElogbook.cbd')
                break;
            case ESubCode.DOPS:
                wbaFullName = t('EvidenceSurgicalElogbook.dops')
                break;
            case ESubCode.CEX:
                wbaFullName = t('EvidenceSurgicalElogbook.cex')
                break;
            case ESubCode.DOCE:
                wbaFullName = t('EvidenceSurgicalElogbook.doce')
                break;
            case ESubCode.MSF:
                wbaFullName = t('EvidenceSurgicalElogbook.msf')
                break;
            case ESubCode.PBA:
                wbaFullName = t('EvidenceSurgicalElogbook.pba')
                break;
            case ESubCode.PSA:
                wbaFullName = t('EvidenceSurgicalElogbook.psa')
                break;
            case ESubCode.NOTSA:
                wbaFullName = t('EvidenceSurgicalElogbook.notsa')
                break;
            case ESubCode.SURLOG:
                wbaFullName = t('EvidenceSurgicalElogbook.surlog');
                break;
        }
        return wbaFullName
    }


    const formModelOpen = (type) => {
        const data = { isOpen: true, title: (portfolioActionData?.code === ECodeOptions.SURLOG ? getWbsFullName(portfolioActionData?.code?.toLowerCase()) : getWbsFullName(portfolioActionData?.wbaName)), actionData: portfolioActionData?.formData ? JSON.parse(portfolioActionData?.formData) : '', actionType: type, evaluatorFormData: portfolioActionData?.evaluatorFeedBack }
        dispatch(evidenceSurgicalElogbookAssessmentFormModelOpenOrClose(data));
    };


    const back = () => {
        dispatch(setEvidenceSurgicalElogbookActionTypeAndActionData(EOprationalActions.ADD, actionData, null));
    }

    console.log('surgicalElogbookAction==>', portfolioActionData)
    return (

        <>
            <div className="flexLayout maincontent">
                <Row>
                    <Col className="breadcrumbs">
                        <div>
                            <span className='pointer' onClick={back}>{t('EvidenceSurgicalElogbook.surgicalLogbook')} </span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="active"> {t('EvidenceSurgicalElogbook.viewEntry')}</span>
                        </div>
                    </Col>
                </Row>
                <div className="flexScroll pr-3">
                    <div className="top-section">
                        <div className="details-section">
                            <Row className="mt-3">
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.stage')}</Label>
                                        <Input type="text" value={portfolioActionData?.stageName || '-'} disabled className='form-control'></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.rotation')}</Label>
                                        <Input type="text" value={portfolioActionData?.rotationName || '-'} disabled className='form-control'></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.hospital')}</Label>
                                        <Input type="text" value={(portfolioActionData?.hospitalName ? portfolioActionData?.hospitalName : `Other - ${portfolioActionData?.otherHospitalName}`)} name="hospital" disabled id="hospital"></Input>
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.code')}</Label>
                                        <Input type="text" value={portfolioActionData?.code || ''} name="hospital" disabled id="hospital"></Input>
                                    </FormGroup>
                                </Col>
                                {/* <Col sm="4">
                                    <FormGroup>
                                        <Label>  {t('EvidenceSurgicalElogbook.subCode')}</Label>
                                        <Input type="text" value={portfolioActionData?.wbaName || ''} name="hospital" disabled id="hospital"></Input>
                                    </FormGroup>
                                </Col> */}
                                {/* <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('EvidenceSurgicalElogbook.1stRotationalSupervisor')}</Label>
                                        <Input type="text" value={portfolioActionData?.firstRotationSupervisor?.supervisorName || ''} name="rsupervisorone" disabled></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('EvidenceSurgicalElogbook.2ndRotationalSupervisor')}</Label>
                                        <Input type="text" value={portfolioActionData?.secondRotationSupervisor?.supervisorName || ''} name="rsupervisortwo" disabled></Input>
                                    </FormGroup>
                                </Col> */}
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.dueDate')}</Label>
                                        <Input type="text" disabled value={portfolioActionData?.dueDate || null} ></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.completedDate')}</Label>
                                        <Input type="text" disabled value={portfolioActionData?.completedDate || null} ></Input>
                                    </FormGroup>
                                </Col>
                                {/* <Col sm="4">
                                    <FormGroup check className="assessed pl-0">
                                        <Label check>
                                            <Input type="checkbox" disabled value={portfolioActionData?.isAssessed} ></Input>
                                            {t('EvidenceSurgicalElogbook.thiswillbepartofAssessed')}
                                        </Label>
                                    </FormGroup>
                                </Col> */}
                            </Row>
                        </div>
                    </div>
                    <hr />
                    <div className="top-section">
                        <h2>  {t('EvidenceSurgicalElogbook.artifactUploads')}</h2>
                        <div className="details-section mt-3">
                            {portfolioActionData?.fileData && portfolioActionData?.fileData?.map((x: any, i) => (
                                <Row key={i}>
                                    <div className="ArtifactName w400">
                                        <span>{x?.fileName}</span>
                                    </div>
                                </Row>
                            ))}
                        </div>
                    </div>
                    <hr />

                    {portfolioActionData.formData && JSON.parse(portfolioActionData?.formData) && 
                    <div className="top-section">
                    <h2>{t('EvidenceSurgicalElogbook.workplacebasedAssessmentDetails')}</h2>
                    <div className="details-section mt-3">
                    <div className="tbl-parent">
                        <table className="w100 myTable wba-viewtbl table table-bordered">
                            <thead>
                                <tr>
                                    <th> {t('EvidenceSurgicalElogbook.workplacebasedAssessmentName')} </th>
                                    <th className="column-center"> {t('EvidenceSurgicalElogbook.actions')} </th>
                                    {/* <th>&nbsp;</th> */}
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{(portfolioActionData?.code === ECodeOptions.SURLOG ? getWbsFullName(portfolioActionData?.code?.toLowerCase()) : getWbsFullName(portfolioActionData?.wbaName))}  </td>
                                    <td className="column-center">
                                        <span><img src={View} onClick={() => formModelOpen(EOprationalActions.SELECT)} className="actionicon pointer" alt=""></img></span>
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </div>
                    </div>
                    }
                    {/* <div className="top-section">
                        <Row className="mr-3 align-items-center">
                            <Col sm="6" xs="12">
                                <h2 className="mt-0"> {t('EvidenceSurgicalElogbook.approvalDetails')}</h2>
                            </Col>
                        </Row>
                        <div className="details-section mt-3">
                            <Row>
                                <Col sm="6" xs="12">
                                    <h2 className="mt-0"> {t('EvidenceSurgicalElogbook.1stRotationalSupervisor')}</h2>
                                </Col>
                                <Col sm="6" xs="12" className="text-right">
                                    <span className="approvedDate"> {portfolioActionData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? t('EvidenceSurgicalElogbook.rejectOn') : t('EvidenceSurgicalElogbook.approvedon')} <span className="date">
                                        {portfolioActionData?.firstRotationSupervisor?.approvedOn || '-'}
                                    </span></span>
                                </Col>
                            </Row>
                            <Row className="mt-3">

                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.approvalStatus')}</Label>
                                        <Input type="text" value={portfolioActionData?.firstRotationSupervisor?.status || ''} disabled></Input>
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceSurgicalElogbook.approverName')}</Label>
                                        <Input type="text" value={portfolioActionData?.firstRotationSupervisor?.supervisorName || ''} disabled></Input>
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('EvidenceSurgicalElogbook.comments')}</Label>
                                        <textarea value={portfolioActionData?.firstRotationSupervisor?.comments || ''} disabled className="comments" rows={1}></textarea>
                                    </FormGroup>
                                </Col>
                            </Row>
                            {portfolioActionData?.secondRotationSupervisor?.supervisorName && <>
                                <Row>
                                    <Col sm="6" xs="12">
                                        <h2 className="mt-0"> {t('EvidenceSurgicalElogbook.2ndRotationalSupervisor')}</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate"> {portfolioActionData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? t('EvidenceSurgicalElogbook.rejectOn') : t('EvidenceSurgicalElogbook.approvedon')} <span className="date">
                                            {portfolioActionData?.secondRotationSupervisor?.approvedOn || '-'}
                                        </span></span>
                                    </Col>
                                </Row>
                                <Row className="mt-3">

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('EvidenceSurgicalElogbook.approvalStatus')}</Label>
                                            <Input type="text" value={portfolioActionData?.secondRotationSupervisor?.status || ''} disabled></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('EvidenceSurgicalElogbook.approverName')}</Label>
                                            <Input type="text" value={portfolioActionData?.secondRotationSupervisor?.supervisorName || ''} disabled></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('EvidenceSurgicalElogbook.comments')}</Label>
                                            <textarea value={portfolioActionData?.secondRotationSupervisor?.comments || ''} disabled className="comments" rows={1}></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </>}
                        </div>
                    </div>
 */}

                    <div className="text-center mb-4">
                        <Row className="sub-form-footer mt-3 mr-3">
                            <button className="btn blue-button" type='button' onClick={back}>{t('ActionNames.back')}</button>
                        </Row></div>

                </div>
            </div>
        </>
    )
}

export default React.memo(SurgicalElogbookAction)