import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, resetAllEvidenceSurgicalElogbookStateRequest, cancelAllPendingEvidenceSurgicalElogbookRequest, getAllEvidenceSurgicalElogbookDataRequest } from '../../../../store/actions';
import { SuperParentContext } from './surgicalElogbookContext';
import {
    SurgicalElogbookAssessmentforms,
    SurgicalElogbookFilter,
    SurgicalElogbookParentManager,
    SurgicalElogbookView,
    SurgicalElogbookViewManager,
    SurgicalElogbookAction,
    SurgicalElogbookTraineeViewParent,
    SurgicalElogbookTraineeView
} from './surgicalElogbookIndex';
interface IProps {
    activateAuthLayout;
    cancelAllPendingEvidenceSurgicalElogbookRequest;
    resetAllEvidenceSurgicalElogbookStateRequest;
    getAllEvidenceSurgicalElogbookDataRequest
}
class SurgicalElogbook extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            surgicalElogbookAssessmentforms: SurgicalElogbookAssessmentforms,
            surgicalElogbookFilter: SurgicalElogbookFilter,
            surgicalElogbookView: SurgicalElogbookView,
            surgicalElogbookAction: SurgicalElogbookAction,
            surgicalElogbookViewManager: SurgicalElogbookViewManager,
            surgicalElogbookTraineeViewParent: SurgicalElogbookTraineeViewParent,
            surgicalElogbookTraineeView: SurgicalElogbookTraineeView
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllEvidenceSurgicalElogbookStateRequest();
        this.props.getAllEvidenceSurgicalElogbookDataRequest();
    }
    componentWillUnmount() {
        this.props.resetAllEvidenceSurgicalElogbookStateRequest();
        this.props.cancelAllPendingEvidenceSurgicalElogbookRequest();
    }
    render() {
        return (
            <div className="flexLayout maincontent">

                <SuperParentContext.Provider value={this.state}>
                    <SurgicalElogbookParentManager />
                </SuperParentContext.Provider>
            </div>
        )
    }
}


export default connect(null, { activateAuthLayout, resetAllEvidenceSurgicalElogbookStateRequest, cancelAllPendingEvidenceSurgicalElogbookRequest, getAllEvidenceSurgicalElogbookDataRequest })(SurgicalElogbook);