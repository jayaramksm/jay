import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, resetAllEvidenceWbaStateRequest, cancelAllPendingEvidenceWbaRequest, getAllEvidenceWbaDataRequest } from '../../../../store/actions';
import { SuperParentContext } from './wbasContext';
import {
    WbasAssessmentforms,
    WbasFilter,
    WbasParentManager,
    WbasView,
    WbasViewManager,
    WbasAction,
    WbasTraineeView,
    WbasTraineeViewParent
} from './wbasIndex';
interface IProps {
    activateAuthLayout;
    cancelAllPendingEvidenceWbaRequest;
    resetAllEvidenceWbaStateRequest;
    getAllEvidenceWbaDataRequest
}
class Wbas extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            wbasAssessmentforms: WbasAssessmentforms,
            wbasFilter: WbasFilter,
            wbasView: WbasView,
            wbasAction: WbasAction,
            wbasViewManager: WbasViewManager,
            wbasTraineeView: WbasTraineeView,
            wbasTraineeViewParent: WbasTraineeViewParent
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllEvidenceWbaStateRequest();
        this.props.getAllEvidenceWbaDataRequest();
    }
    componentWillUnmount() {
        this.props.resetAllEvidenceWbaStateRequest();
        this.props.cancelAllPendingEvidenceWbaRequest();
    }
    render() {
        return (
            <div className="flexLayout maincontent">

                <SuperParentContext.Provider value={this.state}>
                    <WbasParentManager />
                </SuperParentContext.Provider>
            </div>
        )
    }
}


export default connect(null, { activateAuthLayout, resetAllEvidenceWbaStateRequest, cancelAllPendingEvidenceWbaRequest, getAllEvidenceWbaDataRequest })(Wbas);