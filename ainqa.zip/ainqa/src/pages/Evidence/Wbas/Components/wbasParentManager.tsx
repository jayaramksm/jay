import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/wbasContext';
import { useSelector } from 'react-redux';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';


const WbasParentManager: React.FC = () => {

    const context: any = useContext(SuperParentContext);

    const actionType = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.actionType)
            return state.evidenceWbaReducer.actionType
        else return EOprationalActions.UNSELECT
    });
    const formModelData = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.assessmentModelData) {
            return (state.evidenceWbaReducer)?.assessmentModelData
        } else {
            return EOprationalActions.UNSELECT
        }
    });
    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });
    const role = userDto?.roles?.roleCode;

    return (
        <>
            {(actionType === EOprationalActions.UNSELECT || actionType === EOprationalActions.ADD) && <context.wbasFilter />}
            <div className="flexScroll">
                <div className="main-table h-100">
                    {(actionType === EOprationalActions.SELECT) && <context.wbasAction />}
                    {((role === ERoleDesc.Traninee && actionType === EOprationalActions.UNSELECT) || actionType === EOprationalActions.ADD) && <context.wbasViewManager />}
                    {(role === ERoleDesc.ROTATIONSUPERVISOR || role === ERoleDesc.EDUCATIONALSUPERVISOR) && actionType === EOprationalActions.UNSELECT && <context.wbasTraineeViewParent />}
                    {formModelData?.isOpen && <context.wbasAssessmentforms />}

                </div>
            </div>
        </>
    )
}
export default React.memo(WbasParentManager);