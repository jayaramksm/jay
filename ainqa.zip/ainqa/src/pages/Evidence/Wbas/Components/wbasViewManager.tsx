import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/wbasContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { IPortfolio, IEvidenceWbaModel } from '../../../../models/evidenceWbaModel';
import { setEvidenceWbaPaginationCurrentPageValue } from '../../../../store/actions';

const WbasViewManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;
    let portfoliosData: IPortfolio[] | undefined | any;

    const { t } = useTranslation('translations');
    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.actionData)
            return state.evidenceWbaReducer.actionData;
        else return undefined
    });
    if (actionData)
        portfoliosData = actionData
    portfoliosData = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.portfoliosData)
            return (state.evidenceWbaReducer as IEvidenceWbaModel)?.portfoliosData;
        else return undefined;
    });

    const currentPage: number = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.paginationCurrentPage)
            return (state.evidenceWbaReducer as IEvidenceWbaModel).paginationCurrentPage;
        else return 0;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.searchKey)
            return state.evidenceWbaReducer.searchKey;
        else return ''
    });

    const portfoliosFilterData: IPortfolio[] | undefined = (portfoliosData?.length && searchKey !== '') ? portfoliosData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName?.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : portfoliosData;

    let pagesCount: number = Math.ceil((portfoliosFilterData ? portfoliosFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setEvidenceWbaPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setEvidenceWbaPaginationCurrentPageValue(index));
    };

    console.log("WbasViewManager==>", portfoliosData, context, portfoliosFilterData);

    return (

        <div className="tbl-parent table-responsive h-100 pr-2">
            <table className="myTable evd-wbatable table">
                <thead>
                    <tr>
                        <th> {t('EvidenceWba.stage')}</th>
                        <th>  {t('EvidenceWba.rotations')}</th>
                        <th>  {t('EvidenceWba.code')}</th>
                        <th>  {t('EvidenceWba.subCode')}</th>
                        {/* <th> {t('EvidenceWba.ELAEPA')}</th> */}
                        <th>  {t('EvidenceWba.AssessedNon-Assessed')}</th>
                        <th>  {t('EvidenceWba.1stRotationalSupervisor')}</th>
                        <th>  {t('EvidenceWba.2ndRotationalSupervisor')}</th>
                        <th>  {t('EvidenceWba.finalApprovalDate')}</th>
                        <th>  {t('EvidenceWba.actions')}</th>
                    </tr>
                </thead>
                <tbody>
                    {portfoliosFilterData && portfoliosFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                        <ParentContext.Provider value={x.portfolioId} key={x.portfolioId}>
                            <context.wbasView />
                        </ParentContext.Provider>
                    ))}
                </tbody>
            </table>
            {(portfoliosFilterData && portfoliosFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('EvidenceWba.noDataFound')}</h6></div>}
            {portfoliosFilterData && portfoliosFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>}
        </div>
    )
}
export default React.memo(WbasViewManager);