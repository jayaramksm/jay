import React, { useContext } from 'react';
import { ParentContext } from '../Container/wbasContext';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import View from '../../../../images/View.svg';
import { setEvidenceWbaActionTypeAndActionData } from '../../../../store/actions';
import { IPortfolio, IEvidenceWbaModel } from '../../../../models/evidenceWbaModel';
import { useTranslation } from 'react-i18next'
import groupBy from 'lodash/groupBy';
import maxBy from 'lodash/maxBy';

const WbasTraineeView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);


    const portfolioData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.portfoliosData)
            return (state.evidenceWbaReducer as IEvidenceWbaModel)?.portfoliosData;
        else return undefined;
    });


    const portfolioGroupedData = groupBy(portfolioData, 'traineeId');
    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });
    const role = userDto?.roles?.roleCode;

    const goToTraineeRotationsRlaView = () => {
        dispatch(setEvidenceWbaActionTypeAndActionData(EOprationalActions.ADD, portfolioGroupedData[context], null))
    };

    let portfolioLatestData;
    if (role === ERoleDesc.ROTATIONSUPERVISOR) {
        portfolioLatestData = portfolioGroupedData[context]?.map(x => ({ ...x, latestApproved: (x?.secondRotationSupervisor?.approvedOn && x?.firstRotationSupervisor?.approvedOn) ? ((+new Date(x?.secondRotationSupervisor?.approvedOn) > +new Date(x?.firstRotationSupervisor?.approvedOn)) ? x?.secondRotationSupervisor?.approvedOn : x?.firstRotationSupervisor?.approvedOn) : (x?.secondRotationSupervisor?.approvedOn || x?.firstRotationSupervisor?.approvedOn || '-') }))
    }


    const getLatestSubmite = () => {
        if (portfolioLatestData)
            return maxBy(portfolioLatestData, (data) => +(new Date(data.latestApproved)));
    }

    console.log('WbasTraineeView', { portfolioData, portfolioGroupedData, context })

    return (
        <>
            {portfolioData && portfolioGroupedData && <tr>
                <td onClick={goToTraineeRotationsRlaView} className='pointer'><span className="pointer ActionStatus">{portfolioGroupedData[context][0]?.traineeName}</span></td>
                <td>{portfolioGroupedData[context][0]?.programName || '-'}</td>
                {role === ERoleDesc.ROTATIONSUPERVISOR && <td>{getLatestSubmite()?.stageName}</td>}
                {role === ERoleDesc.ROTATIONSUPERVISOR && <td>{getLatestSubmite()?.rotationName}</td>}
            </tr>}
        </>
    )
}
export default React.memo(WbasTraineeView);