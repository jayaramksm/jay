import React from 'react';
import { EApprovelActions, EOprationalActions } from '../../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Row, Col, Input, FormGroup, Label } from 'reactstrap';
import View from '../../../../images/View.svg';
import { ECodeOptions, ESubCode, IPortfolio } from '../../../../models/evidenceWbaModel';
import { evidenceWbaAssessmentFormModelOpenOrClose, setEvidenceWbaActionTypeAndActionData } from '../../../../store/actions';



const WbasAction: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.actionData)
            return state.evidenceWbaReducer.actionData;
        else return undefined
    });

    const portfolioActionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.portfolioActionData)
            return state.evidenceWbaReducer.portfolioActionData;
        else return undefined
    });

    const getWbsFullName = (value) => {
        let wbaFullName: string = '';
        switch (value) {
            case ESubCode.CBD:
                wbaFullName = t('EvidenceWba.cbd')
                break;
            case ESubCode.DOPS:
                wbaFullName = t('EvidenceWba.dops')
                break;
            case ESubCode.CEX:
                wbaFullName = t('EvidenceWba.cex')
                break;
            case ESubCode.DOCE:
                wbaFullName = t('EvidenceWba.doce')
                break;
            case ESubCode.MSF:
                wbaFullName = t('EvidenceWba.msf')
                break;
            case ESubCode.PBA:
                wbaFullName = t('EvidenceWba.pba')
                break;
            case ESubCode.PSA:
                wbaFullName = t('EvidenceWba.psa')
                break;
            case ESubCode.NOTSA:
                wbaFullName = t('EvidenceWba.notsa')
                break;
            case ESubCode.SURLOG:
                wbaFullName = t('EvidenceWba.surlog');
                break;
        }
        return wbaFullName
    }


    const formModelOpen = (type) => {
        const data = { isOpen: true, title: (portfolioActionData?.code === ECodeOptions.SURLOG ? getWbsFullName(portfolioActionData?.code?.toLowerCase()) : getWbsFullName(portfolioActionData?.wbaName)), actionData: portfolioActionData?.formData ? JSON.parse(portfolioActionData?.formData) : '', actionType: type, evaluatorFormData: portfolioActionData?.evaluatorFeedBack }
        dispatch(evidenceWbaAssessmentFormModelOpenOrClose(data));
    };


    const back = () => {
        dispatch(setEvidenceWbaActionTypeAndActionData(EOprationalActions.ADD, actionData, null));
    }

    console.log('WbasAction==>', portfolioActionData)
    return (

        <>
            <div className="flexLayout maincontent">
                <Row>
                    <Col className="breadcrumbs">
                        <div>
                            <span className='pointer' onClick={back}> {t('EvidenceWba.wBA')}</span>
                            <span><i className="ti-angle-right"></i></span>
                            <span className="active"> {t('EvidenceWba.viewEntry')}</span>
                        </div>
                    </Col>
                </Row>
                <div className="flexScroll pr-3">
                    <div className="top-section">
                        <div className="details-section">
                            <Row className="mt-3">
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.stage')}</Label>
                                        <Input type="text" value={portfolioActionData?.stageName || '-'} disabled className='form-control'></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.rotation')}</Label>
                                        <Input type="text" value={portfolioActionData?.rotationName || '-'} disabled className='form-control'></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.hospital')}</Label>
                                        <Input type="text" value={(portfolioActionData?.hospitalName ? portfolioActionData?.hospitalName : `Other - ${portfolioActionData?.otherHospitalName}`)} name="hospital" disabled id="hospital"></Input>
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.code')}</Label>
                                        <Input type="text" value={portfolioActionData?.code || ''} name="hospital" disabled id="hospital"></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>  {t('EvidenceWba.subCode')}</Label>
                                        <Input type="text" value={portfolioActionData?.wbaName || ''} name="hospital" disabled id="hospital"></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('EvidenceWba.1stRotationalSupervisor')}</Label>
                                        <Input type="text" value={portfolioActionData?.firstRotationSupervisor?.supervisorName || ''} name="rsupervisorone" disabled></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('EvidenceWba.2ndRotationalSupervisor')}</Label>
                                        <Input type="text" value={portfolioActionData?.secondRotationSupervisor?.supervisorName || '-'} name="rsupervisortwo" disabled></Input>
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.dueDate')}</Label>
                                        <Input type="text" disabled value={portfolioActionData?.dueDate || null} ></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.completedDate')}</Label>
                                        <Input type="text" disabled value={portfolioActionData?.completedDate || null} ></Input>
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup check className="assessed pl-0">
                                        <Label check>
                                            <Input type="checkbox" disabled value={portfolioActionData?.isAssessed} checked={portfolioActionData?.isAssessed} ></Input>
                                            {t('EvidenceWba.thiswillbepartofAssessed')}
                                        </Label>
                                    </FormGroup>
                                </Col>
                            </Row>
                        </div>
                    </div>
                    <hr />
                    <div className="top-section">
                        <h2>  {t('EvidenceWba.artifactUploads')}</h2>
                        <div className="details-section mt-3">
                            {portfolioActionData?.fileData && portfolioActionData?.fileData?.map((x: any, i) => (
                                <Row key={i}>
                                    <div className="ArtifactName w400">
                                        <span>{x?.fileName}</span>
                                    </div>
                                </Row>
                            ))}
                        </div>
                    </div>
                    <hr />

                    {portfolioActionData.formData && JSON.parse(portfolioActionData?.formData) && 
                    <div className="top-section">
                    <h2>{t('EvidenceWba.workplacebasedAssessmentDetails')}</h2>
                    <div className="details-section mt-3">
                    <div className="tbl-parent">
                        <table className="w100 myTable wba-viewtbl table table-bordered">
                            <thead>
                                <tr>
                                    <th> {t('EvidenceWba.workplacebasedAssessmentName')} </th>
                                    <th className="column-center"> {t('EvidenceWba.actions')} </th>
                                    {/* <th>&nbsp;</th> */}
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{(portfolioActionData?.code === ECodeOptions.SURLOG ? getWbsFullName(portfolioActionData?.code?.toLowerCase()) : getWbsFullName(portfolioActionData?.wbaName))}  </td>
                                    <td className="column-center">
                                        <img src={View} onClick={() => formModelOpen(EOprationalActions.SELECT)} className="actionicon pointer" alt=""></img>
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </div>
                    </div>
                    }
                    <hr />
                    <div className="top-section">
                        <div className="details-section">
                            <Row>
                                <Col sm="6" xs="12">
                                    <h2 className="mt-0"> {t('EvidenceWba.1stRotationalSupervisor')}</h2>
                                </Col>
                                <Col sm="6" xs="12" className="text-right">
                                    <span className="approvedDate"> {portfolioActionData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? t('EvidenceWba.rejectOn') : t('EvidenceWba.approvedon')} <span className="date">
                                        {portfolioActionData?.firstRotationSupervisor?.approvedOn || '-'}
                                    </span></span>
                                </Col>
                            </Row>
                            <Row className="mt-3">

                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.approvalStatus')}</Label>
                                        <Input type="text" value={portfolioActionData?.firstRotationSupervisor?.status || ''} disabled></Input>
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label> {t('EvidenceWba.approverName')}</Label>
                                        <Input type="text" value={portfolioActionData?.firstRotationSupervisor?.supervisorName || ''} disabled></Input>
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('EvidenceWba.comments')}</Label>
                                        <textarea value={portfolioActionData?.firstRotationSupervisor?.comments || ''} disabled className="comments" rows={1}></textarea>
                                    </FormGroup>
                                </Col>
                            </Row>
                        </div>
                        <hr/>
                        <div className="details-section mt-3">
                            {portfolioActionData?.secondRotationSupervisor?.supervisorName && <>
                                <Row>
                                    <Col sm="6" xs="12">
                                        <h2 className="mt-0"> {t('EvidenceWba.2ndRotationalSupervisor')}</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate"> {portfolioActionData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? t('EvidenceWba.rejectOn') : t('EvidenceWba.approvedon')} <span className="date">
                                            {portfolioActionData?.secondRotationSupervisor?.approvedOn || '-'}
                                        </span></span>
                                    </Col>
                                </Row>
                                <Row className="mt-3">

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('EvidenceWba.approvalStatus')}</Label>
                                            <Input type="text" value={portfolioActionData?.secondRotationSupervisor?.status || ''} disabled></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('EvidenceWba.approverName')}</Label>
                                            <Input type="text" value={portfolioActionData?.secondRotationSupervisor?.supervisorName || ''} disabled></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('EvidenceWba.comments')}</Label>
                                            <textarea value={portfolioActionData?.secondRotationSupervisor?.comments || ''} disabled className="comments" rows={1}></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </>}
                        </div>
                    </div>


                    <div className="text-center mb-4">
                        <Row className="sub-form-footer mt-3 mr-3">
                            <button className="btn blue-button" type='button' onClick={back}>{t('ActionNames.back')}</button>
                        </Row></div>

                </div>
            </div>

        </>
    )
}

export default React.memo(WbasAction)