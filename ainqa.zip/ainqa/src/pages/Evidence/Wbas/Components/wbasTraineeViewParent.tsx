import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/wbasContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { IPortfolio, IEvidenceWbaModel } from '../../../../models/evidenceWbaModel';
import { setEvidenceWbaPaginationCurrentPageValue } from '../../../../store/actions';
import groupBy from 'lodash/groupBy';
import { ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';



const WbasTraineeViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;


    const portfoliosData: IPortfolio[] | undefined = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.portfoliosData)
            return (state.evidenceWbaReducer as IEvidenceWbaModel)?.portfoliosData;
        else return undefined;
    });

    const currentPage: number = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.paginationCurrentPage)
            return (state.evidenceWbaReducer as IEvidenceWbaModel).paginationCurrentPage;
        else return 0;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.evidenceSurgicalElogbookReducer?.searchKey)
            return state.evidenceSurgicalElogbookReducer.searchKey;
        else return ''
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });
    const role = userDto?.roles?.roleCode;

    const EvidenceWbaGroupedData = Object.entries(groupBy(portfoliosData, 'traineeId'));

    const portfoliosFilterData: any = (EvidenceWbaGroupedData?.length && searchKey !== '') ? EvidenceWbaGroupedData?.filter((x: any) => (
        searchKey !== '' ? x?.[1][0].traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : EvidenceWbaGroupedData;

    let pagesCount: number = Math.ceil((portfoliosFilterData ? portfoliosFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setEvidenceWbaPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setEvidenceWbaPaginationCurrentPageValue(index));
    };

    console.log('WbasTraineeViewParent', { portfoliosFilterData, portfoliosData })

    return (
        <>
            <div className="tbl-parent table-responsive">
                <table className="w100 myTable evt-table table">
                    <thead>
                        <tr>
                            <th> {t('EvidenceWba.traineeName')}</th>
                            <th> {t('EvidenceWba.programName')}</th>
                            {role === ERoleDesc.ROTATIONSUPERVISOR && <th> {t('EvidenceWba.stage')}</th>}
                            {role === ERoleDesc.ROTATIONSUPERVISOR && <th> {t('EvidenceWba.rotations')}</th>}
                        </tr>
                    </thead>
                    <tbody>
                        {
                            portfoliosData && portfoliosFilterData?.length > 0 && portfoliosFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                                <ParentContext.Provider value={x[0]} key={x[0]}>
                                    <context.wbasTraineeView />
                                </ParentContext.Provider>
                            ))
                        }
                    </tbody>
                </table>
                {portfoliosData && (portfoliosFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('EvidenceWba.noDataFound')}</h6></div>}
            </div>
            {portfoliosFilterData && portfoliosFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </>
    )
}
export default React.memo(WbasTraineeViewParent);