import React, { useContext } from 'react';
import { ParentContext } from '../Container/wbasContext';
import { EOprationalActions } from '../../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import View from '../../../../images/View.svg';
import { setEvidenceWbaActionTypeAndActionData } from '../../../../store/actions';
import { IPortfolio, IEvidenceWbaModel } from '../../../../models/evidenceWbaModel';
import { useTranslation } from 'react-i18next';


const WbasView: React.FC = () => {
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);
    const { t } = useTranslation('translations');

    const portfoliosData: IPortfolio | undefined = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.portfoliosData?.length) {
            let portfolioData = (state.evidenceWbaReducer as IEvidenceWbaModel).portfoliosData;
            return portfolioData.find(x => x.portfolioId === context);
        } else
            return undefined;
    });

    const actionData: IPortfolio = useSelector((state: any) => {
        if (state?.evidenceWbaReducer?.actionData)
            return state.evidenceWbaReducer.actionData;
        else return undefined
    });

    const ViewPortfolio = () => {
        dispatch(setEvidenceWbaActionTypeAndActionData(EOprationalActions.SELECT, actionData, portfoliosData));
    };
    console.log("WbasView==>", portfoliosData);

    return (
        <>
            <tr>
                <td>{portfoliosData?.stageName}</td>
                <td>{portfoliosData?.rotationName}</td>
                <td> {portfoliosData?.code}</td>
                <td> {portfoliosData?.wbaName}</td>
                {/* <td style={{ position: 'relative' }}><span className="elip-more">-</span>{false && <span className="em-icon"><i className="icon-moreicon"></i></span>}</td> */}
                <td> {portfoliosData?.isAssessed ? t('EvidenceWba.assessed') : t('EvidenceWba.nonAssessed')}</td>
                <td> {portfoliosData?.firstRotationSupervisor?.supervisorName}</td>
                {/* <td className="column-center">{portfoliosData?.firstRotationSupervisor?.status ? (portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : portfoliosData?.firstRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-'}</td> */}
                <td> {portfoliosData?.secondRotationSupervisor?.supervisorName || '-'}</td>
                {/* <td className="column-center">{portfoliosData?.secondRotationSupervisor?.status ? (portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.PENDING ? <img src={Pending} className="icon" alt="" /> : portfoliosData?.secondRotationSupervisor?.status === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-'}</td> */}
                <td>{(portfoliosData?.secondRotationSupervisor?.approvedOn && portfoliosData?.firstRotationSupervisor?.approvedOn) ? ((portfoliosData?.secondRotationSupervisor?.approvedOn > portfoliosData?.firstRotationSupervisor?.approvedOn) ? portfoliosData?.secondRotationSupervisor?.approvedOn : portfoliosData?.firstRotationSupervisor?.approvedOn) : (portfoliosData?.secondRotationSupervisor?.approvedOn || portfoliosData?.firstRotationSupervisor?.approvedOn || '-')}</td>
                <td>
                    <span><img src={View} onClick={ViewPortfolio} className="actionicon pointer" alt=""></img></span>
                </td>
            </tr>

        </>

    )
}
export default React.memo(WbasView);