import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, Modal, ModalHeader, ModalBody, UncontrolledDropdown } from 'reactstrap';
import { activateAuthLayout } from '../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import viewicon from '../../../images/View.svg';
import filtericon from '../../../images/column-filter.svg';
import Select from 'react-select';

class LearningAgreements1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            selectedOption: null,
            isModel: false
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    formOptions = [
        { value: 'cbdtrainee', label: 'CBD Form Trainee' },
        { value: 'cbdevaluator', label: 'CBD Form Evaluator' },
        { value: 'cextrainee', label: 'CEX Form Trainee' },
        { value: 'cexevaluator', label: 'CEX Form Evaluator' },
    ];

    communicationOptions = [{ value: 'email', label: 'Email' },
    { value: 'sms', label: 'SMS' }];

    periodOptions = [{ value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' }];

    ednSupervisorOptions = [{ value: 'sup1', label: 'Dr David' },
    { value: 'sup2', label: 'Dr Arnold' },
    { value: 'sup3', label: 'Dr John' },
    { value: 'sup4', label: 'Dr Smith' }];

    coEdnSupervisorOptions = [{ value: 'sup5', label: 'Dr Martin' },
    { value: 'sup6', label: 'Dr Luther' },
    { value: 'sup7', label: 'Dr Kane' },
    { value: 'sup8', label: 'Dr Jane' }];

    render() {
        return (
            <React.Fragment>
                <Modal className="modal-lg glamodal" isOpen={this.state.isModel} style={{margin:"0 auto"}}>
                    <ModalHeader style={{position:"sticky", top:0, zIndex:3, background:"#ffffff", borderRadius:"0"}}>
                        <div className="text-center">LEARNING AGREEMENT FOR ACADEMIC SUPERVISION</div>
                        <div className="modal-close"><button className="btn btn-danger" onClick={() => this.setState({isModel:!this.state.isModel})}><i className="ti-close"></i></button></div>
                    </ModalHeader>
                    <ModalBody>
                        <div className="px-4">
                            <h6>This letter of undertaking defines the relationship between</h6>
                            <Row>
                                <Col sm="6">
                                    <FormGroup>
                                        <Label>Educational Supervisor *</Label>
                                        <Select
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.ednSupervisorOptions}
                                            defaultValue={{ value: 'sup1', label: 'Dr David' }}
                                            placeholder="Select Educational Supervisor"
                                            isDisabled = {true}
                                        />
                                    </FormGroup>
                                </Col>

                                <Col sm="6">
                                    <FormGroup>
                                        <Label>Co-educational Supervisor</Label>
                                        <Select
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.coEdnSupervisorOptions}
                                            defaultValue={{ value: 'sup5', label: 'Dr Martin' }}
                                            placeholder="Select Co Educational Supervisor"
                                            isDisabled = {true}
                                        />
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm="11" xs="12" className="flexone">
                                    <p className="mr-4 alone">and</p>
                                    <FormGroup className="flexone-item">
                                        <Label>Name of Trainee</Label>
                                        <Input type="text" placeholder="Johnny Depp" disabled></Input>
                                    </FormGroup>

                                    <FormGroup className="flexone-item">
                                        <Label>Matric Number</Label>
                                        <Input type="text" placeholder="M12578" disabled></Input>
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm="8" className="flexone">
                                    <p className="mr-4 alone">For the program of</p>
                                    <FormGroup className="flexone-item">
                                        <Label>Name of Program</Label>
                                        <Input type="text" placeholder="Family Medicine" disabled></Input>
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm="6" className="flexone">
                                    <p className="mr-4 alone">at</p>
                                    <FormGroup className="flexone-item">
                                        <Label>Name of Academy/Institute/Faculty/Centre</Label>
                                        <Input type="text" placeholder="University of Malaya" disabled></Input>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <p className="mt-4">
                                The following section outlines the roles and responsibilities of the Academic Supervisor and Trainee,
                                in order to ensure a high quality of supervision, and output that is consistent with the mission and vision
                                of the Institute/Centre/University, pursuant to the requirements of the Postgraduate National Curriculum.<br /><br />

                                Please read the following and sign where indicated on the last page of the letter of undertaking.<br /><br />

                                The trainee shall be responsible for his/her candidature and research throughout their status as a trainee in
                                the respective Institution/Centre/University as set out below:
                            </p>
                            <div className="roles">
                                <h1>ROLES AND RESPONSIBILITIES OF THE TRAINEE</h1>
                                <div className="mx-1 roles-pad">
                                    <h2 className="line-through"><span>General</span></h2>
                                    <ol>
                                        <li>Trainees shall understand and fulfil all of the requirements stated in the offer letter, rules and regulations
                                            applicable to the program.</li>

                                        <li className="tmargin">Trainees shall meet regularly with Academic Supervisors on a regular basis <Select className="period d-inline-block"
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.periodOptions}
                                            placeholder="Choose Period"
                                            isDisabled = {true}
                                        /> Academic Supervisors and trainees shall meet face-to-face in the first meeting. Subsequent meetings may be conducted
                                            via other forms of communication <Select className="moc d-inline-block"
                                                onChange={(e) => this.handleChange(e)}
                                                options={this.communicationOptions}
                                                placeholder="Mode of Communication"
                                                isDisabled = {true}
                                            /></li>

                                        <li>Academic Supervisor-trainee interactions should be documented, to provide a record of progress and
                                            achievements during the period of training. Documentation may be in electronic or paper format.</li>

                                        <li>Trainees shall establish a good working relationship with the Academic Supervisors.</li>

                                        <li>Trainees shall discuss and agree on consultation times with the Academic Supervisors.</li>

                                        <li>Trainees shall plan the research schedule to allow completion within the provisions of the programme. This includes, but is not limited to:
                                            <ol className="sublist">
                                                <li>presenting regular updates on their research progress</li>
                                                <li>notifying their Academic Supervisor of any problems that may interfere with the research / thesis / dissertation.</li>
                                                <li>engaging in relevant academic activities</li>
                                                <li>ensuring sufficient time to conduct the research and write the thesis/dissertation.</li>
                                                <li>alerting the Academic Supervisor of the thesis defence date, at least three months in advance.</li>
                                                <li>submission of the written research report/thesis/dissertation, approved by the Academic Supervisor, at the
                                                    specified time, without falsifying the outcome and ensuring that the work is free of plagiarism.</li>
                                                <li>ensuring that corrections are made within the time stipulated by the Panel of Evaluators.</li>
                                            </ol>
                                        </li>

                                        <li>Trainees are solely responsible for the content and the presentation of the research/thesis/dissertation,
                                            including the thesis defence.</li>
                                    </ol>
                                </div>
                            </div>
                            <p className="py-4">The appointed Academic Supervisor(s) shall exercise roles and responsibilities as set out below:</p>
                            <div className="roles">
                                <h1>ROLES AND RESPONSIBILITIES OF THE ACADEMIC SUPERVISOR</h1>
                                <div className="mx-1 roles-pad">
                                    <h2 className="line-through"><span>General</span></h2>
                                    <ol>
                                        <li>Prior to commencing any supervision of trainees, Academic Supervisors should be familiar with the latest
                                            rules and regulations of their programme curriculum, and ensure consistency with the Postgraduate
                                            National Curriculum.</li>

                                        <li>Academic Supervisors should be knowledgeable, up-to-date in conceptual and applied practices, and actively
                                            practising in the trainee’s field of study.</li>

                                        <li>Academic Supervisors should be aware of the milestones in a project schedule, to ensure smooth completion
                                            within the provisions of the programme.</li>

                                        <li>Academic Supervisors are responsible for providing relevant academic guidance and support to trainees
                                            during the supervisory period, to enable completion of projects to a high standard.</li>

                                        <li className="tmargin">Academic Supervisors shall meet with trainees on a regular basis <Select className="period d-inline-block"
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.periodOptions}
                                            placeholder="Choose Period"
                                            isDisabled = {true}
                                        /> Academic Supervisors
                                            and trainees shall meet face-to-face in the first meeting. Subsequent meetings may be conducted
                                            via other forms of communication <Select className="moc d-inline-block"
                                                onChange={(e) => this.handleChange(e)}
                                                options={this.communicationOptions}
                                                placeholder="Mode of Communication"
                                                isDisabled = {true}
                                            /></li>

                                        <li>Academic Supervisors must be familiar with their responsibilities and advise their trainees on the aspects
                                            that will be supervised. In the event that two (2) or more Academic Supervisors are appointed for each
                                            candidate, the effective working relationship between all parties needs to be maintained together.</li>

                                        <li>Academic Supervisors may advise trainees with regards to preparation of presentations at conferences,
                                            seminars, meetings and workshops. However, trainees are expected to prepare the work themselves.</li>

                                        <li>Academic Supervisor-trainee interactions should be documented, to provide a record of progress and
                                            achievements during the period of training. Documentation may be in electronic or paper format.</li>

                                        <li>Academic Supervisors should monitor the progress of trainees relative to the expected standard. Academic
                                            Supervisors shall inform trainees if the standard is not met, and propose remedial measures.</li>

                                        <li>Academic Supervisors should be aware of, and prepare their trainees for, all formal evaluations. Unsatisfactory
                                            progress, as deemed by the Panel of Evaluators, requires corrective measures by both Academic Supervisor
                                            and trainee.</li>

                                        <li>Academic Supervisors should ensure that any research carried out is in accordance with occupational health
                                            and safety, as well as ethics policies specified by the Institution/Centre/University.</li>

                                        <li>Academic Supervisors should provide constructive comments on trainees’ research/thesis/dissertation
                                            drafts within a reasonable time, and advise on the format of the research/thesis/dissertation as specified
                                            by the Institution/Centre/University.</li>

                                        <li>Academic Supervisors may assist trainees in academic writing, including submission of papers for publication.
                                            When written jointly by the Academic Supervisor and trainee, authorship should be agreed to by both parties
                                            prior to submission.</li>
                                    </ol>
                                    <h2 className="line-through"><span>Role of the Academic Supervisor in the Thesis Defence</span></h2>
                                    <ol>
                                        <li>Academic Supervisors must not be part of the Thesis Defence Panel of Evaluators for trainees they are
                                            supervising. The Panel may ask for input from, or give feedback to, the Academic Supervisor if issues are
                                            identified. The Academic Supervisor must not be involved in determining the outcome of the evaluation.</li>

                                        <li>Academic Supervisors are to provide supervisory reports, where necessary, in the required format within a
                                            stipulated time to the relevant bodies.</li>

                                        <li>Academic Supervisors should assist trainees to make corrections based on feedback from the Panel, and
                                            continue to oversee the trainee should a further defence be required.</li>
                                    </ol>
                                </div>
                            </div>

                            <div className="mt-3">
                            <div className="top-section">
                            <Row className="vhcenter">
                                            <Col sm="6" xs="12">
                                            </Col>
                                            <Col sm="6" xs="12" className="text-right">
                                                <span className="approvedDate">Approved on : <span className="date">07/03/2021</span></span>
                                            </Col>
                                        </Row>
                            <div className="details-section">
                                            <Row className="mt-3">
                                                <Col sm="5">
                                                    <FormGroup>
                                                        <Label>Approval Status</Label>
                                                        <Input type="text" disabled value="-"></Input>
                                                    </FormGroup>
                                                </Col>

                                                <Col sm="5">
                                                    <FormGroup>
                                                        <Label>Remarks</Label>
                                                        <textarea className="form-control" rows={1} disabled></textarea>
                                                    </FormGroup>
                                                </Col>
                                            </Row>

                                        </div>
                                        <div className="text-center mb-4"><button className="btn mt-3 modal-submit-button">Back</button></div>
                                        </div>
                            </div>
                        </div>
                    </ModalBody>
                </Modal>
                <div className="flexLayout maincontent">
                    <Row className="compHeading mb-2 pr-2">
                        <Col>
                            <h3 className="page-header header-title">Learning Agreements</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <div className="search-text">
                                    <input type="text" placeholder="Search" /><i className="ti-search icon"></i>
                                </div>
                            </div>
                        </div>
                    </Row>

                    <div className="flexScroll">
                    <div className="main-table h-100">
                                    <div className="tbl-parent table-responsive h-100 pr-2">
                            <table className="myTable evd-latable table">
                                <thead>
                                    <tr>
                                        <th>Agreement Name</th>
                                        <th>Rotation Name</th>
                                        <th>Stage</th>
                                        <th>Agreement Date</th>
                                        <th className="column-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>General</td>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>05-06-2021 15:03</td>
                                        <td className="column-center"><img src={viewicon} alt="view" className="actionicon pointer" onClick={() => this.setState({isModel:!this.state.isModel})} /></td>
                                    </tr>
                                    <tr>
                                        <td>Rotational</td>
                                        <td>Rotation 02</td>
                                        <td>Stage 1</td>
                                        <td>08-06-2021 11:10</td>
                                        <td className="column-center">
                                            <img src={viewicon} alt="view" className="actionicon pointer" onClick={() => this.setState({isModel:!this.state.isModel})} />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                        </div>
                        </div>
                    </div>
            </React.Fragment>
        )
    }
}
export default withRouter(connect(null, { activateAuthLayout })(LearningAgreements1));
