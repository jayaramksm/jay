import React from 'react';
import {CustomInput, Form, DropdownToggle, DropdownMenu } from 'reactstrap';

class FilterComponent1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        this.state = {
            checked:false
        };
    }

    render() {
        return (
            <>
                <DropdownToggle id="Filter">
                    <i className="icon-funnel columnfilter"></i>
                </DropdownToggle>
                <DropdownMenu className="filter-menu">
                    <Form>
                    <div className="px-3 py-2">
                        <input type="text" placeholder="Search" className="form-control w100" />
                        <div className="filterOptions mt-3">
                            <input type="checkbox" id="topping" name="topping" value="Malaysian" /><span>Malaysian Citizen</span> <br/>
                            <input type="checkbox" id="topping1" name="topping1" value="Permanent" /><span>Permanent Resident</span> <br/>
                            <input type="checkbox" id="topping2" name="topping2" value="Foreigner" /><span>Foreigner</span> <br/>
                        </div>
                        <hr />
                        <button type="reset" className="btn btn-reset mb-2 float-right">Reset</button>
                    </div>
                    </Form>
                </DropdownMenu>
            </>
        )
    }
}

export default React.memo(FilterComponent1);