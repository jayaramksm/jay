import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, UncontrolledDropdown } from 'reactstrap';
import { activateAuthLayout } from '../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import viewicon from '../../../images/View.svg';
import DatePicker from "react-datepicker";


class EvidenceSurgicalElogbook1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            datevalue: new Date(),
            view: false,
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = () => {
        this.setState({ view: !this.state.view });
    };

    render() {
        return (
            <React.Fragment>
                {!this.state.view &&
                <div className="flexLayout maincontent">
                    <Row className="compHeading mb-2 pr-2">
                        <Col>
                            <h3 className="page-header header-title">Surgical Logbook</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <div className="search-text">
                                    <input type="text" placeholder="Search" /><i className="ti-search icon"></i>
                                </div>
                            </div>
                        </div>
                    </Row>

                    <div className="flexScroll">
                    <div className="main-table h-100">
                                    <div className="tbl-parent table-responsive h-100 pr-2">
                            <table className="myTable evd-selogtable table">
                                <thead>
                                    <tr>
                                        <th>Stage</th>
                                        <th>Rotations</th>
                                        <th>Code</th>
                                        <th>Assessed/Non Assessed</th>
                                        <th>ELA/EPA</th>
                                        <th>Completed Date</th>
                                        <th className="column-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Stage1</td>
                                        <td>Rotation01</td>
                                        <td>WBA</td>
                                        <td>Non Assessed</td>
                                        <td style={{position:'relative'}}><span className="elip-more">Initial Management</span><span className="em-icon"><i className="icon-moreicon"></i></span></td>
                                        <td>05-06-2021 15:03</td>
                                        <td className="column-center"><img src={viewicon} alt="view" className="view-icon pointer" onClick={this.handleChange} /></td>
                                    </tr>
                                    <tr>
                                        <td>Stage2</td>
                                        <td>Rotation02</td>
                                        <td>WBA</td>
                                        <td>Non Assessed</td>
                                        <td style={{position:'relative'}}><span className="elip-more">Surgical Management</span><span className="em-icon"><i className="icon-moreicon"></i></span></td>
                                        <td>08-06-2021 11:10</td>
                                        <td className="column-center">
                                            <img src={viewicon} alt="view" className="view-icon pointer"  onClick={this.handleChange} />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                        </div>
                        </div>
                    </div>
                    }
                    {this.state.view &&
                    <div className="flexLayout maincontent">
                        <Row>
                            <Col className="breadcrumbs">
                                <div>
                                    <span className='pointer' onClick={this.handleChange}>Surgical Logbook</span>
                                    <span><i className="ti-angle-right"></i></span>
                                    <span className="active">View Entry</span>
                                </div>
                            </Col>
                        </Row>
                        <div className="flexScroll">
                                <div className="top-section">
                                    <div className="details-section">
                                        <Row>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Stage</Label>
                                                    <Input type="text" disabled value="Stage 1"></Input>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Rotation</Label>
                                                    <Input type="text" disabled value="Rotation R2"></Input>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Hospital</Label>
                                                    <Input type="text" disabled value="Montec Hospital"></Input>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Code</Label>
                                                    <Input type="text" disabled value="SURLOG- Surgical log book"></Input>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Due Date</Label>
                                                    <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Completed Date</Label>
                                                    <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                                <hr/>
                                <div className="top-section">
                                    <h2>Surgical Log Book Details</h2>
                                    <div className="details-section mt-3">
                                        <div className="tbl-parent">
                                            <table className="w100 myTable wba-viewtbl table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Surgical Log Book Name</th>
                                                        <th className="column-center">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>Surgical Log Book (SURLOG) Form</td>
                                                        <td className="column-center">
                                                            <img src={viewicon} className="view-icon pointer" alt=""></img>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <hr/>
                                <div className="top-section">
                                    <Row className="compHeading mr-0">
                                        <Col sm="8"><h2>Approval Details</h2></Col>
                                        <Col sm="4" className="text-right" style={{paddingRight:'5.5%'}}>
                                            <span className="approvedDate">Approved on : <span className="date">07/03/2021</span></span>
                                        </Col>
                                    </Row>
                                    <div className="details-section">
                                        <Row>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Approval Status</Label>
                                                    <Input type="text" disabled value="Approved"></Input>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Approver Name</Label>
                                                    <Input type="text" disabled value="David"></Input>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Comments</Label>
                                                    <textarea disabled placeholder="None" className="comments" rows={1}></textarea>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                                <Row className="sub-form-footer mt-3 mr-3">
                                        <button className="back-button" onClick={this.handleChange}>Back</button>
                                </Row>
                            </div>
                        </div>
                    }
            </React.Fragment>
        )
    }
}
export default withRouter(connect(null, { activateAuthLayout })(EvidenceSurgicalElogbook1));
