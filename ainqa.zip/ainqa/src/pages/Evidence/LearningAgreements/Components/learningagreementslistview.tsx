import React, { useContext } from 'react';
import viewicon from '../../../../images/View.svg';
import { useSelector, useDispatch } from 'react-redux';
import { EAgreementType } from '../../../../models/learningAgreementsModel';
import { setLearningAgreementsActionTypeAndActionData } from '../../../../store/actions';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { ParentContext } from '../Container/learningAgreementsContext';



const LearningAgreementsListView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    let key = userDto?.userType === ERoleDesc.Traninee ? 'learningAgreements' : 'actionData'

    const learningAgreementsData: any | undefined = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.[key])
            return state.learningAgreementsReducer?.[key].find(x => (x.rlaId || x.glaId) === context)
        else return undefined;
    });

    const actionData: any = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.[key])
            return state.learningAgreementsReducer?.[key];
        else return undefined;
    });

    const gotoAgreemtnsViewPage = () => {
        let data = userDto?.userType === ERoleDesc.Traninee ? learningAgreementsData : actionData

        if (learningAgreementsData?.agreementName === EAgreementType.RLA) {
            dispatch(setLearningAgreementsActionTypeAndActionData(EOprationalActions.SELECT, data, learningAgreementsData))
        }
        else if (learningAgreementsData?.agreementName === EAgreementType.GLA) {
            dispatch(setLearningAgreementsActionTypeAndActionData(EOprationalActions.MAPPING, data, learningAgreementsData))
        }
    }

    console.log('learningAgreementsData==>', learningAgreementsData)

    return (
        <>
            {learningAgreementsData && <tr>
                <td>{learningAgreementsData?.agreementName}</td>
                <td>{learningAgreementsData?.rotationName || '-'}</td>
                <td>{learningAgreementsData?.stageName || '-'}</td>
                <td>{learningAgreementsData?.latestApprovedOn}</td>
                <td className="column-center"><span><img src={viewicon} alt="view" className="actionicon pointer" onClick={gotoAgreemtnsViewPage} /></span></td>
            </tr>}
        </>

    )
}

export default React.memo(LearningAgreementsListView)