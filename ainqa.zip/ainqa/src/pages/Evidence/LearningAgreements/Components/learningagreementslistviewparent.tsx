
import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/learningAgreementsContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setLearningAgreementsPaginationCurrentPageValue } from '../../../../store/actions';
import { PaginationComponent } from '../../../../pages/utilities/PaginationComponent';
import { ERoleDesc, IUserDetails } from 'models/utilitiesModel';


const LearningAgreementsListViewParent: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;
    const { t } = useTranslation('translations');

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    let key = userDto?.userType === ERoleDesc.Traninee ? 'learningAgreements' : 'actionData'

    const learningAgreementsData: any[] | undefined = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.[key])
            return state.learningAgreementsReducer?.[key]
        else return undefined;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.searchkey)
            return state.learningAgreementsReducer.searchkey;
        else return '';
    });
    const currentPage: number = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.paginationCurrentPage)
            return state.learningAgreementsReducer.paginationCurrentPage;
        else return 0;
    });


    const learningAgreementsFilter: any[] | undefined = (learningAgreementsData && searchKey !== '') ? learningAgreementsData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName?.toLowerCase()?.startsWith(searchKey.toLowerCase()) : true
    )) : learningAgreementsData;


    let pagesCount: number = Math.ceil((learningAgreementsFilter ? learningAgreementsFilter.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setLearningAgreementsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setLearningAgreementsPaginationCurrentPageValue(index));
    };


    return (
        <>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table evla-table">
                                <thead>
                                    <tr>
                                        <th>{t('LearningAgreements.agreementName')}</th>
                                        <th>{t('LearningAgreements.rotation')}</th>
                                        <th>{t('LearningAgreements.stage')}</th>
                                        <th>{t('LearningAgreements.agreementDate')}</th>
                                        <th className="column-center">{t('LearningAgreements.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    {learningAgreementsFilter && learningAgreementsFilter?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((agreements) => (
                                        <ParentContext.Provider value={agreements?.rlaId || agreements?.glaId} key={agreements?.rlaId || agreements?.glaId}>
                                            <context.learningAgreementsListView />
                                        </ParentContext.Provider>
                                    ))}
                                </tbody>
                            </table>
                            {(learningAgreementsFilter && learningAgreementsFilter?.length === 0) && <div className="norecordsfound"><h6>{t('LearningAgreements.noDataFound')}</h6></div>}
                        </div>
                        {learningAgreementsFilter && learningAgreementsFilter.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>}
                    </div>
                </div>
            </div>
        </>
    )
}
export default React.memo(LearningAgreementsListViewParent);