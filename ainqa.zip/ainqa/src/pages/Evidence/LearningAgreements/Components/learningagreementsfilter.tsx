
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import { setSearchKeyInLearningAgreementsRequest, setLearningAgreementsActionTypeAndActionData } from '../../../../store/actions';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';


const LearningAgreementsFilter: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const onSearchChange = e => {
        const searchInput = e.target.value;
        dispatch(setSearchKeyInLearningAgreementsRequest(searchInput));
    };

    const actionData: any = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.actionData)
            return state.learningAgreementsReducer.actionData;
        else return undefined;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const goBackToTraineeView = () => {
        dispatch(setLearningAgreementsActionTypeAndActionData(EOprationalActions.UNSELECT, null, null))
    }

    return (
        <Row className="compHeading mb-2 pr-2">
            <Col>
                {actionData && userDto?.userType !== ERoleDesc.Traninee && <div className="breadcrumbs">
                    <span className="pointer" onClick={goBackToTraineeView}>{t('LearningAgreements.rotationalLearningAgreements')}</span>
                    <span><i className="ti-angle-right"></i></span>
                    <span className="active">
                        {actionData?.[0]?.traineeName}
                    </span>
                </div>}
                {!actionData && <h3 className="page-header header-title">{t('LearningAgreements.rotationalLearningAgreements')}</h3>}
            </Col>
            <div className="rgtFilter">
                <div className="search-box filtericon">
                    <div className="search-text">
                        <input type="text" placeholder="Search" onChange={onSearchChange} /><i className="ti-search icon"></i>
                    </div>
                </div>
            </div>
        </Row>
    )
}
export default React.memo(LearningAgreementsFilter);