import React, { useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setLearningAgreementsActionTypeAndActionData } from '../../../../store/actions';
import { EApprovelActions, EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { ParentContext } from '../Container/learningAgreementsContext';
import groupBy from 'lodash/groupBy';
import maxBy from 'lodash/maxBy';
import { IRlaAgreementsData } from '../../../../models/learningAgreementsModel';

const LearningAgreementsTraineeView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);

    const learningAgreementsData: any[] | undefined = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.learningAgreements)
            return state.learningAgreementsReducer.learningAgreements
        else return undefined;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const learningAgreementsGroupedData = groupBy(learningAgreementsData, 'traineeId');

    let learningAgreementsLatestData;

    if (userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR) {
        learningAgreementsLatestData = learningAgreementsGroupedData[context]?.map((x: IRlaAgreementsData) => ({ ...x, latestApproved: (x?.secondRotationSupervisor?.approvedOn && x?.firstRotationalSupervisor?.approvedOn) ? ((+new Date(x?.secondRotationSupervisor?.approvedOn) > +new Date(x?.firstRotationalSupervisor?.approvedOn)) ? x?.secondRotationSupervisor?.approvedOn : x?.firstRotationalSupervisor?.approvedOn) : (x?.secondRotationSupervisor?.approvedOn || x?.firstRotationalSupervisor?.approvedOn || '-') }))
    }

    const getLatestSubmite = () => {
        if (learningAgreementsLatestData)
            return maxBy(learningAgreementsLatestData, (data) => +(new Date(data.latestApproved)));
    }


    console.log('LearningAgreementsTraineeView=>', { context, learningAgreementsData: learningAgreementsData, learningAgreementsGroupedData: learningAgreementsGroupedData[context] });

    const goToTraineeRotationsRlaView = () => {
        dispatch(setLearningAgreementsActionTypeAndActionData(EOprationalActions.ADD, learningAgreementsGroupedData[context], null))
    }
    return (
        <>
            {learningAgreementsGroupedData && learningAgreementsData && <tr>
                <td onClick={goToTraineeRotationsRlaView} className='pointer ActionStatus'>{learningAgreementsGroupedData[context][0].traineeName}</td>
                <td>{learningAgreementsGroupedData[context][0]?.programName || '-'}</td>
                {userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR &&
                    <>
                        <td>{getLatestSubmite()?.stageName || '-'}</td>
                        <td>{getLatestSubmite()?.rotationName || '-'}</td>
                    </>
                }
            </tr>}
        </>
    )
}

export default React.memo(LearningAgreementsTraineeView);