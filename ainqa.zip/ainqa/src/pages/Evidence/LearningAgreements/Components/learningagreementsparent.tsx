import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/learningAgreementsContext';
import { useSelector } from 'react-redux';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';

const LearningAgreementsParent: React.FC = () => {
    const context: any = useContext(SuperParentContext);

    const actionType: number = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.actionType)
            return state.learningAgreementsReducer.actionType
        else return EOprationalActions.UNSELECT
    })

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    return (
        <>
            <div className="flexLayout maincontent">
                {(actionType === EOprationalActions.UNSELECT) && (userDto?.userType !== ERoleDesc.Traninee) && <>
                    <context.learningAgreementsFilter />
                    <context.learningAgreementsTraineeListViewParent />
                </>}
                {(userDto?.userType === ERoleDesc.Traninee ? actionType === EOprationalActions.UNSELECT : actionType === EOprationalActions.ADD) && <>
                    <context.learningAgreementsFilter />
                    <context.learningAgreementsListViewParent />
                </>}
                {actionType === EOprationalActions.SELECT && <context.learningAgreementsRlaView />}
                {actionType === EOprationalActions.MAPPING && <context.learningAgreementsGlaView />}
            </div>
        </>
    )
}
export default React.memo(LearningAgreementsParent);