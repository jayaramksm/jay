import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/learningAgreementsContext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import groupBy from 'lodash/groupBy';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setLearningAgreementsPaginationCurrentPageValue } from '../../../../store/actions';
import { IMeetingsData } from '../../../../models/meetingsModel';
import { ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';

const LearningAgreementsTraineeListViewParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const learningAgreementsData: IMeetingsData[] | undefined = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.learningAgreements)
            return state.learningAgreementsReducer.learningAgreements
        else return undefined;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.searchkey)
            return state.learningAgreementsReducer.searchkey;
        else return ''
    });

    const currentPage: number = useSelector((state: any) => state?.learningAgreementsReducer?.paginationCurrentPage || 0);

    const learningAgreementsGroupedData = Object.entries(groupBy(learningAgreementsData, 'traineeId'));

    const learningAgreementsFilterData: any = (learningAgreementsGroupedData?.length && searchKey !== '') ? learningAgreementsGroupedData?.filter((x: any) => (
        searchKey !== '' ? x?.[1][0].traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : learningAgreementsGroupedData;

    let pagesCount: number = Math.ceil((learningAgreementsFilterData ? learningAgreementsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setLearningAgreementsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setLearningAgreementsPaginationCurrentPageValue(index));
    };

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    console.log('LearningAgreementsTraineeListViewParent=>', learningAgreementsData, learningAgreementsFilterData);

    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table evt-table">
                                <thead>
                                    <tr>
                                        <th>{t('LearningAgreements.traineeName')}</th>
                                        <th>{t('LearningAgreements.programName')}</th>
                                        {userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR && <>
                                            <th>{t('LearningAgreements.stage')}</th>
                                            <th>{t('LearningAgreements.rotation')}</th>
                                        </>}
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        learningAgreementsData && learningAgreementsFilterData?.length > 0 && learningAgreementsFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                                            <ParentContext.Provider value={x[0]} key={x[0]}>
                                                <context.learningAgreementsTraineeView />
                                            </ParentContext.Provider>
                                        ))
                                    }
                                </tbody>
                            </table>
                            {learningAgreementsData && (learningAgreementsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('LearningAgreements.noDataFound')}</h6></div>}
                        </div>
                        {learningAgreementsFilterData && learningAgreementsFilterData.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(LearningAgreementsTraineeListViewParent);