import React from 'react';
import { setLearningAgreementsActionTypeAndActionData } from '../../../../store/actions';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Row, Col, Label, FormGroup, Input, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { IGlaAgreementsData } from '../../../../models/learningAgreementsModel';


const LearningAgreementsGlaView: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    let key = userDto?.userType === ERoleDesc.Traninee ? 'actionData' : 'learningAgreementsActionData';

    const actionType: number = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.actionType)
            return state.learningAgreementsReducer.actionType
        else return EOprationalActions.UNSELECT;
    });

    const actionData: IGlaAgreementsData = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.[key])
            return state.learningAgreementsReducer?.[key]
        else return undefined;
    });

    const traineeData: any = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.actionData)
            return state.learningAgreementsReducer.actionData
        else return undefined;
    });

    const cancel = () => {
        let data = userDto?.userType === ERoleDesc.Traninee ? null : traineeData;
        let type = userDto?.userType === ERoleDesc.Traninee ? EOprationalActions.UNSELECT : EOprationalActions.ADD
        dispatch(setLearningAgreementsActionTypeAndActionData(type, data, null));
    };

    console.log("LearningAgreementsAction==>", actionData, actionType,);

    return (
        <Modal className="modal-lg glamodal" isOpen={actionType === EOprationalActions.MAPPING} style={{ margin: "0 auto" }}>
            <ModalHeader style={{ position: "sticky", top: 0, zIndex: 3, background: "#ffffff", borderRadius: "0" }}>
                <div className="text-center"> {t('LearningAgreements.learningAgreementForAcademicSupervision')}</div>
                <div className="modal-close"><button className="btn btn-danger" onClick={cancel}><i className="ti-close"></i></button></div>
            </ModalHeader>
            <ModalBody>
                <div className="px-4">
                    <h6> {t('LearningAgreements.thisLatterofUndertakingDefinesTheRelationshipBetween')}</h6>
                    <Row>
                        <Col sm="6">
                            <FormGroup>
                                <Label>{t('LearningAgreements.educationalSupervisor')} </Label>
                                <Input type="text" value={actionData?.esUserName || ''} disabled></Input>
                            </FormGroup>
                        </Col>
                        {actionData?.mohUserName && <Col sm="6">
                            <FormGroup>
                                <Label> {t('LearningAgreements.mOHSupervisor/coeducationalSupervisor')}</Label>
                                <Input type="text" value={actionData?.mohUserName || ''} disabled></Input>
                            </FormGroup>
                        </Col>}
                    </Row>
                    <Row>
                        <Col sm="11" xs="12" className="flexone">
                            <p className="mr-4 alone"> {t('LearningAgreements.and')}</p>
                            <FormGroup className="flexone-item">
                                <Label> {t('LearningAgreements.nameofTrainee')}</Label>
                                <Input type="text" value={actionData?.traineeName || ''} disabled></Input>
                            </FormGroup>
                        </Col>
                    </Row>

                    <Row>
                        <Col sm="8" className="flexone">
                            <p className="mr-4 alone">  {t('LearningAgreements.fortheprogramof')}</p>
                            <FormGroup className="flexone-item">
                                <Label>  {t('LearningAgreements.nameofProgram')}</Label>
                                <Input type="text" value={actionData?.programName || ''} disabled></Input>
                            </FormGroup>


                            <FormGroup className="flexone-item flexone-item-inline">
                                <Label>{t('LearningAgreements.matricNumber')}</Label>
                                <Input type="text" value={actionData?.matricNumber || ''} disabled></Input>
                            </FormGroup>
                        </Col>
                    </Row>

                    <Row>
                        <Col sm="6" className="flexone">
                            <p className="mr-4 alone"> {t('LearningAgreements.at')}</p>
                            <FormGroup className="flexone-item">
                                <Label>{t('LearningAgreements.nameofAcademy/Institute/Faculty/Centre ')}</Label>
                                <Input type="text" value={userDto.university?.universityName || '-'} disabled></Input>
                            </FormGroup>
                        </Col>
                    </Row>
                    <p className="mt-4">
                        {t('LearningAgreements.academicSupervisionOne')}
                        <br /><br />

                        {t('LearningAgreements.academicSupervisionTwo')} <br /><br />

                        {t('LearningAgreements.academicSupervisionThree')}
                    </p>
                    <div className="roles">
                        <h1>{t('LearningAgreements.rOLESANDRESPONSIBILITIESOFTHETRAINEE')}   </h1>
                        <div className="mx-1 roles-pad">
                            <h2 className="line-through"><span>{t('LearningAgreements.general')}</span></h2>
                            <ol>
                                <li> {t('LearningAgreements.traineeAgreemant1')} </li>

                                <li className="tmargin">{t('LearningAgreements.traineeAgreemant2')}&nbsp;
                                    <div className="period">
                                        <Input type="text" value={actionData?.period || ''} disabled></Input>
                                    </div>
                                    {t('LearningAgreements.traineeAgreemant3')}&nbsp;
                                    <div className="moc">
                                        <Input type="text" value={actionData?.communication || ''} disabled></Input>
                                    </div>
                                </li>

                                <li>   {t('LearningAgreements.traineeAgreemant4')} </li>

                                <li>  {t('LearningAgreements.traineeAgreemant5')} </li>

                                <li> {t('LearningAgreements.traineeAgreemant6')} </li>

                                <li>  {t('LearningAgreements.traineeAgreemant7')} </li>
                                <ol className="sublist">
                                    <li>{t('LearningAgreements.traineeAgreemant8')}</li>
                                    <li>{t('LearningAgreements.traineeAgreemant9')}</li>
                                    <li>{t('LearningAgreements.traineeAgreemant10')}</li>
                                    <li> {t('LearningAgreements.traineeAgreemant11')}</li>
                                    <li> {t('LearningAgreements.traineeAgreemant12')}</li>
                                    <li> {t('LearningAgreements.traineeAgreemant13')} </li>
                                    <li>{t('LearningAgreements.traineeAgreemant14')}</li>
                                </ol>


                                <li> {t('LearningAgreements.traineeAgreemant15')} </li>
                            </ol>
                        </div>
                    </div>
                    <p className="py-4">{t('LearningAgreements.traineeAgreemant16')}</p>
                    <div className="roles">
                        <h1> {t('LearningAgreements.supervisorAgreement')}</h1>
                        <div className="mx-1 roles-pad">
                            <h2 className="line-through"><span> {t('LearningAgreements.general')}</span></h2>
                            <ol>
                                <li>  {t('LearningAgreements.supervisorAgreement1')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement2')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement3')} </li>

                                <li>  {t('LearningAgreements.supervisorAgreement4')} </li>

                                <li className="tmargin"> {t('LearningAgreements.supervisorAgreement5')}&nbsp;
                                    <div className="period">
                                        <Input type="text" value={actionData?.period || ''} disabled></Input>
                                    </div>
                                    {t('LearningAgreements.supervisorAgreement6')}&nbsp;

                                    <div className="moc">
                                        <Input type="text" value={actionData?.communication || ''} disabled></Input>
                                    </div>
                                </li>

                                <li>   {t('LearningAgreements.supervisorAgreement7')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement8')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement9')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement10')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement11')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement12')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement13')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement14')} </li>
                            </ol>
                            <h2 className="line-through"><span> {t('LearningAgreements.supervisorAgreement15')}  </span></h2>
                            <ol>
                                <li> {t('LearningAgreements.supervisorAgreement16')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement17')} </li>

                                <li> {t('LearningAgreements.supervisorAgreement18')} </li>
                            </ol>
                        </div>
                    </div>

                    <div className="mt-3">
                        <div className="top-section">
                            <Row className="vhcenter">
                                <Col sm="6" xs="12">
                                </Col>
                                <Col sm="6" xs="12" className="text-right">
                                    <span className="approvedDate">{t('LearningAgreements.approvedOn')} : <span className="date">{actionData?.esApprovedON}</span></span>
                                </Col>
                            </Row>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="5">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.approvalStatus')}</Label>
                                            <Input type="text" disabled value={actionData?.esStatus || '-'}></Input>
                                        </FormGroup>
                                    </Col>

                                    <Col sm="5">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.comments')}</Label>
                                            <textarea className="form-control" rows={1} value={actionData?.esComments || '-'} disabled></textarea>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                            <div className="text-center mb-4">
                                <button className="btn mt-3 modal-submit-button" onClick={cancel}>{t('LearningAgreements.back')}</button>
                            </div>
                        </div>
                    </div>
                </div>
            </ModalBody>
        </Modal>
    )
}

export default React.memo(LearningAgreementsGlaView);