import React from 'react'
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Row, Col, Input, FormGroup, Label } from 'reactstrap';
import { IRlaAgreementsData } from '../../../../models/learningAgreementsModel';
import { setLearningAgreementsActionTypeAndActionData } from '../../../../store/actions';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';


const LearningAgreementsRlaView: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    let key = userDto?.userType === ERoleDesc.Traninee ? 'actionData' : 'learningAgreementsActionData'

    const rlaAgreementsData: IRlaAgreementsData = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.[key])
            return state.learningAgreementsReducer?.[key]
        else return undefined;
    });

    const traineeData: any = useSelector((state: any) => {
        if (state?.learningAgreementsReducer?.actionData)
            return state.learningAgreementsReducer?.actionData
        else return undefined
    });

    const goBackToList = () => {
        let data = userDto?.userType === ERoleDesc.Traninee ? null : traineeData;
        let type = userDto?.userType === ERoleDesc.Traninee ? EOprationalActions.UNSELECT : EOprationalActions.ADD
        dispatch(setLearningAgreementsActionTypeAndActionData(type, data, null))
    }

    return (
        <>
            <div className="flexLayout">
            <div className="breadcrumbs">
                <span className="pointer" onClick={goBackToList}>{t('LearningAgreements.aggrementDetails')}</span>
                <span><i className="ti-angle-right"></i></span>
                <span className="active">
                    {t('ActionNames.view')}
                </span>
            </div>
                <div className="flexScroll pr-3">
                        <div className="top-section">
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.traineeName')}</Label>
                                            <Input name='traineeName' value={rlaAgreementsData?.traineeName || '-'} type="text" disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.programmeName')}</Label>
                                            <Input type="text" name='programName' value={rlaAgreementsData?.programName || '-'} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.headoftheDepartment')}</Label>
                                            <Input type="text" name='headoftheDepartment' value={rlaAgreementsData?.hodName || '-'} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.educationalSupervisor')}</Label>
                                            <Input type="text" disabled value={rlaAgreementsData?.esName || '-'} name='educationalSupervisor' className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    {<Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.mOHSupervisor')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.mohName || '-'} disabled name='mOHSupervisor' className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    }
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <h2><div> {t('LearningAgreements.rotationDetails')}</div></h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>  {t('LearningAgreements.universityName')}</Label>
                                            <Input type="text" disabled value={userDto.university?.universityName || '-'} className='form-control' name='universityName' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.stage')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.stageName || '-'} disabled name='stage' className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.rotation')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.rotationName || '-'} disabled name='rotation' className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.rotationstartDate')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.rotationStartDate || '-'} disabled name='rotationstartDate' className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.rotationEndDate')}</Label>
                                            <Input type="text" disabled value={rlaAgreementsData?.rotationEndDate || '-'} name='rotationEndDate' className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.rotationDuration')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.rotationDuration || '-'} disabled name='rotationDuration' className='form-control' />
                                        </FormGroup>
                                    </Col>

                                </Row>

                                <Row>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.hosptialName')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.hospitalName || '-'} disabled name='hosptialName' className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.otherHospitalName')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.otherHospitalName || '-'} disabled placeholder={t('LearningAgreements.otherHospitalName')} name='otherHospitalName' className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.placementAimsandobjective')}</Label>
                                            <Input type='textarea' value={rlaAgreementsData?.placementAmisObject || '-'} name='placementAimsandobjective' disabled rows={1} className="comments form-control" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.plannedAbsences&Conferences')}</Label>
                                            <Input type='textarea' value={rlaAgreementsData?.plannedAbsencesConferences || '-'} name='plannedAbsencesConferences' disabled rows={1} className="comments form-control" />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />

                        <div className="top-section">
                            <h2> {t('LearningAgreements.clinicalSupervisorDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <Label> {t('LearningAgreements.firstRotationalSupervisor')}</Label>
                                        <Input type="text" disabled value={rlaAgreementsData?.firstRotationalSupervisor?.supervisorName || '-'} name='firstRotationalSupervisor' className='form-control' />
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label> {t('LearningAgreements.secondRotationalSupervisor')}</Label>
                                            <Input type="text" value={rlaAgreementsData?.secondRotationSupervisor?.supervisorName || '-'} disabled name="secondRotationalSupervisor" className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <h2><div>{t('LearningAgreements.wbaDetails')}</div></h2>
                            <div className="details-section section-border mt-3 table-responsive">
                                <table className="details-table table">
                                    <thead>
                                        <tr>
                                            <th>{t('LearningAgreements.name')}</th>
                                            <th>{t('LearningAgreements.expected')}</th>
                                            <th>{t('LearningAgreements.planned')}</th>
                                            <th>{t('LearningAgreements.completed')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            rlaAgreementsData?.expectedWbas?.map(x => (
                                                <tr key={x.wbaId}>
                                                    <td>{x.wbaName}</td>
                                                    <td className="column-center"><span className="wba-bg">{x.wbaExpected}</span></td>
                                                    <td className="column-center"><span className="wba-bg">{x.planned}</span></td>
                                                    <td className="column-center"><span className="wba-bg">{x.completed || 0}</span></td>
                                                </tr>
                                            ))
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="details-section">
                            <Row className="mt-3">
                                <Col sm="5">
                                    <FormGroup className="ml-4">
                                        <div className="terms"><Input type="checkbox" defaultChecked={rlaAgreementsData?.traineeSignature === 'true' ? true : false} disabled name='agreementStatus' />{t('LearningAgreements.agreementStatus')}</div>
                                    </FormGroup>
                                </Col>
                            </Row>
                        </div>
                        <hr />
                        <div className="top-section">
                            <Row className="compHeading">
                                <Col sm="8" xs="12">
                                    <h2>{t('LearningAgreements.firstRotationalSupervisorDetails')}</h2>
                                </Col>
                                <Col sm="4" className="column-center">
                                    <span className="approvedDate">{t('LearningAgreements.approvedOn')} : <span className="date">{rlaAgreementsData?.firstRotationalSupervisor?.approvedOn || '-'}</span></span>
                                </Col>
                            </Row>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.approvalStatus')}</Label>
                                            <Input placeholder={t('LearningAgreements.approvalStatus')} value={rlaAgreementsData?.firstRotationalSupervisor?.status || '-'} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.remarks')}</Label>
                                            <Input placeholder={t('LearningAgreements.supervisorComments')} value={rlaAgreementsData?.firstRotationalSupervisor?.comments || '-'} disabled as='textarea' name='remarks' className="comments" rows={1} />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.signature')}</Label>
                                            <div className="terms"><Input type="checkbox" name='signature' defaultChecked={rlaAgreementsData?.firstRotationalSupervisor?.signature === 'true' ? true : false} disabled />{t('LearningAgreements.acceptanceofAgreement')}</div>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <Row className="compHeading">
                                <Col sm="8" xs="12">
                                    <h2>{t('LearningAgreements.secondRotationalSupervisor')}</h2>
                                </Col>
                                <Col sm="4" className="column-center">
                                    <span className="approvedDate">{t('LearningAgreements.approvedOn')} : <span className="date">{rlaAgreementsData?.secondRotationSupervisor?.approvedOn || '-'}</span></span>
                                </Col>
                            </Row>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.approvalStatus')}</Label>
                                            <Input placeholder={t('LearningAgreements.approvalStatus')} value={rlaAgreementsData?.secondRotationSupervisor?.status || '-'} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.remarks')}</Label>
                                            <Input placeholder={t('LearningAgreements.supervisorComments')} value={rlaAgreementsData?.secondRotationSupervisor?.comments || '-'} disabled as='textarea' name='remarks' className="comments" rows={1} />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('LearningAgreements.signature')}</Label>
                                            <div className="terms"><Input type="checkbox" defaultChecked={rlaAgreementsData?.secondRotationSupervisor?.signature === 'true' ? true : false} name='signature' disabled />{t('LearningAgreements.acceptanceofAgreement')}</div>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <Row className="sub-form-footer mt-3 mr-3">
                            <button className="btn blue-button" type='button' onClick={goBackToList}>{t('LearningAgreements.back')}</button>
                        </Row>
                </div>
            </div>
        </>

    )
}
export default React.memo(LearningAgreementsRlaView);