import React from 'react';
import { connect } from 'react-redux';
import { SuperParentContext } from './learningAgreementsContext';
import {
    LearningAgreementsFilter,
    LearningAgreementsParent,
    LearningAgreementsRlaView,
    LearningAgreementsListViewParent,
    LearningAgreementsGlaView,
    LearningAgreementsListView,
    LearningAgreementsTraineeListViewParent,
    LearningAgreementsTraineeView
} from './learningAgreementsIndex';
import {
    activateAuthLayout,
    getAllLearningAgreementsDetailsRequest,
    setResetLearningAgreementsStateRequest, cancelAllLearningAgreementsApiRequest
} from '../../../../store/actions';
interface IProps {
    activateAuthLayout: any;
    getAllLearningAgreementsDetailsRequest: any;
    setResetLearningAgreementsStateRequest: any;
    cancelAllLearningAgreementsApiRequest: any;
}
class LearningAgreements extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {
            learningAgreementsFilter: LearningAgreementsFilter,
            learningAgreementsRlaView: LearningAgreementsRlaView,
            learningAgreementsListViewParent: LearningAgreementsListViewParent,
            learningAgreementsGlaView: LearningAgreementsGlaView,
            learningAgreementsListView: LearningAgreementsListView,
            learningAgreementsTraineeListViewParent: LearningAgreementsTraineeListViewParent,
            learningAgreementsTraineeView: LearningAgreementsTraineeView
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetLearningAgreementsStateRequest()
        this.props.getAllLearningAgreementsDetailsRequest()

    }
    componentWillUnmount() {
        this.props.setResetLearningAgreementsStateRequest()
        this.props.cancelAllLearningAgreementsApiRequest()
    }
    render() {
        return (

            <SuperParentContext.Provider value={this.state}>
                <LearningAgreementsParent />
            </SuperParentContext.Provider>

        )
    }
}


export default connect(null, { activateAuthLayout, getAllLearningAgreementsDetailsRequest, setResetLearningAgreementsStateRequest, cancelAllLearningAgreementsApiRequest })(LearningAgreements);