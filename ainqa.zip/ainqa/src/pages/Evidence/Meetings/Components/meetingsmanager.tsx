import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/meetingscontext';
import { useSelector } from 'react-redux';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';


const MeetingsManager: React.FC = () => {

    const context = useContext(SuperParentContext);

    const actionType: number = useSelector((state: any) => {
        if (state?.meetingsReducer?.actionType)
            return state.meetingsReducer.actionType
        else return EOprationalActions.UNSELECT
    })

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    return (
        <>
            <div className="flexLayout maincontent">
                {(actionType === EOprationalActions.UNSELECT) && (userDto?.userType !== ERoleDesc.Traninee) && <>
                    <context.meetingsFilter />
                    <context.meetingsTraineeListParent />
                </>}
                {(userDto?.userType === ERoleDesc.Traninee ? actionType === EOprationalActions.UNSELECT : actionType === EOprationalActions.ADD) && <>
                    <context.meetingsFilter />
                    <context.meetingsListParent />
                </>}
                {actionType === EOprationalActions.SELECT && <context.meetingView />}
            </div>
        </>
    )
}

export default React.memo(MeetingsManager)
