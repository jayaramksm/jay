import React, { useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setMeetingsActionTypeAndActionData } from '../../../../store/actions';
import { EApprovelActions, EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { ParentContext } from '../Container/meetingscontext';
import groupBy from 'lodash/groupBy';
import maxBy from 'lodash/maxBy';
import { IMeetingsData } from '../../../../models/meetingsModel';

const MeetingsTraineeView: React.FC = () => {

    const dispatch = useDispatch();
    const context = useContext(ParentContext);

    const allMeetingsData: IMeetingsData[] | undefined = useSelector((state: any) => {
        if (state?.meetingsReducer?.allMeetingsData)
            return state.meetingsReducer.allMeetingsData
        else return undefined;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const allMeetingsGroupedData = groupBy(allMeetingsData, 'traineeId');
    let allMeetingsLatestData;
    if (userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR) {
        allMeetingsLatestData = allMeetingsGroupedData[context]?.map((x: IMeetingsData) => ({ ...x, latestApproved: (x?.secondRotationSupervisor?.approvedOn && x?.firstRotationSupervisor?.approvedOn) ? ((+new Date(x?.secondRotationSupervisor?.approvedOn) > +new Date(x?.firstRotationSupervisor?.approvedOn)) ? x?.secondRotationSupervisor?.approvedOn : x?.firstRotationSupervisor?.approvedOn) : (x?.secondRotationSupervisor?.approvedOn || x?.firstRotationSupervisor?.approvedOn || '-') }))
    }

    const getLatestSubmite = () => {
        if (allMeetingsLatestData)
            return maxBy(allMeetingsLatestData, (data) => +(new Date(data.latestApproved)));
    }


    console.log('MeetingsTraineeView=>', { context, allMeetingsData: allMeetingsData, allMeetingsGroupedData: allMeetingsGroupedData[context] });

    const goToTraineeRotationsRlaView = () => {
        dispatch(setMeetingsActionTypeAndActionData(EOprationalActions.ADD, allMeetingsGroupedData[context], null))
    }

    return (
        <>
            {allMeetingsGroupedData && allMeetingsData && <tr>
                <td onClick={goToTraineeRotationsRlaView} className='pointer ActionStatus'>{allMeetingsGroupedData[context][0].traineeName}</td>
                <td>{allMeetingsGroupedData[context][0]?.programName || '-'}</td>
                {userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR &&
                    <>
                        <td>{getLatestSubmite()?.stage || '-'}</td>
                        {/* <td>
                            <TrimmedText text={'sivasankarsivasankarsivasankarsivasankarsivasankasivasanakakklkakdkdklaklk'} />
                        </td> */}
                        <td>{getLatestSubmite()?.rotationName || '-'}</td>
                    </>
                }
            </tr>}
        </>
    )
}

export default React.memo(MeetingsTraineeView);