import React, { useContext } from 'react';
import View from '../../../../images/View.svg';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext } from '../Container/meetingscontext';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { setMeetingsActionTypeAndActionData } from '../../../../store/actions';
import { IMeetingsData } from '../../../../models/meetingsModel';


const MeetingsListView: React.FC = () => {

    const context = useContext(ParentContext);
    const dispatch = useDispatch();

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    let key = userDto?.userType === ERoleDesc.Traninee ? 'allMeetingsData' : 'actionData'

    const meetingData: IMeetingsData = useSelector((state: any) => {
        if (state?.meetingsReducer?.[key])
            return state.meetingsReducer?.[key]?.find(x => x.rotationalMeetingId === context);
        else return undefined;
    });

    const actionData: any = useSelector((state: any) => {
        if (state?.meetingsReducer?.[key])
            return state.meetingsReducer?.[key];
        else return undefined;
    });

    const viewMeeting = () => {
        let data = userDto?.userType === ERoleDesc.Traninee ? meetingData : actionData
        dispatch(setMeetingsActionTypeAndActionData(EOprationalActions.SELECT, data, meetingData))
    }

    return (
        <>
            {meetingData && <tr>
                <td>{meetingData.stage}</td>
                <td>{meetingData.rotationName}</td>
                <td>{meetingData.firstRotationSupervisor?.supervisorName || '-'}</td>
                <td>{meetingData.secondRotationSupervisor?.supervisorName || '-'}</td>
                <td>{meetingData.meetingType}</td>
                <td>{meetingData.meetingDateTime}</td>
                <td className="ActionStatus text-center">
                    <span><img src={View} onClick={viewMeeting} alt="View Icon" className="actionicon pointer" /></span>
                </td>
            </tr>}
        </>
    )
}

export default React.memo(MeetingsListView)
