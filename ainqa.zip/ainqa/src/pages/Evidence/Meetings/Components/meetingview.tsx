import React from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { EMeetingType, IClinicalMeetings } from '../../../../models/clinicalMeetingsModel';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';
import { setMeetingsActionTypeAndActionData } from '../../../../store/actions';


const MeetingsView: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();



    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    let key = userDto?.userType === ERoleDesc.Traninee ? 'actionData' : 'meetingsActionData'

    const actionData: IClinicalMeetings = useSelector((state: any) => {
        if (state?.meetingsReducer?.[key])
            return state.meetingsReducer?.[key]
        else return undefined
    });

    const traineeData: any = useSelector((state: any) => {
        if (state?.meetingsReducer?.actionData)
            return state.meetingsReducer?.actionData
        else return undefined
    });

    const goBackToMeetings = () => {
        let data = userDto?.userType === ERoleDesc.Traninee ? null : traineeData;
        let type = userDto?.userType === ERoleDesc.Traninee ? EOprationalActions.UNSELECT : EOprationalActions.ADD
        dispatch(setMeetingsActionTypeAndActionData(type, data, null))
    }

    console.log('MeetingsView===>', actionData)

    return (
        <>
                    <div className="breadcrumbs">
                        <span className="pointer" onClick={goBackToMeetings}>{t('MeetingsView.clinicalMeetings')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">
                            {t('ActionNames.view')}
                        </span>
                    </div>
            <div className="flexScroll pr-3">
                        <div className="top-section">
                            <h2>{t('MeetingsView.programDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.programName')}</Label>
                                            <Input name='programName' type="text" disabled value={actionData?.programName || '-'} className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.educationalSupervisor')}</Label>
                                            <Input name='educationalSupervisor' value={actionData?.esName || '-'} type="text" disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        {/* <FormGroup>
                                                <Label>{t('RotationalMeetings.headofTheDepartment')}</Label>
                                                <Input type="text" placeholder={t('RotationalMeetings.selectHod')} disabled value="Dr. Ramesh"></Input>
                                            </FormGroup> */}
                                        <FormGroup>
                                            <Label>{t('MeetingsView.headofTheDepartment')}</Label>
                                            <Input value={actionData?.hodName || '-'} type="text" disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />

                        <div className="top-section">
                            <h2>{t('MeetingsView.rotationDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.universityName')}</Label>
                                            <Input name='universityName' value={userDto?.university?.universityName || '-'} type="text" placeholder={t('RotationalMeetings.universityName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.stage')}</Label>
                                            <Input name='stage' value={actionData?.stage || '-'} type="text" placeholder={t('RotationalMeetings.universityName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.rotation')}</Label>
                                            <Input name='rotation' value={actionData?.rotationName || '-'} type="text" placeholder={t('RotationalMeetings.universityName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.hospitalName')} </Label>
                                            <Input type="text" name='hospitalName' value={actionData?.hospitalName ? actionData?.hospitalName : ''} placeholder={t('RotationalMeetings.hospitalName')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.rotationDuration')}</Label>
                                            <Input type="text" name='rotationDuration' value={actionData?.rotationDuration || '-'} placeholder={t('RotationalMeetings.rotationDuration')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />

                        <div className="top-section">
                            <h2>{t('MeetingsView.supervisorDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.firstRotationalSupervisor')}</Label>
                                            <Input type="text" name='firstRotationalSupervisor' value={actionData?.firstRotationSupervisor?.supervisorName || '-'} placeholder={t('RotationalMeetings.firstRotationalSupervisor')} disabled className='form-control' />

                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.secondRotationalSupervisor')}</Label>
                                            <Input type="text" name='secondRotationalSupervisor' value={actionData?.secondRotationSupervisor?.supervisorName || '-'} placeholder={t('RotationalMeetings.secondRotationalSupervisor')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <h2>{t('MeetingsView.meetingDetails')}</h2>
                            <div className="details-section">
                                <Row className="mt-3">
                                    <Col sm='4'>
                                        <FormGroup>
                                            <Label>{t('MeetingsView.meetingType')}</Label>
                                            <Input type="text" name='meetingType' value={actionData?.meetingType || '-'} placeholder={t('MeetingsView.meetingType')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.meetingDateandTime')}</Label>
                                            <Input type="text" name='meetingStartDate' value={actionData?.meetingDateTime || '-'} placeholder={t('MeetingsView.meetingStartDate')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>
                                    {actionData?.meetingType !== EMeetingType.FinalMeeting && <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.agreedNextMeetingDate')}</Label>
                                            <Input type="text" name='agreedNextMeetingDate' value={actionData?.nextMeetingDate || '-'} placeholder={t('MeetingsView.agreedNextMeetingDate')} disabled className='form-control' />
                                            {actionData?.meetingType === EMeetingType.InterimMeeting && <div className="mt-2 ml-3">
                                                {/* <Label>{t('RotationalMeetings.finalMeeting')}</Label> */}
                                                <Input type="checkbox" checked={actionData?.isFinalMeeting} disabled name='isFinalMeeting' />{t('MeetingsView.isthisFinalMeeting')}
                                            </div>}
                                        </FormGroup>
                                    </Col>}
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.traineeRemarks')}</Label>
                                            <Input as='textarea' name='traineeRemarks' disabled value={actionData?.traineeComments || '-'} placeholder={t('RotationalMeetings.writeDownHere')} className="comments" rows={1} />
                                            {/* <ErrorMessage name='traineeRemarks' component='div' className='text-danger' /> */}
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <div className="details-section">
                                <Row className="vhcenter">
                                    <Col sm="6" xs="12">
                                        <h2>{t('MeetingsView.firstRotationalSupervisor')}</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate">{t('MeetingsView.approvedOn')} : <span className="date">{actionData?.firstRotationSupervisor?.approvedOn || '-'}</span></span>
                                    </Col>
                                </Row>
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.approvalStatus')}</Label>
                                            <Input type="text" name='approvalStatus' value={actionData?.firstRotationSupervisor?.status || '-'} placeholder={t('MeetingsView.approvalStatus')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.remarks')}</Label>
                                            <Input as='textarea' name='remarks' disabled value={actionData?.firstRotationSupervisor?.comments || '-'} placeholder={t('MeetingsView.writeDownHere')} className="comments" rows={1} />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <hr />
                        <div className="top-section">
                            <div className="details-section">
                                <Row className="vhcenter">
                                    <Col sm="6" xs="12">
                                        <h2>{t('MeetingsView.secondRotationalSupervisor')}</h2>
                                    </Col>
                                    <Col sm="6" xs="12" className="text-right">
                                        <span className="approvedDate">{t('MeetingsView.approvedOn')} : <span className="date">{actionData?.secondRotationSupervisor?.approvedOn || '-'}</span></span>
                                    </Col>
                                </Row>
                                <Row className="mt-3">
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.approvalStatus')}</Label>
                                            <Input type="text" name='approvalStatus' value={actionData?.secondRotationSupervisor?.status || '-'} placeholder={t('MeetingsView.approvalStatus')} disabled className='form-control' />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('MeetingsView.remarks')}</Label>
                                            <Input as='textarea' name='remarks' disabled value={actionData?.secondRotationSupervisor?.comments || '-'} placeholder={t('MeetingsView.writeDownHere')} className="comments" rows={1} />
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </div>
                        </div>
                        <Row className="sub-form-footer my-3 mr-3">
                            <button className="btn blue-button" type='button' onClick={goBackToMeetings}>{t('MeetingsView.back')}</button>
                        </Row>
            </div>
        </>
    )
}

export default React.memo(MeetingsView)
