import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/meetingscontext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import groupBy from 'lodash/groupBy';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setMeetingsPaginationCurrentPageValue } from '../../../../store/actions';
import { IMeetingsData } from '../../../../models/meetingsModel';
import { ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';

const MeetingsTraineeListParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const allMeetingsData: IMeetingsData[] | undefined = useSelector((state: any) => {
        if (state?.meetingsReducer?.allMeetingsData)
            return state.meetingsReducer.allMeetingsData
        else return undefined;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.meetingsReducer?.searchkey)
            return state.meetingsReducer.searchkey;
        else return ''
    });

    const currentPage: number = useSelector((state: any) => state?.meetingsReducer?.paginationCurrentPage || 0);

    const allMeetingsGroupedData = Object.entries(groupBy(allMeetingsData, 'traineeId'));

    const allMeetingsFilterData: any = (allMeetingsGroupedData?.length && searchKey !== '') ? allMeetingsGroupedData?.filter((x: any) => (
        searchKey !== '' ? x?.[1][0].traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : allMeetingsGroupedData;

    let pagesCount: number = Math.ceil((allMeetingsFilterData ? allMeetingsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setMeetingsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setMeetingsPaginationCurrentPageValue(index));
    };

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });

    console.log('ApproveRLATraineeViewParnet=>', allMeetingsData, allMeetingsFilterData);

    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table evt-table">
                                <thead>
                                    <tr>
                                        <th>{t('MeetingsView.traineeName')}</th>
                                        <th>{t('MeetingsView.programName')}</th>
                                        {userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR && <>
                                            <th>{t('MeetingsView.stage')}</th>
                                            <th>{t('MeetingsView.rotation')}</th>
                                        </>}
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        allMeetingsData && allMeetingsFilterData?.length > 0 && allMeetingsFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x) => (
                                            <ParentContext.Provider value={x[0]} key={x[0]}>
                                                <context.meetingsTraineeView />
                                            </ParentContext.Provider>
                                        ))
                                    }
                                </tbody>
                            </table>
                            {allMeetingsData && (allMeetingsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('MeetingsView.noDataFound')}</h6></div>}
                        </div>
                        {allMeetingsFilterData && allMeetingsFilterData.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>
                        }
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(MeetingsTraineeListParent);