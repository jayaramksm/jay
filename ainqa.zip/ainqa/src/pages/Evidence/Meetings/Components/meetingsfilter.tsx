import React from 'react';
import { Row, Col } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { setSearchKeyInMeetingsRequest, setMeetingsActionTypeAndActionData } from '../../../../store/actions';
import { EOprationalActions, ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';

const MeetingsFilter: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const setSearchKey = e => {
        dispatch(setSearchKeyInMeetingsRequest(e.target.value))
    }

    const actionData: any = useSelector((state: any) => {
        if (state?.meetingsReducer?.actionData)
            return state.meetingsReducer.actionData;
        else return undefined;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    const goBackToTraineeView = () => {
        dispatch(setMeetingsActionTypeAndActionData(EOprationalActions.UNSELECT, null, null))
    }

    return (
        <>
            <Row className="compHeading">
                <Col>
                    {actionData && userDto?.userType !== ERoleDesc.Traninee && <div className="breadcrumbs">
                        <span className="pointer" onClick={goBackToTraineeView}>{t('MeetingsView.clinicalMeetings')}</span>
                        <span><i className="ti-angle-right"></i></span>
                        <span className="active">
                            {actionData?.[0]?.traineeName}
                        </span>
                    </div>}
                    {!actionData && <h2>{t('MeetingsView.clinicalMeetings')}</h2>}
                </Col>
                <div className="rgtFilter pr-3">
                    <div className="search-box filtericon">
                        <div className="search-text"><input type="text" onChange={setSearchKey} placeholder={t('MeetingsView.search')}></input><i className="ti-search icon"></i></div>
                    </div>
                </div>
            </Row>
        </>
    )
}

export default React.memo(MeetingsFilter)
