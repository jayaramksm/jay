import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/meetingscontext';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { PaginationComponent } from '../../../utilities/PaginationComponent';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setRotationalMeetingsPaginationCurrentPageValue } from '../../../../store/actions';
import { IMeetingsData } from '../../../../models/meetingsModel';
import { ERoleDesc, IUserDetails } from '../../../../models/utilitiesModel';



const MeetingsListParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState?.userDto;
        else return undefined;
    });

    let key = userDto?.userType === ERoleDesc.Traninee ? 'allMeetingsData' : 'actionData'

    const allMeetingsData: IMeetingsData[] | undefined = useSelector((state: any) => {
        if (state?.meetingsReducer?.[key])
            return state.meetingsReducer?.[key]
        else return undefined;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.meetingsReducer?.searchkey)
            return state.meetingsReducer.searchkey;
        else return '';
    });
    const currentPage: number = useSelector((state: any) => {
        if (state?.meetingsReducer?.paginationCurrentPage)
            return state.meetingsReducer.paginationCurrentPage;
        else return 0;
    });


    const allMeetingsFilterData: any = (allMeetingsData?.length && searchKey !== '') ? allMeetingsData?.filter((x: any) => (
        searchKey !== '' ? x?.rotationName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : allMeetingsData;

    let pagesCount: number = Math.ceil((allMeetingsFilterData ? allMeetingsFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setRotationalMeetingsPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setRotationalMeetingsPaginationCurrentPageValue(index));
    };

    return (
        <>
            <div className="flexScroll">
                <div className="maincontent pr-3">
                    <div className="tbl-parent table-responsive">
                        <table className="myTable meetingtable table">
                            <thead>
                                <tr>
                                    <th>{t('MeetingsView.stage')}</th>
                                    <th>{t('MeetingsView.rotation')}</th>
                                    <th>{t('MeetingsView.firstRotationalSupervisor')}</th>
                                    <th>{t('MeetingsView.secondRotationalSupervisor')}</th>
                                    <th>{t('MeetingsView.meetingType')}</th>
                                    <th>{t('MeetingsView.meetingDateandTime')}</th>
                                    <th className="text-center">{t('MeetingsView.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    allMeetingsData && allMeetingsFilterData.length > 0 && allMeetingsFilterData.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((x: IMeetingsData, ind) => (
                                        <ParentContext.Provider value={x.rotationalMeetingId} key={x.rotationalMeetingId}>
                                            <context.meetingsListView />
                                        </ParentContext.Provider>
                                    ))
                                }
                            </tbody>
                        </table>
                        {allMeetingsFilterData && (allMeetingsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('MeetingsView.noDataFound')}</h6></div>}
                    </div>
                    {allMeetingsFilterData && allMeetingsFilterData.length > pageSize &&
                        <div className="pagination">
                            <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                        </div>
                    }
                </div>
            </div>
        </>
    )
}

export default React.memo(MeetingsListParent)
