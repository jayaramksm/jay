import React from 'react';

export const ParentContext = React.createContext<any>(null);
export const SuperParentContext = React.createContext<any>(null);
export const ChildContext = React.createContext<any>(null);