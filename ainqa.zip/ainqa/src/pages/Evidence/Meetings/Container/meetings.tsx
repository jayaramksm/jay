import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    MeetingsView, MeetingsListParent, MeetingsFilter,
    MeetingsListView, MeetingsManager, MeetingsTraineeListParent, MeetingsTraineeView
} from './meetingsindex';
import { SuperParentContext } from './meetingscontext';
import { activateAuthLayout } from '../../../../store/actions';
import { setResetMeetingsStateRequest, cancelAllMeetingsApiRequest, getAllMeetingsDetailsRequest } from '../../../../store/actions';

interface IProps {
    activateAuthLayout: any;
    setResetMeetingsStateRequest: any;
    cancelAllMeetingsApiRequest: any;
    getAllMeetingsDetailsRequest: any;
}

export class Meetings extends Component<IProps, any> {
    constructor(props) {
        super(props)

        this.state = {
            manager: {
                meetingsListParent: MeetingsListParent,
                meetingsFilter: MeetingsFilter,
                meetingView: MeetingsView,
                meetingsListView: MeetingsListView,
                meetingsTraineeView: MeetingsTraineeView,
                meetingsTraineeListParent: MeetingsTraineeListParent
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetMeetingsStateRequest();
        this.props.getAllMeetingsDetailsRequest();
    }
    componentWillUnmount() {
        this.props.setResetMeetingsStateRequest();
        this.props.cancelAllMeetingsApiRequest();
    }

    render() {
        return (
            <>
                <SuperParentContext.Provider value={this.state.manager}>
                    <MeetingsManager />
                </SuperParentContext.Provider>
            </>
        )
    }
}
export default connect(null, { activateAuthLayout, setResetMeetingsStateRequest, cancelAllMeetingsApiRequest, getAllMeetingsDetailsRequest })(Meetings);
