import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, getApproveGlasDataRequest, resetAllApproveGlasStateRequest, cancelAllPendingApproveGlasRequest } from '../../../store/actions';
import { SuperParentContext } from './approveGlaContext';
import { ApproveGlaParent, ApproveGlaViewManager, ApproveGlasView, ApproveGlaAction, ApproveGlaFilter } from './approveGlaIndex';
interface IProps {
    activateAuthLayout;
    getApproveGlasDataRequest;
    resetAllApproveGlasStateRequest;
    cancelAllPendingApproveGlasRequest;
}
class Glas extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            approveGlaViewManager: ApproveGlaViewManager,
            approveGlasView: ApproveGlasView,
            approveGlaAction: ApproveGlaAction,
            approveGlaFilter: ApproveGlaFilter
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllApproveGlasStateRequest();
        this.props.getApproveGlasDataRequest();
    }
    componentWillUnmount() {
        this.props.cancelAllPendingApproveGlasRequest();
        this.props.resetAllApproveGlasStateRequest();

    }
    render() {
        return (

            <div className="flexLayout">

                <SuperParentContext.Provider value={this.state}>
                    <ApproveGlaParent />
                </SuperParentContext.Provider>

            </div>

        )
    }
}


export default connect(null, { activateAuthLayout, getApproveGlasDataRequest, resetAllApproveGlasStateRequest, cancelAllPendingApproveGlasRequest })(Glas);