
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { setSearchApproveGlasData } from '../../../store/actions';


const ApproveGlaFilter: React.FC = () => {
    const { t } = useTranslation('translations');

    const dispatch = useDispatch();
    const onSearchChange = e => {
        const searchInput = e.target.value;
        dispatch(setSearchApproveGlasData(searchInput));
    };
    const showAGlaFilter = useSelector((state: any) => !!(state?.approveGlasReducer?.approveGlasData?.length > 2));

    return (
        <Row className="compHeading">
            <Col>
                <h2 className="mb-0"> {t('approveGla.approveGLA')}</h2>
            </Col>
            {showAGlaFilter && <div className="rgtFilter">
                <div className="search-box filtericon">
                    <div className="search-text"><input type="text" onChange={onSearchChange} placeholder="Search"></input><i className="ti-search icon"></i></div>
                </div>
            </div>}
        </Row>

    )
}
export default React.memo(ApproveGlaFilter);