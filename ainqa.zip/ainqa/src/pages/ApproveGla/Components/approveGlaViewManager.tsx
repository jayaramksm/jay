
import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/approveGlaContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setApproveGlasPaginationCurrentPageValue } from 'store/actions';
import { IApproveGlasMOdel, IGla } from '../../../models/approveGlaModel';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { PaginationComponent } from '../../utilities/PaginationComponent';

const ApproveGlaViewManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;
    const { t } = useTranslation('translations');

    const approveGlasData: IGla[] | any = useSelector((state: any) => {
        if (state?.approveGlasReducer?.approveGlasData)
            return (state.approveGlasReducer as IApproveGlasMOdel)?.approveGlasData;
        else return undefined;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approveGlasReducer?.searchKey)
            return (state.approveGlasReducer as IApproveGlasMOdel).searchKey;
        else return "";
    });

    const approveGlasFilterData: IGla[] = (approveGlasData && searchKey !== '') ? approveGlasData?.filter((x: any) => (
        searchKey !== '' ? x?.traineeName?.toLowerCase()?.startsWith(searchKey.toLowerCase()) : true
    )) : approveGlasData;

    const currentPage: number = useSelector((state: any) => {
        if (state?.approveGlasReducer?.paginationCurrentPage)
            return (state.approveGlasReducer as IApproveGlasMOdel).paginationCurrentPage;
        else return 0;
    });


    let pagesCount: number = Math.ceil((approveGlasFilterData ? approveGlasFilterData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        dispatch(setApproveGlasPaginationCurrentPageValue(0));

    const handleClick = (e, index) => {
        e.preventDefault();
        console.log('_pagination_index', index);
        dispatch(setApproveGlasPaginationCurrentPageValue(index));
    };

    console.log("ApproveGlaViewManager==>", approveGlasData, context);

    return (
        <>
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable table approve-gla-table">
                                <thead>
                                    <tr>
                                        <th> {t('approveGla.traineeName')}</th>
                                        <th> {t('approveGla.programName')}</th>
                                        <th>{t('approveGla.agreementDate')}</th>
                                        <th>{t('approveGla.educationalSupervisor')}</th>
                                        <th className="column-center">{t('approveGla.approvalStatus')}</th>
                                        <th>{t('approveGla.mOHSupervisor/coeducationalSupervisor')}</th>
                                        <th className="column-center"> {t('approveGla.approvalStatus')}</th>
                                        <th>{t('approveGla.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    {approveGlasFilterData && approveGlasFilterData?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize)).map((gla) => (
                                        <ParentContext.Provider value={gla.glaId} key={gla.glaId}>
                                            <context.approveGlasView />
                                        </ParentContext.Provider>
                                    ))}
                                </tbody>
                            </table>
                            {(approveGlasFilterData && approveGlasFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('approveGla.noDataFound')}</h6></div>}
                        </div>
                        {approveGlasFilterData && approveGlasFilterData.length > pageSize &&
                            <div className="pagination">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>}
                    </div>
                </div>
            </div>
        </>
    )
}
export default React.memo(ApproveGlaViewManager);