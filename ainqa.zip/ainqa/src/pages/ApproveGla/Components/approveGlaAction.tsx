import React from 'react'
import { setApproveGlasStatusRequest, setApproveGlasActionTypeData, isEditApproveGlaRequest } from '../../../store/actions';
import { EApprovelActions, EOprationalActions, ERoleDesc, IUserDetails } from '../../../models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, customContentValidation, defultContentObjectValidate } from '../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { Row, Col, Label, FormGroup, Input, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { IApproveGlasMOdel, IGla } from '../../../models/approveGlaModel';


const approvalOptions = [{ value: 'approved', label: 'Approved' },
{ value: 'rejected', label: 'Rejected' }];

const ApproveGlaAction: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionType = useSelector((state: any) => {
        if (state?.approveGlasReducer?.actionType) {
            return (state.approveGlasReducer as IApproveGlasMOdel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const actionData: IGla = useSelector((state: any) => {
        if (state?.approveGlasReducer?.actionData) {
            return (state.approveGlasReducer as IApproveGlasMOdel).actionData
        } else {
            return undefined
        }
    });


    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto;
        else return {};
    });

    const initialValues = () => ({
        approvelStatus: actionData ? ((userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR && actionData?.esId === userDto?.userId) ? approvalOptions.find(x => x.value === actionData?.esStatus) : approvalOptions.find(x => x.value === actionData?.mohStatus)) : '',
        comments: actionData ? ((userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR && actionData?.esId === userDto?.userId) ? actionData?.esComments || '' : actionData?.mohComments || '') : '',
        signatures: actionData ? ((userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR && actionData?.esId === userDto?.userId) ? actionData?.esSignature || '' : actionData?.mohSignature || '') : '',
        supervisorName: userDto?.userFullName,
        supervisorId: actionData?.esId,
        traineeId: actionData?.traineeId,
        traineeUserId: actionData?.universityId,
        glaId: actionData?.glaId,
    });
    const validationSchema = Yup.object().shape({
        approvelStatus: defultContentObjectValidate(t('controleErrors.required')),
        comments: Yup.string().when('approvelStatus', {
            is: (approvelStatus) => approvelStatus?.value === EApprovelActions.REJECTED,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: "" }, 200, 4),
            otherwise: Yup.lazy((val) => {
                if (val)
                    return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4)
                else return defultContentValidate(t(''));
            })
        }),
        signatures: Yup.string().when('approvelStatus', {
            is: (approvelStatus) => approvelStatus?.value === EApprovelActions.APPROVED,
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 50, 4),
            otherwise: defultContentValidate(t('')),
        })
    });

    const setApprovalStatus = (e, setFieldValue) => {
        if (e?.value === EApprovelActions?.REJECTED) {
            setFieldValue('signatures', '');
        }
        setFieldValue('approvelStatus', e);
    }

    const cancel = () => {
        dispatch(isEditApproveGlaRequest(actionData.glaId, false));
        dispatch(setApproveGlasActionTypeData(EOprationalActions.UNSELECT, null));
    };

    console.log("ApproveGlaAction==>", actionData, actionType, actionData?.esUserName, userDto?.userFullName);

    return (

        <>
            <Modal className="modal-lg glamodal" isOpen={true} style={{ margin: "0 auto" }}>
                <ModalHeader style={{ position: "sticky", top: 0, zIndex: 3, background: "#ffffff", borderRadius: "0" }}>
                    <div className="text-center"> {t('approveGla.learningAgreementForAcademicSupervision')}</div>
                    <div className="modal-close"><button className="btn btn-danger" onClick={cancel}><i className="ti-close"></i></button></div>
                </ModalHeader>
                <ModalBody>
                    <div className="px-4">
                        <h6> {t('approveGla.thisLatterofUndertakingDefinesTheRelationshipBetween')}</h6>

                        <Formik
                            enableReinitialize
                            initialValues={initialValues()}
                            validationSchema={validationSchema}
                            onSubmit={(values) => {
                                dispatch(setApproveGlasStatusRequest(values, actionType));
                                if (actionType === EOprationalActions.EDIT)
                                    dispatch(isEditApproveGlaRequest(actionData.glaId, false));
                                console.log("SubmitedValues==>", actionType, values);
                            }}>
                            {({ errors, setFieldValue, setFieldTouched, values, touched }) => (
                                <Form>

                                    <Row>
                                        <Col sm="6">
                                            <FormGroup>
                                                <Label>{t('approveGla.educationalSupervisor')} </Label>
                                                <Input type="text" value={actionData?.esUserName || ''} disabled></Input>
                                            </FormGroup>
                                        </Col>

                                        {actionData?.mohUserName && <Col sm="6">
                                            <FormGroup>
                                                <Label> {t('approveGla.mOHSupervisor/coeducationalSupervisor')}</Label>
                                                <Input type="text" value={actionData?.mohUserName || ''} disabled></Input>
                                            </FormGroup>
                                        </Col>}
                                    </Row>

                                    <Row>
                                        <Col sm="11" xs="12" className="flexone">
                                            <p className="mr-4 alone"> {t('approveGla.and')}</p>
                                            <FormGroup className="flexone-item">
                                                <Label> {t('approveGla.nameofTrainee')}</Label>
                                                <Input type="text" value={actionData?.traineeName || ''} disabled></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="8" className="flexone">
                                            <p className="mr-4 alone">  {t('approveGla.fortheprogramof')}</p>
                                            <FormGroup className="flexone-item">
                                                <Label>  {t('approveGla.nameofProgram')}</Label>
                                                <Input type="text" value={actionData?.programName || ''} disabled></Input>
                                            </FormGroup>


                                            <FormGroup className="flexone-item flexone-item-inline">
                                                <Label>{t('approveGla.matricNumber')}</Label>
                                                <Input type="text" value={actionData?.matricNumber || ''} disabled></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>
                                        <Col sm="6" className="flexone">
                                            <p className="mr-4 alone"> {t('approveGla.at')}</p>
                                            <FormGroup className="flexone-item">
                                                <Label>{t('approveGla.nameofAcademy/Institute/Faculty/Centre ')}</Label>
                                                <Input type="text" value={userDto.university?.universityName || ''} disabled></Input>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <p className="mt-4">
                                        {t('approveGla.academicSupervisionOne')}
                                        <br /><br />

                                        {t('approveGla.academicSupervisionTwo')} <br /><br />

                                        {t('approveGla.academicSupervisionThree')}
                                    </p>
                                    <div className="roles">
                                        <h1>{t('approveGla.rOLESANDRESPONSIBILITIESOFTHETRAINEE')}   </h1>
                                        <div className="mx-1 roles-pad">
                                            <h2 className="line-through"><span>{t('approveGla.general')}</span></h2>
                                            <ol>
                                                <li> {t('approveGla.traineeAgreemant1')} </li>

                                                <li className="tmargin">{t('approveGla.traineeAgreemant2')}&nbsp;
                                                    <div className="period">
                                                        <Input type="text" value={actionData?.period || ''} disabled></Input>
                                                    </div>
                                                    {t('approveGla.traineeAgreemant3')}&nbsp;
                                                    <div className="moc">
                                                        <Input type="text" value={actionData?.communication || ''} disabled></Input>
                                                    </div>
                                                </li>

                                                <li>   {t('approveGla.traineeAgreemant4')} </li>

                                                <li>  {t('approveGla.traineeAgreemant5')} </li>

                                                <li> {t('approveGla.traineeAgreemant6')} </li>

                                                <li>  {t('approveGla.traineeAgreemant7')} </li>
                                                <ol className="sublist">
                                                    <li>{t('approveGla.traineeAgreemant8')}</li>
                                                    <li>{t('approveGla.traineeAgreemant9')}</li>
                                                    <li>{t('approveGla.traineeAgreemant10')}</li>
                                                    <li> {t('approveGla.traineeAgreemant11')}</li>
                                                    <li> {t('approveGla.traineeAgreemant12')}</li>
                                                    <li> {t('approveGla.traineeAgreemant13')} </li>
                                                    <li>{t('approveGla.traineeAgreemant14')}</li>
                                                </ol>


                                                <li> {t('approveGla.traineeAgreemant15')} </li>
                                            </ol>
                                        </div>
                                    </div>
                                    <p className="py-4">{t('approveGla.traineeAgreemant16')}</p>
                                    <div className="roles">
                                        <h1> {t('approveGla.supervisorAgreement')}</h1>
                                        <div className="mx-1 roles-pad">
                                            <h2 className="line-through"><span> {t('approveGla.general')}</span></h2>
                                            <ol>
                                                <li>  {t('approveGla.supervisorAgreement1')} </li>

                                                <li> {t('approveGla.supervisorAgreement2')} </li>

                                                <li> {t('approveGla.supervisorAgreement3')} </li>

                                                <li>  {t('approveGla.supervisorAgreement4')} </li>

                                                <li className="tmargin"> {t('approveGla.supervisorAgreement5')}&nbsp;
                                                    <div className="period">
                                                        <Input type="text" value={actionData?.period || ''} disabled></Input>
                                                    </div>
                                                    {t('approveGla.supervisorAgreement6')}&nbsp;

                                                    <div className="moc">
                                                        <Input type="text" value={actionData?.communication || ''} disabled></Input>
                                                    </div>
                                                </li>

                                                <li>   {t('approveGla.supervisorAgreement7')} </li>

                                                <li> {t('approveGla.supervisorAgreement8')} </li>

                                                <li> {t('approveGla.supervisorAgreement9')} </li>

                                                <li> {t('approveGla.supervisorAgreement10')} </li>

                                                <li> {t('approveGla.supervisorAgreement11')} </li>

                                                <li> {t('approveGla.supervisorAgreement12')} </li>

                                                <li> {t('approveGla.supervisorAgreement13')} </li>

                                                <li> {t('approveGla.supervisorAgreement14')} </li>
                                            </ol>
                                            <h2 className="line-through"><span> {t('approveGla.supervisorAgreement15')}  </span></h2>
                                            <ol>
                                                <li> {t('approveGla.supervisorAgreement16')} </li>

                                                <li> {t('approveGla.supervisorAgreement17')} </li>

                                                <li> {t('approveGla.supervisorAgreement18')} </li>
                                            </ol>
                                        </div>
                                    </div>

                                    <div className="mt-3">

                                        <Row>
                                            <Col sm='6'>
                                                <FormGroup >
                                                    <Label>  {t('approveGla.approvalStatus')}</Label>

                                                    <MySelect
                                                        name='approvelStatus'
                                                        value={values.approvelStatus}
                                                        placeholder={t('asds.approvalStatus')}
                                                        onChange={(e) => setApprovalStatus(e, setFieldValue)}
                                                        options={approvalOptions ? approvalOptions : []}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        isDisabled={actionType === EOprationalActions.SELECT}
                                                        onBlur={() => setFieldTouched('approvelStatus', true)}
                                                        noOptionsMessage={() => { t('asds.NoDataFound') }}
                                                    />
                                                    {errors.approvelStatus && touched.approvelStatus && (
                                                        <div className="text-danger">{errors.approvelStatus}</div>
                                                    )}
                                                </FormGroup>
                                            </Col>
                                            <Col sm='6'>
                                                <FormGroup >
                                                    <Label>  {t('approveGla.comments')}</Label>
                                                    <Field as="textarea" rows={1} placeholder={t('approveGla.comments')} name='comments' disabled={actionType === EOprationalActions.SELECT} className='form-control' />
                                                    <ErrorMessage name='comments' component='div' className='text-danger' />
                                                </FormGroup>
                                            </Col>

                                            <Col sm='6'>
                                                <FormGroup >
                                                    <Label>  {t('approveGla.signature')}</Label>
                                                    <Field placeholder={t('approveGla.signature')} name='signatures' disabled={(values.approvelStatus as any)?.value === EApprovelActions?.REJECTED || actionType === EOprationalActions.SELECT} className='form-control' />
                                                    <ErrorMessage name='signatures' component='div' className='text-danger' />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        {actionType !== EOprationalActions.SELECT && <div className="text-center mb-4"><button className="btn mt-3 modal-submit-button">{actionType === EOprationalActions.ADD ? 'Submit' : 'update'} </button> </div>}
                                    </div>

                                </Form>
                            )
                            }
                        </Formik>
                    </div>
                </ModalBody>
            </Modal>
        </>

    )
}

export default React.memo(ApproveGlaAction)