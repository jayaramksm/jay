import React, { useContext } from 'react';
import { ParentContext } from '../Container/approveGlaContext';
import { EApprovelActions, EOprationalActions, ERoleDesc, IUserDetails } from '../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'react-i18next';
import Approved from '../../../images/Approved.svg';
import { isEditApproveGlaRequest, setApproveGlasActionTypeData } from '../../../store/actions';
import { IApproveGlasMOdel, IGla } from '../../../models/approveGlaModel';
import pending from '../../../images/Pending.svg';
import reject from '../../../images/Reject.svg';

const ApproveGlasView: React.FC = () => {
    // const context: any = useContext(ChildContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const context: any = useContext(ParentContext);

    const glasData: IGla | any = useSelector((state: any) => {
        if (state?.approveGlasReducer?.approveGlasData?.length) {
            let glasData = (state.approveGlasReducer as IApproveGlasMOdel).approveGlasData;
            return glasData.find(gla => gla.glaId === context);
        } else
            return undefined;
    });
    const approveGla = () => {
        dispatch(setApproveGlasActionTypeData(EOprationalActions.EDIT, glasData));
        dispatch(isEditApproveGlaRequest(glasData?.glaId, true));
    };
    const viewGla = () => {
        dispatch(setApproveGlasActionTypeData(EOprationalActions.SELECT, glasData));
    };

    const userDto: IUserDetails = useSelector((state: any) => state?.SessionState?.userDto);
    console.log("ApproveGlasView==>", glasData, userDto);

    return (
        <>
            <tr>
                <td>{glasData?.traineeName}</td>
                <td>{glasData?.programName}</td>
                <td>{glasData?.agreementDate}</td>
                <td>{glasData?.esUserName}</td>
                <td className="column-center">{(glasData?.esStatus === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (glasData?.esStatus === EApprovelActions.PENDING ? <img src={pending} className="icon" alt="" /> : glasData?.esStatus === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "")}</td>
                <td>{glasData?.mohUserName || '-'}</td>
                <td className="column-center">{glasData?.mohStatus ? (glasData?.mohStatus === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (glasData?.mohStatus === EApprovelActions.PENDING ? <img src={pending} className="icon" alt="" /> : glasData?.mohStatus === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "") : '-'}</td>

                <td>
                    {(userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR && glasData?.esId === userDto?.userId) && <>{
                        glasData?.esStatus !== EApprovelActions.PENDING ? <div className="ActionStatus pointer" onClick={viewGla}> {t('asds.view')}</div> : <div className="ActionStatus pointer" onClick={approveGla}> {t('asds.approve')}</div>}</>}
                    {(userDto?.userType === ERoleDesc.MOHSUPERVISOR || (glasData?.mohId === userDto?.userId && userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR)) && <>{(glasData?.mohStatus !== EApprovelActions.PENDING) ? <div className="ActionStatus pointer" onClick={viewGla}> {t('asds.view')}</div> : <div className="ActionStatus pointer" onClick={approveGla}> {t('asds.approve')}</div>}</>}
                </td>
            </tr>
        </>

    )
}
export default React.memo(ApproveGlasView);