import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/approveGlaContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { IApproveGlasMOdel } from '../../../models/approveGlaModel';

const ApproveGlaParent: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const isApproveGlaListActionType = useSelector((state: any) => {
        if (state?.approveGlasReducer)
            return (state.approveGlasReducer as IApproveGlasMOdel)?.actionType === EOprationalActions.UNSELECT;
        else return true;
    });
    console.log("ApproveGlaParent==>", isApproveGlaListActionType);

    return (
        <>
            {isApproveGlaListActionType ?
                <>
                    <context.approveGlaFilter />
                    <context.approveGlaViewManager />
                </>
                :
                <context.approveGlaAction />
            }
        </>
    )
}
export default React.memo(ApproveGlaParent);