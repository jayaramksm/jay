import React, { Component } from 'react';
import { Row, Col, Label, FormGroup, Input, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Approved from '../../images/Approved.svg';
import View from '../../images/View.svg';
import Select from 'react-select';
import Replace from '../../images/Replace.svg';
import EditIcon from '../../images/Edit.svg';

class GeneralLearningAgreement1 extends Component<any, any> {

    constructor(props: any) {
        super(props);
        this.state = {
            datevalue: new Date(),
            selectedOption: null,
            isModel: false
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    communicationOptions = [{ value: 'email', label: 'Email' },
    { value: 'sms', label: 'SMS' }];

    periodOptions = [{ value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' }];

    ednSupervisorOptions = [{ value: 'sup1', label: 'Dr David' },
    { value: 'sup2', label: 'Dr Arnold' },
    { value: 'sup3', label: 'Dr John' },
    { value: 'sup4', label: 'Dr Smith' }];

    coEdnSupervisorOptions = [{ value: 'sup5', label: 'Dr Martin' },
    { value: 'sup6', label: 'Dr Luther' },
    { value: 'sup7', label: 'Dr Kane' },
    { value: 'sup8', label: 'Dr Jane' }];


    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    render() {
        const { selectedOption } = this.state;

        return (
            <React.Fragment>
                <Modal className="modal-lg glamodal" isOpen={this.state.isModel} style={{margin:"0 auto"}}>
                    <ModalHeader style={{position:"sticky", top:0, zIndex:3, background:"#ffffff", borderRadius:"0"}}>
                        <div className="text-center">LEARNING AGREEMENT FOR ACADEMIC SUPERVISION</div>
                        <div className="modal-close"><button className="btn btn-danger" onClick={() => this.setState({isModel:!this.state.isModel})}><i className="ti-close"></i></button></div>
                    </ModalHeader>
                    <ModalBody>
                        <div className="px-4">
                            <h6>This letter of undertaking defines the relationship between</h6>
                            <Row>
                                <Col sm="6">
                                    <FormGroup>
                                        <Label>Educational Supervisor *</Label>
                                        <Select
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.ednSupervisorOptions}
                                            defaultValue={{ value: 'sup1', label: 'Dr David' }}
                                            placeholder="Select Educational Supervisor"
                                        />
                                    </FormGroup>
                                </Col>

                                <Col sm="6">
                                    <FormGroup>
                                        <Label>Co-educational Supervisor</Label>
                                        <Select
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.coEdnSupervisorOptions}
                                            defaultValue={{ value: 'sup5', label: 'Dr Martin' }}
                                            placeholder="Select Co Educational Supervisor"
                                        />
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm="11" xs="12" className="flexone">
                                    <p className="mr-4 alone">and</p>
                                    <FormGroup className="flexone-item">
                                        <Label>Name of Trainee</Label>
                                        <Input type="text" placeholder="Johnny Depp" disabled></Input>
                                    </FormGroup>

                                    <FormGroup className="flexone-item">
                                        <Label>Matric Number</Label>
                                        <Input type="text" placeholder="M12578" disabled></Input>
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm="8" className="flexone">
                                    <p className="mr-4 alone">For the program of</p>
                                    <FormGroup className="flexone-item">
                                        <Label>Name of Program</Label>
                                        <Input type="text" placeholder="Family Medicine" disabled></Input>
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm="6" className="flexone">
                                    <p className="mr-4 alone">at</p>
                                    <FormGroup className="flexone-item">
                                        <Label>Name of Academy/Institute/Faculty/Centre</Label>
                                        <Input type="text" placeholder="University of Malaya" disabled></Input>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <p className="mt-4">
                                The following section outlines the roles and responsibilities of the Academic Supervisor and Trainee,
                                in order to ensure a high quality of supervision, and output that is consistent with the mission and vision
                                of the Institute/Centre/University, pursuant to the requirements of the Postgraduate National Curriculum.<br /><br />

                                Please read the following and sign where indicated on the last page of the letter of undertaking.<br /><br />

                                The trainee shall be responsible for his/her candidature and research throughout their status as a trainee in
                                the respective Institution/Centre/University as set out below:
                            </p>
                            <div className="roles">
                                <h1>ROLES AND RESPONSIBILITIES OF THE TRAINEE</h1>
                                <div className="mx-1 roles-pad">
                                    <h2 className="line-through"><span>General</span></h2>
                                    <ol>
                                        <li>Trainees shall understand and fulfil all of the requirements stated in the offer letter, rules and regulations
                                            applicable to the program.</li>

                                        <li className="tmargin">Trainees shall meet regularly with Academic Supervisors on a regular basis <Select className="period d-inline-block"
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.periodOptions}
                                            placeholder="Choose Period"
                                        /> Academic Supervisors and trainees shall meet face-to-face in the first meeting. Subsequent meetings may be conducted
                                            via other forms of communication <Select className="moc d-inline-block"
                                                onChange={(e) => this.handleChange(e)}
                                                options={this.communicationOptions}
                                                placeholder="Mode of Communication"
                                            /></li>

                                        <li>Academic Supervisor-trainee interactions should be documented, to provide a record of progress and
                                            achievements during the period of training. Documentation may be in electronic or paper format.</li>

                                        <li>Trainees shall establish a good working relationship with the Academic Supervisors.</li>

                                        <li>Trainees shall discuss and agree on consultation times with the Academic Supervisors.</li>

                                        <li>Trainees shall plan the research schedule to allow completion within the provisions of the programme. This includes, but is not limited to:
                                            <ol className="sublist">
                                                <li>presenting regular updates on their research progress</li>
                                                <li>notifying their Academic Supervisor of any problems that may interfere with the research / thesis / dissertation.</li>
                                                <li>engaging in relevant academic activities</li>
                                                <li>ensuring sufficient time to conduct the research and write the thesis/dissertation.</li>
                                                <li>alerting the Academic Supervisor of the thesis defence date, at least three months in advance.</li>
                                                <li>submission of the written research report/thesis/dissertation, approved by the Academic Supervisor, at the
                                                    specified time, without falsifying the outcome and ensuring that the work is free of plagiarism.</li>
                                                <li>ensuring that corrections are made within the time stipulated by the Panel of Evaluators.</li>
                                            </ol>
                                        </li>

                                        <li>Trainees are solely responsible for the content and the presentation of the research/thesis/dissertation,
                                            including the thesis defence.</li>
                                    </ol>
                                </div>
                            </div>
                            <p className="py-4">The appointed Academic Supervisor(s) shall exercise roles and responsibilities as set out below:</p>
                            <div className="roles">
                                <h1>ROLES AND RESPONSIBILITIES OF THE ACADEMIC SUPERVISOR</h1>
                                <div className="mx-1 roles-pad">
                                    <h2 className="line-through"><span>General</span></h2>
                                    <ol>
                                        <li>Prior to commencing any supervision of trainees, Academic Supervisors should be familiar with the latest
                                            rules and regulations of their programme curriculum, and ensure consistency with the Postgraduate
                                            National Curriculum.</li>

                                        <li>Academic Supervisors should be knowledgeable, up-to-date in conceptual and applied practices, and actively
                                            practising in the trainee’s field of study.</li>

                                        <li>Academic Supervisors should be aware of the milestones in a project schedule, to ensure smooth completion
                                            within the provisions of the programme.</li>

                                        <li>Academic Supervisors are responsible for providing relevant academic guidance and support to trainees
                                            during the supervisory period, to enable completion of projects to a high standard.</li>

                                        <li className="tmargin">Academic Supervisors shall meet with trainees on a regular basis <Select className="period d-inline-block"
                                            onChange={(e) => this.handleChange(e)}
                                            options={this.periodOptions}
                                            placeholder="Choose Period"
                                        /> Academic Supervisors
                                            and trainees shall meet face-to-face in the first meeting. Subsequent meetings may be conducted
                                            via other forms of communication <Select className="moc d-inline-block"
                                                onChange={(e) => this.handleChange(e)}
                                                options={this.communicationOptions}
                                                placeholder="Mode of Communication"
                                            /></li>

                                        <li>Academic Supervisors must be familiar with their responsibilities and advise their trainees on the aspects
                                            that will be supervised. In the event that two (2) or more Academic Supervisors are appointed for each
                                            candidate, the effective working relationship between all parties needs to be maintained together.</li>

                                        <li>Academic Supervisors may advise trainees with regards to preparation of presentations at conferences,
                                            seminars, meetings and workshops. However, trainees are expected to prepare the work themselves.</li>

                                        <li>Academic Supervisor-trainee interactions should be documented, to provide a record of progress and
                                            achievements during the period of training. Documentation may be in electronic or paper format.</li>

                                        <li>Academic Supervisors should monitor the progress of trainees relative to the expected standard. Academic
                                            Supervisors shall inform trainees if the standard is not met, and propose remedial measures.</li>

                                        <li>Academic Supervisors should be aware of, and prepare their trainees for, all formal evaluations. Unsatisfactory
                                            progress, as deemed by the Panel of Evaluators, requires corrective measures by both Academic Supervisor
                                            and trainee.</li>

                                        <li>Academic Supervisors should ensure that any research carried out is in accordance with occupational health
                                            and safety, as well as ethics policies specified by the Institution/Centre/University.</li>

                                        <li>Academic Supervisors should provide constructive comments on trainees’ research/thesis/dissertation
                                            drafts within a reasonable time, and advise on the format of the research/thesis/dissertation as specified
                                            by the Institution/Centre/University.</li>

                                        <li>Academic Supervisors may assist trainees in academic writing, including submission of papers for publication.
                                            When written jointly by the Academic Supervisor and trainee, authorship should be agreed to by both parties
                                            prior to submission.</li>
                                    </ol>
                                    <h2 className="line-through"><span>Role of the Academic Supervisor in the Thesis Defence</span></h2>
                                    <ol>
                                        <li>Academic Supervisors must not be part of the Thesis Defence Panel of Evaluators for trainees they are
                                            supervising. The Panel may ask for input from, or give feedback to, the Academic Supervisor if issues are
                                            identified. The Academic Supervisor must not be involved in determining the outcome of the evaluation.</li>

                                        <li>Academic Supervisors are to provide supervisory reports, where necessary, in the required format within a
                                            stipulated time to the relevant bodies.</li>

                                        <li>Academic Supervisors should assist trainees to make corrections based on feedback from the Panel, and
                                            continue to oversee the trainee should a further defence be required.</li>
                                    </ol>
                                </div>
                            </div>

                            <div className="mt-3">
                                <FormGroup check>
                                    <Label check>
                                        <Input type="checkbox" />{' '}
                                        I have read the above and acknowledge the responsibilities as set by the Institution/Centre/University.
                                    </Label>
                                </FormGroup>
                                <div className="text-center mb-4"><button className="btn mt-3 modal-submit-button">Submit</button></div>
                            </div>
                        </div>
                    </ModalBody>
                </Modal>
                <div className="flexLayout">
                    <div className="flexScroll">
                        <div className="maincontent">
                            <>
                                <h2>General Learning Agreements</h2>
                                <div className="add-button mt-3" onClick={() => this.setState({isModel:!this.state.isModel})}>
                                    <div className="button-text">Add General Learning Agreement</div>
                                    <div className="note">* Please Add Agreement for the Program</div>
                                </div>

                                <div className="main-table">
                                <div className="tbl-parent table-responsive mr-3">
                                    <table className="myTable genl-agreements-table table">
                                        <thead>
                                            <tr>
                                                <th>Agreement Date</th>
                                                <th>Edu. Supervisor Name</th>
                                                <th className="column-center">Approval Status</th>
                                                <th>MOH Supervisor Name</th>
                                                <th className="column-center">Approval Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>05/06/21 15:03</td>
                                                <td>Dr. Prakash</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td>Dr. David</td>
                                                <td className="column-center"><img src={Approved} className="icon" alt="" /></td>
                                                <td>
                                                    <span><img src={View} className="actionicon pointer" alt="View" /></span>
                                                    <span><img src={Replace} className="actionicon pointer" alt="Replace" /></span>
                                                    {/* <span><img src={EditIcon} className="actionicon pointer" alt="Edit" /></span> */}
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(GeneralLearningAgreement1));