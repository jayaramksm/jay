import React, { Component } from 'react';
import { FormGroup, Label, Row, Col } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Approved from '../../images/Approved.svg';
import Replace from '../../images/Replace.svg';
import EditIcon from '../../images/Edit.svg';
import Select from 'react-select';
import Modal from 'react-modal'


class RequestReplaceSupervisor1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            opened: false,
        }
        this.toggleModal = this.toggleModal.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    toggleModal() {
        this.setState({ opened: !this.state.opened });
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    ednSupervisorOptions = [{ value: 'sup1', label: 'Supervisor 1' },
    { value: 'sup2', label: 'Supervisor 2' },
    { value: 'sup3', label: 'Supervisor 3' },
    { value: 'sup4', label: 'Supervisor 4' }];

    render() {

        return (

            <React.Fragment>


                <Modal isOpen={this.state.opened} className="confirmModal modal-md" ariaHideApp={false}>
                    <div>
                        Are you sure want to request for <h5 className="mt-1">Replace of New Supervisor?</h5>
                        <div className="confirmBtns">
                            <button className="btn btnNo" onClick={this.toggleModal}>No</button>
                            <button className="btn btnYes" onClick={this.toggleModal}>Yes</button>
                        </div>

                    </div>


                </Modal>


                <div className="flexLayout">
                    <div className="flexScroll">
                        <div className="maincontent">
                            <h2>Approved GLAs</h2>

                            <div className="main-table">
                                <div className="tbl-parent mr-3 table-responsive">
                                    <table className="myTable genl-agreements-table table">
                                        <thead>
                                            <tr>
                                                <th>GLA</th>
                                                <th>Approval Date</th>
                                                <th>Edu. Supervisor Name</th>
                                                <th>Approval Status</th>
                                                <th>MOH Supervisor Name</th>
                                                <th>Approval Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>GLA</td>
                                                <td>05/06/21</td>
                                                <td>Dr. Prakash</td>
                                                <td><img src={Approved} className="icon" alt="" /></td>
                                                <td>Dr. David</td>
                                                <td><img src={Approved} className="icon" alt="" /></td>
                                                <td><div className="icon-text pointer" onClick={this.toggleModal}><img src={Replace} alt="" /> <span>Replace</span></div></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div className="main-table">
                                <h2>GLAs</h2>

                                <div className="tbl-parent mr-3 table-responsive">
                                    <table className="myTable glas-table table">
                                        <thead>
                                            <tr>
                                                <th>Year</th>
                                                <th>Stage</th>
                                                <th>Agreement No.</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Year I</td>
                                                <td>Stage 1</td>
                                                <td>5128745762</td>
                                                <td>05/06/21</td>
                                                <td>05/06/21</td>
                                                <td><img src={EditIcon} className="actionicon" alt="" /></td>
                                            </tr>
                                            <tr>
                                                <td>Year II</td>
                                                <td>Stage 1</td>
                                                <td>4186752416</td>
                                                <td>07/06/21</td>
                                                <td>07/06/21</td>
                                                <td><img src={EditIcon} className="actionicon" alt="" /></td>
                                            </tr>
                                            <tr>
                                                <td>Year III</td>
                                                <td>Stage 1</td>
                                                <td>687459898</td>
                                                <td>05/06/21</td>
                                                <td>05/06/21</td>
                                                <td><img src={EditIcon} className="actionicon" alt="" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div className="sub-form">
                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Educational Supervisor</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.ednSupervisorOptions}
                                                    placeholder="Select Educational Supervisor"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>MOH Supervisor</Label>
                                                <Select
                                                    onChange={(e) => this.handleChange(e)}
                                                    options={this.ednSupervisorOptions}
                                                    placeholder="Select MOH Supervisor"
                                                />
                                            </FormGroup>
                                        </Col>
                                    </Row>

                                    <Row>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Trainee's Signature</Label>
                                                <div className="terms"><input type="checkbox"></input>Acceptance of Agreement</div>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>Trainee Comments</Label>
                                                <textarea rows={1} className="comments" placeholder="Enter Comments"></textarea>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </div>
                                <Row className="sub-form-footer mt-3 mr-3">
                                    <button className="cancel-button">Cancel</button>
                                    <button className="submit-button">Submit for Approval</button>
                                </Row>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(RequestReplaceSupervisor1));