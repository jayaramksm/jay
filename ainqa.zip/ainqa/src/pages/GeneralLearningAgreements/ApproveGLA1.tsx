import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, UncontrolledDropdown, DropdownToggle, DropdownItem, DropdownMenu } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import PendingIcon from '../../images/Pending.svg';
import Select from 'react-select';


class ApproveGLA1 extends Component<any, any> {

    constructor(props: any) {
        super(props);
        this.state = {
            datevalue: new Date(),
            selectedOption: null
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    yearOptions = [{ value: 'year1', label: 'Year 1' },
    { value: 'year2', label: 'Year 2' },
    { value: 'year3', label: 'Year 3' },
    { value: 'year4', label: 'Year 4' }];

    stageOptions = [{ value: 'stage1', label: 'Stage 1' },
    { value: 'stage2', label: 'Stage 2' },
    { value: 'stage3', label: 'Stage 3' },
    { value: 'stage4', label: 'Stage 4' }];

    periodOptions = [{ value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' }];

    ednSupervisorOptions = [{ value: 'sup1', label: 'Supervisor 1' },
    { value: 'sup2', label: 'Supervisor 2' },
    { value: 'sup3', label: 'Supervisor 3' },
    { value: 'sup4', label: 'Supervisor 4' }];

    approvalOptions = [{ value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' }];


    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };
    render() {
        const { selectedOption } = this.state;

        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h2>Approve GLA</h2>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <UncontrolledDropdown>
                                    <DropdownToggle id="Filter">
                                    <i className="icon-filter"></i>
                                    </DropdownToggle>
                                    <DropdownMenu>
                                        <DropdownItem>All</DropdownItem>
                                        <DropdownItem>Pending</DropdownItem>
                                        <DropdownItem>Approved</DropdownItem>
                                        <DropdownItem>Rejected</DropdownItem>
                                    </DropdownMenu>
                                </UncontrolledDropdown>
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                        </div>
                    </Row>
                    <div className="flexScroll">
                            <div className="maincontent">

                                <div className="main-table no-border">
                                    <div className="tbl-parent table-responsive">
                                        <table className="myTable table approve-gla-table">
                                            <thead>
                                                <tr>
                                                    <th>Trainee Name</th>
                                                    <th>Agreement No.</th>
                                                    <th>Edu. Supervisor Name</th>
                                                    <th className="column-center">Approval Status</th>
                                                    <th>MOH Supervisor Name</th>
                                                    <th className="column-center">Approval Status</th>
                                                    <th className="column-center">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>JohnnyDepp</td>
                                                    <td>5128745762</td>
                                                    <td>Dr. Prakash</td>
                                                    <td className="column-center"><img src={PendingIcon} className="icon" alt="" /></td>
                                                    <td>Dr. David</td>
                                                    <td className="column-center"><img src={PendingIcon} className="icon" alt="" /></td>
                                                    <td className="column-center"><div className="ActionStatus pointer">Approve</div></td>
                                                </tr>
                                                <tr>
                                                    <td>Margret</td>
                                                    <td>4186752416</td>
                                                    <td>Dr. Prakash</td>
                                                    <td className="column-center"><img src={PendingIcon} className="icon" alt="" /></td>
                                                    <td>Dr. David</td>
                                                    <td className="column-center"><img src={PendingIcon} className="icon" alt="" /></td>
                                                    <td className="column-center"><div className="ActionStatus pointer">Approve</div></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="main-table">
                                    <h2>GLAs <span className="note-inline">* Please Add agreement for all years of programme</span></h2>
                                    <div className="tbl-parent table-responsive">
                                        <table className="myTable table glas-table">
                                            <thead>
                                                <tr>
                                                    <th>Year</th>
                                                    <th>Stage</th>
                                                    <th>Agreement No.</th>
                                                    <th>Start Date</th>
                                                    <th>End Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Year I</td>
                                                    <td>Stage 1</td>
                                                    <td>5128745762</td>
                                                    <td>05/06/21</td>
                                                    <td>05/06/21</td>
                                                </tr>
                                                <tr>
                                                    <td>Year II</td>
                                                    <td>Stage 1</td>
                                                    <td>4186752416</td>
                                                    <td>07/06/21</td>
                                                    <td>07/06/21</td>
                                                </tr>
                                                <tr>
                                                    <td>Year III</td>
                                                    <td>Stage 1</td>
                                                    <td>687459898</td>
                                                    <td>05/06/21</td>
                                                    <td>05/06/21</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div className="details-section mt-2">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Approval Status</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.approvalOptions}
                                                        placeholder="Select Approval" />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Comments</Label>
                                                    <textarea className="w100" value="1" onChange={() => { }} rows={1}></textarea>
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Signature</Label>
                                                    <div className="terms"><input type="checkbox"></input>Acceptance of Agreement</div>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>

                                    <Row className="sub-form-footer mt-3 mr-3">
                                        <button className="cancel-button">Cancel</button>
                                        <button className="submit-button">Submit</button>
                                    </Row>
                                </div>
                            </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(ApproveGLA1));