import React, { Component, useState } from 'react';
import { Row, Col, Input, FormGroup, Label, Pagination, PaginationItem, PaginationLink, TabContent, TabPane, Nav, NavItem, NavLink, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Scrollbars } from 'react-custom-scrollbars';
import EditIcon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';
import uploadhistory from '../../images/History.svg';
import Select from 'react-select';
import UploadFile from '../../images/upload-file.svg';

class Hospitals1 extends Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            selectedOption: null,
            activeTab: "1",
            fileName: "No file Choosen"
        };
        this.toggle = this.toggle.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this)
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }
    toggle = tab => {
        this.setState({ activeTab: tab })
    }
    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    handleFileChange = (event) => {
        this.setState({ fileName: event.target.files[0].name })
    }

    programCodes = [{ value: 'pg123', label: 'PG123' },
    { value: 'pg113', label: 'PG113' },
    { value: 'pg232', label: 'PG232' },
    { value: 'pg436', label: 'PG436' }];

    durationOptions = [{ value: '3months', label: '3 Months' },
    { value: '6months', label: '6 Months' },
    { value: '9months', label: '9 Months' }];


    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h3 className="page-header header-title">List of Existing Hospitals</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box">
                                <div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                            <button className="addnewButn"><i className="ti-plus"></i> Add Hospital</button>
                            <button className="iconBtn"><img src={UploadFile} alt="" style={{ width: "18px" }}></img></button>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            <div className="main-table">
                                <div className="hospitalTable tbl-parent table-responsive">
                                    <table className="w100 myTable usersTable table">
                                        <thead>
                                            <tr>
                                                <th>Hospital Name</th>
                                                <th>Hospital ID / Code</th>
                                                <th>Hospital Location</th>
                                                <th>Point of Contact Name</th>
                                                <th>POC Contact Number</th>
                                                <th>POC Email Address</th>
                                                <th className="column-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Hospital2</td>
                                                <td>AH123</td>
                                                <td>12, Lorem Ipsum, Malaysia</td>
                                                <td>Hafiz</td>
                                                <td>+60-155-6589</td>
                                                <td>Hafiz@email.com</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Apple Hospital</td>
                                                <td>HC789</td>
                                                <td>12, Lorem Ipsum, Malaysia</td>
                                                <td>Hafiz</td>
                                                <td>+60-155-6589</td>
                                                <td>Hafiz@email.com</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Hospital3</td>
                                                <td>HC123</td>
                                                <td>12, Lorem Ipsum, Malaysia</td>
                                                <td>Hafiz</td>
                                                <td>+60-155-6589</td>
                                                <td>Hafiz@email.com</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Hospital4</td>
                                                <td>HC888</td>
                                                <td>12, Lorem Ipsum, Malaysia</td>
                                                <td>Hafiz</td>
                                                <td>+60-155-6589</td>
                                                <td>Hafiz@email.com</td>
                                                <td className="column-center">
                                                    <img src={EditIcon} className="actionicon pointer" alt=""></img>
                                                    <img src={Delete} alt="" className="actionicon pointer"></img>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div className="pagination">
                                        <Pagination aria-label="Page navigation example">
                                            <PaginationItem>
                                                <PaginationLink first href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink previous href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    1
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    2
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    3
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    4
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink href="#">
                                                    5
                                                </PaginationLink>
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink next href="#" />
                                            </PaginationItem>
                                            <PaginationItem>
                                                <PaginationLink last href="#" />
                                            </PaginationItem>
                                        </Pagination>
                                    </div>
                                </div>
                            </div>

                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Hospitals</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">Add Hospital</BreadcrumbItem>
                            </Breadcrumb>

                            <div className="uploadTabs flexLayout pr-0">
                                <Nav tabs>
                                    <NavItem>
                                        <NavLink className="active">
                                            <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                                            <span className="d-none d-sm-block">Add Hospital</span>
                                        </NavLink>
                                    </NavItem>

                                    <NavItem>
                                        <NavLink className="active">
                                            <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                                            <span className="d-none d-sm-block">Bulk Upload</span>
                                        </NavLink>
                                    </NavItem>
                                </Nav>
                                <TabContent className="flexLayout pr-0">
                                    {/* Hospitals Single Add  */}
                                    <div className="top-section">
                                        <h2>Hospital Details</h2>
                                        <div className="details-section">
                                            <Row className="vhcenter mt-3">
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>Hospital Name</Label>
                                                        <Input type="text" placeholder="Apple Hospital" name="hospName" />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>Hospital ID / Code</Label>
                                                        <Input type="text" placeholder="AH123" name="hospCode" />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>Hospital Location</Label>
                                                        <Input type="text" placeholder="12, Lorem Ipsum, Malaysia" />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>Point of Contact Name</Label>
                                                        <Input type="text" placeholder="Hafiz" />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>POC Contact Number</Label>
                                                        <Input type="text" placeholder="+60-155-6589" name="pocContactNumber" />
                                                    </FormGroup>
                                                </Col>
                                                <Col sm="6" lg="4">
                                                    <FormGroup>
                                                        <Label>POC Email Address</Label>
                                                        <Input type="text" placeholder="Hospital@eamail.com" name="pocEmailAddress" />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Row className="sub-form-footer mt-3 mr-3">
                                                <button className="cancel-button">Cancel</button>
                                                <button className="btn blue-button">Create</button>
                                            </Row>
                                        </div>
                                    </div>

                                    {/* Hospitals Single Add End */}

                                    {/* Hospitals Bulk Add  */}

                                    <div className="top-section">
                                        <Row className="vhcenter">
                                            <Col lg="9" sm="7">
                                                <h2>File Upload</h2>
                                            </Col>
                                            <Col lg="3" sm="5" className="text-right filehistory">
                                                <div><img src={uploadhistory} alt="" />File Uploads History</div>
                                            </Col>
                                        </Row>

                                        <div className="details-section mt-3">
                                            <Row>
                                                <Col lg="7" sm="10" className="upload-btn">
                                                    <FormGroup style={{ float: "left" }}>
                                                        <Label>Browse File</Label>
                                                        <input type="file" id="actual-btn" hidden />
                                                        <div id="blockele">
                                                            <div className="d-flex flex-row" id="file-chosen"><div className="mr-2"><i className="ti-folder icon-folder"></i> </div><div className="fu-fileName-sm">Select File</div></div>
                                                            <label htmlFor="actual-btn" className="choose">Select File</label>
                                                        </div>
                                                        <div className="fileuplod-note">* CSV File only, Max File size is 5MB</div>
                                                    </FormGroup>
                                                    <div className="sampledownldText">Download Sample File</div>
                                                </Col>
                                            </Row>
                                            <Row className="sub-form-footer mt-3 mr-3">
                                                <button className="cancel-button">Cancel</button>
                                                <button type="submit" className="blue-button">Create</button>
                                            </Row>
                                        </div>
                                    </div>

                                    {/* Hospitals Bulk Add End */}

                                </TabContent>
                            </div>

                            <Breadcrumb>
                                <BreadcrumbItem><span>List of Hospitals</span></BreadcrumbItem>
                                <BreadcrumbItem><span>Bulk Upload</span></BreadcrumbItem>
                                <BreadcrumbItem className="subMenu-Active">File Uploads History</BreadcrumbItem>
                            </Breadcrumb>

                            <Row className="compHeading">
                                <Col sm="6" xs="12">
                                    <h3 className="page-header header-title">File Uploads History</h3>
                                </Col>
                                <Col sm="6" xs="12">
                                    <div className="text-right">
                                        <button className="addnewButn">Upload New File</button>
                                    </div>
                                </Col>
                            </Row>


                            <div className="historyTable">
                                <table className="myTable table">
                                    <thead>
                                        <tr>
                                            <th>Uploaded File</th>
                                            <th>Sheet Count</th>
                                            <th>Date and Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="fileName">Hospitals_1.csv</td>
                                            <td>02</td>
                                            <td>25-05-2021, 03.00pm</td>
                                        </tr>
                                        <tr>
                                            <td className="fileName">Hosp_12.csv</td>
                                            <td>02</td>
                                            <td>25-05-2021, 03.10pm</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(Hospitals1));