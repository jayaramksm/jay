import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import approved from '../../images/Approved.svg';
import pending from '../../images/Pending.svg';
import DatePicker from "react-datepicker";
import Select from 'react-select';


class ApproveClinicalMeetings1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            datevalue: new Date()
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    yearOptions = [{ value: 'year1', label: 'Year 1' },
    { value: 'year2', label: 'Year 2' },
    { value: 'year3', label: 'Year 3' },
    { value: 'year4', label: 'Year 4' }];

    stageOptions = [{ value: 'stage1', label: 'Stage 1' },
    { value: 'stage2', label: 'Stage 2' },
    { value: 'stage3', label: 'Stage 3' },
    { value: 'stage4', label: 'Stage 4' }];

    rotationOptions = [{ value: 'rotation1', label: 'Rotation 1' },
    { value: 'rotation2', label: 'Rotation 2' },
    { value: 'rotation3', label: 'Rotation 3' },
    { value: 'rotation4', label: 'Rotation 4' }];

    sequenceOptions = [{ value: 'sequence1', label: 'Secquence 1' },
    { value: 'sequence2', label: 'Secquence 2' },
    { value: 'sequence3', label: 'Secquence 3' },
    { value: 'sequence4', label: 'Secquence 4' }];

    periodOptions = [{ value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' }];

    universityOptions = [{ value: 'university1', label: 'University 1' },
    { value: 'university2', label: 'University 2' },
    { value: 'university3', label: 'University 3' },
    { value: 'university4', label: 'University 4' }];

    hospitalOptions = [{ value: 'hospital1', label: 'Hospital 1' },
    { value: 'hospital2', label: 'Hospital 2' },
    { value: 'hospital3', label: 'Hospital 3' },
    { value: 'hospital4', label: 'Hospital 4' }];

    supervisorOptions = [{ value: 'sup1', label: 'Supervisor 1' },
    { value: 'sup2', label: 'Supervisor 2' },
    { value: 'sup3', label: 'Supervisor 3' },
    { value: 'sup4', label: 'Supervisor 4' }];

    approvalOptions = [{ value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' }];

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout">
                    <Row className="compHeading">
                        <Col>
                            <h2>Clinical Meetings</h2>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon"> <i className="icon-filter"></i><div className="search-text"><input type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                            </div>
                        </div>
                    </Row>
                    <div className="flexScroll">
                        <div className="maincontent pr-3">
                            <div className="tbl-parent table-responsive">
                                <table className="myTable clinicalMTable table">
                                    <thead>
                                        <tr>
                                            <th>Trainee Name</th>
                                            <th>Year</th>
                                            <th>Stage</th>
                                            <th>Rotations</th>
                                            <th>Clinical Supervisor</th>
                                            <th>Meeting Date</th>
                                            <th>Meeting Time</th>
                                            <th className="text-center">Approval Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>JohnyDepp</td>
                                            <td>Year I</td>
                                            <td>Stage I</td>
                                            <td>Rotation 03</td>
                                            <td>Dr. Ramesh</td>
                                            <td>05/06/21</td>
                                            <td>15:00</td>
                                            <td className="text-center"><img src={pending} alt="" /></td>
                                            {/* Clinical Supervisor */}
                                            {/* <td><div className="ActionStatus pointer" onClick={this.addApprove}>Approve</div></td> */}
                                            {/* Clinical Supervisor */}
                                            <td><span className="ActionStatus pointer">Approve</span></td>
                                        </tr>
                                        <tr>
                                            <td>Margret</td>
                                            <td>Year II</td>
                                            <td>Stage II</td>
                                            <td>Rotation 02</td>
                                            <td>Dr. Satish</td>
                                            <td>06/06/21</td>
                                            <td>12:00</td>
                                            <td className="text-center"><img src={approved} alt="" /></td>
                                            {/* Clinical Supervisor */}
                                            {/* <td className="ActionStatus">-</td> */}
                                            {/* Clinical Supervisor */}
                                            <td><span className="ActionStatus pointer">View</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div className="maincontent pr-3">

                                <div className="top-section">
                                    <h2>Programme Details</h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Trainee Name</Label>
                                                    <Input type="text" disabled value="Johnny Depp"></Input>
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Programme Name</Label>
                                                    <Input type="text" disabled value="Family Medicine"></Input>
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Head of the Department</Label>
                                                    <Input type="text" disabled value="Dr. Ramesh"></Input>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Educational Supervisor</Label>
                                                    <Input type="text" disabled value="Dr. Satish"></Input>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                                <hr />

                                <div className="top-section">
                                    <h2>Rotation Details</h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Year</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.yearOptions}
                                                        placeholder="Select Year" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Stage</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.stageOptions}
                                                        placeholder="Select Stage" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Rotation</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.rotationOptions}
                                                        placeholder="Select Rotation" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Rotation Sequence</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.sequenceOptions}
                                                        placeholder="Select Sequence" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Rotation University</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.universityOptions}
                                                        placeholder="Select University" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Rotation Duration</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.periodOptions}
                                                        placeholder="Select Duration" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Rotation start Date</Label>
                                                    <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Rotation End Date</Label>
                                                    <DatePicker disabled className="w100 datepickerIcon form-control" selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Hosptial Name</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.hospitalOptions}
                                                        placeholder="Select Hospital" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>
                                        </Row>

                                        <Row>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Hospital Name (If other selected)</Label>
                                                    <Input type="text" disabled value="Putra Medical Center"></Input>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>

                                <hr />

                                <div className="top-section">
                                    <h2>Supervisor Details</h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>1st Clinical Supervisor</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.supervisorOptions}
                                                        placeholder="Select 1st Clinical Supervisor" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>2nd Clinical Supervisor</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.supervisorOptions}
                                                        placeholder="Select 2nd Clinical Supervisor" isDisabled={true}
                                                    />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                                <hr />

                                <div className="top-section">
                                    <h2>Meeting Details</h2>
                                    <div className="details-section">
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Final Meeting</Label>
                                                    <input type="checkbox" checked={true} onChange={() => { }} disabled ></input>Is this Final Meeting?
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Meeting Start Date</Label>
                                                    <DatePicker className="w100 datepickerIcon form-control" disabled={true} selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Meeting Start Time</Label>
                                                    <Input type="text" placeholder="Enter Time" disabled></Input>
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Agreed Next Meeting Date</Label>
                                                    <DatePicker className="w100 datepickerIcon form-control" disabled={true} selected={this.state.datevalue} onChange={(date) => { this.setState({ datevalue: date }) }} />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="8">
                                                <FormGroup>
                                                    <Label>Trainee Remarks</Label>
                                                    <textarea disabled placeholder="Write down here" className="comments" rows={1}></textarea>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                                <hr />

                                {/* only visible if role is clinical supervisor */}
                                <div className="top-section">
                                    <div className="details-section">
                                        <Row className="vhcenter">
                                            <Col>
                                                <h2>Supervisor Details</h2>
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Approval Status</Label>
                                                    <Select
                                                        onChange={(e) => this.handleChange(e)}
                                                        options={this.approvalOptions}
                                                        placeholder="Select Approval"
                                                    />
                                                </FormGroup>
                                            </Col>

                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>Remarks </Label>
                                                    <textarea placeholder="Write down here" className="comments" rows={1}></textarea>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>
                                {/* only visible if role is clinical supervisor */}

                                <Row className="sub-form-footer my-3 mr-5">
                                    <button className="btn btn-cancel mr-3">Cancel</button>
                                    <button className="btn btn-submit">Submit</button>
                                </Row>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(ApproveClinicalMeetings1));