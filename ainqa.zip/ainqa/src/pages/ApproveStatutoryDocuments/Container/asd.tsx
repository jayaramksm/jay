import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, getAsdsDataRequest, cancelAllPendingAsdsRequest, resetAllAsdsStateRequest } from '../../../store/actions';
import { SuperParentContext } from './asdContext';
import { AsdsParent, AsdViewManager, AsdFilter, AsdActionManager, AsdView, AsdFilewView } from './asdIndex';

interface IProps {
    activateAuthLayout;
    getAsdsDataRequest;
    resetAllAsdsStateRequest;
    cancelAllPendingAsdsRequest;
}

class Asds extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            asdViewManager: AsdViewManager,
            asdFilter: AsdFilter,
            asdActionManager: AsdActionManager,
            asdView: AsdView,
            asdFilewView: AsdFilewView
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllAsdsStateRequest();
        this.props.getAsdsDataRequest();
    }
    componentWillUnmount() {
        this.props.cancelAllPendingAsdsRequest();
        this.props.resetAllAsdsStateRequest();

    }
    render() {
        return (
            <>
                <SuperParentContext.Provider value={this.state}>
                    <AsdsParent />
                </SuperParentContext.Provider>
            </>
        )
    }
}


export default connect(null, { activateAuthLayout, getAsdsDataRequest, cancelAllPendingAsdsRequest, resetAllAsdsStateRequest })(Asds);