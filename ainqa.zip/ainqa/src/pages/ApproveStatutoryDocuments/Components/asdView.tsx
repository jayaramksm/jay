import React, { useContext } from 'react';
import { ChildContext } from '../Container/asdContext';
import { EOprationalActions, EApprovelActions } from 'models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'react-i18next';
import Approved from '../../../images/Approved.svg';
import { setAsdsActionTypeData } from '../../../store/actions';
import { IApproveStatutoryDocumentsMOdel, ITrainee } from '../../../models/approveStatutoryDocumentsModel';
import pending from '../../../images/Pending.svg';
import reject from '../../../images/Reject.svg';

const AsdView: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const context: any = useContext(ChildContext);

    const asdData: ITrainee | any = useSelector((state: any) => {
        if (state?.asdsReducer?.asdsData?.length) {
            let asdData = (state.asdsReducer as IApproveStatutoryDocumentsMOdel).asdsData;
            return asdData.find(gla => gla.traineeId === context);
        } else
            return undefined;
    });
    const approveAsd = () => {
        dispatch(setAsdsActionTypeData(EOprationalActions.ADD, asdData));
    };

    const asdView = () => {
        dispatch(setAsdsActionTypeData(EOprationalActions.SELECT, asdData));
    };

    return (
        <>
            <tr>
                <td>{asdData?.traineeName}</td>
                <td>{asdData?.programName}</td>
                <td className="column-center">{(asdData?.approvalStatus === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (asdData?.approvalStatus === EApprovelActions.PENDING ? <img src={pending} className="icon" alt="" /> : asdData?.approvalStatus === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "")}</td>
                <td>{(asdData?.approvalStatus === EApprovelActions.PENDING) ? <div className="ActionStatus pointer" onClick={approveAsd}> {t('asds.approve')}</div> : <div className="ActionStatus pointer" onClick={asdView}> {t('asds.view')}</div>}</td>
            </tr>
        </>

    )
}
export default React.memo(AsdView);