import React from 'react';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { setSearchAsdsData } from '../../../store/actions';


const AsdFilter: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const showAsdSearch: boolean = useSelector((state: any) => !!(state?.asdsReducer?.asdsData?.length > 2));
    const onSearchChange = e => {
        const searchInput = e.target.value;
        dispatch(setSearchAsdsData(searchInput));
    };
    return (
        <Row className="compHeading">
            <Col>
                <h2> {t('asds.approveStatutoryDocuments')}</h2>
            </Col>
            {showAsdSearch && <div className="rgtFilter">
                <div className="search-box filtericon">
                    <div className="search-text"><input onChange={onSearchChange} type="text" placeholder="Search"></input><i className="ti-search icon"></i></div>
                </div>
            </div>}
        </Row>
    )
}
export default React.memo(AsdFilter);