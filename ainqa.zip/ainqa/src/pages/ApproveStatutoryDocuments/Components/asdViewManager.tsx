
import React, { useContext } from 'react';
import { ParentContext, ChildContext } from '../Container/asdContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { IApproveStatutoryDocumentsMOdel, ITrainee } from '../../../models/approveStatutoryDocumentsModel';
// import { getEnvironment } from '../../../helpers/helpersIndex';
// import { setAsdsPaginationCurrentPageValue } from 'store/actions';
// import { PaginationComponent } from '../../utilities/PaginationComponent';

const AsdViewManager: React.FC = () => {
    const context: any = useContext(ParentContext);
    // const dispatch = useDispatch();
    // const pageSize = getEnvironment.pageSize;
    const { t } = useTranslation('translations');

    const asdsData: ITrainee[] = useSelector((state: any) => state?.asdsReducer?.asdsData);

    const searchKey: string = useSelector((state: any) => {
        if (state?.asdsReducer?.searchKey)
            return (state.asdsReducer as IApproveStatutoryDocumentsMOdel).searchKey;
        else return "";
    });

    const asdsFilterData: any[] = (asdsData && searchKey !== '') ? asdsData?.filter((x: any) => (
        searchKey !== '' ? x.traineeName.toLowerCase().startsWith(searchKey.toLowerCase()) : true
    )) : asdsData;

    // const currentPage: number = useSelector((state: any) => {
    //     if (state?.asdsReducer?.paginationCurrentPage)
    //         return (state.asdsReducer as IApproveStatutoryDocumentsMOdel).paginationCurrentPage;
    //     else return 0;
    // });

    // let pagesCount: number = Math.ceil((asdsFilterData ? asdsFilterData.length : 0) / pageSize);

    // if (currentPage >= pagesCount && pagesCount !== 0)
    //     dispatch(setAsdsPaginationCurrentPageValue(0));

    // const handleClick = (e, index) => {
    //     e.preventDefault();
    //     console.log('_pagination_index', index);
    //     dispatch(setAsdsPaginationCurrentPageValue(index));
    // };

    console.log("AsdViewManager==>", { asdsData, context });

    return (
        <>
            <context.asdFilter />
            <div className="flexLayout">
                <div className="flexScroll">
                    <div className="main-table no-border">
                        <div className="tbl-parent table-responsive">
                            <table className="myTable approve-statutory table">
                                <thead>
                                    <tr>
                                        <th>{t('asds.traineeName')}</th>
                                        <th>{t('asds.programeeName')}</th>
                                        <th className="column-center">{t('asds.approvalStatus')}</th>
                                        <th>{t('asds.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {/* slice((currentPage * pageSize), ((currentPage + 1) * pageSize)) */}
                                    {asdsFilterData && asdsFilterData?.map((x) => (
                                        <ChildContext.Provider value={x.traineeId} key={x.traineeId}>
                                            <context.asdView />
                                        </ChildContext.Provider>
                                    ))}
                                </tbody>
                            </table>
                            {(asdsFilterData && asdsFilterData?.length === 0) && <div className="norecordsfound"><h6>{t('asds.noDataFound')}</h6></div>}
                        </div>
                    </div>
                </div>
                {/* {asdsFilterData && asdsFilterData.length > pageSize &&
                    <div className="pagination">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>} */}
            </div>
        </>
    )
}
export default React.memo(AsdViewManager);