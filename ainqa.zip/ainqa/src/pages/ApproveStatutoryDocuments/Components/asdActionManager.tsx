import React from 'react';
import { EOprationalActions, EApprovelActions } from 'models/utilitiesModel';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { IApproveStatutoryDocumentsMOdel, ITrainee } from '../../../models/approveStatutoryDocumentsModel';
import { FormGroup } from 'reactstrap';
import { Formik, Form, ErrorMessage, FieldArray, Field } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, customContentValidation, getEnvironment, defultContentObjectValidate } from '../../../helpers/helpersIndex';
import * as _ from 'lodash';
import { setAsdFileViewRequest, setAsdsActionTypeData, setAsdsApproveRequest } from '../../../store/actions';


const approvalOptions = [{ value: 'approved', label: 'Approved' },
{ value: 'rejected', label: 'Rejected' }, { value: 'pending', label: 'Pending' }];

const AsdActionManager: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize;

    const actionType = useSelector((state: any) => {
        if (state?.asdsReducer?.actionType) {
            return (state.asdsReducer as IApproveStatutoryDocumentsMOdel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const actionData: ITrainee = useSelector((state: any) => {
        if (state?.asdsReducer?.actionData) {
            return (state.asdsReducer as IApproveStatutoryDocumentsMOdel).actionData
        } else {
            return undefined
        }
    });

    const approvalDocs = actionData?.docs?.map(x => ({
        ...x,
        approvalStatus: approvalOptions.find(y => y.value === x.approvalStatus)
    }))

    const initialValues = () => ({
        traineesId: actionData?.traineeId,
        userId: actionData?.userId,
        approvelStatus: approvalDocs ? approvalDocs : [],
        currentPage: 0
    });

    const backToAsd = () => {
        dispatch(setAsdsActionTypeData(EOprationalActions.UNSELECT, null));
    }

    const validationSchema = Yup.object().shape({
        approvelStatus: Yup.array().of(
            Yup.object().shape({
                approvalStatus: defultContentObjectValidate(t('controleErrors.required')),
                approvalComments: Yup.string().when('approvalStatus', {
                    is: selectedStatus => selectedStatus?.value === EApprovelActions.REJECTED,
                    then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4),
                    otherwise: Yup.lazy((val) => {
                        if (val)
                            return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: '' }, 200, 4)
                        else return defultContentValidate(t(''));
                    })
                })
            }))
    });

    const viewFlileData = (files) => {
        dispatch(setAsdFileViewRequest(files));
        // dispatch(setAsdFileViewModelOpendOrClose(files));
    }
    console.log("AsdActionManager==>", { actionData, actionType });

    return (
        <>
            <div className="breadcrumbs">
                <div>   <span className="pointer" onClick={backToAsd}>{t('asds.approveStatutoryDocuments')}</span>
                    <span>
                        <i className="ti-angle-right"></i></span>
                    <span className="active"> {actionData?.traineeName}</span>
                </div>
            </div>

            <Formik
                initialValues={initialValues()}
                validationSchema={validationSchema}
                onSubmit={(values) => {
                    const diffvalues = _.differenceWith(values.approvelStatus, actionData?.docs, _.isEqual);
                    console.log("AsdActionManager_SubmitedValues==>", values, diffvalues);
                    dispatch(setAsdsApproveRequest({ values, diffvalues }, actionType));

                }}>
                {({ errors, setFieldValue, dirty, setFieldTouched, values, touched }) => {

                    // let pagesCount: number = Math.ceil((values?.approvelStatus ? values?.approvelStatus?.length : 0) / pageSize);

                    // if (values.currentPage >= pagesCount && pagesCount !== 0)
                    //     setFieldValue('currentPage', 0);

                    // const handleClick = (e, index) => {
                    //     e.preventDefault();
                    //     console.log('_pagination_index', index);
                    //     setFieldValue('currentPage', index);
                    // };
                    return <Form className="flexLayout">
                        <div className="flexScroll">
                            <div className="main-table no-border">
                                <div className="tbl-parent">
                                    <table className="myTable documenttypes table">
                                        <thead>
                                            <tr>
                                                <th>{t('asds.documentType')}</th>
                                                <th>{t('asds.documentName')}</th>
                                                <th>{t('asds.fileName')}</th>
                                                <th className="column-center">{t('asds.approvalStatus')}</th>
                                                <th>{t('asds.approvalComments')}</th>
                                                <th>{t('asds.actions')}</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <FieldArray name="approvelStatus">
                                                {({ push, remove }) => (
                                                    <>
                                                        {values.approvelStatus?.map((asdData, index) => {
                                                            // slice((values.currentPage * pageSize), ((values.currentPage + 1) * pageSize))?
                                                            // let index = values.approvelStatus?.findIndex(y => y.docId === asdData.docId);

                                                            // console.log("approvelStatusapprovelStatus", asdData);
                                                            const approvel = `approvelStatus[${index}].approvalStatus`;
                                                            const comments = `approvelStatus[${index}].approvalComments`;

                                                            const touchedcomments = (errors?.approvelStatus?.[index] as any)?.approvalComments //getIn(touched, comments);
                                                            const errorcomments = (touched?.approvelStatus?.[index] as any)?.approvalComments;

                                                            const error = (errors?.approvelStatus?.[index] as any)?.approvalStatus;
                                                            const touch = (touched?.approvelStatus?.[index] as any)?.approvalStatus;


                                                            return (
                                                                <tr key={asdData.docId}>
                                                                    <td className="text-muted">{asdData?.documentTypeName}</td>
                                                                    <td>{asdData?.docName} </td>
                                                                    <td>
                                                                        {asdData?.fileData?.map((file, idx) => <p key={idx}>{file?.fileName}</p>)}
                                                                    </td>
                                                                    <td>
                                                                        <FormGroup className="w80 mx-auto">
                                                                            <MySelect
                                                                                name={approvel}
                                                                                menuPlacement='auto'
                                                                                value={asdData.approvalStatus}
                                                                                placeholder={t('asds.approvalStatus')}
                                                                                onChange={(e) => setFieldValue(approvel, e)}
                                                                                options={approvalOptions ? approvalOptions : []}
                                                                                getOptionLabel={option => option.label}
                                                                                getOptionValue={option => option.value}
                                                                                onBlur={() => setFieldTouched(approvel, true)}
                                                                                noOptionsMessage={() => { t('asds.NoDataFound') }}
                                                                                isDisabled={(actionData?.docs?.[index]?.approvalStatus !== EApprovelActions.PENDING)}
                                                                            />
                                                                            {
                                                                                errors && touch && <div className="text-danger"> {error}</div>
                                                                            }
                                                                        </FormGroup>
                                                                    </td>

                                                                    <td> <Field as="textarea"
                                                                        disabled={((actionData?.docs?.[index]?.approvalStatus !== EApprovelActions.PENDING) || (asdData.approvalStatus?.value === EApprovelActions.PENDING)) ? true : false}
                                                                        placeholder={t('asds.comments')}

                                                                        className={'form-control ' + (touchedcomments && errorcomments ? ' is-invalid' : '')}
                                                                        name={comments}
                                                                        rows={1}
                                                                    />
                                                                        <ErrorMessage name={comments} component="div" className="text-danger" />
                                                                    </td>
                                                                    <td><div onClick={() => viewFlileData(asdData?.fileData?.map(file => file.filePath))} className="fileName pointer">{t('asds.view')}</div>
                                                                    </td>
                                                                </tr>
                                                            );
                                                        })}
                                                    </>
                                                )
                                                }
                                            </FieldArray>
                                        </tbody>
                                    </table>
                                </div>
                                {/* {(values?.approvelStatus?.length > pageSize) &&
                                    <div className="pagination">
                                        <PaginationComponent currentPage={values.currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                                    </div>
                                } */}
                            </div>
                        </div>

                        <div className="text-right mt-2">
                            <button onClick={backToAsd} className="btn cancel-button mr-3">{t('asds.cancel')} </button>
                            {actionType !== EOprationalActions.SELECT && <button type='submit' disabled={!(dirty)} className="btn blue-button"> {t('asds.save')} </button>}
                        </div>
                    </Form>
                }
                }
            </Formik>
        </>
    )
}

export default React.memo(AsdActionManager)