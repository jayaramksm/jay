import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/asdContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { IApproveStatutoryDocumentsMOdel } from '../../../models/approveStatutoryDocumentsModel';

const AsdsParent: React.FC = () => {

    const context: any = useContext(SuperParentContext);

    const isAsdListActionType = useSelector((state: any) => {
        if (state?.asdsReducer)
            return (state.asdsReducer as IApproveStatutoryDocumentsMOdel)?.actionType === EOprationalActions.UNSELECT;
        else return false;
    });

    console.log("ApproveGlaParent==>", isAsdListActionType);

    return (
        <div className="maincontent flexLayout pr-0">
            <context.asdFilewView />
            {isAsdListActionType ?
                <ParentContext.Provider value={{ asdView: context.asdView, asdFilter: context.asdFilter }}>
                    <context.asdViewManager />
                </ParentContext.Provider>
                :
                <context.asdActionManager />
            }
        </div>
    )
}
export default React.memo(AsdsParent);