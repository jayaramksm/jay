import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
    Carousel,
    CarouselItem,
    CarouselControl,
    CarouselIndicators, Modal
} from 'reactstrap';
import { setAsdFileViewModelOpendOrClose } from '../../../store/actions';

const AsdFilewView: React.FC = () => {
    const dispatch = useDispatch();
    const [activeIndex, setActiveIndex] = useState(0);

    // this function is to support IE (in IE, custom events support doesnt exist)
    useEffect(() => {
        if (/msie\s|trident\//i.test(window.navigator.userAgent)) {
            (function () {
                if (typeof window.CustomEvent === "function") return false;
                function CustomEvent(event, params) {
                    params = params || { bubbles: false, cancelable: false, detail: null };
                    var evt = document.createEvent('CustomEvent');
                    evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
                    return evt;
                }
                (window as any).CustomEvent = CustomEvent;
                return;
            })();
        }
    }, []);

    const fileData = useSelector((state: any) => state?.asdsReducer?.fileData || []);

    const next = () => {
        const nextIndex = activeIndex === fileData?.length - 1 ? 0 : activeIndex + 1;
        setActiveIndex(nextIndex);
    }

    const previous = () => {
        const nextIndex = activeIndex === 0 ? fileData?.length - 1 : activeIndex - 1;
        setActiveIndex(nextIndex);
    }

    const goToIndex = (newIndex) => setActiveIndex(newIndex);
    console.log("AsdFilewView == > ", fileData?.[activeIndex]);

    const cancel = () => {
        dispatch(setAsdFileViewModelOpendOrClose());
        setActiveIndex(0);
    };

    return (
        <>
            {fileData?.length > 0 &&
                <Modal className="modal-lg h-100" modalClassName="overflow-hidden" isOpen={fileData?.length > 0}>
                    <div className="text-right p-2"><button onClick={cancel} className="btn btn-danger"><i className="ti-close"></i></button></div>
                    <div style={{ height: "80vh" }}>
                        <Carousel interval={false} next={next} previous={previous} activeIndex={activeIndex} className="text-center">
                            <CarouselIndicators items={fileData} activeIndex={activeIndex} onClickHandler={goToIndex} />

                            {fileData?.map((item, i) => <CarouselItem className="overflow-auto" style={{ height: "75vh" }} key={i}
                            >
                                <div className="mcarousel">
                                <img src={item} alt="Image" className="w-100" />
                                </div>
                            </CarouselItem>
                            )}
                            {fileData?.length !== 1 && <>
                                <CarouselControl direction="prev" directionText="Previous" onClickHandler={previous} />
                                <CarouselControl direction="next" directionText="Next" onClickHandler={next} />
                            </>}
                        </Carousel>
                    </div>
                </Modal>
            }
        </>
    );
}
export default React.memo(AsdFilewView);