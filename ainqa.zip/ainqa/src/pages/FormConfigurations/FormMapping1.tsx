import React, { Component } from 'react';
import { Row, Col, Input, FormGroup, Label, Breadcrumb, BreadcrumbItem, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Scrollbars from 'react-custom-scrollbars';
import EditIcon from '../../images/Edit.svg';
import Delete from '../../images/Delete.svg';
import Select from 'react-select';
import UploadFile from '../../images/upload-file.svg';
import uploadhistory from '../../images/History.svg';



class FormMapping1 extends Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    handleChange = (e: any) => {
        this.setState({ selectedOption: e });
    };

    formOptions = [
        { value: 'cbdtrainee', label: 'CBD Form Trainee' },
        { value: 'cbdevaluator', label: 'CBD Form Evaluator' },
        { value: 'cextrainee', label: 'CEX Form Trainee' },
        { value: 'cexevaluator', label: 'CEX Form Evaluator' },
    ];

    render() {
        return (
            <React.Fragment>
                <div className="flexLayout maincontent">
                    <Row className="compHeading mb-2 pr-2">
                        <Col>
                            <h3 className="page-header header-title">List of Forms Mappings</h3>
                        </Col>
                        <div className="rgtFilter">
                            <div className="search-box filtericon">
                                <div className="search-text">
                                    <input type="text" placeholder="Search" /><i className="ti-search icon"></i>
                                </div>
                            </div>
                            <button className="addnewButn">Open Form Builder</button>
                        </div>
                    </Row>

                    <div className="flexScroll">
                    <div className="main-table h-100">
                                    <div className="tbl-parent table-responsive h-100 pr-2">
                            <table className="myTable formMappingTable table">
                                <thead>
                                    <tr>
                                        <th>Forms List</th>
                                        <th>Sub Category</th>
                                        <th>Map Trainee Form</th>
                                        <th>Map Evaluator Form</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>CBD Form</td>
                                        <td>-</td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                            <img src={EditIcon} alt="edit" className="actionicon pointer" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>CEX Form</td>
                                        <td>-</td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                            <img src={EditIcon} alt="edit" className="actionicon pointer" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>SURLOG Form</td>
                                        <td>-</td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                        <Select className="disabledSelect"
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder=""
                                                isDisabled={true}
                                            /> 
                                        </td>
                                        <td>
                                            <img src={EditIcon} alt="edit" className="actionicon pointer" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>PBA</td>
                                        <td>Colonography</td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                        <button type='button' className='btn blue-button mr-2'>Save</button>
                                        <button type='button' className='btn icon-btn'><i className="icon-Close"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>PBA</td>
                                        <td>OGD</td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                            <img src={EditIcon} alt="edit" className="actionicon pointer" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>PBA</td>
                                        <td>Laproscopy</td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                        <Select
                                                onChange={(e) => this.handleChange(e)}
                                                placeholder="Select Form"
                                                options={this.formOptions}
                                            /> 
                                        </td>
                                        <td>
                                            <img src={EditIcon} alt="edit" className="actionicon pointer" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                        </div>
                        </div>
                    </div>
            </React.Fragment>
        )
    }
}
export default withRouter(connect(null, { activateAuthLayout })(FormMapping1));
