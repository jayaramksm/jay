import React, { useContext } from 'react';
import { IApproveStudyPlanModel } from '../../../models/approveStudyPlanModel';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext, SuperParentContext } from '../Container/ApproveStudyPlanContext';
import { useTranslation } from 'react-i18next';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { setApproveStudyPlanRotationActionTypeData, setApproveStudyplanActionTypeData } from '../../../store/actions';

const ApproveStudyPlanRotationsActionManager: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const rotationActionData: any = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.rotationActionData)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).rotationActionData
        else return undefined;
    });
    console.log('ApproveStudyPlanRotationsActionManager==>', rotationActionData);

    const goBackToStages = () => {
        dispatch(setApproveStudyPlanRotationActionTypeData(EOprationalActions.STUDY_PLAN_STAGES_VIEW, null))
    }

    const goBackToTraineeStudyPlan = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.UNSELECT, null))
    }

    console.log('ApproveStudyPlanRotationsActionManager==>', rotationActionData);


    return (
        <>
            <div className="breadcrumbs mb-2">
                <div> <span className="pointer" onClick={goBackToTraineeStudyPlan}>{t('approveStudyPlan.traineeStudyPlan')}</span>
                    <span>
                        <i className="ti-angle-right"></i></span>
                    <span className="pointer" onClick={goBackToStages}>{rotationActionData?.traineeName}</span>
                    <span>
                        <i className="ti-angle-right"></i></span>
                    <span className="active">{rotationActionData?.stageName}</span>
                </div>
            </div>
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent">
                        <table className="table asp-tbl myTable w-100">
                            <thead>
                                <tr>
                                    <th>{t('approveStudyPlan.sequence')}</th>
                                    <th> {t('approveStudyPlan.rotation')}</th>
                                    <th> {t('approveStudyPlan.stage')}</th>
                                    <th> {t('approveStudyPlan.university')}</th>
                                    <th> {t('approveStudyPlan.hospitalName')}</th>
                                    <th> {t('approveStudyPlan.duration')}<p className="mb-0" style={{ fontSize: "10px" }}> {t('approveStudyPlan.inMonths')}</p></th>
                                    <th> {t('approveStudyPlan.completionMarkStatus')}</th>
                                    <th> {t('approveStudyPlan.remarks')}</th>
                                    <th> {t('approveStudyPlan.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/* .slice((currentPage * pageSize), ((currentPage + 1) * pageSize)) */}

                                {rotationActionData && rotationActionData?.rotations?.map((x, i) => (
                                    <ParentContext.Provider value={x.spRotationId} key={i}>
                                        <context.approveStudyPlanRotationsAction />
                                    </ParentContext.Provider>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(ApproveStudyPlanRotationsActionManager);