import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/ApproveStudyPlanContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { IApproveStudyPlanModel, IStudyPlan } from '../../../models/approveStudyPlanModel';
// import { getEnvironment } from '../../../helpers/helpersIndex';
// import { setApproveStudyplansPaginationCurrentPageValue } from '../../../store/actions';
// import { PaginationComponent } from '../../utilities/PaginationComponent';

const ApproveStudyPlanViewManager: React.FC = () => {
    const { t } = useTranslation('translations');
    const context: any = useContext(SuperParentContext);
    // const dispatch = useDispatch();
    // const pageSize = getEnvironment.pageSize;

    const studyPlanData: IStudyPlan[] | undefined = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.studyPlanData)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel)?.studyPlanData;
        else return undefined;
    });

    const searchKey: string = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.searchKey)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).searchKey;
        else return "";
    });

    const studyPlanFilterData: any[] | undefined = (studyPlanData && searchKey !== '') ? studyPlanData?.filter((x: any) => (
        searchKey !== '' ? x.traineeName.toLowerCase().startsWith(searchKey) : true
    )) : studyPlanData;

    // const currentPage: number = useSelector(state => {
    //     if (state?.approveStudyPlanReducer?.paginationCurrentPage)
    //         return (state.approveStudyPlanReducer as IApproveStudyPlanModel).paginationCurrentPage;
    //     else return 0;
    // });


    // let pagesCount: number = Math.ceil((studyPlanFilterData ? studyPlanFilterData.length : 0) / pageSize);

    // if (currentPage >= pagesCount && pagesCount !== 0)
    //     dispatch(setApproveStudyplansPaginationCurrentPageValue(0));

    // const handleClick = (e, index) => {
    //     e.preventDefault();
    //     console.log('_pagination_index', index);
    //     dispatch(setApproveStudyplansPaginationCurrentPageValue(index));
    // };
    console.log("ApproveStudyPlanViewManager==>", studyPlanData, context);

    return (
        <>
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent table-responsive">
                        <table className="myTable approveStudyViewTable table">
                            <thead>
                                <tr>
                                    <th>{t('approveStudyPlan.traineeName')}</th>
                                    <th>{t('approveStudyPlan.programeeName')}</th>
                                    <th className="text-center"> {t('approveStudyPlan.approvalStatus')}</th>
                                    <th>  {t('approveStudyPlan.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {studyPlanFilterData && studyPlanFilterData.map((x) => (
                                    // ?.slice((currentPage * pageSize), ((currentPage + 1) * pageSize))
                                    <ParentContext.Provider value={x.traineeId} key={x.traineeId}>
                                        <context.approveStudyPlanView />
                                    </ParentContext.Provider>
                                ))}
                            </tbody>
                        </table>
                        {(studyPlanFilterData && studyPlanFilterData?.length === 0 && searchKey === '') && <div className="norecordsfound"><h6>{t('approveStudyPlan.noDataFound')}</h6></div>}

                        {(studyPlanFilterData && (studyPlanFilterData?.length === 0 && searchKey !== '')) && <div className="norecordsfound"><h6>{t('approveStudyPlan.noDataFound')}</h6></div>}
                    </div>
                </div>
            </div>

            {/* {studyPlanFilterData && studyPlanFilterData.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>} */}
        </>
    )
}
export default React.memo(ApproveStudyPlanViewManager);