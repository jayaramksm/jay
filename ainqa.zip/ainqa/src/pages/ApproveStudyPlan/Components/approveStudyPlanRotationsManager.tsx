import React, { useContext } from 'react';
import { ParentContext, SuperParentContext } from '../Container/ApproveStudyPlanContext';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { IApproveStudyPlanModel } from '../../../models/approveStudyPlanModel';
import * as _ from 'lodash';
import { setApproveStudyplanActionTypeData } from '../../../store/actions';
import { EApprovelActions, EOprationalActions } from '../../../models/utilitiesModel';
// import { getEnvironment } from '../../../helpers/helpersIndex';
// import { PaginationComponent } from '../../utilities/PaginationComponent';


const ApproveStudyPlanRotationsManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();
    // const pageSize = getEnvironment.pageSize;


    const actionData: any = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.actionData) {
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).actionData
        } else {
            return undefined
        }
    });

    // const currentPage: number = useSelector(state => {
    //     if (state?.approveStudyPlanReducer?.paginationCurrentPage)
    //         return (state.approveStudyPlanReducer as IApproveStudyPlanModel).paginationCurrentPage;
    //     else return 0;
    // });

    // let pagesCount: number = Math.ceil((actionData?.rotations ? actionData?.rotations.length : 0) / pageSize);

    // if (currentPage >= pagesCount && pagesCount !== 0)
    //     dispatch(setApproveStudyplansPaginationCurrentPageValue(0));

    // const handleClick = (e, index) => {
    //     e.preventDefault();
    //     console.log('_pagination_index', index);
    //     dispatch(setApproveStudyplansPaginationCurrentPageValue(index));
    // };

    const backToStudyPlanList = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.UNSELECT, null));
    }

    const goBackToStages = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.STUDY_PLAN_STAGES_VIEW, actionData));
    }



    console.log("ApproveStudyPlanRotationsManager==>", actionData);

    return (
        <>
            <div className="breadcrumbs pointer mb-2">
                <div>
                    <span onClick={backToStudyPlanList}>  {t('approveStudyPlan.traineeStudyPlan')} </span>
                    {actionData?.apporvalStatus === EApprovelActions.APPROVED && <> <span>
                        <i className="ti-angle-right"></i></span>
                        <span onClick={goBackToStages}>{actionData?.traineeName} </span></>}

                    <span>
                        <i className="ti-angle-right"></i></span>
                    <span className="active">{t('approveStudyPlan.viewStudyPlan')} </span>
                </div>
            </div>

            {/* <div className="compHeading">
                <h2 className="m-0">{t('approveStudyPlan.rotationsofProgramme')}</h2>
            </div> */}
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent table-responsive">
                        <table className="table myTable w-100">
                            <thead>
                                <tr>
                                    <th>{t('approveStudyPlan.sequence')}</th>
                                    <th> {t('approveStudyPlan.stage')}</th>
                                    <th> {t('approveStudyPlan.rotation')}</th>
                                    <th> {t('approveStudyPlan.hospitalName')}</th>
                                    <th> {t('approveStudyPlan.duration')}<p className="mb-0" style={{ fontSize: "10px" }}> {t('approveStudyPlan.inMonths')}</p></th>
                                    <th>{t('approveStudyPlan.completionMarkStatus')}</th>
                                    <th>{t('approveStudyPlan.comments')}</th>
                                    {actionData?.apporvalStatus === EApprovelActions.APPROVED && <th>{t('approveStudyPlan.actions')}</th>}
                                </tr>
                            </thead>
                            <tbody>
                                {/* .slice((currentPage * pageSize), ((currentPage + 1) * pageSize)) */}

                                {actionData?.rotations && actionData?.rotations?.map((x, i) => (
                                    <ParentContext.Provider value={{ spRotationId: x.spRotationId, apporvalStatus: actionData?.apporvalStatus, traineeId: actionData?.traineeId, traineeUserId: actionData?.traineeUserId }} key={i}>
                                        <context.approveStudyPlanRotationsView />
                                    </ParentContext.Provider>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            {/* {actionData?.rotations && actionData?.rotations.length > pageSize &&
                <div className="pagination">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>} */}
        </>
    )
}


export default React.memo(ApproveStudyPlanRotationsManager);