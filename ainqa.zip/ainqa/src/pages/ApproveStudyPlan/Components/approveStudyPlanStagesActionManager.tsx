import React, { useContext } from 'react';
import { IApproveStudyPlanModel, IStudyPlan } from '../../../models/approveStudyPlanModel';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext, SuperParentContext } from '../Container/ApproveStudyPlanContext';
import { useTranslation } from 'react-i18next';
import groupBy from 'lodash/groupBy';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { setApproveStudyplanActionTypeData } from '../../../store/actions';
import { Row, Col } from 'reactstrap';

const ApproveStudyPlanStagesActionManager: React.FC = () => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionData: IStudyPlan | undefined = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.actionData)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).actionData
        else return undefined;
    });

    let groupedRotationData = groupBy(actionData?.rotations, 'rotationStageName')
    let stage = Object.entries(groupedRotationData);
    const goBackToTraineeStudyPlan = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.UNSELECT, null))
    };

    const goToRotationsView = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.SELECT, actionData))
    };
    const goToChartView = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.CHARTVIEW, actionData))
    };
    console.log('ApproveStudyPlanStagesActionManage==>', { groupedRotationData, stage, actionData });

    return (
        <>
            <Row className="compHeading">
                <Col>
                    <div className="breadcrumbs">
                        <div>
                            <span className="pointer" onClick={goBackToTraineeStudyPlan}>{t('approveStudyPlan.traineeStudyPlan')}</span>
                            <span>
                                <i className="ti-angle-right"></i></span>
                            <span className="active">{actionData?.traineeName}</span>
                        </div>
                    </div>
                </Col>
                <div className="rgtFilter">
                    <button className='btn link-button mr-1' onClick={goToChartView}>{t('approveStudyPlan.viewChart')}</button>{' '}
                    <button className='btn btn-green' onClick={goToRotationsView}>{t('approveStudyPlan.viewStudyPlan')}</button>
                </div>
            </Row>
            <div className="flexScroll">
                <div className="main-table no-border">
                    <div className="tbl-parent">
                        <table className="myTable rop-stdplan table">
                            <thead>
                                <tr>
                                    <th>{t('approveStudyPlan.stage')}</th>
                                    <th> {t('approveStudyPlan.rotationsCount')}</th>
                                    <th> {t('approveStudyPlan.duration')}<p className="mb-0" style={{ fontSize: "10px" }}> {t('approveStudyPlan.inMonths')}</p></th>
                                    <th> {t('approveStudyPlan.completionMarkStatus')}</th>
                                    <th> {t('approveStudyPlan.remarks')}</th>
                                    <th> {t('approveStudyPlan.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/* .slice((currentPage * pageSize), ((currentPage + 1) * pageSize)) */}
                                {actionData && groupedRotationData && Object.entries(groupedRotationData)?.map((x) => (
                                    <ParentContext.Provider value={{ x, traineeName: actionData.traineeName, traineeId: actionData?.traineeId, traineeUserId: actionData?.traineeUserId }} key={x[0]}>
                                        <context.apporveStudyPlanStageActions />
                                    </ParentContext.Provider>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(ApproveStudyPlanStagesActionManager);