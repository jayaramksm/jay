import React, { useContext } from 'react';
import { ParentContext } from '../Container/ApproveStudyPlanContext';
import { useDispatch, useSelector } from 'react-redux'
import { EStatusType, IApproveStudyPlanModel } from '../../../models/approveStudyPlanModel';
import { EApprovelActions, EOprationalActions } from '../../../models/utilitiesModel';
import { MySelect, defultContentValidate } from '../../../helpers/helpersIndex';
import { studyPlanStagesOrRotationsStatusModelRequest } from '../../../store/actions';
import { Formik, Form } from 'formik';
import Reject from '../../../images/Reject.svg';
import pending from '../../../images/Pending.svg';
import approved from '../../../images/Approved.svg';
import active from '../../../images/Active_icon.svg';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';


const ApproveStudyPlanRotationsView: React.FC = () => {

    const context: any = useContext(ParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation('translations');

    const rotation: any = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.actionData?.rotations?.length) {
            let rotation = (state.approveStudyPlanReducer as IApproveStudyPlanModel).actionData;
            return rotation?.rotations?.find(x => x.spRotationId === context?.spRotationId);
        } else
            return undefined;
    });

    const actionType: number = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel)?.actionType;
        else return EOprationalActions.UNSELECT;
    });

    // const userDto: IUserDetails = useSelector(state => {
    //     if (state?.SessionState?.userDto)
    //         return state.SessionState.userDto;
    //     else return {};
    // });
    console.log("ApproveStudyPlanRotationsView==>", rotation, context);

    const approvalOptions = [{ value: 'completed', label: 'Completed' },
    { value: 'failed', label: 'Failed' }];

    const markRotationStatus = (setFieldValue) => {
        setFieldValue('canMarkStatus', 'yes')
        return ''
    }
    const cancelRotationStatusUpdate = (setFieldValue) => {
        setFieldValue('canMarkStatus', '')
    }

    const updateRotationStatus = (status, submitForm, isValid, dirty) => {
        submitForm();
        if (isValid && dirty)
            dispatch(studyPlanStagesOrRotationsStatusModelRequest({ isModelOpen: true, data: status, spRotationId: rotation?.spRotationId, requestType: EStatusType.ROTATION, rotationId: rotation?.rotationId, traineeId: context?.traineeId, traineeUserId: context?.traineeUserId }))
    }

    return (
        <>
            {rotation && <tr>
                <Formik
                    initialValues={{
                        approvalStatus: '',
                        canMarkStatus: ''
                    }}
                    validationSchema={Yup.object().shape({
                        approvalStatus: defultContentValidate(t('controleErrors.required'))
                    })}
                    onSubmit={values => console.log('onSubmit==>', values)}
                >
                    {
                        ({ values, setFieldValue, setFieldTouched, errors, touched, submitForm, isValid, dirty }) => {
                            return <>
                                <td>{rotation.rotationSequence}</td>
                                <td>{rotation.rotationStageName}</td>
                                <td>{rotation.rotation}</td>
                                <td>{rotation.hospitalName || `Other- ${rotation.otherHospitalName}`}</td>
                                <td>{rotation.rotationDuration}</td>
                                <td >
                                    {values.canMarkStatus === 'yes' && <MySelect
                                        name='approvelStatus'
                                        value={values.approvalStatus}
                                        placeholder={t('approveStudyPlan.approvalStatus')}
                                        onChange={(e) => setFieldValue("approvalStatus", e)}
                                        options={approvalOptions ? approvalOptions : []}
                                        getOptionLabel={option => option.label}
                                        getOptionValue={option => option.value}
                                        onBlur={() => setFieldTouched('approvalStatus', true)}
                                    />}
                                    {values.canMarkStatus === 'yes' && (errors.approvalStatus && touched.approvalStatus) && <div className='text-danger'>{errors.approvalStatus}</div>}
                                    {
                                        !values.canMarkStatus && (rotation?.rotationStatus === EApprovelActions.COMPLETED ? <img src={approved} alt="" className="icon"></img> :
                                            rotation.rotationStatus === EApprovelActions.FAILED ? <img src={Reject} alt="rejectLogo" /> : rotation.rotationStatus === EApprovelActions.ACTIVE ? <img src={active} alt="" className="icon"></img> : rotation.rotationStatus === EApprovelActions.PENDING ? <img src={pending} alt="pending" className="icon text-primary"></img> : '')
                                    }
                                </td>
                                <td>
                                    {rotation.rotationComments || "--"}
                                </td>
                                {!values.canMarkStatus && context?.apporvalStatus === EApprovelActions.APPROVED && <>{(rotation.rotationStatus === EApprovelActions.ACTIVE) ? <td className='pointer ActionStatus' onClick={() => markRotationStatus(setFieldValue)}>
                                    {t('approveStudyPlan.markStatus')}
                                </td> :
                                    <td>-</td>}
                                </>}
                                {values.canMarkStatus === 'yes' && <td>
                                    <button type='button' className='btn blue-button' onClick={() => updateRotationStatus(values.approvalStatus, submitForm, isValid, dirty)}>{t('ActionNames.save')}</button>
                                    <button type='button' className='btn icon-btn' onClick={() => cancelRotationStatusUpdate(setFieldValue)}><i className="icon-Close"></i></button>
                                </td>}
                            </>
                        }
                    }
                </Formik>
            </tr>}
        </>

    )
}
export default React.memo(ApproveStudyPlanRotationsView);