import React, { useContext } from 'react';
import { Formik, Form } from 'formik';
import { ParentContext } from '../Container/ApproveStudyPlanContext';
import { EApprovelActions, EOprationalActions } from '../../../models/utilitiesModel';
import Reject from '../../../images/Reject.svg';
import pending from '../../../images/Pending.svg';
import approved from '../../../images/Approved.svg';
import active from '../../../images/Active_icon.svg';
import { useTranslation } from 'react-i18next';
import { MySelect, defultContentValidate } from '../../../helpers/helpersIndex';
import { useDispatch } from 'react-redux';
import { alertActionRequest, setApproveStudyPlanRotationActionTypeData, studyPlanStagesOrRotationsStatusModelRequest } from '../../../store/actions';
import * as Yup from 'yup';
import { EStatusType, IRotation } from '../../../models/approveStudyPlanModel';


const ApporveStudyPlanStageActions: React.FC = () => {

    const { x: [stageName, rotations], traineeName, traineeId, traineeUserId } = useContext(ParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const sumRotationsDuration = (rotations) => {
        return rotations?.reduce((acc, x) => acc + (+x.rotationDuration), 0);
    }

    console.log('stagesActionData===>', stageName, rotations, rotations?.map(x => x.spRotationId)?.toString());

    const approvalOptions = [{ value: 'completed', label: 'Completed' },
    { value: 'failed', label: 'Failed' }];

    let isStageActive = rotations?.some(x => x.rotationStatus !== EApprovelActions.PENDING);

    const showRotations = () => {
        dispatch(setApproveStudyPlanRotationActionTypeData(EOprationalActions.STUDY_PLAN_ROTATIONS_VIEW, { stageName, traineeName, rotations, traineeId, traineeUserId }))
    }

    let duplicatesFilteredData: IRotation[] = []
    rotations?.forEach((x, ind, a) => {
        let index = a.findIndex(y => y.rotationId === x.rotationId);
        if (index === ind) {
            duplicatesFilteredData.push(x);
        } else {
            let i = duplicatesFilteredData.findIndex(z => z.rotationId === x.rotationId);
            if (duplicatesFilteredData[i].rotationStatus === EApprovelActions.FAILED) {
                duplicatesFilteredData.splice(i, 1, x)
            }
        }
    });

    const markStageStatus = (setFieldValue) => {
        let pendingActiveRotations = rotations?.filter(x => (x.rotationStatus === EApprovelActions.PENDING || x.rotationStatus === EApprovelActions.ACTIVE));
        if (pendingActiveRotations && pendingActiveRotations.length > 0) {
            console.log('rotationsData==>', pendingActiveRotations)
            const alertMessageData = {
                message: t('approveStudyPlan.rotationsStatus'),
                status: false,
                tranId: Date.now()
            };
            dispatch(alertActionRequest(alertMessageData));
        }
        else {
            setFieldValue('canMarkStatus', 'yes')
        }
    }
    const cancelStageStatusUpdate = (setFieldValue) => {
        setFieldValue('canMarkStatus', '')
    }

    const updateStageStatus = (submitForm, isValid, dirty, status) => {
        submitForm();
        if (isValid && dirty) {
            let pendingActiveRotations = duplicatesFilteredData?.filter(x => (x.rotationStatus === EApprovelActions.PENDING || x.rotationStatus === EApprovelActions.ACTIVE));
            let rotationaCompliteStatus = duplicatesFilteredData?.every(x => (x.rotationStatus === EApprovelActions.COMPLETED));
            let failedRotations = duplicatesFilteredData?.some(x => x.rotationStatus === EApprovelActions.FAILED)
            if (status.value === EApprovelActions.FAILED && (pendingActiveRotations?.length > 0 || !failedRotations)) {
                const alertMessageData = {
                    message: t('approveStudyPlan.failedStatus'),
                    status: false,
                    tranId: Date.now()
                };
                dispatch(alertActionRequest(alertMessageData));
            }
            else if (status.value === EApprovelActions.COMPLETED && !rotationaCompliteStatus) {
                const alertMessageData = {
                    message: t('approveStudyPlan.completeStatus'),
                    status: false,
                    tranId: Date.now()
                };
                dispatch(alertActionRequest(alertMessageData));
            }
            else {
                dispatch(studyPlanStagesOrRotationsStatusModelRequest({ isModelOpen: true, data: status, spRotationId: rotations?.map(x => x.spRotationId)?.toString(), requestType: EStatusType.STAGE }))
            }
        }
    }

    console.log('ApporveStudyPlanStageActions==>', { duplicatesFilteredData, rotations });


    return (
        <>
            <tr>
                <Formik
                    initialValues={{
                        approvalStatus: '',
                        canMarkStatus: ''
                    }}
                    validationSchema={Yup.object().shape({
                        approvalStatus: defultContentValidate(t('controleErrors.required'))
                    })}
                    onSubmit={values => console.log('onSubmit==>', values)}
                >
                    {
                        ({ values, setFieldValue, setFieldTouched, errors, touched, submitForm, isValid, dirty }) => {
                            return <>
                                <td onClick={showRotations} className='pointer ActionStatus'>{stageName}</td>
                                <td>{rotations?.length}</td>
                                <td>{sumRotationsDuration(rotations)}</td>
                                <td>
                                    {values.canMarkStatus === 'yes' && <MySelect
                                        name='approvelStatus'
                                        value={values.approvalStatus}
                                        placeholder={t('approveStudyPlan.approvalStatus')}
                                        onChange={(e) => setFieldValue("approvalStatus", e)}
                                        options={approvalOptions ? approvalOptions : []}
                                        getOptionLabel={option => option.label}
                                        getOptionValue={option => option.value}
                                        onBlur={() => setFieldTouched('approvalStatus', true)}
                                    />
                                    }
                                    {values.canMarkStatus === 'yes' && (errors.approvalStatus && touched.approvalStatus) && <div className='text-danger'>{errors.approvalStatus}</div>}
                                    {
                                        !values.canMarkStatus && (rotations[0]?.stageStatus === EApprovelActions.COMPLETED ? <img src={approved} alt="" className="icon"></img> :
                                            rotations[0]?.stageStatus === EApprovelActions.FAILED ? <img src={Reject} alt="rejectLogo" /> : rotations[0]?.stageStatus === EApprovelActions.ACTIVE ? <img src={active} alt="" className="icon"></img> : rotations[0]?.stageStatus === EApprovelActions.PENDING ? <img src={pending} alt="pending" className="icon"></img> : '')
                                    }
                                </td>
                                <td>
                                    {rotations[0]?.stageComments || '-'}
                                </td>
                                {!values.canMarkStatus && <>{(rotations[0]?.stageStatus !== EApprovelActions.FAILED && rotations[0]?.stageStatus !== EApprovelActions.COMPLETED) ? <td className='pointer ActionStatus' onClick={() => markStageStatus(setFieldValue)}>
                                    {t('approveStudyPlan.markStatus')}
                                </td> :
                                    <td>-</td>}
                                </>}
                                {values.canMarkStatus === 'yes' && <td>
                                    <button type='button' className='btn blue-button mr-2' onClick={() => updateStageStatus(submitForm, isValid, dirty, values.approvalStatus)}>{t('ActionNames.save')}</button>
                                    <button type='button' className='btn icon-btn' onClick={() => cancelStageStatusUpdate(setFieldValue)}><i className="icon-Close"></i></button>
                                </td>}
                            </>
                        }
                    }
                </Formik>
            </tr>
        </>
    )
}

export default React.memo(ApporveStudyPlanStageActions);