import React from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { EStatusType, IApproveStudyPlanModel } from '../../../models/approveStudyPlanModel';
import { setApproveStudyplanStageOrRotationApproveRequest, studyPlanStagesOrRotationsStatusModelRequest } from '../../../store/actions';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { defultContentValidate } from '../../../helpers/helpersIndex';

const ApproveStudyPlanStagesorRotationsModel: React.FC = () => {

    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const modelData: any = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.modelData)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).modelData
        else return undefined;
    });

    const closeModel = () => {
        dispatch(studyPlanStagesOrRotationsStatusModelRequest(undefined))
    }
    console.log("ApproveStudyPlanStagesorRotationsModel==>", modelData)
    return (
        <>
            <Modal isOpen={modelData && modelData.isModelOpen} className="apsr-model">
                <Formik
                    initialValues={{
                        comments: '',
                        spRotationId: modelData?.spRotationId,
                        status: modelData?.data?.value,
                        rotationId: modelData?.rotationId || '',
                        traineeId: modelData?.traineeId || '',
                        traineeUserId: modelData?.traineeUserId || ''
                    }}
                    validationSchema={Yup.object().shape({
                        comments: defultContentValidate(t('controleErrors.required'))
                    })}
                    onSubmit={values => {
                        console.log('onSubmit==>', values)

                        dispatch(setApproveStudyplanStageOrRotationApproveRequest(values, modelData?.requestType));
                        dispatch(studyPlanStagesOrRotationsStatusModelRequest(undefined));
                    }
                    }

                >
                    {
                        ({ values, errors }) => {
                            return <>
                                <Form>
                                    <ModalHeader className="p-0">
                                        <div className="text-center">
                                            <h6>{t('approveStudyPlan.statusHeading').replace('{status}', modelData?.data?.value)}</h6>
                                        </div>
                                        <div className="modal-close">
                                            <span className='btn btn-danger' onClick={closeModel}>X</span>
                                        </div>
                                    </ModalHeader>
                                    <ModalBody>

                                        <label>{t('approveStudyPlan.remarks')}</label>
                                        <Field as='textarea' name='comments' row='20' col='50' className='form-control' />
                                        <ErrorMessage name='comments' component='div' className='text-danger' />

                                    </ModalBody>
                                    <ModalFooter className="md-f align-center">
                                        <Button color="btn btn-borderred px-4 mr-2" onClick={closeModel}>{t('ActionNames.no')}</Button>
                                        <Button color="btn blue-button px-4 ml-2" type='submit'>{t('ActionNames.yes')}</Button>{' '}
                                    </ModalFooter>
                                    {modelData?.requestType === EStatusType.ROTATION && <div className='text-danger text-center pb-2'>{t('approveStudyPlan.recommendedDuration')}</div>}
                                    <div className='text-danger text-center pb-2'>{t('approveStudyPlan.statusFooter')}</div>
                                </Form>
                            </>
                        }
                    }
                </Formik>

            </Modal>

        </>
    )
}

export default React.memo(ApproveStudyPlanStagesorRotationsModel);