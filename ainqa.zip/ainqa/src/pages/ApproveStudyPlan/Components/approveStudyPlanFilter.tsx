import React from 'react';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { useDispatch } from 'react-redux';
import { setSearchApproveStudyplanData } from '../../../store/actions';


const ApproveStudyPlanFilter: React.FC = () => {
    const { t } = useTranslation('translations');

    const dispatch = useDispatch();
    const onSearchChange = e => {
        const searchInput = e.target.value;
        dispatch(setSearchApproveStudyplanData(searchInput));
    };
    return (
        <Row className="compHeading">
            <Col>
                <h2> {t('approveStudyPlan.traineeStudyPlan')}</h2>
            </Col>
            <div className="rgtFilter">
                <div className="search-box filtericon">
                    <div className="search-text"><input type="text" onChange={onSearchChange} placeholder={t('approveStudyPlan.search')}></input><i className="ti-search icon"></i></div>
                </div>
            </div>
        </Row>
    )
}
export default React.memo(ApproveStudyPlanFilter);