import React from 'react'
import { Row, Col, FormGroup, Label } from 'reactstrap';
import { EApprovelActions, EOprationalActions } from 'models/utilitiesModel';
import {  useDispatch } from 'react-redux';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from 'yup';
import { MySelect, defultContentValidate, customContentValidation, defultContentObjectValidate } from '../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { setApproveStudyplanApproveRequest, setApproveStudyplanActionTypeData } from '../../../store/actions';

const ApproveStudyPlanAction: React.FC = () => {
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const approvalOptions = [{ value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' }];

    const backToStudyPlanList = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.UNSELECT, null));
    }
    const initialValues = () => ({
        approvelStatus: "",
        comments: ""
    });
    const validationSchema = Yup.object().shape({
        approvelStatus: defultContentObjectValidate(t('controleErrors.required')),
        comments: Yup.string().when('approvelStatus', {
            is: (approvelStatus) => (approvelStatus?.value === EApprovelActions.REJECTED),
            then: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 200, 4),
            otherwise: Yup.lazy((val) => {
                if (val)
                    return   customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: "" }, 200, 4);
                else return defultContentValidate(t(''));
            })
        })
        
    
    });
    return (
        <>
            <div className="main-form">
                <Formik
                    enableReinitialize
                    initialValues={initialValues()}
                    validationSchema={validationSchema}
                    onSubmit={(values) => {
                        dispatch(setApproveStudyplanApproveRequest(values, null));
                        console.log("SubmitedValues==>", values);
                    }}>
                    {({ errors, setFieldValue, setFieldTouched, values, touched }) => (
                        <Form>
                            <Row className="mt-4">
                                <Col sm="4">
                                    <FormGroup className="mx-auto">
                                        <Label>{t('approveStudyPlan.approvalStatus')}</Label>
                                        <MySelect
                                            name='approvelStatus'
                                            menuPlacement='top'
                                            value={values.approvelStatus}
                                            placeholder={t('approveStudyPlan.approvalStatus')}
                                            onChange={(e) => setFieldValue("approvelStatus", e)}
                                            options={approvalOptions ? approvalOptions : []}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('approvelStatus', true)}
                                            noOptionsMessage={() => { t('asds.NoDataFound') }}
                                        />
                                        {errors.approvelStatus && touched.approvelStatus && <div className="text-danger">{errors.approvelStatus}</div>}
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>  {t('approveStudyPlan.comments')}</Label>
                                        <Field placeholder={t('approveStudyPlan.comments')} name="comments" className={'form-control ' + (errors.comments && touched.comments ? 'is-invalid' : '')} />
                                        <ErrorMessage name="comments" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Row className="sub-form-footer mt-3 ml-1">
                                <button onClick={backToStudyPlanList} className="btn cancel-button mr-2">{t('approveStudyPlan.cancel')}</button>
                                <button className="btn blue-button">{t('approveStudyPlan.submit')}</button>
                            </Row>
                        </Form>
                    )
                    }
                </Formik>
            </div>
        </>

    )
}

export default React.memo(ApproveStudyPlanAction)