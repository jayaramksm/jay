import React, { useContext } from 'react';
import { ParentContext } from '../Container/ApproveStudyPlanContext';
import { EOprationalActions, EApprovelActions } from '../../../models/utilitiesModel';
import { useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'react-i18next';
import Approved from '../../../images/Approved.svg';
import { setApproveStudyplanActionTypeData } from '../../../store/actions';
import { IApproveStudyPlanModel, IStudyPlan } from '../../../models/approveStudyPlanModel';
import pending from '../../../images/Pending.svg';
import reject from '../../../images/Reject.svg';

const ApproveStudyPlanView: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation('translations');
    const context: any = useContext(ParentContext);

    const studyPlanData: IStudyPlan | undefined = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.studyPlanData?.length) {
            let studyPlanData = (state.approveStudyPlanReducer as IApproveStudyPlanModel).studyPlanData;
            return studyPlanData.find(x => x.traineeId === context);
        } else
            return undefined;
    });
    const approveStudyPlan = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.ADD, studyPlanData));
    };

    const StudyPlandView = (status) => {
        console.log('userStatus', status)
        if (status === EApprovelActions.REJECTED)
            dispatch(setApproveStudyplanActionTypeData(EOprationalActions.SELECT, studyPlanData));
        else dispatch(setApproveStudyplanActionTypeData(EOprationalActions.STUDY_PLAN_STAGES_VIEW, { ...studyPlanData }));
    };
    console.log("ApproveStudyPlanView==>", studyPlanData);

    return (
        <>
            <tr>
                <td>{(studyPlanData?.apporvalStatus === EApprovelActions.PENDING) ? <div className="ActionStatus pointer" onClick={approveStudyPlan}> {studyPlanData?.traineeName}</div> : <div className="ActionStatus pointer" onClick={() => StudyPlandView(studyPlanData?.apporvalStatus)}> {studyPlanData?.traineeName}</div>}</td>
                <td>{studyPlanData?.programName}</td>
                <td className="column-center">{(studyPlanData?.apporvalStatus === EApprovelActions.APPROVED) ? <img src={Approved} className="icon" alt="" /> : (studyPlanData?.apporvalStatus === EApprovelActions.PENDING ? <img src={pending} className="icon" alt="" /> : studyPlanData?.apporvalStatus === EApprovelActions.REJECTED ? <img src={reject} className="icon" alt="" /> : "")}</td>
                <td>{(studyPlanData?.apporvalStatus === EApprovelActions.PENDING) ? <div className="ActionStatus pointer" onClick={approveStudyPlan}> {t('approveStudyPlan.approve')}</div> : <div className="ActionStatus pointer" onClick={() => StudyPlandView(studyPlanData?.apporvalStatus)}> {t('approveStudyPlan.view')}</div>}</td>
            </tr>
        </>
    )
}
export default React.memo(ApproveStudyPlanView);