import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/ApproveStudyPlanContext';
import { useSelector, useDispatch } from 'react-redux';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { setApproveStudyplanActionTypeData } from '../../../store/actions';
import { IApproveStudyPlanModel, IStudyPlan } from '../../../models/approveStudyPlanModel';

const ApproveStudyPlanActionManager: React.FC = () => {

    const context: any = useContext(SuperParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const actionType: number = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.actionType) {
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).actionType
        } else {
            return EOprationalActions.UNSELECT
        }
    });

    const actionData: IStudyPlan | any = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.actionData) {
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).actionData
        } else {
            return undefined
        }
    });

    const backToStudyPlanList = () => {
        dispatch(setApproveStudyplanActionTypeData(EOprationalActions.UNSELECT, null));
    }

    return (
        <>
            <div className="breadcrumbs pointer">
                <div> <span onClick={backToStudyPlanList}>  {t('approveStudyPlan.approveStudyPlans')} </span>
                    <span>
                        <i className="ti-angle-right"></i></span>
                    <span className="active">{actionData?.traineeName} </span>
                </div>
            </div>

            <div className="compHeading">
                <h2 className="m-0">{t('approveStudyPlan.rotationsofProgramme')}</h2>
            </div>
            <div className="flexScroll">
                <context.approveStudyPlanRotationsManager />
                {actionType !== EOprationalActions.SELECT && <context.approveStudyPlanAction />}
            </div>
        </>
    )
}
export default React.memo(ApproveStudyPlanActionManager);