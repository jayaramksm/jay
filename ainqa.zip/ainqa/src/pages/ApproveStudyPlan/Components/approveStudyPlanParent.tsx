import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/ApproveStudyPlanContext';
import { useSelector } from 'react-redux';
import { EOprationalActions } from '../../../models/utilitiesModel';
import { IApproveStudyPlanModel } from '../../../models/approveStudyPlanModel';

const ApproveStudyPlanParent: React.FC = () => {

    const context: any = useContext(SuperParentContext);

    const actionType: number = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel)?.actionType;
        else return EOprationalActions.UNSELECT;
    });

    console.log("ApproveStudyPlanParent==>", actionType);

    return (
        <>
            <div className="flexLayout  maincontent pr-0">
                {actionType === EOprationalActions.UNSELECT && <context.approveStudyPlanFilter />}
                {actionType === EOprationalActions.UNSELECT && <context.approveStudyPlanViewManager />}
                {(actionType === EOprationalActions.ADD || actionType === EOprationalActions.SELECT) && <context.approveStudyPlanRotationsManager />}
                {actionType === EOprationalActions.ADD && <context.approveStudyPlanAction />}
                {actionType === EOprationalActions.STUDY_PLAN_STAGES_VIEW && <context.approveStudyPlanStagesActionManager />}
                {actionType === EOprationalActions.STUDY_PLAN_ROTATIONS_VIEW && <context.approveStudyPlanRotationsActionManager />}
                {actionType === EOprationalActions.CHARTVIEW && <context.approveStudyPlanChartView />}
            </div>
            <context.approveStudyPlanStagesorRotationsModel />
        </>
    )
}
export default React.memo(ApproveStudyPlanParent);