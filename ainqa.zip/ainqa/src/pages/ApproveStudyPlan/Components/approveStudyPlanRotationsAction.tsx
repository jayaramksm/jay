import React, { useContext } from 'react';
import { Formik, Form } from 'formik';
import { ParentContext } from '../Container/ApproveStudyPlanContext';
import { EApprovelActions, IUserDetails } from '../../../models/utilitiesModel';
import Reject from '../../../images/Reject.svg';
import pending from '../../../images/Pending.svg';
import approved from '../../../images/Approved.svg';
import { useTranslation } from 'react-i18next';
import { MySelect, defultContentValidate, customContentValidation } from '../../../helpers/helpersIndex';
import { useSelector, useDispatch } from 'react-redux';
import { studyPlanStagesOrRotationsStatusModelRequest } from '../../../store/actions';
import { EStatusType, IApproveStudyPlanModel } from '../../../models/approveStudyPlanModel';
import * as Yup from 'yup';
import active from '../../../images/Active_icon.svg';


const ApproveStudyPlanRotationsAction: React.FC = () => {

    const context = useContext(ParentContext);
    const { t } = useTranslation('translations');
    const dispatch = useDispatch();

    const rotationActionData: any = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.rotationActionData)
            return state.approveStudyPlanReducer.rotationActionData?.rotations?.find(x => x.spRotationId === context)
        else return undefined;
    });
    const rotationActionsData: any = useSelector((state: any) => {
        if (state?.approveStudyPlanReducer?.rotationActionData)
            return (state.approveStudyPlanReducer as IApproveStudyPlanModel).rotationActionData
        else return undefined;
    });

    const userDto: IUserDetails = useSelector((state: any) => {
        if (state?.SessionState?.userDto)
            return state.SessionState.userDto
        else return undefined;
    });

    const approvalOptions = [{ value: 'completed', label: 'Completed' },
    { value: 'failed', label: 'Failed' }];

    const markRotationStatus = (setFieldValue) => {
        setFieldValue('canMarkStatus', 'yes')
        return ''
    }
    const cancelRotationStatusUpdate = (setFieldValue) => {
        setFieldValue('canMarkStatus', '')
    }

    const updateRotationStatus = (status, submitForm, isValid, dirty) => {
        submitForm();
        if (isValid && dirty)
            dispatch(studyPlanStagesOrRotationsStatusModelRequest({ isModelOpen: true, data: status, spRotationId: rotationActionData?.spRotationId, requestType: EStatusType.ROTATION, rotationId: rotationActionData?.rotationId, traineeId: rotationActionsData?.traineeId, traineeUserId: rotationActionsData?.traineeUserId }))
    }
    console.log('ApproveStudyPlanRotationsAction==>', { context, rotationActionData, rotationActionsData })
    return (
        <>
            {rotationActionData && <tr>
                <Formik
                    initialValues={{
                        approvalStatus: '',
                        canMarkStatus: ''
                    }}
                    validationSchema={Yup.object().shape({
                        approvalStatus: defultContentValidate(t('controleErrors.required'))
                    })}
                    onSubmit={values => console.log('onSubmit==>', values)}
                >
                    {
                        ({ values, setFieldValue, setFieldTouched, submitForm, isValid, dirty, errors, touched }) => {
                            return <>
                                <td>{rotationActionData.rotationSequence}</td>
                                <td>{rotationActionData.rotation}</td>
                                <td>{rotationActionData.rotationStageName}</td>
                                <td>{userDto?.university?.universityName}</td>
                                <td>{rotationActionData.hospitalName || `Other- ${rotationActionData.otherHospitalName}`}</td>
                                <td>{rotationActionData.rotationDuration}</td>
                                <td >
                                    {values.canMarkStatus === 'yes' && <><MySelect
                                        name='approvelStatus'
                                        value={values.approvalStatus}
                                        placeholder={t('approveStudyPlan.approvalStatus')}
                                        onChange={(e) => setFieldValue("approvalStatus", e)}
                                        options={approvalOptions ? approvalOptions : []}
                                        getOptionLabel={option => option.label}
                                        getOptionValue={option => option.value}
                                        onBlur={() => setFieldTouched('approvalStatus', true)}
                                    />
                                        {values.canMarkStatus === 'yes' && (errors.approvalStatus && touched.approvalStatus) && <div className='text-danger'>{errors.approvalStatus}</div>}
                                    </>}
                                    {
                                        !values.canMarkStatus && (rotationActionData?.rotationStatus === EApprovelActions.COMPLETED ? <img src={approved} alt="" className="icon"></img> :
                                            rotationActionData.rotationStatus === EApprovelActions.FAILED ? <img src={Reject} alt="rejectLogo" /> : rotationActionData.rotationStatus === EApprovelActions.ACTIVE ? <img src={active} alt="" className="icon"></img> : rotationActionData.rotationStatus === EApprovelActions.PENDING ? <img src={pending} alt="pending" className="icon text-primary"></img> : '')
                                    }
                                </td>
                                <td>
                                    {rotationActionData.rotationComments || "--"}
                                </td>
                                {!values.canMarkStatus && <>{rotationActionData?.rotationStatus === EApprovelActions.ACTIVE ? <td className='pointer ActionStatus' onClick={() => markRotationStatus(setFieldValue)}>
                                    {t('approveStudyPlan.markStatus')}
                                </td> :
                                    <td>-</td>}
                                </>}
                                {values.canMarkStatus === 'yes' && <td>
                                    <button type='button' className='btn blue-button mr-2' onClick={() => updateRotationStatus(values.approvalStatus, submitForm, isValid, dirty)}>{t('ActionNames.save')}</button>
                                    <button type='button' className='btn icon-btn' onClick={() => cancelRotationStatusUpdate(setFieldValue)}><i className="icon-Close"></i></button>
                                </td>}
                            </>
                        }
                    }
                </Formik>
            </tr>}

        </>
    )
}

export default React.memo(ApproveStudyPlanRotationsAction);