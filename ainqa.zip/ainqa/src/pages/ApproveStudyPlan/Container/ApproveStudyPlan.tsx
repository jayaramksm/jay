import React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout, getApproveStudyplanDataRequest, cancelAllPendingApproveStudyPlanRequest, resetAllApproveStudyplanStateRequest } from '../../../store/actions';
import { SuperParentContext } from './ApproveStudyPlanContext';
import {
    ApproveStudyPlanParent, ApproveStudyPlanFilter, ApproveStudyPlanViewManager, ApproveStudyPlanView, ApproveStudyPlanAction,
    ApproveStudyPlanRotationsManager, ApproveStudyPlanRotationsView,
    ApproveStudyPlanRotationsAction, ApproveStudyPlanStagesorRotationsModel, ApproveStudyPlanRotationsActionManager, ApproveStudyPlanStagesActionManager, ApporveStudyPlanStageActions,
    ApproveStudyPlanChartView
} from './approveStudyPlanIndex'

interface IProps {
    activateAuthLayout;
    getApproveStudyplanDataRequest;
    resetAllApproveStudyplanStateRequest;
    cancelAllPendingApproveStudyPlanRequest;
}

class ApproveStudyPlan extends React.PureComponent<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            approveStudyPlanFilter: ApproveStudyPlanFilter,
            approveStudyPlanViewManager: ApproveStudyPlanViewManager,
            approveStudyPlanView: ApproveStudyPlanView,
            approveStudyPlanAction: ApproveStudyPlanAction,
            approveStudyPlanRotationsManager: ApproveStudyPlanRotationsManager,
            approveStudyPlanRotationsView: ApproveStudyPlanRotationsView,
            apporveStudyPlanStageActions: ApporveStudyPlanStageActions,
            approveStudyPlanRotationsAction: ApproveStudyPlanRotationsAction,
            approveStudyPlanRotationsActionManager: ApproveStudyPlanRotationsActionManager,
            approveStudyPlanStagesActionManager: ApproveStudyPlanStagesActionManager,
            approveStudyPlanStagesorRotationsModel: ApproveStudyPlanStagesorRotationsModel,
            approveStudyPlanChartView:ApproveStudyPlanChartView
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.resetAllApproveStudyplanStateRequest();
        this.props.getApproveStudyplanDataRequest();
    }
    componentWillUnmount() {
        this.props.cancelAllPendingApproveStudyPlanRequest();
        this.props.resetAllApproveStudyplanStateRequest();

    }
    render() {
        return (
            <>
                <SuperParentContext.Provider value={this.state}>
                    <ApproveStudyPlanParent />
                </SuperParentContext.Provider>
            </>
        )
    }
}


export default connect(null, { activateAuthLayout, getApproveStudyplanDataRequest, cancelAllPendingApproveStudyPlanRequest, resetAllApproveStudyplanStateRequest })(ApproveStudyPlan);