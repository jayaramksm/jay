import { EOprationalActions } from '../../models/utilitiesModel';
import * as types from './actionTypes';
import { IApproveStatutoryDocumentsMOdel } from 'models/approveStatutoryDocumentsModel';

const initialState = {} as IApproveStatutoryDocumentsMOdel

const asdsReducer = (state = initialState, action) => {
    let undefined;
    switch (action.type) {
        case types.RESET_ALL_ASDS_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefined,
                actionType: EOprationalActions.UNSELECT,
                asdsData: undefined,
                paginationCurrentPage: 0,
                searchKey: '',
                fileData: undefined
            }
            break;
        case types.GET_ASDA_DATA_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    asdsData: action.payload
                }
            break;
        case types.SET_ASDA_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.SET_ASDA_APPROVE_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    asdsData: action.payload,
                    actionType: EOprationalActions.UNSELECT

                }
            break;
        case types.SET_SEARCH_ASDA_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.SET_ASDA_FILE_VIEW_RESPONCE:
            state = {
                ...state,
                fileData: action.payload
            }
            break;

        case types.SET_ASDA_FILE_VIEW_MODEL_CLOSE:
            state = {
                ...state,
                fileData: action.payload,
            }
            break;

        case types.SET_ASDA_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
            }
            break;

        default: state = { ...state }
    }
    return state;
}

export default asdsReducer;