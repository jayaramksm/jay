import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingAsdsRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_ASDS_REQUEST
    }
}

export const resetAllAsdsStateRequest = () => {
    return {
        type: types.RESET_ALL_ASDS_STATE_REQUEST
    }
}

export const getAsdsDataRequest = () => {
    return {
        type: types.GET_ASDA_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true,
    }
}

export const getAsdsDataResponce = (asdsData, alertMessageData) => {
    return {
        type: types.GET_ASDA_DATA_RESPONCE,
        payload: asdsData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData

    }
}

export const setSearchAsdsData = (value) => {
    return {
        type: types.SET_SEARCH_ASDA_DATA,
        payload: value
    }
}

export const setAsdsActionTypeData = (actionType, actionData) => {
    return {
        type: types.SET_ASDA_ACTIONTYPE_DATA,
        payload: { actionType, actionData }
    }
}

export const setAsdsApproveRequest = (requestData, requestType) => {
    return {
        type: types.SET_ASDA_APPROVE_REQUEST,
        payload: { requestData, requestType },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}


export const setAsdsApproveResponse = (asdsData, alertMessageData) => {
    return {
        type: types.SET_ASDA_APPROVE_RESPONCE,
        payload: asdsData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}


export const setAsdFileViewRequest = (requestData) => {
    return {
        type: types.SET_ASDA_FILE_VIEW_REQUEST,
        payload: requestData,
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}

export const setAsdFileViewModelOpendOrClose = (data = null) => {
    return {
        type: types.SET_ASDA_FILE_VIEW_MODEL_CLOSE,
        payload: data
    }
}

export const setAsdFileViewResponse = (fileData, alertMessageData) => {
    return {
        type: types.SET_ASDA_FILE_VIEW_RESPONCE,
        payload: fileData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}


export const setAsdsPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_ASDA_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}


