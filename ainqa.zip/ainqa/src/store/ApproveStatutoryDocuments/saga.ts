import { takeLeading, put, take, cancel, all, fork, call } from 'redux-saga/effects';
import * as types from './actionTypes';
import { convertImagePathToBase64, getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../helpers/helpersIndex';
import { EAPPModules, EApprovelActions, IAlertMessagedata, EAPIComponentNames } from '../../models/utilitiesModel';
import * as actions from './actions';
import * as _ from 'lodash';
import { ITrainee } from '../../models/approveStatutoryDocumentsModel';

function* getOnlyasdsData(tranId) {
    console.log(`${tranId}_getOnlyasdsData_start =>`);
    let asdsData: ITrainee[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        let asdsComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EDUCATIONAL_SUPERVISOR, 'getTraineeDocumentsByEsId');
        console.log(tranId + '_getasds_Api_Request =>', asdsComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, asdsComponentAndMethod, null, 'trainees');
        console.log(tranId + '_getasds_Api_Response =>', response);

        if (response) {
            asdsData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ASD1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveGla.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ASD1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getAllasdsData_error => `, error.messages ? error.messages : 'ASD2');
        console.log(`${tranId}_getAllasdsData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASD2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'asds.alertMessages.',
            messageCode: getMessageCode(tranId, 'ASD2'),

            statusCode: error.statuscode ? error.statuscode : 0
        }
    }
    console.log(`${tranId}_getOnlyasdsData_end =>`, asdsData, alertMessageData);

    return { asdsData, alertMessageData }
}

function* getasdsData() {
    let tranId = gettranId(EAPPModules.APPROVESTATUTORYDOCMODULE);

    console.log(`${tranId}_get_asdsAndDeptData_start =>`);
    let asdsData: ITrainee[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {

        let asdsDataresponse = yield call(getOnlyasdsData, tranId);
        alertMessageData = asdsDataresponse?.alertMessageData
        if (!alertMessageData) {
            asdsData = asdsDataresponse?.asdsData;
        }

    }
    catch (error) {
        console.log(`${tranId}_getasdsAndDepartmentData_error => `, error.messages ? error.messages : 'ASD2');
        console.log(`${tranId}_getasdsAndDepartmentData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASD2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'asds.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ASD2'),

        }
    }
    console.log(`${tranId}_getasdsAndDeptData_end =>`, asdsData, alertMessageData);

    yield put(actions.getAsdsDataResponce(asdsData, alertMessageData));

}


function* updateStatusasds(action) {
    let tranId = gettranId(EAPPModules.APPROVESTATUTORYDOCMODULE);
    console.log(`${tranId}_updateStatusasds_start =>`, action, action.payload.requestData);
    let asdsData: any[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const requestData = action.payload.requestData
    const isAppapprovalStatus = requestData.values?.approvelStatus?.every(x => (x.approvalStatus?.value || x.approvalStatus) === EApprovelActions.APPROVED)
    // const isAppRejectedStatus = requestData.values?.approvelStatus?.some(x => x.approvalStatus === EApprovelActions.REJECTED || x.approvalStatus?.value === EApprovelActions.REJECTED)
    const isAppPendingStatus = requestData.values?.approvelStatus?.some(x => (x.approvalStatus?.value || x.approvalStatus) === EApprovelActions.PENDING)
    try {
        const appStatus = isAppPendingStatus ? EApprovelActions.PENDING : (isAppapprovalStatus ? EApprovelActions.APPROVED : EApprovelActions.REJECTED);
        let createobject: any = {
            appapprovalStatus: appStatus,
            documents: requestData?.diffvalues?.map(doc => (
                {
                    approvalComments: doc.approvalComments,
                    approvalStatus: doc.approvalStatus?.value,
                    docId: doc.docId
                }
            )),
            traineesId: requestData?.values?.traineesId,
            userId: requestData?.values?.userId
        }
        console.log(`${tranId}_updateStatusasds_stringify =>`, { createobject, stringify: JSON.stringify(createobject) }, createobject, appStatus);

        let updateStatusasdComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EDUCATIONAL_SUPERVISOR, 'updateDocumentStatus');
        console.log(`${tranId}_updateStatusasds_Api_Request =>`, updateStatusasdComponentAndMethod, createobject, appStatus);
        let response = yield call(serviceConsumer, tranId, updateStatusasdComponentAndMethod, createobject, null)
        console.log(`${tranId}_updateStatusasds_Api_Response`, response);
        if (response.status) {
            let asdsDataresponse = yield call(getOnlyasdsData, tranId);
            alertMessageData = asdsDataresponse?.alertMessageData

            if (!alertMessageData) {
                asdsData = asdsDataresponse?.asdsData;
            }
            if (!asdsDataresponse.alertMessageData)
                alertMessageData = {
                    message: response.messages ? response.messages : 'ASD3',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'asds.alertMessages.',
                    messageCode: response.messages ? undefined : tranId + 'ASD3'
                }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ASD4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'asds.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ASD4')
            }
        }
    } catch (error) {
        console.log(`${tranId}_updateStatusasds_error => `, error.messages ? error.messages : 'ASD5');
        console.log(`${tranId}_updateStatusasds_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASD5',
            status: false,
            messageCode: getMessageCode(tranId, 'ASD5'),

            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'asds.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        }
    }

    console.log(`${tranId}_updateStatusasds_End`, asdsData, alertMessageData);
    yield put(actions.setAsdsApproveResponse(asdsData, alertMessageData));
}
function* getFileData(action) {
    let tranId = gettranId(EAPPModules.APPROVESTATUTORYDOCMODULE);

    console.log(`${tranId}_getFileData_start =>`, action);
    let fileData: ITrainee[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {

        console.log(`${tranId}_getFileData_api_request =>`, action.payload);
        const responses: any = yield call(convertImagePathToBase64, action.payload);
        console.log(`${tranId}_getFileData_api_responce =>`, responses);

        // [responses] is not required while we are working with multiple files
        if (responses)
            fileData = [responses];
        else {
            alertMessageData = {
                message: 'ASD6',
                status: false,
                tranId: Date.now(),
                transKey: 'asds.alertMessages.',
                messageCode: getMessageCode(tranId, 'ASD6')
            }
        }
    }
    catch (error) {
        console.log(`${tranId}_getFileData_error => `, error.messages ? error.messages : 'ASD7');
        console.log(`${tranId}_getFileData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASD7',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'asds.alertMessages.',
            messageCode: getMessageCode(tranId, 'ASD7'),

            statusCode: error.statuscode ? error.statuscode : 0
        }
    }
    console.log(`${tranId}_getFileData_end =>`, fileData, alertMessageData);

    yield put(actions.setAsdFileViewResponse(fileData, alertMessageData));
}

export function* watchasds() {
    yield takeLeading(types.SET_ASDA_APPROVE_REQUEST, updateStatusasds);
    yield takeLeading(types.SET_ASDA_FILE_VIEW_REQUEST, getFileData);
    while (true) {
        const main = yield takeLeading(types.GET_ASDA_DATA_REQUEST, getasdsData)
        yield take(types.CANCEL_ALL_PENDING_ASDS_REQUEST);
        yield cancel(main);
    }
}

function* asdsSaga() {
    yield all([fork(watchasds)]);
}

export default asdsSaga;