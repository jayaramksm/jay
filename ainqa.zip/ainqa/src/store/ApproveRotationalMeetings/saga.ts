import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, ERoleDesc, IAlertMessagedata, IConfirmModel, IConfirmOptions, IUserDetails } from '../../models/utilitiesModel';
import * as actions from './actions';
import * as _ from 'lodash';
import { IRotationalMeeting } from '../../models/approveRotationalMeetingModel';
import { setConfirmationOpen } from 'store/actions';


function* getOnlyapproveRotationalMeetingsData(tranId) {
    console.log(`${tranId}_getOnlyapproveRotationalMeetingsData_start =>`);
    let approveRotationalMeetingData: IRotationalMeeting[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;

    try {
        let approveClinicalMeetingComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.ROTATIONAL_SUPERVISOR, 'getAllMeetingsByRotationSupervisors');
        console.log(tranId + '_getOnlyapproveRotationalMeetingsData_Api_Request =>', approveClinicalMeetingComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, approveClinicalMeetingComponentAndMethod, null, 'rotationalMeetings');
        console.log(tranId + '_getOnlyapproveClinicalMeetingsData_Api_Response =>', response);

        if (response) {
            approveRotationalMeetingData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ARM1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ApproveRotationalMeetings.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ARM1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getOnlyapproveRotationalMeetingsData_error => `, error.messages ? error.messages : 'ARM2');
        console.log(`${tranId}_getOnlyapproveRotationalMeetingsData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ARM2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveRotationalMeetings.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ARM2'),
        }
    }
    console.log(`${tranId}_getOnlyapproveRotationalMeetingsData_end =>`, approveRotationalMeetingData, alertMessageData);

    return { approveRotationalMeetingData, alertMessageData }
}

function* getapproveRotationalMeetingsData() {
    let tranId = gettranId(EAPPModules.APPROVEROTATIONALMEETINGMODULE);

    console.log(`${tranId}_get_approveRotationalMeetingsData_start =>`);
    let approveRotationalMeetingData: IRotationalMeeting[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {

        let approveClinicalMeetingDataresponse = yield call(getOnlyapproveRotationalMeetingsData, tranId);
        alertMessageData = approveClinicalMeetingDataresponse?.alertMessageData
        if (!alertMessageData) {
            approveRotationalMeetingData = approveClinicalMeetingDataresponse?.approveRotationalMeetingData;
        }

    }
    catch (error) {
        console.log(`${tranId}_getapproveRotationalMeetingsData_error => `, error.messages ? error.messages : 'ARM2');
        console.log(`${tranId}_getapproveRotationalMeetingsData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ARM2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveRotationalMeetings.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ARM2'),
        }
    }
    console.log(`${tranId}_getapproveRotationalMeetingsData_end =>`, approveRotationalMeetingData, alertMessageData);

    yield put(actions.getApproveRotationalMeetingsDataResponce(approveRotationalMeetingData, alertMessageData));

}


function* setApproveRotationalMeetingsSatus(action) {
    let tranId = gettranId(EAPPModules.APPROVEROTATIONALMEETINGMODULE);
    console.log(`${tranId}_setApproveRotationalMeetingsSatus_start =>`, action, action.payload.requestData);
    let approveRotationalMeetingData: IRotationalMeeting[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    const requestData: IRotationalMeeting = action.payload.requestData?.rotationalMeetingActionData
    const { approvalStatus, comments } = action.payload.requestData;
    const methode = (userDto?.userId === requestData.firstRotationSupervisor?.supervisorId) ? 'updateMeetingFirstRsStatus' : 'updateMeetingSecondRsStatus';
    if (action.payload.confirmType) {
        try {
            let statusObject: any = (userDto?.userId === requestData.firstRotationSupervisor?.supervisorId) ? {
                comments: comments || '',
                meetingType: requestData?.meetingType || '',
                nextMeetingDate: requestData?.nextMeetingDate || '',
                programName: requestData?.programName || '',
                rotationName: requestData?.rotationName || '',
                rotationalMeetingId: requestData?.rotationalMeetingId || '',
                stage: requestData?.stage || '',
                status: approvalStatus?.value || '',
                supervisorId: requestData?.firstRotationSupervisor?.supervisorId || '',
                supervisorMailId: requestData?.firstRotationSupervisor?.supervisorMailId || '',
                supervisorName: requestData?.firstRotationSupervisor.supervisorName || '',
                traineeId: requestData?.traineeId || '',
                traineeMailId: requestData?.traineeMailId || '',
                traineeName: requestData?.traineeName || '',
                userId: requestData?.userId || ''
            } :
                {
                    comments: comments || '',
                    meetingType: requestData?.meetingType || "",
                    nextMeetingDate: requestData?.nextMeetingDate || "",
                    programName: requestData?.programName || "",
                    rotationName: requestData?.rotationName || "",
                    rotationalMeetingId: requestData?.rotationalMeetingId || "",
                    stage: requestData?.stage || "",
                    status: approvalStatus?.value || "",
                    supervisorId: requestData?.secondRotationSupervisor?.supervisorId || "",
                    supervisorMailId: requestData?.secondRotationSupervisor?.supervisorName || "",
                    supervisorName: requestData?.secondRotationSupervisor?.supervisorName || "",
                    traineeId: requestData?.traineeId || "",
                    traineeMailId: requestData?.traineeMailId || "",
                    traineeName: requestData?.traineeName || "",
                    userId: requestData?.userId || ''
                }

            let glaCreateComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.ROTATIONAL_SUPERVISOR, methode);
            console.log(`${tranId}_setApproveRotationalMeetingsSatus_Api_Request =>`, glaCreateComponentAndMethod, statusObject);
            let response = yield call(serviceConsumer, tranId, glaCreateComponentAndMethod, statusObject, null)
            console.log(`${tranId}_setApproveRotationalMeetingsSatus_Api_Response`, response);
            if (response.status) {
                let approveClinicalMeetingDataresponse = yield call(getOnlyapproveRotationalMeetingsData, tranId);
                alertMessageData = approveClinicalMeetingDataresponse?.alertMessageData

                if (!alertMessageData) {
                    approveRotationalMeetingData = approveClinicalMeetingDataresponse?.approveRotationalMeetingData;
                }
                if (!approveClinicalMeetingDataresponse.alertMessageData)
                    alertMessageData = {
                        message: response.messages ? response.messages : 'ARM3',
                        status: true,
                        tranId: Date.now(),
                        transKey: response.messages ? '' : 'ApproveRotationalMeetings.alertMessages.',
                        messageCode: response.messages ? undefined : getMessageCode(tranId + 'ARM3')
                    }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'ARM4',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'ApproveRotationalMeetings.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'ARM4')
                }
            }
        } catch (error) {
            console.log(`${tranId}_setApproveRotationalMeetingsSatus_error => `, error.messages ? error.messages : 'ARM5');
            console.log(`${tranId}_setApproveRotationalMeetingsSatus_catch=>`, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'ARM5',
                status: false,
                tranId: Date.now(),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveRotationalMeetings.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0,
                messageCode: getMessageCode(tranId, 'ARM5'),

            }
        }

        console.log(`${tranId}_setApproveRotationalMeetingsSatus_End`, approveRotationalMeetingData, alertMessageData);
        yield put(actions.setApproveRotationalMeetingsSatusResponse(approveRotationalMeetingData, alertMessageData));


    }
    else {
        let optionsData = [
            {
                title: 'Yes',
                function: actions.setApproveRotationalMeetingsStatusRequest(action.payload.requestData, action.payload.requestType, true, action.payload.confirmMessage),
                loading: 1,
                className: 'btn-primary'
            },
            {
                title: 'No',
                loading: 0,
                className: 'btn-danger'
            }
        ] as IConfirmOptions[];

        let confirmModel = {
            title: action.payload.confirmMessage,
            options: optionsData,
            transKey: ''
        } as IConfirmModel;

        console.log(`${tranId}_setActionRequest_2=> `, action, confirmModel);
        yield put(setConfirmationOpen(confirmModel));
    }
}

function* isEditApproveRotationalMeetingsData(action) {
    let tranId = gettranId(EAPPModules.APPROVEROTATIONALMEETINGMODULE);
    let approveRotationalMeetingData: IRotationalMeeting[] | undefined;
    let approveClinicalMeetingActionData: IRotationalMeeting | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    console.log(`${tranId}_isEditApproveRotationalMeetingsData_start =>`);
    const requestData = action.payload;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    const component = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? EAPIComponentNames.MOH_SUPERVISOR : EAPIComponentNames.EDUCATIONAL_SUPERVISOR
    const methode = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? 'updateMohStatusForGla' : 'updateEsStatusForGla'
    try {
        let createobject: any = {
            glaId: requestData.glaId,
            status: requestData.isEdit
        }
        let isEditApproveGlaComponentAndMethod = getApiServiceUrlByComponentAndMethod(component, methode);
        console.log(tranId + '_isEditApproveRotationalMeetingsData_Request =>', createobject, isEditApproveGlaComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, isEditApproveGlaComponentAndMethod, createobject, null);
        console.log(tranId + '_isEditApproveRotationalMeetingsData_Response =>', response);

        if (response.status) {
            console.log(tranId + '_isEditApproveRotationalMeetingsData_if=>', response);

        }
        else {
            console.log(tranId + '_isEditApproveRotationalMeetingsData_else=>', response);
        }
        let approveClinicalMeetingDataresponse = yield call(getOnlyapproveRotationalMeetingsData, tranId);
        alertMessageData = approveClinicalMeetingDataresponse?.alertMessageData
        if (!alertMessageData) {
            approveRotationalMeetingData = approveClinicalMeetingDataresponse?.approveRotationalMeetingData;
        }
        const actionData: IRotationalMeeting = (yield select())['approveGlasReducer']?.actionData;
        if (actionData) {
            let approveGlaActionData = approveRotationalMeetingData?.find(x => x.rotationalMeetingId === actionData?.rotationalMeetingId);
            if (!_.isEqual(approveGlaActionData, actionData))
                approveClinicalMeetingActionData = approveGlaActionData;
            console.log(`${tranId}_isEditApproveRotationalMeetingsData_getRotationalMeetings_And_set_ActionData_responce =>`, { approveRotationalMeetingData, approveClinicalMeetingActionData, actionData, approveGlaActionData, isEqual: !_.isEqual(approveGlaActionData, actionData) });

        }


    } catch (error) {
        console.log(`${tranId}_isEditApproveRotationalMeetingsData_error => `, error.messages ? error.messages : 'AGL6');
        console.log(`${tranId}_isEditApproveRotationalMeetingsData_catch=>`, error);

    }
    console.log(`${tranId}_isEditApproveRotationalMeetingsData_end =>`, approveClinicalMeetingActionData, alertMessageData);
    yield put(actions.isEditApproveRotationalMeetingsResponce(approveClinicalMeetingActionData, alertMessageData));



}



export function* watchapproveRotationalMeetings() {
    yield takeLeading(types.SET_APPROVE_ROTATIONALMEETINGS_SATUS_REQUEST, setApproveRotationalMeetingsSatus);
    // yield takeLeading(types.ISEDIT_APPROVE_ROTATIONALMEETINGS_REQUEST, isEditApproveRotationalMeetingsData);
    while (true) {
        const main = yield takeLeading(types.GET_APPROVE_ROTATIONALMEETINGS_DATA_REQUEST, getapproveRotationalMeetingsData)
        yield take(types.CANCEL_ALL_PENDING_APPROVE_ROTATIONALMEETINGS_REQUEST);
        yield cancel(main);
    }
}

function* approveRotationalMeetingsSaga() {
    yield all([fork(watchapproveRotationalMeetings)]);
}

export default approveRotationalMeetingsSaga;