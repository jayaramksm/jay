import { EOprationalActions } from '../../models/utilitiesModel';
import * as types from './actionTypes';
import { IApproveRotationalMeetingModel } from '../../models/approveRotationalMeetingModel';

const initialState = {} as IApproveRotationalMeetingModel

const approveRotationalMeetingsReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.RESET_ALL_APPROVE_ROTATIONALMEETINGS_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefinedData,
                actionType: EOprationalActions.UNSELECT,
                approveRotationalMeetingData: undefinedData,
                paginationCurrentPage: 0,
                searchKey: '',
                rotationalMeetingActionData:undefinedData
            }
            break;
        case types.SET_SEARCH_APPROVE_ROTATIONALMEETINGS_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.GET_APPROVE_ROTATIONALMEETINGS_DATA_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    approveRotationalMeetingData: action.payload
                }
            break;
        case types.SET_APPROVE_ROTATIONALMEETINGS_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.SET_APPROVE_ROTATIONALMEETINGS_STATUS_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    approveRotationalMeetingData: action.payload,
                    actionType: EOprationalActions.UNSELECT,

                }
            break;
        case types.ISEDIT_APPROVE_ROTATIONALMEETINGS_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    actionData: action.payload
                }
            break;
        case types.SET_APPROVE_ROTATIONALMEETINGS_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
                searchKey: ''
            }
            if (action.payload.rotationalMeetingActionData) {
                state = {
                    ...state,
                    rotationalMeetingActionData: action.payload.rotationalMeetingActionData
                }
            }
            break;

        default: state = { ...state }
    }
    return state;
}

export default approveRotationalMeetingsReducer;