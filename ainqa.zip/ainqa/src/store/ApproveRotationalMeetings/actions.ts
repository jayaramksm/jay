import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from '../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingApproveRotationalMeetingsRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_APPROVE_ROTATIONALMEETINGS_REQUEST
    }
}

export const resetAllApproveRotationalMeetingsStateRequest = () => {
    return {
        type: types.RESET_ALL_APPROVE_ROTATIONALMEETINGS_STATE_REQUEST
    }
}

export const getApproveRotationalMeetingsDataRequest = () => {
    return {
        type: types.GET_APPROVE_ROTATIONALMEETINGS_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true,
    }
}

export const getApproveRotationalMeetingsDataResponce = (approveGlasData, alertMessageData) => {
    return {
        type: types.GET_APPROVE_ROTATIONALMEETINGS_DATA_RESPONCE,
        payload: approveGlasData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData

    }
}

export const setSearchApproveRotationalMeetingsData = (value) => {
    return {
        type: types.SET_SEARCH_APPROVE_ROTATIONALMEETINGS_DATA,
        payload: value
    }
}

export const setApproveRotationalMeetingsActionTypeData = (actionType, actionData, rotationalMeetingActionData) => {
    return {
        type: types.SET_APPROVE_ROTATIONALMEETINGS_ACTIONTYPE_DATA,
        payload: { actionType, actionData, rotationalMeetingActionData }
    }
}



export const setApproveRotationalMeetingsStatusRequest = (requestData, requestType, confirmType, confirmMessage) => {
    return {
        type: types.SET_APPROVE_ROTATIONALMEETINGS_SATUS_REQUEST,
        payload: { requestData, requestType, confirmType, confirmMessage },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const setApproveRotationalMeetingsSatusResponse = (approveGlasData, alertMessageData) => {
    return {
        type: types.SET_APPROVE_ROTATIONALMEETINGS_STATUS_RESPONSE,
        payload: approveGlasData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}


export const setApproveRotationalMeetingsPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_APPROVE_ROTATIONALMEETINGS_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}


export const isEditApproveRotationalMeetingsRequest = (glaId, isEdit) => {
    return {
        type: types.ISEDIT_APPROVE_ROTATIONALMEETINGS_REQUEST,
        payload: { glaId, isEdit },
    }
};


export const isEditApproveRotationalMeetingsResponce = (approveGlasData, alertMessageData) => {
    return {
        type: types.ISEDIT_APPROVE_ROTATIONALMEETINGS_RESPONCE,
        payload: approveGlasData,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}