import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, EOprationalActions, ERoleDesc, IAlertMessagedata, IUserDetails } from '../../models/utilitiesModel';
import * as actions from './actions';
import * as _ from 'lodash';
import { IRla } from '../../models/approveRlaModel';


function* getOnlyapproveRlasData(tranId) {
    console.log(`${tranId}_getOnlyapproveRlasData_start =>`);
    let approveRlasData: IRla[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        let approveGlasComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.ROTATIONAL_SUPERVISOR, 'getAllRlasByRotationSupervisors');
        console.log(tranId + '_getOnlyapproveRlasData_Api_Request =>', approveGlasComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, approveGlasComponentAndMethod, null, 'rlas');
        console.log(tranId + '_getOnlyapproveRlasData_Api_Response =>', response);

        if (response) {
            approveRlasData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ARL1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ApproveRla.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ARL1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getOnlyapproveRlasData_error => `, error.messages ? error.messages : 'ARL2');
        console.log(`${tranId}_getOnlyapproveRlasData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ARL2',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'ARL2'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveRla.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        }
    }
    console.log(`${tranId}_getOnlyapproveRlasData_end =>`, approveRlasData, alertMessageData);

    return { approveRlasData, alertMessageData }
}

function* getapproveRlasData() {
    let tranId = gettranId(EAPPModules.APPROVERLASMODULE);

    console.log(`${tranId}_get_getapproveRlasData_start =>`);
    let approveRlasData: IRla[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {

        let approveRlasDataresponse = yield call(getOnlyapproveRlasData, tranId);
        alertMessageData = approveRlasDataresponse?.alertMessageData
        if (!alertMessageData) {
            approveRlasData = approveRlasDataresponse?.approveRlasData;
        }

    }
    catch (error) {
        console.log(`${tranId}_getapproveRlasData_error => `, error.messages ? error.messages : 'ARL2');
        console.log(`${tranId}_getapproveRlasData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ARL2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveRla.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ARL2'),
        }
    }
    console.log(`${tranId}_getapproveRlasData_end =>`, approveRlasData, alertMessageData);
    yield put(actions.getApproveRlasDataResponce(approveRlasData, alertMessageData));
}


function* setApproveRlasSatus(action) {

    let tranId = gettranId(EAPPModules.APPROVERLASMODULE);
    console.log(`${tranId}_setApproveRlasSatus_start =>`, action, action.payload.requestData);
    let approveRlasData: IRla[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    let rlaActionData: IRla = action.payload.rlaActionData;

    const { approvalStatus, remarks, signature } = action.payload
    const methode = (userDto?.userId === rlaActionData.firstRotationalSupervisor?.supervisorId) ? 'updateRlaFirstRsStatus' : 'updateRlaSecondRsStatus';

    try {
        let statusObject: any = (userDto?.userId === rlaActionData.firstRotationalSupervisor?.supervisorId) ? {
            "rsName": rlaActionData?.firstRotationalSupervisor?.supervisorName || '',
            "comments": (typeof remarks) === 'string' ? remarks : remarks?.value,
            "supervisor": rlaActionData?.firstRotationalSupervisor?.supervisorId || '',
            "signature": signature ? 'true' : 'false',
            "status": approvalStatus?.value || '',
            "rlaId": rlaActionData?.rlaId || 0,
            "rotationName": rlaActionData?.rotationName || '',
            "stage": rlaActionData?.stage || '',
            "stageName": rlaActionData?.stageName || '',
            "submitDate": rlaActionData?.createdOn || '',
            "traineeId": rlaActionData?.traineeId || '',
            "traineeMailId": rlaActionData?.traineeMailId || '',
            "traineeName": rlaActionData?.traineeName || '',
            "traineeUserId": rlaActionData?.userId || '',
            "spRotationId": rlaActionData?.spRotationId

        } :
            {
                "rlaId": rlaActionData?.rlaId || '',
                "rotationName": rlaActionData?.rotationName || '',
                "rsName": rlaActionData?.secondRotationSupervisor?.supervisorName || '',
                "comments": (typeof remarks) === 'string' ? remarks : remarks?.value,
                "supervisor": rlaActionData?.secondRotationSupervisor?.supervisorId || '',
                "signature": signature ? 'true' : 'false',
                "status": approvalStatus?.value || '',
                "stage": rlaActionData?.stage || '',
                "submitDate": rlaActionData?.createdOn || '',
                "traineeId": rlaActionData?.traineeId || '',
                "traineeMailId": rlaActionData?.traineeMailId || '',
                "traineeName": rlaActionData?.traineeName || '',
                "traineeUserId": rlaActionData?.userId || '',
                "spRotationId": rlaActionData?.spRotationId


            }
        console.log(`${tranId}_setApproveRlasSatus_stringify =>`, { statusObject, stringify: JSON.stringify(statusObject) });

        let glaCreateComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.ROTATIONAL_SUPERVISOR, methode);
        console.log(`${tranId}_setApproveRlasSatus_Api_Request =>`, glaCreateComponentAndMethod, statusObject);
        let response = yield call(serviceConsumer, tranId, glaCreateComponentAndMethod, statusObject, null)
        console.log(`${tranId}_setApproveRlasSatus_Api_Response`, response);
        if (response.status) {
            let approveRlasDataresponse = yield call(getOnlyapproveRlasData, tranId);
            alertMessageData = approveRlasDataresponse?.alertMessageData

            if (!alertMessageData) {
                approveRlasData = approveRlasDataresponse?.approveRlasData;
            }
            if (!approveRlasDataresponse.alertMessageData)
                alertMessageData = {
                    message: response.messages ? response.messages : 'ARL3',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'ApproveRla.alertMessages.',
                    messageCode: response.messages ? undefined : getMessageCode(tranId, 'ARL3')
                }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ARL4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ApproveRla.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ARL4')
            }
        }
    } catch (error) {
        console.log(`${tranId}_setApproveRlasSatus_error => `, error.messages ? error.messages : 'ARL5');
        console.log(`${tranId}_setApproveRlasSatus_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ARL5',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveRla.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ARL5'),

        }
    }
    console.log(`${tranId}_setApproveRlasSatus_End`, approveRlasData, alertMessageData);
    yield put(actions.setApproveRlaSatusResponse(approveRlasData, alertMessageData));
}

function* isEditApproveRlasData(action) {
    let tranId = gettranId(EAPPModules.GLASMODULE);
    let approveGlasData: IRla[] | undefined;
    let approveGlasActionData: IRla | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    console.log(`${tranId}_isEditGlasData_start =>`);
    const requestData = action.payload;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    const component = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? EAPIComponentNames.MOH_SUPERVISOR : EAPIComponentNames.EDUCATIONAL_SUPERVISOR
    const methode = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? 'updateMohStatusForGla' : 'updateEsStatusForGla'
    try {
        let createobject: any = {
            glaId: requestData.glaId,
            status: requestData.isEdit
        }
        let isEditApproveGlaComponentAndMethod = getApiServiceUrlByComponentAndMethod(component, methode);
        console.log(tranId + '_isEditGlasData_Request =>', createobject, isEditApproveGlaComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, isEditApproveGlaComponentAndMethod, createobject, null);
        console.log(tranId + '_isEditGlasData_Response =>', response);

        if (response.status) {
            console.log(tranId + '_isEditGlasData_if=>', response);
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'AGL6',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveGla.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'AGL6')

            }
        }
        let approveGlasDataresponse = yield call(getOnlyapproveRlasData, tranId);
        alertMessageData = approveGlasDataresponse?.alertMessageData
        if (!alertMessageData) {
            approveGlasData = approveGlasDataresponse?.approveGlasData;
        }
        const actionData: IRla = (yield select())['approveGlasReducer']?.actionData;
        // if (actionData) {
        //     let glaActionData = approveGlasData?.find(x => x.glaId === actionData?.glaId);
        //     if (!_.isEqual(glaActionData, actionData))
        //         approveGlasActionData = glaActionData;
        //     console.log(`${tranId}_isEditApproveGla_getGlas_And_set_ActionData_responce =>`, { approveGlasData, approveGlasActionData, actionData, glaActionData, isEqual: !_.isEqual(glaActionData, actionData) });
        // }

    } catch (error) {
        console.log(`${tranId}_isEditGlasData_error => `, error.messages ? error.messages : 'AGL6');
        console.log(`${tranId}_isEditGlasData_catch=>`, error);

    }
    console.log(`${tranId}_isEditGlasData_end =>`, approveGlasActionData, alertMessageData);
    yield put(actions.isEditApproveRlaResponce(approveGlasActionData, alertMessageData));

}



export function* watchapproveRlas() {
    yield takeLeading(types.SET_APPROVERLAS_SATUS_REQUEST, setApproveRlasSatus);
    yield takeLeading(types.ISEDIT_APPROVERLAS_REQUEST, isEditApproveRlasData);
    while (true) {
        const main = yield takeLeading(types.GET_APPROVERLAS_DATA_REQUEST, getapproveRlasData)
        yield take(types.CANCEL_ALL_PENDING_APPROVERLAS_REQUEST);
        yield cancel(main);
    }
}

function* approveRlasSaga() {
    yield all([fork(watchapproveRlas)]);
}

export default approveRlasSaga;