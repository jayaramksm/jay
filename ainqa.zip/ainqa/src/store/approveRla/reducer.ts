import { EOprationalActions } from '../../models/utilitiesModel';
import * as types from './actionTypes';
import { IApproveRlasMOdel } from '../../models/approveRlaModel';

const initialState = {} as IApproveRlasMOdel

const approveRlasReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.RESET_ALL_APPROVERLAS_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefinedData,
                actionType: EOprationalActions.UNSELECT,
                approveRlasData: undefinedData,
                paginationCurrentPage: 0,
                rlaActionData: undefinedData,
                searchKey: ''
            }
            break;
        case types.GET_APPROVERLAS_DATA_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    approveRlasData: action.payload
                }
            break;
        case types.SET_APPROVERLAS_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.SET_SEARCH_APPROVERLAS_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.SET_APPROVERLAS_STATUS_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    approveRlasData: action.payload,
                    actionType: EOprationalActions.UNSELECT,
                }
            break;
        case types.ISEDIT_APPROVERLAS_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    actionData: action.payload
                }
            break;
        case types.SET_APPROVERLAS_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
            }
            if (action.payload.rlaActionData) {
                state = {
                    ...state,
                    rlaActionData: action.payload.rlaActionData
                }
            }
            break;
        default: state = { ...state }
    }
    return state;
}

export default approveRlasReducer;