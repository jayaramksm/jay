import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingApproveRlasRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_APPROVERLAS_REQUEST
    }
}

export const resetAllApproveRlasStateRequest = () => {
    return {
        type: types.RESET_ALL_APPROVERLAS_STATE_REQUEST
    }
}

export const getApproveRlasDataRequest = () => {
    return {
        type: types.GET_APPROVERLAS_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true,
    }
}

export const getApproveRlasDataResponce = (approvePlasData, alertMessageData) => {
    return {
        type: types.GET_APPROVERLAS_DATA_RESPONCE,
        payload: approvePlasData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

export const setSearchApproveRlasData = (value) => {
    return {
        type: types.SET_SEARCH_APPROVERLAS_DATA,
        payload: value
    }
}

export const setApproveRlasActionTypeData = (actionType, actionData, rlaActionData) => {
    return {
        type: types.SET_APPROVERLAS_ACTIONTYPE_DATA,
        payload: { actionType, actionData, rlaActionData }
    }
}

export const setApproveRlasStatusRequest = (requestData) => {
    return {
        type: types.SET_APPROVERLAS_SATUS_REQUEST,
        payload: requestData,
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const setApproveRlaSatusResponse = (approveRlasData, alertMessageData) => {
    return {
        type: types.SET_APPROVERLAS_STATUS_RESPONSE,
        payload: approveRlasData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}


export const setApproveRlasPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_APPROVERLAS_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}


export const isEditApproveRlaRequest = (glaId, isEdit) => {
    return {
        type: types.ISEDIT_APPROVERLAS_REQUEST,
        payload: { glaId, isEdit },
    }
};


export const isEditApproveRlaResponce = (approvePlasData, alertMessageData) => {
    return {
        type: types.ISEDIT_APPROVERLAS_RESPONCE,
        payload: approvePlasData,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}