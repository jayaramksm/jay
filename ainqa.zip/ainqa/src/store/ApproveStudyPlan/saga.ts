import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../helpers/helpersIndex';
import { EAPPModules, IAlertMessagedata, EAPIComponentNames } from '../../models/utilitiesModel';
import * as actions from './actions';
import * as _ from 'lodash';
import { EStatusType, IApproveStudyPlanModel, IStudyPlan } from '../../models/approveStudyPlanModel';

function* getOnlyApproveStudyPlanData(tranId) {
    console.log(`${tranId}_getOnlyasdsData_start =>`);
    let studyPlanData: IStudyPlan[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        let asdsComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EDUCATIONAL_SUPERVISOR, 'getAllSpByEsId');
        console.log(tranId + '_getApproveStudyPlan_Api_Request =>', asdsComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, asdsComponentAndMethod, null, 'studyPlans');
        console.log(tranId + '_getApproveStudyPlan_Api_Response =>', response);

        if (response) {
            studyPlanData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ASP1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveStudyPlan.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ASP1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getAllApproveStudyPlanData_error => `, error.messages ? error.messages : 'ASP2');
        console.log(`${tranId}_getAllasdsData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASP2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'approveStudyPlan.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ASP2')
        }
    }
    console.log(`${tranId}_getOnlyApproveStudyPlanData_end =>`, studyPlanData, alertMessageData);
    return { studyPlanData, alertMessageData }
}

function* getApproveStudyPlanAndcurrentDateAndTimeData(action) {
    let tranId = gettranId(EAPPModules.APPROVESTUDYPLAN);

    console.log(`${tranId}_get_getApproveStudyPlanAndcurrentDateAndTimeData_start =>`, action);
    let studyPlanData: IStudyPlan[] | undefined;
    let currentDateAndTime: any | undefined
    let alertMessageData: IAlertMessagedata | undefined;
    try {

        let approveStudyPlanData = yield call(getOnlyApproveStudyPlanData, tranId);
        alertMessageData = approveStudyPlanData?.alertMessageData
        if (!alertMessageData) {
            studyPlanData = approveStudyPlanData?.studyPlanData;
        }

        let currentDataAndTimeMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.AUTH, 'getCurrentDate')
        console.log(tranId + '_getApproveStudyPlanAndcurrentDateAndTimeData_Api_Request =>', currentDataAndTimeMethod);
        const response = yield call(serviceConsumer, tranId, currentDataAndTimeMethod, null, null);
        console.log(tranId + '_getApproveStudyPlanAndcurrentDateAndTimeData_Api_Response =>', response);

        if (response) {
            currentDateAndTime = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ASP1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveStudyPlan.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ASP1')
            }
        }

    }
    catch (error) {
        console.log(`${tranId}_getApproveStudyPlanAndcurrentDateAndTimeData_error => `, error.messages ? error.messages : 'ASP2');
        console.log(`${tranId}_getApproveStudyPlanAndcurrentDateAndTimeData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASP2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'approveStudyPlan.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ASP2')
        }
    }
    console.log(`${tranId}_getApproveStudyPlanAndcurrentDateAndTimeData_end =>`, studyPlanData, currentDateAndTime, alertMessageData);

    yield put(actions.getApproveStudyplanDataResponce(studyPlanData, currentDateAndTime, alertMessageData));

}

function* updateStatusApproveStudyPlan(action) {
    let tranId = gettranId(EAPPModules.APPROVESTUDYPLAN);
    console.log(`${tranId}_updateStatusApproveStudyPlant =>`, action, action.payload.requestData);
    let studyPlanData: IStudyPlan[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const requestData = action.payload.requestData
    let actionData = ((yield select())['approveStudyPlanReducer'] as IApproveStudyPlanModel).actionData
    try {
        let createobject: any = {
            "apporvalComments": requestData?.comments,
            "apporvalStatus": requestData?.approvelStatus?.value,
            "studyPlanId": actionData?.studyPlanId,
            "traineeId": actionData?.traineeId
        }

        let updateStatusasdComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EDUCATIONAL_SUPERVISOR, 'updateStudyPlanStatus');
        console.log(`${tranId}_updateStatusApproveStudyPlan_Api_Request =>`, updateStatusasdComponentAndMethod, createobject);
        let response = yield call(serviceConsumer, tranId, updateStatusasdComponentAndMethod, createobject, null)
        console.log(`${tranId}_updateStatusApproveStudyPlan_Api_Response`, response);
        if (response.status) {
            let approveStudyPlanData = yield call(getOnlyApproveStudyPlanData, tranId);
            alertMessageData = approveStudyPlanData?.alertMessageData

            if (!alertMessageData) {
                studyPlanData = approveStudyPlanData?.studyPlanData;
            }
            if (!approveStudyPlanData.alertMessageData)
                alertMessageData = {
                    message: response.messages ? response.messages : 'ASP3',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'approveStudyPlan.alertMessages.',
                    messageCode: response.messages ? undefined : getMessageCode(tranId, 'ASP3')
                }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ASP4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveStudyPlan.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ASP4')
            }
        }
    } catch (error) {
        console.log(`${tranId}_updateStatusasds_error => `, error.messages ? error.messages : 'ASP5');
        console.log(`${tranId}_updateStatusasds_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASP5',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveStudyPlan.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ASP5')
        }
    }

    console.log(`${tranId}_updateStatusApproveStudyPlan_End`, studyPlanData, alertMessageData);
    yield put(actions.setApproveStudyplanApproveResponse(studyPlanData, alertMessageData));
}



function* updateStatusApproveStudyPlanStageOrRotation(action) {
    let tranId = gettranId(EAPPModules.APPROVESTUDYPLAN);
    console.log(`${tranId}_updateStatusApproveStudyPlanStageOrRotation =>`, action, action.payload.requestData);
    let studyPlanData: IStudyPlan[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const requestData = action.payload.requestData;
    const methode = action.payload.requestType === EStatusType.STAGE ? 'updateStageStatus' : 'updateRotationStatus'
    try {
        let createobject: any = {
            spRotationId: requestData?.spRotationId,
            status: requestData?.status,
            comments: requestData?.comments,
            rotationId: requestData?.rotationId,
            traineeId: requestData?.traineeId,
            traineeUserId: requestData?.traineeUserId
        }

        let updateStatusasdComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EDUCATIONAL_SUPERVISOR, methode);
        console.log(`${tranId}_updateStatusApproveStudyPlanStageOrRotation =>`, updateStatusasdComponentAndMethod, createobject);
        let response = yield call(serviceConsumer, tranId, updateStatusasdComponentAndMethod, createobject, null)
        console.log(`${tranId}_updateStatusApproveStudyPlan_Api_Response`, response);
        if (response.status) {
            let approveStudyPlanData = yield call(getOnlyApproveStudyPlanData, tranId);
            alertMessageData = approveStudyPlanData?.alertMessageData

            if (!alertMessageData) {
                studyPlanData = approveStudyPlanData?.studyPlanData;
            }
            if (!approveStudyPlanData.alertMessageData)
                alertMessageData = {
                    message: response.messages ? response.messages : 'ASP3',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'approveStudyPlan.alertMessages.',
                    messageCode: response.messages ? undefined : getMessageCode(tranId, 'ASP3')
                }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'ASP4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveStudyPlan.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'ASP4')
            }
        }
    } catch (error) {
        console.log(`${tranId}_updateStatusApproveStudyPlanStageOrRotation_error => `, error.messages ? error.messages : 'ASP5');
        console.log(`${tranId}_updateStatusApproveStudyPlanStageOrRotation_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'ASP5',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApproveStudyPlan.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'ASP5')
        }
    }

    console.log(`${tranId}_updateStatusApproveStudyPlanStageOrRotation_End`, studyPlanData, alertMessageData);
    yield put(actions.setApproveStudyplanApproveResponse(studyPlanData, alertMessageData));
}


export function* watchApprovestudyplan() {
    yield takeLeading(types.SET_APPROVESTYDYPLAN_APPROVE_REQUEST, updateStatusApproveStudyPlan);
    yield takeLeading(types.UPDATE_STUDYPLAN_STAGES_OR__ROTATIONS_STATUS_REQUEST, updateStatusApproveStudyPlanStageOrRotation);
    while (true) {
        const main = yield takeLeading(types.GET_APPROVESTYDYPLAN_DATA_REQUEST, getApproveStudyPlanAndcurrentDateAndTimeData)
        yield take(types.CANCEL_ALL_PENDING_APPROVESTYDYPLAN_REQUEST);
        yield cancel(main);
    }
}

function* approveStudyPlanSaga() {
    yield all([fork(watchApprovestudyplan)]);
}

export default approveStudyPlanSaga;