import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingApproveStudyPlanRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_APPROVESTYDYPLAN_REQUEST
    }
}

export const resetAllApproveStudyplanStateRequest = () => {
    return {
        type: types.RESET_ALL_APPROVESTYDYPLAN_STATE_REQUEST
    }
}

export const setApproveStudyPlanRotationActionTypeData = (actionType, rotationData) => ({
    type: types.SET_APPROVESTYDYPLAN_ROTATION_ACTIONTYPE_DATA,
    payload: { actionType, rotationData }
})

export const getApproveStudyplanDataRequest = () => {
    return {
        type: types.GET_APPROVESTYDYPLAN_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true,
    }
}

export const getApproveStudyplanDataResponce = (studyPlanData,currentDateAndTime, alertMessageData) => {
    return {
        type: types.GET_APPROVESTYDYPLAN_DATA_RESPONCE,
        payload: {studyPlanData,currentDateAndTime},
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData

    }
}

export const setSearchApproveStudyplanData = (value) => {
    return {
        type: types.SET_SEARCH_APPROVESTYDYPLAN_DATA,
        payload: value
    }
}

export const setApproveStudyplanActionTypeData = (actionType, actionData) => {
    return {
        type: types.SET_APPROVESTYDYPLAN_ACTIONTYPE_DATA,
        payload: { actionType, actionData }
    }
}

export const setApproveStudyplanApproveRequest = (requestData, requestType) => {
    return {
        type: types.SET_APPROVESTYDYPLAN_APPROVE_REQUEST,
        payload: { requestData, requestType },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}


export const setApproveStudyplanApproveResponse = (studyPlanData, alertMessageData) => {
    return {
        type: types.SET_APPROVESTYDYPLAN_APPROVE_RESPONCE,
        payload: studyPlanData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

export const setApproveStudyplansPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_APPROVESTYDYPLAN_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}


export const studyPlanStagesOrRotationsStatusModelRequest = (isModelOpen) => ({
    type: types.STUDYPLAN_STAGES_OR_ROTATIONS_STATUS_MODEL,
    payload: isModelOpen
});



export const setApproveStudyplanStageOrRotationApproveRequest = (requestData, requestType) => {
    return {
        type: types.UPDATE_STUDYPLAN_STAGES_OR__ROTATIONS_STATUS_REQUEST,
        payload: { requestData, requestType },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}


export const setApproveStudyplanStageOrRotationApproveResponse = (studyPlanData, alertMessageData) => {
    return {
        type: types.UPDATE_STUDYPLAN_STAGES_OR__ROTATIONS_STATUS_RESPONSE,
        payload: studyPlanData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}


