import { EOprationalActions } from '../../models/utilitiesModel';
import * as types from './actionTypes';
import { IApproveStudyPlanModel } from '../../models/approveStudyPlanModel';

const initialState = {} as IApproveStudyPlanModel

const approveStudyPlanReducer = (state = initialState, action) => {
    let undefined;
    switch (action.type) {
        case types.RESET_ALL_APPROVESTYDYPLAN_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefined,
                actionType: EOprationalActions.UNSELECT,
                studyPlanData: undefined,
                paginationCurrentPage: 0,
                searchKey: '',
                rotationActionData: undefined,
                modelData: undefined
            }
            break;
        case types.GET_APPROVESTYDYPLAN_DATA_RESPONCE:
            if (action.payload.studyPlanData)
                state = {
                    ...state,
                    studyPlanData: action.payload.studyPlanData,
                    currentDateAndTime :action.payload.currentDateAndTime

                }
            break;
        case types.SET_APPROVESTYDYPLAN_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.SET_APPROVESTYDYPLAN_APPROVE_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    studyPlanData: action.payload,
                    actionType: EOprationalActions.UNSELECT

                }
            break;
        case types.SET_SEARCH_APPROVESTYDYPLAN_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;


        case types.SET_APPROVESTYDYPLAN_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
                rotationActionData: undefined
            }
            break;

        case types.SET_APPROVESTYDYPLAN_ROTATION_ACTIONTYPE_DATA:
            state = {
                ...state,
                rotationActionData: action.payload.rotationData,
                actionType: action.payload.actionType
            }
            break;
        case types.STUDYPLAN_STAGES_OR_ROTATIONS_STATUS_MODEL:
            state = {
                ...state,
                modelData: action.payload
            }
            break;
            case types.UPDATE_STUDYPLAN_STAGES_OR__ROTATIONS_STATUS_RESPONSE:
                if (action.payload)
                    state = {
                        ...state,
                        studyPlanData: action.payload
                    }
                break;
        default: state = { ...state }
    }
    return state;
}

export default approveStudyPlanReducer;