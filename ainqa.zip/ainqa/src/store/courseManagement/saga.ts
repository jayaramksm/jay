import { takeLeading, put, all, fork, call, select, take, cancel } from 'redux-saga/effects';
import * as types from './actionTypes';
import * as actions from './actions';
import { getApiServiceUrlByComponentAndMethod, serviceConsumer, getMessageCode, gettranId, serviceConsumerWithMultiCalls } from '../../helpers/helpersIndex';
import { EAPPModules, EOprationalActions, IAlertMessagedata, ISessionstate, EAPIComponentNames } from '../../models/utilitiesModel';
import { ICourseManagement, IDenominations, IRotations } from '../../models/courseManagementModel';

function* getOnlyRotationsInfo(tranId, programId) {

    console.log(`_${tranId}_getOnlyRotationsInfo_start===>`, tranId);

    let rotations: IRotations[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.COURSE_MANAGEMENT, 'getAllRotations');
        componentAndMethod.url = componentAndMethod.url.replace('{programid}', programId);
        console.log(`_${tranId}_getOnlyRotationsInfo_Api_request===>`, componentAndMethod);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, null, 'rotations');
        console.log(`_${tranId}_getOnlyRotationsInfo_Api_Response===>`, response);
        if (response) {
            rotations = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'CMM1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'CourseManagement.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'CMM1')
            }
        }
    } catch (error) {
        console.error(`${tranId}_getOnlyRotationsInfo_error => `, error.messages ? error.messages : 'CMM2');
        console.log(`${tranId}_getOnlyRotationsInfo_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'CMM2',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'CMM2'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'CourseManagement.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`_${tranId}_getOnlyRotationsInfo_Api_End===>`, rotations, alertMessageData);
    // yield put(actions.getAllRotationsDetailsResponse(totalRotations, alertMessageData));
    return { rotations, alertMessageData }
}


function* getAllRotationsAndPhaseDinaminationsDetailsRequest() {

    let tranId = gettranId(EAPPModules.COURSEMANAGEMENTMODULE);
    console.log(`_${tranId}_getAllRotationsAndPhaseDinaminationsDetailsRequest_start===>`,);

    let totalRotations: IRotations[] | undefined;
    let phaseDenominations: IDenominations[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let program = ((yield select())['SessionState'] as ISessionstate).userDto.program;

    try {
        let allRotationscomponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.COURSE_MANAGEMENT, 'getAllRotations');
        let phaseDenominationcomponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'getPhaseDenominationsByProgamId');

        allRotationscomponentAndMethod.url = allRotationscomponentAndMethod.url.replace('{programid}', program?.programId);
        phaseDenominationcomponentAndMethod.url = phaseDenominationcomponentAndMethod.url.replace('{programid}', program?.programId);

        const multicallMethods = [allRotationscomponentAndMethod, phaseDenominationcomponentAndMethod];
        const multicallbody = [null, null];

        console.log(`_${tranId}_getAllRotationsAndPhaseDinaminationsDetailsRequest_Api_request===>`, multicallMethods, multicallbody);
        let response = yield call(serviceConsumerWithMultiCalls, tranId, multicallMethods, multicallbody);
        console.log(`_${tranId}_getAllRotationsAndPhaseDinaminationsDetailsRequest_Api_Response===>`, response);
        if (response.length > 0) {
            if (response[0] && response[0].status === 200)
                totalRotations = response[0]?.data['rotations'] || [];
            else {
                alertMessageData = {
                    message: response[0].messages ? response[0].messages : 'CMM1',
                    status: false,
                    tranId: Date.now(),
                    transKey: response[0].messages ? '' : 'CourseManagement.alertMessages.',
                    messageCode: response[0].messages ? tranId : getMessageCode(tranId, 'CMM1')
                }
            }
            if (response[1] && response[1].status === 200)
                phaseDenominations = response[1]?.data['programDenomations'] || [];
            else {
                alertMessageData = {
                    message: response[1].messages ? response[1].messages : 'CMM10',
                    status: false,
                    tranId: Date.now(),
                    transKey: response[1].messages ? '' : 'CourseManagement.alertMessages.',
                    messageCode: response[1].messages ? tranId : getMessageCode(tranId, 'CMM10')
                }
            }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'CMM11',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'CourseManagement.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'CMM11')
            }
        }
    } catch (error) {
        console.error(`${tranId}_getAllRotationsAndPhaseDinaminationsDetailsRequest_error => `, error.messages ? error.messages : 'CMM2');
        console.log(`${tranId}_getAllRotationsAndPhaseDinaminationsDetailsRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'CMM12',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'CMM12'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'CourseManagement.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`_${tranId}_getAllRotationsAndPhaseDinaminationsDetailsRequest_Api_End===>`, totalRotations, phaseDenominations, alertMessageData);
    yield put(actions.getAllRotationsAndPhaseDenominationsDetailsResponse(totalRotations, phaseDenominations, alertMessageData));
}

// function* getDeleteRotationInfo(action) {

//     let tranId = gettranId(EAPPModules.COURSEMANAGEMENTMODULE);
//     console.log(`_${tranId}_getDeleteRotationInfo_start===>`, action);

//     let totoalRotations: any | undefined;
//     let alertMessageData: IAlertMessagedata | undefined;
//     let { rotationId, requestType, confirmMessage } = action.payload;

//     if (requestType) {
//         try {
//             let componentAndMethod = getApiServiceUrlByComponentAndMethod(component, 'deleteRotations');
//             componentAndMethod.url = componentAndMethod.url.replace('{id}', rotationId);
//             console.log(`_${tranId}_getDeleteRotationInfo_Api_request===>`, componentAndMethod);
//             let response = yield call(serviceConsumer, tranId, componentAndMethod, null, null);
//             console.log(`_${tranId}_getDeleteRotationInfo_Api_Response===>`, response);
//             if (response) {
//                 totoalRotations = ((yield select())['courseManagementReducer'] as ICourseManagement).totalRotations;
//                 let ind = totoalRotations?.findIndex(x => x.id === rotationId);
//                 if (ind !== -1) totoalRotations.splice(ind, 1);
//                 alertMessageData = {
//                     message: response.messages ? response.messages : "Rotation deleted Successfully",
//                     status: true,
//                     tranId: Date.now(),
//                     transKey: response.messages ? '' : 'Departments.alertMessages.',
//                     messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM3')
//                 }
//             }
//             else {
//                 alertMessageData = {
//                     message: response.messages ? response.messages : 'DAM4',
//                     status: false,
//                     tranId: Date.now(),
//                     transKey: response.messages ? '' : 'Departments.alertMessages.',
//                     messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM4')
//                 }

//             }

//         } catch (error) {
//             console.error(`${tranId}_getDeleteRotationInfo_error => `, error.messages ? error.messages : 'DAM5');
//             console.log(`${tranId}_getDeleteRotationInfo_catch => `, error);
//             alertMessageData = {
//                 message: error.messages ? error.messages : 'DAM5',
//                 status: false, tranId: Date.now(),
//                 messageCode: getMessageCode(tranId, 'DAM5'),
//                 transKey: error.messages ? '' : 'Departments.alertMessages.',
//                 statusCode: error.statuscode ? error.statuscode : 0
//             };
//         }
//         console.log(`_${tranId}_getDeleteRotationInfo_Api_End===>`, totoalRotations, alertMessageData);
//         yield put(actions.getDeleteRotationsInCourseManagementResponse(totoalRotations, alertMessageData));
//     } else {
//         let optionsData = [
//             {
//                 title: 'Yes',
//                 function: actions.getDeleteRotationsInCourseManagementRequest(rotationId, true, confirmMessage),
//                 loading: 1,
//                 className: 'btn-primary'
//             },
//             {
//                 title: 'No',
//                 loading: 0,
//                 className: 'btn-danger'
//             }
//         ] as IConfirmOptions[];

//         let confirmModel = {
//             title: action.payload.confirmMessage,
//             options: optionsData,
//             transKey: ''
//         } as IConfirmModel;

//         console.log(`${tranId}_setActionRequest_2=> `, action, confirmModel);
//         yield put(setConfirmationOpen(confirmModel));
//     }
// }

function* addWbaDetailsRequest(action) {
    const { wbaDetails, actionType } = action.payload;
    let wbas = ((yield select())['courseManagementReducer'] as ICourseManagement).wbaDetails ?? [];

    let totalwbaDetails = [...wbas];

    if (actionType === EOprationalActions.ADD) {
        totalwbaDetails?.push(wbaDetails);
    }
    else if (actionType === EOprationalActions.EDIT) {
        let ind = totalwbaDetails.findIndex(x => (x.wbaName?.value || x.wbaName) === (wbaDetails?.wbaName?.value || wbaDetails?.wbaName));
        if (ind !== -1) {
            totalwbaDetails.splice(ind, 1, wbaDetails);
            // totalwbaDetails = totalwbaDetails.slice();
        }
    }
    else if (actionType === EOprationalActions.DELETE) {
        let ind = totalwbaDetails.findIndex(x => (x.wbaName?.value || x.wbaName) === (wbaDetails?.wbaName?.value || wbaDetails?.wbaName));
        if (ind !== -1) totalwbaDetails.splice(ind, 1);
    }
    yield put(actions.addOrEditOrDeleteWBADetailsOfRotationsResponse(totalwbaDetails));
}

function* addOrEditRotations(action) {
    let tranId = gettranId(EAPPModules.COURSEMANAGEMENTMODULE);
    console.log(`_${tranId}_addOrEditRotations_start===>`,);

    let totalRotations: IRotations[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const { rotationDetails: rotation, requestType } = action.payload;
    let requestStatus: boolean = false;
    let courseManagementModel = ((yield select())['courseManagementReducer'] as ICourseManagement);
    let programInfo = ((yield select())['SessionState'] as ISessionstate)?.userDto?.program;
    let wbaDetails = courseManagementModel.wbaDetails || [];

    console.log('wbaDetails===>', wbaDetails);

    let createOrUpdatewbas = wbaDetails?.map(x => ({
        wbaExpected: x.wbaExpected,
        wbaName: x.wbaName?.value || x.wbaName,
        ...(() => {
            return requestType === EOprationalActions.ADD ? {} : { wbaId: x.wbaId || '' }
        })()
    }));

    if (requestType === EOprationalActions.ADD) {
        try {
            let createRotation = {
                programId: programInfo?.programId || 0,
                rotationCode: rotation?.rotationCode ?? '',
                rotationDuration: rotation?.duration?.value ?? '',
                rotationName: rotation?.rotationName ?? '',
                phaseDenominationId: rotation?.stage?.phaseDenominationId ?? '',
                wbas: createOrUpdatewbas || []
            }
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.COURSE_MANAGEMENT, 'createRotation');
            console.log(`_${tranId}_addOrEditRotations_Api_request===>`, componentAndMethod);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, createRotation, null);
            console.log(`_${tranId}_addOrEditRotations_Api_Response===>`, response);
            if (response.status) {
                requestStatus = true;
                alertMessageData = {
                    message: response.messages || 'CMM3',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'CourseManagement.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'CMM3')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'CMM5',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'CourseManagement.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'CMM5')
                }
            }
        } catch (error) {
            console.error(`${tranId}_addOrEditRotations_error => `, error.messages ? error.messages : 'CMM6');
            console.log(`${tranId}_addOrEditRotations_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'CMM6',
                status: false, tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'CMM6'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'CourseManagement.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
    } else {

        try {
            let updateRotation = {
                "programId": programInfo?.programId || '',
                "rotationCode": rotation?.rotationCode || '',
                "rotationDuration": rotation.duration?.value || '',
                "rotationId": rotation?.rotationId || '',
                "rotationName": rotation?.rotationName,
                phaseDenominationId: rotation?.stage?.phaseDenominationId ?? '',
                "wbas": [...createOrUpdatewbas],
                deletedWbaIds: rotation?.deletedWbaInfo?.filter(x => x.wbaId).map(y => y.wbaId)
            }
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.COURSE_MANAGEMENT, 'updateRotation');
            componentAndMethod.url = componentAndMethod.url.replace('{id}', rotation.id);
            console.log(`_${tranId}_addOrEditRotations_Api_request===>`, componentAndMethod);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, updateRotation, null);
            console.log(`_${tranId}_addOrEditRotations_Api_Response===>`, response);
            if (response.status) {
                requestStatus = response.status;
                totalRotations = courseManagementModel.totalRotations;
                let ind = totalRotations?.findIndex(x => x.rotationId === rotation?.rotationId);
                totalRotations.splice(ind, 1, updateRotation);

                alertMessageData = {
                    message: response.messages ? response.messages : 'CMM7',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'CourseManagement.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'CMM7')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'CMM8',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'CourseManagement.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'CMM8')
                }
            }
        } catch (error) {
            console.error(`${tranId}_addOrEditRotations_error => `, error.messages ? error.messages : 'CMM9');
            console.log(`${tranId}_addOrEditRotations_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'CMM9',
                status: false, tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'CMM9'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'CourseManagement.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
    }

    if (requestStatus) {
        let { rotations, alertMessageData: rotationalertMessageData } = yield call(getOnlyRotationsInfo, tranId, programInfo?.programId);

        totalRotations = rotations;
        if (rotationalertMessageData)
            alertMessageData = rotationalertMessageData;
    }
    console.log(`_${tranId}_addOrEditRotations_Api_End===>`, totalRotations, alertMessageData);
    yield put(actions.addOrEditRotationsInCourseManagementResponse(totalRotations, requestStatus, alertMessageData));
}

export function* watchCourseManagement() {
    yield takeLeading(types.ADD_OR_EDIT_OR_DELETE_WBA_DETAILS_OF_ROTATIONS_REQUEST, addWbaDetailsRequest);
    yield takeLeading(types.ADD_OR_EDIT_ROTATIONS_IN_COURSEMANAGEMENT_REQUEST, addOrEditRotations);
    // yield takeLeading(types.GET_DELETE_ROTATIONS_IN_COURSEMANAGEMENT_REQUEST, getDeleteRotationInfo);

    while (true) {
        const main = yield takeLeading(types.GET_ALL_ROTATIONS_AND_DENOMINATIONS_DETAILS_REQUEST, getAllRotationsAndPhaseDinaminationsDetailsRequest);
        yield take(types.CANCEL_ALL_COURSE_MANAGEMENT_API_REQUESTS);
        yield cancel(main);
    }
}


function* courseManagementSaga() {
    yield all([fork(watchCourseManagement)]);
}

export default courseManagementSaga;