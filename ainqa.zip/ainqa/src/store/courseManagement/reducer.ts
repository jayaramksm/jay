import * as types from './actionTypes';
import { ICourseManagement } from '../../models/courseManagementModel';
import { EOprationalActions } from '../../models/utilitiesModel';

const initialState = {} as ICourseManagement

const courseManagementReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.SET_RESET_COURSE_MANAGEMENT_STATE_REQUEST:
            state = {
                ...state,
                actionType: EOprationalActions.UNSELECT,
                actionData: undefinedData,
                wbaDetails: undefinedData,
                searchKey: '',
                wbaActionData: undefinedData,
                wbaActionType: EOprationalActions.ADD
            }
            break;
        case types.SET_COURSE_MANAGEMENT_ACTIONTYPE_AND_ACTIONDATA:
            state = {
                ...state,
                actionType: action.payload.actionType,
                actionData: action.payload.actionData,
                wbaDetails: action.payload.actionData?.wbas,
                wbaActionData: undefinedData,
                wbaActionType: EOprationalActions.ADD
            }
            break;
        case types.SET_WBA_ACTIONTYPE_AND_ACTIONDATA:
            state = {
                ...state,
                wbaActionData: action.payload.actionData,
                wbaActionType: action.payload.actionType,
                searchKey: ''
            }
            break;
        case types.GET_ALL_ROTATIONS_AND_DENOMINATIONS_DETAILS_RESPONSE:
            state = {
                ...state,
                totalRotations: action.payload.totalRotations,
                phaseDenominations: action.payload.denominations
            }
            break;
        case types.SET_SEARC_KEY_IN_COURSE_MANAGEMENT_ROTATIONS:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.ADD_OR_EDIT_OR_DELETE_WBA_DETAILS_OF_ROTATIONS_RESPONSE:
            state = {
                ...state,
                wbaDetails: action.payload,
                wbaActionType: EOprationalActions.ADD,
                wbaActionData: undefinedData
            }
            break;
        case types.ADD_OR_EDIT_ROTATIONS_IN_COURSEMANAGEMENT_RESPONSE:
            if (action.payload.requestStatus)
                state = {
                    ...state,
                    totalRotations: action.payload.totalRotations,
                    actionType: EOprationalActions.UNSELECT
                }
            break;
        default: state = { ...state }
    }
    return state;
}

export default courseManagementReducer;