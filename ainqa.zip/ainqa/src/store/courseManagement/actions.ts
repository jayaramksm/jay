import * as types from './actionTypes';
import { ACTION_LOADING, LAYOUT_ALERT_ACTION_REQUEST } from '../../store/layout/actionTypes';

export const setResetCourseManagementStateRequest = () => ({
    type: types.SET_RESET_COURSE_MANAGEMENT_STATE_REQUEST
});

export const cancelAllCourseManagementApiRequests = () => ({
    type: types.CANCEL_ALL_COURSE_MANAGEMENT_API_REQUESTS
});

export const setCourseManagementActionTypeAndActionData = (actionType, actionData) => ({
    type: types.SET_COURSE_MANAGEMENT_ACTIONTYPE_AND_ACTIONDATA,
    payload: { actionType, actionData }
});

export const setWbaActionTypeAndActionData = (actionType, actionData = null) => ({
    type: types.SET_WBA_ACTIONTYPE_AND_ACTIONDATA,
    payload: { actionType, actionData }
});


export const setSearchKeyInCourseManagementRotations = (searchKey) => ({
    type: types.SET_SEARC_KEY_IN_COURSE_MANAGEMENT_ROTATIONS,
    payload: searchKey
});

export const getAllRotationsAndPhaseDenominationsDetailsRequest = () => ({
    type: types.GET_ALL_ROTATIONS_AND_DENOMINATIONS_DETAILS_REQUEST,
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getAllRotationsAndPhaseDenominationsDetailsResponse = (totalRotations, denominations, alertMessageData) => ({
    type: types.GET_ALL_ROTATIONS_AND_DENOMINATIONS_DETAILS_RESPONSE,
    payload: { totalRotations, denominations },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const addOrEditOrDeleteWBADetailsOfRotationsRequest = (wbaDetails, actionType) => ({
    type: types.ADD_OR_EDIT_OR_DELETE_WBA_DETAILS_OF_ROTATIONS_REQUEST,
    payload: { wbaDetails, actionType }
});

export const addOrEditOrDeleteWBADetailsOfRotationsResponse = (wbaDetails) => ({
    type: types.ADD_OR_EDIT_OR_DELETE_WBA_DETAILS_OF_ROTATIONS_RESPONSE,
    payload: wbaDetails
});

export const addOrEditRotationsInCourseManagementRequest = (rotationDetails, requestType) => ({
    type: types.ADD_OR_EDIT_ROTATIONS_IN_COURSEMANAGEMENT_REQUEST,
    payload: { rotationDetails, requestType },
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const addOrEditRotationsInCourseManagementResponse = (totalRotations, requestStatus, alertMessageData) => ({
    type: types.ADD_OR_EDIT_ROTATIONS_IN_COURSEMANAGEMENT_RESPONSE,
    payload: { totalRotations, requestStatus },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const getDeleteRotationsInCourseManagementRequest = (rotationId, requestType, confirmMessage) => ({
    type: types.GET_DELETE_ROTATIONS_IN_COURSEMANAGEMENT_REQUEST,
    payload: { rotationId, requestType, confirmMessage },
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getDeleteRotationsInCourseManagementResponse = (allRotations, alertMessageData) => ({
    type: types.GET_DELETE_ROTATIONS_IN_COURSEMANAGEMENT_RESPONSE,
    payload: allRotations,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
})


