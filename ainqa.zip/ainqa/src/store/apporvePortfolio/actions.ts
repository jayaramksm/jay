import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingApprovePortfolioRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_APPROVE_PORTFOLIO_REQUEST
    }
}

export const resetAllApprovePortfolioStateRequest = () => {
    return {
        type: types.RESET_ALL_APPROVE_PORTFOLIO_STATE_REQUEST
    }
}

export const setApprovePortfolioActionTypeAndActionData = (actionType, actionData, portfolioActionData) => {
    return {
        type: types.SET_APPROVE_PORTFOLIO_ACTIONTYPE_ACTIONDATA,
        payload: { actionType, actionData, portfolioActionData }
    }
}

export const getAllApprovePortfolioEntriesDataRequest = () => ({
    type: types.GET_ALL_APPROVE_PORTFOLIO_ENTRIES_DATA_REQUEST,
    loadType: ACTION_LOADING,
    loadPayload: true,
});

export const getAllApprovePortfolioEntriesDataResponse = (portfoliosData, alertMessageData) => ({
    type: types.GET_ALL_APPROVE_PORTFOLIO_ENTRIES_DATA_RESPONSE,
    payload: portfoliosData,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});


export const setApprovePortfolioPaginationCurrentPageValue = (currentPage) => ({
    type: types.SET_APPROVE_PORTFOLIO_PAGINATION_CURRENT_PAGE_VALUE,
    payload: currentPage
})


export const approvrPortfolioAssessmentFormModelOpenOrClose = (data) => {
    return {
        type: types.APPROVE_PORTFOLIO_ASSESSMENT_FORM_MODEL_OPEN_OR_CLOSE,
        payload: data
    }
}



export const setSearchApprovePortfolioData = (value) => {
    return {
        type: types.SET_SEARCH_APPROVE_PORTFOLIO_DATA,
        payload: value
    }
}


export const setApprovePoarfolioPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_APPROVE_PORTFOLIO_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}


export const setapprovrPortfolioStatusRequest = (requestData) => {
    return {
        type: types.SET_APPROVE_PORTFOLIO_SATUS_REQUEST,
        payload: requestData,
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const setapprovrPortfolioResponse = (portfoliosData, alertMessageData) => {
    return {
        type: types.SET_APPROVE_PORTFOLIO_SATUS_RESPONCE,
        payload: portfoliosData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}