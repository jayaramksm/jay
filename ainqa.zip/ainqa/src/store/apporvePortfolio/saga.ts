import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer, } from '../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, IAlertMessagedata, IUserDetails } from '../../models/utilitiesModel';
import * as actions from './actions';
import { IPortfolio } from '../../models/approvePortfolioModel';


function* getOnlyPortfoliosData(tranId) {

    console.log(`${tranId}_getOnlyPortfoliosData_start =>`);
    let portfoliosData: IPortfolio[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        let portfolioDataComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.ROTATIONAL_SUPERVISOR, 'getAllPortfoliosByRotationSupervisors');

        console.log(tranId + '_getOnlyPortfoliosData_Api_Request =>', portfolioDataComponentAndMethod);
        let response = yield call(serviceConsumer, tranId, portfolioDataComponentAndMethod, '', 'portfilos');
        console.log(tranId + '_getOnlyPortfoliosData_Api_Response =>', response);
        if (response)
            portfoliosData = response;
        else {
            alertMessageData = {
                message: response[0].messages ? response[0].messages : 'APFO1',
                status: false,
                tranId: Date.now(),
                transKey: response[0].messages ? '' : 'ApprovePortfolio.alertMessages.',
                messageCode: response[0].messages ? tranId : getMessageCode(tranId, 'APFO1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getOnlyPortfoliosData_error => `, error.messages ? error.messages : 'APFO2');
        console.log(`${tranId}_getOnlyPortfoliosData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'APFO2',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'APFO2'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApprovePortfolio.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        }
    }
    console.log(`${tranId}_getOnlyPortfoliosData_end =>`, portfoliosData, alertMessageData);

    return { portfoliosData, alertMessageData }
}


function* getPortfolioEntriesDataRequest() {

    let tranId = gettranId(EAPPModules.APPROVEPORTFOLIOMODULE);
    console.log(`${tranId}_setApproveGlas_start =>`,);

    let portfoliosData: IPortfolio[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        let portfoliosDataresponse = yield call(getOnlyPortfoliosData, tranId);
        alertMessageData = portfoliosDataresponse?.alertMessageData
        portfoliosData = portfoliosDataresponse?.portfoliosData;
    } catch (error) {
        console.log(`${tranId}_getPortfolioEntriesDataRequest_error => `, error.messages ? error.messages : 'APFO2');
        console.log(`${tranId}_getPortfolioEntriesDataRequest_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'APFO2',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'APFO2'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApprovePortfolio.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        }
    }
    console.log(`${tranId}_getPortfolioEntriesDataRequest_end =>`, portfoliosData, alertMessageData);
    yield put(actions.getAllApprovePortfolioEntriesDataResponse(portfoliosData, alertMessageData))
}


function* setStatusPortfolioEntriesData(action) {

    let tranId = gettranId(EAPPModules.APPROVERLASMODULE);
    console.log(`${tranId}_setStatusPortfolioEntriesData_start =>`, action);
    let portfoliosData: IPortfolio[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    let requestData: any = action.payload;
    const methode = (userDto?.userId === requestData?.portfolioActionData?.firstRotationSupervisor?.supervisorId) ? 'updatePortFoliosFirstRsStatus' : 'updatePortFoliosSecondRsStatus';


    try {
        let statusObject: any = (userDto?.userId === requestData?.portfolioActionData?.firstRotationSupervisor?.supervisorId) ? {
            comments: requestData?.comments,
            rotationId: requestData?.portfolioActionData?.rotationId,
            isAssessed: requestData?.isPartOfAssessed,
            portfolioId: requestData?.portfolioId,
            programName: requestData?.programName || '',
            rotationName: requestData?.rotation || '',
            stageId: requestData?.portfolioActionData?.stageId || '',
            stage: requestData?.portfolioActionData?.stageName || '',
            status: requestData?.approvelStatus?.value || '',
            supervisorId: requestData?.portfolioActionData?.firstRotationSupervisor?.supervisorId || '',
            supervisorMailId: requestData?.portfolioActionData?.firstRotationSupervisor?.supervisorMailId || '',
            supervisorName: requestData?.portfolioActionData?.firstRotationSupervisor.supervisorName || '',
            traineeId: requestData?.portfolioActionData?.traineeId || '',
            traineeMailId: requestData?.portfolioActionData?.traineeMailId || '',
            traineeName: requestData?.portfolioActionData?.traineeName || '',
            userId: requestData?.userId || '',
            wbaId: requestData?.portfolioActionData?.wba

        } : {
            comments: requestData?.comments,
            rotationId: requestData?.portfolioActionData?.rotationId,
            isAssessed: requestData?.isPartOfAssessed,
            portfolioId: requestData?.portfolioId,
            programName: requestData?.programName || '',
            rotationName: requestData?.rotation || '',
            stageId: requestData?.portfolioActionData?.stageId || '',
            stage: requestData?.portfolioActionData?.stageName || '',
            status: requestData?.approvelStatus?.value || '',
            supervisorId: requestData?.portfolioActionData?.secondRotationSupervisor?.supervisorId || '',
            supervisorMailId: requestData?.portfolioActionData?.secondRotationSupervisor?.supervisorMailId || '',
            supervisorName: requestData?.portfolioActionData?.secondRotationSupervisor.supervisorName || '',
            traineeId: requestData?.portfolioActionData?.traineeId || '',
            traineeMailId: requestData?.portfolioActionData?.traineeMailId || '',
            traineeName: requestData?.portfolioActionData?.traineeName || '',
            userId: requestData?.userId || '',
            wbaId: requestData?.portfolioActionData?.wba
        }

        let StatusPortfolioComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.ROTATIONAL_SUPERVISOR, methode);
        console.log(`${tranId}_setStatusPortfolioEntriesData_Api_Request =>`, StatusPortfolioComponentAndMethod, statusObject);
        let response = yield call(serviceConsumer, tranId, StatusPortfolioComponentAndMethod, statusObject, null)
        console.log(`${tranId}_setStatusPortfolioEntriesData_Api_Response`, response);
        if (response.status) {
            let portfoliosDataresponse = yield call(getOnlyPortfoliosData, tranId);
            alertMessageData = portfoliosDataresponse?.alertMessageData
            portfoliosData = portfoliosDataresponse?.portfoliosData;

            alertMessageData = {
                message: response.messages ? response.messages : 'APFO3',
                status: true,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ApprovePortfolio.alertMessages.',
                messageCode: response.messages ? undefined : getMessageCode(tranId, 'APFO3')
            }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'APFO4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ApprovePortfolio.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'APFO4')
            }
        }
    } catch (error) {
        console.log(`${tranId}_setStatusPortfolioEntriesData_error => `, error.messages ? error.messages : 'APFO5');
        console.log(`${tranId}_setStatusPortfolioEntriesData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'APFO5',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'ApprovePortfolio.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'APFO5'),

        }
    }
    console.log(`${tranId}_setStatusPortfolioEntriesData_End`, portfoliosData, alertMessageData);
    yield put(actions.setapprovrPortfolioResponse(portfoliosData, alertMessageData));
}













export function* watchApprovePortfolio() {
    yield takeLeading(types.SET_APPROVE_PORTFOLIO_SATUS_REQUEST, setStatusPortfolioEntriesData);

    while (true) {
        const main = yield takeLeading(types.GET_ALL_APPROVE_PORTFOLIO_ENTRIES_DATA_REQUEST, getPortfolioEntriesDataRequest)
        yield take(types.CANCEL_ALL_PENDING_APPROVE_PORTFOLIO_REQUEST);
        yield cancel(main);
    }
}

function* approvePortfolioSaga() {
    yield all([fork(watchApprovePortfolio)]);
}

export default approvePortfolioSaga;