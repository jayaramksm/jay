import { EOprationalActions } from '../../models/utilitiesModel';
import * as types from './actionTypes';
import { IApprovePortfolioMOdel } from '../../models/approvePortfolioModel';

const initialState = {} as IApprovePortfolioMOdel

const approvePortfoliosReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.RESET_ALL_APPROVE_PORTFOLIO_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefinedData,
                portfoliosData: undefinedData,
                actionType: EOprationalActions.UNSELECT,
                paginationCurrentPage: 0,
                searchKey: '',
                portfolioActionData: undefinedData
            }
            break;

        case types.SET_APPROVE_PORTFOLIO_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.SET_SEARCH_APPROVE_PORTFOLIO_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.GET_ALL_APPROVE_PORTFOLIO_ENTRIES_DATA_RESPONSE:
            state = {
                ...state,
                portfoliosData: action.payload
            }
            break;
        case types.SET_APPROVE_PORTFOLIO_SATUS_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    portfoliosData: action.payload,
                    actionType: EOprationalActions.UNSELECT,

                }
            break;
        case types.APPROVE_PORTFOLIO_ASSESSMENT_FORM_MODEL_OPEN_OR_CLOSE:
            state = {
                ...state,
                assessmentModelData: action.payload
            }
            break;

        case types.SET_APPROVE_PORTFOLIO_ACTIONTYPE_ACTIONDATA:
            state = {
                ...state,
                actionType: action.payload.actionType,
                actionData: action.payload.actionData,
            }
            if (action.payload.portfolioActionData) {
                state = {
                    ...state,
                    portfolioActionData: action.payload.portfolioActionData
                }
            }
            break;
        default: state = { ...state }
    }
    return state;
}

export default approvePortfoliosReducer;