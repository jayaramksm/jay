import { IEvaluatorFeedbackFormModel } from '../../models/evaluatorFeedbackFormModel';
import { EOprationalActions } from '../../models/utilitiesModel';
import * as types from './actionTypes';

const initialState = {} as IEvaluatorFeedbackFormModel

const evaluatorFeedbackFormReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.RESET_ALL_EVALUATOR_FEEDBACK_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefinedData,
                actionType: EOprationalActions.UNSELECT,
                isModelOpen: false,
                feedbackFormData: undefinedData,
                updateFeedbackFormData: undefinedData
            }
            break;
        case types.GET_ALL_EVALUATOR_FEEDBACK_DATA_RESPONSE:
            state = {
                ...state,
                feedbackFormData: action.payload
            }
            break;
        case types.UPDATE_EVALUATOR_FEEDBACK_DATA_REQUEST:
            state = {
                ...state,
                isModelOpen: false
            }
            break;
        case types.UPDATE_EVALUATOR_FEEDBACK_DATA_RESPONSE:
            state = {
                ...state,
                updateFeedbackFormData: action.payload
            }
            break
        case types.CLOSE_EVALUATOR_FEEDBACK_FORM_MODEL:
            state = {
                ...state,
                isModelOpen: action.payload
            }
            break;
        default: state = { ...state }
    }
    return state;
}

export default evaluatorFeedbackFormReducer;