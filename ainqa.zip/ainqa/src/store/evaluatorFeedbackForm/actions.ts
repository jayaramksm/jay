import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingEvaluatorsFeedbackRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_EVALUATOR_FEEDBACK_REQUEST
    }
}

export const resetAllEvaluatorsFeedbackStateRequest = () => {
    return {
        type: types.RESET_ALL_EVALUATOR_FEEDBACK_STATE_REQUEST
    }
}

export const getAllEvaluatorFeedbackFormDataRequest = (uniqueId) => ({
    type: types.GET_ALL_EVALUATOR_FEEDBACK_DATA_REQUEST,
    payload: uniqueId,
    loadType: ACTION_LOADING,
    loadPayload: true,
})

export const getAllEvaluatorFeedbackFormDataResponse = (evaluatorFeedbackForm, alertMessageData) => ({
    type: types.GET_ALL_EVALUATOR_FEEDBACK_DATA_RESPONSE,
    payload: evaluatorFeedbackForm,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});


export const closeEvaluatorFeedbackFormModel = (data) => ({
    type: types.CLOSE_EVALUATOR_FEEDBACK_FORM_MODEL,
    payload: data
});

export const updateEvaluatorFeedbackFormDataRequest = (formData) => ({
    type: types.UPDATE_EVALUATOR_FEEDBACK_DATA_REQUEST,
    payload: formData,
    loadType: ACTION_LOADING,
    loadPayload: true,
})

export const updateEvaluatorFeedbackFormDataResponse = (evaluatorFeedbackForm, alertMessageData) => ({
    type: types.UPDATE_EVALUATOR_FEEDBACK_DATA_RESPONSE,
    payload: evaluatorFeedbackForm,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});




