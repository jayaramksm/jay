import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumerWithOutHeaders } from '../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, EOprationalActions, IAlertMessagedata, IUserDetails } from '../../models/utilitiesModel';
import * as actions from './actions';
import * as _ from 'lodash';


function* getAllEvaluatorsFeedbackDataRequest(action) {

    let tranId = gettranId(EAPPModules.EVALUATORFEEDBACKFORM);
    console.log(`${tranId}_getAllEvaluatorsFeedbackDataRequest_start =>`, action);
    let evaluatorFeedbackFormData: any[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        let evaluatorFeedbackFormComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EVALUATOR_FEEDBACK_FORM, 'getAllEvaluatorsFeedBackByUniqueId');
        evaluatorFeedbackFormComponentAndMethod.url = evaluatorFeedbackFormComponentAndMethod.url.replace('{uniqueid}', action.payload)
        console.log(tranId + '_getAllEvaluatorsFeedbackDataRequest_Api_Request =>', evaluatorFeedbackFormComponentAndMethod);
        const response = yield call(serviceConsumerWithOutHeaders, tranId, evaluatorFeedbackFormComponentAndMethod, null, 'feedBacks');
        console.log(tranId + '_getAllEvaluatorsFeedbackDataRequest_Api_Response =>', response);
        if (response) {
            evaluatorFeedbackFormData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'EFFA1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'EvaluatorFeedbackForm.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'EFFA1')
            }
        }
    }
    catch (error) {
        console.log(`${tranId}_getAllEvaluatorsFeedbackDataRequest_error => `, error.messages ? error.messages : 'EFFA2');
        console.log(`${tranId}_getAllEvaluatorsFeedbackDataRequest_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'EFFA2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'EvaluatorFeedbackForm.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'EFFA2')
        }
    }
    console.log(`${tranId}_getAllEvaluatorsFeedbackDataRequest_end =>`, evaluatorFeedbackFormData, alertMessageData);
    yield put(actions.getAllEvaluatorFeedbackFormDataResponse(evaluatorFeedbackFormData, alertMessageData));
}

function* updateEvaluatorFeedbackFormData(action) {

    let tranId = gettranId(EAPPModules.EVALUATORFEEDBACKFORM);
    console.log(`${tranId}_updateEvaluatorFeedbackFormData_start =>`, action);
    let evaluatorFeedbackFormData: any[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    let { feedbackFormData, evaluatorFeedbackId } = action.payload;

    try {
        let data = {
            "evaluatorFeedbackId": evaluatorFeedbackId,
            "evaluatorFormData": feedbackFormData ? JSON.stringify(feedbackFormData) : ''
        }

        let evaluatorFeedbackFormComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EVALUATOR_FEEDBACK_FORM, 'updatePortFoliosEvaluatorsFeedBack');
        console.log(tranId + '_updateEvaluatorFeedbackFormData_Api_Request =>', evaluatorFeedbackFormComponentAndMethod, data);
        const response = yield call(serviceConsumerWithOutHeaders, tranId, evaluatorFeedbackFormComponentAndMethod, data, '');
        console.log(tranId + '_updateEvaluatorFeedbackFormData_Api_Response =>', response);
        if (response) {
            evaluatorFeedbackFormData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'EFFA4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'EvaluatorFeedbackForm.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'EFFA4')
            }
        }
    }
    catch (error) {
        console.log(`${tranId}_updateEvaluatorFeedbackFormData_error => `, error.messages ? error.messages : 'EFFA5');
        console.log(`${tranId}_updateEvaluatorFeedbackFormData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'EFFA5',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'EvaluatorFeedbackForm.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'EFFA5')
        }
    }
    console.log(`${tranId}_updateEvaluatorFeedbackFormData_end =>`, evaluatorFeedbackFormData, alertMessageData);
    yield put(actions.updateEvaluatorFeedbackFormDataResponse(evaluatorFeedbackFormData, alertMessageData));
}



export function* watchEvaluatorFeedback() {

    yield takeLeading(types.UPDATE_EVALUATOR_FEEDBACK_DATA_REQUEST, updateEvaluatorFeedbackFormData)

    while (true) {
        const main = yield takeLeading(types.GET_ALL_EVALUATOR_FEEDBACK_DATA_REQUEST, getAllEvaluatorsFeedbackDataRequest)
        yield take(types.CANCEL_ALL_PENDING_EVALUATOR_FEEDBACK_REQUEST);
        yield cancel(main);
    }
}

function* evaluatorFeedbackSaga() {
    yield all([fork(watchEvaluatorFeedback)]);
}

export default evaluatorFeedbackSaga;