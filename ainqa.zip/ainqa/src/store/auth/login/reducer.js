import { API_FAILED } from './actionTypes';
import { ACTION_LOGOUT } from '../../layout/actionTypes';

const initialState = {
    loginError: null, message: null, loading: null
}
const login = (state = initialState, action) => {
    switch (action.type) {
        case ACTION_LOGOUT:
            state = {
                ...state,
                user: null,
                loading: null,
                loginError: null
            }
            break;
        case API_FAILED:
            state = {
                ...state,
                loading: false,
                loginError: action.payload
            }
            break;
        default:
            break;
    }
    return state;
}
export default login;