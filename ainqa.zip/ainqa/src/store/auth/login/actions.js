import { API_FAILED, SET_KEYCLOAK_DATA } from './actionTypes';

export const setKeycloakData = (keycloakToken, keycloakLogoutUrl, setAuthCheck, setKeycloakProcess, history, keycloakUsername) => ({
    type: SET_KEYCLOAK_DATA,
    payload: { keycloakToken, keycloakLogoutUrl, setAuthCheck, setKeycloakProcess, history, keycloakUsername }
});

export const apiError = (error) => {
    return {
        type: API_FAILED,
        payload: error
    }
}