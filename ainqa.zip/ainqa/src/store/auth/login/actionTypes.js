export const API_FAILED = 'api_failed';
export const SET_KEYCLOAK_DATA = 'SET_KEYCLOAK_DATA';