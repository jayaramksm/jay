import { takeLeading, fork, put, all, call } from 'redux-saga/effects';
import { SET_KEYCLOAK_DATA } from './actionTypes';
import { apiError } from './actions';
import { setSeesionLoginTimedata } from '../session/action';
import { serviceConsumerWithToken, getApiServiceUrlByComponentAndMethod, gettranId, convertImagePathToBase64 } from '../../../helpers/helpersIndex';
import { EAPPModules, EAPIComponentNames } from '../../../models/utilitiesModel';
import { setProfileBase64LogoPath } from '../../layout/actions';

// pa(1), ua(2), tr(3), ms(4), rs(5), eds(6), pc(7)
const menuData = [
    {
        roleCode: 'pa',
        menu: [
            {
                icon: 'universities',
                link: 'universities',
                moduleName: 'Universities',
                subModules: [
                    { link: 'universities', subModuleName: 'Universities' }
                ]
            },
            {
                icon: 'universityadmin',
                link: 'users',
                moduleName: 'Users',
                subModules: [
                    { link: 'users', subModuleName: 'Users' }
                ]
            }
        ]
    },
    {
        roleCode: 'ua',
        menu: [
            // {
            //     icon: 'dashboard',
            //     link: 'admindashboard1',
            //     moduleName: 'Dashboard',
            //     subModules: [
            //         { link: 'admindashboard1', subModuleName: 'Dashboard' }
            //     ]
            // },
            {
                icon: 'users',
                link: 'users',
                moduleName: 'Users',
                subModules: [
                    { link: 'users', subModuleName: 'Users' }
                ]
            },
            {
                icon: 'masterdata',
                link: 'programs',
                moduleName: 'MasterData',
                subModules: [
                    { link: 'programs', subModuleName: 'Programs' },
                    { link: 'departments', subModuleName: 'Departments' },
                    { link: 'hod', subModuleName: 'HOD' },
                    { link: 'hospitals', subModuleName: 'Hospitals' }
                ]
            },
            {
                icon: 'configurations',
                link: 'email',
                moduleName: 'Email',
                subModules: [
                    { link: 'email', subModuleName: 'Email' }
                ]
            }, {
                icon: 'FormBuilder',
                link: 'formconfigurations',
                moduleName: 'FormConfiguration',
                subModules: [
                    { link: 'formconfigurations', subModuleName: 'FormConfiguration' }
                ]
            }
        ]
    },
    {
        roleCode: 'tr',
        menu: [
            {
                icon: 'home',
                link: 'studyplan',
                moduleName: 'Home',
                subModules: [
                    { link: 'studyplan', subModuleName: 'StudyPlan' },
                    // { link: 'dashboard', subModuleName: 'Dashboard' },
                    // { link: 'mydocument', subModuleName: 'MyDocuments' },
                    // { link: 'programmedetail1', subModuleName: 'ProgrammeDetails' },
                    // { link: 'pointofcontact1', subModuleName: 'PointofContact' }
                ]
            },
            {
                icon: 'gla',
                link: 'gla',
                moduleName: 'GLA',
                subModules: [
                    { link: 'gla', subModuleName: 'GLA' },
                    // { link: 'requestreplace1', subModuleName: 'requestreplaceofsupervisor' }
                ]
            },
            {
                icon: 'rla',
                link: 'placementofrotation',
                moduleName: 'RLA',
                subModules: [
                    { link: 'placementofrotation', subModuleName: 'RLA' },
                    // { link: 'requestreplace1', subModuleName: 'requestreplaceofsupervisor' }
                ]
            },
            {
                icon: 'clinicalMeetings',
                link: 'rotationalmeetings',
                moduleName: 'RotationalMeetings',
                subModules: [
                    { link: 'rotationalmeetings', subModuleName: 'RotationalMeetings' }
                ]
            },
            {
                icon: 'elogbook',
                link: 'portfolio',
                moduleName: 'Portfolio',
                subModules: [
                    { link: 'portfolio', subModuleName: 'Portfolio' }
                ]
            },
            {
                icon: 'Evidence',
                link: 'learningagreements',
                moduleName: 'Evidence',
                subModules: [
                    { link: 'learningagreements', subModuleName: 'LearningAgreements' },
                    { link: 'meetings', subModuleName: 'Meetings' },
                    { link: 'wba', subModuleName: 'Wba' },
                    { link: 'evidencesurgicallogbook', subModuleName: 'Evidencesurgicallogbook' },
                ]
            }
        ]
    },
    {
        roleCode: 'ms',
        menu: [
            // {
            //     icon: 'dashboard',
            //     link: 'dashboard',
            //     moduleName: 'Dashboard',
            //     subModules: [
            //         { link: 'dashboard', subModuleName: 'Dashboard' }
            //     ]
            // },
            {
                icon: 'gla',
                link: 'approvegla',
                moduleName: 'ApproveGLA',
                subModules: [
                    { link: 'approvegla', subModuleName: 'ApproveGLA' },
                    // { link: 'reqreplofsupervisor1', subModuleName: 'replacementrequests' }
                ]
            }
        ]
    },
    {
        roleCode: 'pc',
        menu: [
            {
                icon: 'coursemanagement',
                link: 'coursemanagement',
                moduleName: 'CourseManagement',
                subModules: [
                    { link: 'coursemanagement', subModuleName: 'CourseManagement' }
                ]
            }
        ]
    },
    {
        roleCode: 'rs',
        menu: [
            // {
            //     icon: 'home',
            //     link: 'dashboard',
            //     moduleName: 'Home',
            //     subModules: [
            //         { link: 'dashboard', subModuleName: 'Dashboard' }
            //     ]
            // },
            {
                icon: 'rla',
                link: 'approverla',
                moduleName: 'RLA',
                subModules: [
                    { link: 'approverla', subModuleName: 'RLA' },
                    // { link: 'requestreplace1', subModuleName: 'replacementrequests' }
                ]
            },
            {
                icon: 'clinicalMeetings',
                link: 'approveclinicalmeeting',
                moduleName: 'RotationalMeetings',
                subModules: [
                    { link: 'approveclinicalmeeting', subModuleName: 'RotationalMeetings' }
                ]
            }, {
                icon: 'elogbook',
                link: 'approveportfolio',
                moduleName: 'Portfolio',
                subModules: [
                    { link: 'approveportfolio', subModuleName: 'Portfolio' }
                ]
            },
            {
                icon: 'Evidence',
                link: 'learningagreements',
                moduleName: 'Evidence',
                subModules: [
                    { link: 'learningagreements', subModuleName: 'LearningAgreements' },
                    { link: 'meetings', subModuleName: 'Meetings' },
                    { link: 'wba', subModuleName: 'Wba' },
                    { link: 'evidencesurgicallogbook', subModuleName: 'Evidencesurgicallogbook' },
                ]
            }
        ]
    },
    {
        roleCode: 'eds',
        menu: [
            {
                icon: 'home',
                link: 'approvestatutorydocs',
                moduleName: 'Home',
                subModules: [
                    { link: 'approvestatutorydocs', subModuleName: 'approvestatutorydocuments' },
                    // { link: 'dashboard', subModuleName: 'Dashboard' },
                    { link: 'approvestudyplan', subModuleName: 'approvestudyplan' },
                ]
            },
            {
                icon: 'gla',
                link: 'approvegla',
                moduleName: 'ApproveGLA',
                subModules: [
                    { link: 'approvegla', subModuleName: 'ApproveGLA' },
                    // { link: 'reqreplofsupervisor1', subModuleName: 'replacementrequests' }
                ]
            },
            {
                icon: 'Evidence',
                link: 'learningagreements',
                moduleName: 'Evidence',
                subModules: [
                    { link: 'learningagreements', subModuleName: 'LearningAgreements' },
                    { link: 'meetings', subModuleName: 'Meetings' },
                    { link: 'wba', subModuleName: 'Wba' },
                    { link: 'evidencesurgicallogbook', subModuleName: 'Evidencesurgicallogbook' },
                ]
            }
        ]
    }
];

// keycloak login process
function* loginWithKeycloak(action) {
    const tranId = gettranId(EAPPModules.LOGINMODULE);
    const { keycloakToken, keycloakLogoutUrl, setAuthCheck, setKeycloakProcess, history, keycloakUsername } = action.payload;
    console.log(`${tranId}_loginWithKeycloak_request=>`, action);

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.AUTH, 'userLogin');
        console.log(`${tranId}_loginWithKeycloak_getUserDto_request=>`, { tranId, componentAndMethod, keycloakToken, keycloakUsername });
        const response = yield call(serviceConsumerWithToken, tranId, componentAndMethod, keycloakToken, { username: keycloakUsername });
        console.log(`${tranId}_loginWithKeycloak_getUserDto_response=>`, response);

        if (response.status) {
            // yield put(setAuthToken(keycloakToken));
            // yield put(setSessionUserdata(response.userDetails));

            let profilePath = response.userDetails?.profileUrl
            if (profilePath) {
                let base64Path = yield call(convertImagePathToBase64, profilePath);
                if (base64Path) yield put(setProfileBase64LogoPath(base64Path));
            }


            // request keycloak to update the token

            let roolCode = response.userDetails?.roles?.roleCode || '';
            const menuResponse = menuData.find(x => x.roleCode === roolCode)?.menu;

            if (menuResponse?.length > 0) {
                let redirectPath;

                redirectPath = '/' + menuResponse[0].link;
                if (redirectPath) {
                    setAuthCheck(true);
                    setKeycloakProcess(true);
                    console.log(tranId + '_loginUser_end=>', { keycloakToken, menuResponse, response, redirectPath });
                    // if (response.userDetails.isFirstLogin) {
                    //     //  yield put(setIsDefultPasswordAuth(password));
                    //     yield put(setSeesionLoginTimedata(keycloakToken, [], response.userDetails, keycloakLogoutUrl));
                    //     redirectPath = '/defaultchangepassword';
                    // }
                    // else
                    yield put(setSeesionLoginTimedata(keycloakToken, menuResponse, response.userDetails, keycloakLogoutUrl));
                    history.push(redirectPath);
                }
            }
            else {
                yield put(apiError('Menu is not found, so Unable to login'));
                setAuthCheck(true);
            }
        }
        else {
            setAuthCheck(true);
            yield put(apiError(response ? (response.messages ? response.messages : 'Your Request has failed') : 'Your Request has failed'));
        }
    }
    catch (error) {
        setAuthCheck(true);
        yield put(apiError(error ? (error.messages ? (error.statuscode === 500 ? 'Unable to Connect Server ,Please try after some time..' : error.messages) : 'Your Request has failed') : 'Your Request has failed'));
    }
}

export function* watchUserLogin() {
    yield takeLeading(SET_KEYCLOAK_DATA, loginWithKeycloak);
}
function* loginSaga() {
    yield all([fork(watchUserLogin)]);
}
export default loginSaga;