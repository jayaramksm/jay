import { SET_AUTH_TOKEN, REMOVE_AUTH_TOKEN, SET_MENU_DATA, SET_SESSION_USER_DATA, SET_SESSION_LOGIN_TIME_DATA, SET_IS_DEFULT_PASSWORD_AUTH } from "./actionTypes";
import { ISessionstate } from '../../../models/utilitiesModel';
import moment from "moment";

const initialState = {} as ISessionstate;

const SessionState = (state = initialState as ISessionstate, action: any) => {
    switch (action.type) {
        case SET_AUTH_TOKEN:
            state = {
                ...state,
                token: action.payload
            }
            break;
        case REMOVE_AUTH_TOKEN:
            state = {
                ...state,
                token: undefined
            }
            break;
        case SET_IS_DEFULT_PASSWORD_AUTH:
            state = {
                ...state,
                isDefultPasswordAuth: action.payload
            }
            break;
        case SET_MENU_DATA:
            state = {
                ...state,
                menuData: action.payload
            }
            break;
        case SET_SESSION_LOGIN_TIME_DATA:
            state = {
                ...state,
                menuData: action.payload.menuData,
                token: action.payload.tokenData,
                userDto: action.payload.userdata,
                loginTime: moment().format('DD/MM/YYYY HH:mm:ss'),
                isDefultPasswordAuth: action.payload.isDefultPasswordAuth,
                logoutUrl: action.payload.logoutUrl
            }
            break;
        case SET_SESSION_USER_DATA:
            if (action.payload)
                state = {
                    ...state,
                    userDto: action.payload

                }
            break;
        default:
            break;
    }
    return state;
}

export default SessionState