import { SET_AUTH_TOKEN, REMOVE_AUTH_TOKEN, SET_SESSION_SELECT_LOCATIONID, SET_SESSION_SELECT_LOCATIONID_REQUEST, SET_MENU_DATA, SET_SESSION_USER_DATA, SET_SESSION_LOGIN_TIME_DATA, SET_SESSION_SELECT_LOCATION_STATUS, SET_IS_DEFULT_PASSWORD_AUTH } from "./actionTypes"

export const setAuthToken = (token) => {
    return {
        type: SET_AUTH_TOKEN,
        payload: token
    }
}
export const removeAuthToken = () => {
    return {
        type: REMOVE_AUTH_TOKEN
    }
}
export const setMenudata = (menu) => {
    return {
        type: SET_MENU_DATA,
        payload: menu
    }
}
export const setSessionUserdata = (data) => {
    return {
        type: SET_SESSION_USER_DATA,
        payload: data
    }
}
export const setIsDefultPasswordAuth = (data) => {
    return {
        type: SET_IS_DEFULT_PASSWORD_AUTH,
        payload: data
    }
}
export const setSeesionLoginTimedata = (tokenData, menuData, userdata, logoutUrl, isDefultPasswordAuth = undefined) => {
    return {
        type: SET_SESSION_LOGIN_TIME_DATA,
        payload: { tokenData, menuData, userdata, logoutUrl, isDefultPasswordAuth }
    }
}
export const setSessionSelectLoactionId = (locationId, status) => {
    return {
        type: SET_SESSION_SELECT_LOCATIONID_REQUEST,
        payload: { locationId, status }
    }
}
export const setSessionSelectLoactionIdResponse = () => {
    return {
        type: SET_SESSION_SELECT_LOCATIONID
    }
}
export const setSessionSelectLoactionStatus = (status) => {
    return {
        type: SET_SESSION_SELECT_LOCATION_STATUS,
        payload: status
    }
}