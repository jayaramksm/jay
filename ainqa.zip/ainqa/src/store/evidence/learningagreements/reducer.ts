import * as types from './actionTypes';
import { ILearningAgreementsModel } from '../../../models/learningAgreementsModel';
import { EOprationalActions } from '../../../models/utilitiesModel';

const initialState = {} as ILearningAgreementsModel

const learningAgreementsReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.SET_RESET_LEARNING_AGREEMENTS_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefinedData,
                actionType: EOprationalActions.UNSELECT,
                searchkey: '',
                paginationCurrentPage: 0,
                learningAgreements: undefinedData,
                learningAgreementsActionData: undefinedData
            }
            break;
        case types.SET_SEARCH_KEY_IN_LEARNING_AGREEMENTS_REQUEST:
            state = {
                ...state,
                searchkey: action.payload
            }
            break;
        case types.SET_LEARNING_AGREEMENTS_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.GET_ALL_LEARNING_AGREEMENTS_DETAILS_RESPONSE:
            state = {
                ...state,
                learningAgreements: action.payload
            }
            break;
        case types.SET_LEARNING_AGREEMENTS_ACTION_TYPE_AND_ACTION_DATA:
            state = {
                ...state,
                actionType: action.payload.actionType,
                actionData: action.payload.actionData
            }
            if (action.payload.learningAgreementsActionData) {
                state = {
                    ...state,
                    learningAgreementsActionData: action.payload.learningAgreementsActionData
                }
            }
            break;
        default: state = { ...state }
    }
    return state
}

export default learningAgreementsReducer;