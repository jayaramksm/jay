import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import * as actions from './actions';
import { getApiServiceUrlByComponentAndMethod, serviceConsumer, getMessageCode, gettranId, serviceConsumerWithMultiCalls, } from '../../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, ERoleDesc, IAlertMessagedata, ISessionstate, IUserDetails } from '../../../models/utilitiesModel';
import { IGlaAgreementsData, IRlaAgreementsData } from '../../../models/learningAgreementsModel';
import groupBy from 'lodash/groupBy';

function* getAllLearningAgreementsDetailsRequest() {

    let tranId = gettranId(EAPPModules.LEARNINGAGREEMENTSMODULE);
    console.log(`${tranId}_getAllLearningAgreementsDetailsRequest =>`,);
    let rlaAgreementsData: IRlaAgreementsData[] | undefined;
    let glaAgreementsData: any[] | undefined = [];
    let learningAgreements: any[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let userDto: IUserDetails = ((yield select())['SessionState'] as ISessionstate).userDto;

    let method = userDto?.userType === ERoleDesc.Traninee ? 'getAllApprovedRlasByTrId' : userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR ? 'getAllApprovedRlasByRsId' : 'getAllApprovedRlasByEsId'
    let component = userDto?.userType === ERoleDesc.Traninee ? EAPIComponentNames.TRAINEE : userDto?.userType === ERoleDesc.ROTATIONSUPERVISOR ? EAPIComponentNames.ROTATIONAL_SUPERVISOR : EAPIComponentNames.EDUCATIONAL_SUPERVISOR;

    let glamethod = userDto?.userType === ERoleDesc.Traninee ? 'getAllApprovedGlasByTrId' : 'getAllApprovedGlasByEsId'
    let glacomponent = userDto?.userType === ERoleDesc.Traninee ? EAPIComponentNames.TRAINEE : EAPIComponentNames.EDUCATIONAL_SUPERVISOR;

    try {
        let rlacomponentAndMethod = getApiServiceUrlByComponentAndMethod(component, method);
        let glacomponentAndMethod = getApiServiceUrlByComponentAndMethod(glacomponent, glamethod);

        let multiCallcomponentAndMethods = [rlacomponentAndMethod];
        let multiCallbody = [null];

        if ((userDto?.userType === ERoleDesc.Traninee) || (userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR)) {
            multiCallcomponentAndMethods.push(glacomponentAndMethod);
            multiCallbody.push(null)
        }
        console.log(`${tranId}_getAllLearningAgreementsDetailsRequest_Api_Request => `, multiCallcomponentAndMethods, multiCallbody);
        let response = yield call(serviceConsumerWithMultiCalls, tranId, multiCallcomponentAndMethods, multiCallbody, undefined);
        console.log(`${tranId}_getAllLearningAgreementsDetailsRequest_Api_Response =>`, response);

        if (response && response?.length > 0) {
            if (response[0] && response[0].status === 200) {
                let res = response[0].data['rlas'] ? response[0].data['rlas'] : [];

                rlaAgreementsData = res?.map((x: IRlaAgreementsData) => {
                    if (x.firstRotationalSupervisor?.supervisorName && x.secondRotationSupervisor?.supervisorName) {
                        if (+new Date(x.firstRotationalSupervisor?.approvedOn) >= +new Date(x.secondRotationSupervisor?.approvedOn))
                            return { ...x, agreementName: 'RLA', latestApprovedOn: x.firstRotationalSupervisor?.approvedOn }
                        else return { ...x, agreementName: 'RLA', latestApprovedOn: x.secondRotationSupervisor?.approvedOn }
                    } else if (x.firstRotationalSupervisor?.supervisorName)
                        return { ...x, agreementName: 'RLA', latestApprovedOn: x.firstRotationalSupervisor?.approvedOn }
                    return x
                });
            }
            else {
                alertMessageData = {
                    message: response[0].messages ? response[0].messages : 'LAA1',
                    status: false,
                    tranId: Date.now(),
                    transKey: response[0].messages ? '' : 'LearningAgreements.alertMessages.',
                    messageCode: response[0].messages ? tranId : getMessageCode(tranId, 'LAA1')
                }
            }
            if (response[1]) {

                if (response[1] && response[1].status === 200) {
                    let res = response[1].data['glas'] ? response[1].data['glas'] : [];
                    let groupedglasData = groupBy(res, 'traineeId');
                    console.log('groupedglasData==>', groupedglasData)
                    let latestApprovedGlaDate: any = '';
                    Object.keys(groupedglasData).forEach((x, i) => {
                        let agreements = groupedglasData[x].map((y: IGlaAgreementsData, ind, arr) => {
                            let data;
                            if (ind === 0) {
                                if (y.esUserName && y.mohUserName) {
                                    if (+new Date(y?.esApprovedON) >= +new Date(y?.mohApprovedOn)) {
                                        data = { ...y, agreementName: 'GLA', latestApprovedOn: y.esApprovedON }
                                        latestApprovedGlaDate = y.esApprovedON
                                    }
                                    else {
                                        data = { ...y, agreementName: 'GLA', latestApprovedOn: y.mohApprovedOn }
                                        latestApprovedGlaDate = y.mohApprovedOn
                                    }
                                } else if (y?.esUserName) {
                                    data = { ...y, agreementName: 'GLA', latestApprovedOn: y.esApprovedON }
                                    latestApprovedGlaDate = y.esApprovedON;
                                }
                            } else {
                                if (arr?.length > 1) {
                                    if (y.esUserName && y.mohUserName) {
                                        if (+new Date(y?.esApprovedON) >= +new Date(y?.mohApprovedOn)) {
                                            data = { ...y, agreementName: 'GLA', latestApprovedOn: `${y.esApprovedON} - ${latestApprovedGlaDate}` }
                                            latestApprovedGlaDate = y.esApprovedON
                                        }
                                        else {
                                            data = { ...y, agreementName: 'GLA', latestApprovedOn: `${y.mohApprovedOn} - ${latestApprovedGlaDate}` }
                                            latestApprovedGlaDate = y.mohApprovedOn
                                        }
                                    } else if (y?.esUserName) {
                                        data = { ...y, agreementName: 'GLA', latestApprovedOn: `${y.esApprovedON} - ${latestApprovedGlaDate}` }
                                        latestApprovedGlaDate = y.esApprovedON;
                                    }
                                }
                            }
                            return data || x;
                        })
                        glaAgreementsData?.push(...agreements);
                    })
                }
                else {
                    if (!alertMessageData)
                        alertMessageData = {
                            message: response[1].messages ? response[1].messages : 'LAA2',
                            status: false,
                            tranId: Date.now(),
                            transKey: response[1].messages ? '' : 'LearningAgreements.alertMessages.',
                            messageCode: response[1].messages ? tranId : getMessageCode(tranId, 'LAA2')
                        }
                }
            }
        }
        else {
            alertMessageData = {
                message: response?.messages || 'LAA3',
                status: false,
                tranId: Date.now(),
                transKey: response?.messages ? '' : 'LearningAgreements.alertMessages.',
                messageCode: response?.messages ? tranId : getMessageCode(tranId, 'LAA3')
            };
        }
    } catch (error) {
        console.error(`${tranId}_getAllLearningAgreementsDetailsRequest_error => `, error.messages ? error.messages : "LAA4");
        console.log(`${tranId}_getAllLearningAgreementsDetailsRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'LAA4',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'LearningAgreements.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'LAA4')
        };
    }
    if (rlaAgreementsData && glaAgreementsData) {
        if (rlaAgreementsData?.length > 0 && glaAgreementsData?.length > 0)
            learningAgreements = rlaAgreementsData.concat(glaAgreementsData);
        else if (rlaAgreementsData?.length > 0)
            learningAgreements = rlaAgreementsData;
        else if (glaAgreementsData?.length > 0)
            learningAgreements = glaAgreementsData
        else learningAgreements = []
    }
    console.log(`${tranId}_getAllLearningAgreementsDetailsRequest_End => `, rlaAgreementsData, glaAgreementsData, learningAgreements, alertMessageData);
    yield put(actions.getAllLearningAgreementsDetailsResponse(learningAgreements, alertMessageData));
}


export function* watchAllLearningAgreements() {

    while (true) {
        const main = yield takeLeading(types.GET_ALL_LEARNING_AGREEMENTS_DETAILS_REQUEST, getAllLearningAgreementsDetailsRequest)
        yield take(types.CANCEL_ALL_LEARNING_AGREEMENTS_API_REQUESTS);
        yield cancel(main);
    }
}

function* learningAgreementsSaga() {
    yield all([fork(watchAllLearningAgreements)]);
}

export default learningAgreementsSaga;

