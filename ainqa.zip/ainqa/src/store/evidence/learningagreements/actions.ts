import * as types from './actionTypes';
import { ACTION_LOADING, LAYOUT_ALERT_ACTION_REQUEST } from '../../layout/actionTypes';

export const setResetLearningAgreementsStateRequest = () => ({
    type: types.SET_RESET_LEARNING_AGREEMENTS_STATE_REQUEST
});

export const setLearningAgreementsActionTypeAndActionData = (actionType, actionData, learningAgreementsActionData) => ({
    type: types.SET_LEARNING_AGREEMENTS_ACTION_TYPE_AND_ACTION_DATA,
    payload: { actionType, actionData, learningAgreementsActionData }
});

export const setLearningAgreementsPaginationCurrentPageValue = (currentPageData) => ({
    type: types.SET_LEARNING_AGREEMENTS_PAGINATION_CURRENT_PAGE_VALUE,
    payload: currentPageData
});

export const cancelAllLearningAgreementsApiRequest = () => ({
    type: types.CANCEL_ALL_LEARNING_AGREEMENTS_API_REQUESTS
});

export const setSearchKeyInLearningAgreementsRequest = (searchKey) => ({
    type: types.SET_SEARCH_KEY_IN_LEARNING_AGREEMENTS_REQUEST,
    payload: searchKey
});

export const getAllLearningAgreementsDetailsRequest = () => ({
    type: types.GET_ALL_LEARNING_AGREEMENTS_DETAILS_REQUEST,
    loadType: ACTION_LOADING,
    loadPayload: true,
})
export const getAllLearningAgreementsDetailsResponse = (learningAgreements, alertMessageData) => ({
    type: types.GET_ALL_LEARNING_AGREEMENTS_DETAILS_RESPONSE,
    payload: learningAgreements,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});





