import * as types from './actionTypes';
import { ACTION_LOADING, LAYOUT_ALERT_ACTION_REQUEST } from '../../layout/actionTypes';

export const setResetMeetingsStateRequest = () => ({
    type: types.SET_RESET_MEETINGS_STATE_REQUEST
});

export const setMeetingsActionTypeAndActionData = (actionType, actionData, meetingsActionData) => ({
    type: types.SET_MEETINGS_ACTION_TYPE_AND_ACTION_DATA,
    payload: { actionType, actionData, meetingsActionData }
});

export const setMeetingsPaginationCurrentPageValue = (currentPageData) => ({
    type: types.SET_MEETINGS_PAGINATION_CURRENT_PAGE_VALUE,
    payload: currentPageData
});

export const cancelAllMeetingsApiRequest = () => ({
    type: types.CANCEL_ALL_MEETINGS_API_REQUESTS
});

export const setSearchKeyInMeetingsRequest = (searchKey) => ({
    type: types.SET_SEARCH_KEY_IN_MEETINGS_REQUEST,
    payload: searchKey
});

export const getAllMeetingsDetailsRequest = () => ({
    type: types.GET_ALL_MEETINGS_DETAILS_REQUEST,
    loadType: ACTION_LOADING,
    loadPayload: true,
})
export const getAllMeetingsDetailsResponse = (meetingDetails, alertMessageData) => ({
    type: types.GET_ALL_MEETINGS_DETAILS_RESPONSE,
    payload: meetingDetails,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});





