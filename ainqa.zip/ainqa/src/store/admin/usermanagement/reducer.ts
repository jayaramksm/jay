import { EOprationalActions } from '../../../models/utilitiesModel';
import { IUserManagementModel } from '../../../models/userManagementModel';
import * as types from './actionTypes';

const initialState = {} as IUserManagementModel;
const userManagementReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.GET_ALL_USER_AND_ROLES_DATA_RESPONSE:
            if (action.payload.isUniveristyAdminRole)
                state = {
                    ...state,
                    usersData: action.payload.usersData,
                    rolesData: action.payload.rolesData,
                    currentDate: action.payload.currentDate,
                    programeeDetails: action.payload.programmeCodeDetailsList,
                    universityCode: action.payload.universityCodeDeatilsList,
                    deptsData: action.payload.deptsData,
                    programsData: action.payload.programsData,
                    programmeCodeDetailsList: action.payload.programmeCodeDetailsList,
                    universitiesData: action.payload.universitiesData
                }
            else
                state = {
                    ...state,
                    usersData: action.payload.usersData,
                    universitiesData: action.payload.universitiesData
                };
            break;
        case types.RESET_ALL_USERS_STATE_REQUEST:
            state = {
                ...state,
                usersData: undefinedData,
                rolesData: undefinedData,
                deptsData: undefinedData,
                programsData: undefinedData,
                universitiesData: undefinedData,
                programmeCodeDetailsList: undefinedData,
                actionType: EOprationalActions.UNSELECT,
                actionData: undefinedData,
                searchKey: '',
                uploadedFilesInfo: undefinedData,
                currentDate: undefinedData,
                paginationCurrentPage: 0,
                programeeDetails: undefinedData,
                universityCode: undefinedData
            }
            break;
        case types.SET_SEARCH_USER_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.SET_USERS_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
                searchKey: ''
            }
            break;
        case types.CREATE_OR_EDIT_SINGLE_USERS_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    usersData: action.payload,
                    actionType: EOprationalActions.UNSELECT
                }
            break;
        case types.SET_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.DELETE_USERS_DATA_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    usersData: action.payload
                }
            break;
        case types.BULK_UPLOAD_USER_DATA_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    usersData: action.payload,
                    actionType: EOprationalActions.UNSELECT
                }
            break;
        default: state = { ...state }
    }
    return state;
}

export default userManagementReducer;