import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { bulkUploadRecordsCount, DownloadCsv, getApiServiceUrlByComponentAndMethod, getMessageCode, getModifiedDate, gettranId, serviceConsumer, serviceConsumerWithMultiCalls, getMomentModifiedDateObject } from '../../../helpers/helpersIndex';
import { EAPPModules, EOprationalActions, ERoleDesc, ERoleId, IAlertMessagedata, IConfirmModel, IConfirmOptions, ICurrentDateAndTime, ISessionstate, IUniversity, EAPIComponentNames, IUserDetails } from '../../../models/utilitiesModel';
import { IDepartment, IProgram, IRoles, IUser, IUserManagementModel } from '../../../models/userManagementModel';
import * as actions from './actions';
import { setConfirmationOpen } from '../../../store/actions';
import * as _ from 'lodash';

function* getOnlyUSerData(tranId) {
    console.log(`${tranId}_getOnlyUSerData_start =>`);
    let usersData: IUser[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const { universityId = '0' } = (yield select())['SessionState']?.userDto?.university || {};
    try {
        let usersComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.USER_MANAGEMENT, 'getUsersByRoleCode');
        console.log(tranId + '_getAllUsers_Api_Request =>', usersComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, usersComponentAndMethod, { universityId }, 'users');
        console.log(tranId + '_getAllUsers_Api_Response =>', response);
        if (response)
            usersData = response;
        else {
            alertMessageData = {
                message: response.messages || 'EUM1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'EUM1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getAllUsersData_error => `, error.messages || 'EUM25');
        console.log(`${tranId}_getAllUsersData_catch=>`, error);
        alertMessageData = {
            message: error.messages || 'EUM25',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'UsersManagement.alertMessages.',
            messageCode: getMessageCode(tranId, 'EUM25'),

            statusCode: error.statuscode ? error.statuscode : 0
        }
    }
    return { usersData, alertMessageData };
}

function* getUsersRolesDeptsPrgmsUniversitiesData() {
    let tranId = gettranId(EAPPModules.USERMANAGEMENTMODULE);
    console.log(`${tranId}_getUsersRolesDeptsPrgmsUniversitiesData_start =>`);

    let usersData: IUser[] | undefined;
    let rolesData: IRoles[] | undefined;
    let deptsData: IDepartment[] | undefined;
    let programsData: IProgram[] | undefined;
    let universitiesData: IUniversity[] | undefined;
    let currentDate: ICurrentDateAndTime | undefined;
    let programmeCodeDetailsList: any;
    let alertMessageData: IAlertMessagedata | undefined;

    const userDto = (yield select())['SessionState']?.userDto;
    const { universityId = '0' } = userDto?.university || {};
    const isUniveristyAdminRole = (userDto?.roles?.roleCode || '') === ERoleDesc.UNIVERSITYADMIN;

    try {
        const usersComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.USER_MANAGEMENT, 'getUsersByRoleCode');
        const universitiesComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.UNIVERSITY, 'getAllUniverties')
        const usersCurrrentDateComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.AUTH, 'getCurrentDate');
        const usersRoleComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.ROLES, 'getAllRoles');
        const deptsCompoentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'getAllDepartments');
        const programsCompoentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'getAllPrograms');

        const multipleApiCallMethods: any[] = [usersComponentAndMethod, universitiesComponentAndMethod];
        const multipleApiBody: any[] = [{ universityId }, null];

        if (isUniveristyAdminRole) {
            const otherApiMethods = [usersCurrrentDateComponentAndMethod, usersRoleComponentAndMethod, deptsCompoentAndMethod, programsCompoentAndMethod];
            const otherApiBodys = [null, null, null, null];

            multipleApiCallMethods.push(...otherApiMethods);
            multipleApiBody.push(...otherApiBodys);
        }

        console.log(tranId + '_getUsersRolesDeptsPrgmsUniversitiesData_Api_Request =>', multipleApiCallMethods, multipleApiBody);
        const response = yield call(serviceConsumerWithMultiCalls, tranId, multipleApiCallMethods, multipleApiBody);
        console.log(tranId + '_getUsersRolesDeptsPrgmsUniversitiesData_Api_Response =>', response);

        if (response.length > 0) {
            if (response[0] && response[0].status === 200)
                usersData = response[0].data['users'] ? response[0].data['users'] : undefined;
            else {
                alertMessageData = {
                    message: response[0].messages ? response[0].messages : 'EUM1',
                    status: false,
                    tranId: Date.now(),
                    transKey: response[0].messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response[0].messages ? tranId : getMessageCode(tranId, 'EUM1')
                }
            }
            if (response[1] && response[1].status === 200)
                universitiesData = response[1]?.data['universities'] || [];
            else {
                alertMessageData = {
                    message: response[1].messages || 'EUM21',
                    status: false,
                    tranId: Date.now(),
                    transKey: response[1].messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response[1].messages ? tranId : getMessageCode(tranId, 'EUM21')
                }
            }

            if (isUniveristyAdminRole) {
                if (response[2] && response[2].status === 200)
                    currentDate = response[2]?.data;
                else
                    alertMessageData = {
                        message: response[2].messages ? response[2].messages : 'EUM7',
                        status: false,
                        tranId: Date.now(),
                        transKey: response[2].messages ? '' : 'UsersManagement.alertMessages.',
                        messageCode: response[2].messages ? tranId : getMessageCode(tranId, 'EUM7')
                    }
                if (response[3] && response[3].status === 200)
                    rolesData = response[3].data['roles'] ? response[3].data['roles'] : []
                else
                    alertMessageData = {
                        message: response[3].messages ? response[3].messages : 'EUM2',
                        status: false,
                        tranId: Date.now(),
                        transKey: response[3].messages ? '' : 'UsersManagement.alertMessages.',
                        messageCode: response[3].messages ? tranId : getMessageCode(tranId, 'EUM2')
                    }
                if (response[4] && response[4].status === 200)
                    deptsData = response[4]?.data['departments'] || [];
                else
                    alertMessageData = {
                        message: response[4].messages || 'EUM19',
                        status: false,
                        tranId: Date.now(),
                        transKey: response[4].messages ? '' : 'UsersManagement.alertMessages.',
                        messageCode: response[4].messages ? tranId : getMessageCode(tranId, 'EUM19')
                    }
                if (response[5] && response[5].status === 200) {
                    programsData = response[5]?.data['program'] || [];
                    programmeCodeDetailsList = programsData?.reduce((codes, code) => {
                        if (!codes[code.programCode]) {
                            codes[code.programCode] = code.programId
                            if (!codes[code.programId]) codes[code.programId] = code.programCode
                        }
                        return codes;
                    }, {})
                }
                else
                    alertMessageData = {
                        message: response[5].messages || 'EUM20',
                        status: false,
                        tranId: Date.now(),
                        transKey: response[5].messages ? '' : 'UsersManagement.alertMessages.',
                        messageCode: response[5].messages ? tranId : getMessageCode(tranId, 'EUM20')
                    }
            }
        }
        else {
            alertMessageData = {
                message: response.messages || isUniveristyAdminRole ? 'EUM22' : 'EUM23',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, isUniveristyAdminRole ? 'EUM22' : 'EUM23')
            }
        }
    }
    catch (error) {
        console.log(`${tranId}_getUsersRolesDeptsPrgmsUniversitiesData_error => `, error.messages || isUniveristyAdminRole ? 'EUM3' : 'EUM24');
        console.log(`${tranId}_getUsersRolesDeptsPrgmsUniversitiesData_catch=>`, error);
        alertMessageData = {
            message: (error.messages && isUniveristyAdminRole) ? 'EUM3' : 'EUM24',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, isUniveristyAdminRole ? 'EUM3' : 'EUM24'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'UsersManagement.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`${tranId}_getUsersRolesDeptsPrgmsUniversitiesData_End =>`, usersData, universitiesData, currentDate, rolesData, deptsData, programsData, programmeCodeDetailsList, alertMessageData);
    yield put(actions.getAllUsersDataResponse(isUniveristyAdminRole, usersData, universitiesData, currentDate, rolesData, deptsData, programsData, programmeCodeDetailsList, alertMessageData));
}

function* createOrEditSingleUSersData(action) {
    let tranId = gettranId(EAPPModules.USERMANAGEMENTMODULE);
    const { requestType, requestData, isPlatformAdmin } = action.payload;
    console.log(`${tranId}_createOrEditSingleUSersData_start =>`, { action, requestData });

    let usersData: IUser[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let dateOfBirth = getMomentModifiedDateObject(requestData.dob);
    let traineeActiveFromDate = getMomentModifiedDateObject(requestData.trActiveFrom);
    let traineeActiveToDate = getMomentModifiedDateObject(requestData.trActiveTo);

    if (requestType === EOprationalActions.ADD) {
        try {
            const createobject = {
                correspondentAddress: requestData?.correspondentAddress || '',
                correspondentCountry: requestData?.correspondentCountry?.value || '',
                departmentIds: requestData?.departmentIds?.map(x => x.departmentId) || [],
                dob: dateOfBirth ? dateOfBirth.format('YYYY-MM-DD') : '',
                employeeId: requestData?.employeeId || '',
                eportfolioEmailId: requestData.eportfolioEmailId || '',
                gender: requestData?.gender?.value || '',
                isActive: requestData?.isActive || 1,
                isFirstLogin: requestData?.isFirstLogin || 0,
                isMohSupervisor: requestData?.roles?.roleCode === ERoleDesc.MOHSUPERVISOR,
                isSameAddress: requestData?.isSameAddress === true ? 1 : 0,
                mmcno: requestData?.mmcno || '',
                mobileno1: requestData?.mobileno1 || '',
                mobileno2: requestData?.mobileno2 || '',
                mohId: requestData?.mohId || '',
                personalEmailId: requestData?.personalEmailId || '',
                programId: requestData?.programId?.programId || '',
                residentialAddress: requestData?.residentialAddress || '',
                residentialCountry: requestData?.residentialCountry?.value || '',
                resourceCode: requestData?.resourceCode || '',
                roleId: isPlatformAdmin ? ERoleId.UNIVERSITYADMIN : requestData?.roles?.roleId || '',
                roleCode: isPlatformAdmin ? ERoleDesc.UNIVERSITYADMIN : (requestData?.roles?.roleCode || ''),
                roleName: requestData?.roles?.roleName || '',
                trainee: requestData?.roles?.roleCode === ERoleDesc.Traninee ? {
                    anmno: requestData?.anmno || '',
                    coEducationalSupervisor: requestData?.coEducationalSupervisor?.userId || '',
                    educationalSupervisor: requestData?.educationalSupervisor?.userId || '',
                    nsrno: requestData?.nsrno || '',
                    pathwayTag: requestData?.pathwayTag?.value || '',
                    remark: requestData?.remark || '',
                    trActiveFrom: traineeActiveFromDate ? traineeActiveFromDate.format('YYYY-MM-DD') : null,
                    trActiveTo: traineeActiveToDate ? traineeActiveToDate.format('YYYY-MM-DD') : null,
                    trIcNo: requestData?.trIcNo || '',
                    trLegacyCode: requestData?.trLegacyCode || '',
                    trMohUser: (requestData?.coEducationalSupervisor?.userId) ? "1" : "0",
                    trStatus: requestData?.trStatus || ''
                } : null,
                universityId: isPlatformAdmin ? (requestData?.university?.universityId) : (requestData?.universityId ? requestData?.universityId : ''),
                universityCode: isPlatformAdmin ? (requestData?.university?.universityCode) : (requestData?.universityCode ? requestData?.universityCode : ''),
                universityName: isPlatformAdmin ? (requestData?.university?.universityName) : (requestData?.universityName ? requestData?.universityName : ''),
                userFullName: requestData?.userFullName || '',
                userName: requestData?.userName || '',
                userType: isPlatformAdmin ? ERoleDesc.UNIVERSITYADMIN : (requestData?.roles?.roleCode || ''),
                designation: requestData?.designation || ''
            }

            let userCreateComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.USER_MANAGEMENT, 'createUser');
            console.log(`${tranId}_createOrEditSingleUSersData_Api_Request =>`, { userCreateComponentAndMethod, createobject });
            let response = yield call(serviceConsumer, tranId, userCreateComponentAndMethod, createobject, null)
            console.log(`${tranId}_createOrEditSingleUSersData_Api_Response`, response);
            if (response.status) {
                let usersDataresponse = yield call(getOnlyUSerData, tranId);
                usersData = usersDataresponse.usersData;
                alertMessageData = usersDataresponse.alertMessageData;

                if (!alertMessageData)
                    alertMessageData = {
                        message: response.messages ? response.messages : 'EUM4',
                        status: true,
                        tranId: Date.now(),
                        transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                        messageCode: response.messages ? undefined : tranId + 'EUM4'
                    }
                else
                    alertMessageData = {
                        message: 'EUM26',
                        status: true,
                        tranId: Date.now(),
                        transKey: 'UsersManagement.alertMessages.',
                        messageCode: getMessageCode(tranId, 'EUM26')
                    };
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'EUM5',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'EUM5')
                }
            }
        } catch (error) {
            console.log(`${tranId}_createOrEditSingleUSersData_error => `, error.messages ? error.messages : 'EUM6');
            console.log(`${tranId}_createOrEditSingleUSersData_catch=>`, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'EUM6',
                status: false,
                tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'EUM6'),

                transKey: error.messages ? 'controleErrors.' + error.messages : 'UsersManagement.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            }
        }
    } else {
        try {
            const updateObject = {
                userId: requestData?.userId || '',
                correspondentAddress: requestData?.correspondentAddress || '',
                correspondentCountry: requestData?.correspondentCountry?.value || '',
                departmentIds: requestData?.departmentIds?.map(x => x.departmentId) || [],
                dob: dateOfBirth ? dateOfBirth.format('YYYY-MM-DD') : '',
                employeeId: requestData?.employeeId || '',
                eportfolioEmailId: requestData.eportfolioEmailId || '',
                gender: requestData?.gender?.value || '',
                isActive: requestData?.isActive || 1,
                isFirstLogin: requestData?.isFirstLogin || 0,
                isMohSupervisor: !!(requestData?.isMohSupervisor) || false,
                isSameAddress: requestData?.isSameAddress === true ? 1 : 0,
                mmcno: requestData?.mmcno || '',
                mobileno1: requestData?.mobileno1 || '',
                mobileno2: requestData?.mobileno2 || '',
                mohId: requestData?.mohId || '',
                personalEmailId: requestData?.personalEmailId || '',
                programId: requestData?.programId?.programId || '',
                residentialAddress: requestData?.residentialAddress || '',
                residentialCountry: requestData?.residentialCountry?.value || '',
                resourceCode: requestData?.resourceCode || '',
                roleId: isPlatformAdmin ? ERoleId.UNIVERSITYADMIN : requestData?.roles?.roleId || '',
                roleCode: isPlatformAdmin ? ERoleDesc.UNIVERSITYADMIN : (requestData?.roles?.roleCode || ''),
                roleName: requestData?.roles?.roleName || '',
                trainee: requestData?.roles?.roleCode === ERoleDesc.Traninee ? {
                    anmno: requestData?.anmno || '',
                    coEducationalSupervisor: requestData?.coEducationalSupervisor?.userId || '',
                    educationalSupervisor: requestData?.educationalSupervisor?.userId || '',
                    nsrno: requestData?.nsrno || '',
                    pathwayTag: requestData?.pathwayTag?.value || '',
                    remark: requestData?.remark || '',
                    trActiveFrom: traineeActiveFromDate ? traineeActiveFromDate.format('YYYY-MM-DD') : null,
                    trActiveTo: traineeActiveToDate ? traineeActiveToDate.format('YYYY-MM-DD') : null,
                    trIcNo: requestData?.trIcNo || '',
                    trId: requestData?.trId || '',
                    trLegacyCode: requestData?.trLegacyCode || '',
                    trMohUser: (requestData?.coEducationalSupervisor?.userId) ? "1" : "0",
                    trStatus: requestData?.trStatus || ''
                } : null,
                universityId: isPlatformAdmin ? (requestData?.university?.universityId) : (requestData?.universityId ? requestData?.universityId : ''),
                universityCode: isPlatformAdmin ? (requestData?.university?.universityCode) : (requestData?.universityCode ? requestData?.universityCode : ''),
                universityName: isPlatformAdmin ? (requestData?.university?.universityName) : (requestData?.universityName ? requestData?.universityName : ''),
                userFullName: requestData?.userFullName || '',
                userName: requestData?.userName || '',
                userType: isPlatformAdmin ? ERoleDesc.UNIVERSITYADMIN : (requestData?.roles?.roleCode || ''),
                designation: requestData?.designation || ''
            }

            let userUpdateComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.USER_MANAGEMENT, 'updateUser');
            console.log(`${tranId}createOrEditSingleUSersData_update_Api_Request=>`, { userUpdateComponentAndMethod, updateObject });
            let response = yield call(serviceConsumer, tranId, userUpdateComponentAndMethod, updateObject, null);
            console.log(`${tranId}__createOrEditSingleUSersData_Update_Api_Response=>`, response);
            if (response.status) {
                let usersDataresponse = yield call(getOnlyUSerData, tranId);
                usersData = usersDataresponse.usersData;
                alertMessageData = usersDataresponse.alertMessageData;

                if (!alertMessageData)
                    alertMessageData = {
                        message: response.messages ? response.messages : 'EUM10',
                        status: true,
                        tranId: Date.now(),
                        transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                        messageCode: response.messages ? tranId : getMessageCode(tranId, 'EUM10')
                    }
                else
                    alertMessageData = {
                        message: 'EUM27',
                        status: true,
                        tranId: Date.now(),
                        transKey: 'UsersManagement.alertMessages.',
                        messageCode: getMessageCode(tranId, 'EUM27')
                    };
            } else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'EUM11',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'EUM11')
                }
            }
        } catch (error) {
            console.log(`${tranId}_createOrEditSingleUSersData_error => `, error.messages ? error.messages : 'EUM12');
            console.log(`${tranId}_createOrEditSingleUSersData_catch=>`, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'EUM12',
                status: false,
                tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'EUM12'),

                transKey: error.messages ? 'controleErrors.' + error.messages : 'UsersManagement.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            }
        }
    }
    console.log(`${tranId}_createOrEditSingleUSersData_End`, usersData, alertMessageData);
    yield put(actions.createOrEditSingleUsersResponse(usersData, alertMessageData));
}

function* deleteUsersData(action) {
    let tranId = gettranId(EAPPModules.USERMANAGEMENTMODULE);
    console.log(`${tranId}_deleteUsersData_Start =>`, action);

    if (action.payload.requestType) {
        let alertMessageData: IAlertMessagedata | undefined;
        let usersData: IUser[] | undefined;
        try {
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.USER_MANAGEMENT, 'deleteUser');
            componentAndMethod.url = componentAndMethod.url.replace('{delete-userid}', action.payload.deleteUserId);
            componentAndMethod.url = componentAndMethod.url.replace('{traineeid}', action.payload.trId || '0');
            console.log(tranId + '_deleteUsersData_Api_Request => ', componentAndMethod, action.payload);
            const response = yield call(serviceConsumer, tranId, componentAndMethod, null, null);
            console.log(tranId + '_deleteUsersData_Api_Response => ', response);

            if (response.status) {
                usersData = ((yield select())['userManagementReducer'] as IUserManagementModel).usersData;
                if (usersData) {
                    let index = usersData?.findIndex(x => x.userId === action.payload.deleteUserId);
                    if (index !== -1) {
                        usersData.splice(index, 1);
                        usersData = usersData.slice();
                    }
                }
                alertMessageData = {
                    message: response.messages ? response.messages : "EUM13",
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response.messages ? undefined : getMessageCode(tranId, "EUM13")
                }
            }
            else
                alertMessageData = {
                    message: response.messages ? response.messages : "EUM14",
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, "EUM14")
                }
        }
        catch (error) {
            console.error(`${tranId}_deleteUsersData_error => `, error.messages ? error.messages : "SM9");
            console.log(`${tranId}_deleteUsersData_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'EUM15',
                status: false,
                tranId: Date.now(),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'UsersManagement.alertMessages.',
                messageCode: getMessageCode(tranId, 'EUM15'),

                statusCode: error.statuscode ? error.statuscode : 0
            }
        }

        console.log(`${tranId}_setUserStatusOrDelete_End => `, usersData, alertMessageData);
        yield put(actions.deleteUserDataResponse(usersData, alertMessageData));
    }
    else {
        let optionsData = [
            {
                title: 'Yes',
                function: actions.deleteUserDataRequest(action.payload.deleteUserId, true, action.payload.confirmMessage, action.payload.trId),
                loading: 1,
                className: 'btn-primary'
            },
            {
                title: 'No',
                loading: 0,
                className: 'btn-danger'
            }
        ] as IConfirmOptions[];

        let confirmModel = {
            title: action.payload.confirmMessage,
            options: optionsData,
            transKey: ''
        } as IConfirmModel;

        console.log(`${tranId}_setActionRequest_2=> `, action, confirmModel);
        yield put(setConfirmationOpen(confirmModel));
    }
}

// bulk upload new implementation
function* bulkUsersCreateRequest(action) {

    let tranId = gettranId(EAPPModules.USERMANAGEMENTMODULE);
    console.log(`${tranId}_bulkUsersCreateRequest_Start=> `, action);

    const { validFileData, inValidFileData, selectedRole, headerColumnMapping } = action.payload;
    let alertMessageData: IAlertMessagedata | undefined;
    let responseStatus: boolean = false;
    let userData: IUser[] | undefined;
    let failedDataFromApi: any[] | undefined;
    let totalInvalidFileData: any[] | undefined;
    let userDto: IUserDetails = ((yield select())['SessionState'] as ISessionstate).userDto;

    console.log(`${tranId}_bulkUsersCreateRequest_SheetData => `, { validFileData, inValidFileData });
    let createBulkUsers = {
        roleCode: selectedRole?.roleCode,
        roleId: selectedRole?.roleId,
        roleName: selectedRole?.roleName,
        universityId: userDto.university?.universityId,
        universityName: userDto.university?.universityName,
        universityCode: userDto.university?.universityCode,
        userType: selectedRole?.roleCode,
        users: validFileData
    }

    console.log(`${tranId}_bulkUsersCreateRequest_JsonStringfy =>`, { createBulkUsers, stringified: JSON.stringify(createBulkUsers) });

    try {
        let bulkUploadMethodAndComponent = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.USER_MANAGEMENT, 'bulkUserCreation');
        console.log(`${tranId}__bulkUsersCreateRequest_Api_Request =>`, bulkUploadMethodAndComponent, createBulkUsers);
        let response = yield call(serviceConsumer, tranId, bulkUploadMethodAndComponent, createBulkUsers, null);
        console.log(`${tranId}__bulkUsersCreateRequest_Api_Response =>`, response);
        if (response) {
            responseStatus = response.status;
            failedDataFromApi = response.failedUsers;

            alertMessageData = {
                message: bulkUploadRecordsCount(validFileData, inValidFileData, (failedDataFromApi || [])) || (response.status ? 'EUM16' : 'EUM17'),
                status: response.status,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'UsersManagement.alertMessages.',
                messageCode: response.messages ? (response.status ? undefined : tranId) : getMessageCode(tranId, response.status ? 'EUM16' : 'EUM17')
            }
        }
        totalInvalidFileData = _.concat(failedDataFromApi || [], inValidFileData);
        console.log('__totalInvalidFileData__', { totalInvalidFileData, failedDataFromApi, inValidFileData });

        if (totalInvalidFileData?.length) {
            totalInvalidFileData = totalInvalidFileData?.map(x => {
                const {
                    employeeId, resourceCode, trainee, failedReason,
                    roleId, roleCode, roleName, userType, universityId, universityName, mohId, isMohSupervisor, dob, departmentIds, programId, ...rest
                } = x;

                const { coEducationalSupervisor, educationalSupervisor, pathwayTag, trMohUser, trActiveFrom, trActiveTo, trStatus, ...trRest } = trainee ?? {};
                switch (x.userType) {
                    case ERoleDesc.Traninee: return { ...rest, dob: getModifiedDate(dob, false), trActiveFrom: getModifiedDate(trActiveFrom, false), trActiveTo: getModifiedDate(trActiveTo, false), ...trRest, failedReason }
                    case ERoleDesc.MOHSUPERVISOR: return { mohId, dob: getModifiedDate(dob, false), ...rest, failedReason }
                    case ERoleDesc.PROGRAMCOORDINATOR: return { ...rest, dob: getModifiedDate(dob, false), employeeId, failedReason };
                    case ERoleDesc.ROTATIONSUPERVISOR:
                    case ERoleDesc.EDUCATIONALSUPERVISOR: return {
                        ...rest,
                        dob: getModifiedDate(dob, false),
                        employeeId,
                        failedReason
                    }
                }
            })
            DownloadCsv(undefined, undefined, totalInvalidFileData, 'invalidUserData', undefined, headerColumnMapping);
            console.log("_totalInvalidFileData", { totalInvalidFileData, inValidFileData, failedDataFromApi });
        }
    }
    catch (error) {
        console.error(`${tranId}_bulkUsersCreateRequest_error => `, error.messages ? error.messages : 'EUM18');
        console.log(`${tranId}_bulkUsersCreateRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'EUM18',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'EUM18'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'UsersManagement.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    const responseUser = yield call(getOnlyUSerData, tranId);
    console.log(`${tranId}_bulkUsersCreateRequest_responseUser=> `, responseUser);
    if (!responseUser.alertMessageData)
        userData = responseUser.usersData;
    console.log(`${tranId}_bulkUsersCreateRequest_End=> `, userData, responseStatus, alertMessageData);
    yield put(actions.bulkUploadUSersDataResponse(userData, responseStatus, alertMessageData));
}

export function* watchUserManagement() {
    yield takeLeading(types.CREATE_OR_EDIT_SINGLE_USERS_REQUEST, createOrEditSingleUSersData);
    yield takeLeading(types.DELETE_USERS_DATA_REQUEST, deleteUsersData);
    yield takeLeading(types.BULK_UPLOAD_USER_DATA_REQUEST, bulkUsersCreateRequest);
    while (true) {
        const main = yield takeLeading(types.GET_ALL_USER_AND_ROLES_DATA_REQUEST, getUsersRolesDeptsPrgmsUniversitiesData)
        yield take(types.CANCEL_ALL_PENDING_USERS_REQUEST);
        yield cancel(main);
    }
}

function* userManagementSaga() {
    yield all([fork(watchUserManagement)]);
}
export default userManagementSaga;