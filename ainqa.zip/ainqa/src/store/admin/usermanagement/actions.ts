import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingUsersRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_USERS_REQUEST
    }
}

export const resetAllUserStateRequest = () => {
    return {
        type: types.RESET_ALL_USERS_STATE_REQUEST
    }
}
export const setUsersActionTypeData = (actionType, actionData) => {
    return {
        type: types.SET_USERS_ACTIONTYPE_DATA,
        payload: { actionType, actionData }
    }
}

export const setSearchUsersData = (value) => {
    return {
        type: types.SET_SEARCH_USER_DATA,
        payload: value
    }
}

export const getAllUsersDataRequest = () => {
    return {
        type: types.GET_ALL_USER_AND_ROLES_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const getAllUsersDataResponse = (isUniveristyAdminRole, usersData, universitiesData, currentDate, rolesData, deptsData, programsData, programmeCodeDetailsList, alertMessageData) => {
    return {
        type: types.GET_ALL_USER_AND_ROLES_DATA_RESPONSE,
        payload: { isUniveristyAdminRole, usersData, universitiesData, currentDate, rolesData, deptsData, programsData, programmeCodeDetailsList },
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}
export const createOrEditSingleUsersRequest = (requestData, requestType, isPlatformAdmin) => {
    return {
        type: types.CREATE_OR_EDIT_SINGLE_USERS_REQUEST,
        payload: { requestData, requestType, isPlatformAdmin },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const createOrEditSingleUsersResponse = (usersData, alertMessageData) => {
    return {
        type: types.CREATE_OR_EDIT_SINGLE_USERS_RESPONSE,
        payload: usersData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

export const setPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}

export const deleteUserDataRequest = (deleteUserId, requestType, confirmMessage, trId) => {
    return {
        type: types.DELETE_USERS_DATA_REQUEST,
        payload: { deleteUserId, requestType, confirmMessage, trId },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const deleteUserDataResponse = (usersData, alertMessageData) => {
    return {
        type: types.DELETE_USERS_DATA_RESPONSE,
        payload: usersData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

// new bulk upload action
export const bulkUploadUsersDataRequest = (selectedRole, validFileData, inValidFileData, headerColumnMapping) => {
    return {
        type: types.BULK_UPLOAD_USER_DATA_REQUEST,
        payload: { selectedRole, validFileData, inValidFileData, headerColumnMapping },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}

// old bulk upload action

// export const bulkUploadUsersDataRequest = (data) => {
//     return {
//         type: types.BULK_UPLOAD_USER_DATA_REQUEST,
//         payload: data,
//         loadType: ACTION_LOADING,
//         loadPayload: true
//     }
// }
export const bulkUploadUSersDataResponse = (usersData, responseStatus, alertMessageData) => {
    if (responseStatus) {
        return {
            type: types.BULK_UPLOAD_USER_DATA_RESPONSE,
            payload: usersData,
            loadType: ACTION_LOADING,
            loadPayload: false,
            alertMType: LAYOUT_ALERT_ACTION_REQUEST,
            alertMPayload: alertMessageData
        }
    } else {
        return {
            type: types.BULK_UPLOAD_USER_DATA_RESPONSE,
            loadType: ACTION_LOADING,
            loadPayload: false,
            alertMType: LAYOUT_ALERT_ACTION_REQUEST,
            alertMPayload: alertMessageData
        }
    }
}