import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../../../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingHospitalsRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_HOSPITALS_REQUEST
    }
}

export const resetAllHospitalsStateRequest = () => {
    return {
        type: types.RESET_ALL_HOSPITALS_STATE_REQUEST
    }
}

export const getHospitalsDataRequest = () => {
    return {
        type: types.GET_HOSPITALS_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true,
    }
}

export const getHospitalsDataResponce = (HospitalsData, alertMessageData) => {
    return {
        type: types.GET_HOSPITALS_DATA_RESPONCE,
        payload: HospitalsData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData

    }
}

export const setSearchHospitalsData = (value) => {
    return {
        type: types.SET_SEARCH_HOSPITALS_DATA,
        payload: value
    }
}

export const setHospitalsActionTypeData = (actionType, actionData) => {
    return {
        type: types.SET_HOSPITALS_ACTIONTYPE_DATA,
        payload: { actionType, actionData }
    }
}

export const createOrEditSingleHospitalsRequest = (requestData, requestType) => {
    return {
        type: types.CREATE_OR_EDIT_SINGLE_HOSPITALS_REQUEST,
        payload: { requestData, requestType },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const createOrEditSingleHospitalsResponse = (hospitalsData, alertMessageData) => {
    return {
        type: types.CREATE_OR_EDIT_SINGLE_HOSPITALS_RESPONSE,
        payload: hospitalsData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

export const deleteHospitalDataRequest = (deleteHospitalsId, requestType, confirmMessage) => {
    return {
        type: types.DELETE_HOSPITAL_DATA_REQUEST,
        payload: { deleteHospitalsId, requestType, confirmMessage },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const deleteHospitalDataResponse = (hospitalsData, alertMessageData) => {
    return {
        type: types.DELETE_HOSPITAL_DATA_RESPONSE,
        payload: hospitalsData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

export const getHospitalBulkuploadFileHisrotyRequest = () => {
    return {
        type: types.GET_HOSPITALS_BULKUPLOAD_FILE_HISTORY_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const getHospitalBulkuploadFileHisrotyResponse = (uploadedFilesInfo, alertMessageData) => {
    return {
        type: types.GET_HOSPITALS_BULKUPLOAD_FILE_HISTORY_RESPONCE,
        payload: uploadedFilesInfo,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}
export const setHospitalsPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_HOSPITALS_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}

export const createBulkUploadHospitalsDataRequest = (validFileData, inValidFileData, columnHeaderMapping, values = null) => ({
    type: types.CREATE_BULKUPLOAD_HOSPITALS_DATA_REQUEST,
    payload: { validFileData, inValidFileData, columnHeaderMapping, values },
    loadType: ACTION_LOADING,
    loadPayload: true,
});

export const createBulkUploadHospitalsDataResponse = (hospitalsData, responseStatus, alertMessageData) => ({
    type: types.CREATE_BULKUPLOAD_HOSPITALS_DATA_RESPONSE,
    payload: { hospitalsData, responseStatus },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});