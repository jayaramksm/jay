import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import * as actions from './actions';
import { bulkUploadRecordsCount, DownloadCsv, getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../../../helpers/helpersIndex';
import { EAPPModules, EOprationalActions, IAlertMessagedata, IConfirmModel, IConfirmOptions, EAPIComponentNames } from '../../../../models/utilitiesModel';
import { IHospaitalsModel, IHospital } from '../../../../models/hospaitalsModel';
import { setConfirmationOpen } from '../../../../store/actions';
import * as _ from 'lodash';

function* getOnlyHospitalData(tranId) {
    console.log(`${tranId}_getOnlyHospitalData_start =>`);
    let HospitalsData: IHospital | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        let HospitalsComponentAndMethospital = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HOSPITALS, 'getAllHospitals');
        console.log(tranId + '_getHospitals_Api_Request =>', HospitalsComponentAndMethospital);
        const response = yield call(serviceConsumer, tranId, HospitalsComponentAndMethospital, null, 'hospitals');
        console.log(tranId + '_getHospitals_Api_Response =>', response);

        if (response) {
            HospitalsData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'HOS1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOS1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getAllHospitalsData_error => `, error.messages ? error.messages : 'HOS2');
        console.log(`${tranId}_getAllHospitalsData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOS2',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'HOS2'),

            transKey: error.messages ? 'controleErrors.' + error.messages : 'Hospitals.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0

        }
    }
    console.log(`${tranId}_getOnlyHospitalData_end =>`, HospitalsData, alertMessageData);

    return { HospitalsData, alertMessageData }
}

function* getHospitalsData() {
    let tranId = gettranId(EAPPModules.HOSPITALSMODULE);

    console.log(`${tranId}_get_HospitalData_start =>`);
    let HospitalsData: IHospital[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        let HospitalDataresponse = yield call(getOnlyHospitalData, tranId);
        alertMessageData = HospitalDataresponse?.alertMessageData
        if (!alertMessageData)
            HospitalsData = HospitalDataresponse?.HospitalsData;
    }
    catch (error) {
        console.log(`${tranId}_getHospitalsData_error => `, error.messages ? error.messages : 'HOS2');
        console.log(`${tranId}_getHospitalsData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOS2',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'HOS2'),

            transKey: error.messages ? 'controleErrors.' + error.messages : 'Hospitals.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0

        }
    }
    console.log(`${tranId}_getOnlyHospitalData_end 11=>`, HospitalsData, alertMessageData);

    yield put(actions.getHospitalsDataResponce(HospitalsData, alertMessageData));

}


function* createOrEditSinglehospitalsData(action) {
    let tranId = gettranId(EAPPModules.HOSPITALSMODULE);
    console.log(`${tranId}_createOrEditSinglehospitalsData_start =>`, action, action.payload.requestData);
    let hospitalsData: IHospital[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const requestData = action.payload.requestData
    if (action.payload.requestType === EOprationalActions.ADD) {
        try {
            let createobject = {
                contactName: requestData.contactName,
                contactNum: requestData.contactNumber,
                emailId: requestData.email,
                hospitalCode: requestData.hospCode,
                hospitalName: requestData.hospName,
                location: requestData.location
            }
            console.log(`${tranId}_createOrEditSinglehospitalsData_stringify =>`, { createobject, stringify: JSON.stringify(createobject) });

            let hospitalCreateComponentAndMethospital = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HOSPITALS, 'createHospital');
            console.log(`${tranId}_createOrEditSinglehospitalsData_Api_Request =>`, hospitalCreateComponentAndMethospital, createobject);
            let response = yield call(serviceConsumer, tranId, hospitalCreateComponentAndMethospital, createobject, null)
            console.log(`${tranId}_createOrEditSinglehospitalsData_Api_Response`, response);
            if (response.status) {
                let hospitalsDataresponse = yield call(getOnlyHospitalData, tranId);
                alertMessageData = hospitalsDataresponse?.alertMessageData

                if (!alertMessageData) {
                    hospitalsData = hospitalsDataresponse?.HospitalsData;
                }
                if (!hospitalsDataresponse.alertMessageData)
                    alertMessageData = {
                        message: response.messages ? response.messages : 'HOS3',
                        status: true,
                        tranId: Date.now(),
                        transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                        messageCode: response.messages ? undefined : tranId + 'HOS3'
                    }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'HOS4',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOS4')
                }
            }
        } catch (error) {
            console.log(`${tranId}_createOrEditSinglehospitalsData_error => `, error.messages ? error.messages : 'HOS5');
            console.log(`${tranId}_createOrEditSinglehospitalsData_catch=>`, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'HOS5',
                status: false,
                tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'HOS5'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Hospitals.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            }
        }
    } else {
        try {
            let updateObject = {
                contactName: requestData.contactName,
                contactNum: requestData.contactNumber,
                emailId: requestData.email,
                hospitalCode: requestData.hospCode,
                hospitalName: requestData.hospName,
                location: requestData.location,
                hospitalId: requestData.id
            }
            console.log(`${tranId}createOrEditSinglehospitalsData_stringify =>`, JSON.stringify(updateObject));

            let hospitalUpdateComponentAndMethospital = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HOSPITALS, 'updateHospital');
            console.log(`${tranId}createOrEditSinglehospitalsData_update_Api_Request=>`, updateObject, hospitalUpdateComponentAndMethospital);
            let response = yield call(serviceConsumer, tranId, hospitalUpdateComponentAndMethospital, updateObject, null);
            console.log(`${tranId}__createOrEditSinglehospitalsData_Update_Api_Response=>`, response);
            if (response.status) {
                let hospitalsDataresponse = yield call(getOnlyHospitalData, tranId);
                alertMessageData = hospitalsDataresponse?.alertMessageData

                if (!alertMessageData) {
                    hospitalsData = hospitalsDataresponse?.HospitalsData;
                }
                if (!hospitalsDataresponse.alertMessageData)
                    alertMessageData = {
                        message: response.messages ? response.messages : 'HOS6',
                        status: true,
                        tranId: Date.now(),
                        transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                        messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOS6')
                    }
            } else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'HOS7',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOS7')
                }
            }
        } catch (error) {
            console.log(`${tranId}_createOrEditSinglehospitalsData_error => `, error.messages ? error.messages : 'HOS8');
            console.log(`${tranId}_createOrEditSinglehospitalsData_catch=>`, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'HOS8',
                status: false,
                tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'HOS8'),

                transKey: error.messages ? 'controleErrors.' + error.messages : 'Hospitals.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            }
        }
    }
    console.log(`${tranId}_createOrEditSinglehospitalsData_End`, hospitalsData, alertMessageData);
    yield put(actions.createOrEditSingleHospitalsResponse(hospitalsData, alertMessageData));
}



function* bulkUploadHospitalCreateDataRequest(action) {
    let tranId = gettranId(EAPPModules.PROGRAMSMODULE);
    console.log(`_${tranId}_bulkUploadHospitalCreateDataRequest_start===>`, action);

    let { validFileData, inValidFileData, columnHeaderMapping } = action.payload;


    let hospitalsDetails: IHospital[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let responseStatus: boolean = false;
    let failedDataFromApi: any[] | undefined;
    let totalInvalidFileData: any[] | undefined;

    let createBulkUsers = validFileData?.map(x => ({
        contactName: x[columnHeaderMapping.contactName] || '',
        contactNum: x[columnHeaderMapping.contactNum] || '',
        emailId: x[columnHeaderMapping.emailId] || '',
        hospitalCode: x[columnHeaderMapping.hospitalCode] || '',
        hospitalName: x[columnHeaderMapping.hospitalName] || '',
        location: x[columnHeaderMapping.location] || ''
    }))

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HOSPITALS, 'createBulkHospital');
        console.log(`_${tranId}_bulkUploadHospitalCreateDataRequest_Api_request===>`, componentAndMethod, createBulkUsers);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, { hospitals: createBulkUsers }, '');
        console.log(`_${tranId}_bulkUploadHospitalCreateDataRequest_Api_Response===>`, response);
        if (response) {
            responseStatus = response.status;
            failedDataFromApi = response.failedHospitals;

            alertMessageData = {
                message: bulkUploadRecordsCount(validFileData, inValidFileData, (failedDataFromApi || [])) || (response.status ? 'HOS3' : 'HOS3'),
                status: response.status,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                messageCode: response.messages ? (response.status ? undefined : tranId) : getMessageCode(tranId, response.status ? 'PAM14' : 'PAM15')
            }
            totalInvalidFileData = (failedDataFromApi || []).concat(inValidFileData);
            if (totalInvalidFileData?.length > 0) {
                totalInvalidFileData = totalInvalidFileData?.map(x => ({
                    contactName: x[columnHeaderMapping.contactName] ?? x.contactName,
                    contactNum: x[columnHeaderMapping.contactNum] ?? x.contactNum,
                    emailId: x[columnHeaderMapping.emailId] ?? x.emailId,
                    hospitalCode: x[columnHeaderMapping.hospitalCode] ?? x.hospitalCode,
                    hospitalName: x[columnHeaderMapping.hospitalName] ?? x.hospitalName,
                    location: x[columnHeaderMapping.location] ?? x.location,
                    failedReason: x.failedReason
                }));
            }
            console.log('__totalInvalidFileData__', { totalInvalidFileData, failedDataFromApi, inValidFileData });

            if (totalInvalidFileData?.length) {
                DownloadCsv(undefined, undefined, totalInvalidFileData, 'invalidHospitalsData', undefined, columnHeaderMapping);
                console.log("_totalInvalidFileData", { totalInvalidFileData, inValidFileData, failedDataFromApi });
            }
        }
        else {
            alertMessageData = {
                message: response.messages || 'HOS4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOS4')
            }
        }
    }
    catch (error) {
        console.error(`${tranId}_bulkUploadHospitalCreateDataRequest_error => `, error.messages ? error.messages : 'PAM16');
        console.log(`${tranId}_bulkUploadHospitalCreateDataRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOS5',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'HOS5'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Hospitals.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    if (responseStatus) {
        const responseUser = yield call(getOnlyHospitalData, tranId);
        console.log(`${tranId}_bulkUploadHospitalCreateDataRequest_responseUser=> `, responseUser);
        if (!responseUser.alertMessageData) {
            hospitalsDetails = responseUser.HospitalsData;
        }
    }
    console.log(`_${tranId}_bulkUploadHospitalCreateDataRequest_Api_End===>`, hospitalsDetails, alertMessageData);
    yield put(actions.createBulkUploadHospitalsDataResponse(hospitalsDetails, responseStatus, alertMessageData));
}


function* deleteHospitalsData(action) {
    let tranId = gettranId(EAPPModules.HOSPITALSMODULE);
    console.log(`${tranId}_deleteHospitalsData_Start =>`, action);

    if (action.payload.requestType) {
        let alertMessageData: IAlertMessagedata | undefined;
        let hospitalsData: IHospital[] | undefined;
        try {
            let componentAndMetHospital = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HOSPITALS, 'deleteHospital');
            componentAndMetHospital.url = componentAndMetHospital.url.replace('{hospitalid}', action.payload.deleteHospitalsId);
            console.log(tranId + '_deleteHospitalsData_Api_Request => ', componentAndMetHospital, action.payload);
            const response = yield call(serviceConsumer, tranId, componentAndMetHospital, null, null);
            console.log(tranId + '_deleteHospitalsData_Api_Response => ', response);

            if (response.status) {
                let HospitalsDataModel = ((yield select())['hospitalsReducer'] as IHospaitalsModel).HospitalsData;
                hospitalsData = HospitalsDataModel;
                if (hospitalsData) {
                    let index = hospitalsData?.findIndex(x => x.hospitalId === action.payload.deleteHospitalsId);
                    if (index !== -1) {
                        hospitalsData.splice(index, 1);
                        hospitalsData = hospitalsData.slice();
                    }
                }
                alertMessageData = {
                    message: response.messages ? response.messages : "HOS9",
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                    messageCode: response.messages ? undefined : getMessageCode(tranId, "HOS9")
                }
            }
            else
                alertMessageData = {
                    message: response.messages ? response.messages : "HOS10",
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hospitals.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, "HOS10")
                }
        }
        catch (error) {
            console.error(`${tranId}_deleteHospitalsData_error => `, error.messages ? error.messages : "HOS11");
            console.log(`${tranId}_deleteHospitalsData_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'HOS11',
                status: false,
                tranId: Date.now(),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Hospitals.alertMessages.',
                messageCode: getMessageCode(tranId, 'HOS11'),
                statusCode: error.statuscode ? error.statuscode : 0
            }
        }

        console.log(`${tranId}_setHospitalstatusOrDelete_End => `, hospitalsData, alertMessageData);
        yield put(actions.deleteHospitalDataResponse(hospitalsData, alertMessageData));
    }
    else {
        let optionsData = [
            {
                title: 'Yes',
                function: actions.deleteHospitalDataRequest(action.payload.deleteHospitalsId, true, action.payload.confirmMessage),
                loading: 1,
                className: 'btn-primary'
            },
            {
                title: 'No',
                loading: 0,
                className: 'btn-danger'
            }
        ] as IConfirmOptions[];

        let confirmModel = {
            title: action.payload.confirmMessage,
            options: optionsData,
            transKey: ''
        } as IConfirmModel;

        console.log(`${tranId}_setActionRequest_2=> `, action, confirmModel);
        yield put(setConfirmationOpen(confirmModel));
    }
}

function* getHospitalBulkuploadFileHisrotyRequest(action) {
    let tranId = gettranId(EAPPModules.HOSPITALSMODULE);

    console.log(`${tranId}_getHospitalBulkuploadFileHisrotyRequest_start =>`, action);
    let uploadedFilesInfo: any;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        // let HospitalsComponentAndMetHospital = getApiServiceUrlByComponentAndMethod(component, 'getAllHospitals');
        // console.log(tranId + '_getHospitalBulkuploadFileHisrotyRequest_Api_Request =>', HospitalsComponentAndMetHospital);
        // const response = yield call(serviceConsumer, tranId, HospitalsComponentAndMetHospital, null, 'Hospitals');
        // console.log(tranId + '_getHospitalBulkuploadFileHisrotyRequest_Api_Response =>', response);

        if (true) {
            const response = [
                {
                    fileName: "HospitalCsv_01.csv",
                    sheetCount: "02",
                    dateandTime: "24-05-2021, 03.30pm"
                },

                {
                    fileName: "HospitalCsv_03.csv",
                    sheetCount: "03",
                    dateandTime: "25-0^-2021, 04.30pm"
                },
                {
                    fileName: "HospitalCsv_04.csv",
                    sheetCount: "04",
                    dateandTime: "26-05-2021, 03.30pm"
                },
                {
                    fileName: "HospitalCsv_05.csv",
                    sheetCount: "05",
                    dateandTime: "24-05-2021, 03.30pm"
                },
                {
                    fileName: "HospitalCsv_06.csv",
                    sheetCount: "06",
                    dateandTime: "24-05-2021, 03.30pm"
                }

            ]
            uploadedFilesInfo = response;
        }
        else {
            // alertMessageData = {
            //     message: response.messages ? response.messages : 'HOS12',
            //     status: false,
            //     tranId: Date.now(),
            //     transKey: response.messages ? '' : 'Hospitals.alertMessages.',
            //     messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOS12')
            // }
        }
    } catch (error) {
        console.log(`${tranId}_getHospitalBulkuploadFileHisrotyRequest_error => `, error.messages ? error.messages : 'HOS13');
        console.log(`${tranId}_getHospitalBulkuploadFileHisrotyRequest_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOS13',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'HOS13'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Hospitals.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        }
    }
    console.log(`${tranId}_getHospitalBulkuploadFileHisrotyRequest_end =>`, uploadedFilesInfo, alertMessageData);
    yield put(actions.getHospitalBulkuploadFileHisrotyResponse(uploadedFilesInfo, alertMessageData));


}

export function* watchHospital() {
    yield takeLeading(types.CREATE_OR_EDIT_SINGLE_HOSPITALS_REQUEST, createOrEditSinglehospitalsData);
    yield takeLeading(types.DELETE_HOSPITAL_DATA_REQUEST, deleteHospitalsData);
    yield takeLeading(types.GET_HOSPITALS_BULKUPLOAD_FILE_HISTORY_REQUEST, getHospitalBulkuploadFileHisrotyRequest);
    yield takeLeading(types.CREATE_BULKUPLOAD_HOSPITALS_DATA_REQUEST, bulkUploadHospitalCreateDataRequest);
    while (true) {
        const main = yield takeLeading(types.GET_HOSPITALS_DATA_REQUEST, getHospitalsData)
        yield take(types.CANCEL_ALL_PENDING_HOSPITALS_REQUEST);
        yield cancel(main);
    }
}

function* hospitalsSaga() {
    yield all([fork(watchHospital)]);
}

export default hospitalsSaga;