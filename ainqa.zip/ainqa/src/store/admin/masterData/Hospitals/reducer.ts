import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IHospaitalsModel } from '../../../../models/hospaitalsModel';
import * as types from './actionTypes';

const initialState = {} as IHospaitalsModel

const hospitalsReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.RESET_ALL_HOSPITALS_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefined,
                actionType: EOprationalActions.UNSELECT,
                searchKey: '',
                uploadedFilesInfo: undefined,
                HospitalsData: undefinedData
            }
            break;
        case types.GET_HOSPITALS_DATA_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    HospitalsData: action.payload
                }
            break;
        case types.SET_SEARCH_HOSPITALS_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.SET_HOSPITALS_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
                searchKey: '',

            }
            break;

        case types.CREATE_OR_EDIT_SINGLE_HOSPITALS_RESPONSE:

            if (action.payload)
                state = {
                    ...state,
                    HospitalsData: action.payload,
                    actionType: EOprationalActions.UNSELECT,

                }
            break;

        case types.DELETE_HOSPITAL_DATA_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    HospitalsData: action.payload
                }
            break;
        case types.GET_HOSPITALS_BULKUPLOAD_FILE_HISTORY_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    uploadedFilesInfo: action.payload
                }
            break;
        case types.SET_HOSPITALS_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.CREATE_BULKUPLOAD_HOSPITALS_DATA_RESPONSE:
            if (action.payload.responseStatus)
                state = {
                    ...state,
                    HospitalsData: action.payload.hospitalsData,
                    actionType: EOprationalActions.UNSELECT

                };
            break;

        default: state = { ...state }
    }
    return state;
}

export default hospitalsReducer;