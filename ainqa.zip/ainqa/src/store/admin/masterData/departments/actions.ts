import { ACTION_LOADING, LAYOUT_ALERT_ACTION_REQUEST } from '../../../../store/layout/actionTypes';
import * as types from './actionTypes';

export const setResetMasterDataDepartmentsStateRequest = () => ({
    type: types.SET_RESET_MASTER_DATA_DEPARTMENTS_STATE_REQUEST
});

export const setActionTypeInDepartments = (actionType, actionData = null) => ({
    type: types.SET_ACTION_TYPE_IN_DEPARTMENTS,
    payload: { actionType, actionData }
});


export const setSearchKeyInDepartments = (searchkey) => ({
    type: types.SET_SEARCH_KEY_IN_DEPARTMENTS,
    payload: searchkey
});

export const setPaginationCurrentPageValueInDepartments = (currentPage) => ({
    type: types.SET_PAGINATION_CURRENT_PAGE_IN_DEPARTMENTS,
    payload: currentPage
});

export const getAllDepartmentsDetailsRequest = (isInitialRequest = false) => ({
    type: types.GET_ALL_DEPARTMENTS_DETAILS_REQUEST,
    payload: isInitialRequest,
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getAllDepartmentsDetailsResponse = (departmentsDetails, alertMessageData) => ({
    type: types.GET_ALL_DEPARTMENTS_DETAILS_RESPONSE,
    payload: departmentsDetails,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const getDeleteDepartmentFromDepartmentsDetailsRequest = (deptId, requestType, confirmMessage) => ({
    type: types.GET_DELETE_DEPARTMENT_FROM_DEPARTMENTS_DETAILS_REQUEST,
    payload: { deptId, requestType, confirmMessage },
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getDeleteDepartmentFromDepartmentsDetailsResponse = (departmentsDetails, alertMessageData) => ({
    type: types.GET_DELETE_DEPARTMENT_FROM_DEPARTMENTS_DETAILS_RESPONSE,
    payload: departmentsDetails,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const getAddOrEditDepartmentRquest = (departmentDetails, actionType) => ({
    type: types.GET_ADD_OR_EDIT_DEPARTMENTS_REQUEST,
    payload: { departmentDetails, actionType },
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getAddOrEditDepartmentResponse = (departmentsDetails, requestStatus, alertMessageData) => ({
    type: types.GET_ADD_OR_EDIT_DEPARTMENTS_RESPONSE,
    payload: { departmentsDetails, requestStatus },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const getFileUploadsHistoryInDepartmentsRequest = () => ({
    type: types.GET_FILE_UPLOADS_HISTORY_IN_DEPARTMENTS_REQUEST,
    payload: '',
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getFileUploadsHistoryInDepartmentsResponse = (fileUploadHistory, alertMessageData) => ({
    type: types.GET_FILE_UPLOADS_HISTORY_IN_DEPARTMENTS_RESPONSE,
    payload: fileUploadHistory,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const createBulkUploadDepartmentsDataRequest = (validFileData, inValidFileData, columnHeaderMapping) => ({
    type: types.CREATE_BULKUPLOAD_DEPARTMENTS_DATA_REQUEST,
    payload: { validFileData, inValidFileData, columnHeaderMapping },
    loadType: ACTION_LOADING,
    loadPayload: true,
});

export const createBulkUploadDepartmentsDataResponse = (departmentsData, responseStatus, alertMessageData) => ({
    type: types.CREATE_BULKUPLOAD_DEPARTMENTS_DATA_RESPONSE,
    payload: { departmentsData, responseStatus },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const cancelAllPendingDepartmentsRequest = () => ({
    type: types.CANCEL_ALL_PENDING_DEPARTMENTS_REQUEST
});