import { takeLeading, put, all, fork, call, select, take, cancel } from 'redux-saga/effects';
import * as types from './actionTypes';
import * as actions from './actions';
import { getApiServiceUrlByComponentAndMethod, serviceConsumer, getMessageCode, gettranId, DownloadCsv, bulkUploadRecordsCount } from '../../../../helpers/helpersIndex';
import { EOprationalActions, IAlertMessagedata, EAPPModules, IConfirmOptions, IConfirmModel, EAPIComponentNames } from '../../../../models/utilitiesModel';
import { IDepartments, IDepartmentsMOdel } from '../../../../models/departmentsModel';
import { setConfirmationOpen } from '../../../../store/actions';

function* getAllDepartmentsDetailsRequest(action) {
    let tranId = gettranId(EAPPModules.DEPARTMENTSMODULE);
    const isInitialRequest = action.payload;
    console.log(`_${tranId}_getAllDepartmentsDetailsRequest_start===>`,);

    let departmentsDetails: IDepartments[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'getAllDepartments');
        console.log(`_${tranId}_getAllDepartmentsDetailsRequest_Api_request===>`, componentAndMethod);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, null, "departments");
        console.log(`_${tranId}_getAllDepartmentsDetailsRequest_Api_Response===>`, response);
        if (response) {
            departmentsDetails = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'DAM1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Departments.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM1')
            }

        }

    } catch (error) {
        console.error(`${tranId}_getAllDepartmentsDetailsRequest_error => `, error.messages ? error.messages : 'DAM2');
        console.log(`${tranId}_getAllDepartmentsDetailsRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'DAM2',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'DAM2'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Departments.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`_${tranId}_getAllDepartmentsDetailsRequest_Api_End===>`, departmentsDetails, alertMessageData);

    if (isInitialRequest)
        yield put(actions.getAllDepartmentsDetailsResponse(departmentsDetails, alertMessageData));

    return { departmentsDetails, alertMessageData };
}


function* getDeleteDepartmentFromDepartmentsDetails(action) {

    let tranId = gettranId(EAPPModules.DEPARTMENTSMODULE);
    console.log(`_${tranId}_getDeleteDepartmentFromDepartmentsDetails_start===>`, action);

    let departmentsDetails: IDepartments[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let { deptId, requestType, confirmMessage } = action.payload;

    if (requestType) {
        try {
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'deleteDepartment');
            componentAndMethod.url = componentAndMethod.url.replace('{deptid}', deptId);
            console.log(`_${tranId}_getDeleteDepartmentFromDepartmentsDetails_Api_request===>`, componentAndMethod);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, null, null);
            console.log(`_${tranId}_getDeleteDepartmentFromDepartmentsDetails_Api_Response===>`, response);
            if (response.status) {
                departmentsDetails = ((yield select())['departmentsReducer'] as IDepartmentsMOdel).departmentsDetails;
                let ind = departmentsDetails?.findIndex(x => x.departmentId === deptId);
                if (ind !== -1) departmentsDetails.splice(ind, 1);
                alertMessageData = {
                    message: response.messages ? response.messages : "DAM3",
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Departments.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM3')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'DAM4',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Departments.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM4')
                }

            }

        } catch (error) {
            console.error(`${tranId}_getDeleteDepartmentFromDepartmentsDetails_error => `, error.messages ? error.messages : 'DAM5');
            console.log(`${tranId}_getDeleteDepartmentFromDepartmentsDetails_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'DAM5',
                status: false, tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'DAM5'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Departments.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
        console.log(`_${tranId}_getDeleteDepartmentFromDepartmentsDetails_Api_End===>`, departmentsDetails, alertMessageData);
        yield put(actions.getDeleteDepartmentFromDepartmentsDetailsResponse(departmentsDetails, alertMessageData));
    } else {
        let optionsData = [
            {
                title: 'Yes',
                function: actions.getDeleteDepartmentFromDepartmentsDetailsRequest(deptId, true, confirmMessage),
                loading: 1,
                className: 'btn-primary'
            },
            {
                title: 'No',
                loading: 0,
                className: 'btn-danger'
            }
        ] as IConfirmOptions[];

        let confirmModel = {
            title: action.payload.confirmMessage,
            options: optionsData,
            transKey: ''
        } as IConfirmModel;

        console.log(`${tranId}_setActionRequest_2=> `, action, confirmModel);
        yield put(setConfirmationOpen(confirmModel));
    }
}

function* getAddOrEditDepartment(action) {

    let tranId = gettranId(EAPPModules.DEPARTMENTSMODULE);
    console.log(`_${tranId}_getAddOrEditDepartment_start===>`, action);

    let updatedDepartmentsDetails: IDepartments[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let requestStatus: boolean = false;
    let { departmentDetails, actionType } = action.payload;

    if (actionType === EOprationalActions.ADD) {
        try {
            let createDepartment = {
                departmentName: departmentDetails?.deptName || '',
                departmentCode: departmentDetails?.deptCode || '',
                location: departmentDetails?.location || ''
            }
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'createDepartment');
            console.log(`_${tranId}_getAddOrEditDepartment_Api_request===>`, componentAndMethod, createDepartment);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, createDepartment, null);
            console.log(`_${tranId}_getAddOrEditDepartment_Api_Response===>`, response);
            if (response.status) {
                let updatedDepartmentsDetailsresponse = yield call(getAllDepartmentsDetailsRequest, tranId);
                alertMessageData = updatedDepartmentsDetailsresponse?.alertMessageData;
                if (!alertMessageData)
                    updatedDepartmentsDetails = updatedDepartmentsDetailsresponse?.departmentsDetails;
                requestStatus = true;
                alertMessageData = {
                    message: response.messages ? response.messages : "DAM6",
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Departments.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM6')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'DAM7',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Departments.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM7')
                }

            }

        } catch (error) {
            console.error(`${tranId}_getAddOrEditDepartment_error => `, error.messages ? error.messages : 'DAM8');
            console.log(`${tranId}_getAddOrEditDepartment_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'DAM8',
                status: false, tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'DAM8'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Departments.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
    } else {
        try {
            let updateDepartment = {
                departmentName: departmentDetails?.deptName || '',
                departmentCode: departmentDetails?.deptCode || '',
                location: departmentDetails?.location || '',
                departmentId: departmentDetails.id,
            }
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'updateDepartment');
            componentAndMethod.url = componentAndMethod.url.replace('{id}', departmentDetails?.id);
            console.log(`_${tranId}_getAddOrEditDepartment_Api_request===>`, componentAndMethod, updateDepartment);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, updateDepartment, null);
            console.log(`_${tranId}_getAddOrEditDepartment_Api_Response===>`, response);
            if (response.status) {
                requestStatus = true;
                let updatedDepartmentsDetailsresponse = yield call(getAllDepartmentsDetailsRequest, tranId);
                alertMessageData = updatedDepartmentsDetailsresponse?.alertMessageData;
                if (!alertMessageData)
                    updatedDepartmentsDetails = updatedDepartmentsDetailsresponse?.departmentsDetails;
                alertMessageData = {
                    message: response.messages ? response.messages : "DAM9",
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Departments.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM9')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'DAM10',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Departments.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM10')
                }
            }

        } catch (error) {
            console.error(`${tranId}_getAddOrEditDepartment_error => `, error.messages ? error.messages : 'DAM11');
            console.log(`${tranId}_getAddOrEditDepartment_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'DAM11',
                status: false,
                tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'DAM11'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Departments.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
    }
    console.log(`_${tranId}_getAddOrEditDepartment_Api_End===>`, updatedDepartmentsDetails, alertMessageData);
    yield put(actions.getAddOrEditDepartmentResponse(updatedDepartmentsDetails, requestStatus, alertMessageData));
}

function* getFileUploadHistory() {

    let tranId = gettranId(EAPPModules.PROGRAMSMODULE);
    console.log(`_${tranId}_getFileUploadHistory_start===>`,);

    let fileUploadHistory: any | undefined;
    let alertMessageData: IAlertMessagedata | undefined

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'getFileUploadHistory');
        console.log(`_${tranId}_getFileUploadHistory_Api_request===>`, componentAndMethod);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, null, null);
        console.log(`_${tranId}_getFileUploadHistory_Api_Response===>`, response);
        if (response) {
            fileUploadHistory = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'DAM12',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Departments.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM12')
            }

        }

    } catch (error) {
        console.error(`${tranId}_getFileUploadHistory_error => `, error.messages ? error.messages : 'DAM13');
        console.log(`${tranId}_getFileUploadHistory_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'DAM13',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'DAM13'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Departments.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`_${tranId}_getFileUploadHistory_Api_End===>`, fileUploadHistory, alertMessageData);
    yield put(actions.getFileUploadsHistoryInDepartmentsResponse(fileUploadHistory, alertMessageData));
}

function* bulkUploadDepartmentsCreateDataRequest(action) {
    let tranId = gettranId(EAPPModules.DEPARTMENTSMODULE);
    console.log(`_${tranId}_bulkUploadDepartmentsCreateDataRequest_start===>`, action);

    let { validFileData, inValidFileData, columnHeaderMapping } = action.payload;

    let departmentDetails: IDepartments[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let responseStatus: boolean = false;
    let failedDataFromApi: any[] | undefined;
    let totalInvalidFileData: any[] | undefined;

    let createBulkUsers = validFileData?.map(x => ({
        departmentName: x[columnHeaderMapping.departmentName],
        departmentCode: x[columnHeaderMapping.departmentCode],
        location: x[columnHeaderMapping.location]
    }));

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'createBulkDepartment');
        console.log(`_${tranId}_bulkUploadDepartmentsCreateDataRequest_Api_request===>`, componentAndMethod, createBulkUsers);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, { departments: createBulkUsers }, null);
        console.log(`_${tranId}_bulkUploadDepartmentsCreateDataRequest_Api_Response===>`, response);

        if (response) {
            responseStatus = response.status;
            failedDataFromApi = response.departments;

            alertMessageData = {
                message: bulkUploadRecordsCount(validFileData, inValidFileData, (failedDataFromApi || [])) || (response.status ? 'DAM14' : 'DAM15'),
                status: response.status,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Departments.alertMessages.',
                messageCode: response.messages ? (response.status ? undefined : tranId) : getMessageCode(tranId, response.status ? 'DAM14' : 'DAM15')
            }

            if (inValidFileData?.length) {
                inValidFileData = inValidFileData.map(x => ({
                    departmentName: x[columnHeaderMapping.departmentName],
                    departmentCode: x[columnHeaderMapping.departmentCode],
                    location: x[columnHeaderMapping.location],
                    failedReason: x.failedReason
                }))
            }

            totalInvalidFileData = (failedDataFromApi || []).concat(inValidFileData);
            console.log('__totalInvalidFileData__', { totalInvalidFileData, failedDataFromApi, inValidFileData });

            if (totalInvalidFileData?.length) {
                DownloadCsv(undefined, undefined, totalInvalidFileData, 'invalidDepartmentsData', undefined, columnHeaderMapping);
                console.log("_totalInvalidFileData", { totalInvalidFileData, inValidFileData, failedDataFromApi });
            }
        }
        else {
            alertMessageData = {
                message: response.messages || 'DAM15',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Departments.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'DAM15')
            }
        }
    } catch (error) {
        console.error(`${tranId}_bulkUploadDepartmentsCreateDataRequest_error => `, error.messages || 'DAM16');
        console.log(`${tranId}_bulkUploadDepartmentsCreateDataRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'DAM16',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'DAM16'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Departments.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    if (responseStatus) {
        const response = yield call(getAllDepartmentsDetailsRequest, { payload: false });
        console.log(`${tranId}_bulkUploadDepartmentsCreateDataRequest_responseUser=> `, response);

        if (!response.alertMessageData)
            departmentDetails = response.departmentsDetails;
    }
    console.log(`_${tranId}_bulkUploadDepartmentsCreateDataRequest_Api_End===>`, departmentDetails, alertMessageData);
    yield put(actions.createBulkUploadDepartmentsDataResponse(departmentDetails, responseStatus, alertMessageData));
}

export function* watchDepartments() {
    yield takeLeading(types.GET_DELETE_DEPARTMENT_FROM_DEPARTMENTS_DETAILS_REQUEST, getDeleteDepartmentFromDepartmentsDetails);
    yield takeLeading(types.GET_ADD_OR_EDIT_DEPARTMENTS_REQUEST, getAddOrEditDepartment);
    yield takeLeading(types.GET_FILE_UPLOADS_HISTORY_IN_DEPARTMENTS_REQUEST, getFileUploadHistory);
    yield takeLeading(types.CREATE_BULKUPLOAD_DEPARTMENTS_DATA_REQUEST, bulkUploadDepartmentsCreateDataRequest);

    while (true) {
        const main = yield takeLeading(types.GET_ALL_DEPARTMENTS_DETAILS_REQUEST, getAllDepartmentsDetailsRequest);
        yield take(types.CANCEL_ALL_PENDING_DEPARTMENTS_REQUEST);
        yield cancel(main);
    }
}

function* departmentsSaga() {
    yield all([fork(watchDepartments)]);
}

export default departmentsSaga;