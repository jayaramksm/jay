import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IDepartmentsMOdel } from '../../../../models/departmentsModel';
import * as types from './actionTypes';

const initialState = {} as IDepartmentsMOdel;
const departmentsReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.SET_RESET_MASTER_DATA_DEPARTMENTS_STATE_REQUEST:
            state = {
                ...state,
                actionType: EOprationalActions.UNSELECT,
                actionData: undefinedData,
                searchKey: '',
                paginationCurrentPage: 0,
                departmentsDetails: undefinedData
            }
            break;
        case types.SET_ACTION_TYPE_IN_DEPARTMENTS:
            state = {
                ...state,
                actionType: action.payload.actionType,
                actionData: action.payload.actionData,
                searchKey: ''
            }
            break;
        case types.GET_ALL_DEPARTMENTS_DETAILS_RESPONSE:
            state = {
                ...state,
                departmentsDetails: action.payload
            }
            break;
        case types.SET_SEARCH_KEY_IN_DEPARTMENTS:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.SET_PAGINATION_CURRENT_PAGE_IN_DEPARTMENTS:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.GET_DELETE_DEPARTMENT_FROM_DEPARTMENTS_DETAILS_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    departmentsDetails: action.payload
                }
            break;
        case types.GET_ADD_OR_EDIT_DEPARTMENTS_RESPONSE:
            if (action.payload.requestStatus)
                state = {
                    ...state,
                    departmentsDetails: action.payload.departmentsDetails,
                    actionType: EOprationalActions.UNSELECT
                }
            break;
        case types.GET_FILE_UPLOADS_HISTORY_IN_DEPARTMENTS_RESPONSE:
            state = {
                ...state,
                fileUploadHistory: action.payload
            }
            break;
        case types.CREATE_BULKUPLOAD_DEPARTMENTS_DATA_RESPONSE:
            if (action.payload.responseStatus)
                state = {
                    ...state,
                    departmentsDetails: action.payload.departmentsData,
                    actionType: EOprationalActions.UNSELECT
                }
            break;
        default: state = { ...state }
    }
    return state;
}
export default departmentsReducer;