import { EOprationalActions } from '../../../../models/utilitiesModel';
import * as types from './actionTypes';
import { IHodsModel } from 'models/hodsModel';

const initialState = {} as IHodsModel

const hodsReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.RESET_ALL_HODS_STATE_REQUEST:
            state = {
                ...state,
                hodsData: undefinedData,
                departmentData: undefinedData,
                actionType: EOprationalActions.UNSELECT,
                actionData: undefinedData,
                searchKey: '',
                paginationCurrentPage: 0
            }
            break;
        case types.GET_HODS_AND_DEPARTMENT_DATA_RESPONCE:
            state = {
                ...state,
                hodsData: action.payload.hodsData,
                departmentData: action.payload.departmentData
            }
            break;
        case types.CREATE_OR_EDIT_SINGLE_HODS_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    hodsData: action.payload,
                    actionType: EOprationalActions.UNSELECT,

                }
            break;
        case types.DELETE_HOD_DATA_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    hodsData: action.payload
                }
            break;
        case types.SET_SEARCH_HODS_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.SET_HODS_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
                searchKey: '',

            }
            break;
        case types.GET_HODS_BULKUPLOAD_FILE_HISTORY_RESPONCE:
            state = {
                ...state,
                uploadedFilesInfo: action.payload
            }
            break;
        case types.SET_HODS_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.CREATE_BULKUPLOAD_HODS_DATA_RESPONSE:
            if (action.payload.responseStatus) {
                state = {
                    ...state,
                    hodsData: action.payload.hodsData,
                    actionType: EOprationalActions.UNSELECT
                }
            }
            break;
        default: state = { ...state };
    }
    return state;
}

export default hodsReducer;