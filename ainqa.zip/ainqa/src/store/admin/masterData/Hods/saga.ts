import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { bulkUploadRecordsCount, DownloadCsv, getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../../../helpers/helpersIndex';
import { EAPPModules, EOprationalActions, IAlertMessagedata, IConfirmModel, IConfirmOptions, EAPIComponentNames } from '../../../../models/utilitiesModel';
import * as actions from './actions';
import { setConfirmationOpen } from '../../../../store/actions';
import * as _ from 'lodash';
import { IHod, IHodsModel } from 'models/hodsModel';

function* getOnlyHodsData(tranId) {
    console.log(`${tranId}_getOnlyHodsData_start =>`);
    let hodsData: IHod[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        let hodsComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HODS, 'getAllHods');
        console.log(tranId + '_gethods_Api_Request =>', hodsComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, hodsComponentAndMethod, null, 'hods');
        console.log(tranId + '_gethods_Api_Response =>', response);

        if (response) {
            hodsData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'HOD1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Hods.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOD1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getAllhodsData_error => `, error.messages ? error.messages : 'HOD2');
        console.log(`${tranId}_getAllhodsData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOD2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Hods.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'HOD2'),

        }
    }
    console.log(`${tranId}_getOnlyHodsData_end =>`, hodsData, alertMessageData);

    return { hodsData, alertMessageData }
}

function* gethodsAndDepartmentData() {
    let tranId = gettranId(EAPPModules.HODSMODULE);

    console.log(`${tranId}_get_HodsAndDeptData_start =>`);
    let hodsData: IHod[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let departmentData: any | undefined;
    try {

        let hodsDataresponse = yield call(getOnlyHodsData, tranId);
        alertMessageData = hodsDataresponse?.alertMessageData
        if (!alertMessageData) {
            hodsData = hodsDataresponse?.hodsData;
        }
        let departmentComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.DEPARTMENTS, 'getAllDepartments');
        console.log(tranId + '_DeptData_Api_Request =>', departmentComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, departmentComponentAndMethod, null, 'departments');
        console.log(tranId + '_DeptData_Request_Api_Response =>', response);
        if (response) {
            departmentData = response
        } else {
            alertMessageData = {
                message: response.messages ? response.messages : 'HOD3',
                status: false,
                tranId: Date.now(),
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOD3'),
                transKey: response.messages ? '' : 'Hods.alertMessages.',
            }
        }
    }
    catch (error) {
        console.log(`${tranId}_gethodsAndDepartmentData_error => `, error.messages ? error.messages : 'HOD4');
        console.log(`${tranId}_gethodsAndDepartmentData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOD4',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Hods.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'HOD4'),

        }
    }
    console.log(`${tranId}_getHodsAndDeptData_end =>`, hodsData, alertMessageData);

    yield put(actions.getHodsAndDepaermentsDataResponce(hodsData, departmentData, alertMessageData));

}


function* createOrEditSinglehodsData(action) {
    let tranId = gettranId(EAPPModules.HODSMODULE);
    console.log(`${tranId}_createOrEditSinglehodsData_start =>`, action, action.payload.requestData);
    let hodsData: IHod[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const requestData = action.payload.requestData;

    if (action.payload.requestType === EOprationalActions.ADD) {
        try {
            let createobject: any = {
                contactNo: requestData.cNumber,
                departmentIds: requestData.deptName.filter(x => !!x.departmentId).map(y => y.departmentId),
                eportfolioEmailId: requestData.email,
                gender: requestData.gender?.value,
                hodFullName: requestData.hodName,
                mmcNo: requestData.mmcNo,
                umId: requestData.umid
            }
            console.log(`${tranId}_createOrEditSinglehodsData_stringify =>`, { createobject, stringify: JSON.stringify(createobject) });

            let hodCreateComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HODS, 'createHod');
            console.log(`${tranId}_createOrEditSinglehodsData_Api_Request =>`, hodCreateComponentAndMethod, createobject);
            let response = yield call(serviceConsumer, tranId, hodCreateComponentAndMethod, createobject, null)
            console.log(`${tranId}_createOrEditSinglehodsData_Api_Response`, response);
            if (response.status) {
                let hodsDataresponse = yield call(getOnlyHodsData, tranId);
                alertMessageData = hodsDataresponse?.alertMessageData

                if (!alertMessageData) {
                    hodsData = hodsDataresponse?.hodsData;
                }
                if (!hodsDataresponse.alertMessageData)
                    alertMessageData = {
                        message: response.messages ? response.messages : 'HOD5',
                        status: true,
                        tranId: Date.now(),
                        transKey: response.messages ? '' : 'Hods.alertMessages.',
                        messageCode: response.messages ? undefined : getMessageCode(tranId + 'HOD5')
                    }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'HOD6',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hods.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOD6')
                }
            }
        } catch (error) {
            console.log(`${tranId}_createOrEditSinglehodsData_error => `, error.messages ? error.messages : 'HOD7');
            console.log(`${tranId}_createOrEditSinglehodsData_catch=>`, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'HOD7',
                status: false,
                tranId: Date.now(),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Hods.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0,
                messageCode: getMessageCode(tranId, 'HOD7'),

            }
        }
    } else {
        try {
            let updateObject = {
                contactNo: requestData.cNumber,
                departmentIds: requestData.deptName.filter(x => !!x.departmentId).map(y => y.departmentId),
                eportfolioEmailId: requestData.email,
                gender: requestData.gender?.value,
                hodFullName: requestData.hodName,
                mmcNo: requestData.mmcNo,
                umId: requestData.umid,
                hodId: requestData.hodId
            }
            console.log(`${tranId}createOrEditSinglehodsData_stringify =>`, updateObject, JSON.stringify(updateObject));

            let hodUpdateComponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HODS, 'updateHod');
            console.log(`${tranId}createOrEditSinglehodsData_update_Api_Request=>`, updateObject, hodUpdateComponentAndMethod);
            let response = yield call(serviceConsumer, tranId, hodUpdateComponentAndMethod, updateObject, null);
            console.log(`${tranId}__createOrEditSinglehodsData_Update_Api_Response=>`, response);
            if (response.status) {
                let hodsDataresponse = yield call(getOnlyHodsData, tranId);
                alertMessageData = hodsDataresponse?.alertMessageData

                if (!alertMessageData) {
                    hodsData = hodsDataresponse?.hodsData;
                }
                if (!hodsDataresponse.alertMessageData)
                    alertMessageData = {
                        message: response.messages ? response.messages : 'HOD8',
                        status: true,
                        tranId: Date.now(),
                        transKey: response.messages ? '' : 'Hods.alertMessages.',
                        messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOD8')
                    }
            } else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'HOD9',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hods.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOD9')
                }
            }
        } catch (error) {
            console.log(`${tranId}_createOrEditSinglehodsData_error => `, error.messages ? error.messages : 'HOD10');
            console.log(`${tranId}_createOrEditSinglehodsData_catch=>`, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'HOD10',
                status: false,
                tranId: Date.now(),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Hods.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0,
                messageCode: getMessageCode(tranId, 'HOD10'),

            }
        }
    }
    console.log(`${tranId}_createOrEditSinglehodsData_End`, hodsData, alertMessageData);
    yield put(actions.createOrEditSingleHodsResponse(hodsData, alertMessageData));
}


function* deleteHodsData(action) {
    let tranId = gettranId(EAPPModules.HODSMODULE);
    console.log(`${tranId}_deleteHodsData_Start =>`, action);

    if (action.payload.requestType) {
        let alertMessageData: IAlertMessagedata | undefined;
        let hodsData: IHod[] | undefined;
        try {
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HODS, 'deleteHod');
            componentAndMethod.url = componentAndMethod.url.replace('{hodid}', action.payload.deleteHodId);
            console.log(tranId + '_deleteHodsData_Api_Request => ', componentAndMethod, action.payload);
            const response = yield call(serviceConsumer, tranId, componentAndMethod, null, null);
            console.log(tranId + '_deleteHodsData_Api_Response => ', response);

            if (response.status) {
                let HodsDataModel = ((yield select())['hodsReducer'] as IHodsModel).hodsData;
                hodsData = HodsDataModel;
                if (hodsData) {
                    let index = hodsData?.findIndex(x => x.hodId === action.payload.deleteHodId);
                    if (index !== -1) {
                        hodsData.splice(index, 1);
                        hodsData = hodsData.slice();
                    }
                }
                alertMessageData = {
                    message: response.messages ? response.messages : "HOD11",
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hods.alertMessages.',
                    messageCode: response.messages ? undefined : getMessageCode(tranId, "HOD11")
                }
            }
            else
                alertMessageData = {
                    message: response.messages ? response.messages : "HOD12",
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Hods.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, "HOD12")
                }
        }
        catch (error) {
            console.error(`${tranId}_deleteHodsData_error => `, error.messages ? error.messages : "HOD13");
            console.log(`${tranId}_deleteHodsData_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'HOD13',
                status: false,
                tranId: Date.now(),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Hods.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0,
                messageCode: getMessageCode(tranId, 'HOD13'),

            }
        }

        console.log(`${tranId}_setHodstatusOrDelete_End => `, hodsData, alertMessageData);
        yield put(actions.deleteHodDataResponse(hodsData, alertMessageData));
    }
    else {
        let optionsData = [
            {
                title: 'Yes',
                function: actions.deleteHodDataRequest(action.payload.deleteHodId, true, action.payload.confirmMessage),
                loading: 1,
                className: 'btn-primary'
            },
            {
                title: 'No',
                loading: 0,
                className: 'btn-danger'
            }
        ] as IConfirmOptions[];

        let confirmModel = {
            title: action.payload.confirmMessage,
            options: optionsData,
            transKey: ''
        } as IConfirmModel;

        console.log(`${tranId}_setActionRequest_2=> `, action, confirmModel);
        yield put(setConfirmationOpen(confirmModel));
    }
}

function* getHodBulkuploadFileHisrotyRequest(action) {
    let tranId = gettranId(EAPPModules.HODSMODULE);

    console.log(`${tranId}_getHodBulkuploadFileHisrotyRequest_start =>`, action);
    let uploadedFilesInfo: any;
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        // let hodsComponentAndMethod = getApiServiceUrlByComponentAndMethod(component, 'getAllhods');
        // console.log(tranId + '_getHodBulkuploadFileHisrotyRequest_Api_Request =>', hodsComponentAndMethod);
        // const response = yield call(serviceConsumer, tranId, hodsComponentAndMethod, null, 'hods');
        // console.log(tranId + '_getHodBulkuploadFileHisrotyRequest_Api_Response =>', response);

        if (true) {
            const response = [
                {
                    fileName: "HODCsv_01.csv",
                    sheetCount: "02",
                    dateandTime: "24-05-2021, 03.30pm"
                },

                {
                    fileName: "HODCsv_03.csv",
                    sheetCount: "03",
                    dateandTime: "25-0^-2021, 04.30pm"
                },
                {
                    fileName: "HODCsv_04.csv",
                    sheetCount: "04",
                    dateandTime: "26-05-2021, 03.30pm"
                },
                {
                    fileName: "HODCsv_05.csv",
                    sheetCount: "05",
                    dateandTime: "24-05-2021, 03.30pm"
                },
                {
                    fileName: "HODCsv_06.csv",
                    sheetCount: "06",
                    dateandTime: "24-05-2021, 03.30pm"
                }

            ]
            uploadedFilesInfo = response;
        }
        else {
            // alertMessageData = {
            //     message: response.messages ? response.messages : 'HOD14',
            //     status: false,
            //     tranId: Date.now(),
            //     transKey: response.messages ? '' : 'Hods.alertMessages.',
            //     messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOD14')
            // }
        }
    } catch (error) {
        console.log(`${tranId}_getHodBulkuploadFileHisrotyRequest_error => `, error.messages ? error.messages : 'HOD2');
        console.log(`${tranId}_getHodBulkuploadFileHisrotyRequest_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOD15',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Hods.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'HOD15'),

        }
    }
    console.log(`${tranId}_getHodBulkuploadFileHisrotyRequest_end =>`, uploadedFilesInfo, alertMessageData);
    yield put(actions.getHodBulkuploadFileHisrotyResponse(uploadedFilesInfo, alertMessageData));
}

function* bulkUplaodHodCreateDataRequest(action) {
    let tranId = gettranId(EAPPModules.HODSMODULE);
    console.log(`_${tranId}_bulkUplaodHodCreateDataRequest_start===>`, action);

    let { validFileData, inValidFileData, columnHeaderMapping, values: { deptName } } = action.payload;


    let hodDetails: IHod[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let responseStatus: boolean = false;
    let failedDataFromApi: any[] | undefined;
    let totalInvalidFileData: any[] | undefined;

    let createBulkUsers = validFileData?.map(x => ({
        departmentIds: deptName ? deptName?.map(x => x.departmentId) : [],
        contactNo: x[columnHeaderMapping.contactNo],
        eportfolioEmailId: (x[columnHeaderMapping.eportfolioEmailId]),
        gender: x[columnHeaderMapping.gender],
        hodFullName: x[columnHeaderMapping.hodFullName],
        mmcNo: x[columnHeaderMapping.mmcNo],
        umId: x[columnHeaderMapping.umId]
    }));

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.HODS, 'createBulkHod');
        console.log(`_${tranId}_bulkUplaodHodCreateDataRequest_Api_request===>`, componentAndMethod, createBulkUsers);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, { hods: createBulkUsers }, '');
        console.log(`_${tranId}_bulkUplaodHodCreateDataRequest_Api_Response===>`, response);

        if (response) {
            responseStatus = response.status;
            failedDataFromApi = response.hods;

            alertMessageData = {
                message: bulkUploadRecordsCount(validFileData, inValidFileData, (failedDataFromApi || [])) || (response.status ? 'HOD16' : 'HOD17'),
                status: response.status,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Hods.alertMessages.',
                messageCode: response.messages ? (response.status ? undefined : tranId) : getMessageCode(tranId, response.status ? 'HOD16' : 'HOD17')
            }
            totalInvalidFileData = (failedDataFromApi || []).concat(inValidFileData);
            if (totalInvalidFileData?.length > 0) {
                totalInvalidFileData = totalInvalidFileData?.map(x => ({
                    contactNo: x[columnHeaderMapping.contactNo] ?? x.contactNo,
                    eportfolioEmailId: x.eportfolioEmailId ?? (x[columnHeaderMapping.eportfolioEmailId]),
                    gender: x[columnHeaderMapping.gender] ?? x.gender,
                    hodFullName: x[columnHeaderMapping.hodFullName] ?? x.hodFullName,
                    mmcNo: x[columnHeaderMapping.mmcNo] ?? x.mmcNo,
                    umId: x[columnHeaderMapping.umId] ?? x.umId,
                    failedReason: x.failedReason
                }));
            }


            console.log('__totalInvalidFileData__', { totalInvalidFileData, failedDataFromApi, inValidFileData });

            if (totalInvalidFileData?.length) {
                DownloadCsv(undefined, undefined, totalInvalidFileData, 'invalidHodsData', undefined, columnHeaderMapping);
                console.log("_totalInvalidFileData", { totalInvalidFileData, inValidFileData, failedDataFromApi });
            }
        }
        else {
            alertMessageData = {
                message: response.messages || 'HOD17',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Hods.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'HOD17')
            }
        }
    }
    catch (error) {
        console.error(`${tranId}_bulkUplaodHodCreateDataRequest_error => `, error.messages ? error.messages : 'HOD18');
        console.log(`${tranId}_bulkUplaodHodCreateDataRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'HOD18',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'HOD18'),
            transKey: error.messages ? '' : 'Hods.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,

        };
    }
    if (responseStatus) {
        const responseUser = yield call(getOnlyHodsData, tranId);
        console.log(`${tranId}_bulkHodCreateRequest_responseUser=> `, responseUser);
        if (!responseUser.alertMessageData) {
            hodDetails = responseUser.hodsData;
        }
    }
    console.log(`_${tranId}_bulkUplaodHodCreateDataRequest_Api_End===>`, hodDetails, alertMessageData);
    yield put(actions.createBulkUploadHodsDataResponse(hodDetails, responseStatus, alertMessageData));
}

export function* watchHods() {
    yield takeLeading(types.CREATE_OR_EDIT_SINGLE_HODS_REQUEST, createOrEditSinglehodsData);
    yield takeLeading(types.DELETE_HOD_DATA_REQUEST, deleteHodsData);
    yield takeLeading(types.GET_HODS_BULKUPLOAD_FILE_HISTORY_REQUEST, getHodBulkuploadFileHisrotyRequest);
    yield takeLeading(types.CREATE_BULKUPLOAD_HODS_DATA_REQUEST, bulkUplaodHodCreateDataRequest);
    while (true) {
        const main = yield takeLeading(types.GET_HODS_AND_DEPARTMENT_DATA_REQUEST, gethodsAndDepartmentData)
        yield take(types.CANCEL_ALL_PENDING_HODS_REQUEST);
        yield cancel(main);
    }
}

function* hodsSaga() {
    yield all([fork(watchHods)]);
}

export default hodsSaga;