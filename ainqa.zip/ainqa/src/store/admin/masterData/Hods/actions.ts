import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../../../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingHodsRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_HODS_REQUEST
    }
}

export const resetAllHodsStateRequest = () => {
    return {
        type: types.RESET_ALL_HODS_STATE_REQUEST
    }
}

export const getHodsAndDepaermentsDataRequest = () => {
    return {
        type: types.GET_HODS_AND_DEPARTMENT_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true,
    }
}

export const getHodsAndDepaermentsDataResponce = (hodsData, departmentData, alertMessageData) => {
    return {
        type: types.GET_HODS_AND_DEPARTMENT_DATA_RESPONCE,
        payload: { hodsData, departmentData },
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData

    }
}

export const setSearchHodsData = (value) => {
    return {
        type: types.SET_SEARCH_HODS_DATA,
        payload: value
    }
}

export const setHodsActionTypeData = (actionType, actionData) => {
    return {
        type: types.SET_HODS_ACTIONTYPE_DATA,
        payload: { actionType, actionData }
    }
}

export const createOrEditSingleHodsRequest = (requestData, requestType) => {
    return {
        type: types.CREATE_OR_EDIT_SINGLE_HODS_REQUEST,
        payload: { requestData, requestType },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const createOrEditSingleHodsResponse = (hodsData, alertMessageData) => {
    return {
        type: types.CREATE_OR_EDIT_SINGLE_HODS_RESPONSE,
        payload: hodsData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

export const deleteHodDataRequest = (deleteHodId, requestType, confirmMessage) => {
    return {
        type: types.DELETE_HOD_DATA_REQUEST,
        payload: { deleteHodId, requestType, confirmMessage },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const deleteHodDataResponse = (hodsData, alertMessageData) => {
    return {
        type: types.DELETE_HOD_DATA_RESPONSE,
        payload: hodsData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}


export const getHodBulkuploadFileHisrotyRequest = () => {
    return {
        type: types.GET_HODS_BULKUPLOAD_FILE_HISTORY_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const getHodBulkuploadFileHisrotyResponse = (uploadedFilesInfo, alertMessageData) => {
    return {
        type: types.GET_HODS_BULKUPLOAD_FILE_HISTORY_RESPONCE,
        payload: uploadedFilesInfo,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}

export const setHodsPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_HODS_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}

export const createBulkUploadHodsDataRequest = (validFileData, inValidFileData, columnHeaderMapping, values) => ({
    type: types.CREATE_BULKUPLOAD_HODS_DATA_REQUEST,
    payload: { validFileData, inValidFileData, columnHeaderMapping, values },
    loadType: ACTION_LOADING,
    loadPayload: true,
});

export const createBulkUploadHodsDataResponse = (hodsData, responseStatus, alertMessageData) => ({
    type: types.CREATE_BULKUPLOAD_HODS_DATA_RESPONSE,
    payload: { hodsData, responseStatus },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});