import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import * as actions from './actions';
import { getApiServiceUrlByComponentAndMethod, gettranId, serviceConsumer, getMessageCode, DownloadCsv, serviceConsumerWithMultiCalls, bulkUploadRecordsCount } from '../../../../helpers/helpersIndex';
import { EAPPModules, EOprationalActions, IAlertMessagedata, IConfirmModel, IConfirmOptions, EAPIComponentNames } from '../../../../models/utilitiesModel';
import { setConfirmationOpen } from '../../../../store/actions';
import { IPhase, IProgram, IProgramsMOdel } from '../../../../models/programsModel';

function* getAllProgramsDetailsRequest(tranId) {
    console.log(`_${tranId}_getAllProgramsDetailsRequest_start===>`,);

    let programsDetails: IProgram[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'getAllPrograms');
        console.log(`_${tranId}_getAllProgramsDetailsRequest_Api_request===>`, componentAndMethod);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, null, "program");
        console.log(`_${tranId}_getAllProgramsDetailsRequest_Api_Response===>`, response);
        if (response) {
            programsDetails = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'PAM1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Programs.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM1')
            }

        }

    } catch (error) {
        console.error(`${tranId}_getAllProgramsDetailsRequest_error => `, error.messages ? error.messages : 'PAM2');
        console.log(`${tranId}_getAllProgramsDetailsRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'PAM2',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'PAM2'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Programs.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`_${tranId}_getAllProgramsDetailsRequest_Api_End===>`, programsDetails, alertMessageData);
    // yield put(actions.getAllProgramsDetailsAndPhaseDistributionResponse(programsDetails, alertMessageData));
    return { programsDetails, alertMessageData }
}

function* getAllProgramsDetailsAndPhaseDistributionDataRequest() {
    let tranId = gettranId(EAPPModules.PROGRAMSMODULE);
    console.log(`_${tranId}_getAllProgramsDetailsRequest_start===>`,);

    let programsDetails: IProgram[] | undefined;
    let phaseDistribution: IPhase[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        let programscomponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'getAllPrograms');
        let phasecomponentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PHASES, 'getAllPhases');
        let multiApiCall = [programscomponentAndMethod, phasecomponentAndMethod];
        let multiApiData = [null, null]
        console.log(`_${tranId}_getAllProgramsDetailsRequest_Api_request===>`, multiApiCall, multiApiData);
        let response = yield call(serviceConsumerWithMultiCalls, tranId, multiApiCall, multiApiData);
        console.log(`_${tranId}_getAllProgramsDetailsRequest_Api_Response===>`, response);
        if (response.length > 0) {
            if (response[0] && response[0].status === 200)
                programsDetails = response[0].data['program'] ? response[0].data['program'] : undefined;
            else {
                alertMessageData = {
                    message: response[0].messages ? response[0].messages : 'EUM1',
                    status: false,
                    tranId: Date.now(),
                    transKey: response[0].messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response[0].messages ? tranId : getMessageCode(tranId, 'EUM1')
                }
            }
            if (response[1] && response[1].status === 200)
                phaseDistribution = response[1].data['phases'] ? response[1].data['phases'] : []
            else {
                alertMessageData = {
                    message: response[1].messages ? response[1].messages : 'EUM2',
                    status: false,
                    tranId: Date.now(),
                    transKey: response[1].messages ? '' : 'UsersManagement.alertMessages.',
                    messageCode: response[1].messages ? tranId : getMessageCode(tranId, 'EUM2')
                }
            }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'PAM1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Programs.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM1')
            }

        }

    } catch (error) {
        console.error(`${tranId}_getAllProgramsDetailsRequest_error => `, error.messages ? error.messages : 'PAM2');
        console.log(`${tranId}_getAllProgramsDetailsRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'PAM2',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'PAM2'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Programs.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`_${tranId}_getAllProgramsDetailsRequest_Api_End===>`, programsDetails, phaseDistribution, alertMessageData);
    yield put(actions.getAllProgramsDetailsAndPhaseDistributionResponse(programsDetails, phaseDistribution, alertMessageData));

}



function* bulkUplaodProgramCreateDataRequest(action) {

    let tranId = gettranId(EAPPModules.PROGRAMSMODULE);
    console.log(`_${tranId}_bulkUplaodProgramCreateDataRequest_start===>`, action);

    let { validFileData, inValidFileData, columnHeaderMapping, values: { phaseDistribution, denomination } } = action.payload;


    let programsDetails: IProgram[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let responseStatus: boolean = false;
    let failedDataFromApi: any[] | undefined;
    let totalInvalidFileData: any[] | undefined;

    let createBulkUsers = validFileData?.map(x => ({
        phaseDistributionId: phaseDistribution ? phaseDistribution?.phaseDistributionId : "",
        phaseDenominationIds: denomination ? denomination?.map(x => x.phaseDenominationId) : [],
        programCode: x[columnHeaderMapping.programCode],
        programName: x[columnHeaderMapping.programName]
    }))

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'bulkProgramCreation');
        console.log(`_${tranId}_bulkUplaodProgramCreateDataRequest_Api_request===>`, componentAndMethod, createBulkUsers);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, { programs: createBulkUsers }, '');
        console.log(`_${tranId}_bulkUplaodProgramCreateDataRequest_Api_Response===>`, response);
        if (response) {
            responseStatus = response.status;
            failedDataFromApi = response.failedProgrames;

            alertMessageData = {
                message: bulkUploadRecordsCount(validFileData, inValidFileData, (failedDataFromApi || [])) || (response.status ? 'PAM14' : 'PAM15'),
                status: response.status,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Programs.alertMessages.',
                messageCode: response.messages ? (response.status ? undefined : tranId) : getMessageCode(tranId, response.status ? 'PAM14' : 'PAM15')
            }
            totalInvalidFileData = (failedDataFromApi || []).concat(inValidFileData);
            if (totalInvalidFileData?.length > 0) {
                totalInvalidFileData = totalInvalidFileData?.map(x => ({
                    programCode: x[columnHeaderMapping.programCode] ?? x.programCode,
                    programName: x[columnHeaderMapping.programName] ?? x.programName,
                    failedReason: x.failedReason
                }));
            }
            console.log('__totalInvalidFileData__', { totalInvalidFileData, failedDataFromApi, inValidFileData });

            if (totalInvalidFileData?.length) {
                DownloadCsv(undefined, undefined, totalInvalidFileData, 'invalidProgramsData', undefined, columnHeaderMapping);
                console.log("_totalInvalidFileData", { totalInvalidFileData, inValidFileData, failedDataFromApi });
            }
        }
        else {
            alertMessageData = {
                message: response.messages || 'PAM15',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Programs.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM15')
            }
        }
    }
    catch (error) {
        console.error(`${tranId}_bulkUplaodProgramCreateDataRequest_error => `, error.messages ? error.messages : 'PAM16');
        console.log(`${tranId}_bulkUplaodProgramCreateDataRequest_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'PAM16',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'PAM16'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Programs.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    if (responseStatus) {
        const responseUser = yield call(getAllProgramsDetailsRequest, tranId);
        console.log(`${tranId}_bulkProgramCreateRequest_responseUser=> `, responseUser);
        if (!responseUser.alertMessageData) {
            programsDetails = responseUser.programsDetails;
        }
    }
    console.log(`_${tranId}_bulkUplaodProgramCreateDataRequest_Api_End===>`, programsDetails, alertMessageData);
    yield put(actions.createBulkUploadProgramsDataResponse(programsDetails, responseStatus, alertMessageData));
}


function* getDeleteProgramFromProgramsDetails(action) {

    let tranId = gettranId(EAPPModules.PROGRAMSMODULE);
    console.log(`_${tranId}_getDeleteProgramFromProgramsDetails_start===>`, action);

    let programsDetails: IProgram[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let { programId, requestType, confirmMessage } = action.payload;

    if (requestType) {
        try {
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'deleteProgram');
            componentAndMethod.url = componentAndMethod.url.replace('{programid}', programId);
            console.log(`_${tranId}_getDeleteProgramFromProgramsDetails_Api_request===>`, componentAndMethod);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, null, null);
            console.log(`_${tranId}_getDeleteProgramFromProgramsDetails_Api_Response===>`, response);
            if (response.status) {
                programsDetails = ((yield select())['programsReducer'] as IProgramsMOdel).programsDetails;
                let ind = programsDetails?.findIndex(x => x.programId === programId);
                if (ind !== -1) programsDetails.splice(ind, 1);
                alertMessageData = {
                    message: response.messages ? response.messages : 'PAM3',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Programs.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM3')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'PAM4',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Programs.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM4')
                }

            }

        } catch (error) {
            console.error(`${tranId}_getDeleteProgramFromProgramsDetails_error => `, error.messages ? error.messages : 'PAM5');
            console.log(`${tranId}_getDeleteProgramFromProgramsDetails_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'PAM5',
                status: false, tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'PAM5'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Programs.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
        console.log(`_${tranId}_getDeleteProgramFromProgramsDetails_Api_End===>`, programsDetails, alertMessageData);
        yield put(actions.getDeleteProgramFromProgramsDetailsResponse(programsDetails, alertMessageData));
    } else {
        let optionsData = [
            {
                title: 'Yes',
                function: actions.getDeleteProgramFromProgramsDetailsRequest(programId, true, confirmMessage),
                loading: 1,
                className: 'btn-primary'
            },
            {
                title: 'No',
                loading: 0,
                className: 'btn-danger'
            }
        ] as IConfirmOptions[];

        let confirmModel = {
            title: action.payload.confirmMessage,
            options: optionsData,
            transKey: ''
        } as IConfirmModel;

        console.log(`${tranId}_setActionRequest_2=> `, action, confirmModel);
        yield put(setConfirmationOpen(confirmModel));
    }
}

function* getAddOrEditProgram(action) {
    let tranId = gettranId(EAPPModules.PROGRAMSMODULE);
    console.log(`_${tranId}_getAddOrEditProgram_start===>`, action);

    let updatedProgramsDetails: any | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    let requestStatus: boolean = false;
    let { programDetails, actionType } = action.payload;
    const selectedphaseDenominationOption = programDetails?.denomination?.map(x => x.phaseDenominationId) || [];

    if (actionType === EOprationalActions.ADD) {
        try {
            let createProgram = {
                phaseDistributionId: programDetails?.phaseDistribution?.phaseDistributionId,
                programCode: programDetails?.programCode,
                programName: programDetails?.programName,
                phaseDenominationIds: selectedphaseDenominationOption
            }
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'createProgram');
            console.log(`_${tranId}_getAddOrEditProgram_Api_request===>`, componentAndMethod, createProgram);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, createProgram, null);
            console.log(`_${tranId}_getAddOrEditProgram_Api_Response===>`, response);
            if (response.status) {
                // updatedProgramsDetails.unshift({ ...createProgram, programId: response.id });
                let programsDataresponse = yield call(getAllProgramsDetailsRequest, tranId);
                alertMessageData = programsDataresponse?.alertMessageData;
                if (!alertMessageData)
                    updatedProgramsDetails = programsDataresponse?.programsDetails;
                requestStatus = true;
                alertMessageData = {
                    message: response.messages ? response.messages : 'PAM6',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Programs.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM6')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'PAM7',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Programs.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM7')
                }

            }

        } catch (error) {
            console.error(`${tranId}_getAddOrEditProgram_error => `, error.messages ? error.messages : 'PAM8');
            console.log(`${tranId}_getAddOrEditProgram_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'PAM8',
                status: false, tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'PAM8'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Programs.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
    } else {
        try {
            let updateProgram = {
                phaseDistributionId: programDetails?.phaseDistribution?.phaseDistributionId,
                programCode: programDetails?.programCode,
                programName: programDetails?.programName,
                programId: programDetails?.programId,
                phaseDenominationIds: selectedphaseDenominationOption

            }
            let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'updateProgram');
            // componentAndMethod.url = componentAndMethod.url.replace('{id}', programDetails?.id);
            console.log(`_${tranId}_getAddOrEditProgram_Api_request===>`, componentAndMethod, updateProgram);
            let response = yield call(serviceConsumer, tranId, componentAndMethod, updateProgram, null);
            console.log(`_${tranId}_getAddOrEditProgram_Api_Response===>`, response);
            if (response.status) {
                requestStatus = true;

                let programsDataresponse = yield call(getAllProgramsDetailsRequest, tranId);
                alertMessageData = programsDataresponse?.alertMessageData;
                if (!alertMessageData)
                    updatedProgramsDetails = programsDataresponse?.programsDetails;
                alertMessageData = {
                    message: response.messages ? response.messages : "PAM9",
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Programs.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM9')
                }
            }
            else {
                alertMessageData = {
                    message: response.messages ? response.messages : 'PAM10',
                    status: false,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'Programs.alertMessages.',
                    messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM10')
                }
            }

        } catch (error) {
            console.error(`${tranId}_getAddOrEditProgram_error => `, error.messages ? error.messages : 'PAM11');
            console.log(`${tranId}_getAddOrEditProgram_catch => `, error);
            alertMessageData = {
                message: error.messages ? error.messages : 'PAM11',
                status: false, tranId: Date.now(),
                messageCode: getMessageCode(tranId, 'PAM11'),
                transKey: error.messages ? 'controleErrors.' + error.messages : 'Programs.alertMessages.',
                statusCode: error.statuscode ? error.statuscode : 0
            };
        }
    }
    console.log(`_${tranId}_getAddOrEditProgram_Api_End===>`, updatedProgramsDetails, alertMessageData);
    yield put(actions.getAddOrEditProgramResponse(updatedProgramsDetails, requestStatus, alertMessageData));
}

function* getFileUploadHistory() {

    let tranId = gettranId(EAPPModules.PROGRAMSMODULE);
    console.log(`_${tranId}_getFileUploadHistory_start===>`,);

    let fileUploadHistory: any | undefined;
    let alertMessageData: IAlertMessagedata | undefined

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.PROGRAMS, 'getFileUploadHistory');
        console.log(`_${tranId}_getFileUploadHistory_Api_request===>`, componentAndMethod);
        let response = yield call(serviceConsumer, tranId, componentAndMethod, null, null);
        console.log(`_${tranId}_getFileUploadHistory_Api_Response===>`, response);
        if (response) {
            fileUploadHistory = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'PAM12',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Programs.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'PAM12')
            }

        }

    } catch (error) {
        console.error(`${tranId}_getFileUploadHistory_error => `, error.messages ? error.messages : 'PAM13');
        console.log(`${tranId}_getFileUploadHistory_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'PAM13',
            status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'PAM13'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Programs.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`_${tranId}_getFileUploadHistory_Api_End===>`, fileUploadHistory, alertMessageData);
    yield put(actions.getFileUploadsHistoryInProgramsResponse(fileUploadHistory, alertMessageData));
}



export function* watchPrograms() {
    yield takeLeading(types.GET_DELETE_PROGRAM_FROM_PROGRAMS_DETAILS_REQUEST, getDeleteProgramFromProgramsDetails);
    yield takeLeading(types.GET_ADD_OR_EDIT_PROGRAMS_REQUEST, getAddOrEditProgram);
    yield takeLeading(types.GET_FILE_UPLOADS_HISTORY_IN_PROGRAMS_REQUEST, getFileUploadHistory);
    yield takeLeading(types.CREATE_BULKUPLOAD_PROGRAMS_DATA_REQUEST, bulkUplaodProgramCreateDataRequest);


    while (true) {
        const main = yield takeLeading(types.GET_ALL_PROGRAMS_DETAILS_PHASE_DISTRIBUTION_REQUEST, getAllProgramsDetailsAndPhaseDistributionDataRequest);
        yield take(types.CANCEL_ALL_PENDING_PROGRAMS_REQUEST);
        yield cancel(main);
    }
}

function* programsSaga() {
    yield all([fork(watchPrograms)]);
}

export default programsSaga;