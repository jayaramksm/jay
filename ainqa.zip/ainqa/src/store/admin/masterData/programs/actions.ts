import { ACTION_LOADING, LAYOUT_ALERT_ACTION_REQUEST } from '../../../../store/layout/actionTypes';
import * as types from './actionTypes';

export const setResetMasterDataProgramsStateRequest = () => ({
    type: types.SET_RESET_MASTER_DATA_PROGRAMS_STATE_REQUEST
});


export const setActionTypeInPrograms = (actionType, actionData = null) => ({
    type: types.SET_ACTION_TYPE_IN_PROGRAMS,
    payload: { actionType, actionData }
});

export const setSearchKeyInPrograms = (searchkey) => ({
    type: types.SET_SEARCH_KEY_IN_PROGRAMS,
    payload: searchkey
});

export const setPaginationCurrentPageValueInPrograms = (currentPage) => ({
    type: types.SET_PAGINATION_CURRENT_PAGE_IN_PROGRAMS,
    payload: currentPage
});

export const getAllProgramsDetailsAndPhaseDistributionRequest = () => ({
    type: types.GET_ALL_PROGRAMS_DETAILS_PHASE_DISTRIBUTION_REQUEST,
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getAllProgramsDetailsAndPhaseDistributionResponse = (programsDetails, phaseDistribution, alertMessageData) => ({
    type: types.GET_ALL_PROGRAMS_DETAILS_PHASE_DISTRIBUTION_RESPONSE,
    payload: { programsDetails, phaseDistribution },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const getDeleteProgramFromProgramsDetailsRequest = (programId, requestType, confirmMessage) => ({
    type: types.GET_DELETE_PROGRAM_FROM_PROGRAMS_DETAILS_REQUEST,
    payload: { programId, requestType, confirmMessage },
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getDeleteProgramFromProgramsDetailsResponse = (programsDetails, alertMessageData) => ({
    type: types.GET_DELETE_PROGRAM_FROM_PROGRAMS_DETAILS_RESPONSE,
    payload: programsDetails,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const getAddOrEditProgramRquest = (programDetails, actionType) => ({
    type: types.GET_ADD_OR_EDIT_PROGRAMS_REQUEST,
    payload: { programDetails, actionType },
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getAddOrEditProgramResponse = (programsDetails, requestStatus, alertMessageData) => ({
    type: types.GET_ADD_OR_EDIT_PROGRAMS_RESPONSE,
    payload: { programsDetails, requestStatus },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const getFileUploadsHistoryInProgramsRequest = () => ({
    type: types.GET_FILE_UPLOADS_HISTORY_IN_PROGRAMS_REQUEST,
    payload: '',
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getFileUploadsHistoryInProgramsResponse = (fileUploadHistory, alertMessageData) => ({
    type: types.GET_FILE_UPLOADS_HISTORY_IN_PROGRAMS_RESPONSE,
    payload: fileUploadHistory,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const createBulkUploadProgramsDataRequest = (validFileData, inValidFileData, columnHeaderMapping, values) => ({
    type: types.CREATE_BULKUPLOAD_PROGRAMS_DATA_REQUEST,
    payload: { validFileData, inValidFileData, columnHeaderMapping, values },
    loadType: ACTION_LOADING,
    loadPayload: true,
});

export const createBulkUploadProgramsDataResponse = (programsData, responseStatus, alertMessageData) => ({
    type: types.CREATE_BULKUPLOAD_PROGRAMS_DATA_RESPONSE,
    payload: { programsData, responseStatus },
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

export const cancelAllPendingProgramsRequest = () => ({
    type: types.CANCEL_ALL_PENDING_PROGRAMS_REQUEST
});