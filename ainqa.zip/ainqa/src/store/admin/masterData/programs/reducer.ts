import { EOprationalActions } from '../../../../models/utilitiesModel';
import { IProgramsMOdel } from '../../../../models/programsModel';
import * as types from './actionTypes';

const initialState = {} as IProgramsMOdel;
const programsReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.SET_RESET_MASTER_DATA_PROGRAMS_STATE_REQUEST:
            state = {
                ...state,
                actionType: EOprationalActions.UNSELECT,
                actionData: undefinedData,
                programsDetails: undefinedData,
                searchKey: '',
                paginationCurrentPage: 0,
                phaseDistribution: undefinedData
            }
            break;
        case types.SET_ACTION_TYPE_IN_PROGRAMS:
            state = {
                ...state,
                actionType: action.payload.actionType,
                actionData: action.payload.actionData,
                searchKey: '',

            }
            break;
        case types.GET_ALL_PROGRAMS_DETAILS_PHASE_DISTRIBUTION_RESPONSE:
            state = {
                ...state,
                programsDetails: action.payload.programsDetails,
                phaseDistribution: action.payload.phaseDistribution
            }
            break;
        case types.CREATE_BULKUPLOAD_PROGRAMS_DATA_RESPONSE:
            if (action.payload.responseStatus)
                state = {
                    ...state,
                    programsDetails: action.payload.programsData,
                    actionType: EOprationalActions.UNSELECT
                }
            break;
        case types.SET_SEARCH_KEY_IN_PROGRAMS:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.SET_PAGINATION_CURRENT_PAGE_IN_PROGRAMS:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.GET_DELETE_PROGRAM_FROM_PROGRAMS_DETAILS_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    programsDetails: action.payload
                }
            break;
        case types.GET_ADD_OR_EDIT_PROGRAMS_RESPONSE:
            if (action.payload.requestStatus)
                state = {
                    ...state,
                    programsDetails: action.payload.programsDetails,
                    actionType: EOprationalActions.UNSELECT
                }
            break;
        case types.GET_FILE_UPLOADS_HISTORY_IN_PROGRAMS_RESPONSE:
            state = {
                ...state,
                fileUploadHistory: action.payload
            }
            break;
        default: state = { ...state };
    }
    return state;
}

export default programsReducer;