import { takeLeading, put, take, cancel, all, fork, call, select } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, EOprationalActions, ERoleDesc, IAlertMessagedata, IUserDetails } from '../../models/utilitiesModel';
import * as actions from './actions';
import * as _ from 'lodash';
import { IGla } from '../../models/glasModel';


function* getOnlyapproveGlasData(tranId) {
    console.log(`${tranId}_getOnlyapproveGlasData_start =>`);
    let approveGlasData: IGla[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    const component = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? EAPIComponentNames.MOH_SUPERVISOR : EAPIComponentNames.EDUCATIONAL_SUPERVISOR
    const methode = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? 'getAllGlasByMohId' : 'getAllGlasByEsId'

    try {
        let approveGlasComponentAndMethod = getApiServiceUrlByComponentAndMethod(component, methode);
        console.log(tranId + '_getapproveGlas_Api_Request =>', approveGlasComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, approveGlasComponentAndMethod, null, 'glas');
        console.log(tranId + '_getapproveGlas_Api_Response =>', response);

        if (response) {
            approveGlasData = response;
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'AGL1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveGla.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'AGL1')
            }
        }
    } catch (error) {
        console.log(`${tranId}_getAllapproveGlasData_error => `, error.messages ? error.messages : 'AGL2');
        console.log(`${tranId}_getAllapproveGlasData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'AGL2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'approveGla.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'AGL2'),
        }
    }
    console.log(`${tranId}_getOnlyapproveGlasData_end =>`, approveGlasData, alertMessageData);

    return { approveGlasData, alertMessageData }
}

function* getapproveGlasData() {
    let tranId = gettranId(EAPPModules.APPROVEGlLASMODULE);

    console.log(`${tranId}_get_approveGlasAndDeptData_start =>`);
    let approveGlasData: IGla[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    try {

        let approveGlasDataresponse = yield call(getOnlyapproveGlasData, tranId);
        alertMessageData = approveGlasDataresponse?.alertMessageData
        if (!alertMessageData) {
            approveGlasData = approveGlasDataresponse?.approveGlasData;
        }

    }
    catch (error) {
        console.log(`${tranId}_getapproveGlasAndDepartmentData_error => `, error.messages ? error.messages : 'AGL2');
        console.log(`${tranId}_getapproveGlasAndDepartmentData_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'AGL2',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'approveGla.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'AGL2'),
           
        }
    }
    console.log(`${tranId}_getapproveGlasAndDeptData_end =>`, approveGlasData, alertMessageData);

    yield put(actions.getApproveGlasDataResponce(approveGlasData, alertMessageData));

}


function* setApproveGlasSatus(action) {
    let tranId = gettranId(EAPPModules.APPROVEGlLASMODULE);
    console.log(`${tranId}_setApproveGlas_start =>`, action, action.payload.requestData);
    let approveGlasData: IGla[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    const requestData = action.payload.requestData

    const component = (userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR && userDto?.userId === requestData?.supervisorId) ? EAPIComponentNames.EDUCATIONAL_SUPERVISOR : EAPIComponentNames.MOH_SUPERVISOR
    const methode = (userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR && userDto?.userId === requestData?.supervisorId) ? 'updateGlaStatusByEs' : 'updateGlaStatusByMoh';
    try {
        let statusObject: any = (userDto?.userType === ERoleDesc.EDUCATIONALSUPERVISOR && userDto?.userId === requestData?.supervisorId) ? {

            esComments: requestData.comments,
            signature: requestData?.signatures,
            esStatus: requestData.approvelStatus?.value,
            glaId: requestData?.glaId,
            supervisorName: requestData?.supervisorName,
            traineeId: requestData?.traineeId,
            traineeUserId: requestData?.traineeUserId

        } :
            {
                glaId: requestData?.glaId,
                mohComments: requestData.comments,
                signature: requestData?.signatures,
                mohStatus: requestData.approvelStatus?.value,
                supervisorName: requestData?.supervisorName,
                traineeId: requestData?.traineeId,
                traineeUserId: requestData?.traineeUserId
            }
        console.log(`${tranId}_setApproveGlas_stringify =>`, { statusObject, stringify: JSON.stringify(statusObject) });

        let glaCreateComponentAndMethod = getApiServiceUrlByComponentAndMethod(component, methode);
        console.log(`${tranId}_setApproveGlas_Api_Request =>`, glaCreateComponentAndMethod, statusObject);
        let response = yield call(serviceConsumer, tranId, glaCreateComponentAndMethod, statusObject, null)
        console.log(`${tranId}_setApproveGlas_Api_Response`, response);
        if (response.status) {
            let approveGlasDataresponse = yield call(getOnlyapproveGlasData, tranId);
            alertMessageData = approveGlasDataresponse?.alertMessageData

            if (!alertMessageData) {
                approveGlasData = approveGlasDataresponse?.approveGlasData;
            }
            if (!approveGlasDataresponse.alertMessageData)
                alertMessageData = {
                    message: response.messages ? response.messages : 'AGL3',
                    status: true,
                    tranId: Date.now(),
                    transKey: response.messages ? '' : 'approveGla.alertMessages.',
                    messageCode: response.messages ? undefined : tranId + 'AGL3'
                }
        }
        else {
            alertMessageData = {
                message: response.messages ? response.messages : 'AGL4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'approveGla.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'AGL4')
            }
        }
    } catch (error) {
        console.log(`${tranId}_setApproveGlas_error => `, error.messages ? error.messages : 'AGL5');
        console.log(`${tranId}_setApproveGlas_catch=>`, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'AGL5',
            status: false,
            tranId: Date.now(),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'approveGla.alertMessages.',
            statusCode: error.statuscode ? error.statuscode : 0,
            messageCode: getMessageCode(tranId, 'AGL5'),

        }
    }

    console.log(`${tranId}_setApproveGlas_End`, approveGlasData, alertMessageData);
    yield put(actions.setApproveGlaSatusResponse(approveGlasData, alertMessageData));
}

function* isEditApproveGlasData(action) {
    let tranId = gettranId(EAPPModules.APPROVEGlLASMODULE);
    let approveGlasData: IGla[] | undefined;
    let approveGlasActionData: IGla | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    console.log(`${tranId}_isEditApproveGlasData_start =>`);
    const requestData = action.payload;
    const userDto: IUserDetails = (yield select())['SessionState']?.userDto;
    const component = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? EAPIComponentNames.MOH_SUPERVISOR : EAPIComponentNames.EDUCATIONAL_SUPERVISOR
    const methode = userDto?.userType === ERoleDesc.MOHSUPERVISOR ? 'updateMohStatusForGla' : 'updateEsStatusForGla'
    try {
        let createobject: any = {
            glaId: requestData.glaId,
            status: requestData.isEdit
        }
        let isEditApproveGlaComponentAndMethod = getApiServiceUrlByComponentAndMethod(component, methode);
        console.log(tranId + '_isEditApproveGlasData_Request =>', createobject, isEditApproveGlaComponentAndMethod);
        const response = yield call(serviceConsumer, tranId, isEditApproveGlaComponentAndMethod, createobject, null);
        console.log(tranId + '_iisEditApproveGlasData_Response =>', response);

        if (response.status) {
            console.log(tranId + '_isEditApproveGlasData_if=>', response);

        }
        else {
            console.log(tranId + '_isEditApproveGlasData_else=>', response);
        }
        let approveGlasDataresponse = yield call(getOnlyapproveGlasData, tranId);
        alertMessageData = approveGlasDataresponse?.alertMessageData
        if (!alertMessageData) {
            approveGlasData = approveGlasDataresponse?.approveGlasData;
        }
        const actionData: IGla = (yield select())['approveGlasReducer']?.actionData;
        if (actionData) {
            let approveGlaActionData = approveGlasData?.find(x => x.glaId === actionData?.glaId);
            if (!_.isEqual(approveGlaActionData, actionData))
                approveGlasActionData = approveGlaActionData;
            console.log(`${tranId}_isEditApproveGla_getGlas_And_set_ActionData_responce =>`, { approveGlasData, approveGlasActionData, actionData, approveGlaActionData, isEqual: !_.isEqual(approveGlaActionData, actionData) });

        }


    } catch (error) {
        console.log(`${tranId}_isEditApproveGlasData_error => `, error.messages ? error.messages : 'AGL6');
        console.log(`${tranId}_isEditApproveGlasData_catch=>`, error);

    }
    console.log(`${tranId}_isEditApproveGlasData_end =>`, approveGlasActionData, alertMessageData);
    yield put(actions.isEditApproveGlaResponce(approveGlasActionData, alertMessageData));

}



export function* watchapproveGlas() {
    yield takeLeading(types.SET_APPROVEGLAS_SATUS_REQUEST, setApproveGlasSatus);
    yield takeLeading(types.ISEDIT_APPROVEGLAS_REQUEST, isEditApproveGlasData);
    while (true) {
        const main = yield takeLeading(types.GET_APPROVEGLAS_DATA_REQUEST, getapproveGlasData)
        yield take(types.CANCEL_ALL_PENDING_APPROVEGLAS_REQUEST);
        yield cancel(main);
    }
}

function* approveGlasSaga() {
    yield all([fork(watchapproveGlas)]);
}

export default approveGlasSaga;