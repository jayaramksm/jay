import { EOprationalActions } from '../../models/utilitiesModel';
import * as types from './actionTypes';
import { IApproveGlasMOdel } from '../../models/approveGlaModel';

const initialState = {} as IApproveGlasMOdel

const approveGlasReducer = (state = initialState, action) => {
    let undefined;
    switch (action.type) {
        case types.RESET_ALL_APPROVEGLAS_STATE_REQUEST:
            state = {
                ...state,
                actionData: undefined,
                actionType: EOprationalActions.UNSELECT,
                approveGlasData: undefined,
                paginationCurrentPage: 0,
                searchKey: ''
            }
            break;
        case types.SET_SEARCH_APPROVEGLAS_DATA:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        case types.GET_APPROVEGLAS_DATA_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    approveGlasData: action.payload
                }
            break;
        case types.SET_APPROVEGLAS_PAGINATION_CURRENT_PAGE_VALUE:
            state = {
                ...state,
                paginationCurrentPage: action.payload
            }
            break;
        case types.SET_APPROVEGLAS_STATUS_RESPONSE:
            if (action.payload)
                state = {
                    ...state,
                    approveGlasData: action.payload,
                    actionType: EOprationalActions.UNSELECT,

                }
            break;
        case types.ISEDIT_APPROVEGLAS_RESPONCE:
            if (action.payload)
                state = {
                    ...state,
                    actionData: action.payload
                }
            break;
        case types.SET_APPROVEGLAS_ACTIONTYPE_DATA:
            state = {
                ...state,
                actionData: action.payload.actionData,
                actionType: action.payload.actionType,
                searchKey: ''
            }
            break;

        default: state = { ...state }
    }
    return state;
}

export default approveGlasReducer;