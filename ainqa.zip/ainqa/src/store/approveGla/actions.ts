import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from './../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingApproveGlasRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_APPROVEGLAS_REQUEST
    }
}

export const resetAllApproveGlasStateRequest = () => {
    return {
        type: types.RESET_ALL_APPROVEGLAS_STATE_REQUEST
    }
}

export const getApproveGlasDataRequest = () => {
    return {
        type: types.GET_APPROVEGLAS_DATA_REQUEST,
        loadType: ACTION_LOADING,
        loadPayload: true,
    }
}

export const getApproveGlasDataResponce = (approveGlasData, alertMessageData) => {
    return {
        type: types.GET_APPROVEGLAS_DATA_RESPONCE,
        payload: approveGlasData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData

    }
}

export const setSearchApproveGlasData = (value) => {
    return {
        type: types.SET_SEARCH_APPROVEGLAS_DATA,
        payload: value
    }
}

export const setApproveGlasActionTypeData = (actionType, actionData) => {
    return {
        type: types.SET_APPROVEGLAS_ACTIONTYPE_DATA,
        payload: { actionType, actionData }
    }
}



export const setApproveGlasStatusRequest = (requestData, requestType) => {
    return {
        type: types.SET_APPROVEGLAS_SATUS_REQUEST,
        payload: { requestData, requestType },
        loadType: ACTION_LOADING,
        loadPayload: true
    }
}
export const setApproveGlaSatusResponse = (approveGlasData, alertMessageData) => {
    return {
        type: types.SET_APPROVEGLAS_STATUS_RESPONSE,
        payload: approveGlasData,
        loadType: ACTION_LOADING,
        loadPayload: false,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}


export const setApproveGlasPaginationCurrentPageValue = (value) => {
    return {
        type: types.SET_APPROVEGLAS_PAGINATION_CURRENT_PAGE_VALUE,
        payload: value
    }
}


export const isEditApproveGlaRequest = (glaId, isEdit) => {
    return {
        type: types.ISEDIT_APPROVEGLAS_REQUEST,
        payload: { glaId, isEdit },
    }
};


export const isEditApproveGlaResponce = (approveGlasData, alertMessageData) => {
    return {
        type: types.ISEDIT_APPROVEGLAS_RESPONCE,
        payload: approveGlasData,
        alertMType: LAYOUT_ALERT_ACTION_REQUEST,
        alertMPayload: alertMessageData
    }
}