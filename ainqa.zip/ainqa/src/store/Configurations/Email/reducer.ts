import { IEmailModel } from 'models/emailModel';
import * as types from './actionTypes';
import * as _ from 'lodash';

const initialState = {} as IEmailModel

const emailReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.SET_RESET_FOR_CONFIGURATIONS_EMAIL:
            state = {
                ...state,
                emailData: undefinedData
            }
            break;
        case types.GET_CONFIGURATIONS_EMAIL_DATA_RESPONSE:
            if (action.payload && !_.isEqual(state.emailData, action.payload)) {
                state = {
                    ...state,
                    emailData: action.payload
                }
            }
            break;
        case types.CREATE_OR_UPDATE_CONFIGURATIONS_EMAIL_DATA_RESPONCE:
            if (action.payload && !_.isEqual(state.emailData, action.payload)) {
                state = {
                    ...state,
                    emailData: action.payload
                }
            }
            break;

        default: state = { ...state }
    }
    return state;
}

export default emailReducer;