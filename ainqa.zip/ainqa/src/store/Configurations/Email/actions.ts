import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from '../../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingConfigurationsEmailRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_CONFIGURATIONS_EMAIL_REQUESTS
    }
}

export const setResetForConfigurationsEmail = () => ({
    type: types.SET_RESET_FOR_CONFIGURATIONS_EMAIL
});

export const getConfigurationsEmailDataRequest = () => ({
    type: types.GET_CONFIGURATIONS_EMAIL_DATA_REQUEST,
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getConfigurationsEmailDataResponse = (emailData, alertMessageData) => ({
    type: types.GET_CONFIGURATIONS_EMAIL_DATA_RESPONSE,
    payload: emailData,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});



export const createOrUpdateConfigurationsEmailDataRequest = (emailData) => ({
    type: types.CREATE_OR_UPDATE_CONFIGURATIONS_EMAIL_DATA_REQUEST,
    payload: emailData,
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const createOrUpdateConfigurationsEmailDataResponce = (updatedEmailData, alertMessageData) => ({
    type: types.CREATE_OR_UPDATE_CONFIGURATIONS_EMAIL_DATA_RESPONCE,
    payload: updatedEmailData,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});

