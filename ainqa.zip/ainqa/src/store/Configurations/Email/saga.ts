import { takeLeading, put, take, cancel, all, fork, call } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, IAlertMessagedata } from '../../../models/utilitiesModel';
import * as actions from './actions';
import { IEmail } from 'models/emailModel';


function* getOnlyEmailData(tranId) {
    console.log(`${tranId} _getEmailData_Start`);
    let emailData: IEmail | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EMAIL, 'getAllEmailSettingsByUniversityId');
        console.log(`${tranId}_getGlobalSettingsBySettingType_Api_Request => `, componentAndMethod);
        const response = yield call(serviceConsumer, tranId, componentAndMethod, null, 'emailSettings');
        console.log(`${tranId}_getGlobalSettingsBySettingType_Api_Response => `, response);
        if (response) {
            emailData = response
        }
        else
            alertMessageData = {
                message: response.messages ? response.messages : 'CFE1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ConfigurationsEmail.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'CFE1')
            }
    }
    catch (error) {
        console.error(`${tranId}_getEmailData_error => `, error.messages ? error.messages : 'CFE2');
        console.log(`${tranId}_getEmailData_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'CFE2', status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'CFE2'), transKey: error.messages ? 'controleErrors.' + error.messages : 'ConfigurationsEmail.alertMessages.', statusCode: error.statuscode ? error.statuscode : 0
        };
    }

    console.log(`${tranId} _getEmailData_End => `, emailData, alertMessageData);
    return { emailData, alertMessageData }
}

function* getEmailData() {
    let tranId = gettranId(EAPPModules.EMAILMODULE);
    console.log(`${tranId} _getEmailData_Start`);
    let emailData: IEmail | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        const emailDataResponce = yield call(getOnlyEmailData, tranId);
        alertMessageData = emailDataResponce?.alertMessageData
        if (!alertMessageData)
            emailData = emailDataResponce?.emailData
    }
    catch (error) {
        console.error(`${tranId}_getEmailData_error => `, error.messages ? error.messages : 'CFE2');
        console.log(`${tranId}_getEmailData_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'CFE2', status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'CFE2'), transKey: error.messages ? 'controleErrors.' + error.messages : 'ConfigurationsEmail.alertMessages.', statusCode: error.statuscode ? error.statuscode : 0
        };
    }

    console.log(`${tranId} _getEmailData_End => `, emailData, alertMessageData);
    yield put(actions.getConfigurationsEmailDataResponse(emailData, alertMessageData));
}
function* createOrUpdateEmailData(action) {
    let tranId = gettranId(EAPPModules.EMAILMODULE);
    console.log(`${tranId} _createOrUpdateEmailData_Start`, action);

    let updatedEmailData: IEmail | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const actionData = action.payload
    const methode = actionData?.emailData ? 'updateEmailSettings' : 'createEmailSettings'
    try {
        const reqData = {
            emailAccount: actionData.emailAccount,
            password: actionData.password?.trim(),
            port: actionData.port,
            serverIp: actionData.serverIp,
            serverName: actionData.serverName,
            mailBoxType: (actionData.mailBoxType as any)?.value,
            emailSettingsId: actionData?.emailSettingsId,
        }
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.EMAIL, methode);
        console.log(`${tranId}_createOrUpdateEmailData_Api_Request => `, methode, componentAndMethod, reqData);
        const response = yield call(serviceConsumer, tranId, componentAndMethod, reqData, null);
        console.log(`${tranId}_createOrUpdateEmailData_Api_Response => `, response);

        if (response.status) {
            alertMessageData = {
                message: response.messages ? response.messages : 'CFE5',
                status: true,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ConfigurationsEmail.alertMessages.',
                messageCode: response.messages ? undefined : getMessageCode(tranId, 'CFE5')
            }

            const emailDataResponce = yield call(getOnlyEmailData, tranId);
            if (!emailDataResponce?.alertMessageData)
                updatedEmailData = emailDataResponce?.emailData;
        }

        else
            alertMessageData = {
                message: response.messages ? response.messages : 'CFE6',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'ConfigurationsEmail.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'CFE6')
            }
    }
    catch (error) {
        console.error(`${tranId}_createOrUpdateEmailData_error => `, error.messages ? error.messages : 'CFE7');
        console.log(`${tranId}_createOrUpdateEmailData => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'CFE7', status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'CFE7'), transKey: error.messages ? 'controleErrors.' + error.messages : 'ConfigurationsEmail.alertMessages.', statusCode: error.statuscode ? error.statuscode : 0
        };
    }

    console.log(`${tranId} _createOrUpdateEmailData_End`, updatedEmailData, alertMessageData);
    yield put(actions.createOrUpdateConfigurationsEmailDataResponce(updatedEmailData, alertMessageData));
}

export function* watchEmail() {
    yield takeLeading(types.CREATE_OR_UPDATE_CONFIGURATIONS_EMAIL_DATA_REQUEST, createOrUpdateEmailData);

    while (true) {
        const main = yield takeLeading(types.GET_CONFIGURATIONS_EMAIL_DATA_REQUEST, getEmailData);
        yield take(types.CANCEL_ALL_PENDING_CONFIGURATIONS_EMAIL_REQUESTS);
        yield cancel(main);
    }
}

function* emailSaga() {
    yield all([fork(watchEmail)]);
}

export default emailSaga;