import { LAYOUT_ALERT_ACTION_REQUEST, ACTION_LOADING } from '../../layout/actionTypes';
import * as types from './actionTypes';

export const cancelAllPendingFormConfigurationsRequest = () => {
    return {
        type: types.CANCEL_ALL_PENDING_FORM_CONFIGURATIONS_REQUESTS
    }
}

export const setResetForFormConfigurations = () => ({
    type: types.SET_RESET_FOR_FORM_CONFIGURATIONS
});

export const getFormConfigurationsDataRequest = () => ({
    type: types.GET_FORM_CONFIGURATIONS_DATA_REQUEST,
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const getFormConfigurationsDataResponse = (formData, alertMessageData) => ({
    type: types.GET_FORM_CONFIGURATIONS_DATA_RESPONSE,
    payload: formData,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});



export const createOrUpdateFormConfigurationsDataRequest = (formData) => ({
    type: types.CREATE_OR_UPDATE_FORM_CONFIGURATIONS_DATA_REQUEST,
    payload: formData,
    loadType: ACTION_LOADING,
    loadPayload: true
});

export const createOrUpdateFormConfigurationsDataResponce = (updatedFormData, alertMessageData) => ({
    type: types.CREATE_OR_UPDATE_FORM_CONFIGURATIONS_DATA_RESPONCE,
    payload: updatedFormData,
    loadType: ACTION_LOADING,
    loadPayload: false,
    alertMType: LAYOUT_ALERT_ACTION_REQUEST,
    alertMPayload: alertMessageData
});


export const setFormConfigurationCurrentPageInPagination = (currentPage) => ({
    type: types.SET_FORM_CONFIGURATION_CURRENT_PAGE_IN_PAGINATION,
    payload: currentPage
});

export const setFormConfigurationsSearchKey = (searchkey) => ({
    type: types.SET_FORM_CONFIGURATION_SEARCH_KEY,
    payload: searchkey
});

export const setFormConfigurationsActionTypeAndActionData = (actionType, actionData) => ({
    type: types.SET_FORM_CONFIGURATIONS_ACTIONTYPE_ACTIONDATA,
    payload: { actionType, actionData }
})

