import * as types from './actionTypes';
import * as _ from 'lodash';
import { IFormConfigurationsModel } from '../../../models/formConfigurationsModel'
import { EOprationalActions } from '../../../models/utilitiesModel';

const initialState = {} as IFormConfigurationsModel

const formConfigurationsReducer = (state = initialState, action) => {
    let undefinedData;
    switch (action.type) {
        case types.SET_RESET_FOR_FORM_CONFIGURATIONS:
            state = {
                ...state,
                formData: undefinedData,
                currentPage: 0,
                actionType: EOprationalActions.UNSELECT,
                searchKey: ''
            }
            break;
        case types.GET_FORM_CONFIGURATIONS_DATA_RESPONSE:
            state = {
                ...state,
                formData: action.payload
            }
            break;
        case types.CREATE_OR_UPDATE_FORM_CONFIGURATIONS_DATA_RESPONCE:
            state = {
                ...state,
                formData: action.payload
            }
            break;
        case types.SET_FORM_CONFIGURATION_CURRENT_PAGE_IN_PAGINATION:
            state = {
                ...state,
                currentPage: action.payload
            }
            break;
        case types.SET_FORM_CONFIGURATION_SEARCH_KEY:
            state = {
                ...state,
                searchKey: action.payload
            }
            break;
        default: state = { ...state }
    }
    return state;
}

export default formConfigurationsReducer;