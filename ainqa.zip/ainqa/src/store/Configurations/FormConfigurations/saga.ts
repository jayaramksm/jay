import { takeLeading, put, take, cancel, all, fork, call } from 'redux-saga/effects';
import * as types from './actionTypes';
import { getApiServiceUrlByComponentAndMethod, getMessageCode, gettranId, serviceConsumer } from '../../../helpers/helpersIndex';
import { EAPIComponentNames, EAPPModules, IAlertMessagedata } from '../../../models/utilitiesModel';
import * as actions from './actions';
import { IFormData } from '../../../models/formConfigurationsModel';


function* getOnlyFormConfigurationsData(tranId) {
    console.log(`${tranId} _getOnlyFormConfigurationsData_Start`);
    let formData: IFormData[] | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.FORM_BUILDER, 'getAllFormsWithMappingData');
        console.log(`${tranId}_getOnlyFormConfigurationsData_Api_Request => `, componentAndMethod);
        const response = yield call(serviceConsumer, tranId, componentAndMethod, null, 'portfolioForms');
        console.log(`${tranId}_getOnlyFormConfigurationsData_Api_Response => `, response);
        if (response) {
            formData = response
        }
        else
            alertMessageData = {
                message: response.messages ? response.messages : 'FCA1',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'FormConfigurations.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'FCA1')
            }
    }
    catch (error) {
        console.error(`${tranId}_getOnlyFormConfigurationsData_error => `, error.messages ? error.messages : 'FCA2');
        console.log(`${tranId}_getOnlyFormConfigurationsData_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'FCA2', status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'FCA2'), transKey: error.messages ? 'controleErrors.' + error.messages : 'FormConfigurations.alertMessages.', statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`${tranId} _getOnlyFormConfigurationsData_End => `, formData, alertMessageData);
    return { formData, alertMessageData }
}

function* getFormConfigurationsData() {
    let tranId = gettranId(EAPPModules.FORMCONFIGURATIONSMODEL);
    console.log(`${tranId} _getFormConfigurationsData_Start`);
    let formData: any | undefined;
    let alertMessageData: IAlertMessagedata | undefined;

    try {
        const formDataResponce = yield call(getOnlyFormConfigurationsData, tranId);
        alertMessageData = formDataResponce?.alertMessageData
        if (!alertMessageData)
            formData = formDataResponce?.formData
    }
    catch (error) {
        console.error(`${tranId}_getFormConfigurationsData_error => `, error.messages ? error.messages : 'FCA2');
        console.log(`${tranId}_getFormConfigurationsData_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'FCA2', status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'FCA2'), transKey: error.messages ? 'controleErrors.' + error.messages : 'FormConfigurations.alertMessages.', statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`${tranId} _getFormConfigurationsData_End => `, formData, alertMessageData);
    yield put(actions.getFormConfigurationsDataResponse(formData, alertMessageData));
}


function* createOrUpdateformConfigurationData(action) {
    let tranId = gettranId(EAPPModules.FORMCONFIGURATIONSMODEL);
    console.log(`${tranId} _createOrUpdateformConfigurationData_Start`, action);

    let updatedFormData: any | undefined;
    let alertMessageData: IAlertMessagedata | undefined;
    const { traineefeedbackForm, evaluatorfeedbackForm, portfolioFormMappings, portfolioFormId } = action.payload;

    try {
        const reqData = {
            "evaluatorForm": evaluatorfeedbackForm,
            "portfolioFormId": portfolioFormId,
            "portfolioFormsMappingId": portfolioFormMappings?.portfolioFormsMappingId || "",
            "traineeForm": traineefeedbackForm
        }
        console.log('stringfyData==>', JSON.stringify(reqData))
        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.FORM_BUILDER, 'createPortfolioFormMappings');
        console.log(`${tranId}_createOrUpdateformConfigurationData_Api_Request => `, componentAndMethod, reqData);
        const response = yield call(serviceConsumer, tranId, componentAndMethod, reqData, null);
        console.log(`${tranId}_createOrUpdateformConfigurationData_Api_Response => `, response);

        if (response.status) {
            alertMessageData = {
                message: response.messages ? response.messages : 'FCA3',
                status: true,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'FormConfigurations.alertMessages.',
                messageCode: response.messages ? undefined : getMessageCode(tranId, 'FCA3')
            }
            const formConfigurationDataResponce = yield call(getOnlyFormConfigurationsData, tranId);
            if (!formConfigurationDataResponce?.alertMessageData)
                updatedFormData = formConfigurationDataResponce?.formData;
        }

        else
            alertMessageData = {
                message: response.messages ? response.messages : 'FCA4',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'FormConfigurations.alertMessages.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'FCA4')
            }
    }
    catch (error) {
        console.error(`${tranId}_createOrUpdateformConfigurationData_error => `, error.messages ? error.messages : 'FCA5');
        console.log(`${tranId}_createOrUpdateformConfigurationData_catch => `, error);
        alertMessageData = {
            message: error.messages ? error.messages : 'FCA5', status: false, tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'FCA5'), transKey: error.messages ? 'controleErrors.' + error.messages : 'FormConfigurations.alertMessages.', statusCode: error.statuscode ? error.statuscode : 0
        };
    }
    console.log(`${tranId} _createOrUpdateformConfigurationData_End`, updatedFormData, alertMessageData);
    yield put(actions.createOrUpdateFormConfigurationsDataResponce(updatedFormData, alertMessageData));
}


export function* watchFormConfiguration() {
    yield takeLeading(types.CREATE_OR_UPDATE_FORM_CONFIGURATIONS_DATA_REQUEST, createOrUpdateformConfigurationData);

    while (true) {
        const main = yield takeLeading(types.GET_FORM_CONFIGURATIONS_DATA_REQUEST, getFormConfigurationsData);
        yield take(types.CANCEL_ALL_PENDING_FORM_CONFIGURATIONS_REQUESTS);
        yield cancel(main);
    }
}

function* formConfigurationSaga() {
    yield all([fork(watchFormConfiguration)]);
}

export default formConfigurationSaga;