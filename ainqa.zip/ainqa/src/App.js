import React, { Component } from 'react';
import { Route, Switch, HashRouter as Router } from 'react-router-dom';
import routes from './routes';
import './custom.css';
import './App.scss';
import './menuicons.css';
import AppIdle from './AppIdle';

// Get all Auth methods
import { initVersionCheck, withLayout, withOutLayout, PrivateRoute, HomeRoute } from './helpers/helpersIndex';
import { withTranslation } from 'react-i18next';
import AppLanguageTransaltors from './AppLanugageTranslators';

let previousPath;
class App extends Component {
  componentDidMount() {
    const { t } = this.props
    if (process.env.NODE_ENV === 'production')
      initVersionCheck('version.json', routes, t('Utilities.versionUpdateMsg'));

    window.history.pushState(null, "", window.location.href);
    previousPath = window.location.hash;
    window.onpopstate = function () {
      if (previousPath !== window.location.hash) {
        let index = routes.filter(y => y.ispublic || y?.isDefultauth || (y.isClient && !y.isProfilePath)).findIndex(x => '#' + x.path === previousPath || '#' + x.path === window.location.hash);
        previousPath = window.location.hash;
        if (index !== -1)
          window.history.pushState(null, "", window.location.href);
      }
      else
        window.history.pushState(null, "", window.location.href);
    };
  }

  render() {
    return (
      <React.Fragment>
        <AppIdle />
        <AppLanguageTransaltors />
        <Router>
          <Switch>
            {routes.map((route, idx) =>
              route.ispublic ? route.ishomeRoute ?
                <HomeRoute path={route.path} exact component={route.islazy ? withOutLayout(route.component, route.isProfilePath) : route.component} key={idx} />
                : <Route path={route.path} exact component={route.islazy ? withOutLayout(route.component, route.isProfilePath) : route.component} key={idx} />
                :
                <PrivateRoute path={route.path} exact routeProps={route} component={withLayout(route.component, route.isProfilePath)} key={idx} />
            )}
          </Switch>
        </Router>
      </React.Fragment>
    );
  }
}
export default withTranslation('translations')(App);