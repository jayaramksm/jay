import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import i18n from "i18next";


const AppLanguageTransaltors = () => {

    const language = useSelector(state => {
        return state?.SessionState?.language ? state.SessionState.language : 'en';
    });

    useEffect(() => {
        if (i18n?.language && i18n?.language !== language)
            i18n.changeLanguage(language);
    }, [language]);

    return (
        <>
        </>
    )
}

export default React.memo(AppLanguageTransaltors);
