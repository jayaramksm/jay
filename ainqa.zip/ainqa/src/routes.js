import React from 'react';
import Pageslogin from './pages/Auth/Login';
import Error404 from './pages/ErrorPages/pages-404';
import Error440 from './pages/ErrorPages/pages-440';
import PageUnAuthorized from './pages/ErrorPages/pages-unauthorized';

// -- Admin Modules --
// const ChangePassword = React.lazy(() => import(/* webpackChunkName: "ChangePassword" */'./pages/ProfileManager/Container/changepassword'));

// --* POC Components --* 
const Dashboard1 = React.lazy(() => import(/* webpackChunkName: "dashboard1" */'./pages/Home/Dashboard1.tsx'));
const AdminDashboard1 = React.lazy(() => import(/* webpackChunkName: "adminDashboard1" */'./pages/Home/AdminDashboard1.tsx'));
const ApproveStatutoryDocuments1 = React.lazy(() => import(/* webpackChunkName: "approveStatutoryDocuments1" */'./pages/Home/ApproveStatutoryDocuments1.tsx'));
const ApproveStudyPlan1 = React.lazy(() => import(/* webpackChunkName: "approveStudyPlan1" */'./pages/Home/ApproveStudyPlan1.tsx'));
const Mydocument1 = React.lazy(() => import(/* webpackChunkName: "myDocument1" */'./pages/Home/Mydocument1.tsx'));
const PointofContact1 = React.lazy(() => import(/* webpackChunkName: "pointOfContact1" */'./pages/Home/PointofContact1.tsx'));
const ProgrammeDetail1 = React.lazy(() => import(/* webpackChunkName: "programmeDetail1" */'./pages/Home/ProgrammeDetail1.tsx'));
const Studyplan1 = React.lazy(() => import(/* webpackChunkName: "studyPlan1" */'./pages/Home/Studyplan1.tsx'));
const Portfolio1 = React.lazy(() => import(/* webpackChunkName: "Portfolio1" */'./pages/Elogbook/Portfolio1'));
const EvaluatorFeedback1 = React.lazy(() => import(/* webpackChunkName: "EvaluatorFeedback1" */'./pages/Elogbook/EvaluatorFeedback1'));

const UserManagement1 = React.lazy(() => import(/* webpackChunkName: "userManagement1" */'./pages/UserManagement/UserManagement1.tsx'));
const UniversityManagement1 = React.lazy(() => import(/* webpackChunkName: "universityManagement1" */'./pages/UniversityManagement/UniversityManagement1'));
const UniversityAdmin1 = React.lazy(() => import(/* webpackChunkName: "universityAdmin1" */'./pages/UniversityAdmin/UnivesityAdmin1'));

const UserProfile1 = React.lazy(() => import(/* webpackChunkName: "userProfile1" */'./pages/ProfileManager/UserProfile1'));
const UserProfile = React.lazy(() => import(/* webpackChunkName: "userProfile" */'./pages/ProfileManager/Container/userprofile'));

const ApproveClinicalMeetings1 = React.lazy(() => import(/* webpackChunkName: "approveClinicalMeetings1" */'./pages/ClinicalMeetings/ApproveClinicalMeetings1.tsx'));
const ClinicalMeetings1 = React.lazy(() => import(/* webpackChunkName: "clinicalMeetings1" */'./pages/ClinicalMeetings/ClinicalMeetings1.tsx'));

const ApproveGLA1 = React.lazy(() => import(/* webpackChunkName: "approveGLA1" */'./pages/GeneralLearningAgreements/ApproveGLA1.tsx'));
const ApproveGLA = React.lazy(() => import(/* webpackChunkName: "ApproveGLA" */'./pages/ApproveGla/Container/approveGla'));

const GeneralLearningAgreement1 = React.lazy(() => import(/* webpackChunkName: "generalLearningAgreement1" */'./pages/GeneralLearningAgreements/GeneralLearningAgreement1.tsx'));
const GeneralLearningAgreement = React.lazy(() => import(/* webpackChunkName: "GeneralLearningAgreement" */'./pages/Trainee/Gla/Container/gla'));
const ReqReplofSupervisor1 = React.lazy(() => import(/* webpackChunkName: "reqReplofSupervisor1" */'./pages/GeneralLearningAgreements/ReqReplofSupervisor1.tsx'));

const ApprovePla1 = React.lazy(() => import(/* webpackChunkName: "approvePla1" */'./pages/PlacementofRotations/ApprovePla1.tsx'));
const PlacementofRotations1 = React.lazy(() => import(/* webpackChunkName: "placementOfRotations1" */'./pages/PlacementofRotations/PlacementofRotations1.tsx'));
const ApproveRotationalMeetings = React.lazy(() => import(/* webpackChunkName: "ApproveRotationalMeetings" */'./pages/ApproveRotationalMeetings/Container/approveRotationalMeetings'));

const PlacementofRotation = React.lazy(() => import(/* webpackChunkName: "PlacementofRotation1 */'./pages/Trainee/RotationsandLearningAgreements/Container/rla'));

const RequestReplace1 = React.lazy(() => import(/* webpackChunkName: "requestReplace1" */'./pages/PlacementofRotations/RequestReplace1.tsx'));

const CourseManagement1 = React.lazy(() => import(/* webpackChunkName: "coursemanagement1" */'./pages/CourseManagement/CourseManagement1'));
const HOD1 = React.lazy(() => import(/* webpackChunkName: "hod1" */'./pages/MasterData/HOD1'));
const Programs1 = React.lazy(() => import(/* webpackChunkName: "programs1" */'./pages/MasterData/Programs1'));
const Departments1 = React.lazy(() => import(/* webpackChunkName: "departments1" */'./pages/MasterData/Departments1'));
const Hospitals1 = React.lazy(() => import(/* webpackChunkName: "hospitals1" */'./pages/Hospitals/Hospitals1'));

const Hospitals = React.lazy(() => import(/* webpackChunkName: "Hospitals" */'./pages/Admin/MasterData/Hospitals/Container/hospitals'));

const Programs = React.lazy(() => import(/* webpackChunkName: "Programs" */'./pages/Admin/MasterData/Programs/Container/programs'));
const Departments = React.lazy(() => import(/* webpackChunkName: "Departments" */'./pages/Admin/MasterData/Departments/Container/departments'));
const HOD = React.lazy(() => import(/* webpackChunkName: "hod1" */'./pages/Admin/MasterData/Hods/Container/hods'));
const CourseManagement = React.lazy(() => import(/* webpackChunkName: "coursemanagement" */'./pages/CourseManagement/Container/coursemanagement'));

const UserManagement = React.lazy(() => import(/* webpackChunkName: "userManagement" */'./pages/Admin/UserManagement/Container/usermanagement.tsx'));
const Universities = React.lazy(() => import(/* webpackChunkName: "universities" */'./pages/PlatformAdmin/Universities/container/universities'));
const Portfolio = React.lazy(() => import(/* webpackChunkName: "Portfolio" */'./pages/Trainee/portfolio/Container/portfolio'));

const Elogbook1 = React.lazy(() => import(/* webpackChunkName: "elogbook1" */'./pages/Elogbook/Elogbook1'));
const SurgicalElogbook1 = React.lazy(() => import(/* webpackChunkName: "surgicalelogbook1" */'./pages/Elogbook/SurgicalElogbook1'));

const MyDocuments = React.lazy(() => import(/* webpackChunkName: "MyDocuments" */'./pages/ProfileManager/Container/userprofile'));
const ApproveStatutoryDocuments = React.lazy(() => import(/* webpackChunkName: "approveStatutoryDocuments" */'./pages/ApproveStatutoryDocuments/Container/asd'));

const StudyPlan = React.lazy(() => import(/* webpackChunkName: "StudyPlan" */'./pages/Trainee/StudyPlan/Container/studyplan'));
const ApproveStudyPlan = React.lazy(() => import(/* webpackChunkName: "ApproveStudyPlan" */'./pages/ApproveStudyPlan/Container/ApproveStudyPlan'));
const ApproveRla = React.lazy(() => import(/* webpackChunkName: "approveRla1" */'./pages/approveRla/Container/approveRla'));
const RotationalMeetings = React.lazy(() => import(/* webpackChunkName: "clinicalMeetings1" */'./pages/Trainee/RotationalMeetings/Container/rotationalmeetings'));
const ApprovePortfolio = React.lazy(() => import(/* webpackChunkName: "approvePortfolio" */'./pages/ApprovePortfolio/Container/approvePortfolio'));
const FormConfigurations = React.lazy(() => import(/* webpackChunkName: "FormConfigurations" */'./pages/Configurations/FormConfigurations/Container/formconfiguration'));
const EvaluatorFeedbackForm = React.lazy(() => import(/* webpackChunkName: "EvaluatorFeedbackForm" */'./pages/EvaluatorFeedBackForm/Container/evaluatorFeedbackForm'));

const LearningAgreements1 = React.lazy(() => import(/* webpackChunkName: "LearningAgreements1" */'./pages/Evidence/Components/LearningAgreements1'));
const Wba1 = React.lazy(() => import(/* webpackChunkName: "Wba1" */'./pages/Evidence/Components/WBA1'));
const Meetings1 = React.lazy(() => import(/* webpackChunkName: "Meetings1" */'./pages/Evidence/Components/Meetings1'));
const EvidenceSurgicalLogBook1 = React.lazy(() => import(/* webpackChunkName: "EvidenceSurgicalLogBook1" */'./pages/Evidence/Components/EvidenceSurgicalElogbook1'));
const EvidenceSurgicalLogBook = React.lazy(() => import(/* webpackChunkName: "EvidenceSurgicalLogBook" */'./pages/Evidence/SurgicalElogbook/Container/surgicalElogbook'));
const Wbas = React.lazy(() => import(/* webpackChunkName: "Wbas" */'./pages/Evidence/Wbas/Container/wbas'));
const Meetings = React.lazy(() => import(/* webpackChunkName: "Meetings" */'./pages/Evidence/Meetings/Container/meetings'));
const LearningAgreements = React.lazy(() => import(/* webpackChunkName: "LearningAgreements" */'./pages/Evidence/LearningAgreements/Container/learningAgreements'));


const Email = React.lazy(() => import(/* webpackChunkName: "Email" */'./pages/Configurations/Email/container/email'))

const routes = [
    // public Routes
    { path: '/login', component: Pageslogin, ispublic: true },
    { path: '/profile1', component: UserProfile1, isNotMenuAuth: true },
    { path: '/profile', component: UserProfile, isNotMenuAuth: true },

    { path: '/users', component: UserManagement },
    { path: '/universities', component: Universities },
    { path: '/programs', component: Programs },
    { path: '/departments', component: Departments },
    { path: '/hod', component: HOD },
    { path: '/coursemanagement', component: CourseManagement },
    { path: '/mydocument', component: MyDocuments },
    { path: '/approvestatutorydocs', component: ApproveStatutoryDocuments },
    { path: '/studyplan', component: StudyPlan },
    { path: '/approvestudyplan', component: ApproveStudyPlan },
    { path: '/approverla', component: ApproveRla },
    { path: '/rotationalmeetings', component: RotationalMeetings },
    { path: '/formconfigurations', component: FormConfigurations },
    { path: '/evaluatorFeedbackForm', component: EvaluatorFeedbackForm, ispublic: true, islazy: true },
    { path: '/meetings', component: Meetings },
    { path: '/learningagreements', component: LearningAgreements },

    { path: '/admindashboard1', component: AdminDashboard1 },
    { path: '/dashboard', component: Dashboard1 },
    { path: '/dashboard1', component: Dashboard1 },
    { path: '/approvestatutorydocs1', component: ApproveStatutoryDocuments1 },
    { path: '/approvestudyplan1', component: ApproveStudyPlan1 },
    { path: '/mydocument1', component: Mydocument1 },
    { path: '/pointofcontact1', component: PointofContact1 },
    { path: '/programmedetail1', component: ProgrammeDetail1 },
    { path: '/studyplan1', component: Studyplan1 },
    { path: '/approveclinicalmeetings1', component: ApproveClinicalMeetings1 },
    { path: '/approveclinicalmeeting', component: ApproveRotationalMeetings },
    { path: '/clinicalmeetings1', component: ClinicalMeetings1 },
    { path: '/approveportfolio', component: ApprovePortfolio },
    { path: '/approvegla1', component: ApproveGLA1 },
    { path: '/approvegla', component: ApproveGLA },
    { path: '/gla1', component: GeneralLearningAgreement1 },
    { path: '/gla', component: GeneralLearningAgreement },
    { path: '/reqreplofsupervisor1', component: ReqReplofSupervisor1 },
    { path: '/approvepla1', component: ApprovePla1 },
    { path: '/placementofrotations1', component: PlacementofRotations1 },
    { path: '/placementofrotation', component: PlacementofRotation },
    { path: '/requestreplace1', component: RequestReplace1 },
    { path: '/users1', component: UserManagement1 },
    { path: '/universityadmin1', component: UniversityAdmin1 },
    { path: '/universities1', component: UniversityManagement1 },
    { path: '/coursemanagement1', component: CourseManagement1 },
    { path: '/hod1', component: HOD1 },
    { path: '/programs1', component: Programs1 },
    { path: '/departments1', component: Departments1 },
    { path: '/hospitals1', component: Hospitals1 },
    { path: '/hospitals', component: Hospitals },
    { path: '/elogbook1', component: Elogbook1 },
    { path: '/portfolio', component: Portfolio },
    { path: '/surgicalelogbook1', component: SurgicalElogbook1 },
    { path: '/email1', component: Email },
    { path: '/email', component: Email },
    { path: '/portfolio1', component: Portfolio1 },
    { path: '/evaluatorFeedback1', component: EvaluatorFeedback1 },

    { path: '/meetings1', component: Meetings1 },
    { path: '/wba1', component: Wba1 },
    { path: '/wba', component: Wbas },
    { path: '/agreements1', component: LearningAgreements1 },
    // { path: '/evidencesurgicallogbook1', component: EvidenceSurgicalLogBook1 },
    { path: '/evidencesurgicallogbook', component: EvidenceSurgicalLogBook },

    { path: '/403', component: PageUnAuthorized, ispublic: true },
    { path: '/440', component: Error440, ispublic: true },
    { path: '/404', component: Error404, ispublic: true },
    { path: '/', component: Pageslogin, ispublic: true, ishomeRoute: true },
    { path: '/login/:type', component: Pageslogin, ispublic: true, ishomeRoute: true },
    { path: '*', component: Error404, ispublic: true, ishomeRoute: true },
];
export default routes;