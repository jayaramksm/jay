import { call } from 'redux-saga/effects';
import { getApiServiceUrlByComponentAndMethod, serviceConsumer, gettranId, getMessageCode } from './helpersIndex';
import { IAlertMessagedata, EAPIComponentNames } from '../models/utilitiesModel';


function* getUrlAfterFileUpload(fileData, modulesCode: string) {
    const tranId = gettranId(modulesCode);
    console.log(`${tranId}_getUrlAfterFileUpload_Start=>`);

    let fileUrls: any[] = [];
    let alertMessageData: IAlertMessagedata | undefined;
    try {
        const formData = new FormData();
        for (let i = 0; i < fileData.length; i++)
            formData.append('files', fileData[i]);

        let componentAndMethod = getApiServiceUrlByComponentAndMethod(EAPIComponentNames.FILE_UPLOAD, 'uploadFile');
        console.log(`${tranId}_getUrlAfterFileUpload_Api_Request => `, { componentAndMethod, formData });
        const response = yield call(serviceConsumer, tranId, componentAndMethod, formData, null);
        console.log(`${tranId}_getUrlAfterFileUpload_Api_Response => `, response);

        if (response.status && response.fileData?.length)
            fileUrls = response.fileData;
        else {
            alertMessageData = {
                message: response.messages || 'unableToUploadFile',
                status: false,
                tranId: Date.now(),
                transKey: response.messages ? '' : 'Utilities.',
                messageCode: response.messages ? tranId : getMessageCode(tranId, 'unableToUploadFile')
            }
        }
    }
    catch (error) {
        console.error(`${tranId}_getUrlAfterFileUpload_error => `, error.messages || 'failedToUploadFile');
        console.log(`${tranId}_getUrlAfterFileUpload_catch => `, error);
        alertMessageData = {
            message: error.messages || 'unableToUploadFile',
            status: false,
            tranId: Date.now(),
            messageCode: getMessageCode(tranId, 'unableToUploadFile'),
            transKey: error.messages ? 'controleErrors.' + error.messages : 'Utilities.',
            statusCode: error.statuscode || 0
        };
    }
    console.log(`${tranId}_getUrlAfterFileUpload_End => `, { fileUrl: fileUrls, alertMessageData });
    return { fileUrls, alertMessageData };
}


export { getUrlAfterFileUpload };