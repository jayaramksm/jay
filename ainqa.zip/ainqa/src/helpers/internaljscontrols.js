import { store } from './helpersIndex';
import { EUserManagementFilterKeys, EBulkUploadUsers } from '../models/utilitiesModel';
import moment from 'moment';

const encryptSecretKey = 'Gr3@tW@t3rS@lt@1B2c3D4e5F6g7H8';
const replaceData = [
    { keyName: 'userId', ReplaceKey: /{userid}/g, defultVal: 0 },
    { keyName: 'roleId', parentKeyName: 'roles', ReplaceKey: /{roleid}/g },
    { keyName: 'roleCode', parentKeyName: 'roles', ReplaceKey: /{rolecode}/g },
    { keyName: 'universityId', parentKeyName: 'university', ReplaceKey: /{universityid}/g },
    { keyName: 'trId', parentKeyName: 'trainee', ReplaceKey: /{traineeid}/g }
];
const customPatterns = [
    { type: 'alphanumaricsp', pattern: /^[a-zA-Z0-9]*$/, message: 'alphanumaric', alowChar: '^[a-zA-Z0-9{spacial}]*$' },
    { type: 'notarbicspn', pattern: /^[a-zA-Z0-9]*$/, message: 'alphanumaric', alowChar: '^[^\u0621-\u064A{spacial}]*$' },
    { type: 'alphanumericspacesp', pattern: /^[a-zA-Z0-9 ]*$/, message: 'alphanumaricandspace', alowChar: '^[a-zA-Z0-9 {spacial}]*$' },
    { type: 'alphasp', pattern: /^[a-zA-Z]*$/, message: 'alpha', alowChar: '^[a-zA-Z{spacial}]*$' },
    { type: 'alphaspacesp', pattern: /^[a-zA-Z ]*$/, message: 'alphaspace', alowChar: '^[a-zA-Z {spacial}]*$' },
    { type: 'alphanumaricallspecials', pattern: /^[a-zA-Z0-9 !”$@^#.?"':&’()*+-<>%,/;[\\\]^_`{|}~\n]*$/, message: 'arabicnumaricspecial', alowChar: null },
    { type: 'arabicnumaricallspecial', pattern: /^[\u0621-\u064A,0-9 !”$@^#.?"':&’()*+<>%,/;[\\\]^_`{|}~\n-]*$/, message: 'arabicnumaricspecial', alowChar: null },
    { type: 'arabicnumaricspacesp', pattern: /^[\u0621-\u064A0-9 ]*$/, message: 'arabicnumaricspace', alowChar: '^[\u0621-\u064A0-9 {spacial}]*$' },
    { type: 'arabicnumaricsp', pattern: /^[\u0621-\u064A0-9]*$/, message: 'arabicnumaricspace', alowChar: '^[\u0621-\u064A0-9{spacial}]*$' },
    { type: 'number', pattern: /^[0-9]{1,500}$/, message: 'number', alowChar: null },
    { type: 'commaseparatenumbers', pattern: /^[0-9]{1}[0-9,]*$/, message: 'commaseparatenumbers', alowChar: null },
    { type: 'capitalsAndNumbers', pattern: /^[A-Z0-9]*$/, message: 'capitalsAndNumbers', alowChar: null },
    { type: 'alphaCapitals', pattern: /^[A-Z]*$/, message: 'alphaCapitals', alowChar: null },
    { type: 'alphanumricwithoutspaceandallspecial', pattern: /^[a-zA-Z0-9!”$@^#.<>?":%&’()*+,/;[\\\]^_`{|}~-]+$/, message: 'alphanumricwithoutspaceandallspecial', alowChar: null },
    { type: 'onlyCoustomumbersAreAllowed', pattern: /^(5|10|20|30|40|50|60)$/, message: 'onlyCoustomumbersAreAllowed', alowChar: '^({spacial})$' },
    { type: 'onlyAllowSpecialChar', pattern: /^[=!”$@^#.?"':&’()*+<>%,/;[\\\]^_`{|}~-]*$/, message: 'onlyAllowSpecialChar', alowChar: '^[{spacial}]*$' },
    { type: 'traineeIcNumber', pattern: /^([0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(-[A-Za-z0-9]{2})(-[A-Za-z0-9]{4})$/, message: 'traineeIcNumber', alowChar: null },
    { type: 'dateFormat', pattern: /^(0[1-9]|[12][0-9]|3[01])[-](0[1-9]|1[012])[-](19|20)\d\d$/, message: 'dateFormat', alowChar: null },
    { type: 'customWords', pattern: /^()$/, message: 'customWords', alowChar: '^({spacial})$' },
    { type: 'numbersWithoutZero', pattern: /^(0*[1-9][0-9]*(\.[0-9]+)?|0+\.[0-9]*[1-9][0-9]*)$/gm, message: 'numbersWithoutZero', alowChar: null },

];

const patterns = [
    { type: 'website', pattern: /^((http|https?|ftp|smtp):\/\/)?(www.)?([a-z0-9]+\.[a-z])?[a-z0-9]+\.[a-z]+(\/[a-zA-Z0-9#]+\/?)*$/ },
    { type: 'path', pattern: /^(\/\w+){0,10}\/?$/ },
    { type: 'comaSaparateMobileNumber', pattern: /^((\d{10,15})|((\d{10,15})(,\d{10,15})*))$/ },
    { type: 'multiEmail', pattern: /^(\s?[^\s,]+@[^\s,]+\.[^\s,]+\s?,)*(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$/g },
    { type: 'domain', pattern: /([a-z0-9]+\.)*[a-z0-9]+\.[a-z]+/ },
    { type: 'htmlTags', pattern: /<([^/>]+)\/>/g },
    { type: 'test', pattern: /^(\w+\s?)*\s*$/ },
    { type: 'roomNo', pattern: /^(?:(([0-9A-Z]{1,3})([,][0-9A-Z]{1,3})*)|([A-Z0-9]{1,3})|\d{1,3}-\d{1,3})$/ },
    { type: 'ipPattern', pattern: /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/ },
    { type: 'host', pattern: /^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/ },
    { type: 'path', pattern: /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]/ },
    { type: 'ipOrDomain', pattern: /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|(([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]))$/ },
    { type: 'server', pattern: /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|(([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]))$/ },
];

const selectStyles = {
    menuList: styles => ({ ...styles, maxHeight: '200px', msOverflowStyle: "auto", wordBreak: "break-all", border: "1px solid #CED4DA", borderRadius: "5px", color: "#444444" })
};

export function toDataUrl(url, callback) {
    try {
        var xhr = new XMLHttpRequest();
        xhr.onload = function () {
            var reader = new FileReader();
            reader.onloadend = function () {
                callback(reader.result);
            }
            reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
        xhr.onerror = () => callback('data:')
    }
    catch (e) {
        console.log('toDataUrl_Catch=>', e)
        callback('data:')
    }
}

// expects public urls & return base64 strings
// const getMultipleBase64Urls = (publicUrlsArr) => {
//     return new Promise((resolve, reject) => {
//         Axios.all(publicUrlsArr.map(url => convertImagePathToBase64(url))).then(res => resolve(res)).catch(err => reject(err));
//     });
// }

const getEnvironment = {
    pageSize: process.env.NODE_ENV === 'production' ? 7 : 7,
    pageRightSize: process.env.NODE_ENV === 'production' ? 5 : 5,
    listPageSize: process.env.NODE_ENV === 'production' ? 20 : 20
};

const validateFileData = async (validationSchema, data) => {
    let validateStatus = await validationSchema.isValid(data);
    return await validateStatus;
}

const getRoleCode = () => store.getState()['SessionState']?.userDto?.roles?.roleCode;

const getBulkUploadCsvHeaders = (user) => {
    switch (user) {
        case EBulkUploadUsers.PROGRAMS:
            return {
                programName: "Program Name *",
                programCode: 'Program Code *'
            }
        case EBulkUploadUsers.DEPARTMENTS:
            return {
                departmentName: "Department Name *",
                departmentCode: "Department Code *",
                location: "Location"
            }
        case EBulkUploadUsers.HOD:
            return {
                contactNo: "Contact No *",
                eportfolioEmailId: "EportFolio Eamil Id *",
                gender: "Gender *",
                hodFullName: "HOD Full Name *",
                mmcNo: "MMC No *",
                umId: "UM ID *"
            }
        case EBulkUploadUsers.HOSPITALS: return {
            hospitalName: "Hospital Name *",
            hospitalCode: "Hospital Code *",
            contactName: "Contact Name ",
            contactNum: "Contact Number ",
            emailId: "Email Id",
            location: "Location"
        }
        default: return {}
    }
}

const getModifiedDate = (inputDate = '', modifier) => {
    const splitter = inputDate.includes('-') ? '-' : (inputDate.includes('/') ? '/' : '');
    if (modifier) {
        const [inputDay = '', inputMonth = '', inputYear = ''] = inputDate.split(splitter);
        if (inputDay && inputMonth && inputYear)
            return `${inputYear}-${inputMonth}-${inputDay}`;
        else return '';
    } else {
        const [inputYear = '', inputMonth = '', inputDay = ''] = inputDate.split(splitter);
        if (inputDay && inputMonth && inputYear)
            return `${inputDay}-${inputMonth}-${inputYear}`;
        else return '';
    }
}

const getFileSizeInMb = (fileSize = 0) => fileSize ? (fileSize / 1024 / 1024) : 0;
const getFileExtension = (fileName = '') => fileName ? (fileName.split('.')?.pop()) : '';

// returns data based on the search key specified in the filter obj
const getFilteredDataAfterSearch = (data, filterKeys, searchKey, rolesObj = {}) => {
    if (data?.length) {
        data = data.filter(x => {
            let dataExists = false;
            filterKeys.forEach(y => {
                if (y === EUserManagementFilterKeys.USER_TYPE && rolesObj[x[y]]?.startsWith(searchKey))
                    dataExists = true;
                else if (String(x[y])?.startsWith(searchKey))
                    dataExists = true;
            });
            return dataExists;
        });
    }
    return data;
}

const bulkUploadRecordsCount = (validData, invalidData, invalidDataFromApi) => {
    let msg = `Total Processed Rows: ${validData.length + invalidData.length}, 
    No. of Rows Uploaded Successfully: ${validData.length - invalidDataFromApi.length}, 
    No. of Failure Rows:${invalidData.length + invalidDataFromApi.length}`
    console.log('responseMessage==>', msg)
    return msg;
}

const getMomentModifiedDateObject = dateObj => {
    if (dateObj)
        return moment(new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate(), 0, 0, 0, 0));
    else return dateObj;
}

export { encryptSecretKey, getMomentModifiedDateObject, getBulkUploadCsvHeaders, bulkUploadRecordsCount, getModifiedDate, getFileSizeInMb, getFileExtension, getFilteredDataAfterSearch, getRoleCode, replaceData, validateFileData, getEnvironment, customPatterns, patterns, selectStyles };