export interface IClinicalMeetingsModel {
    actionType: number;
    actionData: any;
    searchkey: string;
    hodsData: IHod[];
    rotationalSupervisorsData: IRotationalSupervisors[];
    studyPlanRotationsData: IRotations[];
    allClinicalMeetingsData: IClinicalMeetings[];
    paginationCurrentPage: number;
    currentDateAndTime: ICurrentDateAndTime,
    studyPlanstatus: IstudyPlanStaus
};

export enum EMeetingType {
    InitialMeeting = 'Initial Meeting',
    InterimMeeting = 'Interim Meeting',
    FinalMeeting = 'Final Meeting'
}

export interface IClinicalMeetings {
    educationalSupervisorId: string
    esName: string
    firstRotationSupervisor: IFirstRotationSupervisor
    hodId: string
    hodName: string
    hospitalName: string
    otherHospitalName: string
    isFinalMeeting: string
    meetingDateTime: string
    meetingType: string
    mohName: string
    mohSupervisorId: string
    nextMeetingDate: string
    programName: string
    rotationDuration: string
    rotationId: string
    rotationName: string
    rotationalMeetingId: string
    secondRotationSupervisor: ISecondRotationSupervisor
    stage: string
    traineeComments: string
    traineeId: string
    traineeMailId: string
    traineeName: string
    userId: string
    createdOn: string
}

export interface IFirstRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface ISecondRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface IUpdateRotationalMeeting {
    firstSupervisorEmail: string
    firstSupervisorId: string
    firstSupervisorName: string
    hodId: string
    isFinalMeeting: boolean
    meetingDateTime: string
    meetingType: string
    nextMeetingDate: string
    oldFirstRsMail: string
    oldFirstRsName: string
    oldFirstSupervisorId: string
    oldSecondRsMail: string
    oldSecondRsName: string
    oldSecondSupervisorId: string
    programmeName: string
    rotation: string
    rotationId: string
    rotationalMeetingId: string
    secondSupervisorEmail: string
    secondSupervisorId: string
    secondSupervisorName: string
    stage: string
    traineeComments: string
    traineeId: string
    traineeName: string
}

export interface ICreateRotationalMeeting {
    firstSupervisorEmail: string
    firstSupervisorId: string
    firstSupervisorName: string
    hodId: string
    isFinalMeeting: boolean
    meetingDateTime: string
    meetingType: string
    nextMeetingDate: string
    programId: string
    programmeName: string
    rotationId: string
    rotationName: string
    secondSupervisorEmail: string
    secondSupervisorId: string
    secondSupervisorName: string
    stage: string
    traineeComments: string
    traineeId: string
    traineeName: string
}



export interface IRotations {
    hospitalId: string
    hospitalName: string
    otherHospitalName: string
    rotation: string
    rotationDuration: string
    rotationEndDate: string
    rotationId: string
    rotationSequence: string
    rotationStageName: string
    rotationStartDate: string
    rotationStatus: string
    stage: string
    wbas: Wba[]
}

export interface Wba {
    planned: string
    wbaExpected: string
    wbaId: string
    wbaName: string
}


export interface IHod {
    contactNo: string;
    departments: IDepartment[];
    eportfolioEmailId: string;
    gender: string;
    hodFullName: string;
    hodId: string;
    mmcNo: string;
    umId: string;
}

export interface IDepartment {
    departmentCode: string;
    departmentId: string;
    departmentName: string;
    location: string;
}


export interface IRotationalSupervisors {
    correspondentAddress: string
    correspondentCountry: string
    departmentIds: string[]
    designation: string
    dob: string
    employeeId: string
    eportfolioEmailId: string
    gender: string
    isActive: number
    isFirstLogin: number
    isMohSupervisor: boolean
    isSameAddress: number
    mmcno: string
    mobileno1: string
    mobileno2: string
    mohId: string
    personalEmailId: string
    profileUrl: string
    programId: string
    residentialAddress: string
    residentialCountry: string
    resourceCode: string
    roleId: string
    trainee: Trainee
    universityId: string
    userFullName: string
    userId: string
    userName: string
    userType: string
}

export interface Trainee {
    anmno: string
    coEducationalSupervisor: string
    educationalSupervisor: string
    nsrno: string
    pathwayTag: string
    remark: string
    trActiveFrom: string
    trActiveTo: string
    trIcNo: string
    trId: string
    trLegacyCode: string
    trMohUser: string
    trStatus: string
}

export interface ICurrentDateAndTime {
    date: string
    dateTime: string
    hours: string
    minutes: string
    seconds: string
    time: string
}

export interface IstudyPlanStaus {
    messages: string;
    status: boolean;
    statusCode: number;
}

