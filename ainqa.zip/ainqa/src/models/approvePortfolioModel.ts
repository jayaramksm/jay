export interface IApprovePortfolioMOdel {
    actionType: number;
    actionData: any;
    portfoliosData: IPortfolio[];
    searchKey: string;
    paginationCurrentPage: number;
    currentDate: ICurrentDateAndTime,
    portfolioActionData: any;
    assessmentModelData: any;
}

export enum ECodeOptions {
    WBA = 'WBA',
    SURLOG = 'SURLOG'
}
export enum EEvaluatorFeedBack {
    APPROVED = '1',
    PENDING = '0'
}

export interface ICurrentDateAndTime {
    date: string;
    dateTime: string;
    hours: string;
    minutes: string;
    seconds: string;
    time: string;
}
export enum ESubCode {
    CBD = 'cbd',
    CEX = 'cex',
    DOPS = 'dops',
    MSF = 'msf',
    PBA = 'pba',
    PSA = 'psa',
    NOTSA = 'notsa',
    DOCE = 'doce',
    SURLOG = 'surlog'
}
export interface IPortfolio {
    code: string
    completedDate: string
    dueDate: string
    evaluatorFeedBack: IEvaluatorFeedBack[];
    feedBackStatus: string
    fileData: IFileData[]
    firstRotationSupervisor: IFirstRotationSupervisor
    formData: string
    isAssessed: boolean
    portfolioId: string
    programId: string
    programName: string
    rotationId: string
    rotationName: string
    secondRotationSupervisor: ISecondRotationSupervisor
    stageId: string
    stageName: string
    traineeId: string
    traineeMailId: string
    traineeName: string
    traineeUserId: string
    wba: string
    wbaName: string
    hospitalId: string;
    hospitalName: string;
    updatedOn: string;
    otherHospitalName: string;
}


export interface IEvaluatorFeedBack {
    createdOn: string,
    evaluatorEmailId: string;
    evaluatorFeedBackId: string;
    evaluatorFormData: string;
    evaluatorFormId: string;
    status: string;
    uniqueId: string;

}


export interface FileData {
    fileName: string;
    filePath: string;
}

export interface FirstRotationSupervisor {
    approvedOn: string;
    comments: string;
    status: string;
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}

export interface SecondRotationSupervisor {
    approvedOn: string;
    comments: string;
    status: string;
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}





export interface IFileData {
    file_name: string
    file_path: string
}

export interface IFirstRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface IFormData { }

export interface ISecondRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}
