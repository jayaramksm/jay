export interface IDepartmentsMOdel {
    actionType: number;
    actionData: any;
    departmentsDetails: IDepartments[];
    searchKey: string;
    paginationCurrentPage: number;
    fileUploadHistory: any;
}

export interface IDepartments {
    departmentCode: string;
    departmentId: string;
    departmentName: string;
    location: string;
}