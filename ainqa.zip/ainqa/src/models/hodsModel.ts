export interface IHodsModel {
    hodsData: IHod[];
    departmentData: any;
    actionType: number;
    actionData: any;
    searchKey: string;
    uploadedFilesInfo: any;
    currentDate: any;
    paginationCurrentPage: number;
}


export interface IHod {
    contactNo: string;
    departments: IDepartment[];
    eportfolioEmailId: string;
    gender: string;
    hodFullName: string;
    hodId: string;
    mmcNo: string;
    umId: string;
}

export interface IDepartment {
    departmentCode: string;
    departmentId: string;
    departmentName: string;
    location: string;
}