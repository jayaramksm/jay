export interface IApproveRlasMOdel {
    actionType: number;
    actionData: IRla[];
    approveRlasData: IRla[];
    searchKey: string;
    paginationCurrentPage: number;
    rlaActionData: IRla;
}

export interface IRla {
    createdOn: string;
    educationalSupervisorId: string;
    esName: string;
    expectedWbas: IExpectedWba[];
    firstRotationalSupervisor: IFirstRotationalSupervisor;
    hodId: string;
    hodName: string;
    hospitalId: string;
    hospitalName: string;
    otherHospitalName: string;
    mohName: string;
    mohSupervisorId: string;
    placementAmisObject: string;
    plannedAbsencesConferences: string;
    programId: string;
    programName: string;
    rlaId: string;
    rotationDuration: string;
    rotationEndDate: string;
    rotationId: string;
    rotationName: string;
    rotationStartDate: string;
    secondRotationSupervisor: ISecondRotationSupervisor;
    stage: string;
    stageName: string;
    traineeId: string;
    traineeMailId: string;
    traineeName: string;
    traineeSignature: string;
    userId: string;
    spRotationId:string;
}

export interface IExpectedWba {
    completed: string;
    planned: string;
    wbaExpected: string;
    wbaId: string;
    wbaName: string;
}

export interface IFirstRotationalSupervisor {
    approvedOn: string;
    comments: string;
    signature: string;
    status: string;
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}

export interface ISecondRotationSupervisor {
    approvedOn: string;
    comments: string;
    signature: string;
    status: string;
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}


export enum ESupervisor {
    firstSupervisor = 'rotationFirstSupervisor',
    secondSupervisor = 'rotationSecondSupervisor'
}

