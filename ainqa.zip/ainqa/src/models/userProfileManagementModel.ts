export interface IUserProfileManagementModel {
    actionType: number;
    loading: boolean;
    errorMessage: IAlertMessagedata;
    userProfileData: IUserProfileDetails,
    profilePictureInfo: IUploadedProfilePhotoInfo
}

export interface IUpdateUser {
    correspondent_address: string;
    correspondent_country: string;
    is_same_address: number;
    mobileno_1: string;
    mobileno_2: string;
    personal_email_id: string;
    residencial_address: string;
    residencial_country: string;
    profile_url: string;

}

export interface IUploadedProfilePhotoInfo {
    filePath: string;
    logo: string;
    messages: string;
    status: boolean;
    statusCode: number;
}

export interface IAlertMessagedata {
    message: string;
    messageCode?: string;
    transKey?: string;
    status: boolean;
    tranId: number;
    statusCode?: number;
}



export interface IUserProfileDetails {
    correspondentAddress: string
    correspondentCountry: string
    departmentIds: string[]
    designation: string
    dob: string
    employeeId: string
    eportfolioEmailId: string
    gender: string
    isActive: number
    isFirstLogin: number
    isMohSupervisor: boolean
    isSameAddress: number
    mmcno: string
    mobileno1: string
    mobileno2: string
    mohId: string
    personalEmailId: string
    profileUrl: string
    programId: string
    residentialAddress: string
    residentialCountry: string
    resourceCode: string
    roleId: string
    trainee: ITrainee
    universityId: string
    userFullName: string
    userId: string
    userName: string
    userType: string
}

export interface ITrainee {
    anmno: string
    coEducationalSupervisor: string
    educationalSupervisor: string
    nsrno: string
    pathwayTag: string
    remark: string
    trActiveFrom: string
    trActiveTo: string
    trIcNo: string
    trId: string
    trLegacyCode: string
    trMohUser: number
    trStatus: string
}

