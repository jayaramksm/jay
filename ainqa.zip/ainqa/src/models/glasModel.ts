export interface IGlasModel {
    glasData: IGla[];
    departmentData: any;
    actionType: number;
    actionData: any;
    paginationCurrentPage: number;
    usersDta: IUser[]
}


export interface IGla {
    agreementDate: string;
    communication: string;
    esApprovedON: string;
    esComments: string;
    esId: string;
    esStatus: string;
    esUserName: string;
    esSignature: string;
    glaId: string;
    matricNumber: string;
    mohApprovedOn: string;
    mohComments: string;
    mohId: string;
    mohStatus: string;
    mohUserName: string;
    mohSignature: string;
    period: string;
    programId: string;
    status: string;
    traineeId: string;
    traineeUserId: string;
    universityId: string;
}

export enum EActiveStatus {
    TRUE = "true",
    FALSE = "false"
}




export interface IUser {
    designation: string;
    correspondentAddress: string;
    correspondentCountry: string;
    departmentIds: string[];
    dob: string;
    employeeId: string;
    eportfolioEmailId: string;
    gender: string;
    isActive: number;
    isFirstLogin: number;
    isMohSupervisor: boolean;
    isSameAddress: number;
    mmcno: string;
    mobileno1: string;
    mobileno2: string;
    mohId: string;
    personalEmailId: string;
    profileUrl: string;
    programId: number | string;
    residentialAddress: string;
    residentialCountry: string;
    resourceCode: string;
    roleId: number | string;
    trainee: ITrainee;
    universityId: string;
    userFullName: string;
    userId: string;
    userName: string;
    userType: string;
}


export interface ITrainee {
    anmno: string;
    coEducationalSupervisor: string;
    educationalSupervisor: string;
    mohSupervisor: boolean;
    nsrno: string;
    pathwayTag: string;
    remark: string;
    trActiveFrom: string;
    trActiveTo: string;
    trIcNo: string;
    trId: string;
    trLegacyCode: string;
    trMohUser: number;
    trStatus: string;
}