export interface IEvaluatorFeedbackFormModel {
    feedbackFormData: any;
    updateFeedbackFormData: any;
    actionType: any;
    actionData: any;
    isModelOpen: boolean;
}

export interface ItraineeFormData {
    code: string
    completedDate: string
    dueDate: string
    evaluatorEmailId: string
    evaluatorFeedbackId: string
    evaluatorFormData: string
    evaluatorFormId: string
    fileData: IFileData[]
    firstRotationSupervisor: IFirstRotationSupervisor
    formData: string
    isAssessed: string
    portfolioId: string
    programId: string
    programName: string
    rotationId: string
    rotationName: string
    secondRotationSupervisor: ISecondRotationSupervisor
    stageId: string
    stageName: string
    status: string
    traineeId: string
    traineeMailId: string
    traineeName: string
    traineeUserId: string
    wba: string
    wbaName: string
}

export interface IFileData {
    fileName: string
    filePath: string
}

export interface IFirstRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface ISecondRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export enum ESubCode {
    CBD = 'cbd',
    CEX = 'cex',
    DOPS = 'dops',
    MSF = 'msf',
    PBA = 'pba',
    PSA = 'psa',
    NOTSA = 'notsa',
    DOCE = 'doce',
    SURLOG = 'surlog'
}


export enum EFeedbackSumbitedStatus {
    SUBMITED = '1',
    NOTSUBMITED = '0',
    INVALIDLINK = '-1'
}