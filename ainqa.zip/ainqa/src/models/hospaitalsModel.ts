export interface IHospaitalsModel {
    HospitalsData: IHospital[];
    actionType: number;
    paginationCurrentPage: number;
    actionData: any;
    searchKey: string;
    uploadedFilesInfo: any;
    currentDate: any;
}

export interface IHospital {
    contactName: string;
    contactNum: string;
    emailId: string;
    hospitalCode: string;
    hospitalId: string;
    hospitalName: string;
    location: string;
}