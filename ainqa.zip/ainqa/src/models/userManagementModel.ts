import { IUniversity } from './utilitiesModel';

export interface IUserManagementModel {
    usersData: IUser[];
    rolesData: IRoles[];
    deptsData: IDepartment[];
    programsData: IProgram[];
    programmeCodeDetailsList: any;
    universitiesData: IUniversity[];
    actionType: number;
    actionData: any;
    searchKey: string;
    uploadedFilesInfo: any;
    currentDate: any;
    paginationCurrentPage: number;

    programeeDetails: IProgrammeCode[];
    universityCode: IUniversityCode[];
}
export interface IRoles {
    roleCode: string;
    roleId: number;
    roleName: string;
}
export interface ITrainee {
    anmno: string;
    coEducationalSupervisor: string;
    educationalSupervisor: string;
    mohSupervisor: boolean;
    nsrno: string;
    pathwayTag: string;
    remark: string;
    trActiveFrom: string;
    trActiveTo: string;
    trIcNo: string;
    trId: string;
    trLegacyCode: string;
    trMohUser: number;
    trStatus: string;
}

export interface IUser {
    designation: string;
    correspondentAddress: string;
    correspondentCountry: string;
    departmentIds: string[];
    dob: string;
    employeeId: string;
    eportfolioEmailId: string;
    gender: string;
    isActive: number;
    isFirstLogin: number;
    isMohSupervisor: boolean;
    isSameAddress: number;
    mmcno: string;
    mobileno1: string;
    mobileno2: string;
    mohId: string;
    personalEmailId: string;
    profileUrl: string;
    programId: number | string;
    residentialAddress: string;
    residentialCountry: string;
    resourceCode: string;
    roleId: number | string;
    trainee: ITrainee;
    universityId: string;
    userFullName: string;
    userId: string;
    userName: string;
    userType: string;
}

export interface IProgram {
    phaseDistribution: string;
    programCode: string;
    programId: string;
    programName: string;
}

export interface IProgrammeCode {
    programCode: string;
    programId: number;
    programName: string;
}
export interface IUniversityCode {
    universityCode: string;
    universityId: number;
    universityName: string;
}

export enum ECreationType {
    SINGLEUSERCREARION = '0',
    BULKUPLAODCREATION = '1'
}

export enum EUserActiveInactive {
    ACTIVE = 'A',
    INACTIVE = 'I'
}

export interface IFailedUser {
    eportfolioEmailId: string;
    failedReason: string;
    gender: string;
    mobileno1: string;
    mobileno2: string;
    resourceCode: string;
    trainee: ITrainee;
    userFullName: string;
    userName: string;
}

export interface IBulkUploadResponse {
    failedUsers: IFailedUser[];
    messages: string;
    status: boolean;
    statusCode: number;
}

export interface IColumnData {
    eportfolioEmailId: string;
    gender: string;
    mobileno1: string;
    mobileno2: string;
    resourceCode?: string;
    userFullName: string;
    userName: string;
    anmno?: string;
    dob?: string;
    isSameAddress?: number;
    mmcno?: string;
    nsrno?: string;
    permenentAddress?: string;
    permenentCountry?: string;
    programCode?: string;
    remark?: string;
    residentialAddress?: string;
    residentialCountry?: string;
    trActiveFrom?: string;
    trActiveTo?: string;
    trIcNo?: string;
    trLegacyCode?: string;
    trMohUser?: string;
    trPersonalEmail?: string;
    trStatus?: string;
    universityCode?: string;
}
export interface IBulkUploadData {
    selectedRole: IRoles,
    mappedColumns: IColumnData,
    validationSchema: any,
    extension: string,
    data: any,
    translator: any
}

export enum EBulkUploadStatus {
    FILE_VALIDATED = '1',
    PROCESSING = '2',
    HEADERS_MATCHED = '3',
    DEFAULT = ''
}

export interface IDepartment {
    departmentCode: string;
    departmentId: string;
    departmentName: string;
    location: string;
}

export enum EPathwayTags {
    OPEN = "open",
    CLOSED = "closed",
    HYBRID = "hybrid"
}