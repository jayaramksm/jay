export interface IStudyPlanModel {
    actionType: number;
    actionData: IStudyPlan;
    studyPlansData: IStudyPlan[];
    predefinedRotations: IPredefinedRotations[];
    hospitalsData: IHospital[],
    rotationsActionData: any;
    paginationCurrentPage: number;
    currentDateAndTime: ICurrentDateAndTime;
}

export interface ICurrentDateAndTime {
    date: string
    dateTime: string
    hours: string
    minutes: string
    seconds: string
    time: string
}

export enum EStudyPlanStatus {
    APPROVED = 'approved',
    REJECTED = 'rejected',
    PENDING = 'pending',
    FAILED = 'failed',
    COMPLETED = 'completed',
    ACTIVE = "active",
}

export interface IStudyPlan {
    approvalComments: string
    approvalStatus: string
    approvedBy: string
    approvedDate: string
    programId: string
    programName: string
    rotations: IRotation[]
    studyPlanId: string;
    isUpdateFromView?: boolean;
    stage?: string;
    studyplan: any;
    chartPath?: number;
}

export interface IRotation {
    approvedBy: string
    approvedOn: string
    hospitalId: string
    hospitalName: string
    isWbaFiled: boolean
    otherHospitalName: string
    rotation: string
    rotationComments: string
    rotationDuration: string
    rotationId: string
    rotationSequence: string
    rotationStageName: string
    rotationStatus: string
    spRotationId: string
    stage: string
    stageStatus: string;
    rotationEndDate: string;
    rotationStartDate: string;
}

export interface ICreateStudyPlan {
    approvalStatus: string
    program: string
    programName: string
    rotations: ICreateRotation[]
    trainee: string
    traineeName: string
    university: string
}

export interface ICreateRotation {
    hospitalId: string
    otherHospitalName: string
    rotationComments: string
    rotationId: string
    rotationSequence: string
    rotationStatus: string
    stage: string
    stageStatus: string
}

export interface IUpdateStudyPlan {
    approvalComments: string
    approvalStatus: string
    program: string
    programName: string
    rotations: IUpdateRotation[]
    studyPlanId: string
    trainee: string
    traineeName: string
}

export interface IUpdateRotation {
    hospitalId: string
    otherHospitalName: string
    rotationComments: string
    rotationId: string
    rotationSequence: number
    rotationStatus: string
    spRotationId: string
    stage: string
}

export interface IPredefinedRotations {
    phaseDenominationId: string
    programId: string
    rotationCode: string
    rotationDuration: string
    rotationId: string
    rotationName: string
    wbas: IWba[]
}

export interface IWba {
    wbaDigitalForm?: string
    wbaExpected: string
    wbaId?: string
    wbaName: any;
}

export interface IHospital {
    contactName: string;
    contactNum: string;
    emailId: string;
    hospitalCode: string;
    hospitalId: string;
    hospitalName: string;
    location: string;
}

