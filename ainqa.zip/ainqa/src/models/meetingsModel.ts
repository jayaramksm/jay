export interface IMeetingsModel {
    actionType: number;
    actionData: any;
    searchkey: string;
    allMeetingsData: IMeetingsData[];
    paginationCurrentPage: number;
    meetingsActionData: any;
};

export interface IMeetingsData {
    createdOn: string
    educationalSupervisorId: string
    esName: string
    firstRotationSupervisor: IFirstRotationSupervisor
    hodId: string
    hodName: string
    hospitalName: string
    isFinalMeeting: boolean
    meetingDateTime: string
    meetingType: string
    mohName: string
    mohSupervisorId: string
    nextMeetingDate: string
    otherHospitalName: string
    programName: string
    rotationDuration: string
    rotationEndDate: string
    rotationId: string
    rotationName: string
    rotationStartDate: string
    rotationalMeetingId: string
    secondRotationSupervisor: ISecondRotationSupervisor
    stage: string
    traineeComments: string
    traineeId: string
    traineeMailId: string
    traineeName: string
    userId: string
}

export interface IFirstRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface ISecondRotationSupervisor {
    approvedOn: string
    comments: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}
