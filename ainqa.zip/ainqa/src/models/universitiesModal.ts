export interface IUniversitiesModal {
    actionType: number,
    actionData: any,
    searchKey: string,
    currentPage: number,
    universitiesList: IUniversity[],
}

export interface IUniversity {
    country: string;
    location: string;
    pincode: string;
    primaryContact: string;
    primaryContactDesignation: string;
    primaryContactEmailId: string;
    primaryName: string;
    secondaryContact: string;
    secondaryContactDesignation: string;
    secondaryContactEmailId: string;
    secondaryName: string;
    universityCode: string;
    universityId: string;
    universityName: string;
    website: string;
    zipCode: string;
}

