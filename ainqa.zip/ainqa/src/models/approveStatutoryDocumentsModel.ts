export interface IApproveStatutoryDocumentsMOdel {
    actionType: number;
    actionData: any;
    asdsData: ITrainee[];
    searchKey: string;
    paginationCurrentPage: number;
    fileData: any;
}

export interface IFileData {
    fileName: string;
    filePath: string;
}

export interface IDoc {
    approvalComments: string;
    approvalStatus: string;
    docId: string;
    docName: string;
    docTypeId: string;
    documentTypeName: string;
    fileData: IFileData[];
}

export interface ITrainee {
    approvalStatus: string;
    docs: IDoc[];
    educationalSupervisor: string;
    programId: string;
    programName: string;
    traineeId: string;
    traineeName: string;
    userId: string;
}

