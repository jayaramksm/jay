export interface ICourseManagement {
    totalRotations: IRotations[];
    actionType: number;
    actionData: IRotations;
    wbaDetails: IWba[];
    wbaActionType: number;
    wbaActionData: IWba;
    searchKey: string;
    phaseDenominations: IDenominations[];
}

export interface IRotations {
    phaseDenominationId: string
    phaseDenominationName?: string
    programId: string
    rotationCode: string
    rotationDuration: string
    rotationId: string
    rotationName: string
    wbas: IWba[]
    isRlaFiled?: boolean
}

export interface IWba {
    wbaDigitalForm?: string
    wbaExpected: string
    wbaId?: string
    wbaName: any;
}

export interface IDenominations {
    phaseDenominationId: string
    phaseDenomitationName: string
}