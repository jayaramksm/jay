export interface IApproveGlasMOdel {
    actionType: number;
    actionData: any;
    approveGlasData: IGla[];
    searchKey: string;
    paginationCurrentPage: number;
    fileUploadHistory: any;
}



export interface IGla {
    agreementDate: string;
    communication: string;
    esApprovedON: string;
    esComments: string;
    esSignature: string;
    esId: string;
    esStatus: string;
    esUserName: string;
    glaId: string;
    matricNumber: string;
    mohApprovedOn: string;
    mohComments: string;
    mohId: string;
    mohStatus: string;
    mohSignature: string;
    mohUserName: string;
    period: string;
    programId: string;
    programName: string;
    status: string;
    traineeId: string;
    traineeName: string;
    traineeUserId: string;
    universityId: string;
}
