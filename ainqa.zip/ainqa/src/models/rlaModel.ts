import { ICurrentDateAndTime } from "./utilitiesModel";

export interface IRlaModel {
    rlaData: IRla[];
    departmentData: any;
    actionType: number;
    actionData: any;
    totalRotationSupervisor: IUser[];
    studyPlanStaus: IstudyPlanStaus;
    studyplanRotationsWithWbas: IRotation[];
    paginationCurrentPage: number;
    searchKey: string;
    currentDate: ICurrentDateAndTime,
    hodsData: IHod[]
}

export interface IstudyPlanStaus {
    messages: string;
    status: boolean;
    statusCode: number;
}




export interface IWba {
    wbaExpected: string;
    wbaId: string;
    wbaName: string;
    planned: string;
    completed: string
}

export interface IRotation {
    hospitalId: string;
    hospitalName: string;
    otherHospitalName: string;
    rotation: string;
    rotationDuration: string;
    rotationId: string;
    rotationSequence: string;
    rotationStageName: string;
    rotationStatus: string;
    stage: string;
    wbas: IWba[];
}



export interface ITrainee {
    anmno: string;
    coEducationalSupervisor: string;
    educationalSupervisor: string;
    nsrno: string;
    pathwayTag: string;
    remark: string;
    trActiveFrom: string;
    trActiveTo: string;
    trIcNo: string;
    trId: string;
    trLegacyCode: string;
    trMohUser: string;
    trStatus: string;
}

export interface IUser {
    correspondentAddress: string;
    correspondentCountry: string;
    departmentIds: string[];
    designation: string;
    dob: string;
    employeeId: string;
    eportfolioEmailId: string;
    gender: string;
    isActive: number;
    isFirstLogin: number;
    isMohSupervisor: boolean;
    isSameAddress: number;
    mmcno: string;
    mobileno1: string;
    mobileno2: string;
    mohId: string;
    personalEmailId: string;
    profileUrl: string;
    programId: string;
    residentialAddress: string;
    residentialCountry: string;
    resourceCode: string;
    roleId: string;
    trainee: ITrainee;
    universityId: string;
    userFullName: string;
    userId: string;
    userName: string;
    userType: string;
}


export interface IRla {
    createdOn: string
    educationalSupervisorId: string
    esName: string
    expectedWbas: IExpectedWba[]
    firstRotationalSupervisor: IFirstRotationalSupervisor
    hodId: string
    hodName: string
    hospitalId: string
    hospitalName: string;
    isWbaFiled: boolean,
    mohName: string
    mohSupervisorId: string
    otherHospitalName: string
    placementAmisObject: string
    plannedAbsencesConferences: string
    programId: string
    programName: string
    rlaId: string
    rlaStatus: string
    rotationDuration: string
    rotationEndDate: string
    rotationId: string
    rotationName: string
    rotationStartDate: string
    secondRotationSupervisor: ISecondRotationSupervisor
    spRotationId: string
    stage: string
    stageName: string
    traineeId: string
    traineeMailId: string
    traineeName: string
    traineeSignature: string
    userId: string
}

export interface IExpectedWba {
    completed: string
    planned: string
    wbaExpected: string
    wbaId: string
    wbaName: string
}

export interface IFirstRotationalSupervisor {
    approvedOn: string
    comments: string
    signature: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface ISecondRotationSupervisor {
    approvedOn: string
    comments: string
    signature: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}


export interface IHod {
    contactNo: string;
    departments: IDepartment[];
    eportfolioEmailId: string;
    gender: string;
    hodFullName: string;
    hodId: string;
    mmcNo: string;
    umId: string;
}

export interface IDepartment {
    departmentCode: string;
    departmentId: string;
    departmentName: string;
    location: string;
}

export enum EWbaNames {

}