export interface ILearningAgreementsModel {
    actionType: number;
    actionData: any;
    searchkey: string;
    paginationCurrentPage: number;
    learningAgreements: any[];
    learningAgreementsActionData: any;
}


export enum EAgreementType {
    RLA = 'RLA',
    GLA = 'GLA'
}

export interface IRlaAgreementsData {
    createdOn: string
    educationalSupervisorId: string
    esName: string
    expectedWbas: IExpectedWba[]
    firstRotationalSupervisor: IFirstRotationalSupervisor
    hodId: string
    hodName: string
    hospitalId: string
    hospitalName: string
    isWbaFiled: boolean
    mohName: string
    mohSupervisorId: string
    otherHospitalName: string
    placementAmisObject: string
    plannedAbsencesConferences: string
    programId: string
    programName: string
    rlaId: string
    rlaStatus: string
    rotationDuration: string
    rotationEndDate: string
    rotationId: string
    rotationName: string
    rotationStartDate: string
    secondRotationSupervisor: ISecondRotationSupervisor
    spRotationId: string
    stage: string
    stageName: string
    traineeId: string
    traineeMailId: string
    traineeName: string
    traineeSignature: string
    userId: string
    agreementName?: string
    latestApprovedOn?: string
}

export interface IExpectedWba {
    completed: string
    planned: string
    wbaExpected: string
    wbaId: string
    wbaName: string
}

export interface IFirstRotationalSupervisor {
    approvedOn: string
    comments: string
    signature: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface ISecondRotationSupervisor {
    approvedOn: string
    comments: string
    signature: string
    status: string
    supervisorId: string
    supervisorMailId: string
    supervisorName: string
}

export interface IGlaAgreementsData {
    agreementDate: string
    communication: string
    esApprovedON: string
    esComments: string
    esId: string
    esSignature: string
    esStatus: string
    esUserName: string
    glaId: string
    matricNumber: string
    mohApprovedOn: string
    mohComments: string
    mohId: string
    mohSignature: string
    mohStatus: string
    mohUserName: string
    period: string
    programId: string
    programName: string
    status: string
    traineeId: string
    traineeName: string
    traineeUserId: string
    universityId: string
    agreementName?: string
    startDate?: string
    endDate?: string
    latestApprovedOn?: string
}