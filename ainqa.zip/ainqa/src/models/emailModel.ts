export interface IEmailModel {
    emailData: IEmail[];
}

export interface IEmail {
    emailAccount: string;
    emailSettingsId: string;
    mailBoxType: string;
    password: string;
    port: string;
    serverIp: string;
    serverName: string;
}