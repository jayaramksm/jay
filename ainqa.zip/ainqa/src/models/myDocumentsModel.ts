export interface IMyDocumentsModel {
    documentsData: IDocumentsData[];
    documentsTypes: IDocumentType[],
}


export interface IDocumentType {
    docName: string;
    docTypeId: string;
}

export interface IDocumentsData {
    approvalComments: "string"
    approvalStatus: "string"
    approvedBy: "string"
    approvedDate: "string"
    checkListId: "string"
    docId: "string"
    docName: "string"
    docNo: "string"
    docTypeId: "string"
    fileData: IFileData[]
    programId: "string"
}

export interface ICreateDocument {
    checkListId: string
    documents: IDocument[]
    programId: string
    programName: string
    traineeId: string
    traineeName: string
}

export interface IDocument {
    approvalStatus: string
    docName: string
    docTypeId: string
    fileData: IFileData[]
}

export interface IFileData {
    fileName: string
    filePath: string
}

export interface IUpdateDocuments {
    checkListId: string
    deleteDocIds: string[]
    docs: IDoc[]
    programId: string
    programName: string
    traineeId: string
    traineeName: string
}

export interface IDoc {
    approvalComments: string
    approvalStatus: string
    approvedBy: string
    approvedDate: string
    docId: string
    docName: string
    docNo: string
    docTypeId: string
    fileData: IFileData[]
}

export interface IImageInfo {
    filePath: string;
    logo: string;
    messages: string;
    status: boolean;
    statusCode: number
}

export enum EDocStatus {
    APPROVED = 'approved',
    REJECTED = 'rejected',
    PENDING = 'pending'
}

export enum EDocType {
    PANCARD = 'PAN Card',
    ADHARCARD = 'Aadhar Card',
    DRIVINGLICENCE = 'Driving Licence',
    OTHERS = "Other"
}
