export interface IPortfolioMOdel {
    actionType: number;
    actionData: any;
    portfoliosData: any;
    portfolioDraftData: IPortfilo[];
    searchKey: string;
    paginationCurrentPage: number;
    studyPlanRotationsData: IRotations[];
    currentDate: ICurrentDateAndTime,
    formModelData: any;
    paginationDraftCurrentPage: number;
    portfolioFormData: IPortfolioForm[];
    createdOnDate: any
}

export enum EEvaluatorFeedBack {
    APPROVED = '1',
    PENDING = '0'
}

export enum ECodeOptions {
    WBA = 'WBA',
    SURLOG = 'SURLOG'
}

export enum ESubCode {
    CBD = 'cbd',
    CEX = 'cex',
    DOPS = 'dops',
    MSF = 'msf',
    PBA = 'pba',
    PSA = 'psa',
    NOTSA = 'notsa',
    DOCE = 'doce',
    SURLOG = 'surlog'
};

export enum EFieldNames {
    STAGE = 'stage',
    CODE = 'code',
    ROTATION = 'rotation',
    SUBCODE = 'subCode',
    SUBCATEGOTYNAME = 'subCategoryName'

}


// export enum EIsAssessed{

// }

export interface ICurrentDateAndTime {
    date: string;
    dateTime: string;
    hours: string;
    minutes: string;
    seconds: string;
    time: string;
}

export interface IFirstRotationSupervisor {
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}

export interface ISecondRotationSupervisor {
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}

export interface IWba {
    wbaDigitalForm: string;
    wbaExpected: string;
    wbaId: string;
    wbaName: string;
}

export interface IRotations {
    firstRotationSupervisor: IFirstRotationSupervisor;
    hospitalId: string;
    hospitalName: string;
    otherHospitalName: string;
    rotationId: string;
    rotationName: string;
    secondRotationSupervisor: ISecondRotationSupervisor;
    stageId: string;
    stageName: string;
    wbas: IWba[];
}


export interface IFileData {
    file_name: string;
    file_path: string;
}

export interface IFirstRotationSupervisor {
    approvedOn: string;
    comments: string;
    status: string;
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}

export interface IFormData {
}

export interface ISecondRotationSupervisor {
    approvedOn: string;
    comments: string;
    status: string;
    supervisorId: string;
    supervisorMailId: string;
    supervisorName: string;
}



export interface IEvaluatorFeedBack {
    createdOn: string,
    evaluatorEmailId: string;
    evaluatorFeedBackId: string;
    evaluatorFormData: string;
    evaluatorFormId: string;
    status: string;
    uniqueId: string;
}

export interface FileData {
    fileName: string;
    filePath: string;
}


export interface IPortfilo {
    code: string;
    completedDate: string;
    dueDate: string;
    evaluatorFeedBack: IEvaluatorFeedBack[];
    feedBackStatus: string;
    fileData: FileData[];
    firstRotationSupervisor: IFirstRotationSupervisor;
    formData: string;
    hospitalId: string;
    hospitalName: string;
    isAssessed: boolean;
    otherHospitalName: string;
    portfolioId: string;
    programId: string;
    programName: string;
    rotationId: string;
    rotationName: string;
    secondRotationSupervisor: ISecondRotationSupervisor;
    stageId: string;
    stageName: string;
    subCategoryName: string;
    traineeId: string;
    traineeMailId: string;
    traineeName: string;
    traineeUserId: string;
    updatedOn: string,
    wba: string;
    wbaName: string;
}




export interface FormData {
}

export interface IPortfolioOrDraftCreateObject {
    code: string;
    completedDate: string;
    dueDate: string;
    evaluatorFormId: string;
    fileData: IFileData[];
    firstRotationSupervisorId: string;
    firstRotationSupervisorName: string;
    firstSupervisorEmail: string;
    formData: string;
    hospitalId: string;
    isAssessed: boolean;
    otherHospitalName: string;
    portfolioId: string;
    programName: string;
    rotation: string;
    rotationName: string;
    secondRotationSupervisorId: string;
    secondRotationSupervisorName: string;
    secondSupervisorEmail: string;
    stage: string;
    subCategoryName: string;
    traineeId: string;
    traineeMailId: string;
    traineeName: string;
    wba: string;
    wbaName: string;

}


export interface IPortfolioFormMappings {
    evaluatorForm: string;
    portfolioFormsMappingId: string;
    traineeForm: string;
}

export interface IPortfolioForm {
    code: string;
    formName: string;
    portfolioFormId: string;
    portfolioFormMappings: IPortfolioFormMappings;
    subCategoryName: string;
}
