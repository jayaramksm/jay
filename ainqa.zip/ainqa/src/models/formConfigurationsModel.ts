export interface IFormConfigurationsModel {
    formData: any;
    currentPage: number;
    searchKey: string;
    actionType: number
}

export interface IFormData {
    code: string
    formName: string
    portfolioFormId: string
    portfolioFormMappings: IPortfolioFormMapping
    subCategoryName: string
}

export interface IPortfolioFormMapping {
    evaluatorForm: string
    portfolioFormsMappingId: string
    traineeForm: string
}