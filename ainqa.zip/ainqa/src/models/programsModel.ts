export interface IProgramsMOdel {
    actionType: number;
    actionData: any;
    programsDetails: IProgram[];
    searchKey: string;
    paginationCurrentPage: number;
    fileUploadHistory: any;
    phaseDistribution: IPhase[];
}

export interface IProgram {
    phaseDistribution: string;
    programCode: string;
    programId: string;
    programName: string;
}

export interface IPhaseDenomination {
    phaseDenominationId: string;
    phaseDenomitationName: string;
}

export interface IPhase {
    phaseDenominations: IPhaseDenomination[];
    phaseDistribution: string;
    phaseDistributionId: string;
}