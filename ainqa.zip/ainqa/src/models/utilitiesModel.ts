export enum EAPPModules {
    LOGINMODULE = 'EP0',
    FORGETPASSWORDMODULE = 'EP1',
    USERPROFILEMANAGEMENTMODULE = 'EP2',
    USERMANAGEMENTMODULE = 'EP3',
    UNIVERSITIESMODULE = 'EP4',
    PROGRAMSMODULE = 'EP5',
    DEPARTMENTSMODULE = 'EP6',
    HODSMODULE = 'EP7',
    HOSPITALSMODULE = 'EP8',
    COURSEMANAGEMENTMODULE = 'EP9',
    APPROVESTATUTORYDOCMODULE = 'EP10',
    MYDOCUMENTSMODULE = 'EP11',
    STUDYPLANMODULE = 'EP12',
    APPROVESTUDYPLAN = 'EP13',
    GLASMODULE = 'EP14',
    APPROVEGlLASMODULE = 'EP15',
    EMAILMODULE = 'EP16',
    RLAMODULE = 'EP17',
    APPROVERLASMODULE = 'EP18',
    APPROVEROTATIONALMEETINGMODULE = 'EP19',
    ROTATIONALMEETINGS = 'EP20',
    PORTFOLIOSMODULE = 'EP21',
    APPROVEPORTFOLIOMODULE = 'EP22',
    FORMCONFIGURATIONSMODEL = 'EP23',
    EVALUATORFEEDBACKFORM = 'EP24',
    EVIDENCE_WBA = 'EP25',
    EVIDENCE_SURGICALELOGBOOK = 'EP26',
    EVIDENCMEETINGSMODULE = 'EP27',
    LEARNINGAGREEMENTSMODULE = 'EP28'
}
export enum ELogoutTypes {
    RELOGIN = 'relogin',
    LOGOUT = 'logout',
    LOGOUT404 = 'logout 404',
    LOGOUT403 = 'logout 403',
    LOGOUT440 = 'logout 440'
}
export enum ERoutePath {
    default = '/',
    timeOut = '/440',
    notAuthenticated = '/403',
    isAuthenticated = '1',
    pageNotFound = '/404'
}
export enum EOprationalActions {
    UNSELECT = 0,
    ADD = 1,
    EDIT = 2,
    DELETE = 3,
    SELECT = 4,
    MAPPING = 5,
    BULKUPLOAD = 6,
    BULK_UPLOAD_FILE_HISTORY = 7,
    CHARTVIEW = 8,
    STUDY_PLAN_STAGES_VIEW = 9,
    STUDY_PLAN_ROTATIONS_VIEW = 10,
    REPLACE = 11,
    DRAFT = 12,
}

export enum EBulkUploadUsers {
    PROGRAMS = 1,
    HOD = 2,
    DEPARTMENTS = 3,
    HOSPITALS = 4
}

export enum EBulkUploadStatus {
    FILE_VALIDATED = '1',
    PROCESSING = '2',
    HEADERS_MATCHED = '3',
    DEFAULT = ''
}

export enum ECheckedEnums {
    NCHECKED = 1,
    NUNCHECKED = 0
}

export enum EStatusEnum {
    NACTIVE = 1,
    NINACTIVE = 0,
    NACTIVE_STR = '1',
    NINACTIVE_STR = '0'
}
export enum ELayoutType {
    AUTH = 'Auth',
    NONAUTH = 'NonAuth'
}
export interface IConfirmModel {
    title: string;
    subtitle?: string;
    transKey: string;
    replaceData?: IConfirmReplaceModal[];
    options: IConfirmOptions[];
    subTitleClassName?: string;
}
export interface IConfirmReplaceModal {
    replaceKey: string;
    replaceValue: string;
}
export interface IConfirmOptions {
    title: string;
    function?: any;
    loading?: number;
    className?: string;
}
export interface IApiThrowResponse {
    status: boolean;
    statuscode: number,
    messages: string;
    data?: any;
    error?: any;
}
export interface Settings {
    sessionTime: number;
    showMessagecode: boolean;
    versionCheckInterval: number;
    domainEmail: any;
    keyClock?: IKeycloakConfig;
    formBuilderUrl: string
}

export interface IKeycloakConfig {
    realm?: string;
    url?: string;
    resource?: string;
    clientId?: string;
}

export interface IBaseApiUrls {
    baseUrl: string;
    components: IApiUrls[];
}
export interface IApiUrls {
    apiUrl: string
    component: string;
    methods: IApiMethod[];
}

export interface IApiMethod {
    name: string;
    type: string;
    url: string;
}
export interface ISessionstate {
    token: any;
    menuData: IMenuModules[];
    loginTime: any,
    userDto: IUserDetails,
    language: string;
    isDefultPasswordAuth: IIsDefultPasswordAuth | undefined;

    authenticationCheck: boolean;
    logoutUrl: string;
}
export interface IIsDefultPasswordAuth {
    enable: boolean;
    password: string;
    menuData: IMenuModules[];
}
export interface IMenuModules {
    icon: string;
    link: string;
    moduleName: string;
    subModules: IMenuSubModule[];
}

export interface IMenuSubModule {
    link: string;
    subModuleName: string;
}
export interface ICurrentDateAndTime {
    date: string;
    dateTime: string;
    hours: string;
    minutes: string;
    seconds: string;
    time: string;
}

export interface IAlertMessagedata {
    message: string;
    messageCode?: string;
    transKey?: string;
    status: boolean;
    tranId: number;
    statusCode?: number;

}

export interface IUserDetails {
    eportfolioEmailId: string;
    gender: string;
    isActive: number;
    isFirstLogin: number;
    mobileno1: string;
    mobileno2: string;
    profileUrl: string;
    resourceCode: string;
    roles: IRoles;
    university: IUniversity;
    userFullName: string;
    userId: string;
    userName: string;
    userType: string;
    program: IProgram;
    trainee: ITrainee
}

export interface ITrainee {
    esName: string
    mohName: string
    anmno: string
    coEducationalSupervisor: string
    educationalSupervisor: string
    nsrno: string
    pathwayTag: string
    remark: string
    trActiveFrom: string
    trActiveTo: string
    trIcNo: string
    trId: string
    trLegacyCode: string
    trMohUser: string
    trStatus: string
}

export interface IProgram {
    programName: string;
    programCode: string;
    programId: string;
}

export interface IUniversity {
    country: string;
    location: string;
    pincode: string;
    primaryContact: string;
    primaryContactDesignation: string;
    primaryContactEmailId: string;
    primaryName: string;
    secondaryContact: string;
    secondaryContactDesignation: string;
    secondaryContactEmailId: string;
    secondaryName: string;
    universityCode: string;
    universityId: string;
    universityName: string;
    website: string;
    zipCode: string;
    logoUrl: string;
    themeInfo: IThemeInfo;
}

export interface IThemeInfo {
    isDefault: boolean;
    themeDesc: string;
    themeId: string;
    themeName: string;
}

export enum EThemeNames {
    THEME_1 = "theme-1",
    THEME_2 = "theme-2",
    THEME_3 = "theme-3"
}

export enum EThemeIds {
    THEME_1 = "1",
    THEME_2 = "2",
    THEME_3 = "3"
}

export interface IRoles {
    roleCode: string;
    roleId: number;
    roleName: string;
}
export interface IPasswordPolicy {
    changePasswordatFirstLogin: boolean;
    maximumLength: number;
    minimumLength: number;
    noOfLowerCaseLetters: number;
    noOfUpperCaseLetters: number;
    numberOfAlphabets: number;
    numberOfNumerical: number;
    passwordValidityPeriod: number;
    specialCharactersAllowed: string;
}
export enum ERoleDesc {
    PLATFORMADMIN = 'pa',
    UNIVERSITYADMIN = 'ua',
    Traninee = "tr",
    MOHSUPERVISOR = "ms",
    ROTATIONSUPERVISOR = "rs",
    EDUCATIONALSUPERVISOR = "eds",
    PROGRAMCOORDINATOR = "pc"
}
export enum ERoleDescNames {
    'pa' = "Platform Admin",
    'ua' = "University Admin",
    "tr" = "Trainee",
    "ms" = "MOH Supervisor",
    "rs" = "Rotational Supervisor",
    "eds" = "Educational Supervisor",
    "pc" = "Program Coordinator"
}
export enum ERoleId {
    PLATFORMADMIN = '1',
    UNIVERSITYADMIN = '2',
    Traninee = "3",
    MOHSUPERVISOR = "4",
    ROTATIONSUPERVISOR = "5",
    EDUCATIONALSUPERVISOR = "6",
    PROGRAMCOORDINATOR = "7"
}

export enum ERoleNames {
    PLATFORMADMIN = 'platformadmin',
    UNIVERSITYADMIN = 'universityadmin',
    Traninee = "trainee",
    MOHSUPERVISOR = "moh supervisor",
    ROTATIONSUPERVISOR = "rotation supervisor",
    EDUCATIONALSUPERVISOR = "educational supervisor",
    PROGRAMCOORDINATOR = "program coordinator"
}

export enum EFileSizes {
    USER_MANAGEMENT_BULK_UPLOAD_MAX_FILE_SIZE = 5,
    UNIVERSITY_LOGO_MAX_SIZE = 2
}

export enum EBulkUploadComponentNames {
    PROGRAMS = 'programs',
    DEPARTMENTS = 'departments',
    HODS = 'hods',
    HOSPITALS = 'hospitals'
}

export enum EUserManagementFilterKeys {
    USER_ID = 'userId',
    RESOURCE_CODE = 'resourceCode',
    USERNAME = 'userName',
    USER_TYPE = 'userType'
}

export enum EApprovelActions {
    APPROVED = "approved",
    PENDING = "pending",
    REJECTED = "rejected",
    ACTIVE = "active",
    COMPLETED = 'completed',
    FAILED = 'failed'
}

export enum EAPIComponentNames {
    AUTH = "Auth",
    USER_PROFILE_MANAGEMENT = "UserProfileManagement",
    FILE_UPLOAD = "FileUpload",
    UNIVERSITY = "University",
    USER_MANAGEMENT = "UserMangement",
    DEPARTMENTS = "Departments",
    HODS = "Hods",
    PROGRAMS = "Programs",
    HOSPITALS = "Hospitals",
    COURSE_MANAGEMENT = "CourseManagement",
    PHASES = "Phases",
    ROLES = "Roles",
    EDUCATIONAL_SUPERVISOR = "educationalSupervisor",
    MOH_SUPERVISOR = "mohSupervisor",
    MY_DOCUMENTS = "MyDocuments",
    TRAINEE = "Trainee",
    EMAIL = "email",
    ROTATIONAL_SUPERVISOR = 'rotationalSupervisor',
    FORM_BUILDER = 'formBuilder',
    EVALUATOR_FEEDBACK_FORM = 'evaluatorFeedbackForm'
}