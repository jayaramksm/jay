export interface IApproveStudyPlanModel {
    actionType: number;
    actionData: IStudyPlan;
    studyPlanData: IStudyPlan[];
    searchKey: string;
    paginationCurrentPage: number;
    rotationActionData: any;
    modelData: any;
    currentDateAndTime: any;
}

export interface ICurrentDateAndTime {
    date: string
    dateTime: string
    hours: string
    minutes: string
    seconds: string
    time: string
}

export interface IStudyPlan {
    apporvalStatus: string
    programCode: string
    programId: string
    programName: string
    rotations: IRotation[]
    studyPlanId: string
    traineeId: string
    traineeName: string
    traineeUserId: string
}

export interface IRotation {
    approvedBy: string
    approvedOn: string
    hospitalId: string
    hospitalName: string
    otherHospitalName: string
    rotation: string
    rotationComments: string
    rotationDuration: string
    rotationId: string
    rotationSequence: string
    rotationStageName: string
    rotationStatus: string
    spRotationId: string
    stage: string
    stageStatus: string,
    stageComments: string,
    rotationStartDate: string;
    rotationEndDate: string;
}
export enum EStatusType {
    ROTATION = 'rotation',
    STAGE = 'stage'
}