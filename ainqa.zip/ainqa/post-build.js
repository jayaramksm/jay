const path = require('path');
const fs = require('fs');
const util = require('util');
// get application version from package.json
const appVersion = require('./package.json').version;
const versionPath = '/build';
const buildVersion = require('./public/version.json').version;
const updatedOn = require('./public/version.json').updatedOn
// promisify core API's
const readDir = util.promisify(fs.readdir);
const writeFile = util.promisify(fs.writeFile);
const readFile = util.promisify(fs.readFile);

// our version.json will be in the dist folder
const versionFilePath = path.join((__dirname) + versionPath + '/version.json');
console.log('\nRunning post-build tasks=>', versionFilePath);
let mainHash = '';
let mainBundleFile = '';
readFile(path.join((__dirname) + versionPath + '/asset-manifest.json')).then(x => {
  console.log("12345 =>", JSON.parse(x.toString()).entrypoints);
  let entrypoints;
  if (x) {
    let convertData = JSON.parse(x.toString());
    if (convertData.entrypoints)
      entrypoints = convertData.entrypoints;
  }
  if (entrypoints) {
    // RegExp to find main.bundle.js, even if it doesn't include a hash in it's name (dev build)
    const regex = /\.([a-z0-9]*?)\./;
    let keyValue = [];
    entrypoints.forEach(element => {
      let data = regex.exec(element);
      if (data.length >= 2)
        keyValue.push(data[1]);
    });
    // if it has a hash in it's name, mark it down
    mainHash = keyValue.join('');
    console.log('\nRunning post-build tasks=>1', mainHash, entrypoints);
    // write current version and hash into the version.json file buildVersion
    const src = `{"version": "${buildVersion}", "versionhash": "${mainHash}", "hash": "${mainHash}" ,"updatedOn":"${updatedOn}"}`;
    return writeFile(versionFilePath, src);
  }
  else
    console.log('not definde endpoint from asset-manifest.json file');

}).catch(err => {
  console.log('Error with post build:', err);
});