import React, { Component } from 'react';
import { Col, Row } from 'reactstrap';
import logo from "../../../images/firstpasslogo.svg";
import './clientprofilesetting.css';
import BackToLogin from '../../../images/backtologin.svg'; //backtologin.svg'
import BackToHome from '../../../images/home-run.svg'; //backtohome.svg'
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import {
    activateClientAuthLayout, logOutRequest, alertActionRequest,
    getBranchServicesDataRequest, cancelPendingClientProfileSettingRequests, setResetForClientProfileSetting,
    getServicesMappedToUserRequest
} from '../../../store/actions';
import { withTranslation } from 'react-i18next';
import { IBranchService, IPrevBranchServices, ISelectionArea, IService } from '../../../models/clientProfileSettingsModel';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import { defultContentValidate, gettranId } from '../../../helpers/helpersIndex';
import { ILogoutTypes, IAlertMessagedata, IAPPModules, IRoutePath, ISessionstate } from '../../../models/utilitiesModel';

export interface IProps {
    activateClientAuthLayout: any;
    getBranchServicesDataRequest: any;
    setResetForClientProfileSetting: any;
    cancelPendingClientProfileSettingRequests: any;
    t: any;
    branchServicesData: IBranchService[];
    prevMappedServices: IPrevBranchServices;
    getServicesMappedToUserRequest: any;
    history: any;
    logOutRequest: any;
    alertActionRequest: any;
    defauldPath: string;
    isUserProfile: boolean;
}

class ClientProfileSetting extends Component<IProps, any> {

    t = this.props.t;
    componentDidMount() {
        this.props.activateClientAuthLayout();
        this.props.setResetForClientProfileSetting();
        this.props.getBranchServicesDataRequest(true);
    }
    componentWillUnmount() {
        this.props.cancelPendingClientProfileSettingRequests();
        this.props.setResetForClientProfileSetting();
    }

    validationSchema = Yup.object().shape({
        branches: defultContentValidate(this.props.t('ClientProfileSettings.branchError')),
        services: defultContentValidate(this.props.t('ClientProfileSettings.serviceError'))
    });

    selectServices(service: IService, values, setFieldValue) {
        let isServices: number[] = values.services === '' ? [] : values.services;
        let index = isServices.findIndex(x => x === service.serviceId);
        if (index !== -1)
            isServices.splice(index, 1);
        else {
            if (isServices.length >= 20) {
                let tranId = gettranId(IAPPModules.CLIENTPROFILESETTINGS);
                let alertMessageData: IAlertMessagedata | undefined;
                alertMessageData = {
                    message: 'CLP7', status: false, tranId: Date.now(),
                    messageCode: tranId + 'CLP7', transKey: 'ClientProfileSettings.alertMessages.'
                };
                this.props.alertActionRequest(alertMessageData);
            }
            else
                isServices.push(service.serviceId);
        }
        setFieldValue('services', isServices);
    }

    patchPrevSevices() {
        if (this.props.prevMappedServices && this.props.prevMappedServices.services) {
            let serviceData: number[] = [];
            this.props.prevMappedServices.services.forEach(x => {
                serviceData.push(x.serviceId);
            });
            return serviceData.length > 0 ? serviceData : '';
        }
        else return ''
    }
    patchSeviceList() {
        let selectBranch = this.props.branchServicesData && this.props.prevMappedServices ? this.props.branchServicesData.find(x => x.branchId === this.props.prevMappedServices.branchId) : undefined;
        return selectBranch ? selectBranch.services : [];
    }

    render() {

        return (
            <React.Fragment>
                <Row className="loginBg" style={{ overflow: "hidden" }}>
                    <Col sm="4" className="LoginLft">

                        <div className="login-logo">
                            <img src={logo} alt="" />
                        </div>

                        <div className="lftCaption">
                            <div className="arrow-right-light"></div>
                            <h1>{this.t('ClientProfileSettings.weAre')}</h1>
                            <h3>{this.t('ClientProfileSettings.leftMsg')}</h3>
                        </div>
                    </Col>

                    <Col className="rgtcol h-100">
                        <Row className="mr-4">
                            {this.props.isUserProfile && this.props.defauldPath && < Col sm="6" className="bckhome" onClick={() => this.props.history.push('/' + this.props.defauldPath)}>
                                <div className="pointer">
                                    <img src={BackToHome} alt="" className="pb-1" />
                                    <span className="ml-3">
                                        {this.t('ClientProfileSettings.backToHome')}
                                    </span>
                                </div>
                            </Col>}
                            <Col className="bcktoLogin align-right" onClick={() => this.props.logOutRequest(this.props.history, IRoutePath.default, ILogoutTypes.LOGOUT)}>
                                <div className="pointer">
                                    <span className="mr-3">
                                        {this.t('ClientProfileSettings.backToLogin')}
                                    </span>
                                    <img src={BackToLogin} alt="" />
                                </div>
                            </Col>
                        </Row>

                        <Formik
                            enableReinitialize
                            initialValues={{
                                step: ISelectionArea.Branch,
                                branchSearch: '',
                                serviceSearch: '',
                                branches: this.props.prevMappedServices ? this.props.prevMappedServices.branchId > 0 ? this.props.prevMappedServices.branchId : '' : '',
                                serviceList: this.patchSeviceList(),
                                services: this.patchPrevSevices()
                            }}
                            validationSchema={this.validationSchema}
                            onSubmit={(values) => {
                                console.log('onSubmit_Values => ', values);
                                let requestObject = {
                                    branchId: values.branches,
                                    services: values.services
                                }
                                console.log('onSubmit_Values =>2 ', requestObject);
                                this.props.getServicesMappedToUserRequest(requestObject, this.props.history);
                            }}
                        >
                            {({ values, errors, touched, dirty, setFieldValue, setFieldTouched }) => (
                                <Form className="h-100">
                                    <div className="flexLayout">
                                        <Row className="mt-4">
                                            <Col sm="9" className="p-3">
                                                <div className="arrow-right-dark"></div>
                                                {values.step === ISelectionArea.Branch && <div className="text">{this.t('ClientProfileSettings.leftMsg')}</div>}
                                                {values.step === ISelectionArea.Service && <div className="text">{this.t('ClientProfileSettings.serviceMsg')}</div>}
                                                {values.step === ISelectionArea.Branch && this.props.branchServicesData?.length === 0 && <div className="error-msg">{this.t('ClientProfileSettings.noBranches')}</div>}
                                            </Col>


                                        </Row>
                                        {values.step === ISelectionArea.Branch && this.props.branchServicesData && this.props.branchServicesData.length > 10 && <div className="app-search w-50 p-0 form-group mb-0 mt-3">
                                            <Field name="branchSearch" className="form-control w-100" placeholder={this.t('ActionNames.search')} />
                                            <i className="fa fa-search"></i>
                                        </div>}
                                        {errors.branches && touched.branches && (
                                            <div className="error-msg">{errors.branches}
                                            </div>
                                        )}
                                        {values.step === ISelectionArea.Service && values.serviceList.length > 10 && <div className="app-search w-50 p-0 form-group mb-0 mt-2">
                                            <Field name="serviceSearch" className="form-control w-100" placeholder={this.t('ActionNames.search')} />
                                            <i className="fa fa-search"></i>
                                        </div>}
                                        {values.step === 1 &&
                                            <>
                                                <div className="mx-0 h-100 deptMar flexLayout w81">
                                                    <div className="pl-0 flexLayout-inner">
                                                        <div className="branches">
                                                            {this.props.branchServicesData && (values.branchSearch === '' ? this.props.branchServicesData : this.props.branchServicesData.filter(x => x.branchNameEn.toLowerCase().startsWith(values.branchSearch.toLowerCase()))).map((item: IBranchService, index) => {
                                                                return (
                                                                    <div className={'btn btn-sm ' + (item.branchId === values.branches ? 'activeList' : '')} key={index} onClick={() => {
                                                                        setFieldValue('branches', item.branchId);

                                                                        if (item.branchId !== values.branches) {

                                                                            setFieldValue('serviceList', item.services);
                                                                            if ((this.props.prevMappedServices && this.props.prevMappedServices.branchId ? this.props.prevMappedServices.branchId : 0) === item.branchId)
                                                                                setFieldValue('services', this.patchPrevSevices());
                                                                            else
                                                                                setFieldValue('services', '');
                                                                        }
                                                                    }}>
                                                                        {item.branchNameEn}
                                                                    </div>
                                                                )
                                                            })}
                                                        </div>
                                                    </div>
                                                </div>
                                                {this.props.branchServicesData && this.props.branchServicesData?.length !== 0 && <div className="mb-3 align-right nxtstep">
                                                    <button type="button" className="btn btn-primary" onClick={() => {
                                                        if (values.branches)
                                                            setFieldValue('step', ISelectionArea.Service);
                                                        else
                                                            setFieldTouched('branches', true);
                                                    }}>
                                                        {this.t('ClientProfileSettings.nextStep')}
                                                    </button>
                                                </div>}
                                            </>}
                                        {values.step === ISelectionArea.Service &&
                                            <>
                                                {errors.services && touched.services && (
                                                    <div className="error-msg">{errors.services}
                                                    </div>
                                                )}
                                                <h6>
                                                    {this.props.branchServicesData && this.props.branchServicesData.find(x => x.branchId === values.branches)?.branchNameEn}
                                                </h6>

                                                <div className="mx-0 h-100 flexLayout w81">
                                                    <div className="pl-0 flexLayout-inner">
                                                        <div className="branches">
                                                            {values.serviceList?.length === 0 && <div className="error-msg">{this.t('ClientProfileSettings.noServices')}</div>}
                                                            {(values.serviceSearch === '' ? values.serviceList : values.serviceList.filter((x: IService) => x.serviceNameEn.toLowerCase().startsWith(values.serviceSearch.toLowerCase()))).map((service: IService, index) => {
                                                                return (
                                                                    <div className={'btn btn-sm ' + ((values.services !== '' ? (values.services as number[]).find(x => x === service.serviceId) : false) ? 'activeList' : '')} key={index}
                                                                        onClick={() => this.selectServices(service, values, setFieldValue)}>
                                                                        {service.serviceNameEn}
                                                                    </div>
                                                                )
                                                            })}
                                                        </div>
                                                    </div>
                                                </div>
                                                <Row className="actnbtns mb-3">
                                                    <Col>
                                                        <button type="button" className="btn prev" onClick={() => {
                                                            setFieldValue('step', 1)
                                                            setFieldTouched('services', false)
                                                        }}>
                                                            <i className="fa fa-angle-double-left iconcolor"></i> {this.t('ClientProfileSettings.prevStep')}
                                                        </button>
                                                    </Col>
                                                    <div className="align-right nxtstep">
                                                        <button className="btn groupBtn mr-3">
                                                            Create Group
                                                            </button>
                                                        {values.serviceList?.length !== 0 && <button className="btn btn-primary" onClick={() => setFieldTouched('services', true)}>
                                                            {this.t('ClientProfileSettings.proceedWork')}
                                                        </button>}
                                                    </div>
                                                </Row>
                                            </>}
                                    </div>
                                </Form>
                            )}
                        </Formik>
                    </Col>
                </Row>

            </React.Fragment >
        );
    }
}

const getSessionFiltterdata = (sessionstate: ISessionstate | undefined) => {
    let defauldPath;
    let isUserProfile;
    if (sessionstate) {
        defauldPath = sessionstate.menuData.length > 0 ? sessionstate.menuData[0].link : undefined;
        isUserProfile = sessionstate?.userDto?.isUserProfile;
    }
    return { defauldPath, isUserProfile }
}
const mapStatetoProps = state => {
    const branchServicesData = state && state.clientProfileSettingsReducer && state.clientProfileSettingsReducer.branchServicesData ? state.clientProfileSettingsReducer.branchServicesData : undefined;
    const prevMappedServices = state && state.clientProfileSettingsReducer && state.clientProfileSettingsReducer.prevMappedServices ? state.clientProfileSettingsReducer.prevMappedServices : undefined;
    const sessionfiltterdata = getSessionFiltterdata(state?.SessionState);
    console.log('ClientProfileSetting_mapStatetoProps =>', { branchServicesData, prevMappedServices });
    return { branchServicesData, prevMappedServices, ...sessionfiltterdata }
}

export default withRouter(withTranslation("translations")(connect(mapStatetoProps, { activateClientAuthLayout, logOutRequest, getBranchServicesDataRequest, alertActionRequest, getServicesMappedToUserRequest, cancelPendingClientProfileSettingRequests, setResetForClientProfileSetting })(ClientProfileSetting)));





