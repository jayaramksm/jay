import React, { Component } from 'react';
import { Alert, Button, Col, Row } from 'reactstrap';
import logo from "../../../images/firstpasslogo.svg";
import './clientprofilesetting.css';
import BackToLogin from '../../../images/firstpasslogo.svg'; //backtologin.svg'
import PerfectScrollbar from 'react-perfect-scrollbar';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateNonAuthLayout } from '../../../store/actions';
class ClientProfileSetting1 extends Component<any, any> {

    constructor(props) {
        super(props);
        this.state = { branches: false };
        this.nextStep = this.nextStep.bind(this);
    }
    componentDidMount() {
        this.props.activateNonAuthLayout();
    }
    nextStep() {
        this.setState({ branches: !this.state.branches })
    }
    render() {

        return (
            <React.Fragment>

                <Row className="loginBg">
                    <Col lg="4" md="12" sm="12" xs="12" className="LoginLft">

                        <div className="login-logo">
                            <img src={logo} alt="" />
                        </div>

                        <div className="lftCaption">
                            <div className="arrow-right-light"></div>
                            <h1>We are !</h1>
                            <h3>few steps away from creating todays journey for you !</h3>
                        </div>
                    </Col>

                    <Col className="rgtcol">
                        <Row className="align-center">
                            <Col sm="9" className="p-3">
                                <div className="arrow-right-dark"></div>
                                {this.state.branches == false && <div className="text">Select the Branches you will be working today !</div>}
                                {this.state.branches == true && <div className="text">Select the Services you will be working today !</div>}

                            </Col>
                            <Col sm="3">
                                <div className="bcktoLogin">
                                    <span className="mr-3">Back to Login</span>
                                    <img src={BackToLogin} alt="" />
                                </div>
                            </Col>

                        </Row>
                        <div className="app-search w-50 p-0 form-group mb-0 mt-3">
                            <input type="text" className="form-control w-100" placeholder="Search" />
                            <i className="fa fa-search"></i>
                        </div>
                        {this.state.branches == false && <div>
                            <Row className="mt-4">
                                <Col sm="12" className="branches">
                                    <div className="btn btn-sm">Kuwait</div>
                                    <div className="btn btn-sm">Dubai</div>
                                    <div className="btn btn-sm">Riyadh</div>
                                    <div className="btn btn-sm">Jeddah</div>
                                    <div className="btn btn-sm">Muscat</div>
                                    <div className="btn btn-sm">Behrain</div>
                                    <div className="btn btn-sm">Doha</div>
                                    <div className="btn btn-sm">Jeddah</div>
                                    <div className="btn btn-sm">Muscat</div>
                                    <div className="btn btn-sm">Behrain</div>
                                    <div className="btn btn-sm">Doha</div>
                                </Col>
                            </Row>
                            <div className="text-right nxtstep">
                                <button className="btn btn-primary" onClick={this.nextStep}>Next Step</button>
                            </div>
                        </div>}

                        {this.state.branches == true &&
                            <div>
                                <Row className="mt-2">
                                    <h6 className="pl-3">Riyadh</h6>
                                    <Col sm="12" className="branches">
                                        <div className="btn btn-sm">Kuwait</div>
                                        <div className="btn btn-sm">Dubai</div>
                                        <div className="btn btn-sm">Riyadh</div>
                                        <div className="btn btn-sm">Jeddah</div>
                                        <div className="btn btn-sm">Muscat</div>
                                        <div className="btn btn-sm">Behrain</div>
                                        <div className="btn btn-sm">Doha</div>
                                        <div className="btn btn-sm">Jeddah</div>
                                        <div className="btn btn-sm">Muscat</div>
                                        <div className="btn btn-sm">Behrain</div>
                                        <div className="btn btn-sm">Doha</div>
                                    </Col>
                                </Row>
                                <Row>
                                    <h6 className="pl-3">Jeddah</h6>
                                    <Col sm="12" className="branches">
                                        <div className="btn btn-sm">Kuwait</div>
                                        <div className="btn btn-sm">Dubai</div>
                                        <div className="btn btn-sm">Riyadh</div>
                                        <div className="btn btn-sm">Jeddah</div>
                                        <div className="btn btn-sm">Muscat</div>
                                        <div className="btn btn-sm">Behrain</div>
                                        <div className="btn btn-sm">Doha</div>
                                        <div className="btn btn-sm">Jeddah</div>
                                        <div className="btn btn-sm">Muscat</div>
                                        <div className="btn btn-sm">Behrain</div>
                                        <div className="btn btn-sm">Doha</div>
                                    </Col>
                                </Row>
                                <Row className="mt-5">
                                    <Col>
                                        <button className="btn">Previous Step</button>
                                    </Col>
                                    <Col className="align-right">
                                        <button className="btn btn-primary">Proceed to my workspace</button>
                                    </Col>
                                </Row>
                            </div>}
                    </Col>
                </Row>

            </React.Fragment>
        );
    }
}

const mapStatetoProps = state => {
    console.log('state=>', state);

    const { user, loginError, loading } = state.Login ? state.Login : { user: null, loginError: null, loading: null };
    return { user, loginError, loading };
}

export default withRouter(connect(mapStatetoProps, { activateNonAuthLayout })(ClientProfileSetting1));





