import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import '../../Container/globalsettings.css';
import { SuperParentContext } from './smscontext';
import { SMSParentManager, SMSAction } from './smsindex';
import { getSmsGBDataRequest, setResetForSMSGB, cancelAllPendingSmsGBRequests } from '../../../../store/actions';
import { IActions } from '../../../../models/utilitiesModel';
import { IGlobalSettingsModel } from '../../../../models/globalSettingsModel';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../../helpers/helpersIndex';

export interface IProps {
    activateAuthLayout: any;
    getSmsGBDataRequest: any;
    setResetForSMSGB: any;
    smsLoad: boolean;
    cancelAllPendingSmsGBRequests: any;
    edit: boolean;
}
class SMS extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props)
        this.state = {
            actionComp: SMSAction,
            actions: { edit: this.props.edit }
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForSMSGB();
        if (this.props.smsLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getSmsGBDataRequest(!this.props.smsLoad);
            }, getautoRefreshTime());
        }
        else
            this.props.getSmsGBDataRequest(!this.props.smsLoad);
    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForSMSGB();
        this.props.cancelAllPendingSmsGBRequests();
    }

    render() {
        return (
            <>
                <Container fluid className="h-100">
                    <SuperParentContext.Provider value={this.state}>
                        <SMSParentManager />
                    </SuperParentContext.Provider>
                </Container>
            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['edit'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'smsapi', defaultPrivilages);
    if (getAutoRefresing() && state.globalSettingsReducer && (state.globalSettingsReducer as IGlobalSettingsModel).smsData)
        return { smsLoad: ((state.globalSettingsReducer as IGlobalSettingsModel).smsData ? true : false), loginUserRolecode: loginUserRolecode, edit: privileges.includes(IActions.EDIT) };
    else
        return { smsLoad: false, loginUserRolecode: loginUserRolecode, edit: privileges.includes(IActions.EDIT) };
}


export default connect(mapStatetoProps, { activateAuthLayout, cancelAllPendingSmsGBRequests, getSmsGBDataRequest, setResetForSMSGB })(SMS);
