import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, FormGroup, Label } from 'reactstrap';
import '../../Container/globalsettings.css';
import { Formik, Field, Form, ErrorMessage, FieldArray, getIn } from 'formik';
import { controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { SuperParentContext } from '../container/smscontext';
import { useTranslation } from 'react-i18next';
import { IGlobalSettingsModel, IQueryParam, ISmsSettings } from '../../../../models/globalSettingsModel';
import { updateSmsGBDataRequest } from '../../../../store/actions';
import Autocomplete from "react-autocomplete";
import * as _ from 'lodash';

export interface optionsData {
    value: any;
    label: any;
}

const typeOfApisOptions = [
    { value: 'http', label: 'HTTP' },
    { value: 'https', label: 'HTTPS' }
];
const methodsOptions = [
    { value: 'GET', label: 'GET' },
    // { value: 'POST', label: 'POST' },
    // { value: 'PUT', label: 'PUT' },
    // { value: 'DELETE', label: 'DELETE' }
];

const SMSAction: React.FC = () => {

    // Yup.addMethod(Yup.array, 'unique', function (message, mapper = a => a) {
    //     return Yup.mixed().test('unique', message, function (list) {
    //         return list.length === new Set(list.map(mapper)).size;
    //     });
    // });

    const contextActions: any = useContext(SuperParentContext)?.actions;
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const smsData: ISmsSettings = useSelector(state => {
        if (state && state.globalSettingsReducer && state.globalSettingsReducer.smsData)
            return (state.globalSettingsReducer as IGlobalSettingsModel).smsData;
        else return undefined;
    });
    const smsQueryData: IQueryParam[] = useSelector(state => {
        if (state && state.globalSettingsReducer && state.globalSettingsReducer.smsQueryParamsData)
            return (state.globalSettingsReducer as IGlobalSettingsModel).smsQueryParamsData;
        else return undefined;
    });
    console.log("SMSAction =>", smsData, smsQueryData, contextActions);


    const typeOFApiSelection = (value, setFieldValue) => {
        setFieldValue('typeOfApi', value);
    }
    const methodSelection = (value, setFieldValue) => {
        setFieldValue('method', value);
    }

    const PatchTypeOfApi = (apiType) => {
        let index = typeOfApisOptions.findIndex(x => x.value === apiType);
        return index !== -1 ? { value: typeOfApisOptions[index].value, label: typeOfApisOptions[index].label } : '';
    }
    const patchMethodType = (methodType) => {
        let index = methodsOptions.findIndex(x => x.value === methodType);
        return index !== -1 ? { value: methodsOptions[index].value, label: methodsOptions[index].label } : '';
    }

    return (
        <>
            <Formik
                enableReinitialize
                initialValues={{
                    connectionName: smsData ? smsData.connectionName : '',
                    typeOfApi: smsData ? PatchTypeOfApi(smsData.typeOfApi) : '',
                    method: smsData ? patchMethodType(smsData.method) : { value: 'GET', label: 'GET' },
                    host: smsData ? smsData.host : '',
                    path: smsData ? smsData.path : '',
                    queryParam: smsData ? smsData.queryParameters : [
                        {
                            paramName: "",
                            paramValue: ""
                        }
                    ],
                    isQueryParamDup: ''
                }}
                validationSchema={Yup.object().shape({
                    connectionName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
                    typeOfApi: controleContentValidate(t('controleErrors.required')),
                    method: controleContentValidate(t('controleErrors.required')),
                    host: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: '/.:' }, 50, 2),
                    path: controleContentValidate(t('controleErrors.required'), { value: 2, message: t('controleErrors.min').replace('{min}', '2') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, ''),
                    queryParam: Yup.array().of(
                        Yup.object().shape({
                            paramName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
                            paramValue: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 1)
                        })
                    ),
                    isQueryParamDup: Yup.string().when('queryParam', val => {
                        let value = val ? val.filter(x => x.paramName !== '' && x.paramName) : [];
                        if (value.length > 0)
                            return value.length !== (_.sortedUniq(value.map(x => x.paramName))).length ? Yup.string().required(t('GlobalSettings.uniqueName')) : Yup.string().notRequired();
                        else
                            return Yup.string().notRequired();
                    })
                })}
                onSubmit={(values, { resetForm }) => {
                    console.log("Values =>", values);
                    let typeOfData: optionsData = values.typeOfApi as any;
                    let methodData: optionsData = values.method as any;
                    let smsReqObj = {
                        connectionName: values.connectionName,
                        host: values.host,
                        path: values.path,
                        queryParameters: values.queryParam,
                        method: methodData.value,
                        typeOfApi: typeOfData.value
                    }
                    console.log("dispatch =>", smsReqObj);
                    dispatch(updateSmsGBDataRequest(smsReqObj));
                }}
            >
                {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                    <Form>
                        <Col sm="10" className="p-0">
                            <Row>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label htmlFor="example-text-input">{t('GlobalSettings.connectionName')}</Label>
                                        <Field disabled={!contextActions.edit} name="connectionName" placeholder={t('GlobalSettings.connectionName')}
                                            className={'form-control ' + (errors.connectionName && touched.connectionName ? 'is-invalid' : '')} />
                                        <ErrorMessage name="connectionName" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('GlobalSettings.typeOfApi')}</Label>
                                        <MySelect
                                            name="typeOfApi"
                                            value={values.typeOfApi}
                                            onChange={(e) => typeOFApiSelection(e, setFieldValue)}
                                            options={typeOfApisOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('typeOfApi', true)}
                                            isDisabled={!contextActions.edit}
                                            noOptionsMessage={() => t('GlobalSettings.noApiTypes')}
                                        />
                                        {errors.typeOfApi && touched.typeOfApi && (
                                            <div style={{ color: "red", marginTop: ".5rem" }}>{errors.typeOfApi}
                                            </div>
                                        )}
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('GlobalSettings.method')}</Label>
                                        <MySelect
                                            name="method"
                                            value={values.method}
                                            onChange={(e) => methodSelection(e, setFieldValue)}
                                            options={methodsOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('method', true)}
                                            isDisabled={!contextActions.edit}
                                            noOptionsMessage={() => t('GlobalSettings.noMethods')}
                                        />
                                        {errors.method && touched.method && (
                                            <div className="error-msg">{errors.method}
                                            </div>
                                        )}
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label htmlFor="example-text-input">{t('GlobalSettings.host')}</Label>
                                        <Field disabled={!contextActions.edit} name="host" placeholder={t('GlobalSettings.host')}
                                            className={'form-control ' + (errors.host && touched.host ? 'is-invalid' : '')} />
                                        <ErrorMessage name="host" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <FormGroup>
                                        <Label htmlFor="example-text-input">{t('GlobalSettings.path')}</Label>
                                        <Field disabled={!contextActions.edit} name="path" placeholder={t('GlobalSettings.path')}
                                            className={'form-control ' + (errors.path && touched.path ? 'is-invalid' : '')} />
                                        <ErrorMessage name="path" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>

                                <Col sm="8">
                                    <Label htmlFor="example-text-input">{t('GlobalSettings.queryParam')}</Label>
                                    {errors.isQueryParamDup && (
                                        <div className="error-msg">{errors.isQueryParamDup}
                                        </div>
                                    )}
                                    <br />
                                    <FieldArray name="queryParam">
                                        {({ push, remove }) => (
                                            <>
                                                {values.queryParam.map((p, index) => {
                                                    const paramName = `queryParam[${index}].paramName`;
                                                    const touchedParamName = getIn(touched, paramName);
                                                    const errorParamName = getIn(errors, paramName);

                                                    const paramValue = `queryParam[${index}].paramValue`;
                                                    const touchedParamValue = getIn(touched, paramValue);
                                                    const errorParamValue = getIn(errors, paramValue);

                                                    return (
                                                        <Row key={index}>
                                                            <Col sm="4">
                                                                <FormGroup>
                                                                    <Label>{t('GlobalSettings.paramName')}</Label>
                                                                    <Field
                                                                        disabled={!contextActions.edit}
                                                                        placeholder={t('GlobalSettings.paramName')}
                                                                        className={'form-control ' + (touchedParamName && errorParamName ? ' is-invalid' : '')}
                                                                        label={t('GlobalSettings.paramName')}
                                                                        name={paramName}
                                                                    />
                                                                    <ErrorMessage name={paramName} component="div" className={(touchedParamName && errorParamName) ? 'invalid-feedback' : ''} />
                                                                </FormGroup>
                                                            </Col>
                                                            <Col sm="3" className="Autocmp">
                                                                <FormGroup onClick={() => setFieldTouched(`queryParam[${index}].paramValue`, true)}>
                                                                    <Label>{t('GlobalSettings.paramValue')}</Label>
                                                                    {!contextActions.edit && <Field
                                                                        disabled={true}
                                                                        placeholder={t('GlobalSettings.paramValue')}
                                                                        className={'form-control ' + (touchedParamValue && errorParamValue ? ' is-invalid' : '')}
                                                                        label={t('GlobalSettings.paramValue')}
                                                                        name={paramValue}
                                                                        value={p.paramValue}
                                                                    />}
                                                                    {contextActions.edit && <Autocomplete
                                                                        items={
                                                                            smsQueryData ? smsQueryData.map(item => ({ id: item.queryParamId, label: item.queryParam })) : []
                                                                        }
                                                                        shouldItemRender={(item, value) => item.label.toLowerCase().indexOf(value.toLowerCase()) > -1}
                                                                        getItemValue={item => item.label}
                                                                        renderItem={(item, highlighted) =>
                                                                            <div
                                                                                key={item.id}
                                                                                style={{ backgroundColor: highlighted ? '#eee' : 'transparent', padding: '8px' }}
                                                                            >
                                                                                {item.label}
                                                                            </div>
                                                                        }
                                                                        value={values.queryParam[index].paramValue}
                                                                        onChange={e => {
                                                                            setFieldValue(`queryParam[${index}].paramValue`, e.target.value);
                                                                            // setFieldTouched(`queryParam[${index}].paramValue`, true)
                                                                        }}
                                                                        onSelect={value => setFieldValue(`queryParam[${index}].paramValue`, value)}
                                                                    />}
                                                                    {console.log("Errors =>", errors, touched)}
                                                                    {(errors.queryParam ? errors?.queryParam[index]?.paramValue : false) && (touched.queryParam ? touched?.queryParam[index]?.paramValue : false) && (
                                                                        <div className="error-msg">{errors.queryParam ? errors?.queryParam[index]?.paramValue : ''}
                                                                        </div>
                                                                    )}
                                                                </FormGroup>
                                                            </Col>


                                                            <Col sm="4" className="parambtn p-0">
                                                                {values.queryParam.length > 1 && contextActions.edit && <button type="button" className="btn btn-cancel" onClick={() => remove(index)} >
                                                                    {t('ActionNames.delete')}
                                                                </button>}
                                                                {values.queryParam.length - 1 === index && values.queryParam.length < 10 && contextActions.edit && <button type="button" className="btn btn-primary-border ml-2" onClick={() =>
                                                                    push({ paramName: "", paramValue: "" })
                                                                }>
                                                                    {t('GlobalSettings.addParam')}
                                                                </button>}
                                                            </Col>
                                                        </Row>
                                                    );
                                                })}
                                            </>
                                        )}
                                    </FieldArray>
                                </Col>
                            </Row>

                            <hr />

                            <div className="mt-4 mb-3">
                                {contextActions.edit && <button className="btn btn-primary" disabled={!(dirty)}>
                                    {!smsData ? t('ActionNames.save') : t('ActionNames.update')}
                                </button>}
                                {/* <button className="btn btn-cancel ml-3">Clear</button> */}
                            </div>

                        </Col>
                    </Form>
                )}
            </Formik>
        </>
    )
}

export default React.memo(SMSAction);