import React, { useContext } from 'react';
import { SuperParentContext } from '../container/smscontext';
import { useSelector } from 'react-redux';

const SMSParentManager: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    console.log("SMSParentManager =>", context);

    const smsStatus = useSelector(state => {
        if (state && state.globalSettingsReducer && (state.globalSettingsReducer.smsStatus !== undefined))
            return true;
        else return false;
    });
    console.log("SMSParentManager =>", smsStatus);

    return (
        <>

            <div className="flexLayout">
                <div className="flexLayout-inner">
                    <div className="pr-3 pb-3">

                        {smsStatus && <context.actionComp />}
                        {/* {smsStatus === false && <span>{t('GlobalSettings.noSmsData')}</span>} */}

                    </div>
                </div>
            </div>
        </>
    )
}

export default React.memo(SMSParentManager);