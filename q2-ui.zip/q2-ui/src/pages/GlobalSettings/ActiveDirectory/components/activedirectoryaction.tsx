import React, { useContext, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, FormGroup, Label } from 'reactstrap';
import { Formik, Form, ErrorMessage, Field } from 'formik';
import { controleContentValidate, customContentValidation } from '../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { IAdSettings } from '../../../../models/globalSettingsModel';
import { UpdateGBActionDirectoryRequest } from '../../../../store/actions';
import { SuperParentContext } from '../Container/activedirectoryContextApi';
import '../../Container/globalsettings.css';

const ActiveDirectoryAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const activeDirectoryData = useSelector(state => state?.globalSettingsReducer?.activeDirectoryData);
    const dispatch = useDispatch();
    const [hidden, setHidden] = useState(false)
    const contextActions = useContext(SuperParentContext)?.actions;
    console.log("ActiveDirectoryAction =>", activeDirectoryData);
    return (
        <>
            <Row>
                <Col sm="10">
                    <Formik
                        enableReinitialize
                        initialValues={{
                            adPath: activeDirectoryData ? activeDirectoryData.adPath : '',
                            firstName: activeDirectoryData ? activeDirectoryData.firstName : '',
                            host: activeDirectoryData ? activeDirectoryData.host : '',
                            lastName: activeDirectoryData ? activeDirectoryData.lastName : '',
                            ldapTimeOut: activeDirectoryData ? activeDirectoryData.ldapTimeOut : '',
                            loginId: activeDirectoryData ? activeDirectoryData.loginId : '',
                            mailId: activeDirectoryData ? activeDirectoryData.mailId : '',
                            maxUsers: activeDirectoryData ? activeDirectoryData.maxUsers : '',
                            mobileNo: activeDirectoryData ? activeDirectoryData.mobileNo : '',
                            password: activeDirectoryData ? activeDirectoryData.password : '',
                            port: activeDirectoryData ? activeDirectoryData.port : '',
                            userName: activeDirectoryData ? activeDirectoryData.userName : ''
                        }}
                        validationSchema={Yup.object().shape({
                            userName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
                            firstName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
                            lastName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
                            mailId: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 1),
                            mobileNo: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 1),
                            loginId: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
                            password: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumricwithoutspaceandallspecial', message: 'alphanumricwithoutspaceandallspecial', spacialChar: null }, 50, 2),
                            port: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number' }, 5, 3),
                            host: controleContentValidate(t('controleErrors.required'), { value: 5, message: t('controleErrors.min').replace('{min}', '5') }, { value: 100, message: t('controleErrors.max').replace('{max}', '100') }, { patternType: 'ipOrDomain', message: t('controleErrors.ipOrDomainPattern') }),
                            adPath: customContentValidation(t, t('controleErrors.required'), '', 50, 2)
                        })}
                        onSubmit={(values) => {

                            let activeDirectory = {
                                adPath: values.adPath,
                                firstName: values.firstName,
                                host: values.host,
                                lastName: values.lastName,
                                ldapTimeOut: values.ldapTimeOut,
                                loginId: values.loginId,
                                mailId: values.mailId,
                                maxUsers: values.maxUsers,
                                mobileNo: values.mobileNo,
                                password: values.password,
                                port: values.port,
                                userName: values.userName
                            } as IAdSettings;
                            console.log("Values =>", values, activeDirectory);
                            dispatch(UpdateGBActionDirectoryRequest(activeDirectory))


                        }}
                    >
                        {({ errors, touched, dirty }) => (
                            <Form className="pr-3">
                                <Row>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.ip/domain')}</Label>
                                            <Field disabled={!contextActions.edit} name="host" placeholder={t('GlobalSettings.ip/domain')}
                                                className={'form-control ' + (errors.host && touched.host ? 'is-invalid' : '')} />
                                            <ErrorMessage name="host" component="div" className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.port')}</Label>
                                            <Field disabled={!contextActions.edit} name="port" placeholder={t('GlobalSettings.port')}
                                                className={'form-control ' + (errors.port && touched.port ? 'is-invalid' : '')} />
                                            <ErrorMessage name="port" component="div" className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.username')}</Label>
                                            <Field disabled={!contextActions.edit} name="userName" placeholder={t('GlobalSettings.username')}
                                                className={'form-control ' + (errors.userName && touched.userName ? 'is-invalid' : '')} />
                                            <ErrorMessage name="userName" component="div" className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup className="eyepassword">
                                            <Label htmlFor="example-password-input">{t('GlobalSettings.password')}</Label>
                                            <Field type={!hidden ? "password" : 'text'} disabled={!contextActions.edit} name="password" placeholder={t('GlobalSettings.password')}
                                                className={'form-control ' + (errors.password && touched.password ? 'is-invalid' : '')} />
                                            <ErrorMessage name="password" component="div" className="invalid-feedback" />
                                            <i className={(!hidden ? 'ti-eye' : 'ti-close')} onClick={() => {
                                                setHidden(!hidden)
                                            }}></i>
                                            {/* <i className="ti-close"></i> */}
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.firstname')}</Label>
                                            <Field disabled={!contextActions.edit} name="firstName" placeholder={t('GlobalSettings.firstname')}
                                                className={'form-control ' + (errors.firstName && touched.firstName ? 'is-invalid' : '')} />
                                            <ErrorMessage name="firstName" component="div" className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.lastname')}</Label>
                                            <Field disabled={!contextActions.edit} name="lastName" placeholder={t('GlobalSettings.lastname')}
                                                className={'form-control ' + (errors.lastName && touched.lastName ? 'is-invalid' : '')} />
                                            <ErrorMessage name="lastName" component="div" className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.mobileno')}</Label>
                                            <Field disabled={!contextActions.edit} name="mobileNo" placeholder={t('GlobalSettings.mobileno')}
                                                className={'form-control ' + (errors.mobileNo && touched.mobileNo ? 'is-invalid' : '')} />
                                            <ErrorMessage name="mobileNo" component="div" className="invalid-feedback" />                                     </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.emailid')}</Label>
                                            <Field disabled={!contextActions.edit} name="mailId" placeholder={t('GlobalSettings.emailid')}
                                                className={'form-control ' + (errors.mailId && touched.mailId ? 'is-invalid' : '')} />
                                            <ErrorMessage name="mailId" component="div" className="invalid-feedback" />                                     </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.loginid')}</Label>
                                            <Field disabled={!contextActions.edit} name="loginId" placeholder={t('GlobalSettings.loginid')}
                                                className={'form-control ' + (errors.loginId && touched.loginId ? 'is-invalid' : '')} />
                                            <ErrorMessage name="loginId" component="div" className="invalid-feedback" />                                     </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label htmlFor="example-text-input">{t('GlobalSettings.adPath')}</Label>
                                            <Field disabled={!contextActions.edit} name="adPath" placeholder={t('GlobalSettings.adPath')}
                                                className={'form-control ' + (errors.adPath && touched.adPath ? 'is-invalid' : '')} />
                                            <ErrorMessage name="adPath" component="div" className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <hr />

                                <div className="mt-4 mb-3">
                                    {contextActions.edit && <button type="submit" disabled={!(dirty)} className="btn btn-primary">
                                        {!activeDirectoryData ? t('ActionNames.save') : t('ActionNames.update')}
                                    </button>}
                                </div>
                            </Form>
                        )}
                    </Formik>
                </Col>
            </Row>
        </>
    )
}
export default React.memo(ActiveDirectoryAction)