import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/activedirectoryContextApi';


const ActiveDirectoryParentManager: React.FC = () => {
    const context = useContext(SuperParentContext);


    const activeDirectoryDataStatus = useSelector(state => {
        if (state && state.globalSettingsReducer && (state.globalSettingsReducer.activeDirectoryStatus !== undefined))
            return true;
        else return false;
    });
    return (
        <>
            <div className="flexLayout">
                <div className="flexLayout-inner">
                    {activeDirectoryDataStatus && <context.actionComponent />}
                    {/* {activeDirectoryDataStatus === false && <span>{t('GlobalSettings.nodata')}</span>} */}
                </div>
            </div>
        </>
    )
}
export default React.memo(ActiveDirectoryParentManager)