import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import {
    ActiveDirectoryAction,
    ActiveDirectoryParentManager
} from './activedirectoryindex';
import '../../Container/globalsettings.css';
import { getGBActiveDirectoryDataRequest, cancelAllPendingActiveDirectoryGBRequests, setResetForGBActiveDirectory } from '../../../../store/actions';
import { SuperParentContext } from './activedirectoryContextApi';
import { getautoRefreshTime, getAutoRefresing, getModulePrivilages } from '../../../../helpers/helpersIndex';
import { IGlobalSettingsModel } from '../../../../models/globalSettingsModel';
import { IActions } from '../../../../models/utilitiesModel';

export interface IProps {
    activateAuthLayout: any;
    getGBActiveDirectoryDataRequest: any;
    setResetForGBActiveDirectory: any;
    activeDirectoryLoad: any;
    cancelAllPendingActiveDirectoryGBRequests: any;
    edit: boolean;
}
class ActiveDirectory extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            actionComponent: ActiveDirectoryAction,
            actions: { edit: this.props.edit }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForGBActiveDirectory();
        this.props.getGBActiveDirectoryDataRequest();
        if (this.props.activeDirectoryLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getGBActiveDirectoryDataRequest();
            }, getautoRefreshTime());
        }
        else
            this.props.getGBActiveDirectoryDataRequest();
    }

    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForGBActiveDirectory();
        this.props.cancelAllPendingActiveDirectoryGBRequests()

    }

    render() {
        return (
            <>

                <Container fluid className="h-100">
                    <SuperParentContext.Provider value={this.state}>
                        <ActiveDirectoryParentManager />
                    </SuperParentContext.Provider>
                </Container>

            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['edit'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'activedirectory', defaultPrivilages);
    if (getAutoRefresing() && state.globalSettingsReducer && (state.globalSettingsReducer as IGlobalSettingsModel).activeDirectoryData)
        return { activeDirectoryLoad: ((state.globalSettingsReducer as IGlobalSettingsModel).activeDirectoryData.length > 0 ? true : false), loginUserRolecode: loginUserRolecode, edit: privileges.includes(IActions.EDIT) };
    else
        return { activeDirectoryLoad: false, loginUserRolecode: loginUserRolecode, edit: privileges.includes(IActions.EDIT) };
}
export default connect(mapStatetoProps, { activateAuthLayout, cancelAllPendingActiveDirectoryGBRequests, getGBActiveDirectoryDataRequest, setResetForGBActiveDirectory })(ActiveDirectory);