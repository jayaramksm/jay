import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import {
    PasswordPolicyAction,
    PasswordPolicyParentManager
} from './passwordpolicyindex';
import '../../Container/globalsettings.css';
import { getGBPasswordPolicyDataRequest, cancelAllPendingPasswordPolicyGBRequests, setResetForPasswordPolicyGB } from '../../../../store/actions';
import { SuperParentContext } from './passwordpolicycontextapi';
import { getautoRefreshTime, getAutoRefresing, getModulePrivilages } from '../../../../helpers/helpersIndex';
import { IGlobalSettingsModel } from '../../../../models/globalSettingsModel';
import { IActions } from '../../../../models/utilitiesModel';

export interface IProps {
    activateAuthLayout: any;
    getGBPasswordPolicyDataRequest: any;
    setResetForPasswordPolicyGB: any;
    passwordPolicyLoad: any;
    cancelAllPendingPasswordPolicyGBRequests: any;
    edit: boolean;
}

class PasswordPolicy extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            actionComponent: PasswordPolicyAction,
            actions: { edit: this.props.edit }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForPasswordPolicyGB();
        this.props.getGBPasswordPolicyDataRequest();
        if (this.props.passwordPolicyLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getGBPasswordPolicyDataRequest();
            }, getautoRefreshTime());
        }
        else
            this.props.getGBPasswordPolicyDataRequest();
    }

    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForPasswordPolicyGB();
        this.props.cancelAllPendingPasswordPolicyGBRequests()

    }

    render() {
        return (
            <>

                <Container fluid className="h-100">
                    <SuperParentContext.Provider value={this.state}>
                        <PasswordPolicyParentManager />
                    </SuperParentContext.Provider>
                </Container>

            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['edit'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'passwordpolicy', defaultPrivilages);
    if (getAutoRefresing() && state.globalSettingsReducer && (state.globalSettingsReducer as IGlobalSettingsModel).passwordPolicyData)
        return { passwordPolicyLoad: ((state.globalSettingsReducer as IGlobalSettingsModel).passwordPolicyData.length > 0 ? true : false), loginUserRolecode: loginUserRolecode, edit: privileges.includes(IActions.EDIT) };
    else
        return { passwordPolicyLoad: false, loginUserRolecode: loginUserRolecode, edit: privileges.includes(IActions.EDIT) };
}
export default connect(mapStatetoProps, { activateAuthLayout, cancelAllPendingPasswordPolicyGBRequests, getGBPasswordPolicyDataRequest, setResetForPasswordPolicyGB })(PasswordPolicy);