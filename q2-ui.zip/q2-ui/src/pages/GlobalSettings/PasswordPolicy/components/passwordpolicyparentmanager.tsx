import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../container/passwordpolicycontextapi';


const PasswordPolicyParentManager: React.FC = () => {

    const context = useContext(SuperParentContext);

    const passwordPolicyDataStatus = useSelector(state => {
        if (state && state.globalSettingsReducer && (state.globalSettingsReducer.passwordPolicyStatus !== undefined))
            return true;
        else return false;
    });

    return (
        <>
            <div className="flexLayout">
                <div className="flexLayout-inner">
                    {passwordPolicyDataStatus && <context.actionComponent />}
                </div>
            </div>
        </>
    )
}

export default React.memo(PasswordPolicyParentManager)