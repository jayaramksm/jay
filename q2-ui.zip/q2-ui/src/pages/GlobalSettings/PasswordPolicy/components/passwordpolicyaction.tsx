import React, { useEffect, useContext, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, FormGroup, Label } from 'reactstrap';
import { Formik, Form, ErrorMessage, Field } from 'formik';
import { controleContentValidate, customContentValidation } from '../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import * as _ from 'lodash';
import { useTranslation } from 'react-i18next';
import { IPasswordPolicy } from '../../../../models/globalSettingsModel';
import { UpdateGBPasswordPolicyRequest } from '../../../../store/actions';
import { SuperParentContext } from '../container/passwordpolicycontextapi';
import '../../Container/globalsettings.css';
import { isNumeric } from 'rxjs/internal-compatibility';

let minValue: number = 1;
let upperValue: number = 0;
let lowerValue: number = 0;
let alphaValue: number = 0;
let numricValue: number = 0;
let maxValue: number = 30;

const PasswordPolicyAction: React.FC = () => {

    const { t } = useTranslation("translations");
    const passwordPolicyData: IPasswordPolicy = useSelector(state => state?.globalSettingsReducer?.passwordPolicyData);
    const dispatch = useDispatch();
    const contextActions = useContext(SuperParentContext)?.actions;
    console.log("PasswordPolicyAction =>", passwordPolicyData);


    const onChangeSpecial = (e, setFieldValue) => {
        let eVal = e?.target?.value ? e?.target?.value : '';
        let eValDuplicate = 0;
        try {
            eValDuplicate = eVal.toLowerCase().split("").sort().join("").match(/(.)\1+/g).length;
        }
        catch (e) {
            eValDuplicate = 0;
        }
        console.log("onChangeSpecial =>", e.target.value, eValDuplicate);
        if (eValDuplicate === 0)
            setFieldValue('specialCharactersAllowed', e.target.value);
    }

    useEffect(() => {
        return () => {
            minValue = 1;
            minValue = 1;
            upperValue = 0;
            lowerValue = 0;
            alphaValue = 0;
            numricValue = 0;
            maxValue = 30;
        }
    }, [])

    return (
        <>
            <Row>
                <Col sm="10">
                    <Formik
                        enableReinitialize
                        initialValues={{
                            noOfUpperCaseLetters: passwordPolicyData ? passwordPolicyData.noOfUpperCaseLetters : '',
                            noOfLowerCaseLetters: passwordPolicyData ? passwordPolicyData.noOfLowerCaseLetters : '',
                            numberOfNumerical: passwordPolicyData ? passwordPolicyData.numberOfNumerical : '',
                            numberOfAlphabets: passwordPolicyData ? passwordPolicyData.numberOfAlphabets : '',
                            specialCharactersAllowed: passwordPolicyData ? passwordPolicyData.specialCharactersAllowed : '',
                            minimumLength: passwordPolicyData && passwordPolicyData?.minimumLength ? passwordPolicyData.minimumLength : '',
                            maximumLength: passwordPolicyData && passwordPolicyData?.maximumLength ? passwordPolicyData.maximumLength : '',
                            passwordValidityPeriod: passwordPolicyData && passwordPolicyData?.passwordValidityPeriod ? passwordPolicyData.passwordValidityPeriod : 90,
                            changePasswordatFirstLogin: passwordPolicyData ? passwordPolicyData?.changePasswordatFirstLogin : true
                        }}
                        validationSchema={Yup.object().shape({
                            minimumLength: Yup.number().integer().min(3, t('controleErrors.minNumber').replace('{min}', '3')).max(29, t('controleErrors.maxNumber').replace('{max}', '29')).required(t('controleErrors.required')).typeError(t('controleErrors.number')),
                            maximumLength: Yup.lazy(maxVal => {
                                if (maxVal !== undefined) {
                                    return Yup.number().integer().min(4, t('controleErrors.minNumber').replace('{min}', '4')).max(30, t('controleErrors.maxNumber').replace('{max}', '30')).when('minimumLength', {
                                        is: val => {
                                            if (isNumeric(val))
                                                minValue = +val;
                                            if (isNumeric(maxVal) && _.inRange(maxVal, 3, 31))
                                                maxValue = +maxVal;
                                            else
                                                maxValue = 30;
                                            return isNumeric(val) && _.inRange(maxVal, 3, 31)
                                        },
                                        then: Yup.number().integer().moreThan(minValue, t('GlobalSettings.minValueMaxFieldMsg')).typeError(t('controleErrors.number')),
                                    }).required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                } else {
                                    return Yup.number().integer().min(4, t('controleErrors.minNumber').replace('{min}', '4')).max(30, t('controleErrors.maxNumber').replace('{max}', '30')).required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                }
                            }),
                            noOfUpperCaseLetters: Yup.lazy(val => {
                                upperValue = 0;
                                if (isNumeric(val)) {
                                    if (_.inRange(val, 1, maxValue))
                                        upperValue = +val;
                                    let maxval = (alphaValue ? alphaValue - lowerValue : maxValue - (lowerValue + numricValue));
                                    return Yup.number().integer().min(0, t('controleErrors.minNumber').replace('{min}', '0')).max(maxval, t('controleErrors.maxNumber').replace('{max}', maxval + '')).required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                }
                                else
                                    return Yup.number().integer().required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                            }),
                            noOfLowerCaseLetters: Yup.lazy(val => {
                                lowerValue = 0;
                                if (isNumeric(val)) {
                                    if (_.inRange(val, 1, maxValue))
                                        lowerValue = +val;
                                    let maxval = (alphaValue ? alphaValue - upperValue : maxValue - (upperValue + numricValue));
                                    return Yup.number().integer().min(0, t('controleErrors.minNumber').replace('{min}', '0')).max(maxval, t('controleErrors.maxNumber').replace('{max}', maxval + '')).required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                }
                                else
                                    return Yup.number().integer().required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                            }),
                            specialCharactersAllowed: Yup.lazy(val => {
                                return val !== undefined ? customContentValidation(t, t('controleErrors.required'), { patternType: 'onlyAllowSpecialChar', message: 'onlyAllowSpecialChar', spacialChar: null }, 30, 1) : Yup.string().notRequired()
                            }),
                            numberOfNumerical: Yup.lazy(val => {
                                numricValue = 0;
                                if (val !== undefined) {
                                    if (isNumeric(val)) {
                                        if (_.inRange(val, 1, maxValue))
                                            numricValue = +val;
                                        let maxval = maxValue - (alphaValue ? alphaValue : (upperValue + lowerValue));
                                        return Yup.number().integer().min(0, t('controleErrors.minNumber').replace('{min}', '0')).max(maxval, t('controleErrors.maxNumber').replace('{max}', maxval + '')).required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                    }
                                    else
                                        return Yup.number().integer().required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                }
                                else
                                    return Yup.number().integer().notRequired()
                            }),

                            numberOfAlphabets: Yup.lazy(val => {
                                alphaValue = 0;
                                if (val !== undefined) {
                                    if (isNumeric(val)) {
                                        if (_.inRange(val, 1, maxValue))
                                            alphaValue = +val;
                                        let maxval = maxValue - numricValue;
                                        return Yup.number().integer().min(0, t('controleErrors.minNumber').replace('{min}', '0')).max(maxval, t('controleErrors.maxNumber').replace('{max}', maxval + '')).required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                    }
                                    else
                                        return Yup.number().integer().required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                                }
                                else
                                    return Yup.number().integer().notRequired()
                            }),
                            passwordValidityPeriod: Yup.number().integer().min(10, t('controleErrors.minNumber').replace('{min}', '10')).max(365, t('controleErrors.maxNumber').replace('{max}', '365')).required(t('controleErrors.required')).typeError(t('controleErrors.number'))
                        })}
                        onSubmit={(values) => {
                            let requestData = values as IPasswordPolicy;
                            requestData.numberOfAlphabets = requestData?.numberOfAlphabets ? requestData.numberOfAlphabets : 0;
                            requestData.numberOfNumerical = requestData?.numberOfNumerical ? requestData.numberOfNumerical : 0;
                            console.log("onSubmit_Values =>", values, requestData);
                            dispatch(UpdateGBPasswordPolicyRequest(requestData));
                        }}
                    >
                        {({ errors, touched, dirty, values, setFieldValue }) => (
                            <Form className="pr-3">
                                <Row>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.minLength')}</Label>
                                            <Field placeholder={t('GlobalSettings.minLength')} name="minimumLength" type="text" className={'form-control ' + (errors.minimumLength && touched.minimumLength ? 'is-invalid' : '')} />
                                            <ErrorMessage name="minimumLength" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.maxLength')}</Label>
                                            <Field placeholder={t('GlobalSettings.maxLength')} name="maximumLength" type="text" className={'form-control ' + (errors.maximumLength && touched.maximumLength ? 'is-invalid' : '')} />
                                            <ErrorMessage name="maximumLength" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>

                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.nNumerical')}</Label>
                                            <Field placeholder={t('GlobalSettings.nNumerical')} name="numberOfNumerical" type="text" className={'form-control ' + (errors.numberOfNumerical && touched.numberOfNumerical ? 'is-invalid' : '')} />
                                            <ErrorMessage name="numberOfNumerical" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.nAlphabtes')}</Label>
                                            <Field placeholder={t('GlobalSettings.nAlphabtes')} name="numberOfAlphabets" type="text" className={'form-control ' + (errors.numberOfAlphabets && touched.numberOfAlphabets ? 'is-invalid' : '')} />
                                            <ErrorMessage name="numberOfAlphabets" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.nUpperLetter')}</Label>
                                            <Field placeholder={t('GlobalSettings.nUpperLetter')} name="noOfUpperCaseLetters" type="text" className={'form-control ' + (errors.noOfUpperCaseLetters && touched.noOfUpperCaseLetters ? 'is-invalid' : '')} />
                                            <ErrorMessage name="noOfUpperCaseLetters" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.nLowerLetter')}</Label>
                                            <Field placeholder={t('GlobalSettings.nLowerLetter')} name="noOfLowerCaseLetters" type="text" className={'form-control ' + (errors.noOfLowerCaseLetters && touched.noOfLowerCaseLetters ? 'is-invalid' : '')} />
                                            <ErrorMessage name="noOfLowerCaseLetters" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>



                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.specialChars')}</Label>
                                            <Field placeholder={t('GlobalSettings.specialChars')} name="specialCharactersAllowed" onChange={(e) => onChangeSpecial(e, setFieldValue)} type="text" className={'form-control ' + (errors.specialCharactersAllowed && touched.specialCharactersAllowed ? 'is-invalid' : '')} />
                                            <ErrorMessage name="specialCharactersAllowed" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>


                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.passwordValidityPeriod')}</Label>
                                            <Field placeholder={t('GlobalSettings.passwordValidityPeriod')} name="passwordValidityPeriod" type="text" className={'form-control ' + (errors.passwordValidityPeriod && touched.passwordValidityPeriod ? 'is-invalid' : '')} />
                                            <ErrorMessage name="passwordValidityPeriod" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('GlobalSettings.isFirstLoginCP')}</Label>
                                            <Field placeholder={t('GlobalSettings.isFirstLoginCP')} name="changePasswordatFirstLogin" type="checkbox" checked={values.changePasswordatFirstLogin} className={'form-control ' + (errors.changePasswordatFirstLogin && touched.changePasswordatFirstLogin ? 'is-invalid' : '')} style={{ width: "25px" }} />
                                            <ErrorMessage name="changePasswordatFirstLogin" component='div' className="invalid-feedback" />
                                        </FormGroup>
                                    </Col>
                                </Row>

                                <hr />

                                <div className="mt-4 mb-3">
                                    {contextActions.edit && <button type="submit" disabled={!(dirty)} className="btn btn-primary">
                                        {!passwordPolicyData ? t('ActionNames.save') : t('ActionNames.update')}
                                    </button>}
                                </div>
                            </Form>
                        )}
                    </Formik>
                </Col>
            </Row>
        </>
    )
}

export default React.memo(PasswordPolicyAction)