export { default as EmailAction } from '../components/emailaction';
export { default as EmailParentManager } from '../components/emailparentmanager';