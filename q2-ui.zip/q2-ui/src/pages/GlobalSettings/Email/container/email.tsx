import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import {
    EmailAction,
    EmailParentManager
} from './emailindex';
import '../../Container/globalsettings.css';
import { IActions } from '../../../../models/utilitiesModel';
import { getGBEmailDataRequest, cancelAllPendingEmailGBRequests, setResetForGBEmail } from '../../../../store/actions';
import { SuperParentContext } from './emailcontext';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../../helpers/helpersIndex';
import { IGlobalSettingsModel } from '../../../../models/globalSettingsModel';

export interface IProps {
    activateAuthLayout: any;
    getGBEmailDataRequest: any;
    setResetForGBEmail: any;
    emailLoad: any;
    cancelAllPendingEmailGBRequests: any;
    edit: boolean;
}
class Email extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            actionComponent: EmailAction,
            actions: { edit: this.props.edit }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForGBEmail();

        if (this.props.emailLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getGBEmailDataRequest();
            }, getautoRefreshTime());
        }
        else
            this.props.getGBEmailDataRequest();
    }

    componentWillUnmount() {
        if (this.setinterval) {
            clearTimeout(this.setinterval);
        }
        this.props.setResetForGBEmail();
        this.props.cancelAllPendingEmailGBRequests();
    }

    render() {
        return (
            <>
                <Container fluid className="h-100">

                    <SuperParentContext.Provider value={this.state}>
                        <EmailParentManager />
                    </SuperParentContext.Provider>

                </Container>
            </>
        );
    }
}
const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['edit'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'mail', defaultPrivilages);
    if (getAutoRefresing() && state.globalSettingsReducer && (state.globalSettingsReducer as IGlobalSettingsModel).emailData)
        return {
            emailLoad: state.globalSettingsReducer.emailData ? true : false,
            loginUserRolecode: loginUserRolecode,
            edit: privileges.includes(IActions.EDIT)
        };
    else
        return {
            emailLoad: false,
            loginUserRolecode: loginUserRolecode,
            edit: privileges.includes(IActions.EDIT)
        };
}
export default connect(mapStatetoProps, { activateAuthLayout, cancelAllPendingEmailGBRequests, getGBEmailDataRequest, setResetForGBEmail })(Email);