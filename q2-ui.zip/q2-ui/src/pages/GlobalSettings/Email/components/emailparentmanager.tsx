import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../container/emailcontext';
import '../../Container/globalsettings.css';

const EmailParentManager: React.FC = () => {
    const context = useContext(SuperParentContext);
    const emailDataStatus = useSelector(state => {
        if (state && state.globalSettingsReducer && (state.globalSettingsReducer.emailStatus !== undefined))
            return true;
        else return false;
    });

    return (
        <>
            <div className="flexLayout pb-3">
                <div className="flexLayout-inner">

                    {emailDataStatus && <context.actionComponent />}
                    {/* {emailDataStatus === false && <span>{t('GlobalSettings.noData')}</span>} */}

                </div>
            </div>
        </>
    )
}
export default React.memo(EmailParentManager);