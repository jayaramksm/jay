import React, { useContext, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { SuperParentContext } from '../container/emailcontext';
import { Col, Row, Label } from 'reactstrap';
import '../../Container/globalsettings.css';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { IEmail } from '../../../../models/globalSettingsModel';
import { emailContentValidate, controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { updateGBEmailDataRequest } from '../../../../store/actions';

const EmailAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const [isTextType, setIsTextType] = useState(false);
    const contextActions = useContext(SuperParentContext)?.actions;
    const emailData: IEmail = useSelector(state => state?.globalSettingsReducer?.emailData);

    const getInitialValues = () => ({
        emailAccount: emailData ? emailData.emailAccount : '',
        password: emailData ? emailData.password : '',
        port: emailData ? emailData.port : '',
        serverIp: emailData ? emailData.serverIp : '',
        serverName: emailData ? emailData.serverName : '',
        mailBoxType: emailData ? mailBoxTypeData.find((x: any) => x.value === emailData.mailBoxType) : '',
        // mailCheckInterval: emailData ? emailData.mailCheckInterval : ''
    });

    const validationSchema = Yup.object().shape({
        emailAccount: emailContentValidate(t('controleErrors.required'), { value: 3, message: t('controleErrors.min').replace('{min}', '3') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid')),
        password: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumricwithoutspaceandallspecial', message: 'alphanumricwithoutspaceandallspecial', spacialChar: null }, 50, 2),
        port: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 4, 2),
        serverIp: controleContentValidate(t('controleErrors.required'), { value: 5, message: t('controleErrors.min').replace('{min}', '5') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, { patternType: 'server', message: t('controleErrors.serverPattern') }),
        serverName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
        mailBoxType: controleContentValidate(t('controleErrors.required')).ensure().nullable(),
        // mailCheckInterval: controleContentValidate(t('controleErrors.required'), '', { value: 2, message: t('controleErrors.max').replace('{max}', '2') }, { patternType: 'numberPattern', message: t('controleErrors.patterninvalid') })
    });

    return (
        <>
            <Row>
                <Col sm="10">
                    <Formik
                        enableReinitialize
                        initialValues={getInitialValues()}
                        validationSchema={validationSchema}
                        onSubmit={(values) => {
                            let data = {
                                emailAccount: values.emailAccount,
                                password: values.password,
                                port: values.port,
                                serverIp: values.serverIp,
                                serverName: values.serverName,
                                mailBoxType: (values.mailBoxType as any).value,
                                // mailCheckInterval: values.mailCheckInterval
                            }
                            dispatch(updateGBEmailDataRequest(data));
                        }}
                    >
                        {({ errors, touched, values, dirty, setFieldValue, setFieldTouched }) => (
                            <Form>
                                <Row>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('GlobalSettings.name')}</Label>
                                            <Field disabled={!contextActions.edit} placeholder={t('GlobalSettings.name')} name="serverName" className={'form-control ' + (errors.serverName && touched.serverName ? 'is-invalid' : '')} />
                                            <ErrorMessage name="serverName" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('GlobalSettings.emailAccount')}</Label>
                                            <Field disabled={!contextActions.edit} placeholder={t('GlobalSettings.emailAccount')} name="emailAccount" className={'form-control ' + (errors.emailAccount && touched.emailAccount ? 'is-invalid' : '')} />
                                            <ErrorMessage name="emailAccount" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group eyepassword">
                                            <Label>{t('GlobalSettings.password')}</Label>
                                            <Field disabled={!contextActions.edit} type={isTextType ? 'text' : 'password'} placeholder={t('GlobalSettings.password')} name="password" className={'form-control ' + (errors.password && touched.password ? 'is-invalid' : '')} />
                                            <i className={(!isTextType ? 'ti-eye' : 'ti-close')} onClick={() => setIsTextType(!isTextType)}></i>
                                            <ErrorMessage name="password" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('GlobalSettings.mailBoxType')}</Label>
                                            <MySelect
                                                name="mailBoxType"
                                                isDisabled={!contextActions.edit}
                                                value={values.mailBoxType}
                                                onChange={(e) => setFieldValue('mailBoxType', e)}
                                                options={mailBoxTypeData}
                                                getOptionLabel={option => option.label}
                                                getOptionValue={option => option.value}
                                                onBlur={() => setFieldTouched('mailBoxType', true)}
                                                noOptionsMessage={() => t('GlobalSettings.noMailboxTypes')}
                                            />
                                            {errors.mailBoxType && touched.mailBoxType && (
                                                <div className="error-msg">{errors.mailBoxType}</div>
                                            )}
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('GlobalSettings.serverIp')}</Label>
                                            <Field disabled={!contextActions.edit} placeholder={t('GlobalSettings.serverIp')} name="serverIp" className={'form-control ' + (errors.serverIp && touched.serverIp ? 'is-invalid' : '')} />
                                            <ErrorMessage name="serverIp" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('GlobalSettings.port')}</Label>
                                            <Field disabled={!contextActions.edit} placeholder={t('GlobalSettings.port')} name="port" className={'form-control ' + (errors.port && touched.port ? 'is-invalid' : '')} />
                                            <ErrorMessage name="port" component="div" className="invalid-feedback" />
                                        </div>
                                    </Col>
                                    {/* <Col sm="4">
                                    <div className="form-group">
                                        <Label>{t('GlobalSettings.checkInterval')}</Label>
                                        <Field disabled={!contextActions.edit} name="mailCheckInterval" as={(props) => CustomNumberComponent(props, errors.mailCheckInterval, touched.mailCheckInterval)} placeholder={t('GlobalSettings.checkInterval')} />
                                        <ErrorMessage name="mailCheckInterval" component="div" className="invalid-feedback" />
                                    </div>
                                </Col> */}
                                </Row>

                                <hr />

                                <div className="mt-4 mb-3">
                                    {/* <button className="btn btn-primary-border">Add Mailbox</button> */}
                                    {contextActions.edit && <button type="submit" className="btn btn-primary" disabled={!(dirty)}>
                                        {!emailData ? t('ActionNames.save') : t('ActionNames.update')}
                                    </button>}
                                    {/* <button className="btn btn-cancel ml-3">Clear</button> */}
                                </div>
                            </Form>
                        )}
                    </Formik>
                </Col>
            </Row>
        </>
    )
}
// const CustomNumberComponent = (props, errors, touched) => (
//     <input className={'form-control ' + (errors && touched ? 'is-invalid' : '')} type="number" {...props} />
// );
const mailBoxTypeData = [
    { value: '1', label: 'SMTP' },
    { value: '2', label: 'IMAP' }
];
export default React.memo(EmailAction);