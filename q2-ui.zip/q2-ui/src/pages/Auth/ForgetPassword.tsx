import React, { Component } from 'react';
import { Alert, Button, Col, Row, FormGroup } from 'reactstrap';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { forgetPasswordVerifyUserRequest, sendDefaultPasswordRequest, setResetForForgetPassword, cancelSendDefaultPassword } from '../../store/actions';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import logo from "../../images/firstpasslogo.svg";
import clientLogo from '../../images/vmcare.svg';
import { withTranslation } from 'react-i18next';
import { Form, Formik } from 'formik';
import { ICheckedEnums } from '../../models/utilitiesModel';
import BackToLogin from '../../images/backtologin.svg';
export interface IProps {
    forgetPasswordVerifyUserRequest: any;
    setResetForForgetPassword: any;
    sendDefaultPasswordStatus: any;
    t: any;
    history: any;
    cancelSendDefaultPassword: any;
    errorMessage: any;
    loading: any;
    data: any;
    sendDefaultPasswordRequest: any;
    cancelAllPendingForgetPasswordRequests: any;
}


class ForgetPassword extends Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = { username: "" }
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    t = this.props.t;
    handleSubmit(event, values) {
        console.log("values", values);

        this.props.forgetPasswordVerifyUserRequest(values.username.trim());
    }
    componentDidMount() {
        this.props.setResetForForgetPassword();
    }
    componentDidUpdate() {
        if (this.props?.sendDefaultPasswordStatus) {
            this.setinterval = setTimeout(() => {
                this.props?.history.push('/');
            }, 5000)
        }
    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForForgetPassword();
    }
    cancelSendDefaultPassword = () => {
        this.props.cancelSendDefaultPassword()
    }

    render() {
        console.log("props==>", this.props);

        return (
            <React.Fragment>

                <Row className="loginBg">
                    <Col lg="4" md="4" sm="12" xs="12" className="LoginLft">

                        <div className="login-logo">
                            <img src={logo} alt="" />
                        </div>

                        <div className="lftCaption">
                            <div className="arrow-right-light"></div>
                            <h1>We are here!</h1>
                            <h3>to create a smooth waiting process</h3>
                        </div>
                    </Col>

                    <Col lg="8" md="8" sm="12" xs="12" className="LoginForgtRgt" style={{ flexDirection: "column" }}>
                        <Row className="pt-4 px-2 logoBackheader">
                            <Col className="bcktoLogin pl-4" onClick={() => this.props?.history.push('/')}>
                                <div className="pointer" >
                                    <span className="mr-3">
                                        Back To Login
                                    </span>
                                    <img src={BackToLogin} alt="" />
                                </div>
                            </Col>
                            <Col className="text-right pr-4"><img src={clientLogo} alt="logo" width="160" /></Col>

                        </Row>
                        <Row className="w100 h-100 justify-content-md-center align-center">
                            <div className="wrapper-page">
                                <div className="overflow-hidden account-card mx-3 mb-0">
                                    <div className="account-card-content">
                                        <div className="arrow-right-dark"></div>
                                        <h1>We are here to <br />help you!</h1>

                                        {this.props.errorMessage && <Alert color={(this.props?.sendDefaultPasswordStatus) ? "success" : "danger"}>
                                            {this.t(this.props.errorMessage?.transKey + this.props.errorMessage?.message) === this.props.errorMessage?.transKey + this.props.errorMessage?.message ? this.props.errorMessage?.message : this.t(this.props.errorMessage?.transKey + this.props.errorMessage?.message)
                                            }</Alert>}

                                        {!(this.props?.data) && <AvForm className="form-horizontal m-t-30 w-80" onValidSubmit={this.handleSubmit} >
                                            <div>
                                                <AvField name="username" label="Username" value={this.state.username} placeholder="Enter your name…" type="text" required />
                                                <br />
                                                <Button color="primary" disabled={this.props.loading} className="w-md waves-effect waves-light" type="submit">Verify</Button>

                                            </div>
                                        </AvForm>}
                                        {!(this.props?.sendDefaultPasswordStatus) && (this.props?.data && this.props.data.status) && <Formik
                                            enableReinitialize
                                            initialValues={{
                                                emailId: ICheckedEnums.NCHECKED,
                                                mobileNo: ICheckedEnums.NUNCHECKED,
                                            }}
                                            onSubmit={(values) => {

                                                let sendDefaultPassword = {
                                                    isSendEmail: values.emailId,
                                                    isSendSms: values.mobileNo,
                                                    userId: this.props?.data?.userDto?.userId
                                                } as any
                                                console.log("Values =>", values, sendDefaultPassword);
                                                this.props.sendDefaultPasswordRequest(sendDefaultPassword)

                                            }}
                                        >
                                            {({ values, setFieldValue }) => (
                                                <Form>
                                                    <div>
                                                        <strong>How do you want to send your password ?</strong>
                                                        <div style={{ marginTop: "8px" }}>
                                                            <em>
                                                                <FormGroup className="custom-control custom-checkbox align-vertical mb-1">
                                                                    <input type="checkbox" name="emailId" id="emailId"
                                                                        checked={values.emailId === ICheckedEnums.NCHECKED}
                                                                        className="custom-control-input" disabled={true}
                                                                    />
                                                                    <label className="custom-control-label" htmlFor="emailId" >"Through your email id&nbsp;
                                                                    {this.props?.data?.userDto?.emailId ? this.props?.data?.userDto?.emailId.replace(/(.{2})(.*)(?=@)/,
                                                                        function (gp1, gp2, gp3) {
                                                                            for (let i = 0; i < gp3.length; i++) {
                                                                                gp2 += "*";
                                                                            } return gp2;
                                                                        }) : this.props?.data?.userDto?.emailId}" </label>
                                                                </FormGroup>
                                                                <FormGroup className="custom-control custom-checkbox align-vertical mb-2">
                                                                    <input type="checkbox" name="mobileNo" id="mobileNo"
                                                                        checked={values.mobileNo === ICheckedEnums.NCHECKED} disabled={this.props.loading}
                                                                        className="custom-control-input"
                                                                        onChange={(e) => {
                                                                            if (e.target.checked)
                                                                                setFieldValue('mobileNo', ICheckedEnums.NCHECKED);
                                                                            else
                                                                                setFieldValue('mobileNo', ICheckedEnums.NUNCHECKED);
                                                                        }}
                                                                    />
                                                                    <label className="custom-control-label" htmlFor="mobileNo" >
                                                                        "Through your Moble Number&nbsp;
                                                                        {(this.props?.data?.userDto?.contactNo).substring(0, 4) + (this.props?.data?.userDto?.contactNo).substring(4, this.props?.data?.userDto?.contactNo?.length).replace(/\d/gm, '*')}"</label>                                                                </FormGroup>

                                                            </em>
                                                        </div>
                                                        <br />
                                                        <Row className="form-group mb-0">
                                                            <Col md="12">
                                                                <>
                                                                    <Button color="primary" className="w-md waves-effect waves-light" disabled={this.props?.loading} type="submit">Send</Button>
                                                                    <Button className="w-md waves-effect waves-light btn-cancel ml-3" disabled={this.props?.loading} onClick={this.cancelSendDefaultPassword}>Cancel</Button>
                                                                </>
                                                            </Col>
                                                        </Row>
                                                    </div>

                                                </Form>
                                            )}
                                        </Formik>}
                                    </div>
                                </div>
                            </div>
                        </Row>

                    </Col>
                </Row>

            </React.Fragment>
        );
    }
}



const mapStatetoProps = state => {
    console.log("mapStatetoProps==>", state);
    const data = state?.forgetpwd?.data;
    const errorMessage = state?.forgetpwd?.errorMessage;
    const loading = state?.forgetpwd?.loading;
    const sendDefaultPasswordStatus = state?.forgetpwd?.sendDefaultPasswordStatus
    return { data, errorMessage, loading, sendDefaultPasswordStatus };
}

export default withRouter(withTranslation("translations")(connect(mapStatetoProps, { forgetPasswordVerifyUserRequest, sendDefaultPasswordRequest, setResetForForgetPassword, cancelSendDefaultPassword })(ForgetPassword)));




