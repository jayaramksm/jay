import React, { Component } from 'react';
import { Alert, Button, Col, Row } from 'reactstrap';
import { Link, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { checkLogin } from '../../store/actions';
import { AvForm, AvField } from 'availity-reactstrap-validation';
//import logoIcon from '../../images/qsmarticon.png';
//import logo from "../../images/SSMC_logo.svg";
import logo from "../../images/firstpasslogo.svg";
import { isTokenIsAvailble } from '../../helpers/helpersIndex';
import { logOutRequest } from '../../store/actions';
import { ILogoutTypes } from '../../models/utilitiesModel';
import clientLogo from '../../images/vmcare.svg';

class Pageslogin extends Component {

    constructor(props) {
        super(props);
        this.state = { username: "", password: "" }
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    componentDidMount() {
        if (isTokenIsAvailble())
            this.props.logOutRequest(this.props.history, undefined, ILogoutTypes.RELOGIN);
    }

    handleSubmit(event, values) {
        this.props.checkLogin(values.username, values.password, this.props.history);
    }

    render() {

        return (
            <React.Fragment>

                <Row className="loginBg">

                    <Col lg="4" md="4" sm="12" xs="12" className="LoginLft">

                        <div className="login-logo">
                            <img src={logo} alt="" />
                        </div>
                        <div className="lftCaption">
                            <div className="arrow-right-light"></div>
                            <h1>We are here!</h1>
                            <h3>to create a smooth waiting process</h3>
                        </div>
                    </Col>

                    <Col lg="8" md="8" sm="12" xs="12" className="LoginRgt">
                        <img src={clientLogo} alt="logo" className="loginClientLogo" />
                        <Row className="w100 justify-content-md-center">


                            <div className="wrapper-page">

                                <div className="overflow-hidden account-card mx-3 mb-0">



                                    <div className="account-card-content">
                                        <div className="arrow-right-dark"></div>
                                        <h1>Welcome<br />
                                             back to Login!</h1>

                                        {this.props.user && <Alert color="success">
                                            Your Login is successfull.</Alert>}

                                        {this.props.loginError && <Alert color="danger">
                                            {this.props.loginError}</Alert>}

                                        <AvForm className="form-horizontal" onValidSubmit={this.handleSubmit} >
                                            <AvField name="username" label="Username / Emp ID" value={this.state.username} placeholder="Enter your name…" type="text" required />
                                            <AvField name="password" label="Password" value={this.state.password} placeholder="Enter your password…" type="password" required />

                                            <div className="form-group">
                                                <div className="text-right">
                                                    <small> <Link to="/forget-password">Forgot Password? </Link></small>
                                                </div>
                                                <div >
                                                    <Button color="primary" disabled={this.props.loading} className="w-md waves-effect waves-light" type="submit">Login</Button>
                                                </div>
                                            </div>




                                        </AvForm>
                                    </div>


                                </div>



                            </div>
                        </Row>

                    </Col>
                </Row>

            </React.Fragment>
        );
    }
}

const mapStatetoProps = state => {
    console.log('state=>', state);

    const { user, loginError, loading } = state.Login ? state.Login : { user: null, loginError: null, loading: null };
    return { user, loginError, loading };
}

export default withRouter(connect(mapStatetoProps, { checkLogin, logOutRequest })(Pageslogin));



