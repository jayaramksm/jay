import React, { Component } from 'react';
import { Button, Col, Row, Alert, FormGroup } from 'reactstrap';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import logo from "../../images/firstpasslogo.svg";
import clientLogo from '../../images/vmcare.svg';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { customContentValidation, coustmizePasswordPattern } from '../../helpers/helpersIndex';
import { Label } from 'reactstrap';
import { withTranslation } from 'react-i18next';
import { IPasswordPolicy } from '../../models/globalSettingsModel';
import { getGBPasswordPolicyDataRequest, changeUserProfilePasswordRequest, activateNonAuthLayout } from '../../store/actions';

export interface IProps {
    getGBPasswordPolicyDataRequest: any;
    t: any;
    history: any;
    password: any;
    passwordPolicyData: IPasswordPolicy;
    changeUserProfilePasswordRequest: any;
    activateNonAuthLayout: any;
    loading: any;
    errorMessage: any;
    cancelAllPendingUserProfileChangePasswordsRequests: any
}
class DefaultChangePassword extends Component<IProps, any> {

    constructor(props) {
        super(props);
        this.state = { newPassword: "", confirmPassword: "" }
    }
    t = this.props.t;

    componentDidMount() {
        this.props.activateNonAuthLayout();
        this.props.getGBPasswordPolicyDataRequest(true);
        console.log("DEfaultChangePassword=>", this.props);
    }
    // componentWillUnmount() {
    //     // this.props.cancelAllPendingUserProfileChangePasswordsRequests();
    // }
    render() {

        return (
            <React.Fragment>

                <Row className="loginBg">

                    <Col lg="4" md="4" sm="12" xs="12" className="LoginLft">
                        <div className="login-logo">
                            <img src={logo} alt="" />
                        </div>
                        <div className="lftCaption">
                            <div className="arrow-right-light"></div>
                            <h1>We are here!</h1>
                            <h3>to create a smooth waiting process</h3>
                        </div>

                    </Col>

                    <Col lg="8" md="8" sm="12" xs="12" className="LoginRgt">
                        <img src={clientLogo} alt="logo" className="loginClientLogo" />
                        <Row className="w100 justify-content-md-center">
                            <div className="wrapper-page">
                                <div className="overflow-hidden account-card mx-3 mb-0">

                                    <div className="account-card-content">
                                        <div className="arrow-right-dark"></div>
                                        <h1>We are here to<br />
                                        help you </h1>
                                        {this.props.errorMessage && <Alert color="danger">
                                            {this.t(this.props.errorMessage?.transKey + this.props.errorMessage?.message) === this.props.errorMessage?.transKey + this.props.errorMessage?.message ? this.props.errorMessage?.message : this.t(this.props.errorMessage?.transKey + this.props.errorMessage?.message)
                                            }</Alert>}
                                        <Formik
                                            enableReinitialize
                                            initialValues={{
                                                currentPassword: this.props?.password ? this.props?.password : '',
                                                newPassword: '',
                                                confirmPassword: ''
                                            }}
                                            validationSchema={Yup.object().shape({
                                                newPassword: coustmizePasswordPattern(this.t, this.t('controleErrors.required'), {
                                                    patternType: 'alphanumricwithoutspaceandallspecial', message: '#invalid#', spacialChar: null,
                                                    replaceData: [
                                                        { replaceKey: '{lowerChar}', replaceValue: this.props.passwordPolicyData.noOfLowerCaseLetters + '' },
                                                        { replaceKey: '{capsChar}', replaceValue: this.props.passwordPolicyData.noOfUpperCaseLetters + '' },
                                                        { replaceKey: '{alphabetics}', replaceValue: this.props.passwordPolicyData.numberOfAlphabets + '' },
                                                        { replaceKey: '{numeric}', replaceValue: this.props.passwordPolicyData.numberOfNumerical + '' },
                                                        { replaceKey: '{special}', replaceValue: this.props.passwordPolicyData.specialCharactersAllowed }
                                                    ]
                                                }, this.props.passwordPolicyData.maximumLength, this.props.passwordPolicyData.minimumLength),
                                                confirmPassword: Yup.string().required(this.t('controleErrors.required')).when("newPassword", {
                                                    is: val => (val && val.length > 0 ? true : false),
                                                    then: Yup.string().oneOf(
                                                        [Yup.ref("newPassword")],
                                                        this.t('UserProfileManagement.passwordMismatch')
                                                    ),
                                                    otherWise: customContentValidation(this.t, this.t('controleErrors.required'))
                                                })
                                            })}
                                            onSubmit={(values, { resetForm }) => {
                                                console.log('Values => ', values);
                                                let requestData = {
                                                    currentPassword: values.currentPassword,
                                                    newPassword: values.newPassword,
                                                }
                                                this.props.changeUserProfilePasswordRequest(requestData, this.props.history, true);

                                            }}
                                        >
                                            {({ errors, touched, dirty, setValues, setTouched }) => (
                                                <Form>

                                                    <FormGroup>
                                                        <Label htmlFor="example-text-input1">{this.t('UserProfileManagement.newPassword')}</Label>
                                                        <Field type='password' disabled={this.props.loading} name="newPassword" onPaste={e => e.preventDefault()} placeholder={this.t('UserProfileManagement.newPassword')} className={'form-control ' + (errors.newPassword && touched.newPassword ? 'is-invalid' : '')} />
                                                        {/* <ErrorMessage name="newPassword" component="div" className="invalid-feedback" /> */}
                                                        {errors.newPassword && touched.newPassword && (
                                                            <div className="error-msg">
                                                                {errors.newPassword !== '#invalid#' && <span>{errors.newPassword}</span>}
                                                                {errors.newPassword === '#invalid#' && <>
                                                                    {this.props.passwordPolicyData?.noOfUpperCaseLetters > 0 && <div>{(this.t('UserProfileManagement.passwordPatternUpper').replace('{number}', this.props.passwordPolicyData.noOfUpperCaseLetters + ''))}</div>}
                                                                    {this.props.passwordPolicyData?.noOfLowerCaseLetters > 0 && <div>{(this.t('UserProfileManagement.passwordPatternLower').replace('{number}', this.props.passwordPolicyData.noOfLowerCaseLetters + ''))}</div>}
                                                                    {this.props.passwordPolicyData?.numberOfAlphabets > 0 && <div>{(this.t('UserProfileManagement.passwordPatternAlphabetics').replace('{number}', this.props.passwordPolicyData.numberOfAlphabets + ''))}</div>}
                                                                    {this.props.passwordPolicyData?.numberOfNumerical > 0 && <div>{(this.t('UserProfileManagement.passwordPatternNumerics').replace('{number}', this.props.passwordPolicyData.numberOfNumerical + ''))}</div>}
                                                                    {this.props.passwordPolicyData?.specialCharactersAllowed !== '' && <div>{(this.t('UserProfileManagement.passwordPatternSpecial').replace('{special}', this.props.passwordPolicyData.specialCharactersAllowed + ''))}</div>}
                                                                    {!(this.props.passwordPolicyData?.specialCharactersAllowed !== '') && <div>{this.t('UserProfileManagement.notAllowedSpecials')}</div>}
                                                                </>}
                                                            </div>
                                                        )}
                                                    </FormGroup>

                                                    <FormGroup>
                                                        <Label htmlFor="example-text-input2">{this.t('UserProfileManagement.retypenewPassword')}</Label>
                                                        <Field type='password' disabled={this.props.loading} name="confirmPassword" onPaste={e => e.preventDefault()} placeholder={this.t('UserProfileManagement.retypenewPassword')} className={'form-control ' + (errors.confirmPassword && touched.confirmPassword ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="confirmPassword" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                    <div className="form-group mt-5">
                                                        <Button color="primary" disabled={!(dirty) || this.props.loading} className="w-md waves-effect waves-light" type="submit">Change Password</Button>
                                                    </div>
                                                </Form>
                                            )}
                                        </Formik>
                                    </div>
                                </div>

                            </div>
                        </Row>

                    </Col>
                </Row>

            </React.Fragment>
        );
    }
}

const mapStatetoProps = state => {
    const errorMessage = state?.userProfileManagementReducer?.errorMessage;
    const loading = state?.userProfileManagementReducer?.loading;
    console.log("mapStatetoProps_changePassword =>", state, state?.globalSettingsReducer?.passwordPolicyData);
    const { password } = state?.SessionState?.isDefultPasswordAuth ? state?.SessionState?.isDefultPasswordAuth : { password: undefined };
    const passwordPolicyData: IPasswordPolicy = state?.globalSettingsReducer?.passwordPolicyData ? state?.globalSettingsReducer?.passwordPolicyData : { changePasswordatFirstLogin: false, maximumLength: 8, minimumLength: 6, noOfUpperCaseLetters: 1, noOfLowerCaseLetters: 1, numberOfNumerical: 1, numberOfAlphabets: 0, specialCharactersAllowed: '`~!@#$%^&*()_-+=|\\}{][";:/?.>,<' + "'", passwordValidityPeriod: 90 } as IPasswordPolicy;
    return { password, passwordPolicyData, errorMessage, loading };
}

export default withRouter(withTranslation("translations")(connect(mapStatetoProps, { changeUserProfilePasswordRequest, getGBPasswordPolicyDataRequest, activateNonAuthLayout })(DefaultChangePassword)));



