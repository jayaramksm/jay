import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, UncontrolledTooltip } from 'reactstrap';
import { ParentContext } from '../Container/rolespriviligescontextApi';
import { useTranslation } from 'react-i18next';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IRolesPriviligesModel } from '../../../models/rolespriviligesModel';
import { setRoleSearchKey, setRoleActionRequestData } from '../../../store/actions';

const RoleFilter: React.FC = () => {
    const context: any = useContext(ParentContext);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const actionArea = useSelector(state => {
        if (state && state.rolesPriviligesReducer)
            return (state.rolesPriviligesReducer as IRolesPriviligesModel).actionType === IOprationalActions.ADD;
        else return false;
    });

    const filterActions = useSelector(state => {
        if (state && state.rolesPriviligesReducer && state.rolesPriviligesReducer.rolesData)
            return (state.rolesPriviligesReducer as IRolesPriviligesModel).rolesData.length > 0;
        else return false;
    });

    const addRole = () => {
        if (actionArea !== IOprationalActions.ADD)
            dispatch(setRoleActionRequestData(IOprationalActions.ADD, null, false));
    }
    const setSearch = (key) => {
        dispatch(setRoleSearchKey(key));
    }
    return (
        <>
            <Row className="roleslist">
                <Col className="pr-0"><h6 className="m-0">
                    {t('RolesPriviliges.listOfRoles')}</h6>
                </Col>
                {context.add && <div className="align-right pl-2 pr-3 addupload">
                    <button className="btn btn-out-dashed" id="add" disabled={actionArea} onClick={addRole}>{t('RolesPriviliges.add')} &nbsp;<span className="addbtn">+</span></button>
                    {!actionArea && <UncontrolledTooltip color="primary" placement="right" target="add">
                        {t('RolesPriviliges.addrole')}
                    </UncontrolledTooltip>}
                </div>}
            </Row>

            {filterActions &&
                <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                    <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={e => setSearch(e.target.value)} />
                    <i className="fa fa-search"></i>
                </div>}
        </>
    )
}
export default RoleFilter;