import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../Container/roles&privillages.css';
import { useTranslation } from 'react-i18next';
import { Col, Row, Card, CardBody, FormGroup, Label } from 'reactstrap';
import { Formik, Field, Form, ErrorMessage, FieldArray } from 'formik';
import { controleContentValidate, customContentValidation, MySelect } from '../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { IRolesPriviligesModel, IRole, IModuleDefaultPage, IDefaultPermissions, IPrivilege, IRoleType, IBranchType } from '../../../models/rolespriviligesModel';
import { IOprationalActions, IRoleTypeEnum } from '../../../models/utilitiesModel';
import { roleSuspendOrEditAction, getRoleDefaultPermissionsRequest, createOrEditRoleRequest, suspendRoleDefaultPermissions } from '../../../store/actions';
import * as _ from 'lodash';

export interface optionsData {
    value: any;
    label: any;
}

let isBranchRequried: boolean = false;
let isModifiedPriviliges: boolean = true;
const RoleAction: React.FC = () => {

    useEffect(() => {

        return () => {
            isBranchRequried = false;
            isModifiedPriviliges = true;
        }
    }, []);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const roleActionData = useSelector(state => {
        if ((state.rolesPriviligesReducer))
            return (state.rolesPriviligesReducer as IRolesPriviligesModel).actionData
        else
            return undefined
    }) as IRole;

    const roleTypes: IRoleType[] = useSelector(state => {
        if (state.rolesPriviligesReducer && state.rolesPriviligesReducer.roleTypesData)
            return state.rolesPriviligesReducer.roleTypesData;
        else return [];
    });

    const branchTypes: IBranchType[] = useSelector(state => {
        if (state.rolesPriviligesReducer && state.rolesPriviligesReducer.branchTypesData)
            return state.rolesPriviligesReducer.branchTypesData;
        else return [];
    });

    console.log("RoleAction_Types =>", roleTypes, branchTypes);

    const actionType = useSelector(state => {
        if (state && state.rolesPriviligesReducer)
            return state.rolesPriviligesReducer.actionType;
        else return undefined;
    });

    let defaultPermissionsData: IModuleDefaultPage[] = useSelector(state => {
        if (state && state.rolesPriviligesReducer && state.rolesPriviligesReducer.defaultPermissions)
            return (state.rolesPriviligesReducer.defaultPermissions as IDefaultPermissions).masterPermissionsData;
        else return undefined;
    });
    const maxMrivilegesLength = _.max(_.max(_.map(defaultPermissionsData, function (module) {
        return _.map(module.subModules, function (subModules) {
            return subModules.privileges.length
        });
    })));
    console.log("defaultPermissionsData =>", defaultPermissionsData);

    const roleTypeSelection = (e, setFieldValue, values) => {
        if (!_.isEqual(e, values.roleType)) {
            setFieldValue('roleType', e);
            setFieldValue('branchType', '');
            setFieldValue('permissions', []);
            if (e.value.roleTypeCode === IRoleTypeEnum.ADMIN) {
                isBranchRequried = false;
                dispatch(getRoleDefaultPermissionsRequest(e.value.roleTypeId, 0));
            } else {
                isBranchRequried = true;
                dispatch(suspendRoleDefaultPermissions());
                if (branchTypes.length === 1) {
                    let singleBranch = { value: branchTypes[0].branchTypeId, label: branchTypes[0].branchTypeDisplay };
                    setFieldValue('branchType', singleBranch);
                    dispatch(getRoleDefaultPermissionsRequest(e.value.roleTypeId, singleBranch.value));

                }
            }
        }
    }
    const branchTypeSelection = (value, setFieldValue, roleTypeValue) => {
        console.log("branchTypeSelection =>", value, roleTypeValue.branchType);
        if (!_.isEqual(value, roleTypeValue.branchType)) {
            setFieldValue('branchType', value);
            setFieldValue('permissions', []);
            dispatch(getRoleDefaultPermissionsRequest(roleTypeValue.roleType.value.roleTypeId, value.value));
        }
    }

    const cancelEditFunction = () => {
        dispatch(roleSuspendOrEditAction(actionType === IOprationalActions.EDIT ? IOprationalActions.SELECT : 0));
    }

    const setSubModulePermissions = (value, setFieldvalue, permissionsData, permissionId, priviliges) => {
        console.log("setSubModulePermissions =>", value, setFieldvalue, permissionsData, permissionId, priviliges);
        let pData = permissionsData as number[];
        let priviligesData = priviliges as IPrivilege[];
        if (value) {
            let index = pData.findIndex(x => x === permissionId);
            if (index === -1) {
                pData.push(permissionId);
                setFieldvalue('permissions', pData);
            }
        }
        else {
            let index = pData.findIndex(x => x === permissionId);
            if (index !== -1) {
                pData.splice(index, 1);
            }
            for (let i = 0; i < priviligesData.length; i++) {
                let index1 = pData.findIndex(x => x === priviligesData[i].permissionId);
                if (index1 !== -1) {
                    pData.splice(index1, 1);
                }
            }
            setFieldvalue('permissions', pData);

        }
        if (roleActionData) {
            if (roleActionData.permissions.length === pData.length)
                isModifiedPriviliges = roleActionData.permissions.every(x => pData.includes(x));
            else
                isModifiedPriviliges = false;
        }
    }

    const actionCheckAll = (value, setFieldvalue, permissions, privilige) => {
        let privilgesData = privilige as IPrivilege[];
        let pData = permissions as number[];
        if (value) {
            for (let i = 0; i < privilgesData.length; i++) {
                let index = pData.findIndex(x => x === privilgesData[i].permissionId);
                if (index === -1) {
                    pData.push(privilgesData[i].permissionId);
                }
            }
        }
        else {
            for (let i = 0; i < privilgesData.length; i++) {
                let index = pData.findIndex(x => x === privilgesData[i].permissionId);
                if (index !== -1) {
                    pData.splice(index, 1);
                }
            }
        }
        setFieldvalue('permissions', pData);
        if (roleActionData) {
            if (roleActionData.permissions.length === pData.length)
                isModifiedPriviliges = roleActionData.permissions.every(x => pData.includes(x));
            else
                isModifiedPriviliges = false;
        }
    }

    const allCheckedOrNot = (permissionsValue, priviliges) => {
        return priviliges.every(x => permissionsValue.includes(x.permissionId));
    }
    const actionCheck = (value, setFieldvalue, permissions, priviligeId) => {
        let pData = permissions as number[];
        if (value) {
            let index = pData.findIndex(x => x === priviligeId);
            if (index === -1) {
                pData.push(priviligeId);
                setFieldvalue('permissions', pData);
            }
        }
        else {
            let index = pData.findIndex(x => x === priviligeId);
            if (index !== -1) {
                pData.splice(index, 1);
                setFieldvalue('permissions', pData);
            }
        }
        if (roleActionData) {
            if (roleActionData.permissions.length === pData.length)
                isModifiedPriviliges = roleActionData.permissions.every(x => pData.includes(x));
            else
                isModifiedPriviliges = false;
        }
    }

    const patchRoleType = (roleTypeId) => {
        isBranchRequried = false;
        let index = roleTypes.findIndex(x => x.roleTypeId === roleTypeId);
        if (index !== -1) {
            if (roleTypes[index].roleTypeCode !== 'AD')
                isBranchRequried = true;
            return { value: roleTypes[index], label: roleTypes[index].roleType };
        }
        else return '';
    }
    const patchbranchType = (branchTypeId) => {

        let index = branchTypes.findIndex(x => x.branchTypeId === branchTypeId);
        return index !== -1 ? { value: branchTypes[index].branchTypeId, label: branchTypes[index].branchTypeDisplay } : '';
    }


    return (
        <>
            <Formik
                enableReinitialize
                initialValues={{
                    permissions: roleActionData ? [...roleActionData.permissions] : [],
                    roleId: roleActionData ? roleActionData.roleId : 0,
                    roleName: roleActionData ? roleActionData.roleName : '',
                    roleType: roleActionData ? patchRoleType(roleActionData.roleType) : '',
                    branchType: roleActionData ? patchbranchType(roleActionData.branchType) : ''
                }}
                validationSchema={Yup.object().shape({
                    roleName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
                    roleType: controleContentValidate(t('controleErrors.required')),
                    branchType: Yup.string()
                        .when('roleType', {
                            is: value => { return isBranchRequried },
                            then: controleContentValidate(t('controleErrors.required')),
                            otherwise: controleContentValidate(''),
                        })
                })}
                onSubmit={(values, { resetForm }) => {
                    console.log("Values =>", values, roleActionData);
                    let branchTypeId = values.branchType === '' ? 0 : (values.branchType as optionsData).value;
                    let roleTypeId = ((values.roleType as optionsData).value as IRoleType).roleTypeId;
                    let role = {
                        roleId: values.roleId,
                        roleName: values.roleName,
                        roleType: roleTypeId,
                        branchType: branchTypeId,
                        permissions: values.permissions
                    };
                    console.log("Dispatch_Action =>", actionType, role);
                    dispatch(createOrEditRoleRequest(actionType, role));
                }}
            >
                {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                    <Form className="h-100">
                        <div className="flexLayout">
                            <Card className="mb-3  flex-headerfix">
                                <CardBody >
                                    <Row>
                                        <Col sm="12">
                                            <Row>
                                                <Col sm="3">
                                                    <Row className="FormStyle">
                                                        <Col>
                                                            <FormGroup className="mb-0">
                                                                <Field name="roleName" placeholder={t('RolesPriviliges.roleName')}
                                                                    className={'form-control ' + (errors.roleName && touched.roleName ? 'is-invalid' : '')} />
                                                                <ErrorMessage name="roleName" component="div" className="invalid-feedback" />
                                                                <Label className="label" htmlFor="example-text-input">{t('RolesPriviliges.roleName')}</Label>
                                                            </FormGroup>
                                                        </Col>
                                                    </Row>
                                                </Col>
                                                <Col sm="3">
                                                    <FormGroup className="mb-0">
                                                        <Label>{t('RolesPriviliges.selectRoletype')}</Label>
                                                        <MySelect
                                                            name="roleType"
                                                            placeholder={t('RolesPriviliges.selectRoletype')}
                                                            value={values.roleType}
                                                            onChange={(e) => roleTypeSelection(e, setFieldValue, values)}
                                                            options={roleTypes.map(item => ({ value: item, label: item.roleType, }))}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            onBlur={() => setFieldTouched('roleType', true)}
                                                            isDisabled={actionType === IOprationalActions.EDIT}
                                                            noOptionsMessage={() => t('RolesPriviliges.noRoleTypes')}
                                                        />
                                                        {errors.roleType && touched.roleType && (
                                                            <div className="error-msg">{errors.roleType}
                                                            </div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                                {isBranchRequried && <Col sm="4">

                                                    <FormGroup className="mb-0">
                                                        <Label>{t('RolesPriviliges.selectBranchtype')}</Label>
                                                        <MySelect
                                                            name="branchType"
                                                            placeholder={t('RolesPriviliges.selectBranchtype')}
                                                            value={values.branchType}
                                                            onChange={(e) => branchTypeSelection(e, setFieldValue, values)}
                                                            options={branchTypes.map(item => ({ value: item.branchTypeId, label: item.branchTypeDisplay }))}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            onBlur={() => setFieldTouched('branchType', true)}
                                                            isDisabled={actionType === IOprationalActions.EDIT}
                                                            noOptionsMessage={() => t('RolesPriviliges.noBranchTypes')}
                                                        />
                                                        {errors.branchType && touched.branchType && (
                                                            <div className="error-msg">{errors.branchType}
                                                            </div>
                                                        )}
                                                    </FormGroup>

                                                </Col>}
                                            </Row>
                                            <hr />

                                            <Row>
                                                <Col className="action">
                                                    {actionType === IOprationalActions.ADD && <button type="submit" disabled={!(dirty) || values.permissions.length === 0} className="btn btn-primary"> {t('ActionNames.save')}</button>}
                                                    {actionType === IOprationalActions.EDIT && <button type="submit" disabled={!(dirty || !isModifiedPriviliges) || values.permissions.length === 0} className="btn btn-primary"> {t('ActionNames.update')} </button>}
                                                    <button type="button" className="btn btn-cancel ml-3" onClick={cancelEditFunction}>{t('ActionNames.cancel')}</button>
                                                </Col>
                                            </Row>

                                        </Col>
                                    </Row>


                                </CardBody>
                            </Card>

                                     {defaultPermissionsData && defaultPermissionsData.length > 0 && values.permissions.length === 0 && <span style={{ color: "#dc3545", marginTop: ".5rem" }}>Please select one (minimum) privilege to create the role {values.roleName}</span>}
                                    {defaultPermissionsData && defaultPermissionsData.length === 0 && <span>No Priviliges are Available...</span>}
                        <div className="flexLayout">
                            <Card className="flexLayout-inner roleprvlgs">
                                <CardBody className="p-0">
                                   
                                  
                                            {defaultPermissionsData && defaultPermissionsData.map((item, index) => {
                                                return (
                                                    <div className="rolesTable mt-2" style={{ width: "98%" }} key={index}>
                                                        <h6 className="roleHeader">{t('MenuItems.' + item.moduleName)}</h6>
                                                        <table className="table">
                                                            <tbody>
                                                                {item.subModules.map((sItem, ind) => {
                                                                    return (
                                                                        <FieldArray key={ind}
                                                                            name='permissions'
                                                                            render={arrayHelpers => (
                                                                                <tr key={ind}>
                                                                                    <td>
                                                                                        <div className="custom-control custom-checkbox align-vertical">
                                                                                            <input type="checkbox" name='permissions'
                                                                                                value={sItem.subModuleName}
                                                                                                checked={values.permissions.includes(sItem.readPermissionId)}
                                                                                                onChange={e => {
                                                                                                    setSubModulePermissions(e.target.checked, setFieldValue, values.permissions, sItem.readPermissionId, sItem.privileges)
                                                                                                }}
                                                                                                className="custom-control-input" id={sItem.subModuleName}
                                                                                            />
                                                                                            <label className="custom-control-label" htmlFor={sItem.subModuleName}>{t('MenuItems.' + sItem.subModuleName)} </label>
                                                                                        </div>
                                                                                    </td>
                                                                                    <FieldArray
                                                                                        name='permissions'
                                                                                        render={arrayHelpers => (
                                                                                            <>
                                                                                                {sItem.privileges.map((a, i) => {
                                                                                                    return (
                                                                                                        <td key={i}>
                                                                                                            <div className="custom-control custom-checkbox">
                                                                                                                <input type="checkbox"
                                                                                                                    className="custom-control-input" id={a.permission + index + ind + i}
                                                                                                                    value={a.permissionId}
                                                                                                                    disabled={!(values.permissions.includes(sItem.readPermissionId))}
                                                                                                                    checked={values.permissions.includes(a.permissionId)}
                                                                                                                    onChange={e => {
                                                                                                                        actionCheck(e.target.checked, setFieldValue, values.permissions, a.permissionId)
                                                                                                                    }}
                                                                                                                />
                                                                                                                <label className="custom-control-label" htmlFor={a.permission + index + ind + i}>{t('ActionNames.' + a.permission)}</label>
                                                                                                            </div>
                                                                                                        </td>
                                                                                                    )
                                                                                                })}
                                                                                                {(maxMrivilegesLength - sItem.privileges.length) > 0 && [...Array((maxMrivilegesLength - sItem.privileges.length))].map((page, i) => {
                                                                                                    return (
                                                                                                        <td key={i}>
                                                                                                            <div>
                                                                                                                {/* <label> 123 </label> */}
                                                                                                            </div>
                                                                                                        </td>
                                                                                                    )
                                                                                                })}
                                                                                            </>

                                                                                        )}
                                                                                    />
                                                                                    {sItem.privileges.length > 1 && <td>
                                                                                        <div className="custom-control custom-checkbox">
                                                                                            <input type="checkbox" name='permissions'
                                                                                                className="custom-control-input" id={sItem.subModuleName + 'all'}
                                                                                                disabled={!(values.permissions.includes(sItem.readPermissionId))}
                                                                                                checked={allCheckedOrNot(values.permissions, sItem.privileges)}
                                                                                                onChange={e => {
                                                                                                    actionCheckAll(e.target.checked, setFieldValue, values.permissions, sItem.privileges)
                                                                                                }}
                                                                                            />
                                                                                            <label className="custom-control-label" htmlFor={sItem.subModuleName + 'all'}>{t('ActionNames.all')}</label>
                                                                                        </div>
                                                                                    </td>}
                                                                                    {sItem.privileges.length === 1 && maxMrivilegesLength > 1 && <td>
                                                                                        <div>
                                                                                            {/* <label>1234</label> */}
                                                                                        </div>
                                                                                    </td>}
                                                                                </tr>
                                                                            )}
                                                                        />
                                                                    )
                                                                })}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                )
                                            })}
                                       
                                   
                                </CardBody>
                            </Card>
                        </div>
                        </div>
                    </Form>
                )}
            </Formik>
        </>
    )
}

export default RoleAction;