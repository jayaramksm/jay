import * as React from 'react';
import { Col, Row, Card, CardBody, Label, UncontrolledTooltip } from 'reactstrap';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { useContext } from 'react';
import { ParentContext } from '../Container/rolespriviligescontextApi';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import '../Container/roles&privillages.css';
import { IRole, IModuleDefaultPage, IDefaultPermissions, IRoleType, IBranchType, ISubModule, IPrivilege } from '../../../models/rolespriviligesModel';
import { roleSuspendOrEditAction, deleteRoleRequest } from '../../../store/actions';
import * as _ from 'lodash';

const RoleView: React.FC = () => {
    const { t } = useTranslation("translations");
    const context: any = useContext(ParentContext);
    console.log('context_new => ', context);
    const dispatch = useDispatch();

    const roleActionData: IRole = useSelector(state => {
        if (state && state.rolesPriviligesReducer && state.rolesPriviligesReducer.actionData)
            return state.rolesPriviligesReducer.actionData;
        else return undefined;
    });

    const roleTypes: IRoleType[] = useSelector(state => {
        if (state.rolesPriviligesReducer && state.rolesPriviligesReducer.roleTypesData)
            return state.rolesPriviligesReducer.roleTypesData;
        else return [];
    });

    const branchTypes: IBranchType[] = useSelector(state => {
        if (state.rolesPriviligesReducer && state.rolesPriviligesReducer.branchTypesData)
            return state.rolesPriviligesReducer.branchTypesData;
        else return [];
    });
    console.log("roleActionData =>", roleActionData, roleTypes, branchTypes);

    const masterPermissionsData: IModuleDefaultPage[] = useSelector(state => {
        if (state && state.rolesPriviligesReducer && state.rolesPriviligesReducer.defaultPermissions)
            return (state.rolesPriviligesReducer.defaultPermissions as IDefaultPermissions).masterPermissionsData;
        else return undefined;
    });
    console.log("masterPermissionsData =>", masterPermissionsData);
    const manageMasterData = (data: IModuleDefaultPage[]) => {
        console.log("manageMasterData =>", data, roleActionData);
        if (roleActionData && roleActionData.isCustomRole === 1) {
            let moduleData: IModuleDefaultPage[] = [];
            data.forEach(x => {
                let subModulesData: ISubModule[] = [];
                x.subModules.forEach(y => {
                    if (roleActionData.permissions.includes(y.readPermissionId)) {
                        let priviligesData: IPrivilege[] = [];
                        y.privileges.forEach(z => {
                            if (roleActionData.permissions.includes(z.permissionId)) {
                                priviligesData.push(z);
                            }
                        });
                        let subModule = {
                            branchType: y.branchType,
                            icon: y.icon,
                            link: y.link,
                            readPermissionId: y.readPermissionId,
                            sequenceNo: y.sequenceNo,
                            subModuleId: y.subModuleId,
                            subModuleName: y.subModuleName,
                            privileges: priviligesData
                        } as ISubModule;
                        subModulesData.push(subModule);
                    }
                });
                if (subModulesData.length > 0) {
                    let module = {
                        icon: x.icon,
                        link: x.link,
                        moduleId: x.moduleId,
                        moduleName: x.moduleName,
                        moduleType: x.moduleType,
                        sequenceNo: x.sequenceNo,
                        subModules: subModulesData
                    } as IModuleDefaultPage;
                    moduleData.push(module);
                }
            });
            return moduleData;
        }
        else {
            return data;
        }
    }
    const defaultPermissionsData: IModuleDefaultPage[] | undefined = roleActionData && masterPermissionsData ? manageMasterData(masterPermissionsData) : undefined;
    const maxMrivilegesLength = _.max(_.max(_.map(defaultPermissionsData, function (module) {
        return _.map(module.subModules, function (subModules) {
            return subModules.privileges.length
        });
    })));
    console.log("PermissionsData =>", defaultPermissionsData, maxMrivilegesLength, roleActionData);

    const editRole = () => {
        dispatch(roleSuspendOrEditAction(IOprationalActions.EDIT))
    }

    const deleteRole = (roleData: IRole) => {
        let message = t('RolesPriviliges.confirmMessages.RPC2').replace('{roleName}', roleData.roleName);
        dispatch(deleteRoleRequest(IOprationalActions.DELETE, roleData.roleId, message, false));
    }


    return (
        <>
        <div className="flexLayout">
            <Card className=" mb-3 flex-headerfix">
                <CardBody>
                    <Row className="FormStyle">
                        <Col>
                            <Label className="pt-2">{t('RolesPriviliges.roleName')}</Label> 
                            <h6>{roleActionData && roleActionData.roleName}</h6>
                        </Col>
                        {roleActionData && roleActionData.isCustomRole !== 0 && <Col>
                            <Label className="pt-2">{t('RolesPriviliges.roletype')}</Label> 
                            <h6>{roleTypes && roleTypes.find(x => x.roleTypeId === roleActionData.roleType)?.roleType}</h6>
                        </Col>}
                        {roleActionData && roleActionData.branchType !== 0 && <Col>
                            <Label className="pt-2">{t('RolesPriviliges.branchtype')}</Label> 
                            <h6>{branchTypes && branchTypes.find(x => x.branchTypeId === roleActionData.branchType)?.branchTypeDisplay}</h6>
                        </Col>}

                    </Row>
                    <hr className="mb-0" />

                    <Row>
                        <Col className="action">
                            {context.edit && roleActionData.isCustomRole !== 0 && <>
                                <i id="edit" className="ti-pencil-alt" onClick={() => editRole()}> </i>
                                <UncontrolledTooltip color="primary" placement="top" target="edit">
                                    {t('ActionNames.edit')}
                                </UncontrolledTooltip>
                            </>}
                            {context.delete && roleActionData.isCustomRole !== 0 && <>
                                <i id="delete" className="ti-trash" onClick={() => deleteRole(roleActionData)}></i>
                                <UncontrolledTooltip color="primary" placement="top" target="delete">
                                    {t('ActionNames.delete')}
                                </UncontrolledTooltip>
                            </>}
                        </Col>
                    </Row>


                </CardBody>
            </Card>
           
            
            <div className="flexLayout">
            <Card className="flexLayout-inner roleprvlgs">
                <CardBody className="p-0">
                  

                            {defaultPermissionsData && defaultPermissionsData.map((item, index) => {
                                return (
                                    <div className="rolesTable" style={{ width: "98%" }} key={index}>
                                        <h6 className="roleHeader">{t('MenuItems.' + item.moduleName)}</h6>

                                        <table className="table">
                                            <tbody>
                                                {item.subModules.map((sItem, ind) => {
                                                    return (
                                                        <tr key={ind}>
                                                            <td>
                                                                <div>
                                                                    <label> {t('MenuItems.' + sItem.subModuleName)} </label>
                                                                </div>
                                                            </td>
                                                            {sItem.privileges.map((a, i) => {
                                                                return (
                                                                    <td key={i}>
                                                                        <div>
                                                                            <label> {t('ActionNames.' + a.permission)} </label>
                                                                        </div>
                                                                    </td>
                                                                )
                                                            })}
                                                            {(maxMrivilegesLength - sItem.privileges.length) > 0 && [...Array((maxMrivilegesLength - sItem.privileges.length))].map((page, i) => {
                                                                return (
                                                                    <td key={i}>
                                                                        <div>
                                                                            {/* <label> 123 </label> */}
                                                                        </div>
                                                                    </td>
                                                                )
                                                            })}

                                                        </tr>
                                                    )
                                                })}
                                            </tbody>
                                        </table>

                                    </div>
                                )
                            })}

                
                </CardBody>
            </Card>
      </div>
      </div>
      
       </>
    );
}

export default RoleView;