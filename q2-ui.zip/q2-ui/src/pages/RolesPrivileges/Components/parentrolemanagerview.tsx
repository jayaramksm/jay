import React, { useContext } from 'react';
import { Card, CardBody } from 'reactstrap';
import { SuperParentContext, ParentContext } from '../Container/rolespriviligescontextApi';
import '../Container/roles&privillages.css';

const ParentRoleManagerView: React.FC = () => {
    const context: any = useContext(SuperParentContext);

    return (
        <>
            <Card className="lft-card flexLayout mb-0">
                <div className="flex-headerfix px-3 pt-3">
                <ParentContext.Provider value={context.actions}>
                        <context.filterComponent />
                    </ParentContext.Provider>
                </div>
                <CardBody>
                    <ParentContext.Provider value={{ viewComponent: context.viewComponent }}>
                        <context.listComponent />
                    </ParentContext.Provider>
                </CardBody>
            </Card>
        </>
    )
}
export default ParentRoleManagerView;