import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../Container/roles&privillages.css';
import { ChildContext } from '../Container/rolespriviligescontextApi';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IRole, IRolesPriviligesModel } from '../../../models/rolespriviligesModel';
import { roleSuspendOrEditAction, selectRoleActionDataRequest } from '../../../store/actions';

const RoleItem: React.FC = () => {

    const context: any = useContext(ChildContext);
    const dispatch = useDispatch();

    let roleData: IRole = useSelector(state => {
        if (state && state.rolesPriviligesReducer) {
            let data = state.rolesPriviligesReducer.rolesData as IRole[];
            let index = data.findIndex(x => x.roleId === context);
            if (index !== -1)
                return state.rolesPriviligesReducer.rolesData[index];
            else return undefined;
        }
        else return undefined;
    });
    console.log("RoleItem =>", roleData);
    const selectedRole = useSelector(state => {
        if (state && state.rolesPriviligesReducer) {
            return (state.rolesPriviligesReducer as IRolesPriviligesModel).actionData ?
                ((state.rolesPriviligesReducer as IRolesPriviligesModel).actionData as IRole).roleId === roleData.roleId : false;
        }
        else return false;
    })

    const selectRole = () => {
        dispatch(selectedRole ? roleSuspendOrEditAction(0) : selectRoleActionDataRequest(IOprationalActions.SELECT, roleData, false));
    }

    return (
        <>
                <span className={'btn btn-sm ' + (selectedRole ? 'activeList' : '')} onClick={selectRole} >
                    {roleData && roleData.roleName}
                </span>
        </>
    )
}

export default RoleItem;