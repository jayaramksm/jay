import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../Container/roles&privillages.css';
import { getRolesDataRequest } from '../../../store/actions';
import { IRolesPriviligesModel } from '../../../models/rolespriviligesModel';
import { useTranslation } from 'react-i18next';
import { UncontrolledTooltip } from 'reactstrap';
export const RolesPriviligesAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const refreshLoading = useSelector(state => {
        if (state && state.rolesPriviligesReducer)
            return (state.rolesPriviligesReducer as IRolesPriviligesModel).refreshLoading
        else
            return false;
    })

    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="RPtooltip" onClick={() => dispatch(getRolesDataRequest(true, true))}></i>
                <UncontrolledTooltip color="primary" placement="top" target="RPtooltip">
                    {t('ActionNames.autoRefresh')}
                </UncontrolledTooltip>
                </>
                }
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}