import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import '../Container/roles&privillages.css';
import { SuperParentContext, ParentContext } from '../Container/rolespriviligescontextApi';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IRolesPriviligesModel } from '../../../models/rolespriviligesModel';

const ParentRolePriviligeManager: React.FC = () => {

    const context: any = useContext(SuperParentContext);
    console.log("ParentRolePriviligeManager =>", context);
    const actionArea = useSelector(state => {
        if (state && state.rolesPriviligesReducer)
            return (state.rolesPriviligesReducer as IRolesPriviligesModel).actionType;
        else return undefined;
    });
    console.log("ParentRolePriviligeManager =>", actionArea);
    return (
        <>


            {(actionArea === IOprationalActions.ADD || actionArea === IOprationalActions.EDIT) && <context.actionComponent />}
            {actionArea === IOprationalActions.SELECT &&
                <ParentContext.Provider value={context.actions}>
                    <context.viewComponent />
                </ParentContext.Provider>
            }

           
           
        </>
    )
}
export default ParentRolePriviligeManager;