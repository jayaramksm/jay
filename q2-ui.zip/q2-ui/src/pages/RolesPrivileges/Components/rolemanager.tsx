import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import '../Container/roles&privillages.css';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { ChildContext, ParentContext } from '../Container/rolespriviligescontextApi';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { PaginationComponent } from '../../Utilities/PaginationComponent';
import { IRole } from '../../../models/rolespriviligesModel';

const RoleManager: React.FC = () => {
    const context = useContext<any>(ParentContext);
    const { t } = useTranslation("translations");
    const pageSize = getEnvironment.listPageSize;

    const rolesData: IRole[] = useSelector(state => {
        if (state && state.rolesPriviligesReducer && state.rolesPriviligesReducer.rolesData) {
            let data = state.rolesPriviligesReducer.rolesData;
            return data;
        }
        else return undefined;
    });
    const searchKey = useSelector(state => {
        if (state && state.rolesPriviligesReducer && state.rolesPriviligesReducer.rolesData) {
            if (state.rolesPriviligesReducer.searchKey)
                return state.rolesPriviligesReducer.searchKey;
            else
                return ''
        }
        else
            return ''
    });

    const filterRoleData: IRole[] = (searchKey && searchKey !== '') && rolesData ?
        rolesData.filter(x => x.roleName.toLowerCase().startsWith(searchKey.toLowerCase())) : rolesData;

    let roleCount = useSelector(state => {
        if (state && state.rolesPriviligesReducer && state.rolesPriviligesReducer.rolesData)
            return state.rolesPriviligesReducer.rolesData.length;
        else return 0;
    });
    console.log("roleCount =>", roleCount);

    let pagesCount = Math.ceil((filterRoleData ? filterRoleData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }


    return (
        <><div className="flexLayout">
            {filterRoleData && filterRoleData.length === 0 && searchKey && <span className="recdnotfound">{t('RolesPriviliges.noResFound')}</span>}
            {filterRoleData && filterRoleData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('RolesPriviliges.norolesfound')}</span>}
            <div className="flexLayout-inner layou1rgtColmn">
                <Row>
                    <Col sm="12" className="actn-list">
                        {filterRoleData && filterRoleData.length > 0 && filterRoleData.slice(currentPage * pageSize,
                            (currentPage + 1) * pageSize).map((item, index) => (
                                <ChildContext.Provider key={index} value={item.roleId}>
                                    <context.viewComponent />
                                </ChildContext.Provider>
                            ))}
                    </Col>
                </Row>
            </div>
            <Row className="lft-pagination">
                {filterRoleData && filterRoleData.length > pageSize &&
                    <div className="pagination ml-4">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                }
            </Row>
        </div>

        </>
    )
}
export default RoleManager;