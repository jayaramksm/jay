import * as React from 'react';
import { activateAuthLayout } from '../../../store/actions';
import { connect } from 'react-redux';
import { Col, Row, Container } from 'reactstrap';
import './roles&privillages.css';
import { getRolesDataRequest, setResetForRolePriviliges, cancelAllPendingRoleRequests } from '../../../store/actions';
import { SuperParentContext } from './rolespriviligescontextApi';
import {
    ParentRoleManagerView, RoleFilter, RoleManager, RoleItem,
    ParentRolePriviligeManager, RoleAction, RoleView, RolesPriviligesAutoRefresh
} from './rolespriviligesindex';
import { IRolesPriviligesModel } from '../../../models/rolespriviligesModel';
import { IActions } from '../../../models/utilitiesModel';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../helpers/helpersIndex';

export interface IProps {
    activateAuthLayout: any;
    getRolesDataRequest: any;
    setResetForRolePriviliges: any;
    rolePriviligeLoad: boolean;
    cancelAllPendingRoleRequests: any;
    add: boolean;
    edit: boolean;
    delete: boolean;
}

class RoleandPrivilages extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props)
        this.state = {
            leftRoleParent: {
                filterComponent: RoleFilter,
                listComponent: RoleManager,
                viewComponent: RoleItem,
                actions: { add: this.props.add }
            },
            rightRolePriviligeParent: {
                viewComponent: RoleView,
                actionComponent: RoleAction,
                actions: { edit: this.props.edit, delete: this.props.delete }
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForRolePriviliges();
        if (this.props.rolePriviligeLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getRolesDataRequest(!this.props.rolePriviligeLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getRolesDataRequest(!this.props.rolePriviligeLoad, true);
    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.cancelAllPendingRoleRequests();
        this.props.setResetForRolePriviliges();
    }



    render() {

        return (
            <>
                {getAutoRefresing() && <RolesPriviligesAutoRefresh />}
                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftRoleParent}>
                                <ParentRoleManagerView />
                            </SuperParentContext.Provider>
                        </Col>
                        <Col sm="8" className="h-100">
                            <SuperParentContext.Provider value={this.state.rightRolePriviligeParent}>
                                <ParentRolePriviligeManager />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>
            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'rolesprivilages', defaultPrivilages);
    if (getAutoRefresing() && state.rolesPriviligesReducer && (state.rolesPriviligesReducer as IRolesPriviligesModel).rolesData)
        return {
            rolePriviligeLoad: ((state.rolesPriviligesReducer as IRolesPriviligesModel).rolesData?.length > 0 ? true : false),
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
    else
        return {
            rolePriviligeLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
}
export default connect(mapStatetoProps, { activateAuthLayout, getRolesDataRequest, setResetForRolePriviliges, cancelAllPendingRoleRequests })(RoleandPrivilages);
