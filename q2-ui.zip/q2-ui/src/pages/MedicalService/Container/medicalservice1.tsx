import * as React from 'react';
import { activateAuthLayout } from '../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Col, Row, Card, CardBody, Modal, ModalBody, FormGroup, Label, Input, UncontrolledTooltip } from 'reactstrap';
import { PaginationComponent } from 'pages/Utilities/PaginationComponent';
import './medicalservice.css';
import DualListBox from 'react-dual-listbox';
import help from '../../../images/icons/help.svg';
import uploadlogo from '../../../images/upload.svg';

let pagesCount = 5;
const pageSize = 8;
const options = [
    { value: '1', label: 'Resource Type -1' },
    { value: '2', label: 'Resource Type -2' },
    { value: '3', label: 'Resource Type -3' },
    { value: '4', label: 'Resource Type -4' },
    { value: '5', label: 'Resource Type -5' },
    { value: '6', label: 'Resource Type -6' },
    { value: '7', label: 'Resource Type -7' },
    { value: '8', label: 'Resource Type -8' },
];


class MedicalService1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        this.state = {
            modal_large: false, currentPage: 0, add_Bulk: false,
            selected: ['2', '7', '5'], service_TypeCreate: false, modal_center: false
        };
        this.tog_large = this.tog_large.bind(this);
        this.addBulk = this.addBulk.bind(this);
        this.serviceType = this.serviceType.bind(this);
        this.tog_center = this.tog_center.bind(this);
    }

    componentDidMount() {
        this.props.activateAuthLayout();

    }
    tog_large() {
        this.setState({ modal_large: !this.state.modal_large });
    }

    handleClick = (e, index) => {
        e.preventDefault();
        this.setState({ currentPage: index })
    }

    addBulk() {
        this.setState({ add_Bulk: !this.state.add_Bulk })
    }

    serviceType() {
        this.setState({ service_TypeCreate: !this.state.service_TypeCreate, modal_center: false });
    }
    tog_center() {
        this.setState({ modal_center: !this.state.modal_center });
    }
    render() {
        return (
            <>
                <Container fluid>
                    <Row>
                        <Col sm="4">
                            <Card className="mb-3">
                                <CardBody>
                                    <Row>
                                        <Col sm="6" className="align-center pr-0">
                                            <span className="locate">Riyadh / الاسم العربي</span>
                                        </Col>
                                        <Col sm="6" className="align-right pr-1">
                                            <div>
                                                <button className="locbtn px-2 py-1" onClick={this.tog_large}>Change Location &nbsp;<i className="ti-angle-down"></i></button>
                                            </div>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>

                            <Card className="lft-card">
                                <CardBody>
                                    <Row className="roleslist">
                                        <Col className="pr-0"><h6 className="m-0">List of Medical Services</h6></Col>
                                        <Col sm="5" className="text-right pl-0">
                                            <button className="btn btn-out-dashed" id="add"> Add &nbsp; <span className="addbtn">+</span></button>
                                            <div className="btn blkupload pr-0" id="upload"><img src={uploadlogo} alt=""/></div>
                                            <UncontrolledTooltip color="primary" placement="top" target="upload">
                                            Bulk Upload
                                            </UncontrolledTooltip>
                                            <UncontrolledTooltip color="primary" placement="top" target="add">
                                            Add Medical Service
                                            </UncontrolledTooltip>
                                        </Col>
                                    </Row>

                                    <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                                        <input type="text" className="form-control w-100" placeholder="Search.." />
                                        <i className="fa fa-search"></i>
                                    </div>

                                    <Row>
                                        <Col sm="12" className="actn">
                                            <div className="btn btn-sm">Medical Service -1</div>
                                            <div className="btn btn-sm">Medical Service -2</div>
                                            <div className="btn btn-sm">Medical Service -3</div>
                                            <div className="btn btn-sm">Medical Service -4</div>
                                        </Col>
                                    </Row>
                                    <Row className="justify-content-end lft-pagination">
                                        <div className="pagination ml-3 text-right rgt-pgn">
                                            <PaginationComponent currentPage={this.state.currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={this.handleClick} />
                                        </div>
                                    </Row>
                                </CardBody>
                            </Card>
                        </Col>
                        <Col sm="8">
                            {/* {Add/edit medical Serivce} */}
                            <Card>
                                <CardBody>
                                    <Row>
                                        <Col sm="12">
                                            <Row>
                                                <Col className="locate align-center">
                                                    <h6>Medical Service Details</h6>
                                                </Col>
                                                <Col className="text-right help-icon">
                                                    <img src={help} alt="" />
                                                </Col>
                                            </Row>
                                            <hr />


                                            {this.state.add_Bulk === false &&

                                                <Row className="FormStyle">
                                                    <Col sm="4">
                                                        <FormGroup>
                                                            <Input type="text" defaultValue="Medical Service-1" id="example-text-input" />
                                                            <Label>Medical Service Name</Label>
                                                        </FormGroup>
                                                    </Col>
                                                    <Col sm="3">
                                                        <FormGroup>
                                                            <Input type="text" defaultValue="MED-12345" id="example-text-input" />
                                                            <Label>Medical Service Code</Label>
                                                        </FormGroup>
                                                    </Col></Row>
                                            }

                                            {this.state.add_Bulk === true &&
                                                <div className="text-center py-3">
                                                    <button type="button" className="btn btn-primary">Upload CSV <span className="addbtn ml-5">+</span></button>
                                                </div>
                                            }
                                            <hr />
                                            <Row className="viewmedsrc">
                                                <Col sm="4">
                                                    <Label>Medical Service Name</Label><br />
                                                    <span>Medical Service -1</span>

                                                </Col>
                                                <Col sm="3">
                                                    <Label>Medical Service Code</Label><br />
                                                    <span>MED-12356</span>

                                                </Col>
                                            </Row>
                                            <hr />
                                            {/* {View Medical Service} */}
                                            <Row className="align-center">


                                                <Col>
                                                    <i className="ti-arrow-left"></i>
                                                </Col>
                                                <Col className="text-right">
                                                    <i className="ti-link mr-3"></i>
                                                    <i className="ti-pencil-alt mr-3"></i>
                                                    <i className="ti-trash mr-3"></i>
                                                    <button className="btn btn-primary" onClick={this.tog_center}>Save</button>
                                                    <button className="btn btn-cancel ml-2">Cancel</button>
                                                </Col>
                                            </Row>
                                        </Col>
                                    </Row>

                                </CardBody>
                            </Card>
                            <Row className="mb-3 text-center">
                                <Col>
                                    <div className="apptype">Resourse Types</div>
                                </Col>
                                <Col className="align-right">
                                    <div className="apptype">Assigned Resourse Types</div>
                                </Col>
                            </Row>
                            <DualListBox
                                options={options}
                                selected={this.state.selected}
                                onChange={(selected) => {
                                    this.setState({ selected });
                                }}
                                canFilter
                            />
                        </Col>
                    </Row>


                    <Modal className="modal-lg OtrServices" isOpen={this.state.modal_large} toggle={this.tog_large} >
                        <Col className="Clos">
                            <button onClick={() => this.setState({ modal_large: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </Col>
                        <ModalBody className="pt-0">
                            <h6>Locations</h6>
                            <div className="topSubmenu">
                                <div className="btn  btn-sm waves-effect ">Abu Dhabi</div>
                                <div className="btn  btn-sm waves-effect ">Dibba Al-Fujairah </div>
                                <div className="btn  btn-sm waves-effect ">Liwa Oasis</div>
                                <div className="btn  btn-sm waves-effect ">Sharjah</div>
                                <div className="btn  btn-sm waves-effect">Ras Al Khaimah</div>
                                <div className="btn  btn-sm waves-effect ">Abu Dhabi</div>
                                <div className="btn  btn-sm waves-effect ">Dibba Al-Fujairah </div>
                                <div className="btn  btn-sm waves-effect ">Liwa Oasis</div>
                                <div className="btn  btn-sm waves-effect ">Sharjah</div>
                                <div className="btn  btn-sm waves-effect">Ras Al Khaimah</div>

                            </div>
                        </ModalBody>
                    </Modal>
                    <Modal className="modal-md servicetype" isOpen={this.state.modal_center} toggle={this.tog_center} >
                        <ModalBody className="text-center">
                            <h5 className="text-success">Service Creation Successful !</h5>
                            <h6>Can you add Service type?</h6>
                            <div className="mt-3">
                                <button className="btn btn-success mr-3" onClick={this.serviceType}>Yes</button>
                                <button className="btn btn-danger">No</button>
                            </div>
                        </ModalBody>
                    </Modal>
                </Container>
            </>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(MedicalService1));
