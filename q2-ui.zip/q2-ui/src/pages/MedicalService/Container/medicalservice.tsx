import React, { Component } from 'react';
import { activateAuthLayout } from '../../../store/actions';
import { connect } from 'react-redux';
import './medicalservice.css'
import { SuperParentContext } from './medicalserviceContextApi';
import { Col, Row, Container } from 'reactstrap';
import {
    MedicalServiceFilter,
    MedicalServiceManager,
    MedicalServiceItem,
    MedicalServiceView,
    MedicalServiceAction,
    LeftParentMedicalService,
    RightParentMedicalService,
    LocationSelectionByMedicalService,
    MedicalServiceMapping,
    MedicalServiceBulkUploadComponent,
    ParentMedicalServiceMapping,
    MedicalServiceAutoRefresh
} from './medicalserviceindex';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../helpers/helpersIndex';
import { IRoleDesc, IActions } from '../../../models/utilitiesModel';
import { IMedicalServiceModel } from '../../../models/medicalServiceModel';
import { getMedicalServiceAndLocRequest, cancelPendingMedicalServiceRequests, setResetForMedicalService } from '../../../store/actions';

export interface IProps {
    activateAuthLayout: any;
    medicalServiceLoad: boolean;
    loginUserRolecode: string;
    getMedicalServiceAndLocRequest: any;
    cancelPendingMedicalServiceRequests: any;
    setResetForMedicalService: any;
    add: boolean;
    edit: boolean;
    delete: boolean;
    bulkUpload: boolean;
}
class MedicalService extends Component<IProps, any>{
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            leftParentMedicalService: {
                locationView: props.loginUserRolecode === IRoleDesc.ENTERPRISEADMIN ? LocationSelectionByMedicalService : null,
                filterComponent: MedicalServiceFilter,
                listComponent: MedicalServiceManager,
                viewComponent: MedicalServiceItem,

                actions: {
                    add: this.props.add,
                    bulkUpload: this.props.bulkUpload
                }
            },
            rightParentMedicalService: {
                viewComponent: MedicalServiceView,
                actionComponent: MedicalServiceAction,
                mappingComponent: MedicalServiceMapping,
                parentmappingcomponent: ParentMedicalServiceMapping,
                bulkuploadComponent: MedicalServiceBulkUploadComponent,
                actions: { edit: this.props.edit, delete: this.props.delete }
            }
        };
    }
    componentDidMount() {

        this.props.activateAuthLayout();
        this.props.setResetForMedicalService();
        if (this.props.medicalServiceLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getMedicalServiceAndLocRequest(!this.props.medicalServiceLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getMedicalServiceAndLocRequest(!this.props.medicalServiceLoad, true);


    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.cancelPendingMedicalServiceRequests();
        this.props.setResetForMedicalService();
    }
    render() {
        return (
            <>
                {getAutoRefresing() && <MedicalServiceAutoRefresh />}

                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftParentMedicalService}>
                                <LeftParentMedicalService />
                            </SuperParentContext.Provider>
                        </Col>
                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightParentMedicalService}>
                                <RightParentMedicalService />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>

            </>
        )
    };
}
const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete', 'bulk_insert'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'medical', defaultPrivilages);
    if (getAutoRefresing() && state.medicalServiceReducer && (state.medicalServiceReducer as IMedicalServiceModel).medicalServiceData)
        return {
            medicalServiceLoad: ((state.medicalServiceReducer as IMedicalServiceModel).medicalServiceData.length > 0 ? true : false),
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
    else
        return {
            medicalServiceLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
}

export default connect(mapStatetoProps, { getMedicalServiceAndLocRequest, activateAuthLayout, cancelPendingMedicalServiceRequests, setResetForMedicalService })(MedicalService);
