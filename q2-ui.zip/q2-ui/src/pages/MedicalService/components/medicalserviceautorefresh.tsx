import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../Container/medicalservice.css';
import { IMedicalServiceModel } from '../../../models/medicalServiceModel';
import { getMedicalServiceAndLocRequest } from '../../../store/actions';
import { useTranslation } from 'react-i18next';
import {UncontrolledTooltip} from 'reactstrap';

const MedicalServiceAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const refreshLoading = useSelector(state => {
        if (state && state.medicalServiceReducer)
            return (state.medicalServiceReducer as IMedicalServiceModel).refreshLoading
        else
            return false;
    })
    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="Ltooltip" onClick={() => dispatch(getMedicalServiceAndLocRequest(true, true))}></i>
            <UncontrolledTooltip color="primary" placement="top" target="Ltooltip">
             {t('ActionNames.autoRefresh')}    
             </UncontrolledTooltip>
             </>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}
export default React.memo(MedicalServiceAutoRefresh)