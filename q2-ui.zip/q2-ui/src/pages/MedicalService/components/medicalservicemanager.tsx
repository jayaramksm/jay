import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import { Col, Row } from 'reactstrap';
import { PaginationComponent } from '../../../pages/Utilities/PaginationComponent';
import '../Container/medicalservice.css';
import { useTranslation } from 'react-i18next';
import { ParentContext, ChildContext } from '../Container/medicalserviceContextApi';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { IMedicalService } from '../../../models/medicalServiceModel';

import PerfectScrollbar from 'react-perfect-scrollbar';

export const MedicalServiceManager: React.FC = () => {
    const { t } = useTranslation("translations");
    const context = useContext(ParentContext);
    const pageSize = getEnvironment.listPageSize;
    const searchKey = useSelector(state => {
        if (state && state.medicalServiceReducer && state.medicalServiceReducer.medicalServiceData) {
            if (state.medicalServiceReducer.searchKey)
                return state.medicalServiceReducer.searchKey;
            else
                return ''
        }
        else
            return ''

    });
    const medicalServiceTData: IMedicalService[] = useSelector(state => {
        if (state && state.medicalServiceReducer && state.medicalServiceReducer.medicalServiceData) {
            return state.medicalServiceReducer.medicalServiceData;

        }
        else return undefined;
    });

    const medicalServiceData: IMedicalService[] = (searchKey && searchKey !== '') ?
        medicalServiceTData.filter(x => x.medServiceName.toLowerCase().startsWith(searchKey.toLowerCase())) : medicalServiceTData;

    let medicalServiceCount = useSelector(state => {
        if (state && state.medicalServiceReducer && state.medicalServiceReducer.medicalServiceData)
            return state.medicalServiceReducer.medicalServiceData.length;
        else return 0;
    });

    console.log("medicalServiceCount=>", medicalServiceCount);

    let pagesCount = Math.ceil((medicalServiceData ? medicalServiceData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }
    return (<>
        {medicalServiceData && medicalServiceData.length === 0 && searchKey && <span className="recdnotfound">{t('MedicalService.noResFound')}</span>}
        {medicalServiceData && medicalServiceData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('MedicalService.noMedSerfound')}</span>}
        <Row className="flexLayout-inner">
            <PerfectScrollbar>
                <Col sm="12" className="actn-list">
                    {medicalServiceData && medicalServiceData.length > 0 && medicalServiceData.slice(currentPage * pageSize,
                        (currentPage + 1) * pageSize).map((item, index) => (
                            <ChildContext.Provider key={item.medServiceId} value={item.medServiceId}>
                                <context.viewComponent />
                            </ChildContext.Provider>
                        ))}
                </Col>
            </PerfectScrollbar>
        </Row>
        <Row className="lft-pagination">
            {medicalServiceData && medicalServiceData.length > pageSize &&
                <div className="pagination ml-4">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </Row>
    </>)
}


export default React.memo(MedicalServiceManager);