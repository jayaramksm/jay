import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, Label, CardBody, Card, UncontrolledTooltip } from 'reactstrap';
import '../Container/medicalservice.css';
import { useTranslation } from 'react-i18next';
import { IMedicalServiceModel, IMedicalService } from '../../../models/medicalServiceModel';
import { ParentContext } from '../Container/medicalserviceContextApi';
import { suspendOrEditMedicalServiceAction, deleteMedicalServiceRequest, fetchDoctorUsersToMapRequest } from '../../../store/actions';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';

export const MedicalServiceView: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);
    const medicalServiceActionData = useSelector(state => {
        if ((state.medicalServiceReducer))
            return (state.medicalServiceReducer as IMedicalServiceModel) ?
                (state.medicalServiceReducer).actionData : undefined
        else
            return undefined
    }) as IMedicalService;
    console.log("medicalServiceActionData", medicalServiceActionData);
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const isMappingAction = useSelector(state => {
        if (state.medicalServiceReducer && state.medicalServiceReducer.actionType)
            return (state.medicalServiceReducer).actionType === IOprationalActions.MAPPING;
        else return false;
    });

    const isSelectAction = useSelector(state => {
        if (state.medicalServiceReducer && state.medicalServiceReducer.actionType)
            return (state.medicalServiceReducer).actionType === IOprationalActions.SELECT;
        else return false;
    });
    const editMedicalService = () => {
        dispatch(suspendOrEditMedicalServiceAction(IOprationalActions.EDIT));
    };

    const deleteMedicalService = (medicalServiceData: IMedicalService) => {
        const message = t('MedicalService.confirmMessages.MC2').replace('{medicalservicename}', medicalServiceData.medServiceName)
        dispatch(deleteMedicalServiceRequest(IOprationalActions.DELETE, medicalServiceData.medServiceId, message, false));
    }
    const mappingDoctors = (medService) => {
        dispatch(fetchDoctorUsersToMapRequest(medService));
    }
    const backToView = () => {
        dispatch(suspendOrEditMedicalServiceAction(isMappingAction ? IOprationalActions.SELECT : 0));
    }
    return (<>
        {(isSelectAction || isMappingAction) && medicalServiceActionData && <Card>
            <CardBody>
                <Row>
                    <Col sm="12">
                        <Row className="viewmedsrc">
                            <Col sm="4">
                                <Label>{t('MedicalService.medicalServiceName')}</Label>
                                <br />
                                <span>{medicalServiceActionData.medServiceName}</span>
                            </Col>
                            <Col sm="3">
                                <Label>{t('MedicalService.medicalServiceCode')}</Label><br />
                                <span>{medicalServiceActionData.medServiceCode}</span>
                            </Col>
                        </Row>
                        <hr />
                        {/* {View Medical Service} */}
                        <Row className="align-center action">


                            {isMappingAction && <Col>
                                <i className="ti-arrow-left pl-0" onClick={backToView}></i>
                            </Col>}
                            <Col className="text-right">
                                {!isMappingAction && selectedLocationStatus && <>
                                    <i id="mapping" className="ti-link" onClick={() => { mappingDoctors(medicalServiceActionData) }}></i>
                                    <UncontrolledTooltip color="primary" placement="top" target="mapping">
                                        {t('ActionNames.map')}
                                    </UncontrolledTooltip>
                                </>}
                                {context.edit && selectedLocationStatus && !isMappingAction && <>
                                    <i id="edit" className="ti-pencil-alt" onClick={() => editMedicalService()}></i>
                                    <UncontrolledTooltip color="primary" placement="top" target="edit">
                                        {t('ActionNames.edit')}
                                    </UncontrolledTooltip>
                                </>}

                                {context.delete && selectedLocationStatus && !isMappingAction && <>
                                    <i id="delete" className="ti-trash" onClick={() => deleteMedicalService(medicalServiceActionData)}></i>
                                    <UncontrolledTooltip color="primary" placement="top" target="delete">
                                        {t('ActionNames.delete')}
                                    </UncontrolledTooltip>
                                </>}
                            </Col>
                        </Row>
                    </Col>
                </Row>
            </CardBody>
        </Card>}

    </>)
}
export default React.memo(MedicalServiceView);