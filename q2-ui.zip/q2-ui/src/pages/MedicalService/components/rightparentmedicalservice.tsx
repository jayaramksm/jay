import React, { useContext, useRef } from 'react';
import { useSelector } from 'react-redux';
import { ParentContext, SuperParentContext } from '../Container/medicalserviceContextApi'
import '../Container/medicalservice.css';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { IOprationalActions } from '../../../models/utilitiesModel';

export const RightParentMedicalService: React.FC = () => {
    const scrollbarRef = useRef<any>(null);
    const context: any = useContext(SuperParentContext);
    const isMappingAction = useSelector(state => {
        if (state && state.medicalServiceReducer)
            return state.medicalServiceReducer.actionType === IOprationalActions.MAPPING;
        else return false;
    });

    if (!isMappingAction) {
        if (scrollbarRef && scrollbarRef.current)
            scrollbarRef.current.scrollTop = 0;
    }

    return (<>


        <div className="flexLayout-inner">
            <PerfectScrollbar ref={scrollbarRef}>
                <div className="pl-3"> 
                    <context.actionComponent />
                    <ParentContext.Provider value={context.actions}>
                        <context.viewComponent />
                    </ParentContext.Provider>
                    <context.parentmappingcomponent />
                    <context.bulkuploadComponent />
                </div>
            </PerfectScrollbar >
        </div>


    </>)
}
export default React.memo(RightParentMedicalService);