import React from "react";
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row } from 'reactstrap';
import DualListBox from 'react-dual-listbox';
import { useTranslation } from "react-i18next";
import { IUser } from "../../../models/medicalServiceModel";
import * as _ from 'lodash';
import { mapMedicalServicesRequest, suspendOrEditMedicalServiceAction } from "../../../store/actions";
import { IOprationalActions } from "../../../models/utilitiesModel";
import { Formik, Form } from "formik";

const MedicalServiceMapping: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const mappedUsersOfMedicalService = useSelector(state => {
        if (state && state.medicalServiceReducer && state.medicalServiceReducer.actionData)
            return state.medicalServiceReducer.actionData.users ? state.medicalServiceReducer.actionData.users : [];
        else return [];
    });
    const existingMappedOptions = mappedUsersOfMedicalService ? mappedUsersOfMedicalService.map(x => x.userId) : [];

    const usersData: IUser[] = useSelector(state => {
        if (state && state.medicalServiceReducer)
            return state.medicalServiceReducer.userData ? state.medicalServiceReducer.userData : [] as IUser[];
        else return undefined;
    });
    const userssDataOptions = usersData ? usersData.map(item => ({ value: item.userId, label: item.userName })) : [];

    const cancelMapping = () => {
        dispatch(suspendOrEditMedicalServiceAction(IOprationalActions.SELECT));
    }
    return (
        <Formik
            enableReinitialize
            initialValues={{
                selected: existingMappedOptions ? existingMappedOptions : []

            }}

            onSubmit={(values) => {
                const mappedData: any = [];
                values.selected.forEach(item => {
                    let data = _.omit(usersData.find(x => x.userId === item));
                    mappedData.push(data);
                });
                dispatch(mapMedicalServicesRequest(mappedData));
            }}
        >
            {({ values, setFieldValue }) => (
                <Form>
                    <Row className="mb-3 text-center">
                        <Col>
                            <div className="apptype">{t('MedicalService.resourseTypes')}</div>
                        </Col>
                        <Col className="align-right">
                            <div className="apptype">{t('MedicalService.assignresourseTypes')}</div>
                        </Col>
                    </Row>
                    <DualListBox
                        name="selected"
                        options={userssDataOptions}
                        selected={values.selected}
                        onChange={(selectedValues) => {
                            setFieldValue('selected', selectedValues)
                        }} preserveSelectOrder
                        showNoOptionsText
                        canFilter
                    />
                    <div className="text-right mt-5">
                        <button className="btn btn-primary" type="submit">
                            {t('ActionNames.save')}
                        </button>
                        <button className="btn btn-cancel ml-3" onClick={cancelMapping}>
                            {t('ActionNames.cancel')}
                        </button>
                    </div>
                </Form>
            )}
        </Formik>)
}
export default React.memo(MedicalServiceMapping);