import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../Container/medicalservice.css';
import { ChildContext } from '../Container/medicalserviceContextApi';
import { IMedicalService, IMedicalServiceModel } from '../../../models/medicalServiceModel';
import { setMedicalServiceActionRequestData, suspendOrEditMedicalServiceAction } from '../../../store/actions';
import { IOprationalActions } from '../../../models/utilitiesModel';

 const MedicalServiceItem: React.FC = () => {
    const context = useContext(ChildContext);
    const dispatch = useDispatch();
    let medicalServiceData: IMedicalService = useSelector(state => {
        if (state && state.medicalServiceReducer) {
            let data = state.medicalServiceReducer.medicalServiceData as IMedicalService[];
            let index = data.findIndex(x => x.medServiceId === context);

            if (index !== -1)
                return state.medicalServiceReducer.medicalServiceData[index];
            else return undefined;
        }
        else return undefined;
    });
    const selectedMedicalService = useSelector(state => {
        if (state && state.medicalServiceReducer) {
            return (state.medicalServiceReducer as IMedicalServiceModel).actionData ?
                ((state.medicalServiceReducer as IMedicalServiceModel).actionData as IMedicalService).medServiceId === medicalServiceData.medServiceId : false;
        }
        else return false;
    })

    return (<>
        {medicalServiceData && 

            <span className={'btn btn-sm ' + (selectedMedicalService ? 'activeList' : '')}
                onClick={() => dispatch(selectedMedicalService ? suspendOrEditMedicalServiceAction(0) : setMedicalServiceActionRequestData(IOprationalActions.SELECT, medicalServiceData, false))}
            >
                {medicalServiceData.medServiceName}
            </span>
        }
    </>)
}
export default React.memo(MedicalServiceItem);