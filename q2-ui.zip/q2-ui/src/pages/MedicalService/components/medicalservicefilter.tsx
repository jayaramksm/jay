import React, { useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Col, Row, UncontrolledTooltip } from 'reactstrap';
import '../Container/medicalservice.css';
import uploadlogo from '../../../images/upload.svg';
import { ParentContext } from '../Container/medicalserviceContextApi';
import { useTranslation } from 'react-i18next';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import { setMedicalServiceActionRequestData, setMedicalServiceSearchKey } from '../../../store/actions';

const MedicalServiceFilter: React.FC = () => {

    const context: any = useContext(ParentContext);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const actionArea = useSelector(state => {
        if (state && state.medicalServiceReducer && state.medicalServiceReducer.actionType)
            return state.medicalServiceReducer.actionType === IOprationalActions.ADD;
        else return false;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const isBulkUpload = useSelector(state => {
        if (state && state.medicalServiceReducer)
            return state.medicalServiceReducer.actionType === IOprationalActions.BULKUPLOAD;
        else return false;
    });
    const filterActions = useSelector(state => {
        if (state && state.medicalServiceReducer && state.medicalServiceReducer.medicalServiceData)
            return state.medicalServiceReducer.medicalServiceData.length > 0;
        else return false;
    });
    console.log('medicalServiceFilter=>', context);

    const addMedicalService = () => {
        if (actionArea !== IOprationalActions.ADD)
            dispatch(setMedicalServiceActionRequestData(IOprationalActions.ADD, null, false));
    }
    const addBulkUpload = () => {
        dispatch(setMedicalServiceActionRequestData(IOprationalActions.BULKUPLOAD, null, false));
    }

    const setSearch = (key) => {
        dispatch(setMedicalServiceSearchKey(key));
    }
    return (<>
        <Row className="roleslist">
            <Col className="pr-0"><h6 className="m-0">{t('MedicalService.listOfMedicalServices')}</h6>
            </Col>
            {selectedLocationStatus &&
                <div className="align-right pr-3 addupload">
                    {context?.actions?.add && <button disabled={(actionArea)}
                        onClick={addMedicalService} className="btn btn-out-dashed" id="add"> {t('ActionNames.add')} &nbsp; <span className="addbtn">+</span></button>}
                    {context.actions?.bulkUpload && selectedLocationStatus && <> <button disabled={isBulkUpload} onClick={addBulkUpload} className="btn blkupload p-0 pl-2" id="upload"><img alt="" src={uploadlogo} /></button>
                        <UncontrolledTooltip color="primary" placement="top" target="upload">
                            {t('ActionNames.bulkupload')}
                        </UncontrolledTooltip>
                    </>}
                    {!actionArea && context?.actions?.add && <UncontrolledTooltip color="primary" placement="top" target="add">
                        {t('MedicalService.addMedicalservice')}
                    </UncontrolledTooltip>}
                </div>}
        </Row>
        {filterActions &&
            <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={e => setSearch(e.target.value)} />
                <i className="fa fa-search"></i>
            </div>}
    </>)
}
export default React.memo(MedicalServiceFilter);