import React from 'react';
import '../Container/medicalservice.css';
import { LocationSelectArea } from '../../../pages/Utilities/LocationSelectArea';
import { changeLocationForMedicalService } from '../../../store/actions';

const LocationSelectionByMedicalService: React.FC = () => {
  
    return (<>
     <LocationSelectArea locationCallBack={changeLocationForMedicalService} />
    </>)
}
export default React.memo(LocationSelectionByMedicalService);