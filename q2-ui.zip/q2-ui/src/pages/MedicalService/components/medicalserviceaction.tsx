import React from 'react';
import '../Container/medicalservice.css';
import { useSelector, useDispatch } from 'react-redux';
import { CardBody, Card, Col, Row, FormGroup, Label } from 'reactstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { IMedicalServiceModel, IMedicalService } from '../../../models/medicalServiceModel';
import * as Yup from 'yup';
import { customContentValidation } from '../../../helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { suspendOrEditMedicalServiceAction, createAndUpdateMedicalServiceRequest } from '../../../store/actions';


const MedicalServiceAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const medicalServiceActionData = useSelector(state => {
        if ((state.medicalServiceReducer))
            return (state.medicalServiceReducer as IMedicalServiceModel) ?
                (state.medicalServiceReducer).actionData : undefined
        else
            return undefined
    }) as IMedicalService;

    const actionType = useSelector(state => {
        if (state && state.medicalServiceReducer && state.medicalServiceReducer.actionType)
            return state.medicalServiceReducer.actionType;
        else return 0;
    });


    const cancelEditFunction = () => {
        dispatch(suspendOrEditMedicalServiceAction(actionType === IOprationalActions.EDIT ? IOprationalActions.SELECT : 0));
    }
    return (<>


        {(actionType === IOprationalActions.ADD || actionType === IOprationalActions.EDIT) && <Card>
            <CardBody>
                <Formik
                    enableReinitialize
                    initialValues={{
                        medSerId: medicalServiceActionData ? medicalServiceActionData.medServiceId : 0,
                        medicalServiceName: medicalServiceActionData ? medicalServiceActionData.medServiceName : '',
                        medicalServiceCode: medicalServiceActionData ? medicalServiceActionData.medServiceCode : '',

                    }}
                    validationSchema={Yup.object().shape({
                        medicalServiceName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
                        medicalServiceCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: ':' }, 50, 2),
                    })}
                    onSubmit={(values) => {
                        console.log("Values =>", values);

                        let medicalService = {
                            medServiceId: values.medSerId,
                            medServiceName: values.medicalServiceName,
                            medServiceCode: values.medicalServiceCode,
                        } as IMedicalService;
                        console.log("Values =>", values, medicalService);
                        dispatch(createAndUpdateMedicalServiceRequest(medicalService, t('MedicalService.confirmMessages.MC3'), t('MedicalService.confirmMessages.MC4')))

                    }}
                >
                    {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                        <Form>
                            <Row>
                                <Col sm="12">

                                    <Row className="FormStyle">
                                        <Col sm="4">
                                            <FormGroup>
                                                <Field name="medicalServiceName" placeholder={t('MedicalService.medicalServiceName')}
                                                    className={'form-control ' + (errors.medicalServiceName && touched.medicalServiceName ? 'is-invalid' : '')} />
                                                <ErrorMessage name="medicalServiceName" component="div" className="invalid-feedback" />
                                                <Label>{t('MedicalService.medicalServiceName')}</Label>
                                            </FormGroup>
                                        </Col>
                                        <Col sm="3">
                                            <FormGroup>
                                                <Field name="medicalServiceCode" placeholder={t('MedicalService.medicalServiceCode')}
                                                    className={'form-control ' + (errors.medicalServiceCode && touched.medicalServiceCode ? 'is-invalid' : '')} />
                                                <ErrorMessage name="medicalServiceCode" component="div" className="invalid-feedback" />
                                                <Label>{t('MedicalService.medicalServiceCode')}</Label>
                                            </FormGroup>
                                        </Col>
                                    </Row>



                                    <hr />
                                    {/* {View Medical Service} */}
                                    <Row className="align-center">


                                        <Col className="text-right">

                                            <button type="submit" disabled={!(dirty)} className="btn btn-primary" >{actionType === IOprationalActions.EDIT ? t('ActionNames.update') : t('ActionNames.save')}</button>
                                            <button className="btn btn-cancel ml-3" onClick={cancelEditFunction}>Cancel</button>
                                        </Col>
                                    </Row>
                                </Col>
                            </Row>
                        </Form>
                    )}
                </Formik>
            </CardBody>
        </Card>}

    </>)
}
export default React.memo(MedicalServiceAction);