import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { SuperParentContext } from '../Container/medicalserviceContextApi';

export const ParentMedicalServiceMapping:React.FC=()=>{

    const context: any = useContext(SuperParentContext);
    const isMappingAction=useSelector(state=>{
        if(state.medicalServiceReducer && state.medicalServiceReducer.actionType)
        return (state.medicalServiceReducer).actionType===IOprationalActions.MAPPING; 
        else return false;
    })

    return (  <>
    
      {isMappingAction && <context.mappingComponent />}

        </>
    )
}
export default React.memo(ParentMedicalServiceMapping)