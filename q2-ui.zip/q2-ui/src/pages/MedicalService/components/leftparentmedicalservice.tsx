import React, { useContext } from 'react';
import '../Container/medicalservice.css';
import { SuperParentContext, ParentContext } from '../Container/medicalserviceContextApi';
import { Card, CardBody } from 'reactstrap';

const LeftParentMedicalService: React.FC = () => {
    const context = useContext(SuperParentContext);

    return (<>
        {context.locationView && <context.locationView />}
        <Card className="lft-card flexLayout mb-0">
        <div className="flex-headerfix px-3 pt-3">
        <ParentContext.Provider value={context}>
            <context.filterComponent />
        </ParentContext.Provider>
        </div>
            <CardBody className="flexLayout">
                <ParentContext.Provider value={{ viewComponent: context.viewComponent }}>
                    <context.listComponent />
                </ParentContext.Provider>
            </CardBody>
        </Card>
    </>)
}
export default React.memo(LeftParentMedicalService);