import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, FormGroup, Label } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { IMTbranchData, IOptionsData } from '../../../../models/manualTokenModel';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { getMTDoctorsDataRequest, generateManualTokenRequest, setMTTokenCreationSuspend } from '../../../../store/actions';
import { controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import '../container/manualtoken.css';
import PerfectScrollbar from 'react-perfect-scrollbar';

const ManualTokenGenerationArea: React.FC = () => {
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");

    const PriorityData =
        [{ value: 0, label: t('ManualToken.normal') },
        { value: 1, label: t('ManualToken.high') }]

    const branchServicesData: IMTbranchData = useSelector(state => {
        if (state && state.manualTokenReducer && state.manualTokenReducer.serviceData)
            return state.manualTokenReducer.serviceData;
        else return undefined;
    });

    let doctorsData: IOptionsData[] = useSelector(state => {
        if (state && state.manualTokenReducer && state.manualTokenReducer.doctorData)
            return state.manualTokenReducer.doctorData;
        else return [];
    });

    const getInitialValues = () => ({
        mrnNo: '',
        firstName: '',
        lastName: '',
        branchId: '',
        serviceId: branchServicesData && branchServicesData.services?.length === 1 ? branchServicesData.services[0] : '',
        drId: '',
        accompanyVisitors: visitorOptions.find(x => x.value === 0),
        // appointmentTime: ''
        mobileNo: '',
        priority: PriorityData[0]
    });

    const validationSchema = Yup.object().shape({
        mrnNo: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 10, 5),
        firstName: customContentValidation(t, '', { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
        lastName: customContentValidation(t, '', { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
        serviceId: controleContentValidate(t('controleErrors.required')),
        drId: controleContentValidate(t('controleErrors.required')),
        accompanyVisitors: controleContentValidate(t('controleErrors.required')),
        mobileNo: Yup.lazy(val => {
            if (val !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number' }, 20, 10)
            return Yup.string().notRequired()
        }),
        priority: controleContentValidate(t('controleErrors.required'))
    });

    const onServiceChange = (value, setFieldValue) => {
        setFieldValue('drId', '');
        setFieldValue('serviceId', value);
        dispatch(getMTDoctorsDataRequest(value?.value));
    }

    const cancelTokenCreation = () => dispatch(setMTTokenCreationSuspend());

    const getDoctorId = (setFieldValue, values) => {
        if (values.drId === '') {
            if (doctorsData.length === 1) {
                setFieldValue('drId', doctorsData[0]);
                return doctorsData[0];
            }
        }
        return values.drId;
    }

    return (
        <>
            <PerfectScrollbar style={{ height: "42vh" }}>
                <div className="header mb-4">
                    <span>{t('ManualToken.generateManualToken')}</span>
                </div>

                <Formik
                    initialValues={getInitialValues()}
                    validationSchema={validationSchema}
                    onSubmit={(values) => {
                        let accompanyVisitorsNo = (values.accompanyVisitors as any).value;
                        let doctorId = values.drId === '' ? 0 : (values.drId as any).value;
                        let serviceId = values.serviceId === '' ? 0 : (values.serviceId as any).value;

                        let tokenData = {
                            accompanyVisitors: accompanyVisitorsNo,
                            // appointmentTime: Date.now().toString(),
                            branchId: branchServicesData ? branchServicesData.branchId : 0,
                            drId: doctorId,
                            firstName: values.firstName,
                            lastName: values.lastName,
                            mrnNo: values.mrnNo,
                            serviceId: serviceId,
                            mobileNo: values.mobileNo,
                            priority: values.priority.value
                        }
                        dispatch(generateManualTokenRequest(tokenData));
                    }}
                >
                    {({ values, errors, touched, setFieldValue, setFieldTouched }) => (
                        <Form>
                            <Row>
                                <Col>
                                    <FormGroup>
                                        <Label>{t('ManualToken.mrnNo')}</Label>
                                        <Field name="mrnNo" placeholder={t('ManualToken.mrnNo')} className={'form-control ' + (errors.mrnNo && touched.mrnNo ? 'is-invalid' : '')} />
                                        <ErrorMessage name="mrnNo" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                                <Col>
                                    <FormGroup>
                                        <Label>{t('ManualToken.pfirstName')}</Label>
                                        <Field name="firstName" placeholder={t('ManualToken.pfirstName')} className={'form-control ' + (errors.firstName && touched.firstName ? 'is-invalid' : '')} />
                                        <ErrorMessage name="firstName" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                                <Col>
                                    <FormGroup>
                                        <Label>{t('ManualToken.plastName')}</Label>
                                        <Field name="lastName" placeholder={t('ManualToken.plastName')} className={'form-control ' + (errors.lastName && touched.lastName ? 'is-invalid' : '')} />
                                        <ErrorMessage name="lastName" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                {/* <Col>
                                <FormGroup>
                                    <Label>{t('ManualToken.selectBranch')}</Label>
                                    <Select
                                        placeholder={t('ManualToken.selectBranch')}
                                        name="branchId"
                                        value={values.branchId}
                                        onChange={(e) => branchSelection(e, setFieldValue)}
                                        options={[]}
                                        getOptionLabel={option => option.label}
                                        getOptionValue={option => option.value}
                                        onBlur={() => setFieldTouched('branchId', true)}
                                    />
                                    {errors.branchId && touched.branchId && (
                                        <div className="error-msg">{errors.branchId}</div>
                                    )}
                                </FormGroup>
                            </Col> */}
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('ManualToken.selectService')}</Label>
                                        <MySelect
                                            placeholder={t('ManualToken.selectService')}
                                            name="serviceId"
                                            value={values.serviceId}
                                            onChange={(e) => onServiceChange(e, setFieldValue)}
                                            options={branchServicesData ? branchServicesData.services : []}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('serviceId', true)}
                                            noOptionsMessage={() => t('ManualToken.noServices')}
                                        />
                                        {errors.serviceId && touched.serviceId && (
                                            <div className="error-msg">{errors.serviceId}</div>
                                        )}
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('ManualToken.selectDoctor')}</Label>
                                        <MySelect
                                            placeholder={t('ManualToken.selectDoctor')}
                                            name="drId"
                                            value={getDoctorId(setFieldValue, values)}
                                            onChange={(e) => setFieldValue('drId', e)}
                                            options={doctorsData}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('drId', true)}
                                            noOptionsMessage={() => t('ManualToken.noDoctors')}
                                        />
                                        {errors.drId && touched.drId && (
                                            <div className="error-msg">{errors.drId}</div>
                                        )}
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('ManualToken.mobileNo')}</Label>
                                        <Field name="mobileNo" placeholder={t('ManualToken.mobileNo')} className={'form-control ' + (errors.mobileNo && touched.mobileNo ? 'is-invalid' : '')} />
                                        <ErrorMessage name="mobileNo" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                {/* <Col>
                        <FormGroup>
                            <Label>Select Appointment Time</Label>
                            <select className="form-control">
                                <option>09.30AM</option>
                                <option>10.30AM</option>
                                <option>11.30AM</option>
                            </select>
                        </FormGroup>
                    </Col> */}
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('ManualToken.visitors')}</Label>
                                        <MySelect
                                            placeholder={t('ManualToken.visitors')}
                                            name="accompanyVisitors"
                                            value={values.accompanyVisitors}
                                            onChange={(e) => setFieldValue('accompanyVisitors', e)}
                                            options={visitorOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('accompanyVisitors', true)}
                                            noOptionsMessage={() => t('ManualToken.noVisitors')}
                                        />
                                        {errors.accompanyVisitors && touched.accompanyVisitors && (
                                            <div className="error-msg">{errors.accompanyVisitors}</div>
                                        )}
                                    </FormGroup>
                                </Col>
                                {/* <Col className="tknbtn" >
                        <button className="btn btn-outline-primary mr-3"><i className="ti-search mr-2"></i>Preview</button>
                        <button className="btn btn-outline-primary"><i className="ti-plus mr-2"></i>Add Token</button>
                    </Col> */}
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('ManualToken.priority')}</Label>
                                        <MySelect
                                            placeholder={t('ManualToken.priority')}
                                            name="priority"
                                            value={values.priority}
                                            onChange={(e) => setFieldValue('priority', e)}
                                            options={PriorityData}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('priority', true)}
                                            noOptionsMessage={() => t('ManualToken.noPriority')}
                                        />
                                        {errors.priority && touched.priority && (
                                            <div className="error-msg">{errors.priority}</div>
                                        )}
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <div style={{ marginTop: "30px" }}>
                                        <button type="submit" className="btn btn-primary mr-3">{t('ManualToken.generate')}</button>
                                        <button type="button" className="btn btn-cancel mr-3" onClick={cancelTokenCreation}>{t('ActionNames.cancel')}</button>
                                    </div>
                                </Col>
                            </Row>
                        </Form>
                    )}
                </Formik>
            </PerfectScrollbar>
        </>
    )
}
const visitorOptions = [
    { value: 0, label: '0' },
    { value: 1, label: '1' },
    { value: 2, label: '2' },
    { value: 3, label: '3' },
    { value: 4, label: '4' },
    { value: 5, label: '5' }
];
export default React.memo(ManualTokenGenerationArea);