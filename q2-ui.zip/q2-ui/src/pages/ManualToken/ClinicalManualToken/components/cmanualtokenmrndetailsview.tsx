import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { IManualTokenModel, IMrnAppointment, ITokenStatus } from '../../../../models/manualTokenModel';
import { setMTTokensViewSuspend, reprintManualTokenRequest, setMTCheckinModalData } from '../../../../store/actions';
import { SuperParentContext } from '../container/cmanualtokencontext';
import '../container/manualtoken.css';

const ManualTokenMrnDetailsView: React.FC = () => {
    const context = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const mrnAppointmentsData: IMrnAppointment[] = useSelector(state => {
        if (state && state.manualTokenReducer && state.manualTokenReducer.mrnAppointmentsData)
            return (state.manualTokenReducer as IManualTokenModel).mrnAppointmentsData;
        else return [];
    });
    console.log('mrnAppointmentsData => ', mrnAppointmentsData);

    const isMrnVerifyEnabled = useSelector(state => {
        if (state && state.manualTokenReducer)
            return (state.manualTokenReducer as IManualTokenModel).mrnVerifyButtonStatus === true;
        else return false;
    });

    const cancelView = () => dispatch(setMTTokensViewSuspend());

    return (
        <>
            {(mrnAppointmentsData.length === 0 && isMrnVerifyEnabled) && <div className="pb-3"><span>{t('ManualToken.noAppointmentsFound')}</span></div>}
            {(mrnAppointmentsData.length > 0 && isMrnVerifyEnabled) &&
                <Row>
                    <Col>
                        <div className="manualtkn mb-5">
                            <table className="table mb-0">
                                <tbody>
                                    <tr>
                                        <th>{t('ManualToken.mrn')}</th>
                                        <th>{t('ManualToken.firstName')}</th>
                                        <th>{t('ManualToken.lastName')}</th>
                                        <th>{t('ManualToken.service')}</th>
                                        {/* <th>{t('ManualToken.dateAndTime')}</th> */}
                                        <th>{t('ManualToken.action')}</th>
                                    </tr>
                                    {mrnAppointmentsData.map((item, index) => (
                                        <tr key={index}>
                                            <td>{item.mrnNO}</td>
                                            <td>{item.firstName}</td>
                                            <td>{item.lastName}</td>
                                            <td>{item.serviceNameEn}</td>
                                            {/* <td>09.30AM</td> */}
                                            <td>
                                                <button className="btn btn-primary btn-sm" onClick={item.status === ITokenStatus.CHECKIN ? () => dispatch(setMTCheckinModalData(item)) : () => dispatch(reprintManualTokenRequest(item.serviceBookedId))}>
                                                    {item.status === ITokenStatus.CHECKIN ? t('ManualToken.checkIn') : t('ManualToken.reprint')}
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                    {/* <tr>
                                        <td>123456</td>
                                        <td>Bella</td>
                                        <td>Smith</td>
                                        <td>Nutrition</td>
                                        <td>11.30AM</td>
                                        <td className="actionText">IN0123</td>
                                    </tr> */}
                                </tbody>
                            </table>
                        </div>
                    </Col>
                    <context.manualTokenCheckinModal />
                </Row>
            }
            {(mrnAppointmentsData && isMrnVerifyEnabled) && <button type="button" className="btn btn-cancel mb-3" onClick={cancelView}>{t('ActionNames.cancel')}</button>}
        </>
    )
}
export default React.memo(ManualTokenMrnDetailsView);