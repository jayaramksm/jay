import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { IManualTokenModel } from '../../../../models/manualTokenModel';
import { SuperParentContext } from '../container/cmanualtokencontext';
import '../container/manualtoken.css';

const ManualTokenMrnGenerationParent: React.FC = () => {
    const context = useContext(SuperParentContext);
    const isGenerateTokenEnabled = useSelector(state => {
        if (state && state.manualTokenReducer)
            return (state.manualTokenReducer as IManualTokenModel).generateTokenButtonStatus === true;
        else return false;
    });

    return (
        <>
            {isGenerateTokenEnabled && <context.manualTokenGenerationArea />}
        </>
    )
}
export default React.memo(ManualTokenMrnGenerationParent);