import * as React from 'react';
import { activateAuthLayout, setResetForManualToken } from '../../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Row } from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import './manualtoken.css';
import {
    ManualTokenLeftParentManager,
    ManualTokenGenerationArea,
    ManualTokenMrnDetailsView,
    ManualTokenMrnInputArea,
    ManualTokenPreviewArea,
    ManualTokenCheckinModal,
    ManualTokenMrnGenerationParent
} from './cmanualtokenindex';
import { SuperParentContext } from './cmanualtokencontext';
import { withTranslation } from 'react-i18next';

interface IProps {
    t: any;
    activateAuthLayout: any;
    history: any;
    setResetForManualToken: any;
    profilePath: any;
}
class ManualToken extends React.Component<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            leftParentManager: {
                manualTokenMrnGenerationParent: ManualTokenMrnGenerationParent,
                manualTokenMrnInputArea: ManualTokenMrnInputArea,
                manualTokenMrnDetailsView: ManualTokenMrnDetailsView,
                manualTokenGenerationArea: ManualTokenGenerationArea,
                manualTokenCheckinModal: ManualTokenCheckinModal,
                actions: { verifyMrn: true, generateToken: true }
            },
            rightParentActions: {
                actions: { print: true }
            }
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForManualToken();
    }
    componentWillUnmount() {
        this.props.setResetForManualToken();
    }

    render() {
        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout">
                        <PerfectScrollbar >
                            <div>
                                {/* {this.props.profilePath && <div>
                                    <div className="btn btn-grey mb-3 btn-sm" onClick={() => this.props.history.push(this.props.profilePath)}>{this.props.t('UserProfileManagement.changeWorkspace')}</div>
                                </div>} */}
                                <Row>
                                    {/* left parent manager */}
                                    <SuperParentContext.Provider value={this.state.leftParentManager}>
                                        <ManualTokenLeftParentManager />
                                    </SuperParentContext.Provider>

                                    {/* token preview area */}
                                    <SuperParentContext.Provider value={this.state.rightParentActions}>
                                        <ManualTokenPreviewArea />
                                    </SuperParentContext.Provider>
                                </Row>
                            </div>
                        </PerfectScrollbar>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(withTranslation("translations")(connect(null, { activateAuthLayout, setResetForManualToken })(ManualToken)));
