import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, FormGroup, Label } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { IRMTbranchData } from '../../../../models/radiologyManualTokenModel';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { generateRManualTokenRequest, setRMTTokenCreationSuspend } from '../../../../store/actions';
import { controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import '../container/manualtoken.css';
import PerfectScrollbar from 'react-perfect-scrollbar';

const RManualTokenGenerationArea: React.FC = () => {

    const dispatch = useDispatch();
    const { t } = useTranslation("translations");

    const PriorityData =
        [{ value: 0, label: t('RadiologyManualToken.normal') },
        { value: 1, label: t('RadiologyManualToken.high') }]

    const branchServicesData: IRMTbranchData = useSelector(state => {
        if (state && state.radiologyManualTokenReducer && state.radiologyManualTokenReducer.serviceData)
            return state.radiologyManualTokenReducer.serviceData;
        else return undefined;
    });

    const getInitialValues = () => ({
        mrnNo: '',
        firstName: '',
        lastName: '',
        branchId: '',
        serviceId: branchServicesData && branchServicesData.services?.length === 1 ? branchServicesData.services[0] : '',
        drId: 0,
        accompanyVisitors: visitorOptions.find(x => x.value === 0),
        // appointmentTime: ''
        mobileNo: '',
        priority: PriorityData[0]
    });

    const validationSchema = Yup.object().shape({
        mrnNo: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 10, 5),
        firstName: customContentValidation(t, '', { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
        lastName: customContentValidation(t, '', { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
        serviceId: controleContentValidate(t('controleErrors.required')),
        accompanyVisitors: controleContentValidate(t('controleErrors.required')),
        mobileNo: Yup.lazy(val => {
            if (val !== undefined)
                return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number' }, 20, 10)
            return Yup.string().notRequired()
        }),
        priority: controleContentValidate(t('controleErrors.required'))
    });

    const onServiceChange = (value, setFieldValue) => {
        setFieldValue('serviceId', value);
    }

    const cancelTokenCreation = () => dispatch(setRMTTokenCreationSuspend());


    return (
        <>
            <PerfectScrollbar style={{ height: "42vh" }}>
                <div className="header mb-4">
                    <span>{t('RadiologyManualToken.generateManualToken')}</span>
                </div>

                <Formik
                    initialValues={getInitialValues()}
                    validationSchema={validationSchema}
                    onSubmit={(values) => {
                        let accompanyVisitorsNo = (values.accompanyVisitors as any).value;
                        let serviceId = values.serviceId === '' ? 0 : (values.serviceId as any).value;

                        let tokenData = {
                            accompanyVisitors: accompanyVisitorsNo,
                            // appointmentTime: Date.now().toString(),
                            branchId: branchServicesData ? branchServicesData.branchId : 0,
                            drId: values.drId,
                            firstName: values.firstName,
                            lastName: values.lastName,
                            mrnNo: values.mrnNo,
                            serviceId: serviceId,
                            mobileNo: values.mobileNo,
                            priority: values.priority.value
                        }
                        console.log("onSubmit_LManualToken => ", tokenData);
                        dispatch(generateRManualTokenRequest(tokenData));
                    }}
                >
                    {({ values, errors, touched, setFieldValue, setFieldTouched }) => (
                        <Form>
                            <Row>
                                <Col>
                                    <FormGroup>
                                        <Label>{t('RadiologyManualToken.mrnNo')}</Label>
                                        <Field name="mrnNo" placeholder={t('RadiologyManualToken.mrnNo')} className={'form-control ' + (errors.mrnNo && touched.mrnNo ? 'is-invalid' : '')} />
                                        <ErrorMessage name="mrnNo" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                                <Col>
                                    <FormGroup>
                                        <Label>{t('RadiologyManualToken.pfirstName')}</Label>
                                        <Field name="firstName" placeholder={t('RadiologyManualToken.pfirstName')} className={'form-control ' + (errors.firstName && touched.firstName ? 'is-invalid' : '')} />
                                        <ErrorMessage name="firstName" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                                <Col>
                                    <FormGroup>
                                        <Label>{t('RadiologyManualToken.plastName')}</Label>
                                        <Field name="lastName" placeholder={t('RadiologyManualToken.plastName')} className={'form-control ' + (errors.lastName && touched.lastName ? 'is-invalid' : '')} />
                                        <ErrorMessage name="lastName" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                {/* <Col>
                                <FormGroup>
                                    <Label>{t('RadiologyManualToken.selectBranch')}</Label>
                                    <Select
                                        placeholder={t('RadiologyManualToken.selectBranch')}
                                        name="branchId"
                                        value={values.branchId}
                                        onChange={(e) => branchSelection(e, setFieldValue)}
                                        options={[]}
                                        getOptionLabel={option => option.label}
                                        getOptionValue={option => option.value}
                                        onBlur={() => setFieldTouched('branchId', true)}
                                    />
                                    {errors.branchId && touched.branchId && (
                                        <div className="error-msg">{errors.branchId}</div>
                                    )}
                                </FormGroup>
                            </Col> */}
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('RadiologyManualToken.selectService')}</Label>
                                        <MySelect
                                            placeholder={t('RadiologyManualToken.selectService')}
                                            name="serviceId"
                                            value={values.serviceId}
                                            onChange={(e) => onServiceChange(e, setFieldValue)}
                                            options={branchServicesData ? branchServicesData.services : []}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('serviceId', true)}
                                            noOptionsMessage={() => t('RadiologyManualToken.noServices')}
                                        />
                                        {errors.serviceId && touched.serviceId && (
                                            <div className="error-msg">{errors.serviceId}</div>
                                        )}
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('RadiologyManualToken.mobileNo')}</Label>
                                        <Field name="mobileNo" placeholder={t('RadiologyManualToken.mobileNo')} className={'form-control ' + (errors.mobileNo && touched.mobileNo ? 'is-invalid' : '')} />
                                        <ErrorMessage name="mobileNo" component="div" className="invalid-feedback" />
                                    </FormGroup>
                                </Col>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('RadiologyManualToken.visitors')}</Label>
                                        <MySelect
                                            placeholder={t('RadiologyManualToken.visitors')}
                                            name="accompanyVisitors"
                                            value={values.accompanyVisitors}
                                            onChange={(e) => setFieldValue('accompanyVisitors', e)}
                                            options={visitorOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('accompanyVisitors', true)}
                                            noOptionsMessage={() => t('RadiologyManualToken.noVisitors')}
                                        />
                                        {errors.accompanyVisitors && touched.accompanyVisitors && (
                                            <div className="error-msg">{errors.accompanyVisitors}</div>
                                        )}
                                    </FormGroup>
                                </Col>

                            </Row>
                            {/* <Col>
                        <FormGroup>
                            <Label>Select Appointment Time</Label>
                            <select className="form-control">
                                <option>09.30AM</option>
                                <option>10.30AM</option>
                                <option>11.30AM</option>
                            </select>
                        </FormGroup>
                    </Col> */}

                            {/* <Col className="tknbtn" >
                        <button className="btn btn-outline-primary mr-3"><i className="ti-search mr-2"></i>Preview</button>
                        <button className="btn btn-outline-primary"><i className="ti-plus mr-2"></i>Add Token</button>
                    </Col> */}
                            <Row>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('RadiologyManualToken.priority')}</Label>
                                        <MySelect
                                            placeholder={t('RadiologyManualToken.priority')}
                                            name="priority"
                                            value={values.priority}
                                            onChange={(e) => setFieldValue('priority', e)}
                                            options={PriorityData}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('priority', true)}
                                            noOptionsMessage={() => t('RadiologyManualToken.noPriority')}
                                        />
                                        {errors.priority && touched.priority && (
                                            <div className="error-msg">{errors.priority}</div>
                                        )}
                                    </FormGroup>
                                </Col>

                                <Col sm="4">
                                    <div style={{ marginTop: "30px" }}>
                                        <button type="submit" className="btn btn-primary mr-3">{t('RadiologyManualToken.generate')}</button>
                                        <button type="button" className="btn btn-cancel mr-3" onClick={cancelTokenCreation}>{t('ActionNames.cancel')}</button>
                                    </div>
                                </Col>
                            </Row>
                        </Form>
                    )}
                </Formik>
            </PerfectScrollbar>
        </>
    )
}
const visitorOptions = [
    { value: 0, label: '0' },
    { value: 1, label: '1' },
    { value: 2, label: '2' },
    { value: 3, label: '3' },
    { value: 4, label: '4' },
    { value: 5, label: '5' }
];
export default React.memo(RManualTokenGenerationArea);