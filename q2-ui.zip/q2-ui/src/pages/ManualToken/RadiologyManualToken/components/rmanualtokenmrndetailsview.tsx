import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { IRManualTokenModel, IRMrnAppointment, IRTokenStatus } from '../../../../models/radiologyManualTokenModel';
import { setRMTTokensViewSuspend, reprintRManualTokenRequest, setRMTCheckinModalData } from '../../../../store/actions';
import { SuperParentContext } from '../container/rmanualtokencontext';
import '../container/manualtoken.css';

const RManualTokenMrnDetailsView: React.FC = () => {

    const context = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const mrnAppointmentsData: IRMrnAppointment[] = useSelector(state => {
        if (state && state.radiologyManualTokenReducer && state.radiologyManualTokenReducer.mrnAppointmentsData)
            return (state.radiologyManualTokenReducer as IRManualTokenModel).mrnAppointmentsData;
        else return [];
    });
    console.log('mrnAppointmentsData => ', mrnAppointmentsData);

    const isMrnVerifyEnabled = useSelector(state => {
        if (state && state.radiologyManualTokenReducer)
            return (state.radiologyManualTokenReducer as IRManualTokenModel).mrnVerifyButtonStatus === true;
        else return false;
    });

    const cancelView = () => dispatch(setRMTTokensViewSuspend());

    return (
        <>
            {(mrnAppointmentsData.length === 0 && isMrnVerifyEnabled) && <span>{t('LaboratoryManualToken.noAppointmentsFound')}</span>}
            {(mrnAppointmentsData.length > 0 && isMrnVerifyEnabled) &&
                <Row>
                    <Col>
                        <div className="manualtkn mb-5">
                            <table className="table table-hover mb-0">
                                <tbody>
                                    <tr>
                                        <th>{t('RadiologyManualToken.mrn')}</th>
                                        <th>{t('RadiologyManualToken.firstName')}</th>
                                        <th>{t('RadiologyManualToken.lastName')}</th>
                                        <th>{t('RadiologyManualToken.service')}</th>
                                        {/* <th>{t('RadiologyManualToken.dateAndTime')}</th> */}
                                        <th>{t('RadiologyManualToken.action')}</th>
                                    </tr>
                                    {mrnAppointmentsData.map((item, index) => (
                                        <tr key={index}>
                                            <td>{item.mrnNO}</td>
                                            <td>{item.firstName}</td>
                                            <td>{item.lastName}</td>
                                            <td>{item.serviceNameEn}</td>
                                            {/* <td>09.30AM</td> */}
                                            <td>
                                                <button className="btn btn-primary btn-sm" onClick={item.status === IRTokenStatus.CHECKIN ? () => dispatch(setRMTCheckinModalData(item)) : () => dispatch(reprintRManualTokenRequest(item.serviceBookedId))}>
                                                    {item.status === IRTokenStatus.CHECKIN ? t('RadiologyManualToken.checkIn') : t('RadiologyManualToken.reprint')}
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                    {/* <tr>
                                        <td>123456</td>
                                        <td>Bella</td>
                                        <td>Smith</td>
                                        <td>Nutrition</td>
                                        <td>11.30AM</td>
                                        <td className="actionText">IN0123</td>
                                    </tr> */}
                                </tbody>
                            </table>
                        </div>
                    </Col>
                    <context.manualTokenCheckinModal />
                </Row>
            }
            {(mrnAppointmentsData && isMrnVerifyEnabled) && <button type="button" className="btn btn-cancel ml-2" onClick={cancelView}>{t('ActionNames.cancel')}</button>}
        </>
    )
}
export default React.memo(RManualTokenMrnDetailsView);