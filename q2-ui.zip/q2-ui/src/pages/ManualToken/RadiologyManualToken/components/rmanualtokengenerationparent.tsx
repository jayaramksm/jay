import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { IRManualTokenModel } from '../../../../models/radiologyManualTokenModel';
import { SuperParentContext } from '../container/rmanualtokencontext';
import '../container/manualtoken.css';

const RManualTokenMrnGenerationParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const isGenerateTokenEnabled = useSelector(state => {
        if (state && state.radiologyManualTokenReducer)
            return (state.radiologyManualTokenReducer as IRManualTokenModel).generateTokenButtonStatus === true;
        else return false;
    });

    return (
        <>
            {isGenerateTokenEnabled && <context.manualTokenGenerationArea />}
        </>
    )
}
export default React.memo(RManualTokenMrnGenerationParent);