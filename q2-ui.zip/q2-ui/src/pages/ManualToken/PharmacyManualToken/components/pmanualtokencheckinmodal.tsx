import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Modal, ModalBody, Row, Col, Label } from 'reactstrap';
import { IPManualTokenModel, IPMrnAppointment } from '../../../../models/pharmacyManualTokenModel';
import { setPMTCheckinModalData, checkinPManualTokenRequest } from '../../../../store/actions';
import { useTranslation } from 'react-i18next';
import { Formik, Form } from 'formik';
import '../container/manualtoken.css';
import { MySelect } from '../../../../helpers/helpersIndex';

const PManualTokenCheckinModal: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const modalData: IPMrnAppointment = useSelector(state => {
        if (state && state.pharmaManualTokenReducer && state.pharmaManualTokenReducer.checkInModalData)
            return (state.pharmaManualTokenReducer as IPManualTokenModel).checkInModalData;
        else return undefined;
    });

    return (
        <>
            <Modal className="modal-md servicetype" isOpen={modalData ? true : false} toggle={() => { }} >
                <ModalBody>
                    <Formik
                        initialValues={{ accompanyVisitors: visitorOptions.find(x => x.value === 0) }}
                        onSubmit={(values) => {
                            let accompanyVisitorsNo = (values.accompanyVisitors as any).value;
                            dispatch(checkinPManualTokenRequest(modalData.serviceBookedId, modalData.mrnNO, accompanyVisitorsNo));
                        }}
                    >
                        {({ values, setFieldValue, setFieldTouched }) => (
                            <Form>
                                <Row>
                                    <Col sm="6">
                                        <Label>{t('PharmacyManualToken.visitors')}</Label>
                                        <MySelect
                                            name="accompanyVisitors"
                                            placeholder={t('PharmacyManualToken.visitors')}
                                            value={values.accompanyVisitors}
                                            onChange={(e) => setFieldValue('accompanyVisitors', e)}
                                            options={visitorOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('accompanyVisitors', true)}
                                            noOptionsMessage={() => t('PharmacyManualToken.noVisitors')}
                                        />
                                    </Col>
                                    <Col className="actionbtn">
                                        <button type="submit" className="btn btn-success mr-2" >{t('ActionNames.submit')}</button>
                                        <button type="button" className="btn btn-danger" onClick={() => dispatch(setPMTCheckinModalData(undefined))}>
                                            {t('ActionNames.cancel')}
                                        </button>

                                    </Col>
                                </Row>
                            </Form>
                        )}
                    </Formik>
                </ModalBody>
            </Modal>
        </>
    )
}
const visitorOptions = [
    { value: 0, label: '0' },
    { value: 1, label: '1' },
    { value: 2, label: '2' },
    { value: 3, label: '3' },
    { value: 4, label: '4' },
    { value: 5, label: '5' }
];
export default React.memo(PManualTokenCheckinModal);