import React, { useEffect, useContext } from 'react';
import { useSelector } from 'react-redux';
import { Col, Card } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { manageTokenTemplate } from '../../../../helpers/helpersIndex';
import { IPTemplateData } from '../../../../models/pharmacyManualTokenModel';
import Barcode from 'react-barcode';
import '../container/manualtoken.css';
import { SuperParentContext } from '../container/pmanualtokencontext';
import printLogo from '../../../../images/aldara-logo-title.png';

const PManualTokenPreviewArea: React.FC = () => {

    const actions = useContext(SuperParentContext)?.actions;
    const { t } = useTranslation("translations");
    let templateData: IPTemplateData = useSelector(state => {
        if (state && state.pharmaManualTokenReducer && state.pharmaManualTokenReducer.templateData)
            return state.pharmaManualTokenReducer.templateData;
        else return undefined;
    });

    useEffect(() => {
        if (templateData && templateData.templates) {
            (document.getElementById('tokenTemplate1') as any).innerHTML = templateData.templates.length >= 1 ? templateData.templates[0] : '';
            (document.getElementById('tokenTemplate2') as any).innerHTML = templateData.templates.length >= 2 ? templateData.templates[1] : '';
        }
    }, [templateData]);

    const printToken = () => {
        if (templateData && templateData.templateOrg) {
            let popupWin;
            popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
            popupWin.document.open();

            let printLogo = document.getElementById('printLogo')?.innerHTML;
            let barcodeHTML: any = document.getElementById('barcodeTemplate')?.innerHTML;
            let template = printLogo + templateData.templateOrg.replace('{barcode}', barcodeHTML);
            popupWin.document.write(manageTokenTemplate(template));
            popupWin.document.close();
        }
    }

    return (
        <Col sm="4">
            {templateData && templateData.templates && <><div id="tokenTemplate" className="header mb-3">
                <span>{t('PharmacyManualToken.previewToken')}</span>
            </div>
                <div>
                    <Card className="tknbackground p-4">
                        <div className="tkn">
                            <div id="printLogo">
                                <table style={{ width: '100%' }} >
                                    <tbody>
                                        <tr>
                                            <td className="text-center" style={{ padding: 0, margin: 0 }}>
                                                <img style={{ height: "60px" }} src={printLogo} alt="" className="mb-2" />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <section id="tokenTemplate1"></section>
                            {templateData.mrnNo && <section id="barcodeTemplate" className="text-center">
                                <Barcode
                                    value={templateData.mrnNo}
                                    textMargin={-5}
                                    marginTop={0}
                                    height={50}
                                    displayValue={true}
                                />
                            </section>}
                            <section id="tokenTemplate2"></section>

                            {actions.print && <div className="mt-4 text-center">
                                <button onClick={printToken} className="btn btn-cancel">{t('PharmacyManualToken.printToken')} <i className="ti-printer ml-2"></i></button>
                            </div>}
                        </div>
                    </Card>
                </div></>}
        </Col>
    )
}
export default React.memo(PManualTokenPreviewArea);