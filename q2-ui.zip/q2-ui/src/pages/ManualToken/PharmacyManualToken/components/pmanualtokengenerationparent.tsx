import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { IPManualTokenModel } from '../../../../models/pharmacyManualTokenModel';
import { SuperParentContext } from '../container/pmanualtokencontext';
import '../container/manualtoken.css';

const PManualTokenMrnGenerationParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const isGenerateTokenEnabled = useSelector(state => {
        if (state && state.pharmaManualTokenReducer)
            return (state.pharmaManualTokenReducer as IPManualTokenModel).generateTokenButtonStatus === true;
        else return false;
    });

    return (
        <>
            {isGenerateTokenEnabled && <context.manualTokenGenerationArea />}
        </>
    )
}
export default React.memo(PManualTokenMrnGenerationParent);