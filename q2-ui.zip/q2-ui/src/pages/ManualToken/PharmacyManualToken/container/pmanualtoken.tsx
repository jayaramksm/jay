import * as React from 'react';
import { activateAuthLayout, setResetForPManualToken } from '../../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Row } from 'reactstrap';
import './manualtoken.css';
import {
    PManualTokenLeftParentManager,
    PManualTokenGenerationArea,
    PManualTokenMrnDetailsView,
    PManualTokenMrnInputArea,
    PManualTokenPreviewArea,
    PManualTokenCheckinModal,
    PManualTokenMrnGenerationParent
} from './pmanualtokenindex';
import { SuperParentContext } from './pmanualtokencontext';
import { withTranslation } from 'react-i18next';

interface IProps {
    t: any;
    activateAuthLayout: any;
    history: any;
    setResetForPManualToken: any;
    profilePath: any;
}
class PManualToken extends React.Component<IProps, any> {

    constructor(props) {
        super(props);

        this.state = {
            leftParentManager: {
                manualTokenMrnGenerationParent: PManualTokenMrnGenerationParent,
                manualTokenMrnInputArea: PManualTokenMrnInputArea,
                manualTokenMrnDetailsView: PManualTokenMrnDetailsView,
                manualTokenGenerationArea: PManualTokenGenerationArea,
                manualTokenCheckinModal: PManualTokenCheckinModal,
                actions: { verifyMrn: true, generateToken: true }
            },
            rightParentActions: {
                actions: { print: true }
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForPManualToken();
    }
    componentWillUnmount() {
        this.props.setResetForPManualToken();
    }

    render() {
        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout">
                        <div className="flexLayout-inner">
                            {/* {this.props.profilePath && <div>
                                    <div className="btn btn-grey mb-3 btn-sm" onClick={() => this.props.history.push(this.props.profilePath)}>{this.props.t('UserProfileManagement.changeWorkspace')}</div>
                                </div>} */}
                            <Row>
                                {/* left parent manager */}
                                <SuperParentContext.Provider value={this.state.leftParentManager}>
                                    <PManualTokenLeftParentManager />
                                </SuperParentContext.Provider>

                                {/* token preview area */}
                                <SuperParentContext.Provider value={this.state.rightParentActions}>
                                    <PManualTokenPreviewArea />
                                </SuperParentContext.Provider>
                            </Row>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(withTranslation("translations")(connect(null, { activateAuthLayout, setResetForPManualToken })(PManualToken)));
