import * as React from 'react';
import { activateAuthLayout, setResetForNCManualToken } from '../../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Row } from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import './ncmanualtoken.css';
import {
    NCManualTokenLeftParentManager,
    NCManualTokenGenerationArea,
    NCManualTokenMrnDetailsView,
    NCManualTokenMrnInputArea,
    NCManualTokenPreviewArea,
    NCManualTokenCheckinModal,
    NCManualTokenMrnGenerationParent
} from './ncmanualtokenindex';
import { SuperParentContext } from './ncmanualtokencontext';
import { withTranslation } from 'react-i18next';

interface IProps {
    t: any;
    activateAuthLayout: any;
    history: any;
    setResetForNCManualToken: any;
    profilePath: any;
}
class NCManualToken extends React.Component<IProps, any> {
    constructor(props) {
        super(props);

        this.state = {
            leftParentManager: {
                manualTokenMrnGenerationParent: NCManualTokenMrnGenerationParent,
                manualTokenMrnInputArea: NCManualTokenMrnInputArea,
                manualTokenMrnDetailsView: NCManualTokenMrnDetailsView,
                manualTokenGenerationArea: NCManualTokenGenerationArea,
                manualTokenCheckinModal: NCManualTokenCheckinModal,
                actions: { verifyMrn: true, generateToken: true }
            },
            rightParentActions: {
                actions: { print: true }
            }
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForNCManualToken();
    }
    componentWillUnmount() {
        this.props.setResetForNCManualToken();
    }

    render() {
        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout">
                        <PerfectScrollbar >
                            <div>
                                {/* {this.props.profilePath && <div>
                                    <div className="btn btn-grey mb-3 btn-sm" onClick={() => this.props.history.push(this.props.profilePath)}>{this.props.t('UserProfileManagement.changeWorkspace')}</div>
                                </div>} */}
                                <Row>
                                    {/* left parent manager */}
                                    <SuperParentContext.Provider value={this.state.leftParentManager}>
                                        <NCManualTokenLeftParentManager />
                                    </SuperParentContext.Provider>

                                    {/* token preview area */}
                                    <SuperParentContext.Provider value={this.state.rightParentActions}>
                                        <NCManualTokenPreviewArea />
                                    </SuperParentContext.Provider>
                                </Row>
                            </div>
                        </PerfectScrollbar>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(withTranslation("translations")(connect(null, { activateAuthLayout, setResetForNCManualToken })(NCManualToken)));
