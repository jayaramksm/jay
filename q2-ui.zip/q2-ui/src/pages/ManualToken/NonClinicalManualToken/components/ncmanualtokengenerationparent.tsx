import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { INCManualTokenModel } from '../../../../models/ncManualTokenModel';
import { SuperParentContext } from '../container/ncmanualtokencontext';
import '../container/ncmanualtoken.css';

const NCManualTokenMrnGenerationParent: React.FC = () => {
    const context = useContext(SuperParentContext);
    const isGenerateTokenEnabled = useSelector(state => {
        if (state && state.ncManualTokenReducer)
            return (state.ncManualTokenReducer as INCManualTokenModel).generateTokenButtonStatus === true;
        else return false;
    });

    return (
        <>
            {isGenerateTokenEnabled && <context.manualTokenGenerationArea />}
        </>
    )
}
export default React.memo(NCManualTokenMrnGenerationParent);