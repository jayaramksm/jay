import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { ILManualTokenModel, ILMrnAppointment, ILTokenStatus } from '../../../../models/laboratoryManualTokenModel';
import { setLMTTokensViewSuspend, reprintLManualTokenRequest, setLMTCheckinModalData } from '../../../../store/actions';
import { SuperParentContext } from '../container/lmanualtokencontext';
import '../container/manualtoken.css';

const LManualTokenMrnDetailsView: React.FC = () => {
    const context = useContext(SuperParentContext);
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const mrnAppointmentsData: ILMrnAppointment[] = useSelector(state => {
        if (state && state.labManualTokenReducer && state.labManualTokenReducer.mrnAppointmentsData)
            return (state.labManualTokenReducer as ILManualTokenModel).mrnAppointmentsData;
        else return [];
    });
    console.log('mrnAppointmentsData => ', mrnAppointmentsData);

    const isMrnVerifyEnabled = useSelector(state => {
        if (state && state.labManualTokenReducer)
            return (state.labManualTokenReducer as ILManualTokenModel).mrnVerifyButtonStatus === true;
        else return false;
    });

    const cancelView = () => dispatch(setLMTTokensViewSuspend());

    return (
        <>
            {(mrnAppointmentsData.length === 0 && isMrnVerifyEnabled) && <span>{t('LaboratoryManualToken.noAppointmentsFound')}</span>}
            {(mrnAppointmentsData.length > 0 && isMrnVerifyEnabled) &&
                <Row>
                    <Col>
                        <div className="manualtkn mb-5">
                            <table className="table table-hover mb-0">
                                <tbody>
                                    <tr>
                                        <th>{t('LaboratoryManualToken.mrn')}</th>
                                        <th>{t('LaboratoryManualToken.firstName')}</th>
                                        <th>{t('LaboratoryManualToken.lastName')}</th>
                                        <th>{t('LaboratoryManualToken.service')}</th>
                                        {/* <th>{t('LaboratoryManualToken.dateAndTime')}</th> */}
                                        <th>{t('LaboratoryManualToken.action')}</th>
                                    </tr>
                                    {mrnAppointmentsData.map((item, index) => (
                                        <tr key={index}>
                                            <td>{item.mrnNO}</td>
                                            <td>{item.firstName}</td>
                                            <td>{item.lastName}</td>
                                            <td>{item.serviceNameEn}</td>
                                            {/* <td>09.30AM</td> */}
                                            <td>
                                                <button className="btn btn-primary btn-sm" onClick={item.status === ILTokenStatus.CHECKIN ? () => dispatch(setLMTCheckinModalData(item)) : () => dispatch(reprintLManualTokenRequest(item.serviceBookedId))}>
                                                    {item.status === ILTokenStatus.CHECKIN ? t('LaboratoryManualToken.checkIn') : t('LaboratoryManualToken.reprint')}
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                    {/* <tr>
                                        <td>123456</td>
                                        <td>Bella</td>
                                        <td>Smith</td>
                                        <td>Nutrition</td>
                                        <td>11.30AM</td>
                                        <td className="actionText">IN0123</td>
                                    </tr> */}
                                </tbody>
                            </table>
                        </div>
                    </Col>
                    <context.manualTokenCheckinModal />
                </Row>
            }
            {(mrnAppointmentsData && isMrnVerifyEnabled) && <button type="button" className="btn btn-cancel ml-2" onClick={cancelView}>{t('ActionNames.cancel')}</button>}
        </>
    )
}
export default React.memo(LManualTokenMrnDetailsView);