import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { ILManualTokenModel } from '../../../../models/laboratoryManualTokenModel';
import { SuperParentContext } from '../container/lmanualtokencontext';
import '../container/manualtoken.css';

const LManualTokenMrnGenerationParent: React.FC = () => {
    const context = useContext(SuperParentContext);
    const isGenerateTokenEnabled = useSelector(state => {
        if (state && state.labManualTokenReducer)
            return (state.labManualTokenReducer as ILManualTokenModel).generateTokenButtonStatus === true;
        else return false;
    });

    return (
        <>
            {isGenerateTokenEnabled && <context.manualTokenGenerationArea />}
        </>
    )
}
export default React.memo(LManualTokenMrnGenerationParent);