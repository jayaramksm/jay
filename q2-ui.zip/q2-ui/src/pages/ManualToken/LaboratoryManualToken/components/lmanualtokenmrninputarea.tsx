import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, Label } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { customContentValidation } from '../../../../helpers/helpersIndex';
import { ILManualTokenModel } from '../../../../models/laboratoryManualTokenModel';
import { searchLMTmrnNumberRequest, setLMTGenerateTokenButtonAction } from '../../../../store/actions';
import '../container/manualtoken.css';
import { SuperParentContext } from '../container/lmanualtokencontext';

const LManualTokenMrnInputArea: React.FC = () => {
    const actions = useContext(SuperParentContext)?.actions;
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const isMrnVerifyEnabled = useSelector(state => {
        if (state && state.labManualTokenReducer)
            return (state.labManualTokenReducer as ILManualTokenModel).mrnVerifyButtonStatus === true;
        else return false;
    });
    const isGenerateTokenEnabled = useSelector(state => {
        if (state && state.labManualTokenReducer)
            return (state.labManualTokenReducer as ILManualTokenModel).generateTokenButtonStatus === true;
        else return false;
    });

    const validationSchema = Yup.object().shape({
        mrnNumber: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 10, 5),
    });

    const generateManualToken = () => dispatch(setLMTGenerateTokenButtonAction());

    return (
        <>
            {actions.generateToken && <div className="header">
                <span>{t('LaboratoryManualToken.generateOrPrintLabel')}</span>
            </div>}
            <Formik
                initialValues={{ mrnNumber: '' }}
                validationSchema={validationSchema}
                onSubmit={(values) => {
                    console.log('values => ', values);
                    dispatch(searchLMTmrnNumberRequest(values.mrnNumber));
                }}
            >
                {({ errors, touched }) => (
                    <Form>
                        <Row className="mt-4 mb-5">
                            {actions.verifyMrn && <><Col sm="5">
                                <Label>{t('LaboratoryManualToken.patientsMRNno')}</Label><br />
                                <div className="app-search w-100 p-0 form-group mb-0">
                                    <Field name="mrnNumber" disabled={isMrnVerifyEnabled} className={'form-control w-100 ' + (errors.mrnNumber && touched.mrnNumber ? 'is-invalid' : '')} placeholder={t('LaboratoryManualToken.mrnNo')} />
                                    <i className="fa fa-search"></i>
                                    <ErrorMessage name="mrnNumber" component="div" className="invalid-feedback" />
                                </div>
                            </Col>
                                <Col sm="1" className="pt-4 mt-1">
                                    <button type="submit" disabled={isMrnVerifyEnabled} className="btn btn-primary">{t('ActionNames.verify')}</button>
                                </Col></>}

                            {(actions.verifyMrn && actions.generateToken) && <Col sm="2" className="text-center pt-4 mt-2">
                                <span>{t('LaboratoryManualToken.orLabel')}</span>
                            </Col>}

                            {actions.generateToken && <Col className="pt-4 mt-1">
                                <button type="button" disabled={isGenerateTokenEnabled} className="btn btn-primary px-4" onClick={generateManualToken}>{t('LaboratoryManualToken.generateNewToken')}</button>
                            </Col>}
                        </Row>
                    </Form>
                )}
            </Formik>
        </>
    )
}
export default React.memo(LManualTokenMrnInputArea);