import React, { useContext } from 'react';
import { Row, Col } from 'reactstrap';
import { SuperParentContext } from '../container/lmanualtokencontext';
import '../container/manualtoken.css';

const LManualTokenLeftParentManager: React.FC = () => {
    const context = useContext(SuperParentContext);

    return (
        <>
            <Col className="pr-5">
                <Row>
                    <Col>
                        <context.manualTokenMrnInputArea />
                        <context.manualTokenMrnDetailsView />
                    </Col>
                </Row>
                <context.manualTokenMrnGenerationParent />
            </Col>
        </>
    )
}
export default React.memo(LManualTokenLeftParentManager);