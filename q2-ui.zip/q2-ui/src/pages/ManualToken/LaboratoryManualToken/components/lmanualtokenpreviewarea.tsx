import React, { useEffect, useContext } from 'react';
import { useSelector } from 'react-redux';
import { Col, Card } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { manageTokenTemplate } from '../../../../helpers/helpersIndex';
import { ILTemplateData } from '../../../../models/laboratoryManualTokenModel';
import Barcode from 'react-barcode';
import '../container/manualtoken.css';
import { SuperParentContext } from '../container/lmanualtokencontext';

const LManualTokenPreviewArea: React.FC = () => {
    const actions = useContext(SuperParentContext)?.actions;
    const { t } = useTranslation("translations");
    let templateData: ILTemplateData = useSelector(state => {
        if (state && state.labManualTokenReducer && state.labManualTokenReducer.templateData)
            return state.labManualTokenReducer.templateData;
        else return undefined;
    });
    console.log("LManualTokenPreviewArea =>", templateData);

    useEffect(() => {
        if (templateData && templateData.templates) {
            (document.getElementById('tokenTemplate1') as any).innerHTML = templateData.templates.length >= 1 ? templateData.templates[0] : '';
            (document.getElementById('tokenTemplate2') as any).innerHTML = templateData.templates.length >= 2 ? templateData.templates[1] : '';
        }
    }, [templateData]);

    const printToken = () => {
        if (templateData && templateData.templateOrg) {
            let popupWin;
            popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
            popupWin.document.open();

            let barcodeHTML: any = document.getElementById('barcodeTemplate')?.innerHTML;
            let template = templateData.templateOrg.replace('{barcode}', barcodeHTML);
            popupWin.document.write(manageTokenTemplate(template));
            popupWin.document.close();
        }
    }

    return (
        <Col sm="4">
            {templateData && templateData.templates && <><div id="tokenTemplate" className="header mb-3">
                <span>{t('LaboratoryManualToken.previewToken')}</span>
            </div>
                <div>
                    <Card className="tknbackground p-4">
                        <div className="tkn">
                            <section id="tokenTemplate1"></section>
                            {templateData.mrnNo && <section id="barcodeTemplate" className="text-center">
                                <Barcode
                                    value={templateData.mrnNo}
                                    textMargin={-5}
                                    marginTop={0}
                                    height={50}
                                    displayValue={true}
                                />
                            </section>}
                            <section id="tokenTemplate2"></section>

                            {actions.print && <div className="mt-4 text-center">
                                <button onClick={printToken} className="btn btn-cancel">{t('LaboratoryManualToken.printToken')} <i className="ti-printer ml-2"></i></button>
                            </div>}
                        </div>
                    </Card>
                </div></>}
        </Col>
    )
}
export default React.memo(LManualTokenPreviewArea);