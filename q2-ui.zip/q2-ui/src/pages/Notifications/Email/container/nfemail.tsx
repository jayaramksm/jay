import * as React from 'react';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../../store/actions';
import { Container } from 'reactstrap';
import {
    NFEmailAction,
    NFEmailAutoRefresh,
    NFEmailManager,
    NFEmailTestModal,
    NFEmailParentManager,
    NFEmailViewComponent

} from './nfemailindex';
import { SuperParentContext } from './nfemailcontext';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../../helpers/helpersIndex';
import '../../Container/notifications.css';
import { IActions } from '../../../../models/utilitiesModel';
import { INotificationEmailModel } from '../../../../models/notificationEmailModel';
import { setResetForNotificationEmail, getNotificationEmailDataRequest, cancelAllPendingNotificationEmailRequests } from '../../../../store/actions';

interface IProps {
    activateAuthLayout: any;
    setResetForNotificationEmail: any;
    NFEmailLoad: any;
    getNotificationEmailDataRequest: any;
    cancelAllPendingNotificationEmailRequests: any;
    add: boolean;
    edit: boolean;
    status: boolean;
}
class NFEmail extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);

        this.state = {
            actionComponent: NFEmailAction,
            testModalComponent: NFEmailTestModal,
            managerComponent: NFEmailManager,
            viewComponent: NFEmailViewComponent,
            actions: { add: this.props.add, edit: this.props.edit, status: this.props.status }
        };
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForNotificationEmail();
        if (this.props.NFEmailLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getNotificationEmailDataRequest(!this.props.NFEmailLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getNotificationEmailDataRequest(!this.props.NFEmailLoad, true);
    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.cancelAllPendingNotificationEmailRequests();
        this.props.setResetForNotificationEmail();
    }


    render() {
        return (
            <>
                {getAutoRefresing() && <NFEmailAutoRefresh />}
                <Container fluid className="h-100">
                    <SuperParentContext.Provider value={this.state}>
                        <NFEmailParentManager />
                    </SuperParentContext.Provider>
                </Container>
            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit','status'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'email', defaultPrivilages);
    if (getAutoRefresing() && state.notificationEmailReducer && (state.notificationEmailReducer as INotificationEmailModel).notificationEmailData)
        return { NFEmailLoad: ((state.notificationEmailReducer as INotificationEmailModel).notificationEmailData?.length > 0 ? true : false), loginUserRolecode: loginUserRolecode, add: privileges.includes(IActions.CREATE), edit: privileges.includes(IActions.EDIT), status: privileges.includes(IActions.STATUS) };
    else
        return { NFEmailLoad: false, loginUserRolecode: loginUserRolecode, add: privileges.includes(IActions.CREATE), edit: privileges.includes(IActions.EDIT), status: privileges.includes(IActions.STATUS) };
}
export default connect(mapStatetoProps, { activateAuthLayout, setResetForNotificationEmail, getNotificationEmailDataRequest, cancelAllPendingNotificationEmailRequests })(NFEmail);