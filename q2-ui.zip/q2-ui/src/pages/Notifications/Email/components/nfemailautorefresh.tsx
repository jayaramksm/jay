import React from 'react';
import { UncontrolledTooltip } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import '../../Container/notifications.css';
import { INotificationEmailModel } from '../../../../models/notificationEmailModel';
import { getNotificationEmailDataRequest } from '../../../../store/actions';
import { useTranslation } from 'react-i18next';

const NFEmailAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const refreshLoading = useSelector(state => {
        if (state && state.notificationEmailReducer)
            return (state.notificationEmailReducer as INotificationEmailModel).refreshLoading;
        else return false;
    })

    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="Utooltip" onClick={() => dispatch(getNotificationEmailDataRequest(true, true))}></i>
                <UncontrolledTooltip color="primary" placement="top" target="Utooltip">
                    {t('ActionNames.autoRefresh')}
                </UncontrolledTooltip></>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}
export default React.memo(NFEmailAutoRefresh);