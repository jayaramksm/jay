import React, { useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Row, Col, FormGroup, Label, Card, CardBody } from 'reactstrap';
import ReactQuill from 'react-quill';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import * as _ from 'lodash';
import '../../Container/notifications.css';
import { IEmailNotification, IEmailTrigger } from '../../../../models/notificationEmailModel';
import { controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import { setNotificationEmailActionRequest, createOrUpdateNotificationEmailRequest, setNotificationEmailModalBody } from '../../../../store/actions';

const NFEmailAction: React.FC = () => {
    let ReactQuillEditor: any = ReactQuill;
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const quillRef = useRef<any>();
    const NFEmailActionData: IEmailNotification = useSelector(state => state?.notificationEmailReducer?.actionData);
    const emailData: IEmailNotification[] = useSelector(state => state?.notificationEmailReducer?.notificationEmailData);
    const triggerData: IEmailTrigger[] = useSelector(state => state?.notificationEmailReducer?.triggerData);

    const getInitialValues = () => ({
        notificationMailId: NFEmailActionData ? NFEmailActionData.notificationMailId : 0,
        mailBody: NFEmailActionData ? NFEmailActionData.mailBody : '',
        mailSubject: NFEmailActionData ? NFEmailActionData.mailSubject : '',
        templateName: NFEmailActionData ? NFEmailActionData.templateName : '',
        tiggerId: NFEmailActionData ? NFEmailActionData.tiggerId : '',
        messageField: '',
        messageFieldError: null,
        mailBodyText: NFEmailActionData ? '1' : ''
    });
    const validationSchema = Yup.object().shape({
        mailBodyText: customContentValidation(t, t('controleErrors.required'), null, 1000, 1),
        mailSubject: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 100, 1),
        tiggerId: controleContentValidate(t('controleErrors.required')),
        templateName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2)
    });

    const insertKey = (key, setFieldValue) => {
        console.log("insertKey", quillRef?.current?.getEditorSelection()?.index);

        let paramKey = `<$${key}$>`;
        if (quillRef?.current?.getEditorSelection()?.index >= 0)
            quillRef?.current?.getEditor()?.clipboard?.dangerouslyPasteHTML(quillRef?.current?.getEditorSelection()?.index, paramKey);
        else {
            setFieldValue('messageFieldError', true);
            setTimeout(() => {
                setFieldValue('messageFieldError', null);

            }, 2000);
        }
    }

    const discard = () => dispatch(setNotificationEmailActionRequest(0, null, false));

    const openTestModal = (mailBody) => dispatch(setNotificationEmailModalBody(mailBody));

    return (
        <Formik
            enableReinitialize
            initialValues={getInitialValues()}
            validationSchema={validationSchema}
            onSubmit={values => {
                console.log('Values111 => ', values);
                dispatch(createOrUpdateNotificationEmailRequest(_.omit(values, ['messageFieldError', 'mailBodyText'])));
            }}
        >
            {({ values, errors, touched, dirty, setFieldValue, setFieldTouched }) => (

                <div className="flexLayout">
                    <div className="flexLayout-inner">
                        <div className="pr-3">

                            <Form>
                                <Row className="mx-0 mb-3">
                                    <Col sm="7" className="px-0">
                                        <div className="mb-4">
                                            <h6>{t('NotificationEmail.messageBuilder')}</h6>
                                        </div>
                                        <Row className="mx-0">
                                            <Col sm="5" className="pl-0">
                                                <FormGroup>
                                                    <Label>{t('NotificationEmail.templateName')}</Label>
                                                    <Field name="templateName" placeholder={t('NotificationEmail.templateName')} className={'form-control ' + (errors.templateName && touched.templateName ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="templateName" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">

                                            </Col>
                                            <Col></Col>

                                        </Row>
                                        <Row className="mx-0">
                                            <Col sm="5" className="pl-0">
                                                <FormGroup>
                                                    <Label>{t('NotificationEmail.subject')}</Label>
                                                    <Field name="mailSubject" placeholder={t('NotificationEmail.subject')} className={'form-control ' + (errors.mailSubject && touched.mailSubject ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="mailSubject" component="div" className="invalid-feedback" />
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup className="mb-0">
                                                    <Label>{t('NotificationEmail.msgField')}</Label>
                                                    <MySelect
                                                        name="messageField"
                                                        placeholder={t('NotificationEmail.selectMsgField')}
                                                        value={values.messageField}
                                                        onChange={(e) => setFieldValue('messageField', e)}
                                                        options={triggerData ? triggerData.filter(x => x.triggerId === values.tiggerId)[0]?.params?.map(item => ({ value: item.paramId, label: item.paramName })) : []}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onBlur={() => setFieldTouched('messageField', true)}
                                                        noOptionsMessage={() => t('NotificationEmail.noMsgField')}
                                                    />
                                                    {!NFEmailActionData && !values.tiggerId && touched.messageField && <span className="error-msg">{t('NotificationEmail.selectTrigger')}</span>}
                                                    {/* {errors.messageField && touched.messageField && (
                                            <div style={{ color: "red", marginTop: ".5rem" }}>{errors.messageField}
                                            </div>
                                        )} */}
                                                </FormGroup>
                                            </Col>
                                            {values.messageField && <Col className="align-left">
                                                <button type="button" className="btn btn-primary mt-2" onClick={() => insertKey((values.messageField as any).label, setFieldValue)}>
                                                    {t('ActionNames.add')}
                                                </button>
                                                {values.messageFieldError && (
                                                    <div className="error-msg">
                                                        {t('NotificationEmail.selectMsgContent')}
                                                    </div>
                                                )}
                                            </Col>}
                                        </Row>
                                        <Row className="mx-0">
                                            <Col sm="11" className="pl-0">
                                                <Label>{t('NotificationEmail.msgContent')}</Label>
                                                <ReactQuillEditor
                                                    name="mailBodyText"
                                                    ref={quillRef}
                                                    value={values.mailBody}
                                                    modules={modules}
                                                    formats={formats}
                                                    theme="snow"
                                                    onChange={(html, delta, meta, methods) => {
                                                        setFieldValue('mailBody', html);
                                                        setFieldValue('mailBodyText', methods.getText())
                                                    }}
                                                    onBlur={() => setFieldTouched('mailBodyText', true)}
                                                />
                                                {errors.mailBodyText && touched.mailBodyText && (
                                                    <div className="error-msg">{errors.mailBodyText}
                                                    </div>
                                                )}
                                            </Col>
                                        </Row>
                                        <div className="mt-4">
                                            <button className="btn btn-primary mr-3" type="submit" disabled={(!(dirty) || ((values.mailBodyText).trim()).length === 0)}>
                                                {NFEmailActionData ? t('ActionNames.update') : t('ActionNames.save')}
                                            </button>
                                            <button type="button" className="btn btn-test mr-3" disabled={!values.mailBody || ((values.mailBodyText).trim()).length === 0} onClick={() => openTestModal(values.mailBody)}>
                                                {t('NotificationEmail.test')}
                                            </button>
                                            <button type="button" className="btn btn-cancel" onClick={discard}>
                                                {t('NotificationEmail.discard')}
                                            </button>
                                        </div>

                                    </Col>
                                    <Col sm="5">
                                        <div className="configCard">
                                            <Card>
                                                <CardBody>
                                                    <div>
                                                        <h6>{t('NotificationEmail.triggerConfig')}</h6>
                                                        {triggerData && emailData && !NFEmailActionData && triggerData.length === emailData.length && <span className="text-danger">{t('NotificationEmail.cannotCreate')}</span>}
                                                    </div>
                                                    <hr />
                                                    {triggerData && triggerData.length > 0 && triggerData.map(x => (
                                                        <Row key={x.triggerId} className="mb-3">
                                                            <Col>
                                                                <div className="chkbox">
                                                                    <input type="radio" disabled={(NFEmailActionData ? true : false) || (emailData ? (emailData.findIndex(y => y.tiggerId === x.triggerId)) !== -1 : false)} value={values.tiggerId} checked={NFEmailActionData ? (NFEmailActionData.tiggerId === x.triggerId) : values?.tiggerId === x.triggerId} name="tiggerId" onChange={() => {
                                                                        setFieldValue('messageField', null);
                                                                        setFieldValue('tiggerId', x.triggerId);
                                                                    }} className="mr-2" />
                                                                    <label htmlFor="customCheck1" className="mb-0">{x.triggerName}</label>
                                                                </div>
                                                            </Col>
                                                        </Row>
                                                    ))}
                                                </CardBody>
                                            </Card>
                                        </div>

                                        {/* {difference === 0 && <span>{t('NotificationEmail.cannotCreate')}</span>} */}
                                        {/* or match emailData & triggerData length */}
                                    </Col>
                                </Row>
                            </Form>

                        </div>

                    </div>
                </div>

            )}
        </Formik>
    )
}
const modules = {
    toolbar: [
        [{ 'header': '1' }, { 'header': '2' }, { 'font': [] }],
        [{ size: [] }],
        ['bold', 'italic', 'underline', 'strike', 'blockquote'],
        [{ 'list': 'ordered' }, { 'list': 'bullet' },
        { 'indent': '-1' }, { 'indent': '+1' }],
        ['link', 'image', 'video'],
        ['clean']
    ],
    clipboard: {
        matchVisual: false,
    }
}
const formats = [
    'header', 'font', 'size',
    'bold', 'italic', 'underline', 'strike', 'blockquote',
    'list', 'bullet', 'indent',
    'link', 'image', 'video'
];

interface optionsData {
    value: any;
    label: any;
}
export default React.memo(NFEmailAction);