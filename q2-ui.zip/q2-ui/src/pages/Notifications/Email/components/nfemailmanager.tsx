import React, { useContext, useState } from 'react';
import { Card, CardBody, Row } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import addIcon from '../../../../images/icons/addicon.svg';
import { SuperParentContext,ParentContext } from '../container/nfemailcontext';
import '../../Container/notifications.css';
import { IEmailNotification, INotificationEmailModel } from '../../../../models/notificationEmailModel';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setNotificationEmailPagination, setNotificationEmailActionRequest } from '../../../../store/actions';
import { PaginationComponent } from '../../../Utilities/PaginationComponent';
import { IOprationalActions } from '../../../../models/utilitiesModel';

const NFEmailManager: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const [searchKey, setSearchKey] = useState('');
    const context = useContext(SuperParentContext);
    const contextActions = useContext(SuperParentContext)?.actions;
    const pageSize = getEnvironment.pageSize + (contextActions?.add ? 0 : 1);

    const emailTData: IEmailNotification[] = useSelector(state => state?.notificationEmailReducer?.notificationEmailData);

    let emailData = (searchKey && searchKey !== '' && emailTData) ?
        emailTData.filter(x => x.templateName.toLowerCase().startsWith(searchKey.toLowerCase())) : emailTData;

    let currentPage = useSelector(state => {
        if (state && state.notificationEmailReducer && state.notificationEmailReducer.paginationIndex)
            return (state.notificationEmailReducer as INotificationEmailModel).paginationIndex;
        else return 0;
    });

    let pagesCount = Math.ceil((emailData ? emailData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        currentPage = 0;

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setNotificationEmailPagination(index));
    }
    return (
        <>
            {emailTData && emailTData.length > 0 && <Row>
                <div className="app-search wi-30 p-0 form-group mb-0 mt-3 pl-3">
                    <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={(e) => setSearchKey(e.target.value)} />
                    <i className="fa fa-search"></i>
                </div>
            </Row>}

            <div className="flexLayout pb-3">
                <div className="flexLayout-inner">
                        <div className="p-2 pl-3">
                            <Row className="mt-4">
                                {contextActions.add && <div className="customCard addCustomCard">
                                    <Card onClick={() => dispatch(setNotificationEmailActionRequest(IOprationalActions.ADD, null))}>
                                        <CardBody>
                                            <span>{t('NotificationEmail.add')} &nbsp;<img src={addIcon} alt="" /></span>
                                        </CardBody>
                                    </Card>
                                </div>}

                                {emailData && emailData.length > 0 && emailData.slice(currentPage * pageSize,
                                    (currentPage + 1) * pageSize).map(x => (
                                        <ParentContext.Provider key={x.tiggerId}  value={{data:x, edit: contextActions.edit, status:contextActions.status}}>
                                        <context.viewComponent />
                                    </ParentContext.Provider>
                                        
                                  
                                    ))}


                                {emailData && emailData.length === 0 && searchKey === '' && <span>{t('NotificationEmail.noData')}</span>}
                                {emailData && emailData.length === 0 && searchKey !== '' && <span>{t('NotificationEmail.noResults')}</span>}

                            </Row>
                        </div>
                </div>

                {emailData && emailData.length > pageSize && <Row className="lft-pagination">
                    <div className="pagination ml-4">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                </Row>}

            </div>

            <context.testModalComponent />
        </>
    )
}
export default React.memo(NFEmailManager);