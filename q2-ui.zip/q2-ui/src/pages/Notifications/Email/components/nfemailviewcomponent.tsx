import React, { useContext, useState } from 'react'
import { ParentContext } from '../container/nfemailcontext';
import { Card, CardBody, Label, UncontrolledTooltip } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { setNotificationEmailActionRequest } from '../../../../store/actions';
import { IOprationalActions, IStatusEnum } from '../../../../models/utilitiesModel';
import { IEmailTrigger, IEmailNotification, INotificationEmailModel } from '../../../../models/notificationEmailModel';
import { useSelector, useDispatch } from 'react-redux';
import '../../Container/notifications.css';
import Switch from "react-switch";
import { updateNFEmailRequest } from '../../../../store/notificationEmail/actions';

function NFEmailViewComponent() {
    const context = useContext(ParentContext);
    console.log('context', context);

    const { t } = useTranslation("translations");
    const [toggleState, setToggleState] = useState(true);
    const NFEmailData: IEmailNotification = useSelector(state => {
        if (state && state.notificationEmailReducer) {
            let data = (state.notificationEmailReducer as INotificationEmailModel).notificationEmailData
            let index = data?.findIndex(y => y.notificationMailId === context.data.notificationMailId)
            console.log('NFEmailData', data, NFEmailData);

            if (index !== -1)
                return state.notificationEmailReducer.notificationEmailData[index] as IEmailNotification
            else return undefined
        }
        else return undefined
    })
    const NFEmailStatus = useSelector(state => {
        if (state && state.notificationEmailReducer && state.notificationEmailReducer.notificationEmailData) {
            let data = (state.notificationEmailReducer as INotificationEmailModel).notificationEmailData;
            let index = data?.findIndex(x => x.notificationMailId === context.data.notificationMailId);
            if (index !== -1)
                return (state.notificationEmailReducer.notificationEmailData[index] as IEmailNotification).status === IStatusEnum.NACTIVE ? true : false;
            else return false;
        }
        else return false;
    });
    console.log('NFEmailStatus', NFEmailStatus);

    const triggerData: IEmailTrigger[] = useSelector(state => state?.notificationEmailReducer?.triggerData);
    console.log('triggerData', triggerData);

    const dispatch = useDispatch();
    const editNotificationMail = actionData => dispatch(setNotificationEmailActionRequest(IOprationalActions.EDIT, actionData));
    const getMailField = (triggerId) => {
        let index = triggerData?.findIndex(x => x.triggerId === triggerId);
        console.log('getMailField', index);

        return index !== -1 ? triggerData[index].triggerName : '';
    }

    return (
        <>
            {NFEmailData && <div className="customCard">
                <Card>
                    <CardBody>
                        <div className="align-right">
                            {(context.edit) && <>
                                <i id="edit" className="ti-pencil-alt mr-2 pointer" onClick={() => editNotificationMail(NFEmailData)}></i>
                                <UncontrolledTooltip color="primary" placement="top" target="edit">
                                    {t('ActionNames.edit')}
                                </UncontrolledTooltip>
                            </>}
                            {context.status && toggleState && <Switch className="mb-0" uncheckedIcon={<Offsymbol />}
                                checkedIcon={<OnSymbol />} onColor="#02a499"
                                onChange={(e) => {
                                    let updatedStatus = e === true ? IStatusEnum.NACTIVE : IStatusEnum.NINACTIVE;
                                    console.log('updatedStatus', updatedStatus);

                                    const confirmMessage = t('NotificationEmail.confirmMessages.NFEC2').replace('{​​​​​​​​triggerName}', NFEmailData.templateName).replace('{​​​​​​​​status}', NFEmailData.status === IStatusEnum.NACTIVE ? t('ActionNames.deactivate') : t('ActionNames.activate'));
                                    dispatch(updateNFEmailRequest(NFEmailData.notificationMailId, updatedStatus, false, confirmMessage));
                                    setTimeout(() => {
                                        setToggleState(false);
                                        setToggleState(true);
                                    }, 1000);
                                }}
                                checked={(NFEmailData.status === IStatusEnum.NACTIVE ? true : false)} />}

                        </div>
                        <div>
                            <Label>{t('NotificationEmail.templateName')}</Label><br />
                            <span>{NFEmailData.templateName}</span>
                        </div>

                        <div>
                            <Label>{t('NotificationEmail.triggerName')}</Label><br />
                            <span>{getMailField(NFEmailData.tiggerId)}</span>
                        </div>


                    </CardBody>
                </Card>
            </div>
            }
        </>

    )
}
const Offsymbol = () => {
    return (
        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
                fontSize: 12,
                color: "#fff",
                paddingRight: 2
            }} >
        </div>
    );
};
const OnSymbol = () => {
    return (
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: 12,
            color: "#fff",
            paddingRight: 2
        }}>
        </div>
    );
}

export default React.memo(NFEmailViewComponent)
