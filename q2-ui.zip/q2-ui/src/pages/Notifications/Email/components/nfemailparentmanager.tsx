import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../container/nfemailcontext';
import '../../Container/notifications.css';
import { IOprationalActions } from '../../../../models/utilitiesModel';


const NFEmailParentManager: React.FC = () => {
    const context = useContext(SuperParentContext);
    const actionType = useSelector(state => {
        if (state && state.notificationEmailReducer && state.notificationEmailReducer.actionType)
            return state.notificationEmailReducer.actionType;
        else return 0;
    });

    return (
        <>
            {(actionType !== IOprationalActions.ADD && actionType !== IOprationalActions.EDIT) && <context.managerComponent />}
            {(actionType === IOprationalActions.ADD || actionType === IOprationalActions.EDIT) && <context.actionComponent />}
            <context.testModalComponent />
        </>
    )
}
export default React.memo(NFEmailParentManager);