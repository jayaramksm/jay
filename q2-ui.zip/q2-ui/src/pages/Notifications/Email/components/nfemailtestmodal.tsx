import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Modal, ModalBody, FormGroup, Label } from 'reactstrap';
import '../../Container/notifications.css';
import { setNotificationEmailModalBody, testNotificationMailRequest } from '../../../../store/actions';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { controleContentValidate } from '../../../../helpers/helpersIndex';

const NFEmailTestModal: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const testModalData = useSelector(state => {
        if (state && state.notificationEmailReducer && state.notificationEmailReducer.testModalData)
            return state.notificationEmailReducer.testModalData;
        else return undefined;
    });

    const validationSchema = Yup.object().shape({
        multipleEmails: controleContentValidate(t('controleErrors.required'), { value: 4, message: t('controleErrors.min').replace('{min}', '4') }, { value: 200, message: t('controleErrors.max').replace('{max}', '200') }, { patternType: 'multiEmail', message: t('controleErrors.patterninvalid') })
    });

    const closeModal = () => dispatch(setNotificationEmailModalBody(''));

    const validateTestData = (multipleEmailsData) => {
        let data = {
            destinations: [multipleEmailsData],
            message: testModalData
        }
        dispatch(testNotificationMailRequest(data));
    }

    return (
        <Formik
            enableReinitialize
            initialValues={{ multipleEmails: '' }}
            validationSchema={validationSchema}
            onSubmit={(values) => console.log('values => ', values)}
        >
            {({ errors, touched, values }) => (
                <Form>
                    <Modal className="modal-md msgdisplay" isOpen={testModalData ? true : false} toggle={() => { }} >
                        <div className="Clos">
                            <button onClick={closeModal} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <ModalBody className="pt-0">
                            <div className="msgcontent px-2">
                                <FormGroup>
                                    <Label>{t('NotificationEmail.emailId')}</Label>
                                    <Field as="textarea" rows="4" name="multipleEmails" placeholder={t('NotificationEmail.emailId')} className={'form-control ' + (errors.multipleEmails && touched.multipleEmails ? 'is-invalid' : '')} />
                                    <ErrorMessage name="multipleEmails" component="div" className="invalid-feedback" />
                                </FormGroup>
                                <span className="note">{t('NotificationEmail.note')}</span>
                                <div className="mt-4">
                                    <button type="submit" className="btn btn-primary mr-3" onClick={() => {
                                        if (!errors.multipleEmails)
                                            validateTestData(values.multipleEmails);
                                    }}>
                                        {t('NotificationEmail.send')}
                                    </button>
                                    <button type="button" className="btn btn-cancel" onClick={closeModal}>
                                        {t('ActionNames.cancel')}
                                    </button>
                                </div>
                            </div>
                        </ModalBody>
                    </Modal>
                </Form>
            )}
        </Formik>
    )
}
export default React.memo(NFEmailTestModal);