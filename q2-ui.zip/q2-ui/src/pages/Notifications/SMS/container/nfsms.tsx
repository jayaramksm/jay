import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import '../../Container/notifications.css';
import { SuperParentContext } from './nfsmscontext';
import { IActions } from '../../../../models/utilitiesModel';
import { INotificationSMSModel } from '../../../../models/notificationSmsModel'
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../../helpers/helpersIndex';
import { getNotificationSmsDataRequest, setResetForNotificationSms, cancelAllPendingNotificationSmsRequests } from '../../../../store/actions';
import {
    SmsAutoRefresh, NFSmsParent, SmsManager, NFSmsAction, SmsTestModel,Nfsmsview
} from './nfsmsindex';

export interface IProps {
    activateAuthLayout: any;
    smsLoad: boolean;
    getNotificationSmsDataRequest: any;
    setResetForNotificationSms: any;
    cancelAllPendingNotificationSmsRequests: any;
    add: boolean;
    edit: boolean;
    status: boolean;
}
class SMS extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props)
        this.state = {
            managerComponent: SmsManager,
            actionComponent: NFSmsAction,
            testModelComponent: SmsTestModel,
            viewcomponent :Nfsmsview,
            actions: { add: this.props.add, edit: this.props.edit,status: this.props.status  }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForNotificationSms();
        if (this.props.smsLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getNotificationSmsDataRequest(!this.props.smsLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getNotificationSmsDataRequest(!this.props.smsLoad, true);
    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.cancelAllPendingNotificationSmsRequests();
        this.props.setResetForNotificationSms();
    }

    render() {
        return (
            <>
                {getAutoRefresing() && <SmsAutoRefresh />}
                <Container fluid className="h-100">
                    <SuperParentContext.Provider value={this.state}>
                        <NFSmsParent />
                    </SuperParentContext.Provider>
                </Container>
            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit','status'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'sms', defaultPrivilages);
    if (getAutoRefresing() && state.notificationSmsReducer && (state.notificationSmsReducer as INotificationSMSModel).smsNotificationData)
        return { smsLoad: ((state.notificationSmsReducer as INotificationSMSModel).smsNotificationData?.length > 0 ? true : false), loginUserRolecode: loginUserRolecode,
             add: privileges.includes(IActions.CREATE),
              edit: privileges.includes(IActions.EDIT),
              status: privileges.includes(IActions.STATUS) };
    else
        return { smsLoad: false, loginUserRolecode: loginUserRolecode, 
            add: privileges.includes(IActions.CREATE), 
            edit: privileges.includes(IActions.EDIT),
            status: privileges.includes(IActions.STATUS) };
}
export default connect(mapStatetoProps, { activateAuthLayout, getNotificationSmsDataRequest, setResetForNotificationSms, cancelAllPendingNotificationSmsRequests })(SMS);
