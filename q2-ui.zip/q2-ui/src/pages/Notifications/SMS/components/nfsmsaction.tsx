import React from 'react';
import '../../Container/notifications.css';
import { Row, Col, FormGroup, Label, Card, CardBody } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import {
    setNotificationSmsActionRequestData, testModelNotificationSmsRequest,
    createOrEditNotificationSmsRequest
} from '../../../../store/actions';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import { controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { INotificationSMSModel, ISmsNotification, ITrigger, IParam } from '../../../../models/notificationSmsModel';


export interface optionsData {
    value: any;
    label: any;
}

const NFSmsAction: React.FC = () => {

    const myRef: any | undefined = React.useRef();
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const smsData: ISmsNotification[] = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.smsNotificationData)
            return (state.notificationSmsReducer as INotificationSMSModel).smsNotificationData;
        else return undefined;
    });
    const smsActionData: ISmsNotification = useSelector(state => {
        if (state && state.notificationSmsReducer)
            return (state.notificationSmsReducer as INotificationSMSModel).actionData ? (state.notificationSmsReducer.actionData) : undefined;
        else return undefined;
    });

    const triggerData = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.triggerData)
            return (state.notificationSmsReducer as INotificationSMSModel).triggerData;
        else return [];
    });
    const actionType = useSelector(state => {
        if (state && state.notificationSmsReducer)
            return (state.notificationSmsReducer as INotificationSMSModel).actionType ? (state.notificationSmsReducer.actionType) : 0;
        else return 0;
    });
    console.log("triggerData =>", smsData, smsActionData, actionType, triggerData);

    const msgFieldSelection = (value, setFieldValue) => {
        setFieldValue('msgField', value);
    }

    const addMsgField = (values, setFieldValue) => {
        console.log("addMsgField =>values", values);
        console.log("addMsgField =>ref", myRef.current, values, setFieldValue);
        if (myRef && myRef.current && values.msgField) {
            console.log("addMsgField ==>s", myRef.current.selectionStart);
            console.log("addMsgField ==>e", myRef.current.selectionEnd);
            let msg = values.smsTxt;
            let option = "<$" + values.msgField.label + "$>";
            msg = msg.substring(0, myRef.current.selectionStart) + option + msg.substring(myRef.current.selectionEnd, msg.length);
            console.log("addMsgField =>msg ", msg, option);
            setFieldValue('smsTxt', msg);
        }
    }


    const checkTrigger = (triggerId) => {
        let index;
        if (smsData)
            index = smsData.findIndex(x => x.triggerId === triggerId);
        return index !== -1 ? true : false
    }


    return (
        <>
            <Formik
                enableReinitialize
                initialValues={{
                    notificationSmsId: smsActionData ? smsActionData.notificationSmsId : 0,
                    templateName: smsActionData ? smsActionData.templateName : '',
                    smsTxt: smsActionData ? smsActionData.smsTxt : '',
                    triggerId: smsActionData ? smsActionData.triggerId : '',
                    msgField: ''
                }}
                validationSchema={Yup.object().shape({
                    templateName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
                    smsTxt: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 1000, 1),
                    triggerId: controleContentValidate(t('controleErrors.required')),
                })}
                onSubmit={(values, { resetForm }) => {
                    console.log("Values =>", values);
                    let smsDataRequest = {
                        notificationSmsId: values.notificationSmsId,
                        smsTxt: values.smsTxt,
                        templateName: values.templateName,
                        triggerId: +values.triggerId
                    } as ISmsNotification;
                    console.log("onSubmit_Dispatch =>", smsDataRequest);
                    dispatch(createOrEditNotificationSmsRequest(actionType, smsDataRequest));
                }}
            >
                {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (

                    <div className="flexLayout pb-3">
                        <div className="flexLayout-inner">
                            <div className="pr-3">

                                <Form>
                                    <Row className="mx-0">
                                        <Col sm="7" className="px-0">
                                            <div className="mb-4">
                                                <h6>{t('NotificationSms.messageBuilder')}</h6>
                                            </div>
                                            <Row className="mx-0">
                                                <Col sm="5" className="pl-0">
                                                    <FormGroup>
                                                        <Label>{t('NotificationSms.templateName')}</Label>
                                                        <Field name="templateName" placeholder={t('NotificationSms.templateName')}
                                                            className={'form-control ' + (errors.templateName && touched.templateName ? 'is-invalid' : '')} />
                                                        <ErrorMessage name="templateName" component="div" className="invalid-feedback" />
                                                    </FormGroup>
                                                </Col>

                                                <Col></Col>

                                            </Row>
                                            <Row className="mx-0">
                                                <Col sm="5" className="pl-0">
                                                    <FormGroup>
                                                        <Label>{t('NotificationSms.messageField')}</Label>
                                                        <MySelect
                                                            name="msgField"
                                                            placeholder={t('NotificationSms.selectMessageField')}
                                                            value={values.msgField}
                                                            onChange={(e) => msgFieldSelection(e, setFieldValue)}
                                                            options={
                                                                triggerData.filter((x: ITrigger) => x.triggerId === +values.triggerId)[0] ? triggerData.filter(x => x.triggerId === +values.triggerId)[0].params.map((item: IParam) => ({ value: item.paramName, label: item.paramName })) : []
                                                            }
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            onBlur={() => setFieldTouched('msgField', true)}
                                                            noOptionsMessage={() => t('NotificationSms.noMsgField')}
                                                        />
                                                        {/* {errors.msgField && touched.msgField && (
                                                <div style={{ color: "red", marginTop: ".5rem" }}>{errors.msgField}
                                                </div>
                                            )} */}
                                                        {!values.triggerId && touched.msgField && (
                                                            <div className="error-msg">{t('NotificationSms.plsSelectTriggerFst')}
                                                            </div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                                {values.msgField && <Col className="align-left">
                                                    <button type="button" className="btn btn-primary mt-2" onClick={() => addMsgField(values, setFieldValue)}>
                                                        {t('ActionNames.add')}
                                                    </button>
                                                </Col>}
                                            </Row>
                                            <Row className="mx-0">
                                                <Col className="msgcontent pl-0" sm="11">
                                                    <FormGroup>
                                                        <Label>{t('NotificationSms.messageContent')}</Label>
                                                        {/* <Input type="textarea"  name="smsTxt" onChange={(e)=>setFieldValue('smsTxt', e.target.value)}  ref={myRef} rows={10} id="exampleText" /> */}
                                                        <textarea name="smsTxt" className="w-100"
                                                            id="exampleText"
                                                            value={values.smsTxt}
                                                            onChange={(e) => setFieldValue('smsTxt', e.target.value)}
                                                            ref={myRef}
                                                            onBlur={() => setFieldTouched('smsTxt', true)}
                                                        />
                                                        <span className="align-right">{1000 - values.smsTxt.length} {t('NotificationSms.charactersRemaining')} </span>

                                                        {errors.smsTxt && touched.smsTxt && (
                                                            <div className="error-msg mt-0">{errors.smsTxt}
                                                            </div>
                                                        )}
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <div className="mt-3 mb-3">
                                                <button className="btn btn-primary mr-3" disabled={!(dirty)}>
                                                    {actionType === IOprationalActions.ADD ? t('ActionNames.save') : t('ActionNames.update')}
                                                </button>
                                                <button disabled={!((values.smsTxt).trim().length > 1)} type="button" className="btn btn-test mr-3" onClick={() => dispatch(testModelNotificationSmsRequest(values.smsTxt))}>
                                                    {t('NotificationSms.test')}
                                                </button>
                                                <button type="button" className="btn btn-cancel" onClick={() => dispatch(setNotificationSmsActionRequestData(0, null, false))}>
                                                    {t('NotificationSms.discard')}
                                                </button>
                                            </div>

                                        </Col>
                                        <Col sm="5">
                                            <div className="configCard">
                                                <Card>
                                                    <CardBody>
                                                        <div>
                                                            <h6>{t('NotificationSms.triggerConfiguration')}</h6>
                                                        </div>
                                                        {triggerData && smsData && actionType === IOprationalActions.ADD && triggerData.length === smsData.length && <span className="text-danger">{t('NotificationSms.noTriggersAvail')}</span>}
                                                        <hr />
                                                        {triggerData && triggerData.map((item, index) => {
                                                            return (
                                                                <React.Fragment key={index}>
                                                                    <Row className="mb-3">
                                                                        <Col>
                                                                            <div className="chkbox">
                                                                                <Field name="triggerId" type="radio"
                                                                                    disabled={actionType === IOprationalActions.EDIT || checkTrigger(item.triggerId)}
                                                                                    value={item.triggerId}
                                                                                    checked={+values.triggerId === item.triggerId}
                                                                                    onChange={() => {
                                                                                        setFieldValue('triggerId', item.triggerId);
                                                                                        setFieldValue('msgField', '');
                                                                                    }}
                                                                                    className={'mr-2' + (errors.triggerId && touched.triggerId ? ' is-invalid' : '')}
                                                                                />
                                                                                <label htmlFor="customCheck1" className="mb-0">{item.triggerName}</label>
                                                                            </div>
                                                                        </Col>
                                                                    </Row>
                                                                </React.Fragment>
                                                            )
                                                        })}
                                                        {errors.triggerId && touched.triggerId && (
                                                            <div style={{ color: "red", marginTop: ".5rem" }}>{errors.triggerId}
                                                            </div>
                                                        )}
                                                    </CardBody>
                                                </Card>
                                            </div>
                                        </Col>
                                    </Row>
                                </Form>
                            </div>
                        </div>
                    </div>

                )}
            </Formik>
        </>
    )
}
export default React.memo(NFSmsAction);