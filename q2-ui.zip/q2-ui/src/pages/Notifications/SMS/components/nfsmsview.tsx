import React, { useContext, useState, } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext } from '../container/nfsmscontext';
import { Row, Card, CardBody, Label, UncontrolledTooltip } from 'reactstrap';
import { INotificationSMSModel, ISmsNotification, ITrigger } from '../../../../models/notificationSmsModel';
import { useTranslation } from 'react-i18next';
import Switch from "react-switch";
import { IOprationalActions, IStatusEnum } from '../../../../models/utilitiesModel';
import { setNotificationSmsActionRequestData, updateSmsStatusRequest } from '../../../../store/actions';


const Nfsmsview: React.FC = () => {

    const { t } = useTranslation("translations");
    const context: any = useContext(ParentContext);
    const actions = useContext<any>(ParentContext)?.actions;
    const [toggleState, setToggleState] = useState(true);
    const dispatch = useDispatch();

    const editSmsNotification = (smsItemData) => {
        console.log("editSmsNotification =>", smsItemData);
        dispatch(setNotificationSmsActionRequestData(IOprationalActions.EDIT, smsItemData, true));
    }

    const smsItemData: ISmsNotification = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.smsNotificationData) {
            let data = (state.notificationSmsReducer as INotificationSMSModel).smsNotificationData;
            let index = data?.findIndex(x => x.notificationSmsId === context.data.notificationSmsId)
            if (index !== -1)
                return state.notificationSmsReducer.smsNotificationData[index] as ISmsNotification;
            else return undefined;
        }
        else return undefined;
    });
    const smsItemStatus: ISmsNotification = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.smsNotificationData) {
            let data = (state.notificationSmsReducer as INotificationSMSModel).smsNotificationData;
            let index = data?.findIndex(x => x.notificationSmsId === context.data.notificationSmsId)
            if (index !== -1)
                return (state.notificationSmsReducer.smsNotificationData[index] as ISmsNotification).status === IStatusEnum.NACTIVE ? true : false;
            else return undefined;
        }
        else return undefined;
    });

    const triggerData: ITrigger[] = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.triggerData)
            return (state.notificationSmsReducer as INotificationSMSModel).triggerData;
        else return [];
    });
    return (
        <>

            {smsItemData && <div className="customCard viewCard">
                <Card>
                    <CardBody>
                        <div className="align-right">
                            {context.actions.edit && <>
                                <i id="edit" className="ti-pencil-alt mr-2 pointer" onClick={() => editSmsNotification(smsItemData)} ></i>
                                <UncontrolledTooltip color="primary" placement="top" target="edit">
                                    {t('ActionNames.edit')}
                                </UncontrolledTooltip>
                            </>}
                            {actions.status && toggleState && <Switch uncheckedIcon={<Offsymbol />}
                                checkedIcon={<OnSymbol />} onColor="#02a499"
                                onChange={(e) => {
                                    let updatedStatus = e === true ? IStatusEnum.NACTIVE : IStatusEnum.NINACTIVE;
                                    const confirmMessage = t('NotificationSms.confirmMessages.NSMC2').replace('{sms}', smsItemData?.templateName).replace('{status}', smsItemData.status === IStatusEnum.NACTIVE ? t('ActionNames.deactivate') : t('ActionNames.activate'));
                                    dispatch(updateSmsStatusRequest(smsItemData.notificationSmsId, updatedStatus, false, confirmMessage));
                                    setTimeout(() => {
                                        setToggleState(false);
                                        setToggleState(true);
                                    }, 1000);
                                }}
                                checked={(smsItemData?.status === IStatusEnum.NACTIVE ? true : false)} />
                            }

                        </div>
                        <div>

                        </div>
                        <div>
                            <Label>{t('NotificationSms.templateName')}</Label><br />
                            <span>{smsItemData.templateName}</span>
                        </div>

                        <div>
                            <Label>{t('NotificationSms.triggerName')}</Label><br />
                            <span>{triggerData && triggerData.find(y => y.triggerId === smsItemData?.triggerId)?.triggerName}</span>
                        </div>

                    </CardBody>
                </Card>
            </div>}
        </>
    )

}
const Offsymbol = () => {
    return (
        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
                fontSize: 12,
                color: "#fff",
                paddingRight: 2
            }} >
        </div>
    );
};
const OnSymbol = () => {
    return (
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: 12,
            color: "#fff",
            paddingRight: 2
        }}>
        </div>
    );
}
export default React.memo(Nfsmsview);