import React, { useContext } from 'react';
import { SuperParentContext } from '../container/nfsmscontext';
import { INotificationSMSModel } from '../../../../models/notificationSmsModel';
import { useSelector } from 'react-redux';
import { IOprationalActions } from '../../../../models/utilitiesModel';

const NFSmsParent: React.FC = () => {
    const context: any = useContext(SuperParentContext);

    const actionType = useSelector(state => {
        if (state && state.notificationSmsReducer)
            return (state.notificationSmsReducer as INotificationSMSModel).actionType;
        else return 0;
    });
    console.log("NFSmsParent =>", actionType);

    return (
        <>
            { (actionType !== IOprationalActions.ADD && actionType !== IOprationalActions.EDIT) && <context.managerComponent />}
            { (actionType === IOprationalActions.ADD || actionType === IOprationalActions.EDIT) && <context.actionComponent />}
            <context.testModelComponent />
        </>
    )
}

export default React.memo(NFSmsParent);