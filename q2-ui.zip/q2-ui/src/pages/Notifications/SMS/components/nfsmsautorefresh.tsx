import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../../Container/notifications.css';
import { getNotificationSmsDataRequest } from '../../../../store/actions';
import { INotificationSMSModel } from '../../../../models/notificationSmsModel';
import { UncontrolledTooltip } from 'reactstrap'
import { useTranslation } from 'react-i18next';

export const SmsAutoRefresh: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const refreshLoading = useSelector(state => {
        if (state && state.notificationSmsReducer)
            return (state.notificationSmsReducer as INotificationSMSModel).refreshLoading
        else
            return false;
    });

    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="Utooltip" onClick={() => dispatch(getNotificationSmsDataRequest(true, true))}></i>
                <UncontrolledTooltip color="primary" placement="top" target="Utooltip">
                    {t('ActionNames.autoRefresh')}
                </UncontrolledTooltip></>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>}
            </div>
        </>
    )
}