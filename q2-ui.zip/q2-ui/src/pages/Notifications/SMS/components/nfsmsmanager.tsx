import React, { useState, useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../../Container/notifications.css';
import { SuperParentContext,ParentContext } from '../container/nfsmscontext';
import { Row, Card, CardBody, Label, UncontrolledTooltip } from 'reactstrap';
import addIcon from '../../../../images/icons/addicon.svg';
import { INotificationSMSModel, ISmsNotification, ITrigger } from '../../../../models/notificationSmsModel';
import { useTranslation } from 'react-i18next';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import { PaginationComponent } from '../../../Utilities/PaginationComponent';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { setNotificationSmsPagination, setNotificationSmsActionRequestData } from '../../../../store/actions';

const SmsManager: React.FC = () => {

    const [searchKey, setSearchKey] = useState('');
    const { t } = useTranslation("translations");
    const context: any = useContext(SuperParentContext);
    console.log("SmsManager =>", context);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageSize + (context?.actions?.add ? 0 : 1);

    const smsData: ISmsNotification[] = useSelector(state => {
        if (state && state.notificationSmsReducer)
            return (state.notificationSmsReducer as INotificationSMSModel).smsNotificationData ? (state.notificationSmsReducer.smsNotificationData) : undefined;
        else return undefined;
    });
    const smsDataCount = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.smsNotificationData)
            return (state.notificationSmsReducer as INotificationSMSModel).smsNotificationData.length;
        else return 0;
    });
    const triggerData: ITrigger[] = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.triggerData)
            return (state.notificationSmsReducer as INotificationSMSModel).triggerData;
        else return [];
    });
    console.log("smsDataCount =>", smsData, smsDataCount, triggerData);

    const actionType = useSelector(state => {
        if (state && state.notificationSmsReducer)
            return (state.notificationSmsReducer as INotificationSMSModel).actionType;
        else return false;
    });
    console.log("SmsManager =>", actionType);

    let currentPage = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.smsCurrentPage)
            return (state.notificationSmsReducer as INotificationSMSModel).smsCurrentPage;
        else return 0;
    });

    let filterSmsData: ISmsNotification[] = (searchKey && searchKey !== '') ?
        smsData.filter(x => x.templateName.toLowerCase().startsWith(searchKey.toLowerCase())) : smsData;

    let pagesCount = Math.ceil((filterSmsData ? filterSmsData.length : 0) / pageSize);

    if (currentPage >= pagesCount && pagesCount !== 0)
        currentPage = 0;

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setNotificationSmsPagination(index));
    }
    const setSearch = (key) => {
        console.log("setSearch =>", key);
        setSearchKey(key);
    }


    return (
        <>
            {smsData && smsData.length > 0 && <Row>
                <div className="app-search wi-30 p-0 form-group mb-0 mt-3 pl-3">
                    <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={e => setSearch(e.target.value)} />
                    <i className="fa fa-search"></i>
                </div>
            </Row>}

            <div className="flexLayout pb-3">
                <div className="flexLayout-inner">
                    <div className="p-2 pl-3">
                        <Row className="mt-4">
                            {context.actions.add && <div className="customCard addCustomCard">
                                <Card onClick={() => dispatch(setNotificationSmsActionRequestData(IOprationalActions.ADD, null, true))}>
                                    <CardBody>
                                        <span>{t('NotificationSms.addTemplate')} &nbsp;<img src={addIcon} alt="" /></span>
                                    </CardBody>
                                </Card>
                            </div>}


                            {filterSmsData && filterSmsData.length > 0 && filterSmsData.slice(currentPage * pageSize,
                                (currentPage + 1) * pageSize)
                                .map((x, index) => {
                                    return (
                                        <ParentContext.Provider  key={index} value={{ data: x, actions: context.actions }}>
                                              <context.viewcomponent  />
                                        </ParentContext.Provider>
                                      
                                    )
                                })
                            }
                            {filterSmsData && searchKey === '' && filterSmsData.length === 0 && <span>{t('NotificationSms.noSMSDataFound')}</span>}
                            {filterSmsData && searchKey !== '' && filterSmsData.length === 0 && <span>{t('NotificationSms.noSmsSearchDataFound')}</span>}
                        </Row>
                    </div>
                </div>


                {
                    filterSmsData && filterSmsData.length > pageSize && <Row className="justify-content-end lft-pagination">
                        <div className="pagination ml-3">
                            <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                        </div>
                    </Row>
                }
            </div>
        </>
    )
}
export default React.memo(SmsManager);