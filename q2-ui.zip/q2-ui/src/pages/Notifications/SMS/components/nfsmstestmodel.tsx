import React from 'react';
import '../../Container/notifications.css';
import { Row, Col, FormGroup, Label, Modal, ModalBody } from 'reactstrap';
import phone from '../../../../images/phone.png';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import { controleContentValidate } from '../../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { INotificationSMSModel } from '../../../../models/notificationSmsModel';
import { testModelNotificationSmsRequestSuspend, testMobileSmsRequest } from '../../../../store/actions';
import Scrollbars from 'react-custom-scrollbars';
const SmsTestModel: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const smsContent = useSelector(state => {
        if (state && state.notificationSmsReducer && state.notificationSmsReducer.smsTextContent)
            return (state.notificationSmsReducer as INotificationSMSModel).smsTextContent;
        else return undefined;
    });

    return (
        <>
            <Modal className="modal-lg msgdisplay" isOpen={smsContent ? true : false} toggle={() => { }} >
                <div className="Clos">
                    <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={() => dispatch(testModelNotificationSmsRequestSuspend())}>
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <ModalBody className="pt-0">
                    <div>
                        <Row>
                            <Formik
                                enableReinitialize
                                initialValues={{
                                    mobileNo: ''
                                }}
                                validationSchema={Yup.object().shape({
                                    mobileNo: controleContentValidate(t('controleErrors.required'), { value: 10, message: t('controleErrors.min').replace('{min}', '10') }, { value: 150, message: t('controleErrors.max').replace('{max}', '150') }, { patternType: 'comaSaparateMobileNumber', message: t('controleErrors.patterninvalid') })
                                })}
                                onSubmit={(values, { resetForm }) => {
                                    console.log("Values =>", values);
                                    let reqObj = {
                                        destinations: values.mobileNo.split(','),
                                        message: smsContent
                                    }
                                    console.log("onSubmit_Dispatch =>", reqObj);
                                    dispatch(testMobileSmsRequest(reqObj));
                                }}
                            >
                                {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                                    <Form>
                                        <Col className="msgcontent pl-4">
                                            <FormGroup>
                                                <Label>{t('NotificationSms.mobileNumber')}</Label>
                                                <Field as="textarea" name="mobileNo"
                                                    rows="6" id="exampleText"
                                                    placeholder={t('NotificationSms.mobileNumber')}
                                                    className={'form-control ' + (errors.mobileNo && touched.mobileNo ? 'is-invalid' : '')}
                                                />
                                                <ErrorMessage name="mobileNo" component="div" className="invalid-feedback" />
                                            </FormGroup>
                                            <span className="note">{t('NotificationSms.noteMobileMsg')}</span>
                                            <div className="sendbtns">
                                                <button className="btn btn-primary mr-3">
                                                    {t('NotificationSms.send')}
                                                </button>
                                                <button type="button" className="btn btn-cancel" onClick={() => dispatch(testModelNotificationSmsRequestSuspend())}>
                                                    {t('ActionNames.cancel')}
                                                </button>
                                            </div>
                                        </Col>
                                    </Form>
                                )}
                            </Formik>
                            <Col className="text-center">
                                <div className="phoneimg">
                                    <img src={phone} alt="" />
                                    <div className="phonemsg pl-1 py-3" style={{ maxHeight: "260px" }}>
                                        <Scrollbars>
                                            <span>{smsContent}</span>
                                        </Scrollbars>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </div>
                </ModalBody>
            </Modal>
        </>
    )
}
export default React.memo(SmsTestModel);