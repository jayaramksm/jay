import * as React from 'react';
import { connect } from 'react-redux';
import { Container, Row, Col } from 'reactstrap';
import { getCareMapDataRequest, activateCareAuthLayout } from '../../../store/actions';
import logo from "../../../images/firstpasslogo.svg";
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
    BreadcrumbView,
    Cam,
    View,
    Serving,
    Waiting,
    CareMapView,
    LeftCareMapParent,
    RightCareMapParent,
    TokenDetailParent
} from './caremapindex';
import { SuperParentContext } from './caremapcontext';

interface IProps {
    getCareMapDataRequest: any;
    activateCareAuthLayout: any;
}
class CareMap extends React.Component<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {
            leftCareMapView: {
                breadcrumbView: BreadcrumbView,
                caremapView: CareMapView
            },
            rightCareMapView: {
                camView: Cam,
                servingParent: TokenDetailParent,
                servingView: Serving,
                waitingView: Waiting,
                tokenDetailsView: View
            },
        }
    }

    componentDidMount() {
        this.props.activateCareAuthLayout();
        this.props.getCareMapDataRequest();
    }

    render() {
        return (
            <Container fluid>
                <Row className="header">
                    <Col className="align-left">
                        <img src={logo} alt="" width="135px" />&nbsp;
                        <div className="crmpalign"> caremaps</div>
                    </Col>
                    <Col className="align-right">
                        <span>23/07/2020 12:57 PM</span>
                    </Col>
                </Row>
                <Row className="content-container">
                    <div className="Logobtm mt-2">
                        <Col sm="8">
                            <SuperParentContext.Provider value={this.state.leftCareMapView}>
                                <LeftCareMapParent />
                            </SuperParentContext.Provider>
                        </Col>

                        <Col sm="4" className="actnview">
                            <PerfectScrollbar style={{ height: '85vh', padding: '0 36px 0 0' }}>
                                <SuperParentContext.Provider value={this.state.rightCareMapView}>
                                    <RightCareMapParent />
                                </SuperParentContext.Provider>
                            </PerfectScrollbar>
                        </Col>
                    </div>
                </Row>
                <div className="copyright">&copy; Vectramind Corporation 2021</div>
            </Container>
        )
    }
}
export default (connect(null, { activateCareAuthLayout, getCareMapDataRequest })(CareMap));
