import React from 'react';
import { useSelector } from 'react-redux';
import * as _ from 'lodash';
import { ICareMapOperations } from 'models/caremapmodel';

const BreadcrumbView: React.FC = () => {
    const breadcrumbData = useSelector(state => {
        if (state && state.careMapReducer && state.careMapReducer.breadcrumbData)
            return state.careMapReducer.breadcrumbData;
        else return [];
    });
    console.log('breadcrumbData ==> ', breadcrumbData);
    return (
        
        <span className='brdcrmb'>
        <h6>
            {_.join(breadcrumbData.filter(x => x.level !== ICareMapOperations.TOKEN).map(x => x.name), '/ ')}</h6>
        </span>
    )
}
export default React.memo(BreadcrumbView);