import React from 'react';
import { useSelector } from 'react-redux';
import { Card, CardBody, Row, Col } from 'reactstrap';
import { IBreadcrumbData } from '../../../models/caremapmodel';
// import { SuperParentContext } from '../container/caremapcontext';
// import TimeLineChart from '../../../charthelpers/timelinechart';
import journeymap from '../../../images/patient-journey.svg';
import user from '../../../images/user.png';

const Serving: React.FC<any> = () => {

  // const context = useContext(SuperParentContext);
  const currentLevelData: IBreadcrumbData = useSelector(state => {
    if (state && state.careMapReducer.breadcrumbData) {
      let breadcrumbData = state.careMapReducer.breadcrumbData;
      return breadcrumbData[breadcrumbData.length - 1];
    }
    else return undefined;
  });

  console.log('Serving', currentLevelData);
  var deptType = currentLevelData.data ? currentLevelData.data.parent.parent.parent.parent.deptType : 4;
  deptType = deptType ? deptType : 4

  return (
    <div className="totaldiv">
      <section className="child">
        {currentLevelData && <div>
          <h6>Patients In Care</h6>
          <Card className="datacard no-radius" style={{ width: "100%" }}>
            <CardBody>
              <Row style={{ position: 'relative' }}>
                <Col sm="10" className="patient-in-care">
                  <h6 className="mt-0">MRN : {currentLevelData.data.mrn}</h6>
                  {/* <table className="details" cellSpacing="0">
                    <tr>
                      <td>Patient Name</td>
                      <td>{currentLevelData.data.name}{deptType}</td>
                    </tr>
                    <tr>
                      <td>Token No</td>
                      <td>{currentLevelData.data.token}</td>
                    </tr>
                    { deptType === 1  && 
                      <tr>
                      <td>Counter No</td>
                      <td>C12</td>
                    </tr>}
                    { deptType === 1  && 
                      <tr>
                      <td>Pharmacist Name</td>
                      <td>Riaz</td>
                    </tr>}
                    { deptType !== 1  && 
                      <tr>
                      <td>Appointment Time</td>
                      <td>05-06-20202 15:30 PM</td>
                    </tr>}
                    { deptType !== 1  && 
                      <tr>
                      <td>Check-In Time</td>
                      <td>05-06-20202 15:30 PM</td>
                    </tr>}
                    { deptType !== 1  && 
                      <tr>
                      <td>Doctor Name</td>
                      <td>XXXXXXXXXX</td>
                    </tr>}
                    { deptType !== 1  && 
                      <tr>
                      <td>Nurse Name</td>
                      <td>XXXXXXXXXX</td>
                    </tr>}
                  </table> */}
                  {/* <p>
                  <span>Patient Name : {currentLevelData.data.name}{deptType}</span>
                  <span>Token No : {currentLevelData.data.token}</span>
                
                  { deptType === 1  && <> <span>Counter No: C12</span></>}
                  { deptType === 1  && <> <span>Pharmacist Name: Riaz</span></>}

                  { deptType !== 1  && <> <span>Appointment Time : 05-06-20202 15:30 PM</span></>}
                  { deptType !== 1  && <> <span>Check-In Time : 05-06-20202 15:30 PM</span></>}
                  { deptType !== 1  && <> <span>Doctor Name : XXXXXXXXXX</span></>}
                  { deptType !== 1  && <> <span>Nurse Name : XXXXXXXXXX</span></>}
                  </p> */}
                  <div className="details">
                    <dl>
                      <dt>Patient Name</dt>
                      <dd>{currentLevelData.data.name}{deptType}</dd>
                    </dl>
                    <dl>
                      <dt>Token No</dt>
                      <dd>{currentLevelData.data.token}</dd>
                    </dl>
                    {deptType === 1 &&
                      <dl>
                        <dt>Counter No</dt>
                        <dd>C12</dd>
                      </dl>
                    }
                    {deptType === 1 &&
                      <dl>
                        <dt>Pharmacist Name</dt>
                        <dd>Riaz</dd>
                      </dl>
                    }
                    {deptType !== 1 &&
                      <dl>
                        <dt>Appointment Time</dt>
                        <dd>05-06-20202 15:30 PM</dd>
                      </dl>
                    }
                    {deptType !== 1 &&
                      <dl>
                        <dt>Check-In Time</dt>
                        <dd>05-06-20202 15:30 PM</dd>
                      </dl>
                    }
                    {deptType !== 1 &&
                      <dl>
                        <dt>Doctor Name</dt>
                        <dd>XXXXXXXXXX</dd>
                      </dl>
                    }
                    {deptType !== 1 &&
                      <dl>
                        <dt>Nurse Name</dt>
                        <dd>XXXXXXXXXX</dd>
                      </dl>
                    }
                  </div>

                  {/* deptType !== 1  && <> <span>Wait Time : {currentLevelData.data.time} Min</span><br/></> */}
                  {/* deptType !== 1  && <> <span>Serving Time : 25 Min</span><br/></> */}
                  {/* deptType !== 1  && <> <span>Total journey Time : { currentLevelData.data.time} Min</span><br/></>*/}
                  { /*deptType !== 1  && <> <span>Priority : {currentLevelData.data.priority === 1 ? 'High Priority' : 'Low Priority'}</span><br /></> */}
                  {/*  <button className="btn btn-active mt-3">End Serving</button> */}
                  {/* <div className="mt-2 serv-btn">
                    <button className="btn blue mr-2">Assign Priority</button>
                    <button className="btn green">Serve Token</button>
                   </div>*/}
                </Col>
                {/* <Col sm="2">
                  <img src={user} alt="" style={{position:'relative',right:'20px'}} />
                </Col> */}
                <img src={user} alt="" style={{ position: 'absolute', right: '20px', top: '0' }} />
              </Row>
            </CardBody>
          </Card>
          {/* <TimeLineChart data={currentLevelData.data} /> */}
        </div>
        }
      </section>
      <section className="child">
        {currentLevelData &&
          <div className="jrnymap" style={{ width: "100%" }}>
            <h6>Journey Map <span className="pt-2"><i className="ti-fullscreen"></i></span></h6>
            <Card className="datacard no-radius" style={{ width: "100%" }}>
              <CardBody>
                <Row>
                  <img src={journeymap} alt="" />
                </Row>
              </CardBody>
            </Card>
          </div>
        }
      </section>
    </div>
  )
}
export default React.memo(Serving);