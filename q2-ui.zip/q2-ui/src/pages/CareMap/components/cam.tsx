import React, { useRef } from 'react';
import { useSelector } from 'react-redux';
import { IBreadcrumbData } from '../../../models/caremapmodel';
import ReactPlayer from 'react-player';
import { Col, Row } from "reactstrap";

const Cam: React.FC<any> = () => {
    var data;

    const reactPlayerRef = useRef<any>();
    const currentLevelData: IBreadcrumbData = useSelector(state => {
        if (state && state?.careMapReducer?.breadcrumbData) {
            let breadcrumbData = state.careMapReducer.breadcrumbData;
            data = breadcrumbData;
            return breadcrumbData[breadcrumbData.length - 1];
        }
        else return undefined;
    });

    var length = data.length;
    var number = Math.random() * 100;
    var totApps = Math.round(number / length);
    var checkIn = number <= 10 ? 0 : Math.round((number - 10) / length);

    var avgWTime = Math.round(25 / length);

    var avgSTime = Math.round(20 / length);
    console.log('breadcrumbData 12 length=>', length, totApps, checkIn);

    // console.log('currentLevelData ==> ', currentLevelData);

    // useEffect(() => {
    //     return () => {
    //         if (reactPlayerRef.current) {
    //             if (reactPlayerRef.current?.player?.mounted)
    //                 reactPlayerRef.current.player.mounted = false;
    //             console.log('reactPlayerRef => ', reactPlayerRef.current?.player);
    //         }
    //     }
    // });


    return (
        <div>
            {currentLevelData && <h6 className="pb-2" style={{ margin: '10px 0 0 0' }}> {currentLevelData.name}</h6>}
            <Row>
                {/* <Col sm="12">
                    <Card className="crd-shdw mr-2  mt-3">
                        <CardBody>
                            <table className="count-tbl">
                                <tbody>
                                    <tr>
                                        <th>Counter</th>
                                        <th>Name</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                    </tr>
                                    <tr>
                                        <td><div className="btn btn-green btn-sm">Counter1</div></td>
                                        <td>Mohmad</td>
                                        <td>10:00 AM</td>
                                        <td>6:00 PM</td>
                                    </tr>
                                    <tr>
                                        <td><div className="btn btn-green btn-sm">Counter2</div></td>
                                        <td>Rhafee</td>
                                        <td>9:00 AM</td>
                                        <td>5:00 PM</td>
                                    </tr>
                                    <tr>
                                        <td><div className="btn btn-grey btn-sm">Counter3</div></td>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>
                                    </tr>
                                    <tr>
                                        <td><div className="btn btn-green btn-sm">Counter4</div></td>
                                        <td>Raheem</td>
                                        <td>11:00 AM</td>
                                        <td>6:00 PM</td>
                                    </tr>
                                </tbody>
                            </table>
                        </CardBody>
                    </Card>
                </Col> */}
                <Col>
                    <Row>
                        <Col sm="6" className="pr-0">
                            <div className="detailcard totalcard">
                                <Row className="align-center">
                                    <Col sm="8">Total Appointments</Col>
                                    <Col sm="4" className="align-center"><span>{totApps}</span></Col>
                                </Row>
                            </div>
                        </Col>
                        <Col sm="6">
                            <div className="detailcard avgcard">
                                <Row className="align-center">
                                    <Col sm="6" style={{ whiteSpace: "nowrap" }}>Avg.<br /> Wait Time</Col>
                                    <Col sm="6" style={{ whiteSpace: "nowrap" }} className="align-center"><span>{avgWTime}<small>min</small></span></Col>
                                </Row>
                            </div>
                        </Col>
                        <Col sm="6" className="pr-0">
                            <div className="detailcard totalcard">
                                <Row className="align-center">
                                    <Col sm="8">Patient Checked-In</Col>
                                    <Col sm="4" className="align-center"><span>{checkIn}</span></Col>
                                </Row>
                            </div>
                        </Col>
                        <Col sm="6">
                            <div className="detailcard">
                                <Row className="align-center">
                                    <Col sm="6" style={{ whiteSpace: "nowrap" }}>Avg.<br /> Care Time</Col>
                                    <Col sm="6" style={{ whiteSpace: "nowrap" }}><span> {avgSTime}</span> <small>min</small></Col>
                                </Row>
                            </div>
                        </Col>
                    </Row>
                    {/* <Card className="mr-2  mt-3 deptcard">
                       <CardBody className="p-0">
                           <Row className="m-0">
                               <Col sm="5" className="text-center p-4 lft-cardbg">
                                 <div>
                                    Total Appointments :
                                    <h3 className="m-0">30</h3>
                                </div><br/>
                                <div>
                                    <span>Checked In :</span>
                                    <h3 className="m-0">25</h3>
                                 </div>
                               </Col>
                               <Col sm="7" className="text-center p-4">
                                  <div>
                                    <span className="head1">Max Wait Time: </span>&nbsp;<span className='time'> 20 Min</span><br/>
                                    <span  className="head1">Min Wait Time: </span>&nbsp;<span  className='time'> 05 Min</span><br/>
                                    <span  className="head1"> Avg Wait Time: </span>&nbsp;<span className='time'> 10 Min</span><br/>
                                  </div><br/>
                                  <div>
                                    <span  className="head1">Max Serve Time: </span>&nbsp;<span className='time'> 30 Min</span><br/>
                                    <span  className="head1">Min Serve Time: </span>&nbsp;<span className='time'> 10 Min</span><br/>
                                    <span  className="head1">Avg Serve Time: </span>&nbsp;<span className='time'> 20 Min</span><br/>
                                  </div>
                               </Col>
                           </Row>
                       </CardBody>
                   </Card>  */}
                </Col>
                {currentLevelData &&
                    // <p><span className="text-primary">{camName.name}</span> Cam Component</p>
                    // Sub Cameras 
                    // <div>
                    // <button className="btn cm-btn"><img src={camera} alt="" />Camera1</button>
                    // <button className="btn cm-btn"><img src={camera} alt="" />Camera2</button>
                    // <button className="btn cm-btn"><img src={camera} alt="" />Camera3</button>
                    // <button className="btn cm-btn"><img src={camera} alt="" />Camera4</button>
                    // </div>
                    // <button className="btn cm-btn"><img src={camera} alt="" />View Camera</button>

                    // View Camera
                    <Col sm="12" className="video">
                        <Row>
                            {/* <Col sm="12" className="align-right mr-4 pr-4 mt-3">
                                <button className="btn close-btn mr-2" disabled={viewVideo} onClick={() => setViewVideo(true)}>View Video</button>
                                <button className="btn close-btn" onClick={() => {
                                if (viewVideo)
                                setViewVideo(false);
                                }}>Close</button>
                            </Col> */}
                            {/* {viewVideo && <img src={video} alt="" />} */}


                            <Col sm="12" className="pr-4 mt-2">
                                <h6> Cam Views</h6>
                                <ReactPlayer
                                    ref={reactPlayerRef}
                                    url='http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
                                    width="100%"
                                    height=""
                                    controls={true}
                                    playing={false}
                                    config={{
                                        file: {
                                            attributes: {
                                                controlsList: 'nodownload',
                                                disablePictureInPicture: true
                                            }
                                        }
                                    }}
                                />
                            </Col>
                        </Row>
                    </Col>
                }
            </Row>
        </div>
    )
}
export default React.memo(Cam);