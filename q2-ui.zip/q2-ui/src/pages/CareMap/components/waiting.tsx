import React from 'react';
import { Card, CardBody, Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { IBreadcrumbData } from '../../../models/caremapmodel';
// import TimeLineChart from '../../../charthelpers/timelinechart';
import { changeTokenPriorityRequest, serveTokenRequest } from '../../../store/actions';
import journeymap from '../../../images/patient-journey.svg';
import user from '../../../images/user.png';

const Waiting: React.FC<any> = () => {
    const dispatch = useDispatch();
    const currentLevelData: IBreadcrumbData = useSelector(state => {
        if (state && state.careMapReducer.breadcrumbData) {
            let breadcrumbData = state.careMapReducer.breadcrumbData;
            return breadcrumbData[breadcrumbData.length - 1];
        }
        else return undefined;
    });
    console.log('currentLevelData_waiting => ', currentLevelData);
    console.log('currentLevelData_waiting => ', currentLevelData.data.parent.parent.parent.parent.deptType);

    const changePriority = (tokenData) => {
        console.log('changePriority => ', tokenData);
        let confirmMsg = tokenData.priority === 1 ? `Do you want to set Low priority to ${tokenData.token}` : `Do you want to set High priority to ${tokenData.token}`;
        dispatch(changeTokenPriorityRequest(tokenData.mrn, tokenData.priority === 1 ? 0 : 1, false, confirmMsg));
    }

    const serveToken = (tokenData) => {
        console.log('serving_tokenData => ', tokenData);
        let confirmMsg = `Are you sure, you want to serve the token ${tokenData.token}`;
        dispatch(serveTokenRequest(tokenData.mrn, false, confirmMsg));
    }
    var deptType = currentLevelData.data ? currentLevelData.data.parent.parent.parent.parent.deptType : 4;
    deptType = deptType ? deptType : 4;

    return (
        <>  {console.log('deptType :', deptType)}
            {currentLevelData && <div>
                <h6>Patients in Waiting</h6>
                <Card className="datacard" style={{ width: "95%" }}>
                    <CardBody>
                        <Row>
                            <Col sm="10">
                                <h6 className="mt-0">MRN : {currentLevelData.data.mrn}</h6>
                                <span>Patient Name : {currentLevelData.data.name}</span><br />
                                <span>Token No : {currentLevelData.data.token}</span><br />
                                {/* <span>MRN : {currentLevelData.data.mrn}</span><br /> */}
                                {deptType !== 1 && <> <span>Appointment Time : 05-06-20202 15:30 PM</span><br /></>}
                                {deptType !== 1 && <> <span>Check-In Time : 05-06-20202 15:30 PM</span><br /></>}
                                {deptType !== 1 && <> <span>Doctor Name : XXXXXXXXXX</span><br /></>}
                                {deptType !== 1 && <> <span>Waiting time : {currentLevelData.data.time} Min</span><br /></>}
                                { /*deptType !== 1  && <> <span>Priority : {currentLevelData.data.priority === 1 ? 'High Priority' : 'Low Priority'}</span><br /></> */}
                                <div className="mt-2 serv-btn">
                                    {deptType !== 1 && <> <button style={{ margin: '5px' }} className="btn blue mr-2"
                                        onClick={() => changePriority(currentLevelData.data)}>
                                        {currentLevelData.data.priority === 1 ? 'Assign priority' : 'Assign priority'}
                                    </button> </>}
                                    {deptType !== 1 && <>
                                        <button className="btn green" style={{ margin: '5px' }}
                                            onClick={() => serveToken(currentLevelData.data)}>Serve Token</button> </>}

                                </div>
                                {/* 
                                <div className="mt-2 serv-btn">
                                <button className="btn blue mr-2">Assign Priority</button>
                                <button className="btn green">Serve Token</button>
                              </div>*/}
                            </Col>
                            <Col sm="2">
                                <img src={user} alt="" />
                            </Col>
                        </Row>
                    </CardBody>
                </Card>
                {/*<TimeLineChart data={currentLevelData.data} /> */}
            </div>}
            {currentLevelData &&
                <div className="jrnymap" style={{ width: "95%" }}>
                    <div>
                        <h6>Journey Map <span className="pt-2"><i className="ti-fullscreen"></i></span></h6>
                    </div>
                    <img src={journeymap} alt="" />
                </div>
            }
        </>
    )
}
export default React.memo(Waiting);