import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { ICareMapOperations, IBreadcrumbData } from '../../../models/caremapmodel';
import { SuperParentContext } from '../container/caremapcontext';

const RightCareMapParent: React.FC<any> = () => {
    const context = useContext(SuperParentContext);
    const currentLevelData: IBreadcrumbData = useSelector(state => {
        if (state && state?.careMapReducer?.breadcrumbData) {
            let breadcrumbData = state.careMapReducer.breadcrumbData;
            return breadcrumbData[breadcrumbData.length - 1];
        }
        else return undefined;
    });
    console.log('currentLevelData => ', currentLevelData);

    return (
        <>
            {currentLevelData && (currentLevelData.level !== ICareMapOperations.LOCATIONS && currentLevelData.level
                < ICareMapOperations.TOKENLEVEL) && <context.camView />}
            {(currentLevelData && currentLevelData.level === ICareMapOperations.TOKEN) && <context.servingParent />}
        </>
    )
}
export default React.memo(RightCareMapParent);