import React from 'react';
import { Card, CardBody } from 'reactstrap';

const View: React.FC<any> = ({ data }) => {
    return (
        <>
            {data && <div>
                <Card className="viewcard">
                    <CardBody>
                        <span>Patient Name : {data.name}</span><br />
                        <span>Token No : {data.token}</span><br />
                        <span>MRN : {data.mrn}</span><br />
                        <span>Appointment Time : 05-06-20202 15:30 PM</span><br />
                        <span>Check-In Time : 05-06-20202 15:30 PM</span><br />
                        <span>Doctor Name : XXXXXXXXXX</span><br />
                        <span>Waiting time : 30 Min</span><br />
                        <div className="btn btn-active mt-3">End Token</div>
                    </CardBody>
                </Card>
            </div>}
        </>
    )
}
export default React.memo(View);