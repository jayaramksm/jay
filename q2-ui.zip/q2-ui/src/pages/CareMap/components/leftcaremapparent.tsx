import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../container/caremapcontext';

const LeftCareMapParent: React.FC<any> = () => {
    const context = useContext(SuperParentContext);
    const isBreadcrumbDataExists = useSelector(state => {
        if (state && state.careMapReducer && state.careMapReducer.breadcrumbData)
            return state.careMapReducer.breadcrumbData.length > 0;
        else return false;
    });
    const isCareMapDataExists = useSelector(state => !!state?.careMapReducer?.caremapData);

    return (
        <>
            {isBreadcrumbDataExists && <context.breadcrumbView />}
            {isCareMapDataExists && <context.caremapView />}
        </>
    )
}
export default React.memo(LeftCareMapParent);