import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { IBreadcrumbData } from '../../../models/caremapmodel';
import { SuperParentContext } from '../container/caremapcontext';

const TokenDetailParent: React.FC<any> = () => {
    const context = useContext(SuperParentContext);
    const isServingToken: IBreadcrumbData = useSelector(state => {
        if (state && state.careMapReducer.breadcrumbData) {
            let breadcrumbData = state.careMapReducer.breadcrumbData;
            console.log('isServingToken name=> [', breadcrumbData[breadcrumbData.length - 2].name,']');
            return breadcrumbData.length > 2 ? 
            breadcrumbData[breadcrumbData.length - 2].name === 'Patients In Care' : false;
        }
        else return false;
    });
    console.log('isServingToken => ', isServingToken);

    return (
        <>
            {isServingToken ? <context.servingView /> : <context.waitingView />}
        </>
    )
}
export default React.memo(TokenDetailParent);