import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import TreeChart from '../../../charthelpers/treechart';
import { ICurrentNodeData } from '../../../models/caremapmodel';
import { selectNodeFromTree } from '../../../store/actions';

const CareMapView: React.FC = () => {
    const dispatch = useDispatch();
    const caremapData = useSelector(state => state?.careMapReducer?.caremapData);
    console.log('caremapData1 => ', caremapData);

    const click = (data: ICurrentNodeData, update) => {
        // console.log('clicked', update);
        dispatch(selectNodeFromTree(data, update));
    }

    return (
        <>  {console.log('CareMapView :', caremapData)}
            {caremapData && <TreeChart jsonData={caremapData} onClick={click} />}
        </>
    )
}
export default CareMapView;