import * as React from 'react';
import { Component } from 'react';
import { activateNonAuthLayout } from '../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import './predictiveinsight.css'
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { Scrollbars } from 'react-custom-scrollbars';
import { Row, Col, Card, CardBody, Container, } from 'reactstrap';
// import * as jsondata from './predictiveinsight.json';
import logo from "../../../images/firstpasslogo.svg";
import { predictiveInsightsDataRequest, cancelAllPendingPredictiveInsightsDataRequest } from '../../../store/actions';


ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);


interface IProps {
  predictiveInsightsDataRequest: any;
  cancelAllPendingPredictiveInsightsDataRequest: any;
  predictiveData: any;
  activateNonAuthLayout: any
}

class PredctiveInsight1 extends React.Component<IProps, any> {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    this.props.activateNonAuthLayout();
    this.props.predictiveInsightsDataRequest();
  }

  componentWillUnmount() {
    this.props.cancelAllPendingPredictiveInsightsDataRequest();
  }

  render() {
    return (
      <>
        {this.props.predictiveData && <Container fluid className="h-100">
          <div className="flexLayout maincontent">
            <Row className="mainheader">
              <Col xs="8" className="align-left">
                <img src={logo} alt="" width="135" />
                <div className="subtitle">Predictive Insights</div>
              </Col>
              <Col className="datetime align-right">
                <span>23/07/2020 12:57 PM</span>
              </Col>
            </Row>
            <Scrollbars style={{ height: "90%" }}>
              <div className="flexLayout-inner px-4">
                <Row className="card-height pt-4">
                  <Col>
                    <Card>
                      <CardBody>
                      <Row className="header mx-1">
                          <Col>
                            <h5>Predictive Influx of Patients</h5>
                          </Col>
                          <Col></Col>
                        </Row>
                        <ReactFC
                          type="msstepline"
                          width="100%"
                          height="350"
                          dataFormat="JSON"
                          dataSource={this.props.predictiveData.influxofPatients}
                        />
                        
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Card>
                      <CardBody>
                      <Row className="header mx-1">
                          <Col sm="8" className="pl-0">
                            <h5>Patients by Department / Service</h5>
                          </Col>
                          <Col className="align-right pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select</option>
                              <option value="nextday">Next Day</option>
                              <option value="next3days">Next 3 Days</option>
                              <option value="Next week">Next One Week</option>
                            </select>
                          </Col>
                        </Row>

                        <ReactFC
                          width="100%"
                          height="350"
                          type="stackedcolumn2d"
                          dataFormat="json"
                          dataSource={this.props.predictiveData.patientsbyDept}>
                        </ReactFC>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Card>
                      <CardBody>
                        <Row className="header mx-1">
                          <Col>
                            <h5>Predictive Patients inflow by Department</h5>
                          </Col>
                          <Col className="align-right pr-0">
                            <select className="drpdwn">
                            <option disabled selected hidden>Select</option>
                              <option value="nextday">Next Day</option>
                              <option value="next3days">Next 3 Days</option>
                              <option value="Next week">Next One Week</option>
                            </select>
                          </Col>
                        </Row>
                        <ReactFC
                          type="scrollcombi2d"
                          width="100%"
                          height="500"
                          dataFormat="JSON"
                          dataSource={this.props.predictiveData.inflowOfPatientsbyDept}
                        />
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                <Row className="card-height">
                  <Col>
                    <Card>
                      <CardBody>
                        <Row className="header mx-1">
                          <Col>
                            <h5>Estimated Upcoming Top Service based on Patients influx</h5>
                          </Col>
                          <Col className="align-right pr-2">
                           <select className="drpdwn ml-3">
                            <option disabled selected hidden>Select</option>
                              <option value="nextday">Next Day</option>
                              <option value="next3days">Next 3 Days</option>
                              <option value="Next week">Next One Week</option>
                            </select>
                          </Col>
                        </Row>
                        <ReactFC
                          type="sunburst"
                          width="100%"
                          height="500"
                          dataFormat="JSON"
                          dataSource={this.props.predictiveData.upcomingTopServices}
                        />
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                <Row className="card-height">
                  <Col sm="6">
                    <Card className="palert">
                      <CardBody>
                        <Row className="header mx-1">
                          <Col sm="9" className="pl-0">
                            <h5>Predicted Care Load by Clinic</h5>
                          </Col>
                          <Col sm="3" className="align-right pr-0">
                            <select className="drpdwn">
                            <option disabled selected hidden>Select</option>
                              <option value="nextday">Next Day</option>
                              <option value="next3days">Next 3 Days</option>
                              <option value="Next week">Next One Week</option>
                            </select>

                          </Col>
                        </Row>
                        <div className="align-center pb-2">
                          <ReactFC
                            type="angulargauge"
                            width="95%"
                            height="250"
                            dataFormat="JSON"
                            dataSource={this.props.predictiveData.clinicalCareLoad}>
                          </ReactFC>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col sm="6">
                    <Card className="palert">
                      <CardBody>
                        <Row className="header mx-1">
                          <Col sm="9" className="pl-0">
                            <h5>Predicted Care Load by Pharmacy</h5>
                          </Col>
                          <Col sm="3" className="align-right pr-0">
                            <select className="drpdwn">
                            <option disabled selected hidden>Select</option>
                              <option value="nextday">Next Day</option>
                              <option value="next3days">Next 3 Days</option>
                              <option value="Next week">Next One Week</option>
                            </select>

                          </Col>
                        </Row>
                        <div className="align-center pb-2">
                          <ReactFC
                            type="angulargauge"
                            width="95%"
                            height="250"
                            dataFormat="JSON"
                            dataSource={this.props.predictiveData.pharmacyCareLoad}>
                          </ReactFC>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>

                </Row>
                <Row>
                  <Col sm="6">
                    <Card className="palert">
                      <CardBody>
                        <Row className="header mx-1">
                          <Col sm="9" className="pl-0">
                            <h5>Predicted Care Load by Lab</h5>
                          </Col>
                          <Col sm="3" className="align-right pr-0">
                            <select className="drpdwn">
                            <option disabled selected hidden>Select</option>
                              <option value="nextday">Next Day</option>
                              <option value="next3days">Next 3 Days</option>
                              <option value="Next week">Next One Week</option>
                            </select>
                          </Col>
                        </Row>
                        <div className="align-center pb-2">
                          <ReactFC
                            width="95%"
                            height="250"
                            type="angulargauge"
                            dataFormat="json"
                            dataSource={this.props.predictiveData.labCareLoad}>
                          </ReactFC>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col sm="6">
                    <Card className="palert">
                      <CardBody>
                        <Row className="header mx-1">
                          <Col sm="9" className="pl-0">
                            <h5>Predicted Care Load by Radiology</h5>
                          </Col>
                          <Col sm="3" className="align-right pr-0">
                            <select className="drpdwn">
                            <option disabled selected hidden>Select</option>
                              <option value="nextday">Next Day</option>
                              <option value="next3days">Next 3 Days</option>
                              <option value="Next week">Next One Week</option>
                            </select>

                          </Col>
                        </Row>
                        <div className="align-center pb-2">
                          <ReactFC
                            width="95%"
                            height="250"
                            type="angulargauge"
                            dataFormat="json"
                            dataSource={this.props.predictiveData.radiologyCareLoad}>
                          </ReactFC>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
              </div>
            </Scrollbars>

          </div>

        </Container>
        }
        <div className="predictive-footer">&copy;&nbsp;Vectramind Corporation 2021</div>

      </>
    );
  }
}
const mapStatetoProps = state => {
  return {
    predictiveData: state.dashboardsReducer?.predictiveChartsData
  }
};
export default withRouter(connect(mapStatetoProps, { activateNonAuthLayout, predictiveInsightsDataRequest, cancelAllPendingPredictiveInsightsDataRequest })(PredctiveInsight1));

