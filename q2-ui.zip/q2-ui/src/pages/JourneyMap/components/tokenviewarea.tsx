import React from 'react';
import { useSelector } from 'react-redux';
import { IJourneyMapModel, ITokens } from '../../../models/journeyMapModel';
import '../container/Journeymap.css';

const TokenViewArea: React.FC = () => {

    const tokensData: ITokens = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.tokenData)
            return (state.journeyMapReducer as IJourneyMapModel).tokenData;
        else return undefined;
    });
    console.log("TokenViewArea_tokensData =>", tokensData);

    return (
        <>
            {tokensData && <div className="patient-details">
                <div className="patient-details-pad">
                    <div className="pditem w8">
                        <span>Token:</span><br />
                        <span>{tokensData.TokenNo}</span>
                    </div>
                    <div className="pditem w16">
                        <span>Appointment:</span><br />
                        <span>{tokensData.Appointment}</span>
                    </div>
                    <div className="pditem w16">
                        <span>Check in:</span><br />
                        <span>{tokensData.checkin}</span>
                    </div>
                    <div className="pditem w13">
                        <span>Avg Wait Time:</span><br />
                        <span>{tokensData.AvgWaitTime}</span>
                    </div>
                    <div className="pditem w13">
                        <span>Avg Care Time:</span><br />
                        <span>{tokensData.AvgCareTime}</span>
                    </div>
                    <div className="pditem w16">
                        <span>Avg Transit Time:</span><br />
                        <span>{tokensData.AvgTransitTime}</span>
                    </div>
                    <div className="pditem w18">
                        <span>Avg Transaction Time:</span><br />
                        <span>{tokensData.AvgTransactionTime}</span>
                    </div>
                </div>
            </div>}
        </>
    )
}

export default React.memo(TokenViewArea);