import React from 'react';
import usericon from "../../../images/usericon.svg";
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import ReactFC from "react-fusioncharts";
import FusionCharts from "fusioncharts";
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import Gantt from 'fusioncharts/fusioncharts.gantt';

import { useSelector } from 'react-redux';
import { IJourneyMapModel } from '../../../models/journeyMapModel';
import '../container/Journeymap.css';

ReactFC.fcRoot(FusionCharts, PowerCharts, Widgets, Charts, FusionTheme, Gantt);

const JourneyView: React.FC = () => {

    const journeyData = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.journeyData)
            return (state.journeyMapReducer as IJourneyMapModel).journeyData;
        else return undefined;
    });
    const patientName = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.patientName)
            return (state.journeyMapReducer as IJourneyMapModel).patientName;
        else return '';
    });
    const mrnNo = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.mrnNo)
            return (state.journeyMapReducer as IJourneyMapModel).mrnNo;
        else return undefined;
    });
    const totalJourneyTime = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.totalJourneyTime)
            return (state.journeyMapReducer as IJourneyMapModel).totalJourneyTime;
        else return 0;
    });
    console.log("JourneyView_journeyData =>", journeyData);

    return (
        <>
            {journeyData && <>
                <div className="chart-area chart-header">
                    <div>
                        <img src={usericon} alt="" className="valign-baseline" />&nbsp;
                        {patientName}, MRN: {mrnNo}
                    </div>
                    <div>
                        Total Journey Time: {totalJourneyTime} &nbsp; | &nbsp;<span className="journeydate">Fri 22/5</span>
                    </div>
                </div>

                <div className="maingraph">
                    <ReactFC
                        type="gantt"
                        width="100%"
                        height="350"
                        dataFormat="JSON"
                        dataSource={journeyData}
                    />
                </div>
            </>}
        </>
    )
}

export default React.memo(JourneyView);