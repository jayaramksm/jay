import React from 'react';
import { Row, Col } from 'reactstrap';
import sms from "../../../images/sms-clr.svg";
import email from "../../../images/mail-clr.svg";
import notification from "../../../images/bell-clr.svg";
import whatsapp from "../../../images/whatsapp-clr.svg";
import { useSelector } from 'react-redux';
import { IJourneyMapModel, INotifications } from '../../../models/journeyMapModel';
import '../container/Journeymap.css';

const NotificationView: React.FC = () => {

    const notificationsData: INotifications = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.notificationData)
            return (state.journeyMapReducer as IJourneyMapModel).notificationData;
        else return undefined;
    });
    console.log("NotificationView_notificationsData =>", notificationsData);

    return (
        <>
            {notificationsData && <Col sm="6" className="d-flex justify-content-center">
                <Row className="notification-details">
                    <Col sm="3" className="summary">
                        Notification Summary
                    </Col>
                    <Col sm="9" className="summary">
                        <div className="alerts"><img src={sms} style={{ width: '16px' }} alt="" /><span>{notificationsData.sms}</span></div>
                        <div className="alerts"><img src={email} style={{ width: '18px' }} alt="" /><span>{notificationsData.email}</span></div>
                        <div className="alerts"><img src={notification} style={{ width: '18px' }} alt="" /><span>{notificationsData.push}</span></div>
                        <div className="alerts"><img src={whatsapp} style={{ width: '19px' }} alt="" /><span>{notificationsData.whatsp}</span></div>
                    </Col>
                </Row>
            </Col>}
        </>
    )
}

export default React.memo(NotificationView);