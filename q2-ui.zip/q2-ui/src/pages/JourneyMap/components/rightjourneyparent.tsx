import React, { useContext } from 'react';
import { SuperParentContext } from '../container/journeymapcontext';
import PerfectScrollbar from 'react-perfect-scrollbar';
import graph from "../../../images/graph.svg";
import { Row } from 'reactstrap';
import { useSelector } from 'react-redux';
import { IJourneyMapModel } from '../../../models/journeyMapModel';
import '../container/Journeymap.css';

const RightJourneyParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    console.log("RightJourneyParent_context =>", context);

    const patientName = useSelector(state => {
        if (state.journeyMapReducer)
            return (state.journeyMapReducer as IJourneyMapModel).patientName !== (null || undefined);
        else return false;
    });
    const mrnNo = useSelector(state => {
        if (state.journeyMapReducer)
            return (state.journeyMapReducer as IJourneyMapModel).mrnNo;
        else return undefined;
    });
    console.log("RightJourneyParent_patientName =>", patientName)

    return (
        <>
            <div className="flexLayout-inner">
                <PerfectScrollbar className="scrollbar-padding">
                    {!patientName && !mrnNo && <div className="flexLayout items-icon">
                        <img src={graph} alt="" />
                        <div className="nodatacontent">Select an item to read</div>
                    </div>}
                    {!patientName && mrnNo && <div className="flexLayout items-icon">
                        <img src={graph} alt="" />
                        <div className="nodatacontent">No Data Found for this Mrn No</div>
                    </div>}
                    <div>
                        <context.tokenViewArea />
                        <context.journeyView />
                        <Row className="mb-6">
                            <context.notificationView />
                            <context.feedBackView />
                        </Row>
                    </div>
                </PerfectScrollbar>
                <div className="journey-footer">&copy;&nbsp;Vectramind Corporation 2021</div>
            </div>
        </>
    )
}

export default React.memo(RightJourneyParent);