import React, { useContext } from 'react';
import { SuperParentContext } from '../container/journeymapcontext';
import '../container/Journeymap.css';

const LeftJourneyParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    console.log("LeftJourneyParent_context =>", context);

    return (
        <>
            <div className="flexLayout">
                <context.inputArea />
                <context.patientVisits />
            </div>
        </>
    )
}

export default React.memo(LeftJourneyParent);