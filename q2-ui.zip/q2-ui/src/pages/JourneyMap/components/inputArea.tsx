import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { journeyMapSearchMrnRequest } from '../../../store/actions';
import '../container/Journeymap.css';
import { withRouter } from 'react-router-dom';

const InputArea: React.FC = (props: any) => {

    const [mrnInput, setMrnInput] = useState('');
    const dispatch = useDispatch();
    let mrnNo: any;
    const paramKey = "mrnno";
    mrnNo = new URLSearchParams(props.history.location.search).toString()?.split('=')[0];
    mrnNo = mrnNo.toLowerCase() === paramKey ? new URLSearchParams(props.history.location.search).get(mrnNo) : '';
    console.log("InputArea_mrnNo =>", mrnNo, props);

    return (
        <>
            {!mrnNo && <div className="col-pad pb-0 flex-headerfix">
                <p className="mb-1 search-text">Search MRN</p>
                <div className="mrn-search form-group">
                    <input type="text" value={mrnInput} onChange={(e) => setMrnInput(e.target.value)} className="form-control w-100" placeholder="Enter MRN Number" />
                    <i className="fa fa-search" onClick={() => dispatch(journeyMapSearchMrnRequest(mrnInput))}></i>
                </div>
            </div>}
        </>
    )
}

export default React.memo(withRouter(InputArea));