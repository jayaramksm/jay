import React from 'react';
import { Row, Col, Progress } from 'reactstrap';
import arrow from "../../../images/trend.svg";
import { useSelector } from 'react-redux';
import { IJourneyMapModel, INotifications } from '../../../models/journeyMapModel';
import '../container/Journeymap.css';

const FeedBackView: React.FC = () => {


    const notificationsData: INotifications = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.notificationData)
            return (state.journeyMapReducer as IJourneyMapModel).notificationData;
        else return undefined;
    });
    console.log("NotificationView_notificationsData =>", notificationsData);

    return (
        <>
            {notificationsData && <Col sm="6" className="d-flex justify-content-center">
                <Row className="notification-details">
                    <Col sm="4" xs="12">
                        <p className="happiness-index">Patient<br /> Happiness index</p>
                        <p className="indexValue">80.35%</p>
                    </Col>
                    <Col sm="8" xs="12">
                        <Progress value={80.35} />
                        <Row className="mt-3">
                            <Col sm="4" xs="4">
                                <p className="mb-0">Previous</p>
                                <p className="progress-value">79.82%</p>
                            </Col>
                            <Col sm="4" xs="4">
                                <p className="mb-0">&#37;&nbsp;Change</p>
                                <p className="progress-value">+14.29%</p>
                            </Col>
                            <Col sm="4" xs="4" className="arrow">
                                <p className="mb-0">Trend</p>
                                <img src={arrow} width="30" alt="" />
                            </Col>
                        </Row>
                    </Col>
                </Row>
            </Col>}
        </>
    )
}

export default React.memo(FeedBackView);