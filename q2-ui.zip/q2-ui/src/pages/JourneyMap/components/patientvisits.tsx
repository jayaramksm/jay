import React from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import searchdocuments from "../../../images/search-documents.svg";
import { useSelector } from 'react-redux';
import { IJourneyMapModel, IPatientVisit } from '../../../models/journeyMapModel';
import '../container/Journeymap.css';

const PatientVisits: React.FC = () => {

    const patientsData: IPatientVisit[] = useSelector(state => {
        if (state.journeyMapReducer && state.journeyMapReducer.patientVisits)
            return (state.journeyMapReducer as IJourneyMapModel).patientVisits;
        else return undefined;
    });
    const mrnNo = useSelector(state => {
        if (state.journeyMapReducer)
            return (state.journeyMapReducer as IJourneyMapModel).mrnNo;
        else return undefined;
    });
    console.log("PatientVisits_tokensData =>", patientsData);

    return (
        <>
            {!patientsData && !mrnNo && <div className="blank-visitlist">
                <img src={searchdocuments} alt="" />
                <div className="nodatacontent">Start Searching MRN</div>
            </div>}
            {!patientsData && mrnNo && <div className="blank-visitlist">
                <img src={searchdocuments} alt="" />
                <div className="nodatacontent">No Data Found for this Mrn No</div>
            </div>}

            {patientsData && patientsData.length > 0 && <div className="flexLayout-inner">
                <Scrollbars>
                    <div className="visited-patients col-pad pt-0">
                        <div className="filter d-flex align-items-center justify-content-between mt-4 mr-0">
                            <h3 className="my-2">Patient visits</h3>
                            <select placeholder="filter" className="searchFilter">
                                <option>Filter</option>
                                <option>Ascending</option>
                                <option>Descending</option>
                            </select>
                        </div>
                        <ul>
                            {patientsData && patientsData.map((x, index) => {
                                return (
                                    <li key={index}>
                                        <div className="patient-name">{x.fName + ' ' + x.lName}</div>
                                        <div className="visited-time align-right">{x.time}</div>
                                    </li>
                                )
                            })}
                        </ul>
                    </div>
                </Scrollbars>
            </div>}
        </>
    )
}

export default React.memo(PatientVisits);