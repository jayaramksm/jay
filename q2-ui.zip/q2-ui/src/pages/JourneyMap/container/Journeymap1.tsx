import * as React from 'react';
import logo from "../../../images/firstpasslogo.svg";
import { Container, Row, Col, Progress } from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import arrow from "../../../images/trend.svg";
import sms from "../../../images/sms-clr.svg";
import email from "../../../images/mail-clr.svg";
import notification from "../../../images/bell-clr.svg";
import whatsapp from "../../../images/whatsapp-clr.svg";
import searchdocuments from "../../../images/search-documents.svg";
import graph from "../../../images/graph.svg";
import usericon from "../../../images/usericon.svg";
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import ReactFC from "react-fusioncharts";
import FusionCharts from "fusioncharts";
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import Gantt from 'fusioncharts/fusioncharts.gantt';
import './Journeymap.css';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateNonAuthLayout } from '../../../store/actions';
import { Scrollbars } from 'react-custom-scrollbars';
import * as jsondata from './JourneymapData.json'



ReactFC.fcRoot(FusionCharts, PowerCharts, Widgets, Charts, FusionTheme, Gantt);

class JourneyMap1 extends React.Component<any, any> {

    constructor(props) {
        super(props);
        this.state = {
            pshowhide: "pshow",
            isFocus: false
        }
        this.toggleCollapse = this.toggleCollapse.bind(this)
    }
    componentDidMount() {
        this.props.activateNonAuthLayout();
    }
    getFocus = () => {
        this.setState({ isFocus: true })
    }

    toggleCollapse = () => {
        this.setState({ "pshowhide": (this.state.pshowhide === "pshow") ? "phide" : "pshow" })
    };
   
    render() {
        let apndMnuCls = this.state.pshowhide;
        return (
            <Container fluid className="p-0">
                <div className="mainheader">
                    <Row>
                        <Col xs="8" className="align-left">
                            <img src={logo} alt="" width="135" />
                            <div className="subtitle">journey maps</div>
                        </Col>
                        <Col className="datetime align-right">
                            <span>23/07/2020 12:57 PM</span>
                            <div className="mobilemenu" onClick={this.toggleCollapse}><i className="ti-menu"></i></div>
                        </Col>
                    </Row>
                </div>
                <div className="content-area">
                    <Row className="h-100 m-0">
                        <Col className={"visit-list flexLayout p-0 " + apndMnuCls} id="visitors-list">
                            <div className="flexLayout">
                                <div className="col-pad pb-0 flex-headerfix">
                                    <p className="mb-1 search-text">Search MRN</p>
                                    <div className="mrn-search form-group">
                                        <input type="text" className="form-control w-100" placeholder="Enter MRN Number" onFocus={this.getFocus} />
                                        <i className="fa fa-search"></i>
                                    </div>
                                </div>

                                {!this.state.isFocus && <div className="blank-visitlist">
                                    <img src={searchdocuments} />
                                    <div className="nodatacontent">Start Searching MRN</div>
                                </div>}

                                <div className="flexLayout-inner">
                                    <Scrollbars>
                                        {this.state.isFocus &&
                                            <div className="visited-patients col-pad pt-0">
                                                <div className="filter d-flex align-items-center justify-content-between mt-4 mr-0">
                                                    <h3 className="my-2">Patient visits</h3>
                                                    <select placeholder="filter" className="searchFilter">
                                                        <option>Filter</option>
                                                        <option>Ascending</option>
                                                        <option>Descending</option>
                                                    </select>
                                                </div>
                                                <ul>
                                                    <li>
                                                        <div className="patient-name">Jane Smith</div>
                                                        <div className="visited-time">08/03/20</div>
                                                    </li>
                                                    <li>
                                                        <div className="patient-name">Jane Smith</div>
                                                        <div className="visited-time">08/02/20</div>
                                                    </li>
                                                    <li>
                                                        <div className="patient-name">Jane Smith</div>
                                                        <div className="visited-time">08/01/20</div>
                                                    </li>
                                                    <li>
                                                        <div className="patient-name">Jane Smith</div>
                                                        <div className="visited-time">07/31/20</div>
                                                    </li>
                                                </ul>
                                            </div>
                                        }
                                    </Scrollbars>
                                </div>
                            </div>
                        </Col>
                        <Col className="maincontent flexLayout">
                            <div className="collapse-handle d-flex align-center" onClick={this.toggleCollapse}><i className="ti-angle-left"></i></div>
                            <div className="flexLayout-inner">
                                <PerfectScrollbar className="scrollbar-padding">
                                    {!this.state.isFocus && <div className="flexLayout items-icon">
                                        <img src={graph} />
                                        <div className="nodatacontent">Select an item to read</div>
                                    </div>}

                                    {this.state.isFocus &&
                                        <div>
                                             <div className="patient-details">
                                                <div className="patient-details-pad">
                                                    <div className="pditem w8">
                                                        <span>Token:</span><br />
                                                        <span>RC598</span>
                                                    </div>
                                                    <div className="pditem w16">
                                                        <span>Appointment:</span><br />
                                                        <span>22-05-20 16:00 PM</span>
                                                    </div>
                                                    <div className="pditem w16">
                                                        <span>Check in:</span><br />
                                                        <span>22-05-20 15:30 PM</span>
                                                    </div>
                                                    <div className="pditem w13">
                                                        <span>Avg Wait Time:</span><br />
                                                        <span>15 min</span>
                                                    </div>
                                                    <div className="pditem w13">
                                                        <span>Avg Care Time:</span><br />
                                                        <span>20 min</span>
                                                    </div>
                                                    <div className="pditem w16">
                                                        <span>Avg Transit Time:</span><br />
                                                        <span>15 min</span>
                                                    </div>
                                                    <div className="pditem w18">
                                                        <span>Avg Transaction Time:</span><br />
                                                        <span>10 min</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="chart-area chart-header">
                                                <div>
                                                    <img src={usericon} className="valign-baseline" />&nbsp; Jane Smith, MRN: 453789056785
                                                </div>
                                                <div>
                                                    Total Journey Time: {this.state.totaltime} &nbsp; | &nbsp;<span className="journeydate">Fri 22/5</span>
                                                </div>
                                            </div>

                                            <div className="maingraph">
                                                <ReactFC
                                                    type="gantt"
                                                    width="100%"
                                                    height="350"
                                                    dataFormat="JSON"
                                                    dataSource={jsondata.journeymapData}
                                                />
                                            </div>
                                            <Row className="mb-6">
                                                <Col sm="6" className="d-flex justify-content-center">
                                                    <Row className="notification-details">
                                                        <Col sm="3" className="summary">
                                                            Notification Summary
                                                        </Col>
                                                        <Col sm="9" className="summary">
                                                            <div className="alerts"><img src={sms} style={{ width: '16px' }} /><span>2</span></div>
                                                            <div className="alerts"><img src={email} style={{ width: '18px' }} /><span>1</span></div>
                                                            <div className="alerts"><img src={notification} style={{ width: '18px' }} /><span>1</span></div>
                                                            <div className="alerts"><img src={whatsapp} style={{ width: '19px' }} /><span>2</span></div>
                                                        </Col>
                                                    </Row>
                                                </Col>

                                                <Col sm="6" className="d-flex justify-content-center">
                                                    <Row className="notification-details">
                                                        <Col sm="4" xs="12">
                                                            <p className="happiness-index">Patient<br /> Happiness index</p>
                                                            <p className="indexValue">80.35%</p>
                                                        </Col>
                                                        <Col sm="8" xs="12">
                                                            <Progress value={80.35} />
                                                            <Row className="mt-3">
                                                                <Col sm="4" xs="4">
                                                                    <p className="mb-0">Previous</p>
                                                                    <p className="progress-value">79.82%</p>
                                                                </Col>
                                                                <Col sm="4" xs="4">
                                                                    <p className="mb-0">&#37;&nbsp;Change</p>
                                                                    <p className="progress-value">+14.29%</p>
                                                                </Col>
                                                                <Col sm="4" xs="4" className="arrow">
                                                                    <p className="mb-0">Trend</p>
                                                                    <img src={arrow} width="30" />
                                                                </Col>
                                                            </Row>
                                                        </Col>
                                                    </Row>
                                                </Col>
                                            </Row>
                                        </div>
                                    }
                                </PerfectScrollbar>
                                <div className="journey-footer">&copy;&nbsp;Vectramind Corporation 2021</div>
                            </div>


                        </Col>
                    </Row>
                </div>

            </Container >
        )
    }

}
export default withRouter(connect(null, { activateNonAuthLayout })(JourneyMap1));

