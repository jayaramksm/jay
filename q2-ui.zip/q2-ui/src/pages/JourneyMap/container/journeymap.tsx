import * as React from 'react';
import logo from "../../../images/firstpasslogo.svg";
import { Container, Row, Col } from 'reactstrap';
import './Journeymap.css';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateNonAuthLayout, cancelAllPendingJourneyMapRequest, journeyMapSearchMrnRequest } from '../../../store/actions';
import { SuperParentContext } from './journeymapcontext';
import {
    LeftJourneyParent, InputArea, PatientVisits,
    RightJourneyParent, TokenViewArea, JourneyView, NotificationView, FeedBackView
} from './journeymapindex';

interface IProps {
    activateNonAuthLayout: any;
    cancelAllPendingJourneyMapRequest: any;
    history: any;
    journeyMapSearchMrnRequest: any;
}


class JourneyMap extends React.Component<IProps, any> {
    mrnNo;
    constructor(props) {
        super(props);
        const paramKey = "mrnno";
        this.mrnNo = new URLSearchParams(this.props.history.location.search).toString()?.split('=')[0];
        this.mrnNo = this.mrnNo.toLowerCase() === paramKey ? new URLSearchParams(this.props.history.location.search).get(this.mrnNo) : '';
        // console.log("constructor =>", this.mrnNo, props);

        this.state = {
            leftParent: {
                inputArea: InputArea,
                patientVisits: PatientVisits,
                // queryMrn: this.mrnNo
            },
            rightParent: {
                tokenViewArea: TokenViewArea,
                journeyView: JourneyView,
                notificationView: NotificationView,
                feedBackView: FeedBackView
            }
        }
        this.toggleCollapse = this.toggleCollapse.bind(this)
    }
    componentDidMount() {
        this.props.activateNonAuthLayout();
        console.log("componentDidMount =>12", this.mrnNo);
        if (this.mrnNo) {
            this.props.journeyMapSearchMrnRequest(this.mrnNo);
        }
    }
    // getFocus = () => {
    //     this.setState({ isFocus: true })
    // }

    componentWillUnmount() {
        this.props.cancelAllPendingJourneyMapRequest();
    }

    toggleCollapse = () => {
        this.setState({ "pshowhide": (this.state.pshowhide === "pshow") ? "phide" : "pshow" })
    };

    render() {
        let apndMnuCls = this.state.pshowhide;
        return (
            <Container fluid className="p-0">

                <div className="mainheader">
                    <Row>
                        <Col xs="8" className="align-left">
                            <img src={logo} alt="" width="135" />
                            <div className="subtitle">journey maps</div>
                        </Col>
                        <Col className="datetime align-right">
                            <span>23/07/2020 12:57 PM</span>
                            <div className="mobilemenu" onClick={this.toggleCollapse}><i className="ti-menu"></i></div>
                        </Col>
                    </Row>
                </div>

                <div className="content-area">
                    <Row className="h-100 m-0">
                        <Col className={"visit-list flexLayout p-0 " + apndMnuCls} id="visitors-list">
                            <SuperParentContext.Provider value={this.state.leftParent}>
                                <LeftJourneyParent />
                            </SuperParentContext.Provider>
                        </Col>
                        <Col className="maincontent flexLayout">
                            <div className="collapse-handle d-flex align-center" onClick={this.toggleCollapse}><i className="ti-angle-left"></i></div>
                            <SuperParentContext.Provider value={this.state.rightParent}>
                                <RightJourneyParent />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </div>

            </Container >
        )
    }

}
export default withRouter(connect(null, { activateNonAuthLayout, cancelAllPendingJourneyMapRequest, journeyMapSearchMrnRequest })(JourneyMap));

