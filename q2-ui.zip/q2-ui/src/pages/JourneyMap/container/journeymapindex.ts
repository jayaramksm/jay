export { default as LeftJourneyParent } from '../components/leftjourneyparent';
export { default as InputArea } from '../components/inputArea';
export { default as PatientVisits } from '../components/patientvisits';
export { default as RightJourneyParent } from '../components/rightjourneyparent';
export { default as TokenViewArea } from '../components/tokenviewarea';
export { default as JourneyView } from '../components/journeyview';
export { default as NotificationView } from '../components/notificationview';
export { default as FeedBackView } from '../components/feedbackview';
