import * as React from 'react';
import { Component } from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Col, Row, Card, CardBody, Progress } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import predictive from '../../images/predictive-insight.svg';
import journey from '../../images/journey-map.svg';
import caremap from '../../images/care-maps.svg';
import arrow from '../../images/down-arrow.svg';
import './dashboard.css';
// import * as jsondata from './LabDashboard.json';
import { labDashboardDataRequest, cancelAllPendingLabDashboardDataRequest } from '../../store/actions'
import { getCaremapPath } from '../../helpers/helpersIndex';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);

interface IProps {
    activateAuthLayout: any,
    labDashboardDataRequest: any,
    cancelAllPendingLabDashboardDataRequest: any,
    labDashboardData: any,
    profilePath: any,
    history: any
}

class LabDashboard1 extends React.Component<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {};
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.labDashboardDataRequest();
    }
    componentWillUnmount() {
        this.props.cancelAllPendingLabDashboardDataRequest()
    }
    render() {
        const patientsByService = {
            ...this.props?.labDashboardData?.patientsByService,
            "events": {
                "beforeRender": function (evt: any, args: any) {
                    evt.sender.configureLink({
                        type: "mscombi2d",
                        overlayButton: {
                            message: 'Back',
                            font: 'roboto',
                        }
                    }, 0);
                }
            }
        }
        return (
            <>
                {
                    this.props.labDashboardData && <Container fluid className="h-100">
                        <div className="flexLayout">
                                <div className="flexLayout-inner general">
                                    <Row className="satisfactionIndex">
                                        <Col>
                                            <Card className="mb-0">
                                                <CardBody>
                                                    <Row >
                                                        <Col sm="8">
                                                            <div>
                                                                <h6>Patient happiness index</h6>
                                                            </div>
                                                        </Col>
                                                        <Col style={{ color: '#29C3BE' }} className="align-right"><h6>75.40%</h6></Col>
                                                    </Row>
                                                    <hr/>
                                                    <Progress value={75.40} style={{ width: '100%', height: '8px' }} />
                                                    <Row className="mt-2 stats">
                                                        <Col className="pr-0 align-left">
                                                            <h6 className="mr-2">Previous</h6>
                                                            <h6 style={{ color: '#5D62B5' }}>79.82%</h6>
                                                        </Col>
                                                        <Col sm="5" className="px-0 align-left">
                                                            <h6 className="mr-2">&#37;&nbsp;Change</h6>
                                                            <h6 style={{ color: '#D42027' }}>-5.69%</h6>
                                                        </Col>
                                                        <Col sm="3" className="btm-arrow align-right pl-0">
                                                            <h6 className="mr-3">Trend</h6>
                                                            <i className="fa fa-caret-down"></i>
                                                        </Col>
                                                    </Row>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                        <Col>
                                        <Row>
                                            <Col className="general">
                                                <h6>Lab</h6>
                                            </Col>
                                        </Row>
                                        <hr />

                                        {this.props?.profilePath && <Row className="mr-top">
                                            <Col className="generalmaps pointer"  onClick={() => window.open(getCaremapPath(), '_blank')}>
                                                <Card>
                                                    <CardBody className="align-center">
                                                        <img src={caremap} alt="" />
                                                        <h6>Care Map</h6>
                                                    </CardBody>
                                                </Card>

                                            </Col>
                                            {this.props?.profilePath?.journeymap && <Col className="generalmaps pointer" onClick={() => (this.props?.profilePath?.journeymap + '').startsWith('/') ? this.props.history.push(this.props.profilePath.journeymap) : window.open(this.props.profilePath.journeymap, '_blank')}>
                                                <Card>
                                                    <CardBody className="align-center">
                                                        <img src={journey} alt="" />
                                                        <h6>Journey Map</h6>
                                                    </CardBody>
                                                </Card>
                                            </Col>
                                            }
                                           {this.props?.profilePath?.predictiveinsight && <Col sm="5" className="generalmaps pointer mr-2"  onClick={() => (this.props?.profilePath?.predictiveinsight + '').startsWith('/') ? this.props.history.push(this.props.profilePath.predictiveinsight) : window.open(this.props.profilePath.predictiveinsight, '_blank')}>
                                                <Card>
                                                    <CardBody className="align-center">
                                                        <img src={predictive} alt="" />
                                                        <h6>Predictive Insights</h6>
                                                    </CardBody>
                                                </Card>

                                            </Col>
                                           }
                                        </Row>
                                        }
                                        </Col>
                                    </Row>
                                    <Row className="card-height mt-5">
                                        <Col>
                                            <Card>
                                                <CardBody className="backbtn">
                                                    <Row className="header mx-1">
                                                        <Col sm="8" className="pl-0">
                                                            <h5>Patients Stats by Service</h5>
                                                        </Col>
                                                        <Col></Col>
                                                    </Row>
                                                    <ReactFC

                                                        {...patientsByService}
                                                    />
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row className="card-height">
                                        <Col>
                                            <Card>
                                                <CardBody>
                                                    <div className="header">
                                                        <h5>Avg wait time & care time / services</h5>
                                                    </div>

                                                    <ReactFC
                                                        width="100%"
                                                        height="430"
                                                        type="msline"
                                                        dataFormat="json"
                                                        dataSource={this.props.labDashboardData.avgWaitTime}>
                                                    </ReactFC>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row className="mb-3">
                                        <Col>
                                            <Card className="mb-0">
                                                <CardBody>
                                                    <Row>

                                                        <Col>
                                                            <ReactFC
                                                                type="thermometer"
                                                                width="100%"
                                                                height="500"
                                                                dataFormat="JSON"
                                                                dataSource={this.props.labDashboardData.totalAppointments}
                                                            />
                                                        </Col>
                                                        <Col>
                                                            <ReactFC
                                                                type="thermometer"
                                                                width="100%"
                                                                height="500"
                                                                dataFormat="JSON"
                                                                dataSource={this.props.labDashboardData.patientsServed}
                                                            />
                                                        </Col>
                                                        <Col>
                                                            <ReactFC
                                                                type="thermometer"
                                                                width="100%"
                                                                height="500"
                                                                dataFormat="JSON"
                                                                dataSource={this.props.labDashboardData.checkedIn}
                                                            />
                                                        </Col>
                                                        <Col>
                                                            <ReactFC
                                                                type="thermometer"
                                                                width="100%"
                                                                height="500"
                                                                dataFormat="JSON"
                                                                dataSource={this.props.labDashboardData.noShow}
                                                            />
                                                        </Col>
                                                    </Row>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>

                                </div>
                        </div>
                    </Container>
                }
            </>
        );
    }
}

const MapStatetoProps = state => {
    console.log("state:::", state, state.dashboardsReducer?.labDashboard);
    return {
        labDashboardData: state.dashboardsReducer?.labDashboard
    }
}
export default withRouter(connect(MapStatetoProps, { activateAuthLayout, labDashboardDataRequest, cancelAllPendingLabDashboardDataRequest })(LabDashboard1));

