import React from 'react';
import { activateAuthLayout } from '../../store/actions';
import { Col, Row, Card, CardBody, Progress } from 'reactstrap';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Scrollbars } from 'react-custom-scrollbars';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import './dashboard.css';
import jsonData from './emergency.json';
import predictive from '../../images/predictive-insight.svg';
import journey from '../../images/journey-map.svg';
import caremap from '../../images/care-maps.svg';
import { getCaremapPath } from '../../helpers/helpersIndex';
ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme);

class EmergencyDashboard1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        this.state = {};
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    render() {
        return (
            <>
                <div className="flexLayout">
                        <div className="flexLayout-inner general">
                            <Row className="satisfactionIndex">
                                <Col>
                                    <Card className="mb-0">
                                        <CardBody>
                                            <Row>
                                                <Col sm="8">
                                                    <div>
                                                        <h6>Patient happiness index</h6>
                                                    </div>
                                                </Col>
                                                <Col style={{ color: '#29C3BE' }} className="align-right"><h6>88%</h6></Col>
                                            </Row>
                                            <hr />
                                            <Progress value={88} style={{ width: '100%', height: '8px' }} />
                                            <Row className="mt-2 stats">
                                                <Col className="pr-0 align-left">
                                                    <h6 className="mr-2">Previous</h6>
                                                    <h6 style={{ color: '#5D62B5' }}>79.82%</h6>
                                                </Col>
                                                <Col className="px-0 align-left">
                                                    <h6 className="mr-2">&#37;Change</h6>
                                                    <h6 style={{ color: '#69BC69' }}>+9.75%</h6>
                                                </Col>
                                                <Col className="arrow align-right pl-0">
                                                    <h6 className="mr-3">Trend</h6>
                                                    <i className="fa fa-caret-up"></i>
                                                </Col>
                                            </Row>
                                        </CardBody>
                                    </Card>
                                </Col>
                                <Col>
                                    <Row>
                                        <Col className="general">
                                            <h6>Emergency</h6>
                                        </Col>
                                    </Row>
                                    <hr />

                                    {this.props?.profilePath &&
                                        <Row className="mr-top">
                                            <Col className="generalmaps pointer" onClick={() => window.open(getCaremapPath(), '_blank')}>
                                                <Card>
                                                    <CardBody className="align-center">
                                                        <img src={caremap} alt="" />
                                                        <h6>Care Map</h6>
                                                    </CardBody>
                                                </Card>
                                            </Col>
                                            {this.props?.profilePath?.journeymap &&
                                                <Col className="generalmaps pointer" onClick={() => (this.props?.profilePath?.journeymap + '').startsWith('/') ? this.props.history.push(this.props.profilePath.journeymap) : window.open(this.props.profilePath.journeymap, '_blank')}>
                                                    <Card>
                                                        <CardBody className="align-center">
                                                            <img src={journey} alt="" />
                                                            <h6>Journey Map</h6>
                                                        </CardBody>
                                                    </Card>
                                                </Col>}
                                            {this.props?.profilePath?.predictiveinsight &&
                                                <Col sm="5" className="generalmaps pointer mr-2" onClick={() => (this.props?.profilePath?.predictiveinsight + '').startsWith('/') ? this.props.history.push(this.props.profilePath.predictiveinsight) : window.open(this.props.profilePath.predictiveinsight, '_blank')}>
                                                    <Card>
                                                        <CardBody className="align-center">
                                                            <img src={predictive} alt="" />
                                                            <h6>Predictive Insights</h6>
                                                        </CardBody>
                                                    </Card>
                                                </Col>}
                                        </Row>}

                                </Col>

                            </Row>
                            <Row className="mt-4">
                                <Col>
                                    <Card>
                                        <CardBody>
                                            <div className="header">
                                                <h5>ER Patient Inflow by Hours</h5>
                                            </div>
                                            <ReactFC
                                                width="100%"
                                                height="350"
                                                type="mscombi2d"
                                                dataFormat="json"
                                                dataSource={jsonData.patientInflowbyHours} />
                                        </CardBody>
                                    </Card>
                                </Col>
                            </Row>
                            <Row className="mt-5">
                                <Col>
                                    <Card>
                                        <CardBody>
                                            <Row className="header mx-1">
                                                <Col sm="5" className="pl-0">
                                                    <h5>Triage</h5>
                                                </Col>
                                                <Col className="text-right">
                                                    <span className="mr-2">ER1-Priority 1</span>
                                                    <span className="mr-2">ER2-Priority 2</span>
                                                    <span>ER3-Priority 3</span>
                                                </Col>
                                            </Row>
                                            <ReactFC
                                                type="mscolumn2d"
                                                width="100%"
                                                height="400"
                                                dataFormat="JSON"
                                                dataSource={jsonData.triage}
                                            />
                                        </CardBody>
                                    </Card>
                                </Col>
                                <Col>
                                    <Card>
                                        <CardBody>
                                            <Row className="header mx-1">
                                                <Col sm="6" className="pl-0">
                                                    <h5>Services</h5>
                                                </Col>
                                                <Col>

                                                </Col>
                                            </Row>
                                            <ReactFC
                                                type="bar2d"
                                                width="100%"
                                                height="400"
                                                dataFormat="JSON"
                                                dataSource={jsonData.services}
                                            />
                                        </CardBody>
                                    </Card>
                                </Col>

                            </Row>
                            <Row className="my-3">
                                <Col>
                                    <Card>
                                        <CardBody>
                                            <Row className="header mx-1">
                                                <Col sm="8" className="pl-0">
                                                    <h5>Patient Demographics</h5>
                                                </Col>
                                                <Col></Col>
                                            </Row>
                                            <ReactFC {...jsonData.patientsDemographics} />
                                        </CardBody>
                                    </Card>
                                </Col>
                                <Col>
                                    <Card>
                                        <CardBody>
                                            <div className="header">
                                                <h5>Staff Available</h5>
                                            </div>
                                            <ReactFC
                                                type="pie2d"
                                                width="100%"
                                                height="350"
                                                dataFormat="JSON"
                                                dataSource={jsonData.staffAvailable} />
                                        </CardBody>
                                    </Card>
                                </Col>

                            </Row>
                        </div>
                </div>
            </>
        )
    }
}
export default withRouter(connect(null, { activateAuthLayout })(EmergencyDashboard1));

