import * as React from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Col, Row, Card, CardBody, Progress } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import './dashboard.css';
import totalAppointments from '../../images/Total_Appointment.svg';
import checkins from '../../images/Total_Checkins.svg';
import walkin from '../../images/Walk-ins.svg';
import tokensissued from '../../images/Token_Issued.svg';
import noshow from '../../images/No_shows.svg';
import patientsServed from '../../images/Patients_served.svg';
import predictive from '../../images/predictive-insight.svg';
import journey from '../../images/journey-map.svg';
import caremap from '../../images/care-maps.svg';
import doctor from '../../images/firstpass_doctor.svg';
import lab from '../../images/firstpass_labtech.svg';
import pharmacist from '../../images/firstpass_pharmacist.svg';
import clerk from '../../images/firstpass_clerk.svg';
import support from '../../images/firstpass_support.svg';
import allstaff from '../../images/firstpass_allstaff.svg';
import nurse from '../../images/firstpass_nurse.svg';
// import jsonData from './general.json';
import { getCaremapPath } from '../../helpers/helpersIndex';

import { generalDashboardDataRequest, cancelAllPendingGeneralDashboardDataRequest } from '../../store/actions';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);


class GeneralDashboard1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        this.state = {};
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.generalDashboardDataRequest();
    }
    componentWillUnmount() {
        this.props.cancelAllPendingGeneralDashboardDataRequest();
    }
    render() {
        return (
            <>
                {this.props.generalDashboard && <Container fluid className="h-100">
                    <div className="flexLayout">
                            <div className="flexLayout-inner general">
                                <Row className="satisfactionIndex">
                                    <Col>
                                        <Card className="mb-0">
                                            <CardBody>
                                                <Row>
                                                    <Col sm="8">
                                                        <div>
                                                            <h6>Patient happiness index</h6>
                                                        </div>
                                                    </Col>
                                                    <Col style={{ color: '#29C3BE' }} className="align-right"><h6>88%</h6></Col>
                                                </Row>
                                                <hr />
                                                <Progress value={88} style={{ width: '100%', height: '8px' }} />
                                                <Row className="mt-2 stats">
                                                    <Col className="pr-0 align-left">
                                                        <h6 className="mr-2">Previous</h6>
                                                        <h6 style={{ color: '#5D62B5' }}>79.82%</h6>
                                                    </Col>
                                                    <Col className="px-0 align-left">
                                                        <h6 className="mr-2">&#37;Change</h6>
                                                        <h6 style={{ color: '#69BC69' }}>+9.75%</h6>
                                                    </Col>
                                                    <Col className="arrow align-right pl-0">
                                                        <h6 className="mr-3">Trend</h6>
                                                        <i className="fa fa-caret-up"></i>
                                                    </Col>
                                                </Row>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Row>
                                            <Col className="general">
                                                <h6>General</h6>
                                            </Col>
                                        </Row>
                                        <hr className="mr-2" />
                                        {this.props?.profilePath &&
                                            <Row className="mr-top">
                                                <Col className="generalmaps pointer" onClick={() => window.open(getCaremapPath(), '_blank')}>
                                                    <Card>
                                                        <CardBody className="align-center">
                                                            <img src={caremap} alt="" />
                                                            <h6>Care Map</h6>
                                                        </CardBody>
                                                    </Card>
                                                </Col>
                                                {this.props?.profilePath?.journeymap &&
                                                    <Col className="generalmaps pointer" onClick={() => (this.props?.profilePath?.journeymap + '').startsWith('/') ? this.props.history.push(this.props.profilePath.journeymap) : window.open(this.props.profilePath.journeymap, '_blank')}>
                                                        <Card>
                                                            <CardBody className="align-center">
                                                                <img src={journey} alt="" />
                                                                <h6>Journey Map</h6>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>}
                                                {this.props?.profilePath?.predictiveinsight &&
                                                    <Col sm="5" className="generalmaps pointer mr-2" onClick={() => (this.props?.profilePath?.predictiveinsight + '').startsWith('/') ? this.props.history.push(this.props.profilePath.predictiveinsight) : window.open(this.props.profilePath.predictiveinsight, '_blank')}>
                                                        <Card>
                                                            <CardBody className="align-center">
                                                                <img src={predictive} alt="" />
                                                                <h6>Predictive Insights</h6>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>}
                                            </Row>}

                                    </Col>

                                </Row>
                                <div className="mt-5 mx-2">
                                    <h6>Staff presence</h6>
                                    <hr />
                                </div>
                                <Row className="staffpresence">
                                    <Col className="pr-1">
                                        <Card>
                                            <CardBody className="p-10">
                                                <div className="text-center">
                                                    <h6 className="mt-0">Doctor</h6>
                                                </div>
                                                <Row className="align-center">
                                                    <Col sm="4">

                                                        <img src={doctor} alt="" />

                                                    </Col>
                                                    <Col className="text-right staff">
                                                        <span>Present</span>
                                                        <span className="presentCount">213</span>
                                                        <span style={{ fontWeight: 'bold' }}>/228</span>
                                                    </Col>
                                                </Row>
                                                <div className="mt-1 doctor">
                                                    <Progress value={93} />
                                                </div>
                                            </CardBody>
                                        </Card>

                                    </Col>
                                    <Col className="px-1">
                                        <Card>
                                            <CardBody className="p-10">
                                                <div className="text-center">
                                                    <h6 className="mt-0">Nurse</h6>
                                                </div>
                                                <Row className="align-center">
                                                    <Col sm="4">

                                                        <img src={nurse} alt="" />

                                                    </Col>
                                                    <Col className="text-right staff">
                                                        <span>Present</span>
                                                        <span className="presentCount">64</span>
                                                        <span style={{ fontWeight: 'bold' }}>/64</span>
                                                    </Col>
                                                </Row>
                                                <div className="mt-1 nurse">
                                                    <Progress value={100} />
                                                </div>

                                            </CardBody>
                                        </Card>

                                    </Col>
                                    <Col className="px-1">
                                        <Card>
                                            <CardBody className="p-10">
                                                <div className="text-center">
                                                    <h6 className="mt-0">Lab Tech</h6>
                                                </div>
                                                <Row className="align-center">
                                                    <Col sm="4">

                                                        <img src={lab} alt="" />

                                                    </Col>
                                                    <Col className="text-right staff">
                                                        <span>Present</span>
                                                        <span className="presentCount">16</span>
                                                        <span style={{ fontWeight: 'bold' }}>/16</span>
                                                    </Col>
                                                </Row>
                                                <div className="mt-1 lab">
                                                    <Progress value={100} />
                                                </div>
                                            </CardBody>
                                        </Card>

                                    </Col>
                                    <Col className="px-1">
                                        <Card>
                                            <CardBody className="p-10">
                                                <div className="text-center">
                                                    <h6 className="mt-0">Pharmacist</h6>
                                                </div>
                                                <Row className="align-center">
                                                    <Col sm="4">

                                                        <img src={pharmacist} alt="" />

                                                    </Col>
                                                    <Col className="text-right staff">
                                                        <span>Present</span>
                                                        <span className="presentCount">02</span>
                                                        <span style={{ fontWeight: 'bold' }}>/08</span>
                                                    </Col>
                                                </Row>
                                                <div className="mt-1 pharma">
                                                    <Progress value={25} />
                                                </div>
                                            </CardBody>
                                        </Card>

                                    </Col>
                                    <Col className="px-1">
                                        <Card>
                                            <CardBody className="p-10">
                                                <div className="text-center">
                                                    <h6 className="mt-0">Clerk</h6>
                                                </div>
                                                <Row className="align-center">
                                                    <Col sm="5">

                                                        <img src={clerk} alt="" />

                                                    </Col>
                                                    <Col className="text-right staff">
                                                        <span>Present</span>
                                                        <span className="presentCount">38</span>
                                                        <span style={{ fontWeight: 'bold' }}>/40</span>
                                                    </Col>
                                                </Row>
                                                <div className="mt-1 clerk">
                                                    <Progress value={95} />
                                                </div>
                                            </CardBody>
                                        </Card>

                                    </Col>
                                    <Col className="px-1">
                                        <Card>
                                            <CardBody className="p-10">
                                                <div className="text-center">
                                                    <h6 className="mt-0">Support</h6>
                                                </div>
                                                <Row className="align-center">
                                                    <Col sm="4">

                                                        <img src={support} alt="" />

                                                    </Col>
                                                    <Col className="text-right staff">
                                                        <span>Present</span>
                                                        <span className="presentCount">42</span>
                                                        <span style={{ fontWeight: 'bold' }}>/45</span>
                                                    </Col>
                                                </Row>
                                                <div className="mt-1 support">
                                                    <Progress value={93} />
                                                </div>
                                            </CardBody>
                                        </Card>

                                    </Col>
                                    <Col className="pl-1">
                                        <Card>
                                            <CardBody className="p-10">
                                                <div className="text-center">
                                                    <h6 className="mt-0">All Staff</h6>
                                                </div>
                                                <Row className="align-center">
                                                    <Col sm="4">

                                                        <img src={allstaff} alt="" />

                                                    </Col>
                                                    <Col className="text-right staff">
                                                        <span>Present</span>
                                                        <span className="presentCount">720</span>
                                                        <span style={{ fontWeight: 'bold' }}>/800</span>
                                                    </Col>
                                                </Row>
                                                <div className="mt-1 all-staff">
                                                    <Progress value={90} />
                                                </div>
                                            </CardBody>
                                        </Card>

                                    </Col>
                                </Row>
                                <Row className="mt-4 card-height">
                                    <Col>
                                        <div className="ml-2">
                                            <h6>Appointment details</h6>
                                            <hr />
                                        </div>
                                        <Row className="apptdetails">
                                            <Col className="text-center">
                                                <Card>
                                                    <CardBody>
                                                        <span>Total Appointments</span>
                                                        <hr />
                                                        <Row className="details">
                                                            <Col sm="4"><img src={totalAppointments} alt="" width="35" /></Col>
                                                            <Col className="text-right"><span>240</span></Col>
                                                        </Row>
                                                    </CardBody>
                                                </Card>
                                            </Col>
                                            <Col className="text-center">
                                                <Card>
                                                    <CardBody>
                                                        <span>Total Check-ins</span>
                                                        <hr />
                                                        <Row className="details" >
                                                            <Col sm="4"><img src={checkins} alt="" width="40" /></Col>
                                                            <Col className="text-right"><span>32</span></Col>
                                                        </Row>
                                                    </CardBody>
                                                </Card>
                                            </Col>
                                            <Col className="text-center">
                                                <Card>
                                                    <CardBody>
                                                        <span>Patients Served</span>
                                                        <hr />
                                                        <Row className="details" >
                                                            <Col sm="4"><img src={patientsServed} alt="" width="33" /></Col>
                                                            <Col className="text-right"><span>12</span></Col>
                                                        </Row>
                                                    </CardBody>
                                                </Card>
                                            </Col>
                                            <Col sm="1"></Col>
                                        </Row>

                                    </Col>
                                    <Col>

                                        <h6>Token details</h6>
                                        <hr className="mr-2" />
                                        <Row className="apptdetails">
                                            <Col className="text-center">
                                                <Card>
                                                    <CardBody>
                                                        <span>No Shows</span>
                                                        <hr />
                                                        <Row className="details" >
                                                            <Col sm="4"><img src={noshow} alt="" width="37" /></Col>
                                                            <Col className="text-right"><span>11</span></Col>
                                                        </Row>

                                                    </CardBody>
                                                </Card>
                                            </Col>
                                            <Col className="text-center">
                                                <Card>
                                                    <CardBody>
                                                        <span>Tokens issued</span>
                                                        <hr />
                                                        <Row className="details" >
                                                            <Col sm="4"><img src={tokensissued} alt="" width="32" /></Col>
                                                            <Col className="text-right"><span>32</span></Col>
                                                        </Row>

                                                    </CardBody>
                                                </Card>

                                            </Col>
                                            <Col className="text-center">
                                                <Card>
                                                    <CardBody>
                                                        <span>Walk-ins</span>
                                                        <hr />
                                                        <Row className="details" >
                                                            <Col sm="4"><img src={walkin} alt="" width="40"/></Col>
                                                            <Col className="text-right"><span>12</span></Col>
                                                        </Row>
                                                    </CardBody>
                                                </Card>
                                            </Col>
                                            <Col sm="1"></Col>
                                        </Row>

                                    </Col>
                                </Row>
                                <Row className="mt-4">

                                    <Col sm="6">
                                        <Card>
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Resource Activity</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC width="100%"
                                                    height="290"
                                                    type="mssplinearea"
                                                    dataFormat="json"
                                                    dataSource={this.props.generalDashboard.resourceActivity}
                                                />
                                            </CardBody>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="6" className="pl-0">
                                                        <h5>Patient Demographics</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC {...this.props.generalDashboard.patientsServedDemographics} />
                                            </CardBody>
                                        </Card>
                                    </Col>

                                </Row>

                                <Row className="mt-4">
                                    <Col>
                                        <Card>
                                            <CardBody>

                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Staff by Department</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC
                                                    width="100%"
                                                    height="400"
                                                    type="scrollstackedcolumn2d"
                                                    dataFormat="json"
                                                    dataSource={this.props.generalDashboard.staffByDept}>
                                                </ReactFC>
                                            </CardBody>
                                        </Card>
                                    </Col>

                                </Row>
                                <Row className="mt-4">
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <div className="header">
                                                    <h5>Patient Inflow by Hours</h5>
                                                </div>
                                                <ReactFC
                                                    width="100%"
                                                    height="350"
                                                    type="mscombi2d"
                                                    dataFormat="json"
                                                    dataSource={this.props.generalDashboard.patientInflowbyHours} />

                                            </CardBody>
                                        </Card>
                                    </Col>
                                </Row>
                                <Row className="mt-4">
                                    <Col>
                                        <Card>
                                            <CardBody>

                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Average wait and care time</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC
                                                    width="100%"
                                                    height="450"
                                                    type="msline"
                                                    dataFormat="json"
                                                    dataSource={this.props.generalDashboard.avgWaitTime}>
                                                </ReactFC>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                </Row>
                                <Row className="mt-4">
                                    <Col>
                                        <Card>
                                            <CardBody>

                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Wait Time / Care Time / Spare Time</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC
                                                    width="100%"
                                                    height="400"
                                                    type="stackedcolumn2d"
                                                    dataFormat="json"
                                                    dataSource={this.props.generalDashboard.waitCareSpareTime}>
                                                </ReactFC>
                                            </CardBody>
                                        </Card>
                                    </Col>

                                </Row>
                                <Row className="mt-4">
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Patient Country Origin / Ethinicty</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC
                                                    type="scrollbar2d"
                                                    width="100%"
                                                    height="350"
                                                    dataFormat="JSON"
                                                    dataSource={this.props.generalDashboard.patientCountryOrigin}
                                                />
                                            </CardBody>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <div className="header">
                                                    <h5>Departments</h5>
                                                </div>
                                                <ReactFC
                                                    type="pie2d"
                                                    width="100%"
                                                    height="350"
                                                    dataFormat="JSON"
                                                    dataSource={this.props.generalDashboard.departments} />
                                            </CardBody>
                                        </Card>

                                    </Col>


                                </Row>
                                <Row className="mt-4">
                                    <Col>
                                        <Card className="mb-0">
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Care Load</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <Row>

                                                    <Col>
                                                        <ReactFC
                                                            type="thermometer"
                                                            width="100%"
                                                            height="400"
                                                            dataFormat="JSON"
                                                            dataSource={this.props.generalDashboard.radiology}
                                                        />
                                                    </Col>
                                                    <Col>
                                                        <ReactFC
                                                            type="thermometer"
                                                            width="100%"
                                                            height="400"
                                                            dataFormat="JSON"
                                                            dataSource={this.props.generalDashboard.pharmacy}
                                                        />
                                                    </Col>
                                                    <Col>
                                                        <ReactFC
                                                            type="thermometer"
                                                            width="100%"
                                                            height="400"
                                                            dataFormat="JSON"
                                                            dataSource={this.props.generalDashboard.lab}
                                                        />
                                                    </Col>
                                                    <Col>
                                                        <ReactFC
                                                            type="thermometer"
                                                            width="100%"
                                                            height="400"
                                                            dataFormat="JSON"
                                                            dataSource={this.props.generalDashboard.billing}
                                                        />
                                                    </Col>
                                                </Row>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                </Row>
                                <Row className="my-4">
                                    <Col sm="6" md="6" className="gaugeCharts">
                                        <Card className="palert">
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="7" className="px-0">
                                                        <h5>Clinical care - load (overall)</h5>
                                                    </Col>
                                                    <Col className="endalign pr-0">
                                                        <select className="drpdwn">
                                                            <option value="Department">Department</option>
                                                            <option value="Cardiology">Cardiology</option>
                                                            <option value="Gynacology">Gynacology</option>
                                                            <option value="Neurology">Neurology</option>
                                                            <option value="Urology">Urology</option>
                                                        </select>
                                                    </Col>
                                                </Row>

                                                <div className="align-center pb-2">
                                                    <ReactFC
                                                        type="angulargauge"
                                                        width="97%"
                                                        height="250"
                                                        dataFormat="JSON"
                                                        dataSource={this.props.generalDashboard.clinicalCareLoad}>
                                                    </ReactFC>
                                                </div>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                    <Col sm="6" md="6" className="gaugeCharts">
                                        <Card className="palert">
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="7" className="pl-0">
                                                        <h5>Total care - load</h5>
                                                    </Col>
                                                    <Col className="endalign pr-0">
                                                        <select className="drpdwn">
                                                            <option value="Department">Department</option>
                                                            <option value="Cardiology">Cardiology</option>
                                                            <option value="Gynacology">Gynacology</option>
                                                            <option value="Neurology">Neurology</option>
                                                            <option value="Urology">Urology</option>
                                                        </select>
                                                    </Col>
                                                </Row>

                                                <div className="align-center pb-2">
                                                    <ReactFC
                                                        type="angulargauge"
                                                        width="95%"
                                                        height="250"
                                                        dataFormat="JSON"
                                                        dataSource={this.props.generalDashboard.totalCareLoad}>
                                                    </ReactFC>
                                                </div>
                                            </CardBody>
                                        </Card>
                                    </Col>

                                </Row>

                            </div>
                    </div>
                </Container>}
            </>
        )
    }
}

const mapStatetoProps = state => {
    return {
        generalDashboard: state.dashboardsReducer?.generalDashboard
    }
};
export default withRouter(connect(mapStatetoProps, { activateAuthLayout, generalDashboardDataRequest, cancelAllPendingGeneralDashboardDataRequest })(GeneralDashboard1));

