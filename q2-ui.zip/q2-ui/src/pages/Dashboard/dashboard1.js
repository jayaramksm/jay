import React, { Component } from 'react';

import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
class Dashboard1 extends Component {
    constructor(props) {
        super(props);
        this.state = {

        };

    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }
    render() {
        return (
            <>
                {true && <iframe src="http://dev.me.synapselive.com:8989/superset/dashboard/world_health/?standalone=true"
                    // frameborder="0"
                    // marginheight="0"
                    // marginwidth="0"
                    width="100%"
                    height="500"
                    scrolling="auto">
                </iframe>}
                {/* <iframe src="http://202.65.159.118/qsmartadmin/#/" height="500" width="100%" /> */}

            </>
        )
    }
}

export default withRouter(connect(null, { activateAuthLayout })(Dashboard1));