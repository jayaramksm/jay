import * as React from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Col, Row, Card, CardBody, Progress } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import './dashboard.css';
import predictive from '../../images/predictive-insight.svg';
import journey from '../../images/journey-map.svg';
import caremap from '../../images/care-maps.svg';
// import jsonData from './devices.json';
import BootstrapTable from 'react-bootstrap-table-next';
import { devicesDashboardDataRequest, cancelAllPendingDevicesDashboardDataRequest } from '../../store/actions';
import { getCaremapPath } from '../../helpers/helpersIndex';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);


class DevicesDashboard1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        this.state = {};
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.devicesDashboardDataRequest();
    }
    componentWillUnmount() {
        this.props.cancelAllPendingDevicesDashboardDataRequest();
    }
    devicecolumns = [{
        dataField: 'deviceStatus',
        text: 'Device Status',
        sort: true,
        formatter: (cell) => {
            return cell === "Online" ? <span><div className="Stat" style={{ background: "#67CEF2" }}></div>{cell}</span> : <span><div className="Stat" style={{ background: "#d9d9d9" }}></div>{cell}</span>
        }
    }, {
        dataField: 'deviceName',
        text: 'Device Name',
        sort: true
    }, {
        dataField: 'deviceType',
        text: 'Device Type',
        sort: true
    }, {
        dataField: 'ipAddress',
        text: 'IP Address',
        sort: true
    },
    {
        dataField: 'link',
        text: 'Link',
        sort: true,
        formatter: (cell) => {
            return <a className="linkText">{cell}</a>
        }
    }, {
        dataField: 'dept',
        text: 'Department',
        sort: true
    }, {
        dataField: 'service',
        text: 'Services',
        formatter: (cell, rowIndex) => {
            let data = cell.split(',')
            return data.map((i, index) => <div key={index} className="serviceItem">{i}</div>)



        }
    }
    ];

    deviceData = [
        { id: 1, deviceStatus: 'Online', deviceName: 'OPD_Level3_KIOSK', deviceType: "Kiosk", ipAddress: "102.168.0.1", link: "CopyLink", dept: "Cardiology", service: "Adolescent Transitional Cardiac Care Program, Cardiac Arrhythmia, Electrophysiology, Heart Transplant, Pacemaker" },
        { id: 2, deviceStatus: 'Online', deviceName: 'OPD_Level2_KIOSK', deviceType: "Kiosk", ipAddress: "152.168.0.1", link: "CopyLink", dept: "Obstetrics and Gynecology", service: "Chronic Pelvic Pain Program, Fertility and Reproductive Health Center, Labor and Delivery, Maternal Fetal Medicine" },
        { id: 3, deviceStatus: 'Offline', deviceName: 'OPD_Level10_Neurogy_Display', deviceType: "DisplayBoard", ipAddress: "112.168.0.1", link: "CopyLink", dept: "Neurology", service: "Neurocritical Care, Neurogenetics, Neurophysiology, NeuroRehabilitation, NeuroOncology" },
        { id: 4, deviceStatus: 'Online', deviceName: 'OPD_Level9_Kiosk', deviceType: "Kiosk", ipAddress: "802.168.0.1", link: "CopyLink", dept: "Head and Neck Surgery", service: "Airway Stenosis Program, Microvascular and Reconstructive Surgery, Minimally Invasive Surgery" },
        { id: 5, deviceStatus: 'Offline', deviceName: 'OPD_Level2_Oncolgy_Kiosk', deviceType: "Kiosk", ipAddress: "102.188.0.1", link: "CopyLink", dept: "Oncology", service: "Palliative Care Program, Travel Medicine Program, Behavioral and Addiction Medicine, Sports Medicine Program" },

    ]
    render() {
        return (
            <>
                {this.props.devicesDashboard && <Container fluid className="h-100">
                    <div className="flexLayout">
                            <div className="flexLayout-inner general">
                                <Row className="satisfactionIndex">
                                    <Col>
                                        <Card className="mb-0">
                                            <CardBody>
                                                <Row>
                                                    <Col sm="8">
                                                        <div>
                                                            <h6>Patient happiness index</h6>
                                                        </div>
                                                    </Col>
                                                    <Col style={{ color: '#29C3BE' }} className="align-right"><h6>88%</h6></Col>
                                                </Row>
                                                <hr />
                                                <Progress value={88} style={{ width: '100%', height: '8px' }} />
                                                <Row className="mt-2 stats">
                                                    <Col className="pr-0 align-left">
                                                        <h6 className="mr-2">Previous</h6>
                                                        <h6 style={{ color: '#5D62B5' }}>79.82%</h6>
                                                    </Col>
                                                    <Col className="px-0 align-left">
                                                        <h6 className="mr-2">&#37;Change</h6>
                                                        <h6 style={{ color: '#69BC69' }}>+9.75%</h6>
                                                    </Col>
                                                    <Col className="arrow align-right pl-0">
                                                        <h6 className="mr-3">Trend</h6>
                                                        <i className="fa fa-caret-up"></i>
                                                    </Col>
                                                </Row>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Row>
                                            <Col className="general">
                                                <h6>Devices</h6>
                                            </Col>
                                        </Row>
                                        <hr />
                                        {this.props?.profilePath &&
                                            <Row className="mr-top">
                                                <Col className="generalmaps pointer" onClick={() => window.open(getCaremapPath(), '_blank')}>
                                                    <Card>
                                                        <CardBody className="align-center">
                                                            <img src={caremap} alt="" />
                                                            <h6>Care Map</h6>
                                                        </CardBody>
                                                    </Card>
                                                </Col>
                                                {this.props?.profilePath?.journeymap &&
                                                    <Col className="generalmaps pointer" onClick={() => (this.props?.profilePath?.journeymap + '').startsWith('/') ? this.props.history.push(this.props.profilePath.journeymap) : window.open(this.props.profilePath.journeymap, '_blank')}>
                                                        <Card>
                                                            <CardBody className="align-center">
                                                                <img src={journey} alt="" />
                                                                <h6>Journey Map</h6>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>}
                                                {this.props?.profilePath?.predictiveinsight &&
                                                    <Col sm="5" className="generalmaps pointer mr-2" onClick={() => (this.props?.profilePath?.predictiveinsight + '').startsWith('/') ? this.props.history.push(this.props.profilePath.predictiveinsight) : window.open(this.props.profilePath.predictiveinsight, '_blank')}>
                                                        <Card>
                                                            <CardBody className="align-center">
                                                                <img src={predictive} alt="" />
                                                                <h6>Predictive Insights</h6>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>}
                                            </Row>}

                                    </Col>

                                </Row>
                                <Row className="mt-5">
                                    <Col>
                                        <Card>
                                            <CardBody style={{ paddingBottom: 0 }}>
                                                <h6 className="tableCap mt-0">Device overview</h6>
                                                <div className="deviceTbl">
                                                    <Scrollbars>
                                                        <BootstrapTable
                                                            classes="deviceDashTable"
                                                            keyField='id'
                                                            data={this.deviceData}
                                                            columns={this.devicecolumns}
                                                            wrapperClasses=""
                                                            bordered={false}
                                                        />
                                                    </Scrollbars>
                                                </div>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                </Row>
                                <Row className="mt-5">
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="6" className="pl-0">
                                                        <h5>Resource Activity</h5>
                                                    </Col>
                                                    <Col className="resourcetext align-right">
                                                        <div>
                                                            <span className="mr-2">Day</span><span>|</span>
                                                            <span className="mx-2">Week</span><span>|</span>
                                                            <span className="mx-2">Month</span><span>|</span>
                                                            <span className="ml-2">Year</span>
                                                        </div>
                                                    </Col>
                                                </Row>
                                                <ReactFC
                                                    type="doughnut2d"
                                                    width="100%"
                                                    height="450"
                                                    dataFormat="JSON"
                                                    dataSource={this.props.devicesDashboard.resourceActivity}
                                                />
                                            </CardBody>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Device Status</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC
                                                    type="mscolumn2d"
                                                    width="100%"
                                                    height="450"
                                                    dataFormat="JSON"
                                                    dataSource={this.props.devicesDashboard.patientsServed}
                                                />
                                            </CardBody>
                                        </Card>
                                    </Col>
                                </Row>
                                <Row className="mt-5 mb-3">
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Kiosk Stats</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC
                                                    type="mscolumn2d"
                                                    width="100%"
                                                    height="450"
                                                    dataFormat="JSON"
                                                    dataSource={this.props.devicesDashboard.kioskStats}
                                                />
                                            </CardBody>
                                        </Card>
                                    </Col>
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <Row className="header mx-1">
                                                    <Col sm="8" className="pl-0">
                                                        <h5>Display board Stats</h5>
                                                    </Col>
                                                    <Col></Col>
                                                </Row>
                                                <ReactFC
                                                    type="mscolumn2d"
                                                    width="100%"
                                                    height="450"
                                                    dataFormat="JSON"
                                                    dataSource={this.props.devicesDashboard.displayboardStats}
                                                />
                                            </CardBody>
                                        </Card>
                                    </Col>

                                </Row>
                            </div>
                    </div>
                </Container>}
            </>
        )
    }
}

const mapStatetoProps = state => {
    return {
        devicesDashboard: state.dashboardsReducer?.devicesDashboard
    }
};
export default withRouter(connect(mapStatetoProps, { activateAuthLayout, devicesDashboardDataRequest, cancelAllPendingDevicesDashboardDataRequest })(DevicesDashboard1));

