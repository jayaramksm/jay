import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Col, Row, Card, CardBody } from 'reactstrap';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { IPharmacyDashboardModel } from '../../../../models/pharmacyDashboardModel';
import { interval } from 'rxjs';
import { getDashboardInterval } from '../../../../helpers/helpersIndex';
import { getServiceTypeByCounterDataRequest } from '../../../../store/actions';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);

let subscription;

const ServiceTypeByCounter: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const serviceTypeByCounterData = useSelector(state => {
        if (state.pharmacyDashboardReducer && state.pharmacyDashboardReducer.serviceTypeByCounterData)
            return (state.pharmacyDashboardReducer as IPharmacyDashboardModel).serviceTypeByCounterData;
        else return undefined;
    });
    console.log("ServiceTypeByCounter_serviceTypeByCounterData =>", serviceTypeByCounterData);

    useEffect(() => {
        dispatch(getServiceTypeByCounterDataRequest());
        subscription = interval(getDashboardInterval() * 1000).subscribe(data => {
            dispatch(getServiceTypeByCounterDataRequest());
        });
        return () => {
            if (subscription)
                subscription.unsubscribe();
        }
    }, [dispatch]);

    return (
        <>
            {serviceTypeByCounterData && <Col>
                <Card className="mb-0">
                    <CardBody>
                        <Row className="header mx-1">
                            <Col sm="8" className="pl-0">
                                <h5>{t('PharmacyDashboard.serviceTypeByCounterLabel')}</h5>
                            </Col>
                            {/* <Col className="endalign pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select Pharmacy</option>
                              <option value="Gynacology">Pharmacy1</option>
                              <option value="Cardiology">Pharmacy2</option>
                              <option value="Urology">Pharmacy3</option>
                              <option value="Neurology">Pharmacy4</option>
                            </select>

                          </Col> */}
                        </Row>
                        <ReactFC
                            type="stackedcolumn2d"
                            width="100%"
                            height="350"
                            dataFormat="JSON"
                            dataSource={serviceTypeByCounterData}
                        />
                    </CardBody>
                </Card>
            </Col>}
        </>
    )
}
export default React.memo(ServiceTypeByCounter);