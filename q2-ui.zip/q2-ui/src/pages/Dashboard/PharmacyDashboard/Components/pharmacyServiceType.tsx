import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Col, Row, Card, CardBody } from 'reactstrap';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { IPharmacyDashboardModel } from '../../../../models/pharmacyDashboardModel';
import { interval } from 'rxjs';
import { getDashboardInterval } from '../../../../helpers/helpersIndex';
import { getPharmacyServiceTypeDataRequest } from '../../../../store/actions';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);

let subscription;

const PharmacyServiceType: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const pharmacyServiceTypeData = useSelector(state => {
        if (state.pharmacyDashboardReducer && state.pharmacyDashboardReducer.pharmacyServiceTypeData)
            return (state.pharmacyDashboardReducer as IPharmacyDashboardModel).pharmacyServiceTypeData;
        else return undefined;
    });
    console.log("PharmacyServiceType_pharmacyServiceTypeData =>", pharmacyServiceTypeData);

    useEffect(() => {
        dispatch(getPharmacyServiceTypeDataRequest());
        subscription = interval(getDashboardInterval() * 1000).subscribe(data => {
            dispatch(getPharmacyServiceTypeDataRequest());
        });
        return () => {
            if (subscription)
                subscription.unsubscribe();
        }
    }, [dispatch]);

    return (
        <>
            {pharmacyServiceTypeData && <Row className="card-height">
                <Col sm="12">
                    <Card>
                        <CardBody className="backbtn">
                            <Row className="header mx-1">
                                <Col sm="8" className="pl-0">
                                    <h5>{t('PharmacyDashboard.pharmacyServiceTypeLabel')}</h5>
                                </Col>
                                {/* <Col className="endalign pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select Pharmacy</option>
                              <option value="Gynacology">Pharmacy1</option>
                              <option value="Cardiology">Pharmacy2</option>
                              <option value="Urology">Pharmacy3</option>
                              <option value="Neurology">Pharmacy4</option>
                            </select>
                          </Col> */}
                            </Row>
                            {pharmacyServiceTypeData?.data?.length === 0 && <div>{t('PharmacyDashboard.ndfPharmacyServiceType')}</div>}
                            <ReactFC
                                type="doughnut2d"
                                width="100%"
                                height="450"
                                dataFormat="JSON"
                                dataSource={pharmacyServiceTypeData}
                            />
                        </CardBody>
                    </Card>
                </Col>
            </Row>}
        </>
    )
}
export default React.memo(PharmacyServiceType);