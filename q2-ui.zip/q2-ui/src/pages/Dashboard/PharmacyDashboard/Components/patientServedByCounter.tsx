import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Col, Row, Card, CardBody } from 'reactstrap';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { IPharmacyDashboardModel } from '../../../../models/pharmacyDashboardModel';
import { interval } from 'rxjs';
import { getDashboardInterval } from '../../../../helpers/helpersIndex';
import { getPatientServedByCounterDataRequest } from '../../../../store/actions';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);

let subscription;

const PatientServedByCounter: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const patientServedByCounterData = useSelector(state => {
        if (state.pharmacyDashboardReducer && state.pharmacyDashboardReducer.patientServedByCounterData)
            return (state.pharmacyDashboardReducer as IPharmacyDashboardModel).patientServedByCounterData;
        else return undefined;
    });
    console.log("PatientServedByCounter =>", patientServedByCounterData);

    useEffect(() => {
        dispatch(getPatientServedByCounterDataRequest());
        subscription = interval(getDashboardInterval() * 1000).subscribe(data => {
            dispatch(getPatientServedByCounterDataRequest());
        });
        return () => {
            if (subscription)
                subscription.unsubscribe();
        }
    }, [dispatch]);

    return (
        <>
            {patientServedByCounterData && <Col>
                <Card className="mb-0">
                    <CardBody>
                        <Row className="header mx-1">
                            <Col sm="8" className="pl-0">
                                <h5>{t('PharmacyDashboard.patientServedByCounterLabel')}</h5>
                            </Col>
                            {/* <Col className="endalign pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select Pharmacy</option>
                              <option value="Gynacology">Pharmacy1</option>
                              <option value="Cardiology">Pharmacy2</option>
                              <option value="Urology">Pharmacy3</option>
                              <option value="Neurology">Pharmacy4</option>
                            </select>
                          </Col> */}
                        </Row>
                        {patientServedByCounterData?.data?.length === 0 && <div>{t('PharmacyDashboard.ndfPatientServedByCounter')}</div>}
                        <ReactFC
                            type="column2d"
                            width="100%"
                            height="350"
                            dataFormat="JSON"
                            dataSource={patientServedByCounterData}
                        />
                    </CardBody>
                </Card>
            </Col>}

        </>
    )
}
export default React.memo(PatientServedByCounter);