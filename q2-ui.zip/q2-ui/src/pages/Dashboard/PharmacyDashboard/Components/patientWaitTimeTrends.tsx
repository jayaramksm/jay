import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Col, Row, Card, CardBody } from 'reactstrap';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { IPharmacyDashboardModel } from '../../../../models/pharmacyDashboardModel';
import { interval } from 'rxjs';
import { getDashboardInterval } from '../../../../helpers/helpersIndex';
import { getPharmacyWaitTimeTrendsDataRequest } from '../../../../store/actions';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);

let subscription;

const PatientWaitTimeTrends: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const waitTimeTrendsData = useSelector(state => {
        if (state.pharmacyDashboardReducer && state.pharmacyDashboardReducer.waitTimeTrendsData)
            return (state.pharmacyDashboardReducer as IPharmacyDashboardModel).waitTimeTrendsData;
        else return undefined;
    });
    console.log("PatientWaitTimeTrends =>", waitTimeTrendsData);

    useEffect(() => {
        dispatch(getPharmacyWaitTimeTrendsDataRequest());
        subscription = interval(getDashboardInterval() * 1000).subscribe(data => {
            dispatch(getPharmacyWaitTimeTrendsDataRequest());
        });
        return () => {
            if (subscription)
                subscription.unsubscribe();
        }
    }, [dispatch]);


    return (
        <>

            {waitTimeTrendsData && <Row className="card-height">
                <Col className="trends">
                    <Card>
                        <CardBody>
                            <div className="header">
                                <h5>{t('PharmacyDashboard.waitTimeTrendsLabel')}</h5>
                            </div>
                            <ReactFC
                                width="100%"
                                height="350"
                                type="mscombi2d"
                                dataFormat="json"
                                dataSource={waitTimeTrendsData}>
                            </ReactFC>
                        </CardBody>
                    </Card>
                </Col>
            </Row>}
        </>
    )
}
export default React.memo(PatientWaitTimeTrends);