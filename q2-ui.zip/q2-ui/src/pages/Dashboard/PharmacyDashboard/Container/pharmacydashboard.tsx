import * as React from 'react';
import { activateAuthLayout, cancelAllPharmacyDashboardsRequest } from '../../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Row } from 'reactstrap';
// import { Scrollbars } from 'react-custom-scrollbars';
import '../../dashboard.css';
import {
    PatientWaitTimeTrends, PharmacyServiceType, PatientServedByCounter, ServiceTypeByCounter
} from './pharmacydashboardindex';

interface IProps {
    activateAuthLayout: any;
    cancelAllPharmacyDashboardsRequest: any;
}


class PharmacyDashboard extends React.Component<IProps, any> {

    componentDidMount() {
        this.props.activateAuthLayout();

    }

    componentWillUnmount() {
        this.props.cancelAllPharmacyDashboardsRequest();
    }

    render() {

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout">
                        <div className="flexLayout-inner general">
                            <PatientWaitTimeTrends />
                            <PharmacyServiceType />
                            <Row className="mb-3">
                                <PatientServedByCounter />
                                <ServiceTypeByCounter />
                            </Row>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}


export default withRouter(connect(null, { activateAuthLayout, cancelAllPharmacyDashboardsRequest })(PharmacyDashboard));
