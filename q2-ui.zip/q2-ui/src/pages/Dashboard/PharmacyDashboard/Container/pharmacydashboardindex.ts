export { default as PatientWaitTimeTrends } from '../Components/patientWaitTimeTrends';
export { default as PharmacyServiceType } from '../Components/pharmacyServiceType';
export { default as PatientServedByCounter } from '../Components/patientServedByCounter';
export { default as ServiceTypeByCounter } from '../Components/serviceTypeByCounter';
