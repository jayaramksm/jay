import * as React from 'react';
import { Component } from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Col, Row, Card, CardBody, Progress } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import predictive from '../../images/predictive-insight.svg';
import journey from '../../images/journey-map.svg';
import caremap from '../../images/care-maps.svg';
import arrow from '../../images/arrow.svg';
import './dashboard.css';
// import * as jsondata from './PharmacyDashboard.json';
import { pharmacyDashboardDataRequest, cancelAllPendingPharmacydashboardDataRequest } from '../../store/actions';
import { getCaremapPath } from '../../helpers/helpersIndex';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);
interface IProps {
  pharmacyDashboardDataRequest: any;
  cancelAllPendingPharmacydashboardDataRequest: any;
  pDashboardData: any;
  activateAuthLayout: any;
  profilePath: any;
  history: any
}
const topDrugDispensed = {

  events: {
    'beforeRender': function (evt, args) {
      evt.sender.configureLink({
        // type: "multilevelpie",
        overlayButton: {
          message: 'Back',
          font: 'roboto',
        }
      }, 0);

    }
  }
};

const patientsServed = {
  chart: {
    baseFontSize: "12",
    baseFont: "ROBOTO",
    legendItemFont: "roboto",
    caption: "PATIENTS SERVED",
    lowerlimit: "20",
    upperlimit: "120",
    thmfillcolor: "#059351",
    showgaugeborder: "1",
    gaugebordercolor: "#008ee4",
    gaugeborderthickness: "2",
    plottooltext: "Patients Served: <b>$datavalue</b> ",
    theme: "fusion",
    showvalue: "0"
  },
  value: "40"
};
const totalAppointments = {
  chart: {
    caption: "TOTAL APPOINTMENTS",
    baseFontSize: "12",
    baseFont: "ROBOTO",
    legendItemFont: "roboto",
    lowerlimit: "20",
    upperlimit: "120",
    thmfillcolor: "#F4B016",
    showgaugeborder: "1",
    gaugebordercolor: "#008ee4",
    gaugeborderthickness: "2",
    plottooltext: "Total Appointments: <b>$datavalue</b> ",
    theme: "fusion",
    showvalue: "0"
  },
  value: "110"
};


class PharmacyDashboard1 extends React.Component<IProps, any> {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount() {
    this.props.activateAuthLayout();
    this.props.pharmacyDashboardDataRequest();
  }

  componentWillUnmount() {
    this.props.cancelAllPendingPharmacydashboardDataRequest();
  }

  render() {
    const pharmacyServiceType = {
      ...this.props?.pDashboardData?.pharmacybyServicetype,
      events: {
        'beforeRender': function (evt, args) {
          evt.sender.configureLink({
            type: "doughnut2d",
            overlayButton: {
              message: 'Back',
              font: 'roboto',
            }
          }, 0);

        }
      }
    };
    return (
      <>
        {this.props.pDashboardData && <Container fluid className="h-100">
          <div className="flexLayout">
              <div className="flexLayout-inner general">
                <Row className="satisfactionIndex card-height">
                  <Col>
                  <Card className="mb-0">
                      <CardBody>
                        <Row>
                          <Col sm="8">
                          <div>
                              <h6>Patient happiness index</h6>
                          </div>
                        </Col>
                          <Col style={{ color: '#29C3BE' }} className="align-right"><h6>85%</h6></Col>
                        </Row>
                        <hr />
                        <Progress value={85} style={{ width: '100%', height: '8px' }} />
                        <Row className="mt-2 stats">
                        <Col className="pr-0 align-left">
                            <h6 className="mr-2">Previous</h6>
                            <h6 style={{ color: '#5D62B5' }}>79.82%</h6>
                        </Col>
                        <Col className="px-0 align-left">
                            <h6 className="mr-2">&#37;Change</h6>
                            <h6 style={{ color: '#69BC69' }}>+6.28%</h6>
                        </Col>
                        <Col className="arrow align-right pl-0">
                            <h6 className="mr-3">Trend</h6>
                            <i className="fa fa-caret-up"></i>
                        </Col>
                        </Row>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col className="caremaps">
                  <Row>
                      <Col className="general">
                          <h6>Pharmacy</h6>
                      </Col>
                  </Row>
                  <hr/>
                    {this.props?.profilePath && <Row className="mr-top">
                      <Col className="generalmaps pointer" onClick={() => window.open(getCaremapPath(), '_blank')}>
                      <Card>
                          <CardBody className="align-center">
                          <img src={caremap} alt="" />
                          <h6>Care Map</h6>
                          </CardBody>
                        </Card>
                      </Col>
                      {this.props?.profilePath?.journeymap && <Col className="generalmaps pointer" onClick={() => (this.props?.profilePath?.journeymap + '').startsWith('/') ? this.props.history.push(this.props.profilePath.journeymap) : window.open(this.props.profilePath.journeymap, '_blank')}>
                      <Card>
                          <CardBody className="align-center">
                          <img src={journey} alt="" />
                          <h6>Journey Map</h6>
                          </CardBody>
                        </Card>
                      </Col>}
                      {this.props?.profilePath?.predictiveinsight && <Col sm="5" md="5" className="generalmaps pointer mr-2" onClick={() => (this.props?.profilePath?.predictiveinsight + '').startsWith('/') ? this.props.history.push(this.props.profilePath.predictiveinsight) : window.open(this.props.profilePath.predictiveinsight, '_blank')}>
                      <Card>
                        <CardBody  className="align-center">
                        <img src={predictive} alt="" />
                        <h6>Predictive Insights</h6>
                        </CardBody>

                        </Card>
                      </Col>}
                    </Row>}
                    {/* <Row className="clinical header-margin">
                                           {/* <Col className="align-right pr-0">
                        <select className="main-drpdwn mr-0">
                          <option disabled selected hidden>Select Pharmacy</option>
                          <option value="Cardiology">Pharmacy1</option>
                          <option value="Gynacology">Pharmacy1</option>
                          <option value="Neurology">Pharmacy1</option>
                          <option value="Urology">Pharmacy1</option>
                        </select>
                      </Col> 
                    </Row> */}
                  </Col>
                </Row>
                <Row className="card-height">
                  <Col>
                    <Card>
                      <CardBody>
                        <div className="header">
                          <h5>Heatmap</h5>
                        </div>
                        {/* <div className="pad-top drpalign">
                          <form>

                            <select className="drpdwn">
                              <option disabled selected hidden>Counter</option>
                              <option value="volvo">Counter1</option>
                              <option value="saab">Counter2</option>
                              <option value="fiat">Counter3</option>
                              <option value="audi">Counter4</option>
                            </select>
                            <button className="button">Apply Filter</button>
                          </form>
                        </div> */}
                        <ReactFC
                          width="100%"
                          height="340"
                          type="chord"
                          dataFormat="json"
                          dataSource={this.props.pDashboardData.heatMapData}>
                        </ReactFC>
                      </CardBody>
                    </Card>
                  </Col>

                  <Col>
                    <Card>
                      <CardBody>
                        <Row className="header mx-1">
                          <Col sm="8" className="pl-0">
                            <h5>New Prescriptions vs Refills</h5>
                          </Col>
                          <Col>

                          </Col>
                        </Row>
                        <div>

                          <ReactFC
                            width="100%"
                            height="370"
                            type="msarea"
                            dataFormat="json"
                            dataSource={this.props.pDashboardData.scheduledAppointments}>
                          </ReactFC>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                <Row className="card-height">
                  <Col className="trends">
                    <Card>
                      <CardBody>
                        <div className="header">
                          <h5>Patients wait time Vs trends & numbers by hours</h5>
                        </div>
                        <ReactFC
                          width="100%"
                          height="350"
                          type="mscombi2d"
                          dataFormat="json"
                          dataSource={this.props.pDashboardData.waitTimeTrends}>
                        </ReactFC>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>

                <Row className="card-height">
                  <Col sm="6">
                    <Card>
                      <CardBody className="backbtn">
                        <Row className="header mx-1">
                          <Col sm="8" className="pl-0">
                            <h5>Pharmacy Service type</h5>
                          </Col>
                          {/* <Col className="endalign pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select Pharmacy</option>
                              <option value="Gynacology">Pharmacy1</option>
                              <option value="Cardiology">Pharmacy2</option>
                              <option value="Urology">Pharmacy3</option>
                              <option value="Neurology">Pharmacy4</option>
                            </select>
                          </Col> */}
                        </Row>
                        <ReactFC
                          type="doughnut2d"
                          width="100%"
                          height="450"
                          dataFormat="JSON"
                          dataSource={pharmacyServiceType}
                        />
                      </CardBody>
                    </Card>
                  </Col>
                  <Col>
                    <Card>
                      <CardBody className="backbtn">
                        <Row className="header mx-1">
                          <Col sm="8" className="pl-0">
                            <h5>Top drug type dispensed</h5>
                          </Col>
                          {/* <Col className="endalign pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select Pharmacy</option>
                              <option value="Gynacology">Pharmacy1</option>
                              <option value="Cardiology">Pharmacy2</option>
                              <option value="Urology">Pharmacy3</option>
                              <option value="Neurology">Pharmacy4</option>
                            </select>
                          </Col> */}
                        </Row>
                        <ReactFC
                          {...this.props.pDashboardData.topDrugDispensed}
                        />
                      </CardBody>
                    </Card>
                  </Col>

                </Row>
                <Row className="mb-3">
                  <Col>
                    <Card className="mb-0">
                      <CardBody>
                        <Row className="header mx-1">
                          <Col sm="8" className="pl-0">
                            <h5>Patient served by Counter</h5>
                          </Col>
                          {/* <Col className="endalign pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select Pharmacy</option>
                              <option value="Gynacology">Pharmacy1</option>
                              <option value="Cardiology">Pharmacy2</option>
                              <option value="Urology">Pharmacy3</option>
                              <option value="Neurology">Pharmacy4</option>
                            </select>
                          </Col> */}
                        </Row>
                        <ReactFC
                          type="column2d"
                          width="100%"
                          height="350"
                          dataFormat="JSON"
                          dataSource={this.props.pDashboardData.patientsServedbyCounter}
                        />
                      </CardBody>
                    </Card>
                  </Col>
                  <Col>
                    <Card className="mb-0">
                      <CardBody>
                        <Row className="header mx-1">
                          <Col sm="8" className="pl-0">
                            <h5>Service type by Counter</h5>
                          </Col>
                          {/* <Col className="endalign pr-0">
                            <select className="drpdwn">
                              <option disabled selected hidden>Select Pharmacy</option>
                              <option value="Gynacology">Pharmacy1</option>
                              <option value="Cardiology">Pharmacy2</option>
                              <option value="Urology">Pharmacy3</option>
                              <option value="Neurology">Pharmacy4</option>
                            </select>

                          </Col> */}
                        </Row>
                        <ReactFC
                          type="stackedcolumn2d"
                          width="100%"
                          height="350"
                          dataFormat="JSON"
                          dataSource={this.props.pDashboardData.serviceTypebyCounter}
                        />
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
              </div>
          </div>
        </Container>}


      </>
    );
  }
}
const mapStatetoProps = state => {
  return {
    pDashboardData: state.dashboardsReducer?.pharmacyDashboard
  }
};
export default withRouter(connect(mapStatetoProps, {
  activateAuthLayout, pharmacyDashboardDataRequest,
  cancelAllPendingPharmacydashboardDataRequest
})(PharmacyDashboard1));
