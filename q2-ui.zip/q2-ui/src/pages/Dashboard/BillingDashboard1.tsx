import * as React from 'react';
import { Component } from 'react';
import { activateAuthLayout } from '../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container, Col, Row, Card, CardBody, Progress } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import * as Zoomline from 'fusioncharts/fusioncharts.zoomline';
import ReactFC from 'react-fusioncharts';
import * as PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import predictive from '../../images/predictive-insight.svg';
import journey from '../../images/journey-map.svg';
import caremap from '../../images/care-maps.svg';
import arrow from '../../images/arrow.svg';
import './dashboard.css';
// import * as jsondata from './BillingDashboard.json';
import { billingDataRequest, cancelAllPendingbillingDataRequest } from '../../store/dashboards/actions';
import { getCaremapPath } from '../../helpers/helpersIndex';

ReactFC.fcRoot(FusionCharts, Widgets, Charts, PowerCharts, FusionTheme, Zoomline);
interface IProps {
    billingDataRequest: any,
    cancelAllPendingbillingDataRequest: any,
    billingState: any,
    activateAuthLayout: any
    profilePath: any
    history: any
}
class BillingDashboard1 extends React.Component<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {};
        console.log("BillingDashboard_props==>", this.props);

    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.billingDataRequest();

    }
    componentWillUnmount() {
        this.props.cancelAllPendingbillingDataRequest();
    }
    render() {
        return (
            <>
                {this.props.billingState &&
                    <Container fluid className="h-100">
                        <div className="flexLayout">
                                <div className="flexLayout-inner general">
                                    <Row className="satisfactionIndex">

                                        <Col>
                                            <Card className="mb-0">
                                                <CardBody>
                                                    <Row>
                                                        <Col sm="8">
                                                            <div>
                                                                <h6>Patient happiness index</h6>
                                                            </div>
                                                        </Col>
                                                        <Col style={{ color: '#29C3BE' }} className="align-right"><h6>83.35%</h6></Col>
                                                    </Row>
                                                    <hr />
                                                    <Progress value={83.35} style={{ width: '100%', height: '8px' }} />
                                                    <Row className="mt-2 stats">
                                                        <Col className="pr-0 align-left">
                                                            <h6 className="mr-2">Previous</h6>
                                                            <h6 style={{ color: '#5D62B5' }}>79.82%</h6>
                                                        </Col>
                                                        <Col className="px-0 align-left">
                                                            <h6 className="mr-2">&#37;Change</h6>
                                                            <h6 style={{ color: '#69BC69' }}>+4.33%</h6>
                                                        </Col>
                                                        <Col className="arrow align-right pl-0">
                                                            <h6 className="mr-3">Trend</h6>
                                                            <i className="fa fa-caret-up"></i>
                                                        </Col>
                                                    </Row>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                        <Col className="caremaps">
                                            <Row>
                                                <Col className="general">
                                                    <h6>Billing</h6>
                                                </Col>
                                            </Row>
                                            <hr />
                                            {this.props ?.profilePath && <Row className="mr-top">
                                                <Col className="generalmaps pointer" onClick={() => window.open(getCaremapPath(), '_blank')}>
                                                    <Card>
                                                        <CardBody className="align-center">
                                                            <img src={caremap} alt="" />
                                                            <h6>Care Map</h6>
                                                        </CardBody>
                                                    </Card>
                                                </Col>
                                                {this.props ?.profilePath ?.journeymap && <Col className="generalmaps pointer" onClick={() => (this.props ?.profilePath ?.journeymap + '').startsWith('/') ? this.props.history.push(this.props.profilePath.journeymap) : window.open(this.props.profilePath.journeymap, '_blank')}>

                                                    <Card>
                                                        <CardBody className="align-center">
                                                            <img src={journey} alt="" />
                                                            <h6>Journey Map</h6>
                                                        </CardBody>
                                                    </Card>
                                                </Col>}
                                                {this.props ?.profilePath ?.predictiveinsight && <Col sm="5" md="5" className="generalmaps pointer mr-2" onClick={() => (this.props ?.profilePath ?.predictiveinsight + '').startsWith('/') ? this.props.history.push(this.props.profilePath.predictiveinsight) : window.open(this.props.profilePath.predictiveinsight, '_blank')}>
                                                    <Card>
                                                        <CardBody className="align-center">
                                                            <img src={predictive} alt="" />
                                                            <h6>Predictive Insights</h6>
                                                        </CardBody>

                                                    </Card>
                                                </Col>}
                                            </Row>}

                                        </Col>
                                    </Row>
                                    <Row className="card-height mt-5">
                                        <Col className="trends">
                                            <Card>
                                                <CardBody>
                                                    <div className="header">
                                                        <h5>Patients wait time Vs trends & numbers by hours</h5>
                                                    </div>

                                                    <ReactFC
                                                        width="100%"
                                                        height="350"
                                                        type="mscombi2d"
                                                        dataFormat="json"
                                                        dataSource={this.props.billingState.waitTimeTrends}>
                                                    </ReactFC>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>

                                    <Row className="card-height">
                                        <Col>
                                            <Card>
                                                <CardBody>
                                                    <div className="header">
                                                        <h5>Avg wait time & Transaction time / services</h5>
                                                    </div>

                                                    <ReactFC
                                                        width="100%"
                                                        height="430"
                                                        type="msline"
                                                        dataFormat="json"
                                                        dataSource={this.props.billingState.avgWaitTime}>
                                                    </ReactFC>
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row className="card-height">
                                        <Col>
                                            <Card>
                                                <CardBody>
                                                    <Row className="header mx-1">
                                                        <Col sm="8" className="pl-0">
                                                            <h5>Patient Stats by Service</h5>
                                                        </Col>
                                                        <Col></Col>
                                                    </Row>
                                                    <ReactFC
                                                        type="stackedcolumn2d"
                                                        width="100%"
                                                        height="450"
                                                        dataFormat="JSON"
                                                        dataSource={this.props.billingState.patientsByServices}
                                                    />
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>
                                    <Row className="mb-3">
                                        <Col>
                                            <Card className="mb-0">
                                                <CardBody>
                                                    <Row className="header mx-1">
                                                        <Col sm="8" className="pl-0">
                                                            <h5>Patients Served vs Waiting</h5>
                                                        </Col>
                                                        {/* <Col className="endalign pr-0">
                                                        <select className="drpdwn">
                                                            <option disabled selected hidden>Select Reception</option>
                                                            <option value="Gynacology">Reception1</option>
                                                            <option value="Cardiology">Reception2</option>
                                                            <option value="Urology">Reception3</option>
                                                            <option value="Neurology">Reception4</option>
                                                        </select>
                                                    </Col> */}
                                                        <Col></Col>
                                                    </Row>
                                                    <ReactFC
                                                        type="msbar2d"
                                                        width="100%"
                                                        height="350"
                                                        dataFormat="JSON"
                                                        dataSource={this.props.billingState.patientsCheckedIn}
                                                    />
                                                </CardBody>
                                            </Card>
                                        </Col>
                                    </Row>
                                </div>
                        </div>
                    </Container>}
            </>
        );
    }
}

const mapStatetoProps = (state) => {

    return {
        billingState: state.dashboardsReducer ?.billingDashboard
    }
}
export default withRouter(connect(mapStatetoProps, { activateAuthLayout, billingDataRequest, cancelAllPendingbillingDataRequest })(BillingDashboard1));

