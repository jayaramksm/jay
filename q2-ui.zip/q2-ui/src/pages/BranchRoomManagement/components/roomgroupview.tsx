import React, { useContext, useState, useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Label, Card, CardBody, UncontrolledTooltip } from 'reactstrap';
import { SubChiledContext } from '../container/branchcontext';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IRoom, IBranchRoomModel } from '../../../models/branchRoomModel';
import { setRoomGroupActionIdRequest, selectRoomGroupActionRequest, deleteRoomGroupRequest } from '../../../store/actions';

const RoomGroupView: React.FC = () => {
    const tooltipRef = useRef<any>(null);
    const tooltipRef1 = useRef<any>(null);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const [collapse, setCollapse] = useState(false);

    const context: IRoom = useContext<any>(SubChiledContext)?.data;
    const actions = useContext<any>(SubChiledContext)?.actions;

    let roomGroupItemData: IRoom = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomGroupData) {
            let data = (state.branchAndRoomReducer as IBranchRoomModel).roomGroupData as IRoom[];
            let index = data?.findIndex(x => x.roomMasterId === context.roomMasterId);
            if (index !== -1)
                return state.branchAndRoomReducer.roomGroupData[index] as IRoom;
            else return undefined;
        }
        else return undefined;
    });
    console.log("roomGroupItemData =>view ", roomGroupItemData);

    const editRoomGroup = () => {
        dispatch(setRoomGroupActionIdRequest(roomGroupItemData.roomMasterId, IOprationalActions.EDIT, false))
    }

    const deleteRoomGroup = () => {
        let message = t('BranchAndRoom.confirmMessages.BRC3').replace('{roomGroupName}', roomGroupItemData.roomNameEn);
        console.log("deleteBranch =>", IOprationalActions.DELETE, roomGroupItemData.roomMasterId, message, false);
        dispatch(deleteRoomGroupRequest(IOprationalActions.DELETE, roomGroupItemData.roomMasterId, message, false));
    }

    const selectRoomGroup = () => {
        console.log("selectRoomGroup =>", roomGroupItemData);
        dispatch(selectRoomGroupActionRequest(roomGroupItemData, IOprationalActions.SELECT, false));
    }

    useEffect(() => {
        const currentTooltip = tooltipRef.current;
        return () => {
            if (currentTooltip?.state?.isOpen)
                currentTooltip.toggle();
            if (currentTooltip?.state?.isOpen)
                currentTooltip.toggle();
        }
    });
    return (
        <>
            {roomGroupItemData && <div className="customCard">
                <Card>
                    <CardBody className="colps">

                        <div className="align-right mb-2">
                            {actions.edit && <>
                                <i id={"roomgroupedit" + context.roomMasterId} className="ti-pencil-alt mr-2 pointer" onClick={editRoomGroup} ></i>
                                <UncontrolledTooltip ref={tooltipRef} color="primary" placement="top" target={"roomgroupedit" + context.roomMasterId}>
                                    {t('ActionNames.edit')}
                                </UncontrolledTooltip>
                            </>
                            }

                            {actions.delete && <>
                                <i id="roomgroupdelete" className="ti-trash pointer" onClick={deleteRoomGroup}></i>
                                <UncontrolledTooltip color="primary" placement="top" target="roomgroupdelete">
                                    {t('ActionNames.delete')}
                                </UncontrolledTooltip>
                            </>}
                        </div>
                        <div onClick={selectRoomGroup} className="pointer">
                            <div className="mb-2"><Label>{t('BranchAndRoom.roomGroupEngName')}</Label><br />{roomGroupItemData.roomNameEn}</div>
                            <div className="text-right"><Label>{t('BranchAndRoom.roomGroupArbName')}</Label><br />{roomGroupItemData.roomNameAr}</div>
                        </div>
                        <div className="cardFooter mt-2">
                            <button className="btn" onClick={() => setCollapse(!collapse)}>
                                <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                            </button>
                        </div>

                        <div className={`CardColpsCnt ${collapse ? 'show' : 'hide'}`} style={{ position: "absolute" }}>
                            <div style={{ marginBottom: "-25px" }}>
                                <div style={{ padding: '0px 15px 0px 15px' }}>
                                    <div className="align-right mb-2" style={{ paddingTop: "15px" }}>
                                        {actions.edit &&
                                            <>
                                                <i id={"croomgroupedit" + context.roomMasterId} className="ti-pencil-alt mr-2 pointer" onClick={editRoomGroup} ></i>
                                                <UncontrolledTooltip ref={tooltipRef1} color="primary" placement="top" target={"croomgroupedit" + context.roomMasterId}>
                                                    {t('ActionNames.edit')}
                                                </UncontrolledTooltip>
                                            </>}

                                        {actions.delete &&
                                            <>
                                                <i id="delete" className="ti-trash pointer" onClick={deleteRoomGroup}></i>
                                                <UncontrolledTooltip ref={tooltipRef1} color="primary" placement="top" target="delete">
                                                    {t('ActionNames.delete')}
                                                </UncontrolledTooltip>
                                            </>}
                                    </div>
                                    <div>
                                        <Label>{t('BranchAndRoom.roomEngName')}</Label>
                                        <span className="mb-0">{roomGroupItemData.roomNameEn}</span>
                                    </div>
                                    <div className="text-right">
                                        <Label>{t('BranchAndRoom.roomArbName')}</Label>
                                        <span className="mb-0">{roomGroupItemData.roomNameAr}</span>
                                    </div>
                                    <div>
                                        <Label>{t('BranchAndRoom.maxAllowedTokens')}</Label>
                                        <span className="mb-0">{roomGroupItemData.maxAllowedToken}</span>
                                    </div>

                                    <div className="text-right viewfooter">
                                        <button className="btn mb-4" onClick={() => setCollapse(!collapse)}>
                                            <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </CardBody>
                </Card>
            </div>}
        </>
    )
}

export default React.memo(RoomGroupView);