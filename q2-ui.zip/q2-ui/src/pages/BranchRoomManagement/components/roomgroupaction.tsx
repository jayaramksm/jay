import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Collapse, Label, Card, CardBody } from 'reactstrap';
import { ChildContext } from '../container/branchcontext';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { customContentValidation } from '../../../helpers/helpersIndex';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IBranchRoomModel, IRoom } from '../../../models/branchRoomModel';
import { setRoomGroupActionIdRequest, createOrEditRoomGroupRequest } from '../../../store/actions';

const RoomGroupAction: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context: IRoom = useContext<any>(ChildContext) ?.data;

    let roomGrouptemData: IRoom = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomGroupData) {
            let data = (state.branchAndRoomReducer as IBranchRoomModel).roomGroupData as IRoom[];
            let index = data ?.findIndex(x => x.roomMasterId === context.roomMasterId);

            if (index !== -1)
                return state.branchAndRoomReducer.roomGroupData[index] as IRoom;
            else return undefined;
        }
        else return undefined;
    });
    const actionType = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupActionType ? (state.branchAndRoomReducer as IBranchRoomModel).roomGroupActionType : 0;
        else return 0;
    });
    console.log("RoomGroupAction =>", roomGrouptemData, actionType);

    const cancelEdit = () => dispatch(setRoomGroupActionIdRequest(-1, 0, true));

    return (
        <>
            <div className={actionType !== IOprationalActions.ADD ? 'customCard' : ''}>
                <Card>
                    <CardBody>
                        <Collapse isOpen={true} className="CardColpsCnt" style={{ position: "absolute" }}>
                            <div style={{ marginBottom: "-50px" }}>
                                <div className="text-right mb-2" >
                                    <i className="ti-close pointer" onClick={cancelEdit}></i>
                                </div>
                                <Formik
                                    enableReinitialize
                                    initialValues={{
                                        roomMasterId: roomGrouptemData ? roomGrouptemData.roomMasterId : 0,
                                        roomNameEn: roomGrouptemData ? roomGrouptemData.roomNameEn : '',
                                        roomNameAr: roomGrouptemData ? roomGrouptemData.roomNameAr : '',
                                        maxAllowedToken: roomGrouptemData ? roomGrouptemData.maxAllowedToken : '',
                                    }}
                                    validationSchema={Yup.object().shape({
                                        roomNameEn: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
                                        roomNameAr: customContentValidation(t, t('controleErrors.required'), { patternType: 'arabicnumaricspacesp', message: 'arabicnumaricspace', spacialChar: null }, 50, 2),
                                        maxAllowedToken: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number' }, 2, 1)
                                    })}
                                    onSubmit={values => {
                                        console.log("onSubmit_Values =>", values);
                                        dispatch(createOrEditRoomGroupRequest(actionType, values));
                                    }}
                                >
                                    {({ errors, touched, dirty, setFieldValue }) => (
                                        <Form>
                                            <div className="form-group">
                                                <Label>{t('BranchAndRoom.roomEngName')}</Label>
                                                <Field placeholder={t('BranchAndRoom.roomEngName')} name="roomNameEn" type="text" className={'form-control ' + (errors.roomNameEn && touched.roomNameEn ? 'is-invalid' : '')} />
                                                <ErrorMessage name="roomNameEn" component='div' className="invalid-feedback" />
                                            </div>
                                            <div className="form-group text-right">
                                                <Label>{t('BranchAndRoom.roomArbName')}</Label>
                                                <Field placeholder={t('BranchAndRoom.roomArbName')} name="roomNameAr" type="text" className={'form-control text-right ' + (errors.roomNameAr && touched.roomNameAr ? 'is-invalid' : '')} />
                                                <ErrorMessage name="roomNameAr" component='div' className="invalid-feedback" />
                                            </div>
                                            <div className="form-group">
                                                <Label>{t('BranchAndRoom.maxAllowedTokens')}</Label>
                                                <Field placeholder={t('BranchAndRoom.maxAllowedTokens')} name="maxAllowedToken"
                                                    onChange={(e) => setFieldValue('maxAllowedToken', +e.target.value === 0 ? '' : e.target.value)}
                                                    type="text" className={'form-control ' + (errors.maxAllowedToken && touched.maxAllowedToken ? 'is-invalid' : '')}
                                                />
                                                <ErrorMessage name="maxAllowedToken" component='div' className="invalid-feedback" />
                                            </div>

                                            <button type="submit" disabled={!(dirty)} className="btn btn-primary mb-5">
                                                {actionType === IOprationalActions.ADD ? t('ActionNames.save') : t('ActionNames.update')}
                                            </button>
                                        </Form>
                                    )}
                                </Formik>
                            </div>
                        </Collapse>
                    </CardBody>
                </Card>
            </div>
        </>
    )
}
export default React.memo(RoomGroupAction);