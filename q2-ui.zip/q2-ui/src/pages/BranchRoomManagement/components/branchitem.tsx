import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../container/branch.css';
import { ChildContext } from '../container/branchcontext';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IBranchRoomModel } from '../../../models/branchRoomModel';
import { selectBranchActionDataRequest, branchSuspendOrEditActionRequest } from '../../../store/actions';

const BranchItem: React.FC = () => {

    const context: any = useContext(ChildContext);
    const dispatch = useDispatch();
    console.log("BranchItem_context =>", context);
    let branchData = useSelector(state => {
        if (state && state.branchAndRoomReducer) {
            let data = (state.branchAndRoomReducer as IBranchRoomModel).branchData;
            let index = data.findIndex(x => x.branchId === context);
            if (index !== -1)
                return state.branchAndRoomReducer.branchData[index];
            else return undefined;
        }
        else return undefined;
    });

    const selectedBranch = useSelector(state => {
        if (state && state.branchAndRoomReducer) {
            return (state.branchAndRoomReducer).actionData ?
                ((state.branchAndRoomReducer as IBranchRoomModel).actionData).branchId === (branchData ? branchData.branchId : false) : false;
        }
        else return false;
    });
    console.log("BranchItem =>", branchData, selectedBranch);

    const selectBranch = () => {
        dispatch(selectedBranch ? branchSuspendOrEditActionRequest(0, false) : selectBranchActionDataRequest(IOprationalActions.SELECT, branchData, false));
    }

    return (
        <>
            <span className={'btn btn-sm ' + (selectedBranch ? 'activeList' : '')} onClick={() => selectBranch()}  >
                {branchData && branchData.branchNameEn}
            </span>
        </>
    )
}

export default React.memo(BranchItem);