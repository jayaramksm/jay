import * as React from 'react';
import { Col, Row, Card, CardBody, Label, UncontrolledTooltip } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { useContext } from 'react';
import { ParentContext } from '../container/branchcontext';
import { IOprationalActions, ICheckedEnums } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import '../container/branch.css';
import { IBranch, IBranchType, IBranchRoomModel, IBranchServingCategory } from '../../../models/branchRoomModel';
import { deleteBranchRequestM, branchSuspendOrEditActionRequest } from '../../../store/actions';
import { getBranchTypeServingCategoryPriviliges } from '../../../helpers/helpersIndex';

const BranchView: React.FC = () => {

    const { t } = useTranslation("translations");
    const context: any = useContext(ParentContext);
    console.log('context_new => ', context);
    const dispatch = useDispatch();

    const branchActionData: IBranch = useSelector(state => {
        console.log("BranchView =>state", state.branchAndRoomReducer);
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.actionData)
            return (state.branchAndRoomReducer as IBranchRoomModel).actionData;
        else return undefined;
    });

    const branchTypes: IBranchType[] = useSelector(state => {
        if (state.branchAndRoomReducer && state.branchAndRoomReducer.branchTypesData)
            return (state.branchAndRoomReducer as IBranchRoomModel).branchTypesData;
        else return [];
    });
    console.log("BranchView =>", branchActionData, branchTypes);
    const branchTypeServingCategoryPriviliges: IBranchServingCategory | undefined = branchTypes?.length > 0 ? getBranchTypeServingCategoryPriviliges(branchTypes.find(x => x.branchTypeId === branchActionData.branchTypeId)?.branchTypeCode) : undefined

    const editBranch = () => {
        dispatch(branchSuspendOrEditActionRequest(IOprationalActions.EDIT, false));
    }

    const deleteBranch = (branchData) => {
        let message = t('BranchAndRoom.confirmMessages.BRC2').replace('{branchName}', branchData.branchNameEn);
        console.log("deleteBranch =>", IOprationalActions.DELETE, branchData.branchId, message, false);
        dispatch(deleteBranchRequestM(IOprationalActions.DELETE, branchData.branchId, message, false));
    }

    return (
        <Card>
            <CardBody style={{padding:"1rem"}}>
                <Row>
                    <Col sm="12">
                        <Row className="FormStyle">
                            <Col>
                                <Label>{t('BranchAndRoom.branchEngName')}</Label><br />
                                <span>{branchActionData.branchNameEn}</span>
                            </Col>
                            <Col>
                                <Row className="align-right">
                                    <Label>{t('BranchAndRoom.branchArbName')}</Label>
                                </Row>
                                <Row className="align-right">
                                    <span>{branchActionData.branchNameAr}</span>
                                </Row>
                            </Col>
                            <Col>
                                <Label>{t('BranchAndRoom.branchPrefix')}</Label><br />
                                <span>{branchActionData.branchIdentifier}</span>
                            </Col>
                            <Col>
                                <Label>{t('BranchAndRoom.serviceLocation')}</Label><br />
                                <span>{branchActionData.serviceLocation}</span>
                            </Col>
                        </Row>
                    </Col>
                </Row>

                <hr />

                <Row>
                    <Col sm="3">
                        <Label>{t('BranchAndRoom.selectBranchtype')}</Label>
                        <h6 className="my-0">{branchTypes && branchTypes.find(x => x.branchTypeId === branchActionData.branchTypeId)?.branchTypeDisplay}</h6>
                    </Col>
                    {branchTypeServingCategoryPriviliges && branchTypeServingCategoryPriviliges['registration'] && <Col className="align-center pr-0">
                        <div className="custom-control custom-checkbox align-vertical">
                            <input type="checkbox" disabled={true} checked={branchActionData?.isRegistration === ICheckedEnums.NCHECKED} className="custom-control-input" />
                            <label className="custom-control-label"> {t('BranchAndRoom.registration')}</label>
                        </div>
                    </Col>}
                    {branchTypeServingCategoryPriviliges && branchTypeServingCategoryPriviliges['vitals'] && <Col className="align-center px-0">
                        <div className="custom-control custom-checkbox align-vertical">
                            <input type="checkbox" disabled={true} checked={branchActionData?.isVital === ICheckedEnums.NCHECKED} className="custom-control-input" />
                            <label className="custom-control-label"> {t('BranchAndRoom.vitals')}</label>
                        </div>
                    </Col>}
                    {branchTypeServingCategoryPriviliges && branchTypeServingCategoryPriviliges['floating'] && <Col className="align-center pl-0">
                        <div className="custom-control custom-checkbox align-vertical">
                            <input type="checkbox" disabled={true} checked={branchActionData?.isFloating === ICheckedEnums.NCHECKED} className="custom-control-input" />
                            <label className="custom-control-label"> {t('BranchAndRoom.floating')}</label>
                        </div>
                    </Col>}
                    <Col className="align-right action">
                        {context.edit && <>
                            <span id="edit" className="ti-pencil-alt" onClick={() => editBranch()}> </span>
                            <UncontrolledTooltip color="primary" placement="top" target="edit">
                                {t('ActionNames.edit')}
                            </UncontrolledTooltip>
                        </>}
                        {context.delete && <>
                            <span id="delete" className="ti-trash" onClick={() => deleteBranch(branchActionData)}></span>
                        <UncontrolledTooltip color="primary" placement="top" target="delete">
                            {t('ActionNames.delete')}
                        </UncontrolledTooltip>
                        </>}
                    </Col>
                </Row>
            </CardBody>
        </Card>
    )
}

export default React.memo(BranchView);