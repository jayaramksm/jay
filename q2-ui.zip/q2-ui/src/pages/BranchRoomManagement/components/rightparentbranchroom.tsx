import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import '../container/branch.css';
import { SuperParentContext, ParentContext } from '../container/branchcontext';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import { IBranchRoomModel } from '../../../models/branchRoomModel';

const RightBranchRoomParent: React.FC = () => {

    const contextData: any = useContext(SuperParentContext);
    console.log("RightBranchRoomParent_Context =>", contextData);

    const actionArea = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).actionType;
        else return 0;
    });

    const actionRoomGroupArea = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel)?.roomGroupActionType === IOprationalActions.SELECT;
        else return false;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const modifiedContext = () => {
        return {
            branchView: contextData.branchView,
            branchAction: contextData.branchAction,
            parentRoomGroup: contextData.parentRoomGroup,
            pGroupManager: {
                roomGroupAddComponent: contextData.pGroupManager.roomGroupAddComponent,
                roomGroupView: contextData.pGroupManager.roomGroupView,
                roomGroupAction: contextData.pGroupManager.roomGroupAction,
                roomGroupItem: contextData.pGroupManager.roomGroupItem,
                actions: {
                    add: false,
                    edit: false,
                    delete: false
                }
            },
            roomManager: contextData.roomManager,
            pRoomManager: {
                roomNoAddComponent: contextData.pRoomManager.roomNoAddComponent,
                roomNoView: contextData.pRoomManager.roomNoView,
                roomNoAction: contextData.pRoomManager.roomNoAction,
                roomNoItem: contextData.pRoomManager.roomNoItem,
                actions: {
                    add: false,
                    edit: false,
                    delete: false
                }
            },
            actions: { edit: false, delete: false }
        }
    }

    const context = selectedLocationStatus ? contextData : modifiedContext();
    console.log("RightBranchRoomParent_actionArea =>", context, actionArea);

    return (
        <>


            <div className="flexLayout-inner">
                    <div className="pl-3 pr-3">

                    {(actionArea === IOprationalActions.ADD || actionArea === IOprationalActions.EDIT ) &&  <context.branchAction />}
                    {actionArea === IOprationalActions.BULKUPLOAD  &&   <context.branchBulkUpload/> }


                        {actionArea === IOprationalActions.SELECT && !actionRoomGroupArea &&
                            <ParentContext.Provider value={context.actions}>
                                <context.branchView />
                            </ParentContext.Provider>
                        }

                        <context.parentRoomGroup.selectedRoomGroup />

                        {(actionArea === IOprationalActions.SELECT || actionArea === IOprationalActions.EDIT) &&
                            <ParentContext.Provider value={context.pGroupManager}>
                                <context.parentRoomGroup.roomGroupManager />
                            </ParentContext.Provider>
                        }

                        <ParentContext.Provider value={context.pRoomManager}>
                            <context.roomManager />
                        </ParentContext.Provider>

                    </div>
            </div>


        </>
    )
}
export default React.memo(RightBranchRoomParent);