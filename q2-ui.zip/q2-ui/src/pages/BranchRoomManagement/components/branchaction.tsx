import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { Col, Row, Card, CardBody, FormGroup, Label } from 'reactstrap';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import { controleContentValidate, customContentValidation, MySelect, getBranchTypeServingCategoryPriviliges } from '../../../helpers/helpersIndex';
import * as Yup from 'yup';
import { IBranchRoomModel, IBranch, IBranchType } from '../../../models/branchRoomModel';
import { IOprationalActions, ICheckedEnums } from '../../../models/utilitiesModel';
import { branchSuspendOrEditActionRequest, createOrEditBranchRequest } from '../../../store/actions';
export interface optionsData {
    value: any;
    label: any;
}

const BranchAction: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    // const checked = false;

    const roleActionData = useSelector(state => {
        if ((state.branchAndRoomReducer))
            return (state.branchAndRoomReducer as IBranchRoomModel);
        else
            return undefined
    });

    const branchTypes: IBranchType[] = useSelector(state => {
        if (state.branchAndRoomReducer && state.branchAndRoomReducer.branchTypesData)
            return (state.branchAndRoomReducer as IBranchRoomModel).branchTypesData;
        else return [];
    });

    const branchTypeSelection = (value, values, setFieldValue) => {
        setFieldValue('branchType', value);
        let index = branchTypes.findIndex(x => x.branchTypeId === value.value);
        let servingCategoryPriviliges = index !== -1 ? getBranchTypeServingCategoryPriviliges(branchTypes[index].branchTypeCode) : undefined;
        setFieldValue('servingCategoryPriviliges', servingCategoryPriviliges);

    }

    const patchbranchType = (branchTypeId) => {
        let index = branchTypes.findIndex(x => x.branchTypeId === branchTypeId);
        return index !== -1 ? { value: branchTypes[index].branchTypeId, label: branchTypes[index].branchTypeDisplay } : '';
    }

    const patchServingCategory = (branchTypeId) => {
        let index = branchTypes.findIndex(x => x.branchTypeId === branchTypeId);
        return index !== -1 ? getBranchTypeServingCategoryPriviliges(branchTypes[index].branchTypeCode) : undefined;
    }

    const cancelEditFunction = () => {
        dispatch(branchSuspendOrEditActionRequest(roleActionData.actionType === IOprationalActions.EDIT ? IOprationalActions.SELECT : 0, true));
    }


    return (
        <>
            {roleActionData && (roleActionData.actionType === IOprationalActions.ADD || roleActionData.actionType === IOprationalActions.EDIT) && <Formik
                enableReinitialize
                initialValues={{
                    branchId: roleActionData.actionData ? roleActionData.actionData.branchId : 0,
                    branchNameEn: roleActionData.actionData ? roleActionData.actionData.branchNameEn : '',
                    branchNameAr: roleActionData.actionData ? roleActionData.actionData.branchNameAr : '',
                    branchPrefix: roleActionData.actionData ? roleActionData.actionData.branchIdentifier : '',
                    serviceLocation: roleActionData.actionData ? roleActionData.actionData.serviceLocation : '',
                    branchType: roleActionData.actionData ? patchbranchType(roleActionData.actionData.branchTypeId) : branchTypes.length === 1 ? { value: branchTypes[0].branchTypeId, label: branchTypes[0].branchTypeDisplay } : '',
                    registration: roleActionData.actionData && roleActionData.actionData.isRegistration ? ICheckedEnums.NCHECKED : ICheckedEnums.NUNCHECKED,
                    vitals: roleActionData.actionData && roleActionData.actionData.isVital ? ICheckedEnums.NCHECKED : ICheckedEnums.NUNCHECKED,
                    floating: roleActionData.actionData && roleActionData.actionData.isFloating ? ICheckedEnums.NCHECKED : ICheckedEnums.NUNCHECKED,
                    servingCategoryPriviliges: roleActionData.actionData ? patchServingCategory(roleActionData.actionData.branchTypeId) : branchTypes.length === 1 ? patchServingCategory(branchTypes[0].branchTypeId) : undefined
                }}
                validationSchema={Yup.object().shape({
                    branchNameEn: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
                    branchNameAr: customContentValidation(t, t('controleErrors.required'), { patternType: 'arabicnumaricspacesp', message: 'arabicnumaricspace', spacialChar: null }, 50, 2),
                    branchPrefix: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 10, 2),
                    serviceLocation: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
                    branchType: controleContentValidate(t('controleErrors.required'))
                })}
                onSubmit={(values, { resetForm }) => {
                    console.log("Values =>", values);
                    let branchTypeId = values.branchType === '' ? 0 : (values.branchType as optionsData).value;
                    let branch = {
                        branchId: values.branchId,
                        branchNameEn: values.branchNameEn,
                        branchNameAr: values.branchNameAr,
                        branchIdentifier: values.branchPrefix,
                        serviceLocation: values.serviceLocation,
                        branchTypeId: branchTypeId,
                        isRegistration: (values.servingCategoryPriviliges && values.servingCategoryPriviliges['registration']) ? values.registration : ICheckedEnums.NUNCHECKED,
                        isVital: (values.servingCategoryPriviliges && values.servingCategoryPriviliges['vitals']) ? values.vitals : ICheckedEnums.NUNCHECKED,
                        isFloating: (values.servingCategoryPriviliges && values.servingCategoryPriviliges['floating']) ? values.floating : ICheckedEnums.NUNCHECKED,
                    } as IBranch;
                    console.log("onSubmit_Branch =>", branch);
                    dispatch(createOrEditBranchRequest(roleActionData.actionType, branch));
                }}
            >
                {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                    <Form>
                        <Card>
                            <CardBody>
                                <Row>
                                    <Col sm="12">
                                        <Row className="FormStyle">
                                            <Col>
                                                <FormGroup>
                                                    <Field name="branchNameEn" placeholder={t('BranchAndRoom.branchEngName')}
                                                        className={'form-control ' + (errors.branchNameEn && touched.branchNameEn ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="branchNameEn" component="div" className="invalid-feedback" />
                                                    <Label className="label" htmlFor="example-text-input">{t('BranchAndRoom.branchEngName')}</Label>
                                                </FormGroup>
                                            </Col>
                                            <Col className="text-right right-align">
                                                <FormGroup>
                                                    <Field name="branchNameAr" placeholder={t('BranchAndRoom.branchArbName')}
                                                        className={'form-control text-right ' + (errors.branchNameAr && touched.branchNameAr ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="branchNameAr" component="div" className="invalid-feedback" />
                                                    <Label className="label" htmlFor="example-text-input">{t('BranchAndRoom.branchArbName')}</Label>
                                                </FormGroup>
                                            </Col>
                                            <Col>
                                                <FormGroup>
                                                    <Field name="branchPrefix" placeholder={t('BranchAndRoom.branchPrefix')}
                                                        className={'form-control ' + (errors.branchPrefix && touched.branchPrefix ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="branchPrefix" component="div" className="invalid-feedback" />
                                                    <Label className="label" htmlFor="example-text-input">{t('BranchAndRoom.branchPrefix')}</Label>
                                                </FormGroup>
                                            </Col>
                                            <Col>
                                                <FormGroup>
                                                    <Field name="serviceLocation" placeholder={t('BranchAndRoom.serviceLocation')}
                                                        className={'form-control ' + (errors.serviceLocation && touched.serviceLocation ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="serviceLocation" component="div" className="invalid-feedback" />
                                                    <Label className="label" htmlFor="example-text-input">{t('BranchAndRoom.serviceLocation')}</Label>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>

                                <hr />

                                <Row>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label>{t('BranchAndRoom.selectBranchtype')}</Label>
                                            <MySelect
                                                name="branchType"
                                                placeholder={t('BranchAndRoom.selectBranchtype')}
                                                value={values.branchType}
                                                onChange={(e) => branchTypeSelection(e, values, setFieldValue)}
                                                options={branchTypes.map(item => ({ value: item.branchTypeId, label: item.branchTypeDisplay }))}
                                                getOptionLabel={option => option.label}
                                                getOptionValue={option => option.value}
                                                onBlur={() => setFieldTouched('branchType', true)}
                                                noOptionsMessage={() => t('BranchAndRoom.noBranchTypes')}
                                            />
                                            {errors.branchType && touched.branchType && (
                                                <div className="error-msg">{errors.branchType}
                                                </div>
                                            )}
                                        </FormGroup>
                                    </Col>
                                    {values.servingCategoryPriviliges && values.servingCategoryPriviliges['registration'] && <Col className="align-center pr-0">
                                        <FormGroup className="custom-control custom-checkbox align-vertical mb-0">
                                            <input type="checkbox" name="registration" id="registration"
                                                checked={values.registration === ICheckedEnums.NCHECKED}
                                                className="custom-control-input"
                                                onChange={(e) => {
                                                    if (e.target.checked)
                                                        setFieldValue('registration', ICheckedEnums.NCHECKED);
                                                    else
                                                        setFieldValue('registration', ICheckedEnums.NUNCHECKED);
                                                }}
                                            />
                                            <label className="custom-control-label" htmlFor="registration" > {t('BranchAndRoom.registration')}</label>
                                        </FormGroup>
                                    </Col>}
                                    {values.servingCategoryPriviliges && values.servingCategoryPriviliges['vitals'] && <Col className="align-center px-0">
                                        <FormGroup className="custom-control custom-checkbox align-vertical mb-0">
                                            <input type="checkbox" name="vitals" id="vitals"
                                                checked={values.vitals === ICheckedEnums.NCHECKED}
                                                className="custom-control-input"
                                                onChange={(e) => {
                                                    if (e.target.checked)
                                                        setFieldValue('vitals', ICheckedEnums.NCHECKED);
                                                    else
                                                        setFieldValue('vitals', ICheckedEnums.NUNCHECKED);
                                                }}
                                            />
                                            <label className="custom-control-label" htmlFor="vitals"> {t('BranchAndRoom.vitals')}</label>
                                        </FormGroup>
                                    </Col>}
                                    {values.servingCategoryPriviliges && values.servingCategoryPriviliges['floating'] && <Col className="align-center pl-0">
                                        <FormGroup className="custom-control custom-checkbox align-vertical mb-0">
                                            <input type="checkbox" name="floating" id="floating"
                                                checked={values.floating === ICheckedEnums.NCHECKED}
                                                className="custom-control-input"
                                                onChange={(e) => {
                                                    if (e.target.checked)
                                                        setFieldValue('floating', ICheckedEnums.NCHECKED);
                                                    else
                                                        setFieldValue('floating', ICheckedEnums.NUNCHECKED);
                                                }}
                                            />
                                            <label className="custom-control-label" htmlFor="floating"> {t('BranchAndRoom.floating')}</label>
                                        </FormGroup>
                                    </Col>}
                                </Row>
                                <hr />
                                <Row>
                                    <Col className="align-right">
                                        {/* <button className="btn btn-primary">Upload CSV&nbsp; <span className="addbtn">+</span></button> */}
                                        <button type="submit" disabled={!(dirty)} className="btn btn-primary ml-2"> {roleActionData.actionType === IOprationalActions.ADD ? t('ActionNames.save') : t('ActionNames.update')} </button>
                                        <button type="button" className="btn btn-cancel ml-2" onClick={cancelEditFunction}>{t('ActionNames.cancel')}</button>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                    </Form>
                )}
            </Formik>}
        </>
    )
}

export default React.memo(BranchAction);


