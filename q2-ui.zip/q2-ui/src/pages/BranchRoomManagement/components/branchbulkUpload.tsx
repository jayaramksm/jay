import React from 'react';
import '../container/branch.css'
import Papa from 'papaparse';
import { useDispatch, useSelector } from 'react-redux';
import { Col, Row, Card, CardBody, FormGroup, Label } from 'reactstrap';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import { controleContentValidate, customContentValidation, getBranchTypeServingCategoryPriviliges, MySelect, defultContentValidate } from 'helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import * as _ from 'lodash';
import * as XLSX from 'xlsx';
import { bulkUploadBranchSubmitActionRequest, branchSuspendOrEditActionRequest } from '../../../store/actions';
import { IColumnsBranch, IBranchType, IBranchRoomModel, IBulkUploadBranchData } from '../../../models/branchRoomModel';
import { IOprationalActions, ICheckedEnums } from '../../../models/utilitiesModel';
import { DownloadExcel, DownloadCsv } from '../../../helpers/helpersIndex';
import csv from '../../../images/csv.svg';
import xls from '../../../images/xls.svg';
import xlsx from '../../../images/xlsx.svg';
import info from '../../../images/info.svg';

export interface optionsData {
    value: any;
    label: any;
}
const headerNames = {
    DeptNameEn: "DeptNameEn*",
    DeptNameAr: "DeptNameAr*",
    branchIdentifier: "DepartmentPrefix*",
    ServiceLocation: "ServiceLocation*"
}

const BranchBulkuploadComponent: React.FC = () => {

    const { t } = useTranslation("translations");
    let dispatch = useDispatch();

    const sampleData = [
        {
            [headerNames.DeptNameEn]: '',
            [headerNames.DeptNameAr]: '',
            [headerNames.branchIdentifier]: '',
            [headerNames.ServiceLocation]: ''
        }
    ];
    console.log("BranchBulkuploadComponent_sampleData =>", sampleData);
    const DownloadXlsRequest = () => {
        const res = DownloadExcel(null, '', sampleData, 'Department.xls', '')
        console.log('DownloadExcelRequest=>', res);
    }
    const DownloadExcelRequest = () => {
        const res = DownloadExcel(null, '', sampleData, 'Department.xlsx', '')
        console.log('DownloadExcelRequest=>', res);
    }
    const DownloadCsvRequest = () => {
        const res = DownloadCsv(null, '', sampleData, 'Department', '');
        console.log('DownloadCsvRequest=>', res);
    }
    const validationSchema = {
        branch: Yup.object().shape({
            branchNameEn: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
            branchNameAr: customContentValidation(t, t('controleErrors.required'), { patternType: 'arabicnumaricspacesp', message: 'arabicnumaricspace', spacialChar: null }, 50, 2),
            branchIdentifier: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 10, 2),
            serviceLocation: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
        })
    }

    const branchTypes: IBranchType[] = useSelector(state => {
        if (state.branchAndRoomReducer && state.branchAndRoomReducer.branchTypesData)
            return (state.branchAndRoomReducer as IBranchRoomModel).branchTypesData;
        else return [];
    });

    const branchTypeSelection = (e, values, setFieldValue) => {
        setFieldValue('branchType', e);
        let index = branchTypes.findIndex(x => x.branchTypeId === e.value);
        let servingCategoryPriviliges = index !== -1 ? getBranchTypeServingCategoryPriviliges(branchTypes[index].branchTypeCode) : undefined;
        setFieldValue('servingCategoryPriviliges', servingCategoryPriviliges);
    }
    const getColumnsPatch = (keysData, setFieldValue) => {
        let index: any = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.DeptNameEn.toLowerCase());
        if (index !== -1)
            setFieldValue('branchNameEn', keysData[index].value);

        const index1 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.DeptNameAr.toLowerCase());
        if (index1 !== -1)
            setFieldValue('branchNameAr', keysData[index1].value);

        const index2 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.branchIdentifier.toLowerCase());
        if (index2 !== -1)
            setFieldValue('branchPrefix', keysData[index2].value);

        const index3 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.ServiceLocation.toLowerCase());
        if (index3 !== -1)
            setFieldValue('serviceLocation', keysData[index3].value);
    }

    const sheetSelection = (e, setFieldValue, values) => {
        setFieldValue('branchNameEn', '');
        setFieldValue('branchPrefix', '');
        setFieldValue('branchNameAr', '');
        setFieldValue('serviceLocation', '');
        let ind = values.excelSheetData.findIndex(x => x.viewValue === e.value);
        console.log("onSheetSelection==>", e, values, ind);
        if (ind !== -1) {
            setFieldValue('selectedSheet', e);
            setFieldValue('columnsData', []);
            let columndata = values.excelSheetData[ind].value;
            let keysData = (columndata[0] as any[]).filter(x => x);
            let papaColumnsData = keysData.map(x => ({ label: x, value: x }));
            setFieldValue('columnsData', keysData.map(x => ({ label: x, value: x })));
            setFieldValue('fileDataCount', columndata?.length - 1);
            getColumnsPatch(papaColumnsData, setFieldValue);
            console.log("keysData=>", keysData, columndata, values);
        }
        else {
            setFieldValue('selectedSheet', null);
            setFieldValue('columnsData', null);
        }
    }

    const uploadFile = (event, setFieldValue) => {

        if (event.target.value) {
            setFieldValue('branchNameEn', '');
            setFieldValue('branchPrefix', '');
            setFieldValue('branchNameAr', '');
            setFieldValue('serviceLocation', '');
            setFieldValue('excelSheetData', []);
            setFieldValue('sheetList', '');
            setFieldValue('selectedSheet', '');
            setFieldValue('fileName', '');
            setFieldValue('columnsData', '');
            setFieldValue('fileDataCount', '');
            setFieldValue('extension', '');
            setFieldValue('invalidFileExtensionError', '');

            const fileList: FileList = event.target.files;
            console.log("frmData=>1", event.target.files);
            if (fileList.length > 0) {
                const file: File = fileList[0];
                console.log("File", file);
                let extension = (file.name as string).split('.').pop();
                let fileSize = file.size / 1024 / 1024;
                console.log("File", file, fileSize);
                if (fileSize < 5) {
                    if (extension === "xlsx" || extension === "xls" || extension === "csv") {
                        setFieldValue('extension', extension);
                        setFieldValue('uploadedFile', fileList[0]);
                        setFieldValue('fileName', fileList[0].name);
                        if (extension === "xlsx" || extension === "xls") {
                            const reader: FileReader = new FileReader();
                            reader.onload = (e: any) => {
                                const arrayBuffer = e.target.result,
                                    data = new Uint8Array(arrayBuffer),
                                    arr = new Array();
                                for (let i = 0; i !== data.length; ++i) {
                                    arr[i] = String.fromCharCode(data[i]);
                                }
                                const bstr: string = arr.join('');
                                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
                                let excelSheetData: any = [];
                                let excelSheetList: any = [];
                                wb.SheetNames.forEach(element => {
                                    let wsname: string = element;
                                    let ws: XLSX.WorkSheet = wb.Sheets[wsname];
                                    let data1 = ((XLSX.utils.sheet_to_json(ws, { header: 1 })));
                                    data1 = data1.filter(z => (z as any[])?.length > 0)
                                    if (data1?.length > 1) {
                                        excelSheetList.push({ value: element, label: element });
                                        excelSheetData.push({ value: data1, viewValue: wsname })
                                    }
                                });
                                if (excelSheetData?.length === 0)
                                    setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                if (excelSheetList?.length === 1) {
                                    setFieldValue('sheetList', excelSheetList);
                                    setFieldValue('selectedSheet', excelSheetList[0]);
                                    let columndata = excelSheetData[0].value;
                                    let keysData = (columndata[0] as any[]).filter(x => x).map(x => ({ value: x, label: x }));
                                    setFieldValue('columnsData', keysData);
                                    setFieldValue('fileDataCount', excelSheetData[0].value.length - 1);
                                    getColumnsPatch(keysData, setFieldValue);
                                }
                                console.log('uploadFile_excelSheetData=>', excelSheetData);
                                setFieldValue('excelSheetData', excelSheetData);
                                setFieldValue('sheetList', excelSheetList);
                            }
                            reader.readAsArrayBuffer(event.target.files[0]);
                        }
                        else {
                            Papa.parse(file, {
                                delimiter: ',', header: true, newline: '\r\n',
                                beforeFirstChunk: (chunk: string) => {
                                    var rows = chunk.split(/\r\n|\r|\n/);
                                    let headings = rows[0].split(',');
                                    console.log("chunk=>", chunk, headings);
                                    let index3 = headings.findIndex(x => x === null || (x + '').trim() === "");
                                    if (index3 !== -1) {
                                        setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                        return "empty";
                                    }
                                    let index4 = _.uniq(_.filter(headings, (v, i, a) => a.findIndex(x => (v + '').trim() === (x + '').trim()) !== i));
                                    if (index4.length > 0) {
                                        setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                        return "duplicate";
                                    }
                                    return chunk
                                },
                                complete: (results) => {
                                    console.log("results=>", results);

                                    if (results.data.length > 0) {
                                        let _fileText = results.data;
                                        let keysData = Object.keys(_fileText[0]).filter(x => x !== '__parsed_extra');
                                        console.log("columns=>", _fileText, keysData);
                                        // let columnsCount: number = keysData.length;
                                        let index1 = keysData.findIndex(x => x === null);
                                        if (index1 !== -1) {
                                            setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                        }
                                        else {
                                            let papaColumnsData = keysData.map(x => ({ label: x, value: x }));
                                            setFieldValue('columnsData', keysData.map(x => ({ label: x, value: x })));
                                            setFieldValue('fileDataCount', _fileText?.length);
                                            setFieldValue('excelSheetData', _fileText);
                                            getColumnsPatch(papaColumnsData, setFieldValue);
                                        }
                                    }
                                }
                            });
                        }
                    }
                    else
                        setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                    event.target.value = null;
                }
                else
                    setFieldValue('invalidFileExtensionError', t("controleErrors.maxFileSize"));
            }
        }
    }


    const cancelBuliUpload = () => {
        dispatch(branchSuspendOrEditActionRequest(IOprationalActions.UNSELECT, true));
    }

    return (<>
        <Card>
            <CardBody>
                <Formik
                    enableReinitialize
                    initialValues={{
                        serviceLocation: '',
                        branchNameEn: '',
                        branchPrefix: '',
                        branchNameAr: '',
                        branchType: '',
                        vitals: ICheckedEnums.NUNCHECKED,
                        floating: ICheckedEnums.NUNCHECKED,
                        registration: ICheckedEnums.NUNCHECKED,
                        servingCategoryPriviliges: '',
                        excelSheetData: [],
                        columnsData: '',
                        invalidFileExtensionError: '',
                        uploadFile: '',
                        fileName: '',
                        sheetList: [],
                        selectedSheet: '',
                        fileDataCount: '',
                        extension: ''
                    }}
                    validationSchema={Yup.object().shape({
                        branchNameAr: controleContentValidate(t('controleErrors.required')),
                        branchNameEn: controleContentValidate(t('controleErrors.required')),
                        branchPrefix: controleContentValidate(t('controleErrors.required')),
                        serviceLocation: controleContentValidate(t('controleErrors.required')),
                        branchType: controleContentValidate(t('controleErrors.required')),
                        fileName: defultContentValidate(t("controleErrors.uploadFile")),
                        selectedSheet: Yup.string().when('extension', {
                            is: val => (val === 'xls' || val === 'xlsx'),
                            then: defultContentValidate(t('controleErrors.required')),
                            otherwise: defultContentValidate('')
                        })
                    })}
                    onSubmit={(values) => {
                        console.log("onSubmit_Values =>", values);
                        let columnsData: IColumnsBranch = {
                            branchNameEn: values.branchNameEn,
                            branchNameAr: values.branchNameAr,
                            branchIdentifier: values.branchPrefix,
                            serviceLocation: values.serviceLocation
                        };
                        let extension = (values?.extension ? values.extension : '').toLowerCase();
                        let branchTypeId = values.branchType === '' ? 0 : (values.branchType as any)?.value;
                        let requestObj: IBulkUploadBranchData = {
                            branchTypeId: branchTypeId,
                            isRegistration: (values.servingCategoryPriviliges && values.servingCategoryPriviliges['registration']) ? values.registration : ICheckedEnums.NUNCHECKED,
                            isVital: (values.servingCategoryPriviliges && values.servingCategoryPriviliges['vitals']) ? values.vitals : ICheckedEnums.NUNCHECKED,
                            isFloating: (values.servingCategoryPriviliges && values.servingCategoryPriviliges['floating']) ? values.floating : ICheckedEnums.NUNCHECKED,
                            mappedColumns: columnsData,
                            validationSchema: validationSchema.branch,
                            extension: extension,
                            data: extension === "xlsx" || extension === "xls" ? (values.excelSheetData as any[]).find(x => x?.viewValue === (values.selectedSheet as any)?.value)?.value : values.excelSheetData,
                            translator: t
                        }
                        console.log("onSubmit_requestObj =>", requestObj);
                        dispatch(bulkUploadBranchSubmitActionRequest(requestObj));
                    }}
                >
                    {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                        <Form>
                            {values.branchType && <> <div>
                                <Row>

                                    <Col>
                                        <Row>
                                            <div className="pt-3 pl-3 mr-2">
                                                <label htmlFor="bulkUploadFile" className="btn btn-primary">{t('ActionNames.uploadFile')}</label>
                                                <input type="file" accept=".csv, .xls, .xlsx" onChange={e => uploadFile(e, setFieldValue)} onBlur={() => setFieldTouched('fileName', true)} id="bulkUploadFile" style={{ display: 'none' }} />
                                                {errors.fileName && touched.fileName && (
                                                    <div className="error-msg">{errors.fileName}
                                                    </div>
                                                )}

                                            </div>
                                            <div className="px-2 pt-3 fileNCount">
                                                {values.fileName && <div className="fileName">{values.fileName}</div>}
                                                {values.fileDataCount && <div>{t('ActionNames.count')}  <span className="formatclr">{values.fileDataCount}</span></div>}

                                            </div>
                                            {(values.fileName && values.invalidFileExtensionError === '') && <>
                                                {values.extension !== 'csv' && <Col sm="5"><div className="FormStyle">
                                                    <FormGroup>
                                                        <Label>{t('UserManagement.sheetList')}</Label>
                                                        <MySelect
                                                            name="selectedSheet"
                                                            placeholder={t('UserManagement.selectSheetList')}
                                                            value={values.selectedSheet}
                                                            onChange={(e) => sheetSelection(e, setFieldValue, values)}
                                                            options={values.sheetList}
                                                            getOptionLabel={option => option.label}
                                                            getOptionValue={option => option.value}
                                                            onBlur={() => setFieldTouched('selectedSheet', true)}
                                                        />
                                                        {errors.selectedSheet && touched.selectedSheet && (
                                                            <div className="error-msg">{errors.selectedSheet}
                                                            </div>
                                                        )}
                                                    </FormGroup>
                                                </div>
                                                </Col>
                                                }</>}
                                        </Row><div className="pb-1 pt-2 align-left"><img src={info} alt="" style={{ width: "17px" }} />&nbsp; <span className="formatclr">{t('ActionNames.format')}</span>{t('ActionNames.exFileFormat')}</div>


                                    </Col>




                                    <div className="px-3">
                                        <span>{t('ActionNames.samplefiles')}</span>
                                        <div className="mt-2">
                                            <img alt="" src={xls} className="pointer" style={{ width: '27px' }} onClick={DownloadXlsRequest} />
                                            <img alt="" src={xlsx} className="pointer" style={{ width: '29px', margin: '0 8px' }} onClick={DownloadExcelRequest} />
                                            <img alt="" src={csv} className="pointer" style={{ width: '25px' }} onClick={DownloadCsvRequest} />
                                        </div>
                                    </div>
                                </Row>
                                <div className="pt-1">
                                    {values.invalidFileExtensionError && <div className="error-msg">{values.invalidFileExtensionError}</div>}
                                    {values.columnsData && !values.invalidFileExtensionError && errors.branchNameEn && values.branchNameEn === '' && <div className="file-errors">{t("BranchAndRoom.invalidDeptNameEn")}</div>}
                                    {values.columnsData && !values.invalidFileExtensionError && errors.branchNameAr && values.branchNameAr === '' && <div className="file-errors">{t("BranchAndRoom.invalidDeptNameAr")}</div>}
                                    {values.columnsData && !values.invalidFileExtensionError && errors.branchPrefix && values.branchPrefix === '' && <div className="file-errors">{t("BranchAndRoom.invalidDepartmentPrefix")}</div>}
                                    {values.columnsData && !values.invalidFileExtensionError && errors.serviceLocation && values.serviceLocation === '' && <div className="file-errors">{t("BranchAndRoom.invalidServiceLocation")}</div>}
                                </div>
                                <div>
                                    <ul className="pl-3 pt-2 instructions">
                                        <li>{t('BranchAndRoom.helperPonit1')}</li>
                                        <li>{t('BranchAndRoom.helperPonit2')}</li>
                                        <li>{t('BranchAndRoom.helperPonit3')}</li>
                                        <li>{t('BranchAndRoom.helperPonit4')}</li>
                                        <li>{t('BranchAndRoom.helperPonit5')}</li>
                                    </ul>
                                </div>
                            </div> <hr /></>}


                            <Row>
                                <Col sm="4">
                                    <FormGroup>
                                        <Label>{t('BranchAndRoom.selectBranchtype')}</Label>
                                        <MySelect
                                            name="branchType"
                                            placeholder={t('BranchAndRoom.selectBranchtype')}
                                            value={values.branchType}
                                            onChange={(e) => branchTypeSelection(e, values, setFieldValue)}
                                            options={branchTypes.map(item => ({ value: item.branchTypeId, label: item.branchTypeDisplay }))}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('branchType', true)}
                                            noOptionsMessage={() => t('BranchAndRoom.noBranchTypes')}
                                        />
                                        {errors.branchType && touched.branchType && (
                                            <div className="error-msg">{errors.branchType}
                                            </div>
                                        )}
                                    </FormGroup>
                                </Col>
                                {values.servingCategoryPriviliges && values.servingCategoryPriviliges['registration'] && <Col className="align-center pr-0">
                                    <FormGroup className="custom-control custom-checkbox align-vertical mb-0">
                                        <input type="checkbox" name="registration" id="registration"
                                            checked={values.registration === ICheckedEnums.NCHECKED}
                                            className="custom-control-input"
                                            onChange={(e) => {
                                                if (e.target.checked)
                                                    setFieldValue('registration', ICheckedEnums.NCHECKED);
                                                else
                                                    setFieldValue('registration', ICheckedEnums.NUNCHECKED);
                                            }}
                                        />
                                        <label className="custom-control-label" htmlFor="registration" > {t('BranchAndRoom.registration')}</label>
                                    </FormGroup>
                                </Col>}
                                {values.servingCategoryPriviliges && values.servingCategoryPriviliges['vitals'] && <Col className="align-center px-0">
                                    <FormGroup className="custom-control custom-checkbox align-vertical mb-0">
                                        <input type="checkbox" name="vitals" id="vitals"
                                            checked={values.vitals === ICheckedEnums.NCHECKED}
                                            className="custom-control-input"
                                            onChange={(e) => {
                                                if (e.target.checked)
                                                    setFieldValue('vitals', ICheckedEnums.NCHECKED);
                                                else
                                                    setFieldValue('vitals', ICheckedEnums.NUNCHECKED);
                                            }}
                                        />
                                        <label className="custom-control-label" htmlFor="vitals"> {t('BranchAndRoom.vitals')}</label>
                                    </FormGroup>
                                </Col>}
                                {values.servingCategoryPriviliges && values.servingCategoryPriviliges['floating'] && <Col className="align-center pl-0">
                                    <FormGroup className="custom-control custom-checkbox align-vertical mb-0">
                                        <input type="checkbox" name="floating" id="floating"
                                            checked={values.floating === ICheckedEnums.NCHECKED}
                                            className="custom-control-input"
                                            onChange={(e) => {
                                                if (e.target.checked)
                                                    setFieldValue('floating', ICheckedEnums.NCHECKED);
                                                else
                                                    setFieldValue('floating', ICheckedEnums.NUNCHECKED);
                                            }}
                                        />
                                        <label className="custom-control-label" htmlFor="floating"> {t('BranchAndRoom.floating')}</label>
                                    </FormGroup>
                                </Col>}
                            </Row>
                            <div>
                                <div className="helpText">{t('BranchAndRoom.helpText1')}</div>
                                <ul className="pl-3 instructions">
                                    <li>{t('BranchAndRoom.helpText2')}</li>
                                    <li>{t('BranchAndRoom.helpText3')}</li>
                                </ul>
                            </div>
                            <hr />
                            <Row>
                                <Col className="action">
                                    <button type="submit" disabled={!(dirty)} className="btn btn-primary">{t('ActionNames.submit')}</button>
                                    <button type="button" className="btn btn-cancel ml-2" onClick={cancelBuliUpload}>{t('ActionNames.cancel')}</button>
                                </Col>
                            </Row>

                        </Form>
                    )}
                </Formik>


            </CardBody>
        </Card>
    </>)

}

export default React.memo(BranchBulkuploadComponent)