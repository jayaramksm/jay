import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row } from 'reactstrap';
import { ParentContext, ChildContext } from '../container/branchcontext';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { IRoom, IBranchRoomModel } from '../../../models/branchRoomModel';
import { PaginationComponent } from '../../Utilities/PaginationComponent';
import { setBranchRoomSearchKey, setRoomsPagination } from '../../../store/actions';
import { IOprationalActions } from '../../../models/utilitiesModel';

const RoomGroupManager: React.FC = () => {

    const { t } = useTranslation("translations");
    const context: any = useContext(ParentContext);
    console.log("ParentRoomGroup_context =>", context);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageRightSize + (context?.actions?.add ? 0 : 1);

    const roomGroupData: IRoom[] = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupData ? (state.branchAndRoomReducer.roomGroupData) : undefined;
        else return undefined;
    });
    const roomGroupDataCount = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomGroupData)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupData.length;
        else return 0;
    });
    console.log("roomGroupDataCount =>", roomGroupDataCount);

    const searchKey = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupSearchKey ? (state.branchAndRoomReducer as IBranchRoomModel).roomGroupSearchKey : '';
        else return '';
    });
    let currentPage = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomsCurrentPage)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomsCurrentPage;
        else return 0;
    });

    let filterRoomGroupData: IRoom[] = (searchKey && searchKey !== '') ?
        roomGroupData.filter(x => x.roomNameEn.toLowerCase().startsWith(searchKey.toLowerCase())) : roomGroupData;

    const isSelectAction = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupActionType === IOprationalActions.SELECT;
        else return false;
    });
    console.log("filterRoomGroupData =>", filterRoomGroupData);

    let pagesCount = Math.ceil((filterRoomGroupData ? filterRoomGroupData.length : 0) / pageSize);
    // const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        // setCurrentPage(0);
        currentPage = 0;

    const handleClick = (e, index) => {
        e.preventDefault();
        // setCurrentPage(index)
        dispatch(setRoomsPagination(index));
    }

    const setSearchkey = e => {
        dispatch(setBranchRoomSearchKey(e.target.value, 2));
    }

    return (
        <>
            {!isSelectAction && <>
                {roomGroupData && roomGroupData.length > 0 && <div className="app-search w-50 p-0 form-group mb-0 mt-3">
                    <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} value={searchKey} onChange={setSearchkey} />
                    <i className="fa fa-search"></i>
                </div>}

                <Row className="mt-4 branchcard lyt2-rgtclmn mx-0">
                    {context.actions.add && <div className="customCard addCustomCard">
                        <context.roomGroupAddComponent />
                    </div>}
                    {filterRoomGroupData && filterRoomGroupData.length > 0 && filterRoomGroupData.slice(currentPage * pageSize,
                        (currentPage + 1) * pageSize)
                        .map((x) => {
                            return (
                                <ChildContext.Provider key={x.roomMasterId} value={{ data: x, actions: context.actions }}>
                                    <context.roomGroupItem />
                                </ChildContext.Provider>
                            )
                        })
                    }
                    {filterRoomGroupData && searchKey === '' && filterRoomGroupData.length === 0 && <span className="align-center mb-4">{t('BranchAndRoom.noRoomGroupsFound')}</span>}
                    {filterRoomGroupData && searchKey !== '' && filterRoomGroupData.length === 0 && <span>{t('BranchAndRoom.noSearchRoomsFound')}</span>}
                </Row>

                {filterRoomGroupData && filterRoomGroupData.length > pageSize && <Row className="justify-content-end rgt-pagination mx-0">
                    <div className="pagination mr-3 pt-3">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                </Row>}
            </>}

        </>
    )
}
export default React.memo(RoomGroupManager);