import * as React from 'react';
import { Col, Row, Card, CardBody, Label } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import '../container/branch.css';
import { IBranchRoomModel, IRoom, IBranch } from '../../../models/branchRoomModel';
import { selectRoomGroupActionSuspendRequest } from '../../../store/actions';

const SelectedRoomGroup: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const branchActionData: IBranch = useSelector(state => {
        console.log("BranchView =>state", state.branchAndRoomReducer);
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.actionData)
            return (state.branchAndRoomReducer as IBranchRoomModel).actionData;
        else return undefined;
    });
    
    const roomActionData: IRoom = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomActionData)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomActionData;
        else return undefined;
    });

    const actionRoomGroupArea = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupActionType;
        else return undefined;
    });

    console.log("RoomGroupView_roomActionData =>", roomActionData, actionRoomGroupArea);

    const selectActionSuspend = () => {
        dispatch(selectRoomGroupActionSuspendRequest(false))
    }

    return (
        <>
            {roomActionData && actionRoomGroupArea === IOprationalActions.SELECT && <Card>
                <CardBody>
                    <Row  className="mx-0">
                        <Col sm="12">
                        <div  className="mb-3">
                            <span style={{fontWeight:600, color:'#5d62b5'}}>{branchActionData.branchNameEn}</span>
                        </div>
                            <Row className="FormStyle">
                                <Col sm="3">
                                    <Label>{t('BranchAndRoom.roomEngName')}</Label><br />
                                    <span>{roomActionData.roomNameEn}</span>
                                </Col>
                                <Col sm="3">
                                    <Row className="right-align">
                                        <Label>{t('BranchAndRoom.roomArbName')}</Label>
                                    </Row>
                                    <Row className="right-align">
                                        <span>{roomActionData.roomNameAr}</span>
                                    </Row>
                                </Col>
                                <Col sm="3">
                                    <Label>{t('BranchAndRoom.maxAllowedTokens')}</Label><br />
                                    <span>{roomActionData.maxAllowedToken}</span>
                                </Col>
                            </Row>
                        </Col>
                    </Row>

                    <hr />

                    {actionRoomGroupArea === IOprationalActions.SELECT &&
                        <i className="ti-arrow-left pointer" style={{fontSize:"18px"}} onClick={selectActionSuspend}></i>
                    }

                    {/* <i className="ti-arrow-left"></i> */}

                </CardBody>
            </Card>}
        </>
    )
}

export default React.memo(SelectedRoomGroup);