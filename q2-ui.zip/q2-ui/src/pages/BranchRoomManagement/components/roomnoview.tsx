import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Label, Card, CardBody, UncontrolledTooltip } from 'reactstrap';
import { SubChiledContext } from '../container/branchcontext';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IRoom, IBranchRoomModel, IRoomNo } from '../../../models/branchRoomModel';
import { setRoomNoActionIdRequest, deleteRoomNoRequest } from '../../../store/actions';

const RoomNoView: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    // const [collapse, setCollapse] = useState(false);

    const context: IRoomNo = useContext<any>(SubChiledContext)?.data;
    const actions = useContext<any>(SubChiledContext)?.actions;

    let roomNoItemData: IRoomNo = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomGroupData) {
            let data = (state.branchAndRoomReducer as IBranchRoomModel).roomNoData as IRoomNo[];
            let index = data?.findIndex(x => x.roomId === context.roomId);
            if (index !== -1)
                return state.branchAndRoomReducer.roomNoData[index] as IRoom;
            else return undefined;
        }
        else return undefined;
    });
    console.log("roomNoItemData =>view ", roomNoItemData, context);

    const editRoomNo = () => {
        dispatch(setRoomNoActionIdRequest(roomNoItemData.roomId, IOprationalActions.EDIT, false))
    }
    const deleteRoomNo = () => {
        let message = t('BranchAndRoom.confirmMessages.BRC4').replace('{roomNo}', roomNoItemData.roomNo);
        console.log("deleteBranch =>", IOprationalActions.DELETE, roomNoItemData.roomId, message, false);
        dispatch(deleteRoomNoRequest(IOprationalActions.DELETE, roomNoItemData.roomId, message, false));
    }

    return (
        <>
            {roomNoItemData && <div className="customCard">
                <Card>
                    <CardBody>

                        <div className="align-right mb-2">
                            {actions.edit &&
                                <>
                                    <i id="edit" className="ti-pencil-alt mr-2 pointer" onClick={editRoomNo} ></i>
                                    <UncontrolledTooltip color="primary" placement="top" target="edit">
                                        {t('ActionNames.edit')}
                                    </UncontrolledTooltip>
                                </>}

                            {actions.delete && <>
                                <i id="delete" className="ti-trash pointer" onClick={deleteRoomNo}></i>
                                <UncontrolledTooltip color="primary" placement="top" target="delete">
                                        {t('ActionNames.delete')}
                                </UncontrolledTooltip>
                            </>}
                        </div>
                        <div>
                            <Label>{t('BranchAndRoom.roomNo')}</Label>
                            <div className="mb-0">{roomNoItemData.roomNo}</div>
                        </div>
                        {/* <div className="text-right mt-2">
                            <button className="btn" onClick={() => setCollapse(!collapse)}>
                                <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                            </button>
                        </div> */}

                        {/* <Collapse isOpen={collapse} className="CardColpsCnt" style={{ position: "absolute" }}>

                            <div className="align-right mb-2">
                                {actions.edit && <i className="ti-pencil-alt mr-2"  onClick={editRoomNo} ></i>}
                                {actions.delete && <i className="ti-trash"></i>}
                            </div>
                            <div>
                                <Label>{t('BranchAndRoom.roomEngName')}</Label>
                                <span>{roomNoItemData.roomNo}</span>
                            </div>

                            <div className="text-right mt-2">
                                <button className="btn" onClick={() => setCollapse(!collapse)}>
                                    <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                                </button>
                            </div>

                        </Collapse> */}

                    </CardBody>
                </Card>
            </div>}
        </>
    )
}

export default React.memo(RoomNoView);