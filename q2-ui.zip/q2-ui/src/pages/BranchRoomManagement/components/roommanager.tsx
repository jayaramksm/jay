import React, { useContext, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row } from 'reactstrap';
import { ParentContext, ChildContext } from '../container/branchcontext';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { IBranchRoomModel, IRoomNo } from '../../../models/branchRoomModel';
import { PaginationComponent } from '../../Utilities/PaginationComponent';
import { setBranchRoomSearchKey } from '../../../store/actions';
import { IOprationalActions } from '../../../models/utilitiesModel';

const RoomManager: React.FC = () => {
    const { t } = useTranslation("translations");
    const context: any = useContext(ParentContext);
    console.log("ParentRoomGroup_context =>", context);
    const dispatch = useDispatch();
    const pageSize = getEnvironment.pageRightSize + (context?.actions?.add ? 0 : 1);

    const roomNosData: IRoomNo[] = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomNoData ? (state.branchAndRoomReducer.roomNoData) : [];
        else return [];
    });

    const searchKey = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomNoSearchKey ? (state.branchAndRoomReducer as IBranchRoomModel).roomNoSearchKey : '';
        else return '';
    });

    let filterRoomNosData: IRoomNo[] = (searchKey && searchKey !== '') ?
        roomNosData.filter(x => x.roomNo.toLowerCase().startsWith(searchKey.toLowerCase())) : roomNosData;

    const roomNosDataCount = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomNoData)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomNoData.length;
        else return 0;
    });
    console.log("roomNosDataCount =>", roomNosDataCount);
    const isSelectAction = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupActionType === IOprationalActions.SELECT;
        else return false;
    });

    let pagesCount = Math.ceil((filterRoomNosData ? filterRoomNosData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }

    const setSearchkey = e => {
        dispatch(setBranchRoomSearchKey(e.target.value, 3));
    }
    return (
        <>
            {isSelectAction && <>
                {roomNosData && roomNosData.length > 0 && <div className="app-search w-50 p-0 form-group mb-0 mt-3">
                    <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} value={searchKey} onChange={setSearchkey} />
                    <i className="fa fa-search"></i>
                </div>}

                <Row className="mt-4 roomcard mx-0">
                    {context.actions.add && <div className="customCard addCustomCard">
                        <context.roomNoAddComponent />
                    </div>}
                    {filterRoomNosData && filterRoomNosData.length > 0 && filterRoomNosData.slice(currentPage * pageSize,
                        (currentPage + 1) * pageSize)
                        .map((x) => {
                            return (
                                <ChildContext.Provider key={x.roomId} value={{ data: x, actions: context.actions }}>
                                    <context.roomNoItem />
                                </ChildContext.Provider>
                            )
                        })
                    }
                    {filterRoomNosData && searchKey === '' && filterRoomNosData.length === 0 && <span>{t('BranchAndRoom.noRoomsFound')}</span>}
                    {filterRoomNosData && searchKey !== '' && filterRoomNosData.length === 0 && <span>{t('BranchAndRoom.noSearchRoomNoFound')}</span>}
                </Row>

                {filterRoomNosData && filterRoomNosData.length > pageSize && <Row className="justify-content-end rgt-pagination">
                    <div className="pagination mr-3 pt-3">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                </Row>}
            </>}
        </>
    )
}
export default React.memo(RoomManager);