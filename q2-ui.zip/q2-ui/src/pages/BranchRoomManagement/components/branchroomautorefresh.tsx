import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../container/branch.css';
import { getBranchDataRequest } from '../../../store/actions';
import { IBranchRoomModel } from '../../../models/branchRoomModel';
import { useTranslation } from 'react-i18next';
import {UncontrolledTooltip} from 'reactstrap';

export const BramchRoomAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const refreshLoading = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).refreshLoading
        else
            return false;
    });

    return (
        <>
            <div className="pageReload"> {!refreshLoading &&  <><i className="ti-reload" id="Btooltip" onClick={() => dispatch(getBranchDataRequest(true, true))}></i>
            <UncontrolledTooltip color="primary" placement="top" target="Btooltip">
                                           {t('ActionNames.autoRefresh')}    
                                          </UncontrolledTooltip></>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}