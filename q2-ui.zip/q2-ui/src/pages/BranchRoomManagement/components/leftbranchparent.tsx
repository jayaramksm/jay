import React, { useContext } from 'react';
import { Card, CardBody } from 'reactstrap';
import { SuperParentContext, ParentContext } from '../container/branchcontext';
import '../container/branch.css';

const LeftBranchParent: React.FC = () => {
    const context: any = useContext(SuperParentContext);

    return (
        <>
            {context.locationView && <context.locationView />}
            <Card className="lft-card flexLayout mb-0">

                <div className="flex-headerfix px-3 pt-3">
                    <ParentContext.Provider value={context.actions}>
                        <context.branchFilter />
                    </ParentContext.Provider>
                </div>

                <CardBody>
                    <div className="flexLayout">
                            <ParentContext.Provider value={{ branchItem: context.branchItem }}>
                                <context.branchManager />
                            </ParentContext.Provider>
                        </div>
                </CardBody>
            </Card>
        </>
    )
}
export default React.memo(LeftBranchParent);