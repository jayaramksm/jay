import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { ChildContext, ParentContext } from '../container/branchcontext';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { PaginationComponent } from '../../Utilities/PaginationComponent';
import { IBranchRoomModel, IBranch } from '../../../models/branchRoomModel';

const BranchManager: React.FC = () => {

    const context = useContext<any>(ParentContext);
    const { t } = useTranslation("translations");
    const pageSize = getEnvironment.listPageSize;

    const branchData: IBranch[] = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData) {
            let data = (state.branchAndRoomReducer as IBranchRoomModel).branchData;
            return data;
        }
        else return [];
    });
    const searchKey = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData) {
            if (state.branchAndRoomReducer.searchKey)
                return state.branchAndRoomReducer.searchKey;
            else
                return ''
        }
        else
            return ''
    });

    const filterBranchData: IBranch[] = (searchKey && searchKey !== '') ?
        branchData.filter(x => x.branchNameEn.toLowerCase().startsWith(searchKey.toLowerCase())) : branchData;

    let branchCount = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData)
            return (state.branchAndRoomReducer as IBranchRoomModel).branchData.length;
        else return 0;
    });
    console.log("BranchManager =>", filterBranchData, branchCount);

    let pagesCount = Math.ceil((filterBranchData ? filterBranchData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }


    return (
        <>
            {filterBranchData && filterBranchData.length === 0 && searchKey !== '' && <span className="recdnotfound">{t('BranchAndRoom.noResFound')}</span>}
            {filterBranchData && filterBranchData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('BranchAndRoom.nobranchsfound')}</span>}

            <div className="flexLayout-inner layou1rgtColmn">
                <Row>
                    <Col sm="12" className="actn-list">
                        {filterBranchData && filterBranchData.length > 0 && filterBranchData.slice(currentPage * pageSize,
                            (currentPage + 1) * pageSize).map((item, index) => (
                                <ChildContext.Provider key={index} value={item.branchId}>
                                    <context.branchItem />
                                </ChildContext.Provider>
                            ))}
                    </Col>
                </Row>
            </div>
            <Row className="lft-pagination">
                {filterBranchData && filterBranchData.length > pageSize &&
                    <div className="pagination ml-4">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                }
            </Row>

        </>
    )
}
export default React.memo(BranchManager);