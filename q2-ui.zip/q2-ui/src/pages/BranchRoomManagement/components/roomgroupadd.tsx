import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Card, CardBody } from 'reactstrap';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import addIcon from '../../../images/icons/addicon.svg';
import { ParentContext, ChildContext } from '../container/branchcontext';
import { setRoomGroupActionIdRequest } from '../../../store/actions';
import { IBranchRoomModel } from '../../../models/branchRoomModel';

const RoomGroupAddComponent: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);
    const roomGroupActionType = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomGroupActionType ? state.branchAndRoomReducer.roomGroupActionType : 0;
        else return 0;
    });
    console.log("roomGroupActionType =>Add", roomGroupActionType);

    return (
        <>
            {!(roomGroupActionType === IOprationalActions.ADD) && <Card onClick={() => dispatch(setRoomGroupActionIdRequest(0, IOprationalActions.ADD, false))}>
                <CardBody>
                    <span>{t('BranchAndRoom.addRoomGroup')} <img src={addIcon} alt="" /></span>
                </CardBody>
            </Card>}

            {(roomGroupActionType === IOprationalActions.ADD) && <ChildContext.Provider value={{ data: { roomMasterId: 0 }, action: context.actions }}>
                <context.roomGroupAction />
            </ChildContext.Provider>}
        </>
    )
}
export default React.memo(RoomGroupAddComponent);