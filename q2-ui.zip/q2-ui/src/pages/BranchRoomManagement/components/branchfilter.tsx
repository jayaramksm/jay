import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, UncontrolledTooltip } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import { ParentContext } from '../container/branchcontext';
import { IBranchRoomModel } from '../../../models/branchRoomModel';
import { setBranchActionRequestData, setBranchRoomSearchKey } from '../../../store/actions';
import uploadlogo from '../../../images/upload.svg';
import '../container/branch.css'

const BranchFilter: React.FC = () => {

    const context: any = useContext(ParentContext);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const isAddAction = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).actionType === IOprationalActions.ADD;
        else return false;
    });
    const isBulkUpload = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).actionType === IOprationalActions.BULKUPLOAD;
        else return false;
    });
    const filterActions = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData)
            return (state.branchAndRoomReducer as IBranchRoomModel).branchData.length > 0;
        else return false;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });

    const addBranch = () => {
        if (!isAddAction)
            dispatch(setBranchActionRequestData(IOprationalActions.ADD, null, false));
    }
    const setSearch = (key) => {
        if (!isBulkUpload)
            dispatch(setBranchRoomSearchKey(key, 1));
    }

    const addBulkUpload = () => {
        dispatch(setBranchActionRequestData(IOprationalActions.BULKUPLOAD, null, false));
    }

    return (
        <>
            <Row className="roleslist">
                <Col className="pr-0"><h6 className="m-0">
                    {t('BranchAndRoom.listOfBranches')}</h6>
                </Col>
                {selectedLocationStatus && <Col className="align-right pl-2 pr-3 addupload">
                    {context.add && <button id="add" className="btn btn-out-dashed" disabled={isAddAction} onClick={addBranch} >{t('ActionNames.add')}&nbsp;&nbsp;<span className="addbtn">+</span></button>}
                    {!isAddAction && context.add &&
                        <UncontrolledTooltip color="primary" placement="right" target="add">
                            {t('BranchAndRoom.addBranch')}
                        </UncontrolledTooltip>
                    }
                    {context.bulkUpload &&
                        <div><button className="btn blkupload pl-2 p-0" id="upload" disabled={isBulkUpload} onClick={addBulkUpload}>
                            <img alt="" src={uploadlogo} /></button>
                            <UncontrolledTooltip color="primary" placement="top" target="upload">
                                {t('ActionNames.bulkupload')}
                            </UncontrolledTooltip>
                        </div>
                    }
                </Col>}
            </Row>

            {filterActions && <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={e => setSearch(e.target.value)} />
                <i className="fa fa-search"></i>
            </div>}
        </>
    )
}
export default React.memo(BranchFilter);