import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { ParentContext, ChildContext, SubChiledContext } from '../container/branchcontext';
import '../container/branch.css';
import { IBranchRoomModel } from '../../../models/branchRoomModel';

const RoomNoItem: React.FC = () => {

    const parentContext = useContext<any>(ParentContext);
    const context: any = useContext(ChildContext);
    const actions = useContext<any>(ChildContext)?.actions;
    console.log("RoomNoItem =>", context, actions);

    const isActionComponent = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomNoActionId)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomNoActionId === context.data.roomId;
        else return false;
    });

    return (
        <>
            <SubChiledContext.Provider value={{ data: context.data, actions: actions }}>
                {isActionComponent ? <parentContext.roomNoAction /> : <parentContext.roomNoView />}
            </SubChiledContext.Provider>
        </>
    )
}
export default React.memo(RoomNoItem);