import React, { useContext, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Collapse, Label, Card, CardBody } from 'reactstrap';
import { ChildContext } from '../container/branchcontext';
import '../container/branch.css';
import { useTranslation } from 'react-i18next';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { controleContentValidate, customContentValidation } from '../../../helpers/helpersIndex';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { IBranchRoomModel, IRoom, IRoomNo } from '../../../models/branchRoomModel';
import { setRoomNoActionIdRequest, createOrEditRoomNoRequest } from '../../../store/actions';
import * as _ from 'lodash';
import info from '../../../images/info.svg';

const RoomNoAction: React.FC = () => {

    const { t } = useTranslation("translations");
    const [helper, setHelper] = useState(false)
    const dispatch = useDispatch();
    const context: IRoomNo = useContext<any>(ChildContext)?.data;

    let roomNoItemData: IRoomNo = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.roomNoData) {
            let data = (state.branchAndRoomReducer as IBranchRoomModel).roomNoData as IRoomNo[];
            let index = data?.findIndex(x => x.roomId === context.roomId);
            console.log("uyuygyy =>", data, context, index);
            if (index !== -1)
                return state.branchAndRoomReducer.roomNoData[index] as IRoom;
            else return undefined;
        }
        else return undefined;
    });
    const actionType = useSelector(state => {
        if (state && state.branchAndRoomReducer)
            return (state.branchAndRoomReducer as IBranchRoomModel).roomNoActionType ? (state.branchAndRoomReducer as IBranchRoomModel).roomNoActionType : 0;
        else return 0;
    });
    console.log("RoomNoAction =>", roomNoItemData, actionType);

    const onChangingRoomNo = (roomNovalue, preFixValue, setFieldValue) => {
        if (roomNovalue.includes(","))
            setFieldValue('prefix', '')
        else if (roomNovalue.includes("-")) {
            let roomrange = roomNovalue.split("-");
            if (roomrange?.length > 1)
                if ((roomrange[1] + '').length + preFixValue.length > 3)
                    setFieldValue('prefix', '')

        }
        setFieldValue('roomNo', roomNovalue)
    }
    const onChangingPrefix = (value, setFieldValue, roomNovalue) => {
        if (roomNovalue.includes(","))
            return;
        else if (roomNovalue.includes("-")) {
            let roomrange = roomNovalue.split("-");
            if (roomrange?.length > 1)
                if ((roomrange[1] + '').length + value.length > 3)
                    return;

        }
        setFieldValue('prefix', value)
    }
    const cancelAction = () => {
        dispatch(setRoomNoActionIdRequest(-1, 0, true));
    }

    return (
        <>
            <div className={actionType !== IOprationalActions.ADD ? 'customCard' : ''}>
                <Card>
                    <CardBody>
                        <Collapse isOpen={true} className="CardColpsCnt" style={{ position: "absolute" }}>
                            <div style={{ marginBottom: "-50px" }}>

                                <div className="text-right mb-2" >
                                {actionType === IOprationalActions.ADD && <img src={info} alt="" className="pointer" style={{ width: "21px" }} onClick={() => setHelper(!helper)} />}
                                    &nbsp;<i className="ti-close pointer" onClick={cancelAction}></i>
                                </div>
                                <Formik
                                    enableReinitialize
                                    initialValues={{
                                        roomId: roomNoItemData ? roomNoItemData.roomId : 0,
                                        prefix: '',
                                        roomNo: '',
                                        selectedRoomNo: roomNoItemData ? roomNoItemData.roomNo : ''
                                    }}
                                    validationSchema={Yup.object().shape({
                                        prefix: Yup.lazy(val => {
                                            if (val !== undefined)
                                                return customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaCapitals', message: 'alphaCapitals' }, 2, 1)
                                            return Yup.string().notRequired()
                                        }),
                                        roomNo: actionType === IOprationalActions.ADD ?controleContentValidate(t('controleErrors.required'), '', { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, { patternType: 'roomNo', message: t('controleErrors.roomNoPattern') }):'',
                                        selectedRoomNo: actionType === IOprationalActions.EDIT? customContentValidation(t, t('controleErrors.required'), { patternType: 'capitalsAndNumbers', message: 'capitalsAndNumbers' }, 3, 1):''


                                    })}
                                    onSubmit={values => {
                                        let rooms: string[] = [];
                                        if (values.roomNo.includes("-")) {
                                            let roomrange = values.roomNo.split("-");
                                            if (roomrange.length > 1) {
                                                if (+roomrange[0] <= +roomrange[1]) {
                                                    _.range(+roomrange[0], +roomrange[1] + 1).forEach(x => {
                                                        rooms.push(values?.prefix + '' + x);
                                                    });
                                                }
                                            }
                                        }
                                        else if (values.roomNo.includes(",")) {
                                            rooms = values.roomNo.split(",")
                                        }
                                        else {
                                            rooms.push(values.roomNo);
                                        }
                                        console.log("onSubmit_Values =>", values);
                                        console.log("onSubmit_Rooms =>", rooms);
                                        let editData = {
                                            roomId: values.roomId,
                                            roomNo: values.selectedRoomNo
                                        }
                                        dispatch(createOrEditRoomNoRequest(actionType, rooms, editData));
                                    }}
                                >
                                    {({ errors, touched, dirty, values, setFieldValue }) => (
                                        <Form>
                                            {actionType === IOprationalActions.ADD &&
                                                <>
                                                <div className="form-group">
                                                    <Label>{t('BranchAndRoom.prefix')}</Label>
                                                    <Field placeholder={t('BranchAndRoom.prefix')} name="prefix" type="text" onChange={(e) => onChangingPrefix(e.target.value, setFieldValue, values.roomNo)} className={'form-control ' + (errors.prefix && touched.prefix ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="prefix" component='div' className="invalid-feedback" />
                                                </div>
                                                    <div className="form-group">
                                                        <Label>{t('BranchAndRoom.roomNo')}</Label>
                                                        <Field placeholder={t('BranchAndRoom.roomNoPlcae')} name="roomNo" type="text" onChange={(e) => onChangingRoomNo(e.target.value, values.prefix, setFieldValue)} className={'form-control ' + (errors.roomNo && touched.roomNo ? 'is-invalid' : '')} />
                                                        <Label style={{ fontSize: "12px" }}>{t('BranchAndRoom.roomNoHint')}</Label>
                                                        <ErrorMessage name="roomNo" component='div' className="invalid-feedback" />
                                                    </div>
                                                
                                                  {helper &&  <div className="infotext">
                                                        {t('BranchAndRoom.roomNoHelpText')}
                                                    </div>
                                                }
                                                </>}
                                            {actionType === IOprationalActions.EDIT && <div className="form-group">
                                                <Label>{t('BranchAndRoom.roomNo')}</Label>
                                                <Field placeholder={t('BranchAndRoom.roomNoPlcae')} name="selectedRoomNo" type="text" className={'form-control ' + (errors.selectedRoomNo && touched.selectedRoomNo ? 'is-invalid' : '')} />
                                                <Label style={{ fontSize: "12px" }}>{t('BranchAndRoom.roomNoHint')}</Label>
                                                <ErrorMessage name="selectedRoomNo" component='div' className="invalid-feedback" />
                                            </div>}
                                          
                                            <button type="submit" disabled={!(dirty)} className="btn btn-primary mb-5">
                                                {actionType === IOprationalActions.ADD ? t('ActionNames.save') : t('ActionNames.update')}
                                            </button>
                                        </Form>
                                    )}
                                </Formik>
                            </div>
                        </Collapse>
                    </CardBody>
                </Card>
            </div>
        </>
    )
}
export default React.memo(RoomNoAction);