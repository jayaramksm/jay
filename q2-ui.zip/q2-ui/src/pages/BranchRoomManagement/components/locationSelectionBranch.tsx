
import React from 'react'
import '../container/branch.css';
import { LocationSelectArea } from '../../Utilities/LocationSelectArea';
import { changeLocationForBranch } from '../../../store/actions';

export const LocationSelectionBranch: React.FC = () => {
    return <LocationSelectArea locationCallBack={changeLocationForBranch} />
}
