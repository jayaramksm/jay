import * as React from 'react';
import { activateAuthLayout } from '../../../store/actions';
import { connect } from 'react-redux';
import { Col, Row, Container } from 'reactstrap';
import { getBranchDataRequest, setResetForBranchRoom, cancelAllPendingBranchRequests } from '../../../store/actions';
import { SuperParentContext } from './branchcontext';
import {
    LeftBranchParent, LocationSelectionBranch, BranchFilter, BranchManager, BranchItem,
    RightBranchRoomParent, BranchAction, BranchView,
    SelectedRoomGroup, RoomGroupManager, RoomGroupItem, RoomGroupAddComponent, RoomGroupAction, RoomGroupView,
    RoomManager, RoomNoItem, RoomNoAddComponent, RoomNoAction, RoomNoView, BramchRoomAutoRefresh, BranchBulkuploadComponent
} from './branchindex';
import { IRoleDesc, IActions } from '../../../models/utilitiesModel';
import { IBranchRoomModel } from '../../../models/branchRoomModel';
import './branch.css';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../helpers/helpersIndex';

export interface IProps {
    activateAuthLayout: any;
    getBranchDataRequest: any;
    setResetForBranchRoom: any;
    cancelAllPendingBranchRequests: any;
    branchLoad: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    bulkUpload: boolean;
}

class Branch extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props)
        this.state = {
            leftBranchParent: {
                locationView: props.loginUserRolecode === IRoleDesc.ENTERPRISEADMIN ? LocationSelectionBranch : null,
                branchFilter: BranchFilter,
                branchManager: BranchManager,
                branchItem: BranchItem,
                actions: { add: this.props.add, bulkUpload: this.props.bulkUpload }
            },
            rightBranchRoomParent: {
                branchView: BranchView,
                branchAction: BranchAction,
                branchBulkUpload: BranchBulkuploadComponent,
                parentRoomGroup: { roomGroupManager: RoomGroupManager, selectedRoomGroup: SelectedRoomGroup },
                pGroupManager: {
                    roomGroupAddComponent: RoomGroupAddComponent,
                    roomGroupView: RoomGroupView,
                    roomGroupAction: RoomGroupAction,
                    roomGroupItem: RoomGroupItem,
                    actions: {
                        add: this.props.add,
                        edit: this.props.edit,
                        delete: this.props.delete
                    }
                },
                roomManager: RoomManager,
                pRoomManager: {
                    roomNoAddComponent: RoomNoAddComponent,
                    roomNoView: RoomNoView,
                    roomNoAction: RoomNoAction,
                    roomNoItem: RoomNoItem,
                    actions: {
                        add: this.props.add,
                        edit: this.props.edit,
                        delete: this.props.delete
                    }
                },
                actions: { edit: this.props.edit, delete: this.props.delete }
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForBranchRoom();
        if (this.props.branchLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getBranchDataRequest(!this.props.branchLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getBranchDataRequest(!this.props.branchLoad, true);
    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.cancelAllPendingBranchRequests();
        this.props.setResetForBranchRoom();
    }



    render() {

        return (
            <>
                {getAutoRefresing() && <BramchRoomAutoRefresh />}
                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftBranchParent}>
                                <LeftBranchParent />
                            </SuperParentContext.Provider>
                        </Col>
                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightBranchRoomParent}>
                                <RightBranchRoomParent />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>
            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete', 'bulk_insert'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'branch', defaultPrivilages);

    if (getAutoRefresing() && state.branchAndRoomReducer && (state.branchAndRoomReducer as IBranchRoomModel).branchData)
        return {
            branchLoad: ((state.branchAndRoomReducer as IBranchRoomModel).branchData?.length > 0 ? true : false),
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
    else
        return {
            branchLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
}
export default connect(mapStatetoProps, { activateAuthLayout, getBranchDataRequest, setResetForBranchRoom, cancelAllPendingBranchRequests })(Branch);
