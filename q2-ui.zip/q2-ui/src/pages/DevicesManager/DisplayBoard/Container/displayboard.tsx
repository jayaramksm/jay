import React from 'react';
import { connect } from 'react-redux';
import {
    DisplayBoardAction,
    DisplayBoardFilter,
    DisplayBoardManager,
    DisplayBoardView,
    LeftParent,
    RightParent,
    LocationSelectionArea,
    DisplayBoardAutoRefresh
} from './displayboardindex';
import { SuperParentContext } from './displayboardcontext';
import { activateAuthLayout } from '../../../../store/actions';
import '../../Container/devices.css';
import { IRoleDesc, IActions } from '../../../../models/utilitiesModel';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../../helpers/helpersIndex';
import { Container, Row, Col } from 'reactstrap';
import { getBranchesThemesDataRequest, setResetForDisplayBoard, cancelAllPendingDisplayRequests } from '../../../../store/actions';

interface IProps {
    activateAuthLayout: any;
    getBranchesThemesDataRequest: any;
    setResetForDisplayBoard: any;
    displayBoardBranchesLoad: any;
    cancelAllPendingDisplayRequests: any;
    add: boolean;
    edit: boolean;
    delete: boolean;
}
class DisplayBoard extends React.PureComponent<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);

        this.state = {
            leftParent: {
                locationSelectionComponent: props.loginUserRolecode === IRoleDesc.ENTERPRISEADMIN ? LocationSelectionArea : null,
                displayBoardManagerComponent: DisplayBoardManager,
                filterComponent: DisplayBoardFilter,
                actions: { add: this.props.add }
            },
            rightParent: {
                actionComponent: DisplayBoardAction,
                viewComponent: DisplayBoardView,
                actions: { edit: this.props.edit, delete: this.props.delete }
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForDisplayBoard();

        if (this.props.displayBoardBranchesLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getBranchesThemesDataRequest(!this.props.displayBoardBranchesLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getBranchesThemesDataRequest(!this.props.displayBoardBranchesLoad, true);
    }

    componentWillUnmount() {
        if (this.setinterval) {
            clearTimeout(this.setinterval);
        }
        this.props.setResetForDisplayBoard();
        this.props.cancelAllPendingDisplayRequests();
    }

    render() {
        return (
            <>
                {getAutoRefresing() && <DisplayBoardAutoRefresh />}
                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftParent}>
                                <LeftParent />
                            </SuperParentContext.Provider>
                        </Col>

                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightParent}>
                                <RightParent />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>
            </>
        )
    }
}
const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'displayboard', defaultPrivilages);
    if (getAutoRefresing() && state.displayBoardReducer && state.displayBoardReducer.displayBoardsData)
        return {
            displayBoardBranchesLoad: state.displayBoardReducer.displayBoardsData.length > 0 ? true : false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
    else
        return {
            displayBoardBranchesLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
}
export default connect(mapStatetoProps, { activateAuthLayout, getBranchesThemesDataRequest, setResetForDisplayBoard, cancelAllPendingDisplayRequests })(DisplayBoard);