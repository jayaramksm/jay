import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../../Container/devices.css';
import { useTranslation } from 'react-i18next';
import { Card, CardBody, Row, Col, Label, FormGroup } from 'reactstrap';
import DualListBox from 'react-dual-listbox';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { IDisplayBoard, IDBTheme, ISeriviceBranchData } from '../../../../models/displayBoardModel';
import { controleContentValidate, customContentValidation, MySelect, Option, MultiValue, ValueContainer } from '../../../../helpers/helpersIndex';
import { IBranch } from '../../../../models/branchRoomModel';
import { createOrUpdateDisplayBoardRequest, suspendDBaction } from '../../../../store/actions';
import { IService } from '../../../../models/servicesModel';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import * as _ from 'lodash';
export interface optionsData {
    value: any;
    label: any;
}

const DisplayBoardAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const displayTypesData: optionsData[] = [
        { value: "W", label: t('Display.waiting') },
        { value: "S", label: t('Display.serving') }]
    const DBactionData: IDisplayBoard = useSelector(state => state?.displayBoardReducer?.actionData);
    const themesData: IDBTheme[] = useSelector(state => state?.displayBoardReducer?.themesData);
    const branchesTData: IBranch[] = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData)
            return state.branchAndRoomReducer.branchData;
        else return [];
    });
    let serviceBranchListData: ISeriviceBranchData[] = useSelector(state => {
        if (state && state.displayBoardReducer && state.displayBoardReducer.servicebrnchhData)
            return state.displayBoardReducer.servicebrnchhData;
        else
            return [];
    });
    const brancheData = branchesTData ? branchesTData?.filter(x => serviceBranchListData.findIndex(y => y.branchId === x.branchId) !== -1) : [];
    const branchesMapData = _.orderBy(brancheData, ['branchNameEn'], ['asc']).map(x => ({ value: x.branchId, label: x.branchNameEn }));
    let dbServicesData: IService[] = useSelector(state => {
        let serviceData = [];
        if (state && state.displayBoardReducer && state.displayBoardReducer.dbServicesData)
            serviceData = state.displayBoardReducer.dbServicesData;
        return serviceData;
    });
    console.log("DisplayBoardAction =>", brancheData, branchesTData, serviceBranchListData, dbServicesData);
    const patchTheme = (themeId) => {
        let index = themesData.findIndex(x => x.themeId === themeId);
        return index !== -1 ? { value: themesData[index].themeId, label: themesData[index].themeName } : '';
    };

    const patchBranches = (branches) => {
        let patchBranchData: any = [];
        branches.forEach(x => {
            let index = branchesTData?.findIndex(y => y.branchId === x);
            if (index !== -1) {
                patchBranchData.push({ value: branchesTData[index]?.branchId, label: branchesTData[index]?.branchNameEn })
            }
        });
        if (branchesTData.length > 2 && branches?.length === brancheData?.length) {
            patchBranchData.push({ value: 0, label: 'Select All' });
        }
        return patchBranchData;
    };
    const patchdisplayType = (displayType) => {
        let index = displayTypesData.findIndex(x => x.value === displayType);
        return index !== -1 ? { value: displayTypesData[index].value, label: displayTypesData[index].label } : '';

    }
    const getInitialValues = () => ({
        displayId: DBactionData ? DBactionData.displayId : 0,
        displayIdentifier: DBactionData ? DBactionData.displayIdentifier : 'di',
        status: DBactionData ? DBactionData.status : 1,
        displayName: DBactionData ? DBactionData.displayName : '',
        themeId: DBactionData ? patchTheme(DBactionData.themeId) : themesData.length === 1 ? { value: themesData[0].themeId, label: themesData[0].themeName } : '',
        branches: DBactionData ? patchBranches(DBactionData.branches) : branchesMapData.length === 1 ? [{ value: branchesMapData[0].value, label: branchesMapData[0].label }] : '',
        services: DBactionData ? DBactionData.services : branchesMapData.length === 1 ? patchSingleService() : '',
        servicesList: DBactionData ? patchServiceList() : branchesMapData.length === 1 ? patchSingleServicesList() : '',
        displayType: DBactionData ? patchdisplayType(DBactionData?.displayType) : ''
    });

    const validationSchema = Yup.object().shape({
        displayName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspacesp', spacialChar: '_-' }, 50, 2),
        themeId: controleContentValidate(t('controleErrors.required')).nullable(),
        branches: controleContentValidate(t('controleErrors.required')).nullable(),
        services: controleContentValidate(t('controleErrors.required')).nullable(),
        displayType: controleContentValidate(t('controleErrors.required')).nullable()
    });

    const onThemeSelection = (e, setFieldValue) => {
        setFieldValue('themeId', e);
    }
    const onDisplayTypeSelection = (e, setFieldValue) => {
        setFieldValue('displayType', e)
    }

    const branchesSelection = (e, setFieldValue, servicesValue) => {
        console.log("branchesSelection", e);

        e = e ? e : [];
        setFieldValue('branches', e);

        let selectedBranches = e?.filter(a => a.value !== 0).map(x => x.value);
        let filterServicesData = dbServicesData.filter(z => selectedBranches.includes(z.branchId));

        if (servicesValue) {
            servicesValue = (servicesValue as any[]).filter(x => filterServicesData.findIndex(y => y.serviceId === x) !== -1);
            setFieldValue('services', servicesValue);
        }
        setFieldValue('servicesList', serviceBranchListData.filter(x => selectedBranches.includes(x.branchId)));
        console.log("branchservicedata", selectedBranches, serviceBranchListData, serviceBranchListData.filter(x => selectedBranches.includes(x.branchId)));
    }

    const patchSingleService = () => {
        let servicesValue;
        let filteredBrancchData = [{ value: branchesMapData[0].value, label: branchesMapData[0].label }]
        let selectedBranches = filteredBrancchData?.filter(a => a.value !== 0).map(x => x.value);
        let filterServicesData = dbServicesData.filter(z => selectedBranches.includes(z.branchId));

        if (DBactionData && DBactionData.services) {
            servicesValue = (DBactionData.services as any[]).filter(x => filterServicesData.findIndex(y => y.serviceId === x) !== -1);
        }
        return servicesValue;

    }
    const patchSingleServicesList = () => {
        let ServicesList;
        let filteredBrancchData = [{ value: branchesMapData[0].value, label: branchesMapData[0].label }]
        let selectedBranches = filteredBrancchData?.filter(a => a.value !== 0).map(x => x.value);
        ServicesList = serviceBranchListData.filter(x => selectedBranches.includes(x.branchId));
        return ServicesList;
    }
    const cancelAction = () => dispatch(suspendDBaction(IOprationalActions.SELECT));

    const patchServiceList = () => {
        let selectedBranches = (DBactionData?.branches) as number[];
        return serviceBranchListData.filter(x => selectedBranches.includes(x.branchId));
    }

    return (
        <>
            <Formik
                enableReinitialize
                initialValues={getInitialValues()}
                validationSchema={validationSchema}
                onSubmit={(values) => {
                    let data;
                    let theme: any = values.themeId;
                    let displayType: optionsData = (values.displayType as any);
                    if (values.displayId > 0 && DBactionData) {
                        data = {
                            branches: values.branches.map(x => x.value),
                            displayId: values.displayId,
                            displayIdentifier: values.displayIdentifier,
                            displayName: values.displayName,
                            services: values.services ? values.services : [],
                            status: values.status,
                            themeId: theme.value,
                            displayType: displayType.value
                        }

                    }
                    else if (values.displayId === 0) {
                        data = {
                            displayId: values.displayId,
                            displayIdentifier: values.displayIdentifier,
                            displayName: values.displayName,
                            branches: values.branches.map(x => x.value),
                            services: values.services ? values.services : [],
                            themeId: theme.value,
                            displayType: displayType.value

                        }
                    }
                    console.log("onSubmitData===>", data);

                    dispatch(createOrUpdateDisplayBoardRequest(data));
                }}
            >
                {({ errors, touched, values, dirty, setFieldTouched, setFieldValue }) => (
                    <Form>
                        <Card>
                            <CardBody>
                                <Row>
                                    <Col sm="4" className="FormStyle">
                                        <div className="form-group">
                                            <Field name="displayName" placeholder={t('Display.enterDBname')} className={'form-control ' + (errors.displayName && touched.displayName ? 'is-invalid' : '')} />
                                            <ErrorMessage name="displayName" component='div' className="invalid-feedback" />
                                            <Label>{t('Display.displayDBname')}</Label>
                                        </div>
                                    </Col>
                                    <Col>
                                        <div className="form-group">
                                            <Label>{t('Display.selectTheme')}</Label>
                                            <MySelect
                                                placeholder={t('Display.selectTheme')}
                                                name="themeId"
                                                value={values.themeId}
                                                onChange={(e) => onThemeSelection(e, setFieldValue)}
                                                options={themesData ? (themesData.map(x => ({ value: x.themeId, label: x.themeName }))) : []}
                                                getOptionLabel={option => option.label}
                                                getOptionValue={option => option.value}
                                                onBlur={() => setFieldTouched('themeId', true)}
                                                noOptionsMessage={() => t('Display.noThemes')}
                                            />
                                            {errors.themeId && touched.themeId && (
                                                <div className="error-msg">{errors.themeId}</div>
                                            )}
                                        </div>
                                    </Col>
                                    <Col>
                                        <FormGroup>
                                            <FormGroup>
                                                <Label>{t('Display.selectBranch')}</Label>
                                                <MySelect
                                                    name="branches"
                                                    allOption={{
                                                        label: "Select All",
                                                        value: 0
                                                    }}
                                                    isMulti
                                                    placeholder={t('Display.selectBranch')}
                                                    options={branchesMapData ? branchesMapData : []}
                                                    value={values.branches ? values.branches : ''}
                                                    onChange={(e) => branchesSelection(e, setFieldValue, values.services)}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    components={{ Option, MultiValue, ValueContainer }}
                                                    hideSelectedOptions={false}
                                                    removeSelected={false}
                                                    closeMenuOnSelect={false}
                                                    backspaceRemovesValue={false}
                                                    allowSelectAll={branchesTData && branchesTData.length > 2 ? true : false}
                                                    onBlur={() => setFieldTouched('branches', true)}
                                                    noOptionsMessage={() => t('Display.noBranches')}
                                                />

                                                {errors.branches && touched.branches && (
                                                    <div className="error-msg">{errors.branches}</div>
                                                )}
                                            </FormGroup>
                                        </FormGroup>
                                    </Col>

                                    {/* <Col sm="1" className="align-center" style={{ direction: 'rtl' }}>
                            <Switch uncheckedIcon={<Offsymbol />}
                                checkedIcon={<OnSymbol />} onColor="#02a499"
                                onChange={() => { this.setState({ switch1: !this.state.switch1 }); }} checked={this.state.switch1} />
                        </Col> */}
                                </Row>
                                <Row>
                                    <Col sm="4">
                                        <div className="form-group">
                                            <Label>{t('Display.displayType')}</Label>
                                            <MySelect
                                                placeholder={t('Display.displayType')}
                                                name="displayType"
                                                value={values.displayType}
                                                onChange={(e) => onDisplayTypeSelection(e, setFieldValue)}
                                                options={themesData ? (displayTypesData.map(x => ({ value: x.value, label: x.label }))) : []}
                                                getOptionLabel={option => option.label}
                                                getOptionValue={option => option.value}
                                                onBlur={() => setFieldTouched('displayType', true)}
                                                noOptionsMessage={() => t('Display.noDisplayTypes')}
                                            />
                                            {errors.displayType && touched.displayType && (
                                                <div className="error-msg">{errors.displayType}</div>
                                            )}
                                        </div>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>

                        {values.servicesList && values.servicesList.length > 0 && <><Row className="mb-3 text-center">
                            <Col>
                                <div className="apptype">{t('Display.services')}</div>
                            </Col>
                            <Col className="align-right">
                                <div className="apptype">{t('Display.assignedServices')}</div>
                            </Col>
                        </Row>
                            <DualListBox
                                name="services"
                                canFilter
                                options={values.servicesList ? values.servicesList : []}
                                onChange={(e) => {
                                    setFieldValue('services', e)

                                }}
                                selected={values.services ? values.services : []}
                                onBlur={e => setFieldTouched('services', true)}
                                showNoOptionsText
                            />
                            {errors.services && touched.services && (
                                <div style={{ color: "red", marginTop: ".5rem" }}>{errors.services}</div>
                            )}
                        </>}
                        <div className="mt-4 mb-2 align-right">
                            <button className="btn btn-primary" type="submit" disabled={!(dirty)}>
                                {DBactionData ? t('ActionNames.update') : t('ActionNames.save')}
                            </button>

                            <button className="btn btn-cancel ml-3" onClick={cancelAction}>
                                {t('ActionNames.cancel')}
                            </button>
                        </div>
                    </Form>
                )}
            </Formik>
        </>
    )
}
export default React.memo(DisplayBoardAction);