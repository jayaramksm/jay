import React, { useContext } from 'react';
import { useSelector, useDispatch, batch } from 'react-redux';
import '../../Container/devices.css';
import { useTranslation } from 'react-i18next';
import { Row, Col, UncontrolledTooltip } from 'reactstrap';
import { IBranch } from '../../../../models/branchRoomModel';
import { setDBsearchKey, setDisplayBoardActionRequest } from '../../../../store/actions';
import { SuperParentContext } from '../Container/displayboardcontext';
import { IOprationalActions, ISessionstate } from '../../../../models/utilitiesModel';
import * as _ from 'lodash';
import { MySelect } from '../../../../helpers/helpersIndex';

const DisplayBoardFilter: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const actions = useContext(SuperParentContext)?.actions;

    const displayDataExists = useSelector(state => {
        if (state && state.displayBoardReducer && state.displayBoardReducer.displayBoardsData)
            return state.displayBoardReducer.displayBoardsData.length > 0;
        else return false;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const isAddActionType = useSelector(state => {
        if (state && state.displayBoardReducer && state.displayBoardReducer.actionType)
            return state.displayBoardReducer.actionType === IOprationalActions.ADD;
        else return false;
    });

    const branchesData: IBranch[] = useSelector(state => state?.branchAndRoomReducer?.branchData);
    let branchesMapData = _.orderBy(branchesData, ['branchNameEn'], ['asc']).map(x => ({ value: x.branchId, label: x.branchNameEn }));
    branchesMapData = [{ value: 0, label: '--Select Department--' }, ...(branchesMapData ? branchesMapData : [])]

    const onBranchSelection = (e) => {
        dispatch(setDBsearchKey(e.value, 2));
    }

    const setSearchKey = (e) => dispatch(setDBsearchKey(e.target.value, 1));

    const addDisplayBoard = () => {
        batch(() => {
            dispatch(setDisplayBoardActionRequest(IOprationalActions.ADD, null, branchesData));
            // dispatch(getServicesDataRequest(branchesData?.map(x => x.branchId)));
        });
    }

    return (
        <>
            <Row className="roleslist">
                <Col className="pr-0"><h6 className="m-0">{t('Display.listOfDb')}</h6></Col>

                {actions.add && selectedLocationStatus && <div className="align-right pl-2 pr-3 addupload">
                    <button className="btn btn-out-dashed" id="add" disabled={isAddActionType} onClick={addDisplayBoard}>{t('ActionNames.add')} &nbsp;<span className="addbtn">+</span></button>
                    {!isAddActionType && <UncontrolledTooltip color="primary" placement="right" target="add">
                        {t('Display.addDb')}
                    </UncontrolledTooltip>}
                </div>}
            </Row>

            {displayDataExists && <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={setSearchKey} />
                <i className="fa fa-search"></i>
            </div>}

            {displayDataExists && branchesMapData?.length > 2 && <Row>
                <Col sm="12" className=" mt-1">
                    <MySelect
                        placeholder={t('Display.selectBranch')}
                        onChange={(e) => onBranchSelection(e)}
                        options={branchesMapData ? branchesMapData : []}
                        getOptionLabel={option => option.label}
                        getOptionValue={option => option.value}
                        noOptionsMessage={() => t('Display.noBranches')}
                    />
                </Col>

                {/* <Col sm="2" className="pl-2 filtericon">
                    <UncontrolledDropdown>
                        <DropdownToggle id="Filter">
                            <img src={filter} alt="" />
                        </DropdownToggle>
                        <DropdownMenu>
                            <DropdownItem>All</DropdownItem>
                            <DropdownItem>Active</DropdownItem>
                            <DropdownItem>InActive</DropdownItem>
                        </DropdownMenu>
                    </UncontrolledDropdown>
                    <UncontrolledTooltip color="primary" placement="top" target="Filter">
                        Filter
                    </UncontrolledTooltip>
                </Col> */}
            </Row>}
        </>
    )
}
export default React.memo(DisplayBoardFilter);