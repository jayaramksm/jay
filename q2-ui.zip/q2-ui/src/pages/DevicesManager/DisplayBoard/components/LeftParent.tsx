import React, { useContext } from 'react';
import '../../Container/devices.css';
import { SuperParentContext } from '../Container/displayboardcontext';

const LeftParent: React.FC = () => {
    const context = useContext(SuperParentContext);

    return (
        <>
            {context.locationSelectionComponent && <context.locationSelectionComponent />}
            <context.displayBoardManagerComponent />
        </>
    )
}
export default React.memo(LeftParent);