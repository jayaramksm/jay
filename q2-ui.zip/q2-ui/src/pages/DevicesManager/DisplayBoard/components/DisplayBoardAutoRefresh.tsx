import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getBranchesThemesDataRequest } from '../../../../store/actions';
import { IDisplayModel } from '../../../../models/displayBoardModel';
import { UncontrolledTooltip } from 'reactstrap';
import { useTranslation } from 'react-i18next';

export const DisplayBoardAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const refreshLoading = useSelector(state => {
        if (state && state.displayBoardReducer)
            return (state.displayBoardReducer as IDisplayModel).refreshLoading;
        else
            return false;
    })
    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="DBtooltip" onClick={() => dispatch(getBranchesThemesDataRequest(true, true))}></i>
                <UncontrolledTooltip color="primary" placement="top" target="DBtooltip">
                    {t('ActionNames.autoRefresh')}
                </UncontrolledTooltip>
            </>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}