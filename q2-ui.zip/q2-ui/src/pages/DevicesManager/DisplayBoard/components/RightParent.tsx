import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import '../../Container/devices.css';
import { SuperParentContext } from '../Container/displayboardcontext';
import { IOprationalActions } from '../../../../models/utilitiesModel';

const RightParent: React.FC = () => {
    const context = useContext(SuperParentContext);

    const DBactionType = useSelector(state => {
        if (state && state.displayBoardReducer && state.displayBoardReducer.actionType)
            return state.displayBoardReducer.actionType;
        else return 0;
    });

    return (
        <>


            <div className="flexLayout-inner">
                    <div className="pl-3 pr-3">
                        {(DBactionType === IOprationalActions.ADD || DBactionType === IOprationalActions.EDIT) && <context.actionComponent />}
                        {DBactionType === IOprationalActions.SELECT && <context.viewComponent />}
                    </div>
            </div>

        </>
    )
}
export default React.memo(RightParent);