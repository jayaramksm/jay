import React, { useContext, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../../Container/devices.css';
import { useTranslation } from 'react-i18next';
import { SuperParentContext } from '../Container/displayboardcontext';
import { Row, Col, Card, CardBody } from 'reactstrap';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../Utilities/PaginationComponent';
import { IDisplayBoard } from '../../../../models/displayBoardModel';
import { setDisplayBoardActionRequest, suspendDBaction } from '../../../../store/actions';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import { IBranch } from '../../../../models/branchRoomModel';

const DisplayBoardManager: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context = useContext(SuperParentContext);
    const branchData: IBranch[] = useSelector(state => state?.branchAndRoomReducer?.branchData);
    const pageSize = getEnvironment.listPageSize;
    const displayBoardsTData: IDisplayBoard[] = useSelector(state => state?.displayBoardReducer?.displayBoardsData);
    const searchKey = useSelector(state => {
        if (state && state.displayBoardReducer && state.displayBoardReducer.dbSearchKey)
            return state.displayBoardReducer.dbSearchKey;
        else return '';
    });
    const selectedDBid = useSelector(state => {
        if (state && state.displayBoardReducer && state.displayBoardReducer.actionData)
            return (state.displayBoardReducer.actionData as IDisplayBoard).displayId;
        else return 0;
    });

    const filterBranchId = useSelector(state => state?.displayBoardReducer?.filterBranchId);
    const displayBoardsData: IDisplayBoard[] = (displayBoardsTData && (searchKey !== '' || filterBranchId !== 0)) ?
        displayBoardsTData.filter((x: IDisplayBoard) =>
            (searchKey !== '' ? x.displayName.toLowerCase().startsWith(searchKey.toLowerCase()) : true) &&
            (filterBranchId !== 0 ? x.branches.includes(filterBranchId) : true)
        ) : displayBoardsTData;

    const selectDisplayBoard = (displayBoardData) => {
        dispatch(setDisplayBoardActionRequest(IOprationalActions.SELECT, displayBoardData, branchData))
    };

    const displayBoardDataCount = useSelector(state => {
        if (state && state.displayBoardReducer && state.displayBoardReducer.displayBoardsData)
            return state.displayBoardReducer.displayBoardsData.length;
        else return 0;
    });
    console.log('displayBoardDataCount => ', displayBoardDataCount);

    const cancelView = () => dispatch(suspendDBaction());

    let pagesCount = Math.ceil((displayBoardsData ? displayBoardsData.length : 0) / pageSize);

    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index);
    }

    return (
        <>
            <Card className="lft-card flexLayout mb-0">

                <div className="flex-headerfix px-3 pt-3">
                    <context.filterComponent />
                </div>
                <CardBody>
                    {displayBoardsData && displayBoardsData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('Display.noDisplays')}</span>}
                    {displayBoardsData && displayBoardsData.length === 0 && searchKey !== '' && <span className="recdnotfound">{t('Display.noSearchResults')}</span>}
                    <div className="flexLayout">
                        <div className="flexLayout-inner layou1rgtColmn">
                            <Row>
                                <Col sm="12" className="actn-list">
                                    {displayBoardsData && displayBoardsData.length > 0 && displayBoardsData.slice(currentPage * pageSize,
                                        (currentPage + 1) * pageSize).map(item => (
                                            <div key={item.displayId} className={'btn btn-sm ' + (selectedDBid === item.displayId ? 'activeList' : '')} onClick={selectedDBid === item.displayId ? cancelView : () => selectDisplayBoard(item)}>{item.displayName}</div>
                                        ))}
                                </Col>
                            </Row>
                        </div>

                        {displayBoardsData && displayBoardsData.length > pageSize && <Row className="lft-pagination">
                            <div className="pagination ml-4">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>
                        </Row>}
                    </div>
                </CardBody>

            </Card>
        </>
    )
}
export default React.memo(DisplayBoardManager);