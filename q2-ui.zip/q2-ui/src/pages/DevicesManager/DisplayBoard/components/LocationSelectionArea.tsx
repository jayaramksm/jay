import React from 'react';
import { LocationSelectArea } from '../../../Utilities/LocationSelectArea';
import { changeLocationForDisplayBoard } from '../../../../store/actions';

const LocationSelectionArea: React.FC = () => {
    return <LocationSelectArea locationCallBack={changeLocationForDisplayBoard} />
}
export default React.memo(LocationSelectionArea);