import React, { useContext, useState } from 'react';
import { useSelector, useDispatch, batch } from 'react-redux';
import '../../Container/devices.css';
import { useTranslation } from 'react-i18next';
import { Card, CardBody, Row, Col, Label, UncontrolledTooltip, Modal, ModalBody } from 'reactstrap';
import publish from '../../../../images/publish.svg';
import { IDisplayBoard, IDBTheme } from '../../../../models/displayBoardModel';
import * as _ from 'lodash';
import { setDisplayBoardActionRequest, deleteDisplayBoardRequest, publishDBUrlRequest } from '../../../../store/actions';
import { SuperParentContext } from '../Container/displayboardcontext';
import { IOprationalActions, ISessionstate } from '../../../../models/utilitiesModel';
import { IBranch } from '../../../../models/branchRoomModel';
import { IService } from '../../../../models/servicesModel';

const DisplayBoardView: React.FC = () => {
    const [moreBranches, setMoreBranches] = useState(false);
    const [moreServices, setMoreServices] = useState(false);

    const actions = useContext(SuperParentContext)?.actions;
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const DBactionData: IDisplayBoard = useSelector(state => state?.displayBoardReducer?.actionData);
    const themesData: IDBTheme[] = useSelector(state => state?.displayBoardReducer?.themesData);
    const DBservicesData: IService[] = useSelector(state => state?.displayBoardReducer?.dbServicesData);
    const branchData: IBranch[] = useSelector(state => state?.branchAndRoomReducer?.branchData);
    let DBbranchDetails, DBserviceDetails;

    if (DBactionData && DBactionData?.branches?.length > 0 && branchData) {
        DBbranchDetails = branchData.filter(x => DBactionData.branches.includes(x.branchId))?.map(y => y.branchNameEn);
    }
    if (DBactionData && DBactionData.services.length > 0 && DBservicesData) {
        DBserviceDetails = DBservicesData.filter(x => DBactionData.services.includes(x.serviceId))?.map(y => y.serviceNameEn);
    }

    const editDisplayBoard = () => {
        batch(() => {
            dispatch(setDisplayBoardActionRequest(IOprationalActions.EDIT, DBactionData, branchData));
            // dispatch(getServicesDataRequest(branchData?.map(x => x.branchId)));
        })
    }
    const deleteDisplayBoard = (displayId, displayName) => {
        let confirmMsg = t('Display.confirmMessages.DC2').replace('{displayName}', displayName);
        dispatch(deleteDisplayBoardRequest(displayId, false, confirmMsg));
    };

    const getPublishUrl = () => dispatch(publishDBUrlRequest(DBactionData?.displayId));

    return (
        <>
            {DBactionData && <><Card className="view">
                <CardBody >
                    <Row>
                        <Col sm="6">
                            <Label>{t('Display.displayDBname')}</Label>
                            <br />
                            <span>{DBactionData.displayName}</span>
                        </Col>
                        <Col sm="3">
                            <Label>{t('Display.theme')}</Label><br />
                            <span>{themesData && themesData.find(x => x.themeId === DBactionData.themeId)?.themeName}</span>
                        </Col>
                        <Col></Col>
                    </Row>
                    <hr />
                    <Row>
                        <Col>
                            <Label>{t('Display.servicesLabel')}</Label><br />
                            <span className="mr-2">{DBactionData?.services?.length > 0 ? _.join(DBserviceDetails?.slice(0, 10), ', ') : t('Display.none')}</span>
                            {DBactionData?.services?.length > 10 && DBserviceDetails?.length > 10 && <span className="btn text-primary pl-0" onClick={() => setMoreServices(true)}>{t('ActionNames.more')}</span>}

                        </Col>
                        <Col>
                            <Label>{t('Display.branches')}</Label><br />
                            <span className="mr-2">{DBactionData?.branches?.length > 0 ? _.join(DBbranchDetails?.slice(0, 10), ', ') : t('Display.none')}</span>
                            {DBactionData?.branches?.length > 10 && DBbranchDetails?.length > 10 && <span className="btn text-primary pl-0" onClick={() => setMoreBranches(true)}>{t('ActionNames.more')}</span>}
                        </Col>
                    </Row>
                    <hr />
                    <Row>
                        <Col className="align-right action">
                            {selectedLocationStatus && <div className="publish p-2 pointer" id="publish" onClick={getPublishUrl}>
                                <img src={publish} alt="" />
                                <UncontrolledTooltip color="primary" placement="top" target="publish">
                                    {t('Display.publishURL')}
                                </UncontrolledTooltip>
                            </div>}
                            {actions.edit && selectedLocationStatus && <>
                                <i id="edit" className="ti-pencil-alt" onClick={editDisplayBoard}></i>
                                <UncontrolledTooltip color="primary" placement="top" target="edit">
                                    {t('ActionNames.edit')}
                                </UncontrolledTooltip>
                            </>}

                            {actions.delete && selectedLocationStatus && <>
                                <i id="delete" className="ti-trash" onClick={() => deleteDisplayBoard(DBactionData.displayId, DBactionData.displayName)}></i>
                                <UncontrolledTooltip color="primary" placement="top" target="delete">
                                    {t('ActionNames.delete')}
                                </UncontrolledTooltip>
                            </>}
                        </Col>
                    </Row>
                </CardBody>
            </Card>

                <Modal className="modal-lg OtrServices services more" isOpen={moreServices} toggle={() => setMoreServices(!moreServices)}>
                    <div className="Clos">
                        <button onClick={() => setMoreServices(false)} type="button" className="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <ModalBody className="pt-0 pr-0">
                        <h6>{t('Display.servicesLabel')}</h6>
                        <div className="flexLayout" style={{ maxHeight: "350px" }}>
                            <div className="flexLayout-inner">
                                <div className="servicesList pr-4">
                                    <span className="mr-2">{_.join(DBserviceDetails, ', ')}</span>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                </Modal>

                <Modal className="modal-lg OtrServices branches more" isOpen={moreBranches} toggle={() => setMoreBranches(!moreBranches)}>
                    <div className="Clos">
                        <button onClick={() => setMoreBranches(false)} type="button" className="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <ModalBody className="pt-0 pr-0">
                        <h6>{t('Display.branchesLabel')}</h6>
                        <div className="flexLayout" style={{ maxHeight: "350px" }}>
                            <div className="flexLayout-inner">
                                <div className="servicesList pr-4">
                                    <span className="mr-2">{_.join(DBbranchDetails, ', ')}</span>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                </Modal>
            </>
            }
        </>
    )
}
export default React.memo(DisplayBoardView);