import * as React from 'react';
import { activateAuthLayout } from '../../../../store/actions';
import { connect } from 'react-redux';
import { Col, Row, Container } from 'reactstrap';
import { SuperParentContext } from './kioskcontext';
import { IRoleDesc, IActions } from '../../../../models/utilitiesModel';
import {
    LeftKioskParent, LocationSelectionKiosk, KioskFilter, KioskManager, KioskItem,
    RightKioskParent, KioskAction, KioskView, KioskAutoRefresh
} from './kioskindex';

import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../../helpers/helpersIndex';
import { getKioskDataRequest, cancelAllPendingKioskRequests, setResetForKiosk } from '../../../../store/actions';

export interface IProps {
    activateAuthLayout: any;
    getKioskDataRequest: any;
    cancelAllPendingKioskRequests: any;
    setResetForKiosk: any;
    kioskLoad: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
}

class Kiosk extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props)
        this.state = {
            leftKioskParent: {
                locationView: props.loginUserRolecode === IRoleDesc.ENTERPRISEADMIN ? LocationSelectionKiosk : null,
                filterComponent: KioskFilter,
                listComponent: KioskManager,
                itemComponent: KioskItem,
                actions: { add: this.props.add }
            },
            rightKioskParent: {
                viewComponent: KioskView,
                actionComponent: KioskAction,
                actions: { edit: this.props.edit, delete: this.props.delete }
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForKiosk();
        if (this.props.kioskLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getKioskDataRequest(!this.props.kioskLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getKioskDataRequest(!this.props.kioskLoad, true);
    }
    componentWillUnmount() {
        this.props.cancelAllPendingKioskRequests();
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForKiosk();
    }



    render() {

        return (
            <>
                {getAutoRefresing() && <KioskAutoRefresh />}
                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftKioskParent}>
                                <LeftKioskParent />
                            </SuperParentContext.Provider>
                        </Col>
                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightKioskParent}>
                                <RightKioskParent />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>
            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'kiosk', defaultPrivilages);
    if (getAutoRefresing() && state.kioskReducer && (state.kioskReducer).kioskData)
        return {
            kioskLoad: ((state.kioskReducer).kioskData.length > 0 ? true : false),
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
    else
        return {
            kioskLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
}
export default connect(mapStatetoProps, { activateAuthLayout, getKioskDataRequest, setResetForKiosk, cancelAllPendingKioskRequests })(Kiosk);
