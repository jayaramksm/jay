import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import { Col, Row, Card, CardBody, FormGroup, Label } from 'reactstrap';
import { MySelect, Option, MultiValue, ValueContainer, controleContentValidate, customContentValidation } from '../../../../helpers/helpersIndex';
import { kioskSuspendOrEditActionRequest, createOrEditKioskRequest } from '../../../../store/actions';
import { IKioskModel, ITheme, IKiosk } from '../../../../models/kioskModel';
import { IBranchRoomModel, IBranch } from '../../../../models/branchRoomModel';
import '../../Container/devices.css';
import * as _ from 'lodash';

export interface optionsData {
    value: any;
    label: any;
}

const KioskAction: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const kioskActionData: IKiosk = useSelector(state => {
        if ((state.kioskReducer && state.kioskReducer.actionData))
            return (state.kioskReducer as IKioskModel).actionData;
        else
            return undefined
    });
    const actionType = useSelector(state => {
        if ((state.kioskReducer && state.kioskReducer.actionType))
            return (state.kioskReducer as IKioskModel).actionType;
        else
            return undefined
    });

    const themesData: ITheme[] = useSelector(state => {
        if ((state.kioskReducer && state.kioskReducer.themsData))
            return (state.kioskReducer as IKioskModel).themsData;
        else
            return []
    });
    const branchData: IBranch[] = useSelector(state => {
        console.log("kiosk_ActionCOmp =>", state.branchAndRoomReducer);
        if ((state.branchAndRoomReducer && state.branchAndRoomReducer.branchData))
            return (state.branchAndRoomReducer as IBranchRoomModel).branchData;
        else
            return []
    });
    const branchesMapData = _.orderBy(branchData, ['branchNameEn'], ['asc']).map(item => ({ value: item.branchId, label: item.branchNameEn }));
    console.log("KioskAction =>", kioskActionData, actionType, themesData, branchData);

    const selectedBranch = (e, setFieldValue) => {
        setFieldValue('branches', e);
    };
    const themsSelection = (e, setFieldValue) => {
        setFieldValue('thems', e);
    };

    const patchTheme = (themId) => {
        let index = themesData.findIndex(x => x.themeId === themId);
        return index !== -1 ? { value: themesData[index].themeId, label: themesData[index].themeName } : '';
    };
    const patchBranches = (branches) => {
        let patchBranchData: any = [];
        branches.forEach(x => {
            let index = branchData.findIndex(y => y.branchId === x);
            if (index !== -1) {
                patchBranchData.push({ value: branchData[index].branchId, label: branchData[index].branchNameEn })
            }
        });
        if (branchData.length > 2 && branches.length === branchData.length) {
            patchBranchData.push({ value: 0, label: 'Select All' });
        }
        return patchBranchData;
    };

    const cancelEditFunction = () => {
        dispatch(kioskSuspendOrEditActionRequest(actionType === IOprationalActions.EDIT ? IOprationalActions.SELECT : 0));
    }

    return (
        <>
            <Formik
                enableReinitialize
                initialValues={{
                    kioskId: kioskActionData ? kioskActionData.kioskId : '',
                    kioskIdentifier: kioskActionData ? kioskActionData.kioskIdentifier : '',
                    status: kioskActionData ? kioskActionData.status : '',
                    kioskName: kioskActionData ? kioskActionData.kioskName : '',
                    kioskIp: kioskActionData ? kioskActionData.kioskIp : '',
                    thems: kioskActionData ? patchTheme(kioskActionData.themeId) : themesData.length === 1 ? { value: themesData[0].themeId, label: themesData[0].themeName } : '',
                    branches: kioskActionData ? patchBranches(kioskActionData.branches) : branchesMapData.length === 1 ? [{ value: branchesMapData[0].value, label: branchesMapData[0].label }] : ''
                }}
                validationSchema={Yup.object().shape({
                    kioskName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspacesp', spacialChar: '_-' }, 50, 2),
                    kioskIp: controleContentValidate(t('controleErrors.required'), { value: 2, message: t('controleErrors.min').replace('{min}', '2') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, { patternType: 'ipPattern', message: t('controleErrors.ipPatternInvalid') }),
                    thems: controleContentValidate(t('controleErrors.required')).nullable(),
                    branches: controleContentValidate(t('controleErrors.required')).nullable(),
                })}
                onSubmit={(values, { resetForm }) => {
                    console.log("onSubmit_Values =>", values);
                    let themeId = values.thems as optionsData;
                    let branchArray = (values.branches as any[]).filter(x => x.value !== 0);
                    let branchIds: any = [];
                    branchArray.forEach(y => {
                        branchIds.push(y.value)
                    });
                    let kiosk = {
                        kioskId: values.kioskId,
                        kioskIdentifier: values.kioskIdentifier,
                        status: values.status,
                        kioskName: values.kioskName,
                        kioskIp: values.kioskIp,
                        themeId: themeId.value,
                        branches: branchIds
                    }
                    console.log("Dispatch_Data =>", kiosk);
                    dispatch(createOrEditKioskRequest(actionType, kiosk));
                }}
            >
                {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                    <Form>
                        <Card>
                            <CardBody>
                                <Row>
                                    <Col sm="12">
                                        <Row>
                                            <Col className="FormStyle">
                                                <FormGroup>
                                                    <Field name="kioskName" placeholder={t('Kiosk.kioskPlace')}
                                                        className={'form-control ' + (errors.kioskName && touched.kioskName ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="kioskName" component="div" className="invalid-feedback" />
                                                    <Label className="label" htmlFor="example-text-input">{t('Kiosk.kioskLabel')}</Label>
                                                </FormGroup>
                                            </Col>
                                            <Col className="FormStyle">
                                                <FormGroup>
                                                    <Field name="kioskIp" placeholder={t('Kiosk.kioskIpPlace')}
                                                        className={'form-control ' + (errors.kioskIp && touched.kioskIp ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="kioskIp" component="div" className="invalid-feedback" />
                                                    <Label className="label" htmlFor="example-text-input">{t('Kiosk.kioskIpLabel')}</Label>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Label>{t('Kiosk.selectTheme')}</Label>
                                                    <MySelect
                                                        name="thems"
                                                        placeholder={t('Kiosk.selectTheme')}
                                                        value={values.thems}
                                                        onChange={(e) => themsSelection(e, setFieldValue)}
                                                        options={themesData.map(item => ({ value: item.themeId, label: item.themeName }))}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onBlur={() => setFieldTouched('thems', true)}
                                                        noOptionsMessage={() => t('Kiosk.noThemes')}
                                                    />
                                                    {errors.thems && touched.thems && (
                                                        <div className="error-msg">{errors.thems}
                                                        </div>
                                                    )}
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <hr />
                                        <Row>
                                            <Col sm="4">
                                                <FormGroup className="multiselect">
                                                    <Label>{t('Kiosk.selectBranch')}</Label>
                                                    <MySelect
                                                        name="branches"
                                                        allOption={{
                                                            label: "Select All",
                                                            value: 0
                                                        }}
                                                        isMulti
                                                        placeholder={t('Kiosk.selectBranch')}
                                                        options={branchesMapData}
                                                        value={values.branches}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onChange={e => selectedBranch(e, setFieldValue)}
                                                        components={{ Option, MultiValue, ValueContainer }}
                                                        defaultValue=''
                                                        hideSelectedOptions={false}
                                                        removeSelected={false}
                                                        closeMenuOnSelect={false}
                                                        backspaceRemovesValue={false}
                                                        allowSelectAll={branchData.length > 2 ? true : false}
                                                        onBlur={() => setFieldTouched('branches', true)}
                                                        noOptionsMessage={() => t('Kiosk.noBranches')}
                                                    />
                                                    {errors.branches && touched.branches && (
                                                        <div className="error-msg">{errors.branches}
                                                        </div>
                                                    )}
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>

                                <hr />

                                <div className="align-right action">
                                    <button type="submit" disabled={!(dirty)} className="btn btn-primary ml-2">
                                        {actionType === IOprationalActions.ADD ? t('ActionNames.save') : t('ActionNames.update')}
                                    </button>
                                    <button className="btn btn-cancel ml-3" onClick={cancelEditFunction}>{t('ActionNames.cancel')}</button>
                                </div>
                            </CardBody>
                        </Card>
                    </Form>
                )}
            </Formik>
        </>
    )
}

export default React.memo(KioskAction);


