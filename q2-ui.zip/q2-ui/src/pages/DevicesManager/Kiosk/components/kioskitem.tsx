import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import { ChildContext } from '../Container/kioskcontext';
import { IKioskModel } from '../../../../models/kioskModel';
import { kioskSuspendOrEditActionRequest, setKioskActionRequestData } from '../../../../store/actions';
import '../../Container/devices.css';

const KioskItem: React.FC = () => {

    const context: any = useContext(ChildContext);
    const dispatch = useDispatch();
    console.log("KioskItem_context =>", context);

    let kioskData = useSelector(state => {
        if (state && state.kioskReducer) {
            let data = (state.kioskReducer as IKioskModel).kioskData;
            let index = data.findIndex(x => x.kioskId === context);
            if (index !== -1)
                return state.kioskReducer.kioskData[index];
            else return undefined;
        }
        else return undefined;
    });

    const selectedKiosk = useSelector(state => {
        if (state && state.kioskReducer) {
            return (state.kioskReducer).actionData ?
                ((state.kioskReducer as IKioskModel).actionData).kioskId === (kioskData ? kioskData.kioskId : false) : false;
        }
        else return false;
    });
    console.log("KioskItem =>", kioskData, selectedKiosk);

    const selectKiosk = () => {
        dispatch(selectedKiosk ? kioskSuspendOrEditActionRequest(0) : setKioskActionRequestData(IOprationalActions.SELECT, kioskData, false));
    }

    return (
        <>
                <span className={'btn btn-sm ' + (selectedKiosk ? 'activeList' : '')} onClick={() => selectKiosk()}  >
                    {kioskData && kioskData.kioskName}
                </span>
        </>
    )
}
export default React.memo(KioskItem);