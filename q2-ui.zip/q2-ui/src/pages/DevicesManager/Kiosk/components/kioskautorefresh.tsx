import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../../Container/devices.css';
import { getKioskDataRequest } from '../../../../store/actions';
import { IKioskModel } from '../../../../models/kioskModel';
import { UncontrolledTooltip } from 'reactstrap';
import { useTranslation } from 'react-i18next';

export const KioskAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const refreshLoading = useSelector(state => {
        if (state && state.kioskReducer)
            return (state.kioskReducer as IKioskModel).refreshLoading
        else
            return false;
    });

    return (
        <>
            <div className="pageReload"> {!refreshLoading && <>
                <i className="ti-reload" id="Ktooltip" onClick={() => dispatch(getKioskDataRequest(true, true))}></i>
                <UncontrolledTooltip color="primary" placement="top" target="Ktooltip">
                    {t('ActionNames.autoRefresh')}
                </UncontrolledTooltip>
            </>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}