
import React from 'react'
import { LocationSelectArea } from '../../../Utilities/LocationSelectArea';
import { changeLocationForKiosk } from '../../../../store/actions';

export const LocationSelectionKiosk: React.FC = () => {
    return <LocationSelectArea locationCallBack={changeLocationForKiosk} />
}
