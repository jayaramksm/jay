import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext, ParentContext } from '../Container/kioskcontext';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import { IKioskModel } from '../../../../models/kioskModel';

const RightKioskParent: React.FC = () => {

    const context: any = useContext(SuperParentContext);
    const actionArea = useSelector(state => {
        if (state && state.kioskReducer)
            return (state.kioskReducer as IKioskModel).actionType;
        else return undefined;
    });
    console.log("RightKioskParent =>", context, actionArea);

    return (
        <>


            <div className="flexLayout-inner">
                    <div className="pl-3 pr-3">

                        {(actionArea === IOprationalActions.ADD || actionArea === IOprationalActions.EDIT) && <context.actionComponent />}
                        {actionArea === IOprationalActions.SELECT &&
                            <ParentContext.Provider value={context.actions}>
                                <context.viewComponent />
                            </ParentContext.Provider>
                        }

                    </div>
            </div>


        </>
    )
}
export default React.memo(RightKioskParent);