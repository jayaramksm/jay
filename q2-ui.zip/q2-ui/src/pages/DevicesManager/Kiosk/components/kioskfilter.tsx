import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { IOprationalActions, ISessionstate } from '../../../../models/utilitiesModel';
import { MySelect } from '../../../../helpers/helpersIndex';
import { ParentContext } from '../Container/kioskcontext';
import { Col, Row, UncontrolledTooltip } from 'reactstrap';
import { setKioskActionRequestData, setKioskSearchKey } from '../../../../store/actions';
import { IKioskModel } from '../../../../models/kioskModel';
import { IBranch } from '../../../../models/branchRoomModel';
import '../../Container/devices.css';
import * as _ from 'lodash';

const KioskFilter: React.FC = () => {

    const context: any = useContext(ParentContext);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const isAddAction = useSelector(state => {
        if (state && state.kioskReducer)
            return (state.kioskReducer as IKioskModel).actionType === IOprationalActions.ADD;
        else return false;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const filterActions = useSelector(state => {
        if (state && state.kioskReducer && state.kioskReducer.kioskData)
            return (state.kioskReducer as IKioskModel).kioskData.length > 0;
        else return false;
    });
    const branchesData: IBranch[] = useSelector(state => state?.branchAndRoomReducer?.branchData);
    let branchesMapData = _.orderBy(branchesData, ['branchNameEn'], ['asc']).map(x => ({ value: x.branchId, label: x.branchNameEn }));
    branchesMapData = [{ value: 0, label: '--Select Department--' }, ...(branchesMapData ? branchesMapData : [])];
    console.log("KioskFilter =>", isAddAction, filterActions, branchesData);

    const addKiosk = () => {
        if (!isAddAction)
            dispatch(setKioskActionRequestData(IOprationalActions.ADD, null, false));
    }
    const setSearch = (key) => {
        console.log("setSearch =>", key);
        dispatch(setKioskSearchKey(key, 1));
    }

    const onBranchSelection = (e) => {
        console.log("onBranchSelection =>", e);
        dispatch(setKioskSearchKey(e.value, 2));
    }

    return (
        <>
            <Row className="roleslist">
                <Col className="pr-0">
                    <h6 className="m-0">{t('Kiosk.listOfKiosk')}</h6>
                </Col>
                <div className="align-right pl-2 pr-3 addupload">
                    {context.add && selectedLocationStatus && <><button className="btn btn-out-dashed" id="add" disabled={isAddAction} onClick={addKiosk}> {t('Kiosk.add')} &nbsp; <span className="addbtn">+</span></button>

                        {!isAddAction && <UncontrolledTooltip color="primary" placement="right" target="add">
                            {t('Kiosk.addKioskTooltip')}
                        </UncontrolledTooltip>}
                    </>}
                </div>
            </Row>
            {filterActions && <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={e => setSearch(e.target.value)} />
                <i className="fa fa-search"></i>
            </div>}
            <Row>
                {filterActions && branchesMapData?.length > 2 && <Col sm="12" className="mt-1">
                    <MySelect
                        placeholder={t('Kiosk.selectBranch')}
                        onChange={(e) => onBranchSelection(e)}
                        options={branchesMapData ? branchesMapData : []}
                        getOptionLabel={option => option.label}
                        getOptionValue={option => option.value}
                        noOptionsMessage={() => t('Kiosk.noBranches')}
                    />
                </Col>}
                {/* <Col sm="2" className="pl-2 filtericon">
                    <UncontrolledDropdown>
                        <DropdownToggle id="Filter">
                            <img src={filter} alt="" />
                        </DropdownToggle>
                        <DropdownMenu>
                            <DropdownItem>All</DropdownItem>
                            <DropdownItem>Active</DropdownItem>
                            <DropdownItem>InActive</DropdownItem>
                        </DropdownMenu>
                    </UncontrolledDropdown>
                    <UncontrolledTooltip color="primary" placement="top" target="Filter">
                        Filter
                    </UncontrolledTooltip>
                </Col> */}
            </Row>
        </>
    )
}
export default React.memo(KioskFilter);