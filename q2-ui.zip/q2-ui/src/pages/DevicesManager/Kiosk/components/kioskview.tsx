import React, { useState, useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext } from '../Container/kioskcontext';
import { IOprationalActions, ISessionstate } from '../../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { Col, Row, Card, CardBody, Label, Modal, ModalBody, UncontrolledTooltip } from 'reactstrap';
import publish from '../../../../images/publish.svg';
import { kioskSuspendOrEditActionRequest, deleteKioskRequest, getKioskURLRequest } from '../../../../store/actions';
import { IBranchRoomModel, IBranch } from '../../../../models/branchRoomModel';
import { ITheme, IKioskModel, IKiosk } from '../../../../models/kioskModel';
import * as _ from 'lodash';
import '../../Container/devices.css';

const KioskView: React.FC = () => {

    let patchBranchData;
    const [moreBranches, setMoreBranches] = useState(false);

    const { t } = useTranslation("translations");
    const context: any = useContext(ParentContext);
    console.log('context_new => ', context);
    const dispatch = useDispatch();

    const branchesData: IBranch[] = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData)
            return (state.branchAndRoomReducer as IBranchRoomModel).branchData;
        else return undefined;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const themesData: ITheme[] = useSelector(state => {
        if (state.kioskReducer && state.kioskReducer.themsData)
            return (state.kioskReducer as IKioskModel).themsData;
        else return [];
    });
    const kioskActionData: IKiosk = useSelector(state => {
        if (state.kioskReducer && state.kioskReducer.actionData)
            return (state.kioskReducer as IKioskModel).actionData;
        else return undefined;
    });
    console.log("KioskView =>", branchesData, themesData, kioskActionData);

    const editKiosk = () => {
        dispatch(kioskSuspendOrEditActionRequest(IOprationalActions.EDIT));
    }
    const deleteKiosk = () => {
        let message = t('Kiosk.confirmMessages.KC2').replace('{kioskName}', kioskActionData.kioskName);
        console.log("deleteBranch =>", IOprationalActions.DELETE, kioskActionData.kioskId, message, false);
        dispatch(deleteKioskRequest(IOprationalActions.DELETE, kioskActionData.kioskId, message, false));
    }
    const publishUrl = () => {
        console.log("publishUrl =>", kioskActionData.kioskId);
        dispatch(getKioskURLRequest(kioskActionData.kioskId));
    }

    if (branchesData && kioskActionData.branches) {
        patchBranchData = branchesData.filter(x => kioskActionData.branches.includes(x.branchId))?.map(y => y.branchNameEn);
        console.log('patchBranchData => ', patchBranchData);
    }

    const tog_branch = () => {
        setMoreBranches(!moreBranches);
    }

    return (
        <>
            <Card>
                <CardBody>
                    <Row>
                        <Col sm="12">
                            <Row className="FormStyle view">
                                <Col>
                                    <Label>{t('Kiosk.kioskLabel')}</Label><br />
                                    <span>{kioskActionData.kioskName}</span>
                                </Col>
                                <Col>
                                    <Label>{t('Kiosk.kioskIpLabel')}</Label><br />
                                    <span>{kioskActionData.kioskIp}</span>
                                </Col>
                                <Col>
                                    <Label>{t('Kiosk.selectTheme')}</Label><br />
                                    <span>{themesData && themesData.find(x => x.themeId === kioskActionData.themeId)?.themeName}</span>
                                </Col>
                            </Row>
                        </Col>
                    </Row>

                    <hr />

                    <Row>
                        <Col className="view">
                            <Label>{t('Kiosk.selectBranch')}</Label><br />
                            <span className="mr-2">
                                {kioskActionData?.branches?.length > 0 ? _.join(patchBranchData?.slice(0, 10), ', ') : t('Kiosk.none')}
                            </span>
                            {kioskActionData?.branches?.length > 10 && patchBranchData?.length > 10 && <span className="btn text-primary pl-0" onClick={() => setMoreBranches(true)}>{t('ActionNames.more')}</span>}
                        </Col>
                    </Row>

                    <hr />

                    <div className="align-right action">
                        {selectedLocationStatus && <div className="publish p-2 pointer" id="publish">
                            <img src={publish} alt="" onClick={publishUrl} />
                            <UncontrolledTooltip color="primary" placement="top" target="publish">
                                {t('Kiosk.publishURL')}
                            </UncontrolledTooltip>
                        </div>}

                        {selectedLocationStatus && <>
                            <i id="edit" className="ti-pencil-alt" onClick={editKiosk}></i>
                            <UncontrolledTooltip color="primary" placement="top" target="edit">
                                {t('ActionNames.edit')}
                            </UncontrolledTooltip>
                        </>}

                        {selectedLocationStatus && <>
                            <i id="delete" className="ti-trash" onClick={deleteKiosk}></i>
                            <UncontrolledTooltip color="primary" placement="top" target="delete">
                                {t('ActionNames.delete')}
                            </UncontrolledTooltip>
                        </>}
                    </div>
                </CardBody>
            </Card>
            <Modal className="modal-lg OtrServices branches more" isOpen={moreBranches} toggle={tog_branch} >
                <div className="Clos">
                    <button onClick={() => setMoreBranches(false)} type="button" className="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <ModalBody className="pt-0 pr-0">
                    <h6>{t('Kiosk.selectBranch')}</h6>

                    <div className="flexLayout" style={{maxHeight:"350px"}}>
                        <div className="flexLayout-inner">
                            <div className="servicesList pr-4">
                                <span className="mr-2">
                                    {_.join(patchBranchData, ', ')}
                                </span>
                            </div>
                        </div>
                    </div>
                </ModalBody>
            </Modal>
        </>
    )
}

export default React.memo(KioskView);