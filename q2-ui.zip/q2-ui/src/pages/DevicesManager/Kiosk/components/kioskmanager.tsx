import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
import { ChildContext, ParentContext } from '../Container/kioskcontext';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { PaginationComponent } from '../../../Utilities/PaginationComponent';
import { IKioskModel, IKiosk } from '../../../../models/kioskModel';
import '../../Container/devices.css';

const KioskManager: React.FC = () => {

    const context = useContext<any>(ParentContext);
    console.log("KioskManager_context =>", context);
    const { t } = useTranslation("translations");
    const pageSize = getEnvironment.listPageSize;

    const kioskData: IKiosk[] = useSelector(state => {
        if (state && state.kioskReducer && state.kioskReducer.kioskData) {
            let data = (state.kioskReducer as IKioskModel).kioskData;
            return data;
        }
        else return undefined;
    });
    const searchKey = useSelector(state => {
        if (state && state.kioskReducer)
            return (state.kioskReducer as IKioskModel).searchKey ? (state.kioskReducer as IKioskModel).searchKey : '';
        else return '';
    });
    const filterBranchId = useSelector(state => {
        if (state && state.kioskReducer)
            return (state.kioskReducer as IKioskModel).searchBranchId ? (state.kioskReducer as IKioskModel).searchBranchId : 0;
        else return 0;
    });

    const filterKioskData: IKiosk[] = (kioskData && (searchKey !== '' || filterBranchId !== 0)) ?
        kioskData.filter((x: IKiosk) =>
            (searchKey !== '' ? x.kioskName.toLowerCase().startsWith(searchKey.toLowerCase()) : true) &&
            (filterBranchId !== 0 ? x.branches.includes(filterBranchId) : true)
        ) : kioskData;

    let kioskCount = useSelector(state => {
        if (state && state.kioskReducer && state.kioskReducer.kioskData)
            return (state.kioskReducer as IKioskModel).kioskData.length;
        else return 0;
    });
    console.log("KioskManager =>", kioskData, filterKioskData, searchKey, filterBranchId, kioskCount);

    let pagesCount = Math.ceil((filterKioskData ? filterKioskData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }


    return (
        <>
            {filterKioskData && filterKioskData.length === 0 && searchKey !== '' && <span className="recdnotfound">{t('Kiosk.noResFound')}</span>}
            {filterKioskData && filterKioskData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('Kiosk.noKioskFound')}</span>}
            <div className="flexLayout">
                <div className="flexLayout-inner layou1rgtColmn">
                    <Row>
                        <Col sm="12" className="actn-list">
                            {filterKioskData && filterKioskData.length > 0 && filterKioskData.slice(currentPage * pageSize,
                                (currentPage + 1) * pageSize).map((item, index) => (
                                    <ChildContext.Provider key={index} value={item.kioskId}>
                                        <context.itemComponent />
                                    </ChildContext.Provider>
                                ))}
                        </Col>
                    </Row>
                </div>

                <Row className="lft-pagination">
                    {filterKioskData && filterKioskData.length > pageSize &&
                        <div className="pagination ml-4">
                            <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                        </div>
                    }
                </Row>
            </div>
        </>
    )
}
export default React.memo(KioskManager);