import React, { useContext } from 'react';
import { Card, CardBody } from 'reactstrap';
import { SuperParentContext, ParentContext } from '../Container/kioskcontext';
import '../../Container/devices.css';

const LeftKioskParent: React.FC = () => {
    const context: any = useContext(SuperParentContext);

    return (
        <>
            {context.locationView && <context.locationView />}
            <Card className="lft-card flexLayout mb-0">
            <div className="flex-headerfix px-3 pt-3">
            <ParentContext.Provider value={context.actions}>
                        <context.filterComponent />
                    </ParentContext.Provider>
            </div>
                <CardBody>
                    <ParentContext.Provider value={{ itemComponent: context.itemComponent }}>
                        <context.listComponent />
                    </ParentContext.Provider>
                </CardBody>
            </Card>
        </>
    )
}
export default React.memo(LeftKioskParent);