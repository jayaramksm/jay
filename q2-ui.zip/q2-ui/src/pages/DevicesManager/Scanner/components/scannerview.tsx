import React, { useContext } from 'react';
import { Col, Row, Card, CardBody, Label, UncontrolledTooltip } from 'reactstrap';
import '../../Container/devices.css';
import { useSelector, useDispatch } from 'react-redux';
import { ParentContext } from '../Container/scannercontextApi';
import { useTranslation } from 'react-i18next';
import { IBranch, IBranchRoomModel } from '../../../../models/branchRoomModel';
import { IScanner, IScannerModel } from '../../../../models/scannerModel';
import { suspendOrEditScannerAction, deleteScannerRequest } from '../../../../store/actions';
import { IOprationalActions, ISessionstate } from '../../../../models/utilitiesModel';

const ScannerView: React.FC = () => {
    const { t } = useTranslation("translations");
    const context: any = useContext(ParentContext);
    const dispatch = useDispatch();

    const branchesData: IBranch[] = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData)
            return (state.branchAndRoomReducer as IBranchRoomModel).branchData;
        else return undefined;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    // const themesData: ITheme[] = useSelector(state => {
    //     if (state.scannerReducer && state.scannerReducer.themesData)
    //         return (state.scannerReducer as IScannerModel).themesData;
    //     else return [];
    // });
    const scannerActionData: IScanner = useSelector(state => {
        if (state.scannerReducer && state.scannerReducer.actionData)
            return (state.scannerReducer as IScannerModel).actionData;
        else return undefined;
    });
    const getBranchName = (branchId) => {
        let branch = branchesData.find(x => x.branchId === branchId);
        return branch ? branch.branchNameEn : t('Scanner.none');
    }

    const editScanner = () => {
        dispatch(suspendOrEditScannerAction(IOprationalActions.EDIT));
    }
    const deleteScanner = () => {
        let message = t('Scanner.confirmMessages.SCC2').replace('{scannerName}', scannerActionData.scannerName);
        console.log("deleteScanner =>", IOprationalActions.DELETE, scannerActionData.scannerId, message, false);
        dispatch(deleteScannerRequest(IOprationalActions.DELETE, scannerActionData.scannerId, message, false));
    }
    return (<>
        {scannerActionData && <Card>
            <CardBody>
                <Row>
                    <Col sm="12">
                        <Row className="FormStyle view">
                            <Col>
                                <Label>{t('Scanner.scannerName')}</Label>
                                <br />
                                <span>{scannerActionData.scannerName}</span>
                            </Col>
                            <Col>
                                <Label>{t('Scanner.scannerIp')}</Label><br />
                                <span>{scannerActionData.scannerIp}</span>
                            </Col>
                            {/* <Col>
                                <Label>{t('Scanner.selectTheme')}</Label><br />
                                <span>{themesData && themesData.find(x => x.themeId === scannerActionData.themeId)?.themeName}</span>
                            </Col> */}
                            <Col>
                                <Label>{t('Scanner.branch')}</Label><br />
                                <span>{branchesData && getBranchName(scannerActionData.branch)}</span>
                            </Col>
                        </Row>
                    </Col>
                </Row>

                <hr />

                <div className="align-right action">
                    {context.edit && selectedLocationStatus && <>
                        <i id="edit" className="ti-pencil-alt" onClick={editScanner}></i>
                        <UncontrolledTooltip color="primary" placement="top" target="edit">
                            {t('ActionNames.edit')}
                        </UncontrolledTooltip>
                    </>}

                    {context.delete && selectedLocationStatus && <>
                        <i id="delete" className="ti-trash" onClick={deleteScanner}></i>
                        <UncontrolledTooltip color="primary" placement="top" target="delete">
                            {t('ActionNames.delete')}
                        </UncontrolledTooltip>
                    </>}
                </div>
            </CardBody>
        </Card>}
    </>)
}
export default React.memo(ScannerView);