import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, Card, CardBody, FormGroup, Label } from 'reactstrap';
import '../../Container/devices.css';
import { useTranslation } from 'react-i18next';
import { IScanner, IScannerModel } from '../../../../models/scannerModel';
import { IBranch, IBranchRoomModel } from '../../../../models/branchRoomModel';
import { suspendOrEditScannerAction, createAndUpdateScannerRequest } from '../../../../store/actions';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { controleContentValidate, customContentValidation, MySelect } from '../../../../helpers/helpersIndex';
import * as _ from 'lodash';

export interface optionsData {
    value: any;
    label: any;
}

const ScannerAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const scannerActionData: IScanner = useSelector(state => {
        if ((state.scannerReducer && state.scannerReducer.actionData))
            return (state.scannerReducer as IScannerModel).actionData;
        else
            return undefined;
    });
    const actionType = useSelector(state => {
        if ((state.scannerReducer && state.scannerReducer.actionType))
            return (state.scannerReducer as IScannerModel).actionType;
        else
            return undefined;
    });

    // const themesData: ITheme[] = useSelector(state => {
    //     if ((state.scannerReducer && state.scannerReducer.themesData))
    //         return (state.scannerReducer as IScannerModel).themesData;
    //     else
    //         return [];
    // });
    const branchData: IBranch[] = useSelector(state => {
        if ((state.branchAndRoomReducer && state.branchAndRoomReducer.branchData))
            return (state.branchAndRoomReducer as IBranchRoomModel).branchData;
        else
            return [];
    });
    const branchesMapData = _.orderBy(branchData, ['branchNameEn'], ['asc']).map(item => ({ value: item.branchId, label: item.branchNameEn }));
    const selectedBranch = (e, setFieldValue) => {
        setFieldValue('branches', e);
    };
    // const themsSelection = (e, setFieldValue) => {
    //     setFieldValue('themes', e);
    // };

    // const patchTheme = (themId) => {
    //     let index = themesData.findIndex(x => x.themeId === themId);
    //     return index !== -1 ? { value: themesData[index].themeId, label: themesData[index].themeName } : '';
    // };
    const patchBranch = (branchId) => {
        let index = branchData.findIndex(x => x.branchId === branchId);
        return index !== -1 ? { value: branchData[index].branchId, label: branchData[index].branchNameEn } : '';
    };

    const cancelEditFunction = () => {
        dispatch(suspendOrEditScannerAction(actionType === IOprationalActions.EDIT ? IOprationalActions.SELECT : 0));
    }

    return (<>
        <Formik
            enableReinitialize
            initialValues={{
                scannerId: scannerActionData ? scannerActionData.scannerId : 0,
                scannerName: scannerActionData ? scannerActionData.scannerName : '',
                scannerIp: scannerActionData ? scannerActionData.scannerIp : '',
                themes: 0,
                branches: scannerActionData ? patchBranch(scannerActionData.branch) : branchesMapData.length === 1 ? {
                    value: branchesMapData[0].value,
                    label: branchesMapData[0].label
                } : ''
            }}
            validationSchema={Yup.object().shape({
                scannerName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspacesp', spacialChar: '_-' }, 50, 2),
                scannerIp: controleContentValidate(t('controleErrors.required'), { value: 5, message: t('controleErrors.min').replace('{min}', '5') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, { patternType: 'ipPattern', message: t('controleErrors.ipPatternInvalid') }),
                themes: controleContentValidate(t('controleErrors.required')).nullable(),
                branches: controleContentValidate(t('controleErrors.required')).nullable(),
            })}
            onSubmit={(values) => {
                console.log("onSubmit_Values =>", values);
                // let themeId = values.themes as optionsData;
                let branchId = values.branches as optionsData;

                let scanner = {
                    scannerId: values.scannerId,
                    scannerName: values.scannerName,
                    scannerIp: values.scannerIp,
                    themeId: values.themes,
                    branch: branchId.value
                }
                dispatch(createAndUpdateScannerRequest(scanner));
            }}
        >
            {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                <Form>
                    <Card>
                        <CardBody>
                            <Row>
                                <Col sm="12">
                                    <Row>
                                        <Col className="FormStyle">
                                            <FormGroup>
                                                <Field name="scannerName" placeholder={t('Scanner.scannerName')}
                                                    className={'form-control ' + (errors.scannerName && touched.scannerName ? 'is-invalid' : '')} />
                                                <ErrorMessage name="scannerName" component="div" className="invalid-feedback" />
                                                <Label className="label" htmlFor="example-text-input">{t('Scanner.scannerName')}</Label>
                                            </FormGroup>
                                        </Col>
                                        <Col className="FormStyle">
                                            <FormGroup>
                                                <Field name="scannerIp" placeholder={t('Scanner.scannerIp')}
                                                    className={'form-control ' + (errors.scannerIp && touched.scannerIp ? 'is-invalid' : '')} />
                                                <ErrorMessage name="scannerIp" component="div" className="invalid-feedback" />
                                                <Label className="label" htmlFor="example-text-input">{t('Scanner.scannerIp')}</Label>
                                            </FormGroup>
                                        </Col>
                                        {/* <Col sm="4">
                                            <FormGroup>
                                                <Label>{t('Scanner.selectTheme')}</Label>
                                                <Select
                                                    name="themes"
                                                    placeholder={t('Scanner.selectTheme')}
                                                    value={values.themes}
                                                    onChange={(e) => themsSelection(e, setFieldValue)}
                                                    options={themesData.map(item => ({ value: item.themeId, label: item.themeName }))}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    onBlur={() => setFieldTouched('themes', true)}
                                                />
                                                {errors.themes && touched.themes && (
                                                    <div style={{ color: "red", marginTop: ".5rem" }}>{errors.themes}
                                                    </div>
                                                )}
                                            </FormGroup>
                                        </Col> */}
                                    </Row>
                                    <hr />
                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label>{t('Scanner.branch')}</Label>
                                                <MySelect
                                                    name="branches"
                                                    placeholder={t('Scanner.branch')}
                                                    value={values.branches}
                                                    onChange={(e) => selectedBranch(e, setFieldValue)}
                                                    options={branchesMapData}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    onBlur={() => setFieldTouched('branches', true)}
                                                    noOptionsMessage={() => t('Scanner.noBranches')}
                                                />
                                                {errors.branches && touched.branches && (
                                                    <div style={{ color: "red", marginTop: ".5rem" }}>{errors.branches}
                                                    </div>
                                                )}

                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </Col>
                            </Row>

                            <hr />

                            <div className="align-right action">
                                <button type="submit" disabled={!(dirty)} className="btn btn-primary ml-2">
                                    {actionType === IOprationalActions.ADD ? t('ActionNames.save') : t('ActionNames.update')}
                                </button>
                                <button className="btn btn-cancel ml-3" onClick={cancelEditFunction}>{t('ActionNames.cancel')}</button>
                            </div>
                        </CardBody>
                    </Card>
                </Form>
            )}
        </Formik>
    </>)
}
export default React.memo(ScannerAction);