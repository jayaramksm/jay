import React from 'react';
import '../../Container/devices.css';
import { LocationSelectArea } from '../../../../pages/Utilities/LocationSelectArea';
import { changeLocationForScanner } from '../../../../store/actions';

const LocationSelectionByScanner: React.FC = () => {
  
    return (<>
     <LocationSelectArea locationCallBack={changeLocationForScanner} />
    </>)
}
export default React.memo(LocationSelectionByScanner);