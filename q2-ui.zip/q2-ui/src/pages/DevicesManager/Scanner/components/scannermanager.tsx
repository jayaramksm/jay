import React, { useContext, useState } from 'react';
import { Col, Row, } from 'reactstrap';
import '../../Container/devices.css';
import { useSelector } from 'react-redux';
import { ParentContext, ChildContext } from '../Container/scannercontextApi';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../../helpers/helpersIndex';
import { IScannerModel, IScanner } from '../../../../models/scannerModel';
import { PaginationComponent } from '../../../../pages/Utilities/PaginationComponent';

const ScannerManager: React.FC = () => {
    let searchBranchId = 0;
    const context = useContext<any>(ParentContext);
    const { t } = useTranslation("translations");
    const pageSize = getEnvironment.listPageSize;
    const searchKey = useSelector(state => {
        if (state && state.scannerReducer)
            return (state.scannerReducer as IScannerModel).searchKey ? (state.scannerReducer as IScannerModel).searchKey : '';
        else return '';
    });
    searchBranchId = useSelector(state => {
        if (state && state.scannerReducer)
            return (state.scannerReducer as IScannerModel).searchBranch ? (state.scannerReducer as IScannerModel).searchBranch : 0;
        else return '';
    });


    const scannerTData: IScanner[] = useSelector(state => {
        if (state && state.scannerReducer && state.scannerReducer.scannerData) {
            let data = (state.scannerReducer as IScannerModel).scannerData;
            return data;
        }
        else return undefined;
    });


    const scannerData: IScanner[] = (scannerTData && (searchKey !== '' || searchBranchId !== 0)) ?
        scannerTData.filter((x: IScanner) =>
            (searchKey !== '' ? x.scannerName.toLowerCase().startsWith(searchKey.toLowerCase()) : true) &&
            (searchBranchId !== 0 ? x.branch === searchBranchId : true)
        ) : scannerTData;



    let scannerCount = useSelector(state => {
        if (state && state.scannerReducer && state.scannerReducer.scannerData)
            return (state.scannerReducer).scannerData.length;
        else return 0;
    });
    console.log("scannerCount", scannerCount);

    let pagesCount = Math.ceil((scannerData ? scannerData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }
    return (<>

        {scannerData && scannerData.length === 0 && searchKey !== '' && <span className="recdnotfound">{t('Scanner.noResFound')}</span>}
        {scannerData && scannerData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('Scanner.noScannerFound')}</span>}
        <div className="flexLayout">
            <div className="flexLayout-inner layou1rgtColmn">
                <Row>
                    <Col sm="12" className="actn-list">
                        {scannerData && scannerData.length > 0 && scannerData.slice(currentPage * pageSize,
                            (currentPage + 1) * pageSize).map((item, index) => (
                                <ChildContext.Provider key={item.scannerId} value={item.scannerId}>
                                    <context.viewComponent />
                                </ChildContext.Provider>
                            ))}
                    </Col>
                </Row>
            </div>
            <Row className="lft-pagination">
                {scannerData && scannerData.length > pageSize &&
                    <div className="pagination ml-4">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                }
            </Row>
        </div>
    </>)
}
export default React.memo(ScannerManager);