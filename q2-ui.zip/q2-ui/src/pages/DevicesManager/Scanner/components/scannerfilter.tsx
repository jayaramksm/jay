import React, { useContext } from 'react';
import { Col, Row, UncontrolledTooltip } from 'reactstrap';
import '../../Container/devices.css';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { IScannerModel } from '../../../../models/scannerModel';
import { IOprationalActions, ISessionstate } from '../../../../models/utilitiesModel';
import { setScannerSearchKey, setScannerActionRequestData } from '../../../../store/actions';
import { IBranch, IBranchRoomModel } from '../../../../models/branchRoomModel';
import { MySelect } from '../../../../helpers/helpersIndex';
import { ParentContext } from '../Container/scannercontextApi';
import * as _ from 'lodash';

const ScannerFilter: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);

    const isAddAction = useSelector(state => {
        if (state && state.scannerReducer)
            return (state.scannerReducer as IScannerModel).actionType === IOprationalActions.ADD;
        else return false;
    });
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const filterActions = useSelector(state => {
        if (state && state.scannerReducer && state.scannerReducer.scannerData)
            return (state.scannerReducer as IScannerModel).scannerData.length > 0;
        else return false;
    });
    const branchData: IBranch[] = useSelector(state => {
        if ((state.branchAndRoomReducer && state.branchAndRoomReducer.branchData))
            return (state.branchAndRoomReducer as IBranchRoomModel).branchData;
        else
            return []
    });
    let branchesMapData = _.orderBy(branchData, ['branchNameEn'], ['asc']).map(x => ({ value: x.branchId, label: x.branchNameEn }));
    branchesMapData = [{ value: 0, label: '--Select Department--' }, ...(branchesMapData ? branchesMapData : [])];
    const addScanner = () => {
        if (!isAddAction)
            dispatch(setScannerActionRequestData(IOprationalActions.ADD, null, false));
    }
    const setSearch = (key) => {
        console.log("setSearch =>", key);
        dispatch(setScannerSearchKey(key, 1));
    }
    const onBranchSelection = (value) => {
        dispatch(setScannerSearchKey(value.value, 2));
    }

    return (<>
        <Row className="roleslist">
            <Col className="pr-0">
                <h6 className="m-0">{t('Scanner.listOfScanner')}</h6>
            </Col>
            {context.actions.add && selectedLocationStatus && <div className="align-right pl-2 pr-3 addupload">
                <button className="btn btn-out-dashed" id="add" disabled={isAddAction} onClick={addScanner}> {t('Scanner.add')} &nbsp; <span className="addbtn">+</span></button>
                {!isAddAction &&
                    <UncontrolledTooltip color="primary" placement="right" target="add">
                        {t('Scanner.addScanner')}
                    </UncontrolledTooltip>
                }
            </div>}
        </Row>
        {filterActions && <div className="app-search w-100 p-0 form-group mb-0 mt-3">
            <input type="text" className="form-control w-100" onChange={e => setSearch(e.target.value)} placeholder={t('ActionNames.search')} />
            <i className="fa fa-search"></i>
        </div>}
        {filterActions && branchesMapData?.length > 2 && <Row>
            <Col sm="12" className="mt-1">
                <MySelect
                    placeholder={t('Scanner.branch')}
                    onChange={(e) => onBranchSelection(e)}
                    options={branchesMapData}
                    getOptionLabel={option => option.label}
                    getOptionValue={option => option.value}
                    noOptionsMessage={() => t('Scanner.noBranches')}
                />
            </Col>

            {/* <Col sm="2" className="pl-2 filtericon">
                <UncontrolledDropdown>
                    <DropdownToggle id="Filter">
                        <img src={filter} alt="" />
                    </DropdownToggle>
                    <DropdownMenu>
                        <DropdownItem>All</DropdownItem>
                        <DropdownItem>Active</DropdownItem>
                        <DropdownItem>InActive</DropdownItem>
                    </DropdownMenu>
                </UncontrolledDropdown>
                <UncontrolledTooltip color="primary" placement="top" target="Filter">
                    Filter
                                                </UncontrolledTooltip>
            </Col> */}
        </Row>}
    </>)
}
export default React.memo(ScannerFilter);