import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/scannercontextApi';
import { useSelector } from 'react-redux';
import { IOprationalActions } from '../../../../models/utilitiesModel';
import '../../Container/devices.css';

const RightParentScanner: React.FC = () => {
    const context = useContext(SuperParentContext);
    const actionArea = useSelector(state => {
        if (state && state.scannerReducer)
            return state.scannerReducer.actionType;
        else return undefined;
    });
    return (<>


        <div className="flexLayout-inner">
                <div className="pl-3 pr-3">

                    {(actionArea === IOprationalActions.ADD || actionArea === IOprationalActions.EDIT) && <context.actionComponent />}
                    {actionArea === IOprationalActions.SELECT && <ParentContext.Provider value={context.actions}>
                        <context.viewComponent />
                    </ParentContext.Provider>}

                </div>
        </div>


    </>)
}
export default React.memo(RightParentScanner);