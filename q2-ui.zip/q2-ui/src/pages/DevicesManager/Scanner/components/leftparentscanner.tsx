import React, { useContext } from 'react';
import { SuperParentContext, ParentContext } from '../Container/scannercontextApi';
import { Card, CardBody} from 'reactstrap';
import '../../Container/devices.css';
const LeftParentScanner:React.FC=()=>{
    const context = useContext(SuperParentContext);
console.log("context",context);

    return( <>
    {context && context.locationView && <context.locationView />}
                             
               <Card className="lft-card flexLayout mb-0">
                <div className="flex-headerfix px-3 pt-3">
                <ParentContext.Provider value={context}>
                           <context.filterComponent />
                       </ParentContext.Provider>
                </div>
                   <CardBody>
                       <ParentContext.Provider value={{ viewComponent: context.viewComponent }}>
                           <context.listComponent />
                       </ParentContext.Provider>
                   </CardBody>
               </Card>

    </>)
}
export default React.memo(LeftParentScanner);