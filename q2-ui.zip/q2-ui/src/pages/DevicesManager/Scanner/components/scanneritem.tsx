import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../../Container/devices.css';
import { ChildContext } from '../Container/scannercontextApi';
import { IScannerModel } from '../../../../models/scannerModel';
import { suspendOrEditScannerAction, setScannerActionRequestData } from '../../../../store/actions';
import { IOprationalActions } from '../../../../models/utilitiesModel';

const ScannerItem:React.FC=()=>{
    const context: any = useContext(ChildContext);
    const dispatch = useDispatch();

    let scannerData = useSelector(state => {
        if (state && state.scannerReducer) {
            let data = (state.scannerReducer as IScannerModel).scannerData;
            let index = data.findIndex(x => x.scannerId === context);
            if (index !== -1)
                return state.scannerReducer.scannerData[index];
            else return undefined;
        }
        else return undefined;
    });

    const selectedScanner = useSelector(state => {
        if (state && state.scannerReducer) {
            return (state.scannerReducer).actionData ?
                ((state.scannerReducer as IScannerModel).actionData).scannerId === (scannerData ? scannerData.scannerId : false) : false;
        }
        else return false;
    });

    const selectScanner = () => {
        dispatch(selectedScanner ? suspendOrEditScannerAction(0) : setScannerActionRequestData(IOprationalActions.SELECT, scannerData, false));
    }
    return(<>
                <span className={'btn btn-sm ' + (selectedScanner ? 'activeList' : '')} onClick={() => selectScanner()}  >
                    {scannerData && scannerData.scannerName}
                </span>
    </>)
}
export default React.memo(ScannerItem);