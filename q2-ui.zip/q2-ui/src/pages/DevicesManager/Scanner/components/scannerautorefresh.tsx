import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import '../../Container/devices.css';
import { IScannerModel } from '../../../../models/scannerModel';
import { getScanerRequest } from '../../../../store/actions';
import { UncontrolledTooltip } from 'reactstrap';
import { useTranslation } from 'react-i18next';

const ScannerAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const refreshLoading = useSelector(state => {
        if (state && state.scannerReducer)
            return (state.scannerReducer as IScannerModel).refreshLoading
        else
            return false;
    });
    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="Stooltip" onClick={() => dispatch(getScanerRequest(true, true))}></i>
                <UncontrolledTooltip color="primary" placement="top" target="Stooltip">
                    {t('ActionNames.autoRefresh')}
                </UncontrolledTooltip> 
                </>}

                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}
export default React.memo(ScannerAutoRefresh)