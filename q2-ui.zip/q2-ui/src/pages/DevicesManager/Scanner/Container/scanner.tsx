import React, { Component } from 'react';
import { connect } from 'react-redux';
import '../../Container/devices.css';
import { SuperParentContext } from './scannercontextApi';
import { Col, Row, Container } from 'reactstrap';
import { LocationSelectionByScanner, ScannerFilter, ScannerManager, ScannerView, ScannerItem, ScannerAction, LeftParentScanner, RightParentScanner, ScannerAutoRefresh } from './scannerindex';
import { activateAuthLayout } from '../../../../store/actions'
import { IRoleDesc, IActions } from '../../../../models/utilitiesModel';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../../helpers/helpersIndex';
import { IScannerModel } from '../../../../models/scannerModel';
import { getScanerRequest, cancelPendingScannerRequests, setResetForScanner } from '../../../../store/actions'

export interface IProps {
    activateAuthLayout: any;
    scannerLoad: boolean;
    privileges: string[]
    loginUserRolecode: string;
    getScanerRequest: any;
    cancelPendingScannerRequests: any;
    setResetForScanner: any;
    add: boolean;
    edit: boolean;
    delete: boolean;
}
class Scanner extends Component<IProps, any>{
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            leftParentScanner: {
                locationView: props.loginUserRolecode === IRoleDesc.ENTERPRISEADMIN ? LocationSelectionByScanner : null,
                filterComponent: ScannerFilter,
                listComponent: ScannerManager,
                viewComponent: ScannerItem,
                actions: { add: this.props.add }
            },
            rightParentScanner: {
                viewComponent: ScannerView,
                actionComponent: ScannerAction,
                actions: { edit: this.props.edit, delete: this.props.delete }
            }
        };
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForScanner();
        if (this.props.scannerLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getScanerRequest(!this.props.scannerLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getScanerRequest(!this.props.scannerLoad, true);
    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForScanner();
        this.props.cancelPendingScannerRequests();
    }
    render() {
        return (
            <>
                {getAutoRefresing() && <ScannerAutoRefresh />}

                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftParentScanner}>
                                <LeftParentScanner />
                            </SuperParentContext.Provider>
                        </Col>

                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightParentScanner}>
                                <RightParentScanner />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>

            </>
        )
    };
}
const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'scanner', defaultPrivilages);
    if (getAutoRefresing() && state.scannerReducer && (state.scannerReducer as IScannerModel).scannerData)
        return {
            scannerLoad: ((state.scannerReducer as IScannerModel).scannerData.length > 0 ? true : false),
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
    else
        return {
            scannerLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE)
        };
}



export default connect(mapStatetoProps, { activateAuthLayout, getScanerRequest, cancelPendingScannerRequests, setResetForScanner })(Scanner);
