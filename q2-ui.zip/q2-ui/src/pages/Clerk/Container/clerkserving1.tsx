import * as React from 'react';
import { Component } from 'react';
import '../clerkserving.css';
import {
    Container, Row, Col, Modal, ModalBody, Card, CardBody, Table, FormGroup, Nav, NavItem,
    NavLink, TabPane, TabContent, Label
} from 'reactstrap';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import classnames from 'classnames';
import journey from '../../../images/journey.jpg';
import priority from '../../../images/priority.svg';
import priorityColor from '../../../images/priority-color.svg'
import PerfectScrollbar from 'react-perfect-scrollbar';
import upArrow from '../../../images/up-arrow.svg';
import upArw from '../../../images/upr.svg'
import upArr from '../../../images/uparrow2.svg';

class ClerkServing1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        this.state = {
            modal_large: false, activeTab1: '1',
        };
        this.tog_large = this.tog_large.bind(this);
        this.toggle1 = this.toggle1.bind(this);

    }
    toggle1(tab) {
        if (this.state.activeTab1 !== tab) {
            this.setState({
                activeTab1: tab
            });
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    tog_large() {
        this.setState(prevState => ({
            modal_large: !prevState.modal_large
        }));
    }
    render() {
        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout">
                        <PerfectScrollbar >
                            <div className="flexLayout-inner">
                                <Row>
                                <Col sm="3" className="pb-2">
                                    <Label>Room</Label>
                                    <select className="form-control">
                                        <option>Select</option>
                                        <option>Nurse Sation - 04</option>
                                        <option>Waiting Room - 01</option>
                                        <option>Vaitals Room - 03</option>
                                        <option>Xray Room - 02</option>
                                        <option>Doctor Room - 04</option>
                                    </select>
                                </Col>
                                <Col className="align-right">
                                <div className="btn btn-grey"> Change Workspace </div>
                                </Col>
                                </Row>
                                <Row>
                                    <Col sm="6">
                                        <div className="heading">Service Details
                                            <button className="btn ml-1">
                                                <i className='ti-angle-up'></i>
                                                {/* <i className="ti-angle-down"></i> */}
                                            </button>
                                        </div>
                                    </Col>
                                </Row>
                                <Row className="mb-3" style={{ justifyContent: "space-around" }}>
                                    <Col lg="" md="6" sm="6" xs="12">
                                        <Card className="widgets">
                                            <Row>
                                                <Col xs="6" style={{ paddingRight: 0 }}>
                                                    <h5>Total Appointments</h5>
                                                </Col>
                                                <Col xs="6" className="widget-count">
                                                    <h2> 50</h2>
                                                </Col>

                                            </Row>
                                        </Card>
                                    </Col>
                                    <Col lg="" md="6" sm="6" xs="12">
                                        <Card className="widgets">
                                            <Row>
                                                <Col xs="6" style={{ paddingRight: 0 }}>
                                                    <h5>Patients Checked-in</h5>
                                                </Col>
                                                <Col xs="6" className="widget-count">
                                                    <h2> 20</h2>
                                                </Col>

                                            </Row>
                                        </Card>
                                    </Col>
                                    <Col lg="" md="6" sm="6" xs="12">
                                        <Card className="widgets">
                                            <Row>
                                                <Col xs="6" style={{ paddingRight: 0 }}>
                                                    <h5>Patients Waiting</h5>
                                                </Col>
                                                <Col xs="6" className="widget-count">
                                                    <h2> 30</h2>
                                                </Col>

                                            </Row>
                                        </Card>
                                    </Col>
                                    <Col lg="" md="6" sm="6" xs="12">
                                        <Card className="widgets">
                                            <Row>
                                                <Col xs="6" style={{ paddingRight: 0 }}>
                                                    <h5>Average Waiting time</h5>
                                                </Col>
                                                <Col xs="6" className="widget-count">
                                                    <h2>15</h2>
                                                </Col>

                                            </Row>
                                        </Card>
                                    </Col>

                                    <Col lg="" md="6" sm="6" xs="12">
                                        <Card className="widgets">
                                            <Row>
                                                <Col xs="6" style={{ paddingRight: 0 }}>
                                                    <h5>Average Care time</h5>
                                                </Col>
                                                <Col xs="6" className="widget-count">
                                                    <h2>15</h2>
                                                </Col>

                                            </Row>
                                        </Card>
                                    </Col>
                                </Row>
                                <div className="PatientView" style={{ marginTop: "30px" }}>
                                    <Row >
                                        <Col sm="8" className="NrsLft">

                                            <Row >
                                                <Col sm="6">
                                                    <h6 className="heading">Patient in Queue</h6>
                                                </Col>

                                                <Col sm="6" className="Qpgnation">
                                                    <button type="button" className="btn btn-sm "><i className="ti-angle-left"></i>Back</button> | <button type="button" className="btn btn-sm ">Next<i className="ti-angle-right"></i></button>
                                                </Col>
                                            </Row>

                                            <Card>
                                                <CardBody>

                                                    <div className="ToknRecordTbl border-0">
                                                        <Table responsive >
                                                            <tbody>
                                                                <tr>
                                                                    <td className="font-weight-bold">John wayne</td>
                                                                    <td>SD-412</td>
                                                                    <td>11:04 | 31 Jan</td>
                                                                    <td>11:30</td>
                                                                    <td>2hrs</td>
                                                                    <td>Simons</td>
                                                                    <td>Completed</td>

                                                                </tr>
                                                                <tr className="textLignt">
                                                                    <td>MRN - 963254</td>
                                                                    <td>Token</td>
                                                                    <td>Appointment time</td>
                                                                    <td>Check-in  time</td>
                                                                    <td>Waiting time</td>
                                                                    <td>Doctor name</td>
                                                                    <td>Vitals</td>

                                                                </tr>
                                                            </tbody>
                                                        </Table>
                                                    </div>



                                                    <hr />

                                                    <div className="QueActns">

                                                        <Row>
                                                            <Col sm="10">
                                                                <Row>
                                                                    <Col sm="4">
                                                                        <FormGroup className="mb-0">
                                                                            <Label>Room</Label>
                                                                            <select className="form-control">
                                                                                <option>Select</option>
                                                                                <option>Nurse Sation - 04</option>
                                                                                <option>Waiting Room - 01</option>
                                                                                <option>Vaitals Room - 03</option>
                                                                                <option>Xray Room - 02</option>
                                                                                <option>Doctor Room - 04</option>
                                                                            </select>
                                                                        </FormGroup>
                                                                    </Col>
                                                                    <Col sm="8" className="mrg-btm pl-0">
                                                                        <span className="nrsActn"><button type="button" className="btn btn-sm  btn-success">Serve</button></span>
                                                                        <span className="nrsActn"><button type="button" className="btn btn-sm  btn-outline-danger">End</button></span>
                                                                        <span className="nrsActn"><button type="button" className="btn btn-sm  btn-outline-danger">No Show</button></span>
                                                                    </Col>
                                                                </Row>
                                                            </Col>
                                                            <Col className="align-right priority">
                                                                <img src={priority} alt="" />
                                                                <img src={priorityColor} alt="" />
                                                            </Col>
                                                        </Row>


                                                    </div>

                                                </CardBody>
                                            </Card>

                                            <Card>
                                                <CardBody>
                                                    <h4 className="mt-0 mb-3">Patient journey</h4>
                                                    <img src={journey} className="img-fluid" alt="" />
                                                </CardBody>
                                            </Card>

                                        </Col>

                                        <Col sm="4" className="NrsRgt">


                                            <Nav className="nav-tabs-custom">
                                                <NavItem>
                                                    <NavLink className={classnames({ active: this.state.activeTab1 === '1' })}
                                                        onClick={() => { this.toggle1('1'); }}>
                                                        <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                                                        <span className="d-none d-sm-block">Currently serving</span>
                                                    </NavLink>
                                                </NavItem>
                                                <NavItem>
                                                    <NavLink className={classnames({ active: this.state.activeTab1 === '2' })}
                                                        onClick={() => { this.toggle1('2'); }}>
                                                        <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                                                        <span className="d-none d-sm-block">Waiting queue</span>
                                                    </NavLink>
                                                </NavItem>
                                            </Nav>

                                            <Card>
                                                <CardBody>

                                                    <TabContent activeTab={this.state.activeTab1}>
                                                        <TabPane tabId="1">

                                                            <div className="ToknRecordTbl active">
                                                                <Table responsive >
                                                                    <tbody>
                                                                        <tr>
                                                                            <td className="font-weight-bold">John wayne</td>
                                                                            <td>SD-412</td>
                                                                            <td>Simons</td>
                                                                            <td>1D</td>
                                                                        </tr>
                                                                        <tr className="textLignt">
                                                                            <td>MRN - 963254</td>
                                                                            <td>Token</td>
                                                                            <td>Doctor name</td>
                                                                            <td>Room detail</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </Table>
                                                            </div>

                                                            <div className="ToknRecordTbl">
                                                                <Table responsive >
                                                                    <tbody>
                                                                        <tr>
                                                                            <td className="font-weight-bold">Al mualim</td>
                                                                            <td>SD-412</td>
                                                                            <td>Simons</td>
                                                                            <td>1D</td>
                                                                        </tr>
                                                                        <tr className="textLignt">
                                                                            <td>MRN - 963254</td>
                                                                            <td>Token</td>
                                                                            <td>Doctor name</td>
                                                                            <td>Room detail</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </Table>
                                                            </div>
                                                            <div className="ToknRecordTbl">
                                                                <Table responsive >
                                                                    <tbody>
                                                                        <tr>
                                                                            <td className="font-weight-bold">Al mualim</td>
                                                                            <td>SD-412</td>
                                                                            <td>Simons</td>
                                                                            <td>1D</td>
                                                                        </tr>
                                                                        <tr className="textLignt">
                                                                            <td>MRN - 963254</td>
                                                                            <td>Token</td>
                                                                            <td>Doctor name</td>
                                                                            <td>Room detail</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </Table>
                                                            </div> <div className="ToknRecordTbl">
                                                                <Table responsive >
                                                                    <tbody>
                                                                        <tr>
                                                                            <td className="font-weight-bold">Al mualim</td>
                                                                            <td>SD-412</td>
                                                                            <td>Simons</td>
                                                                            <td>1D</td>
                                                                        </tr>
                                                                        <tr className="textLignt">
                                                                            <td>MRN - 963254</td>
                                                                            <td>Token</td>
                                                                            <td>Doctor name</td>
                                                                            <td>Room detail</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </Table>
                                                            </div>

                                                           

                                                                                                                       
                                                        </TabPane>
                                                        <TabPane tabId="2">
                                                            <div className="ToknRecordTbl">
                                                                <Table responsive >
                                                                    <tbody>
                                                                        <tr>
                                                                            <td className="font-weight-bold">Al mualim</td>
                                                                            <td>SD-412</td>
                                                                            <td>Simons</td>
                                                                            <td>1D</td>
                                                                        </tr>
                                                                        <tr className="textLignt">
                                                                            <td>MRN - 963254</td>
                                                                            <td>Token</td>
                                                                            <td>Doctor name</td>
                                                                            <td>Room detail</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </Table>
                                                            </div>
                                                        </TabPane>
                                                    </TabContent>



                                                </CardBody>
                                            </Card>
                                        </Col>

                                    </Row>
                                </div>
                                {/* <div className="ListView ">
                                    <Row >
                                        <Col lg="12">

                                            <h6 className="heading">Patient details</h6>
                                            <div className="tblAcord table-rep-plugin">
                                                <Table responsive borderless hover className="mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th>Priority</th>
                                                            <th>Token / MRN</th>
                                                            <th>Patient</th>
                                                            <th>Family MRN</th>
                                                            <th>Token issue time</th>
                                                            <th>Waiting</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <tr>
                                                            <td><img src={upArw} alt=""/></td>
                                                            <td>SDF4 / 963254</td>
                                                            <td>Margarat alba </td>
                                                            <td>963250</td>
                                                            <td>20-05-2019</td>
                                                            <td>12:02 (hh:mm)</td>
                                                            <td>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-success">Serve</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-info">Comment</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-primary">Transfer</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-info">Return</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-warning">Recall</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-danger">End</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-danger">No Show</button></span>
                                                            </td>
                                                        </tr>




                                                        <tr >
                                                            <td>--</td>
                                                            <td>SDF4 / 963254</td>
                                                            <td>Margarat alba </td>
                                                            <td>963250</td>
                                                            <td>20-05-2019</td>
                                                            <td>12:02 (hh:mm)</td>
                                                            <td>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-success">Serve</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-info">Comment</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-primary">Transfer</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-info">Return</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-warning">Recall</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-danger">End</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-danger">No Show</button></span>
                                                            </td>
                                                        </tr>



                                                        <tr >
                                                            <td>--</td>
                                                            <td>SDF4 / 963254</td>
                                                            <td>Margarat alba </td>
                                                            <td>963250</td>
                                                            <td>20-05-2019</td>
                                                            <td>12:02 (hh:mm)</td>
                                                            <td>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-success">Serve</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-info">Comment</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-primary">Transfer</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-info">Return</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-warning">Recall</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-danger">End</button></span>
                                                                <span className="nrsActn"><button className="btn btn-sm btn btn-outline-danger">No Show</button></span>
                                                            </td>
                                                        </tr>


                                                        <tr >
                                                            <td>--</td>
                                                            <td>SDF4 / 963254</td>
                                                            <td>Margarat alba </td>
                                                            <td>963250</td>
                                                            <td>20-05-2019</td>
                                                            <td>12:02 (hh:mm)</td>
                                                            <td>
                                                                <span className="nrsActn"><button className="btn btn-sm btn-success">Serve</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn-outline-info">Comment</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn-outline-primary">Transfer</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn-outline-info">Return</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn-outline-warning">Recall</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn-outline-danger">End</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn-outline-danger">No Show</button></span>
                                                            </td>
                                                        </tr>


                                                        <tr >
                                                            <td>--</td>
                                                            <td>SDF4 / 963254</td>
                                                            <td>Margarat alba </td>
                                                            <td>963250</td>
                                                            <td>20-05-2019</td>
                                                            <td>12:02 (hh:mm)</td>
                                                            <td>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn btn-success">Serve</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn btn-outline-info">Comment</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn btn-outline-primary">Transfer</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn btn-outline-info">Return</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn btn-outline-warning">Recall</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn btn-outline-danger">End</button></span>
                                                                <span className="nrsActn"><button type="button" className="btn btn-sm btn btn-outline-danger">No Show</button></span>
                                                            </td>
                                                        </tr>

                                                    </tbody>
                                                </Table>
                                            </div>

                                        </Col>

                                    </Row>
                                </div> */}
                                </div>
                                </PerfectScrollbar>
                                </div>
                            <Modal className="modal-lg OtrServices" isOpen={this.state.modal_large} toggle={this.tog_large} >
                                <div className="Clos">
                                    <button onClick={() => this.setState({ modal_large: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <ModalBody className="pt-0">
                                    <h6>Recently served</h6>
                                    <div className="topSubmenu mb-3">
                                        <div className="btn active btn-sm waves-effect ">Orthopedic dental</div>
                                        <div className="btn  btn-sm waves-effect">General surgery <span className="count">5</span></div>
                                        <div className="btn  btn-sm waves-effect ">MD surgery</div>
                                        <div className="btn  btn-sm waves-effect">Cardiology<span className="count">5</span></div>
                                        <div className="btn  btn-sm waves-effect">Orthopedic surgery</div>
                                    </div>
                                    <h6>Other services</h6>
                                    <div className="topSubmenu">
                                        <div className="btn  btn-sm waves-effect ">Orthopedic dental</div>
                                        <div className="btn  btn-sm waves-effect">Orthopedic surgery  <span className="count">5</span></div>
                                        <div className="btn  btn-sm waves-effect ">Orthopedic surgery</div>
                                        <div className="btn  btn-sm waves-effect">Orthopedic surgery <span className="count">3</span></div>
                                        <div className="btn  btn-sm waves-effect">Orthopedic surgery</div>
                                        <div className="btn  btn-sm waves-effect ">Orthopedic dental</div>
                                        <div className="btn  btn-sm waves-effect">Orthopedic surgery  <span className="count">5</span></div>
                                        <div className="btn  btn-sm waves-effect ">Orthopedic surgery</div>
                                        <div className="btn  btn-sm waves-effect">Orthopedic surgery <span className="count">15</span></div>
                                        <div className="btn  btn-sm waves-effect">Orthopedic surgery</div>
                                    </div>
                                </ModalBody>
                            </Modal>
                    
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, {activateAuthLayout})(ClerkServing1));
