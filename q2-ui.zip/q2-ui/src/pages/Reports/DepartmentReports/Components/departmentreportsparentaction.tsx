import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/departmentreportsindex';
import '../../Container/reports.css';


const DepartmentReportsParentAction: React.FC = () => {
    const currentDate = useSelector(state => {
        if (state.departmentReportsReducer && state.departmentReportsReducer.currentDate) {
            return true;
        }
        else return false;
    });

    const context = useContext(SuperParentContext);
    console.log("DepartmentReportsParentAction==>", currentDate, context);

    return (<>
        {currentDate && <context.departmentreportsaction />}
    </>)
}

export default React.memo(DepartmentReportsParentAction);