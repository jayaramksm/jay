import React from 'react';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import PerfectScrollbar from 'react-perfect-scrollbar';
import BootstrapTable from 'react-bootstrap-table-next';
import { useSelector } from 'react-redux';
import { IDepartmentReportsData, IDepartmentReportsModel } from '../../../../models/departmentReportsModel';

import { DownloadExcel, DownloadCsv } from '../../../../helpers/helpersIndex';
import '../../Container/reports.css';
import { useTranslation } from 'react-i18next';

const DepartmentReportsView: React.FC = () => {

    const { t } = useTranslation("translations");
    const departmentReportsData: IDepartmentReportsData[] = useSelector(state => {
        if (state.departmentReportsReducer && state.departmentReportsReducer.departmentReportsData)
            return (state.departmentReportsReducer as IDepartmentReportsModel).departmentReportsData;
        else return undefined;
    });

    const departmentReportsDataKeys = departmentReportsData?.length > 0 ? Object.keys(departmentReportsData[0]) : [];
    let columns: any[] = [];
    if (departmentReportsDataKeys)
        departmentReportsDataKeys.filter(y => y !== 'keyId').forEach(x => {
            let keyData = {
                dataField: x,
                text: t('DepartmentReports.' + x),
                sort: true
            }
            columns.push(keyData)
        })

    const options = {
        custom: true,
        totalSize: departmentReportsData.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };
    const DownloadExcelRequest = () => {
        const res = DownloadExcel(t, 'DepartmentReports.', departmentReportsData, 'departmentReports.xlsx', 'keyId')
        console.log('DownloadExcelRequest=>', res);
    }
    const DownloadCsvRequest = () => {
        const res = DownloadCsv(t, 'DepartmentReports.', departmentReportsData, 'departmentReports', 'keyId');
        console.log('DownloadCsvRequest=>', res);
    }
    const { ToggleList } = ColumnToggle;

    return (<>
        {departmentReportsData &&
            <> <PaginationProvider pagination={paginationFactory(options)}>
                {
                    ({
                        paginationProps,
                        paginationTableProps
                    }) => (
                        <ToolkitProvider keyField="keyId"
                            data={departmentReportsData}
                            columns={columns}
                            columnToggle>
                            {
                                props => (
                                    <div className="toggle-headers">
                                        {console.log("selectedcolumns", Object.values(props.baseProps.columnToggle.toggles).filter(x => x === true).length)}
                                        <ToggleList {...props.columnToggleProps} />


                                        <PerfectScrollbar>
                                            <div className={Object.values(props.baseProps.columnToggle.toggles).filter(x => x === true).length <= 7 ? 'dept-rglr' : 'dept-exp'}>

                                                <BootstrapTable
                                                    classes="expandTable buildingStatsTable"
                                                    bordered={false}
                                                    defaultSortDirection="asc"
                                                    {...paginationTableProps}
                                                    {...props.baseProps}

                                                />
                                            </div>
                                        </PerfectScrollbar>
                                        <div className="btn-export mt-4">
                                            <button className="btn mr-3" type="button" onClick={() => DownloadExcelRequest()}>{t('DepartmentReports.exportExcel')}</button>
                                            <button className="btn" type="button" onClick={() => DownloadCsvRequest()}>{t('DepartmentReports.exportToCsv')}</button>
                                            {options.totalSize > options.sizePerPage && <PaginationListStandalone
                                                {...paginationProps}
                                            />
                                            }
                                        </div>
                                    </div>
                                )}
                        </ToolkitProvider>
                    )
                }
            </PaginationProvider>
            </>
        }
    </>

    );
}
export default React.memo(DepartmentReportsView);