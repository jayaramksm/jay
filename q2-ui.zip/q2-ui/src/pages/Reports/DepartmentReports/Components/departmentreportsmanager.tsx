import { IDepartmentReportsModel } from '../../../../models/departmentReportsModel';
import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/departmentreportsindex';
import '../../Container/reports.css';
import { useTranslation } from 'react-i18next';

const DepartmentReportsManager: React.FC = () => {
    const { t } = useTranslation("translations");
    const context = useContext(SuperParentContext);
    console.log("context=>", context);
    const departmentReportsDataCount = useSelector(state => {
        if (state.departmentReportsReducer && state.departmentReportsReducer.departmentReportsData)
            return (state.departmentReportsReducer as IDepartmentReportsModel).departmentReportsData.length;
        else return undefined;
    });
    return (<>
        {departmentReportsDataCount > 0 && <context.departmentreportsview />}
        {departmentReportsDataCount === 0 && <div className="recdnotfound">{t('DepartmentReports.noRecordsFound')}</div>}
    </>

    );
}
export default React.memo(DepartmentReportsManager);