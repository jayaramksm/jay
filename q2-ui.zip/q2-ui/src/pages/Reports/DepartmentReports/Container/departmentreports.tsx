import * as React from 'react';
import { Container } from 'reactstrap';
import { connect } from 'react-redux';
import { DepartmentReportsAction, DepartmentReportsParentAction, DepartmentReportsView, DepartmentReportsManager } from './departmentreportscontextApi';
import { SuperParentContext } from './departmentreportsindex';
// import { Scrollbars } from 'react-custom-scrollbars';
import { activateAuthLayout, cancelAllPendingDepartmentReportsRequests, getCurrentDateDPRequest } from '../../.././../store/actions';
import '../../Container/reports.css';

export interface IProps {
    activateAuthLayout: any;
    cancelAllPendingDepartmentReportsRequests: any;
    getCurrentDateDPRequest: any;
}
class DepartmentReports extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            departmentreportsaction: DepartmentReportsAction,
            departmentreportsview: DepartmentReportsView
        };
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getCurrentDateDPRequest();
    }

    componentWillUnmount() {
        this.props.cancelAllPendingDepartmentReportsRequests();
    }

    render() {
        return (<>
            <Container fluid className="h-100">
                <div className="flexLayout reportsscroll">
                    <div className="flexLayout-inner">
                        <div className="reports mt-2">
                            <SuperParentContext.Provider value={{ departmentreportsaction: this.state.departmentreportsaction }} >
                                <DepartmentReportsParentAction />
                            </SuperParentContext.Provider>
                            <SuperParentContext.Provider value={{ departmentreportsview: this.state.departmentreportsview }} >
                                <DepartmentReportsManager />
                            </SuperParentContext.Provider>
                        </div>
                    </div>
                </div>
            </Container>
        </>
        );
    }
}


export default connect(null, { activateAuthLayout, getCurrentDateDPRequest, cancelAllPendingDepartmentReportsRequests })(DepartmentReports);