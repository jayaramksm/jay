export { default as DepartmentReportsAction } from '../Components/departmentreportsaction';
export { default as DepartmentReportsManager } from '../Components/departmentreportsmanager';
export { default as DepartmentReportsView } from '../Components/departmentreportsview';
export { default as DepartmentReportsParentAction } from '../Components/departmentreportsparentaction';