import * as React from 'react';
import { Container } from 'reactstrap';
import { connect } from 'react-redux';
import { ServiceReportsAction, ServiceReportsParentAction, ServiceReportsView, ServiceReportsManager } from './servicereportscontextApi';
import { SuperParentContext } from './servicereportsindex';
// import { Scrollbars } from 'react-custom-scrollbars';
import { activateAuthLayout, cancelAllPendingServiceReportsRequests, getCurrentDateandServicesDataRequest } from '../../.././../store/actions';
import '../../Container/reports.css';

export interface IProps {
    activateAuthLayout: any;
    cancelAllPendingServiceReportsRequests: any;
    getCurrentDateandServicesDataRequest: any;
}
class ServiceReports extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            servicereportsaction: ServiceReportsAction,
            servicereportsview: ServiceReportsView
        };
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getCurrentDateandServicesDataRequest();

    }

    componentWillUnmount() {
        this.props.cancelAllPendingServiceReportsRequests();
    }

    render() {
        return (<>
            <Container fluid className="h-100">
                <div className="flexLayout reportsscroll">
                    <div className="flexLayout-inner">
                        <div className="reports mt-2">
                            <SuperParentContext.Provider value={{ servicereportsaction: this.state.servicereportsaction }} >

                                <ServiceReportsParentAction />
                            </SuperParentContext.Provider>
                            <SuperParentContext.Provider value={{ servicereportsview: this.state.servicereportsview }} >
                                <ServiceReportsManager />
                            </SuperParentContext.Provider>
                        </div>
                    </div>
                </div>
            </Container>
        </>
        );
    }
}


export default connect(null, { activateAuthLayout, getCurrentDateandServicesDataRequest, cancelAllPendingServiceReportsRequests })(ServiceReports);