export { default as ServiceReportsAction } from '../Components/servicereportsaction';
export { default as ServiceReportsManager } from '../Components/servicereportsmanager';
export { default as ServiceReportsView } from '../Components/servicereportsview';
export { default as ServiceReportsParentAction } from '../Components/servicereportsparentaction';