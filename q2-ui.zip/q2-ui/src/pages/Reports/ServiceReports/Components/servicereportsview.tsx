import React from 'react';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import PerfectScrollbar from 'react-perfect-scrollbar';
import BootstrapTable from 'react-bootstrap-table-next';
import { useSelector } from 'react-redux';
import { IServiceReportsModel } from '../../../../models/serviceReportsModel';
import '../../Container/reports.css';
import { useTranslation } from 'react-i18next';
// import * as _ from 'lodash';
import { DownloadCsv, DownloadExcel } from './../../../../helpers/helpersIndex';

const ServiceReportsView: React.FC = () => {
    const { t } = useTranslation("translations");
    // const dispatch = useDispatch();
    const serviceReportsData = useSelector(state => {
        if (state.serviceReportsReducer && state.serviceReportsReducer.serviceReportsData)
            return (state.serviceReportsReducer as IServiceReportsModel).serviceReportsData;
        else return undefined;
    });
    const serviceReportsDataKeys = serviceReportsData?.length > 0 ? Object.keys(serviceReportsData[0]) : [];
    let columns: any[] = [];
    if (serviceReportsDataKeys)
        serviceReportsDataKeys.filter(y => y !== 'keyId').forEach(x => {
            let keyData = {
                dataField: x,
                text: t('ServiceReports.' + x),
                sort: true
            }
            columns.push(keyData)
        })


    const options = {
        custom: true,
        totalSize: serviceReportsData.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    const { ToggleList } = ColumnToggle;
    const DownloadExcelRequest = () => {
        const res = DownloadExcel(t, 'ServiceReports.', serviceReportsData, 'serviceReports.xlsx', 'keyId')
        console.log('DownloadExcelRequest=>', res);
    }

    const DownloadCsvRequest = () => {

        const res = DownloadCsv(t, 'ServiceReports.', serviceReportsData, 'serviceReports', 'keyId');
        console.log('DownloadCsvRequest=>', res);
    }
    return (<>
        {serviceReportsData &&
            <> <PaginationProvider pagination={paginationFactory(options)}>
                {
                    ({
                        paginationProps,
                        paginationTableProps
                    }) => (
                        <ToolkitProvider keyField="keyId"
                            data={serviceReportsData}
                            columns={columns}
                            columnToggle>
                            {
                                props => (
                                    <div className="toggle-headers">
                                        {console.log("selectedcolumns", Object.values(props.baseProps.columnToggle.toggles).filter(x => x === true).length)}
                                        <ToggleList {...props.columnToggleProps} />


                                        <PerfectScrollbar>
                                            <div className={Object.values(props.baseProps.columnToggle.toggles).filter(x => x === true).length <= 7 ? 'dept-rglr' : 'dept-exp'}>

                                                <BootstrapTable
                                                    classes="expandTable buildingStatsTable"
                                                    bordered={false}
                                                    defaultSortDirection="asc"
                                                    {...paginationTableProps}
                                                    {...props.baseProps}
                                                />
                                            </div>
                                        </PerfectScrollbar>
                                        <div className="btn-export mt-4">
                                            <button className="btn mr-3" type="button" onClick={() => DownloadExcelRequest()}>{t('ServiceReports.exportExcel')}</button>
                                            <button className="btn" type="button" onClick={() => DownloadCsvRequest()}>{t('ServiceReports.exportToCsv')}</button>
                                            {options.totalSize > options.sizePerPage && <PaginationListStandalone
                                                {...paginationProps}
                                            />
                                            }
                                        </div>
                                    </div>
                                )}
                        </ToolkitProvider>
                    )
                }
            </PaginationProvider>
            </>
        }
    </>

    );
}
export default React.memo(ServiceReportsView);