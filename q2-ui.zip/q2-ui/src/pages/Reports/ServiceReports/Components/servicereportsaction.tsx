import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, FormGroup, Input } from 'reactstrap';
import moment from 'moment';
import { Form, Formik } from 'formik';
import "react-datepicker/dist/react-datepicker.css";
import { useTranslation } from 'react-i18next';
import { IServiceReportsModel } from '../../../../models/serviceReportsModel';
import { getServiceReportsDataRequest } from '../../../../store/actions';
import * as Yup from 'yup';
import { controleContentValidate, MySelect } from '../../../../helpers/helpersIndex';
import '../../Container/reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';

let ranges;
let start;
let end;
let maxDate;

const ServiceReportsAction: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const currentDate = useSelector(state => {
        if (state.serviceReportsReducer && state.serviceReportsReducer.currentDate) {
            return (state.serviceReportsReducer as IServiceReportsModel).currentDate;
        }
        else return undefined;
    });
    const services = useSelector(state => {
        if (state.serviceReportsReducer && state.serviceReportsReducer.serviceData)
            return (state.serviceReportsReducer as IServiceReportsModel).serviceData;
        else return undefined;
    });

    console.log("DepartmentReports==>", currentDate);
    const applyCallback = (startdate, enddate, setFieldValue) => {
        console.log("applyCallback ... =>1", startdate, enddate);
        setFieldValue('startDate', moment(startdate._d).format('YYYY-MM-DD'));
        setFieldValue('endDate', moment(enddate._d).format('YYYY-MM-DD'));
    }
    let local = {
        "format": "YYYY-MM-DD",
        "sundayFirst": false
    }
    if (currentDate) {
        start = moment(new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()-1, 0, 0, 0, 0));
        end = moment(new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()-1, 0, 0, 0, 0));
        ranges = {
            "Last Week": [moment(start).subtract(6, "days"), moment(end)],
            "Last Month": [moment(start).subtract(30, "days"), moment(end)],
            "Last Year": [moment(start).subtract(365, "days"), moment(end)]
        }
        maxDate = moment(start).add(0, "day")
    }
    const touchedField = (setFieldTouched) => {
        setFieldTouched('startDate', true);
        setFieldTouched('endDate', true);
    }
    const serviceSelection = (e, setFieldValue) => {
        setFieldValue('serviceId', e);
    }
    const validationSchema = Yup.object().shape({
        startDate: controleContentValidate(t('controleErrors.required')),
        endDate: controleContentValidate(t('controleErrors.required')),
        serviceId: controleContentValidate(t('controleErrors.required'))
    })
    return (
        <>

            <h4>{t('ServiceReports.title')}</h4>

            <Formik
                initialValues={{
                    serviceId: '',
                    startDate: start.format('YYYY-MM-DD'),
                    endDate: end.format('YYYY-MM-DD')
                }}
                validationSchema={validationSchema}
                onSubmit={(values) => {
                    console.log("Values =>", values);
                    dispatch(getServiceReportsDataRequest(values));
                }}
            >
                {({ values, errors, touched, dirty, setFieldValue, setFieldTouched }) => (
                    <Form>
                        <Row className="reportform mb-2">
                            <Col sm="2">
                                <FormGroup>
                                    <MySelect
                                        name="serviceId"
                                        placeholder={t('ServiceReports.selectService')}
                                        value={values.serviceId}
                                        onChange={(e) => serviceSelection(e, setFieldValue)}
                                        options={services?.map(item => ({ value: item.serviceId, label: item.serviceNameEn }))}
                                        getOptionLabel={option => option.label}
                                        getOptionValue={option => option.value}
                                        onBlur={() => setFieldTouched('serviceId', true)}
                                        noOptionsMessage={() => t('ServiceReports.noServices')}
                                    />
                                    {errors.serviceId && touched.serviceId && (
                                        <div className="error-msg">{errors.serviceId}
                                        </div>
                                    )}
                                </FormGroup>
                            </Col>
                            <Col sm="3" className="w-18">
                                <FormGroup>
                                    <DateTimeRangeContainer
                                        ranges={ranges}
                                        start={start}
                                        end={end}
                                        local={local}
                                        maxDate={maxDate}
                                        smartMode
                                        applyCallback={(start, end) => applyCallback(start, end, setFieldValue)}
                                    >
                                        <Input
                                            id="formControlsTextB"
                                            type="text"
                                            label="Text"
                                            className="calendarIcon"
                                            placeholder="Enter text"
                                            value={values.startDate + ' - ' + values.endDate}
                                            onChange={applyCallback}
                                            onBlur={() => touchedField(setFieldTouched)}
                                        />
                                    </DateTimeRangeContainer>
                                    {(values.startDate === '' || values.endDate === '') && (errors.startDate && touched.startDate) && (errors.endDate && touched.endDate) && (
                                        <div className="error-msg">{errors.startDate ? errors.startDate : errors.endDate}
                                        </div>
                                    )}
                                </FormGroup>
                            </Col>
                            <div className="ml-3">
                                <button type="submit" className="btn btn-primary" >
                                    {t('ActionNames.submit')}
                                </button>
                            </div>
                        </Row>
                    </Form>
                )}
            </Formik>

        </>

    )
}
export default React.memo(ServiceReportsAction);