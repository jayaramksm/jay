import { IServiceReportsModel } from '../../../../models/serviceReportsModel';
import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/servicereportsindex';
import '../../Container/reports.css';
import { useTranslation } from 'react-i18next';

const ServiceReportsManager: React.FC = () => {

    const { t } = useTranslation("translations");
    const context = useContext(SuperParentContext);
    console.log("context=>", context);
    const serviceReportsDataCount = useSelector(state => {
        if (state.serviceReportsReducer && state.serviceReportsReducer.serviceReportsData)
            return (state.serviceReportsReducer as IServiceReportsModel).serviceReportsData.length;
        else return undefined;
    });
    console.log("ServiceReportsManagerP_serviceReportsDataCount =>", serviceReportsDataCount);


    return (<>
        {serviceReportsDataCount > 0 && <context.servicereportsview />}
        {serviceReportsDataCount === 0 && <div className="recdnotfound">{t('ServiceReports.noRecordsFound')}</div>}
    </>

    );
}
export default React.memo(ServiceReportsManager);