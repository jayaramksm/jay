import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/servicereportsindex';
import '../../Container/reports.css';


const ServiceReportsParentAction: React.FC = () => {
    const currentDate = useSelector(state => {
        if (state.serviceReportsReducer && state.serviceReportsReducer.currentDate) {
            return true;
        }
        else return false;
    });

    const context = useContext(SuperParentContext);
    console.log("currentDate==>", currentDate, context);

    return (<>
        {currentDate && <context.servicereportsaction />}
    </>)
}

export default React.memo(ServiceReportsParentAction);