import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, Input, FormGroup } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import BootstrapTable from 'react-bootstrap-table-next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import Modal from 'react-modal';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class UserReport1 extends React.Component<any, any> {

    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    toggleModal() {
        this.setState({ modalOpen: true });
    }
    rowEvents = {
        onClick: () => {
            this.toggleModal()
        }
    }

    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    dateOptions = [
        { label: "Department1", value: "Department1" },
        { label: "Department2", value: "Department2" },
        { label: "Department3", value: "Department3" },
        { label: "Department4", value: "Department4" }
    ];
    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'totalTokenserv',
        text: 'Total Tokens Served',
        sort: true
    }, {
        dataField: 'totalnoshow',
        text: 'Total No Show',
        sort: true
    }, {
        dataField: 'nojourney',
        text: 'No Journey',
        sort: true
    }, {
        dataField: 'totServTime',
        text: 'Total Serving Time',
        sort: true
    }, {
        dataField: 'avgwaitTime',
        text: 'Avg Waiting Time',
        sort: true
    }, {
        dataField: 'totalIdleTime',
        text: 'Total Idle Time',
        sort: true
    }, {
        dataField: 'totalsessionTime',
        text: 'Total Session Time',
        sort: true
    }, {
        dataField: 'avgservTime',
        text: 'Avg Serving Time',
        sort: true
    }
    ];
    userdata = [
        { date: '20-08-2020', totalTokenserv: 30, totalnoshow: 2, nojourney: 1, totServTime: '2 min', avgwaitTime: '10 min', totalIdleTime: '10 min', totalsessionTime: '10 min', avgservTime: '10 min' },
        { date: '21-08-2020', totalTokenserv: 20, totalnoshow: 5, nojourney: 4, totServTime: '10 min', avgwaitTime: '20 min', totalIdleTime: '15 min', totalsessionTime: '10 min', avgservTime: '10 min' },
        { date: '22-08-2020', totalTokenserv: 10, totalnoshow: 2, nojourney: 2, totServTime: '10 min', avgwaitTime: '10 min', totalIdleTime: '10 min', totalsessionTime: '10 min', avgservTime: '10 min' },
        { date: '25-08-2020', totalTokenserv: 20, totalnoshow: 4, nojourney: 1, totServTime: '10 min', avgwaitTime: '5 min', totalIdleTime: '21 min', totalsessionTime: '10 min', avgservTime: '10 min' }
    ]

    options = {
        custom: true,
        totalSize: this.userdata.length,
        sizePerPage: 6,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let ranges = {};
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>User Report</h4>
                                    <Row className="reportform">
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    ranges={ranges}
                                                    smartMode
                                                    applyCallback={this.applyCallback}>
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback} />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <> <PaginationProvider pagination={paginationFactory(this.options)}>
                                            {
                                                ({
                                                    paginationProps,
                                                    paginationTableProps
                                                }) => (
                                                        <ToolkitProvider keyField='date'
                                                            data={this.userdata}
                                                            columns={this.columns}
                                                            columnToggle>
                                                            {
                                                                props => (
                                                                    <div className="toggle-headers">
                                                                        <ToggleList {...props.columnToggleProps} />

                                                                        <PerfectScrollbar>
                                                                            <div className={Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'user-rglr' : 'user-exp' }>

                                                                                <BootstrapTable
                                                                                    classes="expandTable userTable"
                                                                                    bordered={false}
                                                                                    defaultSortDirection="asc"
                                                                                    {...props.baseProps}
                                                                                    rowEvents={this.rowEvents}
                                                                                    {...paginationTableProps}
                                                                                    {...props.baseProps}
                                                                                />
                                                                            </div>
                                                                        </PerfectScrollbar>
                                                                        <div className="btn-export mt-4">
                                                                            <button className="btn mr-3" type="button">Export to PDF</button>
                                                                            <button className="btn" type="button">Export to CSV</button>
                                                                            {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                {...paginationProps}
                                                                            />
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                )}
                                                        </ToolkitProvider>
                                                    )}
                                        </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                    {this.state.modalOpen && <div>
                        <Modal isOpen={this.state.modalOpen} ariaHideApp={false} className="expandModal userreports">
                            <Row>
                                <Col className="text-right">
                                    <button onClick={() => this.setState({ modalOpen: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </Col>
                            </Row>
                            <div>
                                <PerfectScrollbar style={{ maxHeight: "350px" }}>
                                    <table>
                                        <thead>
                                            <tr>
                                                <td>Department</td>
                                                <td>Service</td>
                                                <td>Total Token Served</td>
                                                <td>Total No Show</td>
                                                <td>No Journey</td>
                                                <td>Total Serving Time</td>
                                                <td>Avg Waiting Time</td>
                                                <td>Total Idle Time</td>
                                                <td>Total Session Time</td>
                                                <td>Avg Serving Time</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Cardiology</td>
                                                <td>Service1</td>
                                                <td>80</td>
                                                <td>50</td>
                                                <td>10</td>
                                                <td>10 min</td>
                                                <td>15 min</td>
                                                <td>15 min</td>
                                                <td>20 min</td>
                                                <td>18 min</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology</td>
                                                <td>Service1</td>
                                                <td>80</td>
                                                <td>50</td>
                                                <td>10</td>
                                                <td>10 min</td>
                                                <td>15 min</td>
                                                <td>15 min</td>
                                                <td>20 min</td>
                                                <td>18 min</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology</td>
                                                <td>Service1</td>
                                                <td>80</td>
                                                <td>50</td>
                                                <td>10</td>
                                                <td>10 min</td>
                                                <td>15 min</td>
                                                <td>15 min</td>
                                                <td>20 min</td>
                                                <td>18 min</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology</td>
                                                <td>Service1</td>
                                                <td>80</td>
                                                <td>50</td>
                                                <td>10</td>
                                                <td>10 min</td>
                                                <td>15 min</td>
                                                <td>15 min</td>
                                                <td>20 min</td>
                                                <td>18 min</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology</td>
                                                <td>Service1</td>
                                                <td>80</td>
                                                <td>50</td>
                                                <td>10</td>
                                                <td>10 min</td>
                                                <td>15 min</td>
                                                <td>15 min</td>
                                                <td>20 min</td>
                                                <td>18 min</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </PerfectScrollbar>
                            </div>
                        </Modal>
                    </div>}
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(UserReport1));

