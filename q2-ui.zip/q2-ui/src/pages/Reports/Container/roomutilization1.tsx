import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { MySelect } from '../../../helpers/helpersIndex';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import PerfectScrollbar from 'react-perfect-scrollbar';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class RoomUtilization1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    deptOptions = [
        { label: "Department1", value: "Department1" },
        { label: "Department2", value: "Department2" },
        { label: "Department3", value: "Department3" },
        { label: "Department4", value: "Department4" }
    ];

    columns = [{
        dataField: 'department',
        text: 'Department',
        sort: true
    }, {
        dataField: 'roomno',
        text: 'Room No',
        sort: true
    }, {
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'totalUHours',
        text: 'Total Hours Utilized',
        sort: true
    }, {
        dataField: 'pUtilized',
        text: '% Utilized',
        sort: true
    }, {
        dataField: 'totalPServed',
        text: 'Total Patients Served',
        sort: true
    }, {
        dataField: 'avgTime',
        text: 'Average Time Utilized per Patient',
        sort: true
    }, {
        dataField: 'totalIdleTime',
        text: 'Total Idle Time',
        sort: true
    }, {
        dataField: 'pIdleTime',
        text: '% Idle Time',
        sort: true
    }
    ];

    servicedata = [
        { department: 'Department One', roomno: 3, date: '21-07-2020', totalUHours: 23, pUtilized: '23 %', totalPServed: 23, avgTime: '23 min', totalIdleTime: '23 min', pIdleTime: '23 %' },
        { department: 'Department Two', roomno: 6, date: '14-04-2020', totalUHours: 14, pUtilized: '14 %', totalPServed: 14, avgTime: '14 min', totalIdleTime: '14 min', pIdleTime: '14 %' },
        { department: 'Department Three', roomno: 1, date: '15-02-2020', totalUHours: 25, pUtilized: '25 %', totalPServed: 25, avgTime: '25 min', totalIdleTime: '25 min', pIdleTime: '25 %' },
        { department: 'Department Four', roomno: 9, date: '16-07-2020', totalUHours: 13, pUtilized: '17 %', totalPServed: 17, avgTime: '17 min', totalIdleTime: '17 min', pIdleTime: '17 %' },
        { department: 'Department Five', roomno: 3, date: '28-06-2020', totalUHours: 15, pUtilized: '13 %', totalPServed: 13, avgTime: '13 min', totalIdleTime: '13 min', pIdleTime: '13 %' },
        { department: 'Department Six', roomno: 6, date: '17-06-2020', totalUHours: 9, pUtilized: '16 %', totalPServed: 16, avgTime: '16 min', totalIdleTime: '16 min', pIdleTime: '16 %' },
        { department: 'Department Seven', roomno: 3, date: '18-07-2020', totalUHours: 21, pUtilized: '21 %', totalPServed: 21, avgTime: '21 min', totalIdleTime: '21 min', pIdleTime: '21 %' }]

    options = {
        custom: true,
        totalSize: this.servicedata.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;


        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Room Utilization Report</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="department"
                                                    options={this.deptOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Department"
                                                />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    ranges = {ranges}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <Col sm="2">
                                            <button className="btn btn-submit" type="submit" onClick={() => this.showReportsData()}>
                                                Submit
                                            </button>
                                        </Col>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='date'
                                                                data={this.servicedata}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />
                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'room-rglr' : 'room-exp' }>

                                                                                    <BootstrapTable
                                                                                        classes="expandTable roomUtilization"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                    />
                                                                                </div>
                                                                            </PerfectScrollbar>
                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                    {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>

                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(RoomUtilization1));

