import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { MySelect } from '../../../helpers/internaljscontrols';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import './reports.css';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { Scrollbars } from 'react-custom-scrollbars';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class ServicePerformanceReport1 extends React.Component<any, any> {

    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    deptOptions = [
        { label: "Department1", value: "Department1" },
        { label: "Department2", value: "Department2" },
        { label: "Department3", value: "Department3" },
        { label: "Department4", value: "Department4" }
    ];
    serviceOptions = [
        { label: "Cardiology_Srv", value: "Cardiology_Srv" },
        { label: "Radiology_Srv", value: "Radiology_Srv" },
        { label: "Dental_Srv", value: "Dental_Srv" },
        { label: "Oncology_Srv", value: "Oncology_Srv" }
    ];

    columns = [{
        dataField: 'dept',
        text: 'Department',
        sort: true
    }, {
        dataField: 'service',
        text: 'Service',
        sort: true
    }, {
        dataField: 'apptboooked',
        text: 'Appointments Booked',
        sort: true
    }, {
        dataField: 'patientsarrived',
        text: 'Patients Arrived',
        sort: true
    }, {
        dataField: 'patientsarrivedearly',
        text: 'Patients Arrived Early',
        sort: true
    }, {
        dataField: 'patientsarrivedlate',
        text: 'Patients Arrived Late',
        sort: true
    }, {
        dataField: 'avgServTime',
        text: 'Avg Serving Time',
        sort: true
    }, {
        dataField: 'avgwaitTime',
        text: 'Avg Waiting Time',
        sort: true
    }, {
        dataField: 'noshow',
        text: 'No Show',
        sort: true
    }, {
        dataField: 'totalVisit',
        text: 'Total Visit',
        sort: true
    }, {
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'serviceidletime',
        text: 'Service Idle Time',
        sort: true
    }, {
        dataField: 'serviceutilization',
        text: '% Service Utilization',
        sort: true
    }
    ];
    servicedata = [
        { dept: 'Laboratory', service: 'Cardiology_Srv', apptboooked: 20, patientsarrived: 10, patientsarrivedearly: 1, patientsarrivedlate: 2, avgServTime: '10 min', avgwaitTime: '10 min', noshow: 4, totalVisit: 30, date: '10-08-2020', serviceidletime: '12 min', serviceutilization: 12 },
        { dept: 'Cardiology', service: 'Cardiology_Srv', apptboooked: 40, patientsarrived: 20, patientsarrivedearly: 2, patientsarrivedlate: 1, avgServTime: '20 min', avgwaitTime: '15 min', noshow: 1, totalVisit: 20, date: '10-08-2020', serviceidletime: '10 min', serviceutilization: 40 },
        { dept: 'Radiology', service: 'Cardiology_Srv', apptboooked: 10, patientsarrived: 5, patientsarrivedearly: 5, patientsarrivedlate: 2, avgServTime: '10 min', avgwaitTime: '10 min', noshow: 3, totalVisit: 10, date: '10-08-2020', serviceidletime: '2 min', serviceutilization: 30 },
        { dept: 'Neurology', service: 'Cardiology_Srv', apptboooked: 30, patientsarrived: 10, patientsarrivedearly: 2, patientsarrivedlate: 5, avgServTime: '5 min', avgwaitTime: '21 min', noshow: 5, totalVisit: 20, date: '10-08-2020', serviceidletime: '12 min', serviceutilization: 10 }
    ]

    options = {
        custom: true,
        totalSize: this.servicedata.length,
        sizePerPage: 6,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Service Performance</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="department"
                                                    options={this.deptOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Department"
                                                    noOptionsMessage="No Options"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="service"
                                                    options={this.serviceOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Service"
                                                    noOptionsMessage="No Options"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    ranges={ranges}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='dept'
                                                                data={this.servicedata}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />
                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'service-rglr' : 'service-exp' }>
                                                                                    <BootstrapTable
                                                                                        classes="expandTable servicePerfTable"
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                    />
                                                                                </div>
                                                                            </PerfectScrollbar>
                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                    {...paginationProps}
                                                                                />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(ServicePerformanceReport1));

