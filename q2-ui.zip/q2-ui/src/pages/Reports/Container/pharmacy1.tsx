import * as React from 'react';
import { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, FormGroup, Input, Container } from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { Scrollbars } from 'react-custom-scrollbars';
import BootstrapTable from 'react-bootstrap-table-next';
import './reports.css';
import { MySelect } from '../../../helpers/internaljscontrols';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import Modal from 'react-modal';

export interface IProps {
    activateAuthLayout: any;
}

const { ToggleList } = ColumnToggle;

class Pharmacy1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            modalOpen: false,
            start: start,
            end: end
        };
        this.applyCallback = this.applyCallback.bind(this);
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    deptOptions = [
        { label: "Department 1", value: "department1" },
        { label: "Department 2", value: "department2" },
        { label: "Department 3", value: "department3" },
        { label: "Department 4", value: "department4" }
    ];
    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'department',
        text: 'Department',
        sort: true
    }, {
        dataField: 'totalvisits',
        text: 'Total Visits',
        sort: true
    }, {
        dataField: 'totalserved',
        text: 'Total Served',
        sort: true
    },
    {
        dataField: 'totalnoshow',
        text: 'Total No Show',
        sort: true
    }, {
        dataField: 'totalnojourney',
        text: 'Total No Journey',
        sort: true
    }, {
        dataField: 'avgwaitingtime',
        text: 'Avg Waiting Time',
        sort: true
    }, {
        dataField: 'avgservingtime',
        text: 'Avg Serving Time',
        sort: true
    }
        , {
        dataField: 'totalcounters',
        text: 'Total Counters',
        sort: true
    }, {
        dataField: 'totalmanualtokens',
        text: 'Total Manual Tokens',
        sort: true
    }, {
        dataField: 'totalkiosktokens',
        text: 'Total Kiosk Tokens',
        sort: true,

    }, {
        dataField: 'delayedtokens',
        text: 'Delayed Tokens',
        sort: true
    },
    ];
    toggleModal() {
        this.setState({ modalOpen: true });
    }

    tknrepotsData = [
        { id: 1, date: '01-07-2020', department: 'Department 1', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "20 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "30" },
        { id: 2, date: '02-07-2020', department: 'Department 2', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "10 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "25" },
        { id: 3, date: '03-07-2020', department: 'Department 3', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "15 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "23" },
        { id: 4, date: '04-07-2020', department: 'Department 4', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "10 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "25" },
        { id: 5, date: '05-07-2020', department: 'Department 5', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "20 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "30" },
        { id: 6, date: '06-07-2020', department: 'Department 6', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "10 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "25" },
        { id: 7, date: '07-07-2020', department: 'Department 7', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "15 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "23" },
        { id: 8, date: '08-07-2020', department: 'Department 8', totalvisits: "100", totalserved: "60", totalnoshow: '30', totalnojourney: '10', avgwaitingtime: "10 min", avgservingtime: "20 min", totalcounters: "30", totalmanualtokens: '30', totalkiosktokens: '30', delayedtokens: "25" }
    ]

    rowEvents = {
        onClick: () => {
            this.toggleModal()
        }
    }


    options = {
        custom: true,
        totalSize: this.tknrepotsData.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };
    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Pharmacy Reports</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="department"
                                                    options={this.deptOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Department"
                                                    noOptionsMessage="No Options"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    ranges={ranges}
                                                    end={this.state.end}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='date'
                                                                data={this.tknrepotsData}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />

                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'mainTbl-rglr' : 'mainTbl-exp'}>
                                                                                    <BootstrapTable
                                                                                        classes="expandTable pharmacyTable"
                                                                                        id="pharmacyTable"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                        rowEvents={this.rowEvents}
                                                                                    />
                                                                                </div>
                                                                            </PerfectScrollbar>
                                                                            <div className="btn-export mt-2">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage &&
                                                                                    <PaginationListStandalone  {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                    {this.state.modalOpen && <div>
                        <Modal isOpen={this.state.modalOpen} ariaHideApp={false} className="expandModal feedbackexpand">
                            <Row>
                                <Col className="text-right">
                                    <button onClick={() => this.setState({ modalOpen: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </Col>
                            </Row>
                            <div>
                                <PerfectScrollbar style={{ maxHeight: "350px" }}>
                                    <table>
                                        <thead>
                                            <tr>
                                                <td>Date</td>
                                                <td>Department</td>
                                                <td>Service</td>
                                                <td>Total Visits</td><td>Total Served</td><td>Total No Show</td><td>Total No Journey</td><td>Avg Waiting Time</td><td>Avg Serving Time</td>
                                                <td>Total Counters</td><td>Total Manual Tokens</td><td>Total Kiosk Tokens</td><td>Delayed Tokens</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>01-07-2020</td>
                                                <td>Cardiology</td><td>Service2</td><td>12</td>
                                                <td>2</td><td>2</td><td>15</td>
                                                <td>15 min</td><td>4 min</td>
                                                <td>6</td><td>6</td>
                                                <td>2</td><td>4</td>
                                            </tr>
                                            <tr>
                                                <td>01-07-2020</td>
                                                <td>Cardiology</td><td>Service2</td><td>12</td>
                                                <td>2</td><td>2</td><td>15</td>
                                                <td>15 min</td><td>4 min</td>
                                                <td>6</td><td>6</td>
                                                <td>2</td><td>4</td>
                                            </tr>
                                            <tr>
                                                <td>01-07-2020</td>
                                                <td>Cardiology</td><td>Service3</td><td>12</td>
                                                <td>2</td><td>2</td><td>15</td>
                                                <td>15 min</td><td>4 min</td>
                                                <td>6</td><td>6</td>
                                                <td>2</td><td>4</td>
                                            </tr>
                                            <tr>
                                                <td>01-07-2020</td>
                                                <td>Cardiology</td><td>Service4</td><td>12</td>
                                                <td>2</td><td>2</td><td>15</td>
                                                <td>15 min</td><td>4 min</td>
                                                <td>6</td><td>6</td>
                                                <td>2</td><td>4</td>
                                            </tr>
                                            <tr>
                                                <td>01-07-2020</td>
                                                <td>Cardiology</td><td>Service5</td><td>12</td>
                                                <td>2</td><td>2</td><td>15</td>
                                                <td>15 min</td><td>4 min</td>
                                                <td>6</td><td>6</td>
                                                <td>2</td><td>4</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </PerfectScrollbar>
                            </div>
                        </Modal>
                    </div>}
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(Pharmacy1));

