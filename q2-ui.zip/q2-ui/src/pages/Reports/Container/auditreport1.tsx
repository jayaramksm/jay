import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { MySelect } from '../../../helpers/helpersIndex';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import PerfectScrollbar from 'react-perfect-scrollbar';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class RoomUtilization1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        }
        )
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }
    userOptions = [
        { label: "User1", value: "User 1" },
        { label: "User2", value: "User 2" },
        { label: "User3", value: "User 3" },
        { label: "User4", value: "User 4" }
    ];

    columns = [{
        dataField: 'uname',
        text: 'User Name',
        sort: true
    }, {
        dataField: 'ip',
        text: 'IP',
        sort: true
    }, {
        dataField: 'cdrtime',
        text: 'Cdr Time',
        sort: true
    }, {
        dataField: 'pagevisited',
        text: 'Page Visited',
        sort: true
    }, {
        dataField: 'module',
        text: 'Module',
        sort: true
    }, {
        dataField: 'action',
        text: 'Action',
        sort: true
    }
    ];

    auditdata = [
        { uname: 'User 1', ip: '192.168.0.12', cdrtime: '23 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 2', ip: '192.168.0.92', cdrtime: '20 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 3', ip: '192.168.0.101', cdrtime: '13 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 4', ip: '192.168.0.128', cdrtime: '40 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 5', ip: '192.168.0.0', cdrtime: '32 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 6', ip: '192.168.0.1', cdrtime: '12 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 7', ip: '192.168.0.234', cdrtime: '34 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 8', ip: '192.168.0.16', cdrtime: '45 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 9', ip: '192.168.0.85', cdrtime: '34 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 10', ip: '192.168.0.34', cdrtime: '22 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 11', ip: '192.168.0.122', cdrtime: '54 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' },
        { uname: 'User 12', ip: '192.168.0.14', cdrtime: '35 min', pagevisited: 'Dashboard', module: 'Dashboard', action: 'View' }
    ]

    options = {
        custom: true,
        totalSize: this.auditdata.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;
        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Audit Report</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="User"
                                                    options={this.userOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="User"
                                                />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    ranges={ranges}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        className="calendarIcon"
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <Col sm="2">
                                            <button className="btn btn-submit" type="submit" onClick={() => this.showReportsData()}>
                                                Submit
                                            </button>
                                        </Col>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='uname'
                                                                data={this.auditdata}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />

                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'audit-rglr' : 'audit-rglr' }>

                                                                                    <BootstrapTable
                                                                                        classes="expandTable auditReport"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                    />
                                                                                </div>
                                                                            </PerfectScrollbar>

                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                    {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(RoomUtilization1));

