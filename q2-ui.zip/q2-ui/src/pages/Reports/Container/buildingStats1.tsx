import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { MySelect } from '../../../helpers/internaljscontrols';
import BootstrapTable from 'react-bootstrap-table-next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class BuildingStats1 extends React.Component<any, any> {

    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    showReportsData = () => {
        this.setState({ showReportsData: true })
    }


    buildingOptions = [
        { label: "Building 1", value: "building1" },
        { label: "Building 2", value: "building2" },
        { label: "Building 3", value: "building3" },
    ]

    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'buildingname',
        text: 'Building Name',
        sort: true
    }, {
        dataField: 'totalAppt',
        text: 'Total Appointments',
        sort: true
    }, {
        dataField: 'checkin',
        text: 'Check-In',
        sort: true
    }, {
        dataField: 'percheckin',
        text: '% Check-In',
        sort: true
    }, {
        dataField: 'noshow',
        text: 'No Show',
        sort: true
    }, {
        dataField: 'earlycheckin',
        text: 'Early Check-In',
        sort: true
    }, {
        dataField: 'ontime',
        text: 'On Time',
        sort: true
    }, {
        dataField: 'latecheckin',
        text: 'Late Check-In',
        sort: true
    }, {
        dataField: 'nojourney',
        text: 'No Journey',
        sort: true
    }, {
        dataField: 'avgwaitTime',
        text: 'Avg Wait Time (mins)',
        sort: true
    }, {
        dataField: 'avgCareTime',
        text: 'Avg Care Time (mins)',
        sort: true
    }, {
        dataField: 'avgServiceTime',
        text: 'Avg Service Time (mins)',
        sort: true
    }, {
        dataField: 'avgtranstTime',
        text: 'Avg Transit Time',
        sort: true
    }
    ];

    buildingStatsdata = [
        { date: '20-08-2020', buildingname: "Building1", totalAppt: 30, checkin: 2, percheckin: "2%", noshow: 20, earlycheckin: 3, ontime: 2, latecheckin: 4, nojourney: 1, avgwaitTime: '2 min', avgCareTime: '10 min', avgServiceTime: '10 min', avgtranstTime: '10 min' },
        { date: '21-08-2020', buildingname: "Building2", totalAppt: 20, checkin: 5, percheckin: "1%", noshow: 10, earlycheckin: 1, ontime: 5, latecheckin: 1, nojourney: 4, avgwaitTime: '10 min', avgCareTime: '20 min', avgServiceTime: '15 min', avgtranstTime: '10 min' },
        { date: '22-08-2020', buildingname: "Building3", totalAppt: 10, checkin: 2, percheckin: "2%", noshow: 30, earlycheckin: 3, ontime: 1, latecheckin: 4, nojourney: 2, avgwaitTime: '10 min', avgCareTime: '10 min', avgServiceTime: '10 min', avgtranstTime: '10 min' },
        { date: '25-08-2020', buildingname: "Building4", totalAppt: 20, checkin: 4, percheckin: "4%", noshow: 10, earlycheckin: 2, ontime: 4, latecheckin: 5, nojourney: 1, avgwaitTime: '10 min', avgCareTime: '5 min', avgServiceTime: '21 min', avgtranstTime: '10 min' }
    ]

    options = {
        custom: true,
        totalSize: this.buildingStatsdata.length,
        sizePerPage: 6,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {
            "Today": [moment(start), moment(end)],
            "Last Week": [moment(start).subtract(7, "days"), moment(end)],
            "Last Month": [moment(start).subtract(30, "days"), moment(end)],
            "Last Year": [moment(start).subtract(365, "days"), moment(end)]
        }
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Building Stats</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="floor"
                                                    options={this.buildingOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Building"
                                                    noOptionsMessage="No Options"
                                                />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    ranges={ranges}
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        type="text"
                                                        className="calendarIcon"
                                                        label="Text"
                                                        placeholder="Enter text"
                                                        value={value}
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>

                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <> <PaginationProvider pagination={paginationFactory(this.options)}>
                                            {
                                                ({
                                                    paginationProps,
                                                    paginationTableProps
                                                }) => (
                                                        <ToolkitProvider keyField='buildingname'
                                                            data={this.buildingStatsdata}
                                                            columns={this.columns}
                                                            columnToggle>
                                                            {
                                                                props => (
                                                                    <div className="toggle-headers">
                                                                        <ToggleList {...props.columnToggleProps} />
                                                                        <PerfectScrollbar>
                                                                            <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'building-rglr' : 'building-exp' }>
                                                                                <BootstrapTable
                                                                                    classes="expandTable buildingStatsTable"
                                                                                    bordered={false}
                                                                                    defaultSortDirection="asc"
                                                                                    {...paginationTableProps}
                                                                                    {...props.baseProps}
                                                                                />
                                                                            </div>
                                                                        </PerfectScrollbar>
                                                                        <div className="btn-export mt-4">
                                                                            <button className="btn mr-3" type="button">Export to PDF</button>
                                                                            <button className="btn" type="button">Export to CSV</button>
                                                                            {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                {...paginationProps}
                                                                            />
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                )}
                                                        </ToolkitProvider>
                                                    )
                                            }
                                        </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(BuildingStats1));

