import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { MySelect } from '../../../helpers/helpersIndex';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import PerfectScrollbar from 'react-perfect-scrollbar';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class EmailReport1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    statusOptions = [
        { label: "Sent", value: "sent" },
        { label: "Delivered", value: "delivered" },
        { label: "Error", value: "error" },
        { label: "All", value: "all" },
    ];

    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'mobile',
        text: 'Mobile No',
        sort: true
    }, {
        dataField: 'sender',
        text: 'Sender',
        sort: true
    }, {
        dataField: 'message',
        text: 'Message',
        sort: true
    }, {
        dataField: 'submittime',
        text: 'Submit Time',
        sort: true
    }, {
        dataField: 'responsetime',
        text: 'Response Time',
        sort: true
    }, {
        dataField: 'dlrtime',
        text: 'Delivered Time',
        sort: true
    }, {
        dataField: 'rescode',
        text: 'Response Code',
        sort: true
    }, {
        dataField: 'resdescription',
        text: 'Response Description',
        sort: true
    }, {
        dataField: 'triggertype',
        text: 'Trigger Type',
        sort: true
    }
    ];

    emaildata = [
        { date: '21-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '21-07-2020 09:00 AM', responsetime: '21-07-2020 09:00 AM', dlrtime: '21-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '22-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '22-07-2020 09:00 AM', responsetime: '22-07-2020 09:00 AM', dlrtime: '22-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '23-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '23-07-2020 09:00 AM', responsetime: '23-07-2020 09:00 AM', dlrtime: '23-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '24-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '24-07-2020 09:00 AM', responsetime: '24-07-2020 09:00 AM', dlrtime: '24-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '25-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '25-07-2020 09:00 AM', responsetime: '25-07-2020 09:00 AM', dlrtime: '25-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '26-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '26-07-2020 09:00 AM', responsetime: '26-07-2020 09:00 AM', dlrtime: '26-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '27-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '27-07-2020 09:00 AM', responsetime: '27-07-2020 09:00 AM', dlrtime: '27-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '28-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '28-07-2020 09:00 AM', responsetime: '28-07-2020 09:00 AM', dlrtime: '28-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '29-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '29-07-2020 09:00 AM', responsetime: '29-07-2020 09:00 AM', dlrtime: '29-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '30-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '30-07-2020 09:00 AM', responsetime: '30-07-2020 09:00 AM', dlrtime: '30-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '31-07-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '31-07-2020 09:00 AM', responsetime: '31-07-2020 09:00 AM', dlrtime: '31-07-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
        { date: '01-08-2020', mobile: '9900123456', sender: 'HDFC Bank', message: 'This is sample message', submittime: '01-08-2020 09:00 AM', responsetime: '01-08-2020 09:00 AM', dlrtime: '01-08-2020 09:00 AM', rescode: '502', resdescription: 'Delivered', triggertype: 'Sent' },
    ]

    options = {
        custom: true,
        totalSize: this.emaildata.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Email Report</h4>
                                    <Row className="reportform">
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    ranges={ranges}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="Status"
                                                    options={this.statusOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Status"
                                                />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="2">
                                            <button className="btn btn-submit" type="submit" onClick={() => this.showReportsData()}>
                                                Submit
                                            </button>
                                        </Col>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='date'
                                                                data={this.emaildata}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            {console.log("selectedcolumns", Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length)}
                                                                            <ToggleList {...props.columnToggleProps} />

                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'sms-rglr' : 'sms-exp' }>

                                                                                    <BootstrapTable
                                                                                        classes="expandTable smsReport"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                    />
                                                                                </div>
                                                                            </PerfectScrollbar>

                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                    {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(EmailReport1));

