import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { MySelect } from '../../../helpers/internaljscontrols';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { Scrollbars } from 'react-custom-scrollbars';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class StaffReport1 extends React.Component<any, any> {

    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }

    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    deptOptions = [
        { label: "Department1", value: "Department 1" },
        { label: "Department2", value: "Department 2" },
        { label: "Department3", value: "Department 3" },
        { label: "Department4", value: "Department 4" }
    ];
    floorOptions = [
        { label: "Floor 1", value: "Floor1" },
        { label: "Floor 2", value: "Floor2" },
        { label: "Floor 3", value: "Floor3" },
    ]

    columns = [{
        dataField: 'sname',
        text: 'Staff Name',
        sort: true
    }, {
        dataField: 'sid',
        text: 'Staff ID',
        sort: true
    }, {
        dataField: 'avgIdleTime',
        text: 'Avg Idle Time',
        sort: true
    }, {
        dataField: 'avgservTime',
        text: 'Avg Serving Time',
        sort: true
    }, {
        dataField: 'totServTime',
        text: 'Total Serving Time',
        sort: true
    }, {
        dataField: 'totalTokenserv',
        text: 'Total Tokens Served',
        sort: true
    }, {
        dataField: 'utilization',
        text: '% Utilization',
        sort: true
    }, {
        dataField: 'perfIndex',
        text: 'Performance Index',
        sort: true
    }, {
        dataField: 'date',
        text: 'Date',
        sort: true
    }
    ];
    staffdata = [
        { sname: 'Suresh', sid: '112233', avgIdleTime: '10 min', avgservTime: '10 min', totServTime: '2 min', totalTokenserv: 30, utilization: 24, perfIndex: 20, date: '10-08-2020' },
        { sname: 'Ramesh', sid: '112233', avgIdleTime: '20 min', avgservTime: '15 min', totServTime: '10 min', totalTokenserv: 20, utilization: 14, perfIndex: 10, date: '10-08-2020' },
        { sname: 'Akhila', sid: '112233', avgIdleTime: '10 min', avgservTime: '10 min', totServTime: '5 min', totalTokenserv: 10, utilization: 27, perfIndex: 30, date: '10-08-2020' },
        { sname: 'Rajesh', sid: '112365', avgIdleTime: '5 min', avgservTime: '21 min', totServTime: '20 min', totalTokenserv: 20, utilization: 24, perfIndex: 40, date: '10-08-2020' }
    ]

    options = {
        custom: true,
        totalSize: this.staffdata.length,
        sizePerPage: 6,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Staff Reports</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="floor"
                                                    options={this.floorOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Floor"
                                                    noOptionsMessage="No Options"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="department"
                                                    options={this.deptOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Department"
                                                    noOptionsMessage="No Options"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    ranges={ranges}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}>
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback} />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <> <PaginationProvider pagination={paginationFactory(this.options)}>
                                            {
                                                ({
                                                    paginationProps,
                                                    paginationTableProps
                                                }) => (
                                                        <ToolkitProvider keyField='sname'
                                                            data={this.staffdata}
                                                            columns={this.columns}
                                                            columnToggle>
                                                            {
                                                                props => (
                                                                    <div className="toggle-headers">
                                                                        <ToggleList {...props.columnToggleProps} />

                                                                        <PerfectScrollbar>
                                                                            <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'staff-rglr' : 'staff-exp' }>
                                                                                <BootstrapTable
                                                                                    classes="expandTable staffTable"
                                                                                    bordered={false}
                                                                                    defaultSortDirection="asc"
                                                                                    {...paginationTableProps}
                                                                                    {...props.baseProps}
                                                                                />
                                                                            </div>
                                                                        </PerfectScrollbar>
                                                                        <div className="btn-export mt-4">
                                                                            <button className="btn mr-3" type="button">Export to PDF</button>
                                                                            <button className="btn" type="button">Export to CSV</button>
                                                                            {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                {...paginationProps}
                                                                            />
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                )}
                                                        </ToolkitProvider>
                                                    )}
                                        </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(StaffReport1));

