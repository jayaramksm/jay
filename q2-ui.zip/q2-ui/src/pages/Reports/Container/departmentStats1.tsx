import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { MySelect } from '../../../helpers/internaljscontrols';
import BootstrapTable from 'react-bootstrap-table-next';
import PerfectScrollbar from 'react-perfect-scrollbar';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class DepartmentStats1 extends React.Component<any, any> {

    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    deptOptions = [
        { label: "Department 1", value: "department1" },
        { label: "Department 2", value: "department2" },
        { label: "Department 3", value: "department3" },
        { label: "Department 4", value: "department4" }
    ];

    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'deptname',
        text: 'Department',
        sort: true
    }
    , {
        dataField: 'avgwaitTime',
        text: 'Avg Wait Time (mins)',
        sort: true
    }, {
        dataField: 'avgCareTime',
        text: 'Avg Care Time (mins)',
        sort: true
    },{
        dataField: 'checkin',
        text: 'Total Check-In',
        sort: true
    } ,
    {
        dataField: 'served',
        text: 'Total Served',
        sort: true
    }, {
        dataField: 'nojourney',
        text: 'Total No Journey',
        sort: true
    },
    {
       dataField: 'priority',
       text: 'Total Priority Served',
       sort: true
   },
    {
       dataField: 'counters',
       text: 'Total Counters',
       sort: true
   }
    ];

    buildingStatsdata = [
        { date: '11-08-2020', deptname: "Pharmacy", checkin: 30, served: 20, priority: 3,nojourney: 1, avgwaitTime: '2', avgCareTime: '10',counters:"5"},
        { date: '12-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 1, nojourney: 4, avgwaitTime: '10', avgCareTime: '20', counters:"6"},
        { date: '13-08-2020', deptname: "Pharmacy", checkin: 10, served: 30, priority: 3,  nojourney: 2, avgwaitTime: '10', avgCareTime: '10', counters:"15"},
        { date: '14-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 2,  nojourney: 1, avgwaitTime: '10', avgCareTime: '5' , counters:"2"},
        { date: '15-08-2020', deptname: "Pharmacy", checkin: 30, served: 20, priority: 3,  nojourney: 1, avgwaitTime: '2', avgCareTime: '10', counters:"14"},
        { date: '16-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 1, nojourney: 4, avgwaitTime: '10', avgCareTime: '20', counters:"15"},
        { date: '17-08-2020', deptname: "Pharmacy", checkin: 10, served: 30, priority: 3,  nojourney: 2, avgwaitTime: '10', avgCareTime: '10', counters:"5"},
        { date: '18-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 2,  nojourney: 1, avgwaitTime: '10', avgCareTime: '5' , counters:"5"},
        { date: '19-08-2020', deptname: "Pharmacy", checkin: 30, served: 20, priority: 3,nojourney: 1, avgwaitTime: '2', avgCareTime: '10', counters:"5"},
        { date: '20-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 1, nojourney: 4, avgwaitTime: '10', avgCareTime: '20', counters:"15"},
        { date: '21-08-2020', deptname: "Pharmacy", checkin: 10, served: 30, priority: 3, nojourney: 2, avgwaitTime: '10', avgCareTime: '10', counters:"9"},
        { date: '22-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 2, nojourney: 1, avgwaitTime: '10', avgCareTime: '5' , counters:"5"},
        { date: '23-08-2020', deptname: "Pharmacy", checkin: 30, served: 20, priority: 3, nojourney: 1, avgwaitTime: '2', avgCareTime: '10', counters:"13"},
        { date: '24-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 1, nojourney: 4, avgwaitTime: '10', avgCareTime: '20', counters:"7"},
        { date: '25-08-2020', deptname: "Pharmacy", checkin: 10, served: 30, priority: 3, nojourney: 2, avgwaitTime: '10', avgCareTime: '10', counters:"15"},
        { date: '26-08-2020', deptname: "Pharmacy", checkin: 20, served: 10, priority: 2, nojourney: 1, avgwaitTime: '10', avgCareTime: '5' , counters:"5"}
    ]

    options = {
        custom: true,
        totalSize: this.buildingStatsdata.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {
            "Today": [moment(start), moment(end)],
            "Last Week": [moment(start).subtract(7, "days"), moment(end)],
            "Last Month": [moment(start).subtract(30, "days"), moment(end)],
            "Last Year": [moment(start).subtract(365, "days"), moment(end)]
        }
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Department Report</h4>
                                    <Row className="reportform mb-2">
                                       
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    ranges={ranges}
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        type="text"
                                                        label="Text"
                                                        className="calendarIcon"
                                                        placeholder="Enter text"
                                                        value={value}
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>

                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <> <PaginationProvider pagination={paginationFactory(this.options)}>
                                            {
                                                ({
                                                    paginationProps,
                                                    paginationTableProps
                                                }) => (
                                                        <ToolkitProvider keyField='date'
                                                            data={this.buildingStatsdata}
                                                            columns={this.columns}
                                                            columnToggle>
                                                            {
                                                                props => (
                                                                    <div className="toggle-headers">
                                                                        {console.log("selectedcolumns", Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length)}
                                                                        <ToggleList {...props.columnToggleProps} />


                                                                        <PerfectScrollbar>
                                                                            <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'dept-rglr' : 'dept-exp' }>

                                                                                <BootstrapTable
                                                                                    classes="expandTable buildingStatsTable"
                                                                                    bordered={false}
                                                                                    defaultSortDirection="asc"
                                                                                    {...paginationTableProps}
                                                                                    {...props.baseProps}
                                                                                />
                                                                            </div>
                                                                        </PerfectScrollbar>
                                                                        <div className="btn-export mt-4">
                                                                            <button className="btn mr-3" type="button">Export to PDF</button>
                                                                            <button className="btn" type="button">Export to CSV</button>
                                                                            {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                {...paginationProps}
                                                                            />
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                )}
                                                        </ToolkitProvider>
                                                    )
                                            }
                                        </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(DepartmentStats1));

