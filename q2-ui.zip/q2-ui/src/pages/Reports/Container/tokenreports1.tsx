import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, FormGroup, Input, Container} from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { Scrollbars } from 'react-custom-scrollbars';
import BootstrapTable from 'react-bootstrap-table-next';
import './reports.css';
import { MySelect } from '../../../helpers/internaljscontrols';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import Modal from 'react-modal';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class TokenReports1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        this.state = {
            showReportsData: false,
            start: start,
            end: end
        };
        this.applyCallback = this.applyCallback.bind(this);
    }
    rowEvents = {
        onClick: () => {
            this.toggleModal()
        }
    }
    toggleModal() {
        this.setState({ modalOpen: true });
    }

    componentDidMount() {
        this.props.activateAuthLayout();
    }

    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    deptOptions = [
        { label: "Department 1", value: "department1" },
        { label: "Department 2", value: "department2" },
        { label: "Department 3", value: "department3" },
        { label: "Department 4", value: "department4" }
    ];


    tknrepotsData = [
        { id: 1, date: '01-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 1', totalvisits: "30", totalserved: "30", avgwaitingtime: "20 min", avgcaretime: "20 min", avgjourneytime: "30 min", nojourney: '12', totalprioritytkn: '12', scheduledvisits: "30", walkinvisits: '30', adult: '23', childern: "3", walkinvisit: "10%", scheduled: "10%" },
        { id: 2, date: '02-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 2', totalvisits: "25", totalserved: "25", avgwaitingtime: "10 min", avgcaretime: "20 min", avgjourneytime: "35 min", nojourney: '10', totalprioritytkn: '10', scheduledvisits: "25", walkinvisits: '25', adult: '25', childern: "6", walkinvisit: "20%", scheduled: "10%" },
        { id: 3, date: '03-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 3', totalvisits: "23", totalserved: "23", avgwaitingtime: "15 min", avgcaretime: "20 min", avgjourneytime: "40 min", nojourney: '5', totalprioritytkn: '5', scheduledvisits: "23", walkinvisits: '23', adult: '67', childern: "0", walkinvisit: "13%", scheduled: "10%" },
        { id: 4, date: '04-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 4', totalvisits: "25", totalserved: "25", avgwaitingtime: "10 min", avgcaretime: "20 min", avgjourneytime: "50 min", nojourney: '12', totalprioritytkn: '7', scheduledvisits: "25", walkinvisits: '25', adult: '34', childern: "5", walkinvisit: "15%", scheduled: "10%" },
        { id: 5, date: '05-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 5', totalvisits: "30", totalserved: "30", avgwaitingtime: "20 min", avgcaretime: "20 min", avgjourneytime: "30 min", nojourney: '23', totalprioritytkn: '14', scheduledvisits: "30", walkinvisits: '30', adult: '56', childern: "5", walkinvisit: "10%", scheduled: "10%" },
        { id: 6, date: '06-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 6', totalvisits: "25", totalserved: "25", avgwaitingtime: "10 min", avgcaretime: "20 min", avgjourneytime: "35 min", nojourney: '24', totalprioritytkn: '16', scheduledvisits: "25", walkinvisits: '25', adult: '72', childern: "3", walkinvisit: "20%", scheduled: "10%" },
        { id: 7, date: '07-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 7', totalvisits: "23", totalserved: "23", avgwaitingtime: "15 min", avgcaretime: "20 min", avgjourneytime: "40 min", nojourney: '12', totalprioritytkn: '13', scheduledvisits: "23", walkinvisits: '23', adult: '45', childern: "2", walkinvisit: "13%", scheduled: "10%" },
        { id: 8, date: '08-07-2020', year: '2020', quarter: '2020/Q1', month: '02/2020', department: 'Department 8', totalvisits: "25", totalserved: "25", avgwaitingtime: "10 min", avgcaretime: "20 min", avgjourneytime: "50 min", nojourney: '13', totalprioritytkn: '10', scheduledvisits: "25", walkinvisits: '25', adult: '34', childern: "10", walkinvisit: "15%", scheduled: "10%" }
    ]

    options = {
        custom: true,
        totalSize: this.tknrepotsData.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };
    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true,
    },
    {
        dataField: 'department',
        text: 'Department',
        sort: true
    }, {
        dataField: 'totalvisits',
        text: 'Total Visits',
        sort: true
    }, {
        dataField: 'totalserved',
        text: 'Total Served',
        sort: true
    }, {
        dataField: 'avgwaitingtime',
        text: 'Avg Waiting Time',
        sort: true
    }, {
        dataField: 'avgcaretime',
        text: 'Avg Care Time',
        sort: true
    }
        , {
        dataField: 'avgjourneytime',
        text: 'Avg Journey Time',
        sort: true
    }, {
        dataField: 'nojourney',
        text: 'No Journey',
        sort: true
    }, {
        dataField: 'totalprioritytkn',
        text: 'Total Priority Token',
        sort: true,

    }, {
        dataField: 'scheduledvisits',
        text: 'Scheduled Visits',
        sort: true
    }, {
        dataField: 'walkinvisits',
        text: 'Walkin Visits',
        sort: true
    }, {
        dataField: 'adult',
        text: 'Adult (age > 21)',
        sort: true
    }, {
        dataField: 'childern',
        text: 'Childern (age < 21)',
        sort: true
    }, {
        dataField: 'walkinvisit',
        text: '% Walkin Visits',
        sort: true
    }, {
        dataField: 'scheduled',
        text: '% Scheduled',
        sort: true
    }
    ];
    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {
            "Today": [moment(start), moment(end)],
            "Last Week": [moment(start).subtract(7, "days"), moment(end)],
            "Last Month": [moment(start).subtract(30, "days"), moment(end)],
            "Last Year": [moment(start).subtract(365, "days"), moment(end)]
        }
        console.log("ranges=>",ranges)
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }

        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                {console.log("rem")}
                                <div className="reports mt-2">
                                    <h4>Token Reports</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="department"
                                                    options={this.deptOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Department"
                                                    noOptionsMessage="No Options"
                                                />
                                            </FormGroup>
                                        </Col>

                                        <Col sm="3" className="w-18">
                                            <FormGroup>

                                                <DateTimeRangeContainer
                                                    ranges={ranges}
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}>
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        placeholder="Enter text"
                                                        value={value}
                                                        onChange={this.applyCallback}/>
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>

                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='date'
                                                                data={this.tknrepotsData}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />

                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'tkn-rglr' : 'tkn-exp' }>
                                                                                    <BootstrapTable
                                                                                        classes="expandTable tknreportsTable"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                        rowEvents={this.rowEvents}
                                                                                    />
                                                                                </div>
                                                                            </PerfectScrollbar>
                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage &&
                                                                                    <PaginationListStandalone  {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>)}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                    {this.state.modalOpen && <div>
                        <Modal isOpen={this.state.modalOpen} ariaHideApp={false} className="expandModal feedbackexpand">
                            <Row>
                                <Col className="text-right">
                                    <button onClick={() => this.setState({ modalOpen: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </Col>
                            </Row>
                            <div>
                                <PerfectScrollbar style={{ maxHeight: "350px" }}>
                                    <table>
                                        <thead>
                                            <tr>
                                                <td>Dept + Service</td>
                                                <td>Total Visits</td>
                                                <td>Total Served</td>
                                                <td>Avg Waiting Time</td><td>Avg Care Time</td><td>Avg Journey Time</td>
                                                <td>No Journey</td><td>Total Priority Tokens</td><td>Scheduled Visits</td>
                                                <td>Walkin Visits</td><td>Adult(age&gt;21)</td><td>Childern(age&lt;21)</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Cardiology, Service1</td><td>12</td><td>10</td>
                                                <td>15 min </td><td>15 min</td><td>40 min</td>
                                                <td>----</td><td>4</td>
                                                <td>6</td><td>6</td>
                                                <td>23</td><td>4</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology, Service1</td><td>12</td><td>10</td>
                                                <td>15 min </td><td>15 min</td><td>40 min</td>
                                                <td>----</td><td>4</td>
                                                <td>6</td><td>6</td>
                                                <td>23</td><td>4</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology, Service1</td><td>12</td><td>10</td>
                                                <td>15 min </td><td>15 min</td><td>40 min</td>
                                                <td>----</td><td>4</td>
                                                <td>6</td><td>6</td>
                                                <td>23</td><td>4</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </PerfectScrollbar>
                            </div>
                        </Modal>
                    </div>}
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(TokenReports1));

