import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, FormGroup, Input, Container } from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { Scrollbars } from 'react-custom-scrollbars';
import BootstrapTable from 'react-bootstrap-table-next';
import './reports.css';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class AppointmentLookup1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        }
        )
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    statusFormatter = (cell) => {
        return cell === "Scheduled" ? <span><i className="fa fa-check-circle" style={{ color: "#1CA319", fontSize: "16px" }}></i> &nbsp;{cell}</span> :
            cell === "Rescheduled" ? <span><i className="fa fa-check-circle" style={{ color: "#5D62B5", fontSize: "16px" }}></i> &nbsp;{cell}</span> :
                cell === "CheckIn" ? <span><i className="fa fa-check-circle" style={{ color: "#FA9130", fontSize: "16px" }}></i> &nbsp;{cell}</span> :
                    cell === "Cancelled" ? <span><i className="fa fa-times-circle" style={{ color: "#666666", fontSize: "16px" }}></i> &nbsp;{cell}</span> :
                        <span><i className="fa fa-times-circle" style={{ color: "#F91313", fontSize: "16px" }}></i> &nbsp;{cell}</span>
    }
    columns = [{
        dataField: 'apptdate',
        text: 'Appointment Date',
        sort: true
    }, {
        dataField: 'mrn',
        text: 'MRN No',
        sort: true
    }, {
        dataField: 'appttype',
        text: 'Appointment Type',
        sort: true
    }, {
        dataField: 'patientname',
        text: 'Patient Name',
        sort: true
    }, {
        dataField: 'regstatus',
        text: 'Registration Status',
        sort: true
    }, {
        dataField: 'serviceloc',
        text: 'Service Location / Point of Care',
        sort: true
    }, {
        dataField: 'service',
        text: 'Service',
        sort: true
    }, {
        dataField: 'status',
        text: 'Status',
        sort: true,
        formatter: this.statusFormatter,
    }, {
        dataField: 'resource',
        text: 'Doctor / Resource',
        sort: true
    }, {
        dataField: 'dob',
        text: 'DOB',
        sort: true
    }, {
        dataField: 'gender',
        text: 'Gender',
        sort: true
    }, {
        dataField: 'clinic',
        text: 'Department/Clinic',
        sort: true
    }, {
        dataField: 'priority',
        text: 'Priority',
        sort: true
    }
    ];
    apptdata = [
        { apptdate: '01-07-2020 10:00 AM', mrn: '9632587412363', appttype: "Manual", patientname: "Abdul Rehman", regstatus: "Active", serviceloc: "Dubai", service: 'Service1', status: 'Scheduled', resource: "Dr.Rahul", dob: '15-01-1996', gender: 'Male', clinic: "Department 1", priority: "High" },
        { apptdate: '05-07-2020 11:00 AM', mrn: '9632587412363', appttype: "EMR", patientname: "Abdul Rehman", regstatus: "Active", serviceloc: "Dubai", service: 'Service3', status: 'CheckIn', resource: "Dr.Reshma", dob: '15-01-1996', gender: 'Male', clinic: "Department 2", priority: "Low" },
        { apptdate: '06-07-2020 01:00 PM', mrn: '9632587412363', appttype: "EMR", patientname: "Abdul Rehman", regstatus: "Active", serviceloc: "Dubai", service: 'Service2', status: 'Error', resource: "Dr.Sri Ram", dob: '15-01-1996', gender: 'Male', clinic: "Department 3", priority: "Low" },
        { apptdate: '09-07-2020 10:30 AM', mrn: '9632587412363', appttype: "Manual", patientname: "Abdul Rehman", regstatus: "Active", serviceloc: "Dubai", service: 'Service3', status: 'Cancelled', resource: "Dr.Reshma", dob: '15-01-1996', gender: 'Male', clinic: "Department 4", priority: "High" },
        { apptdate: '10-07-2020 11:15 AM', mrn: '9632587412363', appttype: "EMR", patientname: "Abdul Rehman", regstatus: "Active", serviceloc: "Dubai", service: 'Service2', status: 'Rescheduled', resource: "Dr.Sri Ram", dob: '15-01-1996', gender: 'Male', clinic: "Department 5", priority: "Low" },
        { apptdate: '11-07-2020 02:00 PM', mrn: '9632587412363', appttype: "Manual", patientname: "Abdul Rehman", regstatus: "Active", serviceloc: "Dubai", service: 'Service3', status: 'Cancelled', resource: "Dr.Reshma", dob: '15-01-1996', gender: 'Male', clinic: "Department 6", priority: "High" }

    ]
    options = {
        custom: true,
        totalSize: this.apptdata.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };
    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Appointment Lookup</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <div className="mrn-search form-group">
                                                    <Input type="text" className="form-control" placeholder="Search MRN" id="example-text-input" />
                                                    <i className="fa fa-search"></i>
                                                </div>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    ranges={ranges}
                                                    smartMode
                                                    applyCallback={this.applyCallback}>
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback} />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>

                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='apptdate'
                                                                data={this.apptdata}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />
                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'appt-rglr' : 'appt-exp' }>

                                                                                    <BootstrapTable
                                                                                        classes="expandTable apptTable"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps} />
                                                                                </div>
                                                                            </PerfectScrollbar>
                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage &&
                                                                                    <PaginationListStandalone  {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>

                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(AppointmentLookup1));

