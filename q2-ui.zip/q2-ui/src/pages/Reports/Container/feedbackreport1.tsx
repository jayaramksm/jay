import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import PerfectScrollbar from 'react-perfect-scrollbar';
import "react-datepicker/dist/react-datepicker.css";
import './reports.css';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import Modal from 'react-modal'

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class FeedbackReport1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end
        };
        this.applyCallback = this.applyCallback.bind(this);

    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    toggleModal() {
        this.setState({ modalOpen: true });
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }
    rowEvents = {
        onClick: () => {
            this.toggleModal()
        }
    }

    columns = [{
        dataField: 'tCustomersServed',
        text: 'Total Customers Served',
        sort: true
    }, {
        dataField: 'tCustomersFeedback',
        text: 'Total Customer Given Feedback',
        sort: true
    }, {
        dataField: 'percentFeedback',
        text: '% Feedback Given',
        sort: true
    }, {
        dataField: 'uCustFeedback',
        text: 'Unique Customers given Feedback',
        sort: true
    }, {
        dataField: 'fiveStPercent',
        text: '5 Star %',
        sort: true
    }, {
        dataField: 'fourStPercent',
        text: '4 Star %',
        sort: true
    }, {
        dataField: 'threeStPercent',
        text: '3 Star %',
        sort: true
    }, {
        dataField: 'twoStPercent',
        text: '2 Star %',
        sort: true
    }, {
        dataField: 'oneStPercent',
        text: '1 Star %',
        sort: true
    }, {
        dataField: 'satIndex',
        text: 'Satisfaction Index',
        sort: true
    }
    ];

    feedbackdata = [
        { tCustomersServed: 80, tCustomersFeedback: 20, percentFeedback: '50 %', uCustFeedback: 30, fiveStPercent: 30, fourStPercent: 30, threeStPercent: 20, twoStPercent: 20, oneStPercent: 20, satIndex: 20 },
        { tCustomersServed: 70, tCustomersFeedback: 20, percentFeedback: '50 %', uCustFeedback: 30, fiveStPercent: 30, fourStPercent: 30, threeStPercent: 20, twoStPercent: 20, oneStPercent: 20, satIndex: 20 },
        { tCustomersServed: 50, tCustomersFeedback: 20, percentFeedback: '50 %', uCustFeedback: 30, fiveStPercent: 30, fourStPercent: 30, threeStPercent: 20, twoStPercent: 20, oneStPercent: 20, satIndex: 20 },
        { tCustomersServed: 60, tCustomersFeedback: 20, percentFeedback: '50 %', uCustFeedback: 30, fiveStPercent: 30, fourStPercent: 30, threeStPercent: 20, twoStPercent: 20, oneStPercent: 20, satIndex: 20 },
        { tCustomersServed: 90, tCustomersFeedback: 20, percentFeedback: '50 %', uCustFeedback: 30, fiveStPercent: 30, fourStPercent: 30, threeStPercent: 20, twoStPercent: 20, oneStPercent: 20, satIndex: 20 },
        { tCustomersServed: 40, tCustomersFeedback: 20, percentFeedback: '50 %', uCustFeedback: 30, fiveStPercent: 30, fourStPercent: 30, threeStPercent: 20, twoStPercent: 20, oneStPercent: 20, satIndex: 20 }
    ]

    options = {
        custom: true,
        totalSize: this.feedbackdata.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Customer Feedback Report</h4>
                                    <Row className="reportform">
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    ranges={ranges}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        value={value}
                                                        placeholder="Enter text"
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <Col sm="2">
                                            <button className="btn btn-submit" type="submit" onClick={() => this.showReportsData()}>
                                                Submit
                                            </button>
                                        </Col>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='tCustomersServed'
                                                                data={this.feedbackdata}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />

                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'feedback-rglr' : 'feedback-exp' }>

                                                                                    <BootstrapTable
                                                                                        classes="expandTable feedbakReport"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...props.baseProps}
                                                                                        rowEvents={this.rowEvents}
                                                                                        {...paginationTableProps}
                                                                                    />
                                                                                </div>
                                                                            </PerfectScrollbar>

                                                                            <div className="btn-export mt-4">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                    {...paginationProps}
                                                                                />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                    {this.state.modalOpen && <div>
                        <Modal isOpen={this.state.modalOpen} ariaHideApp={false} className="expandModal feedbackexpand">
                            <Row>
                                <Col className="text-right">
                                    <button onClick={() => this.setState({ modalOpen: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </Col>
                            </Row>
                            <div>
                                <PerfectScrollbar style={{ maxHeight: "350px" }}>
                                    <table>
                                        <thead>
                                            <tr>
                                                <td>Dept</td>
                                                <td>Total Customers Served</td><td>Total Customers Given Feddback</td><td>%Feedback Given</td><td>Unique Customers Given Feedback</td>
                                                <td>5star %</td><td>4star %</td>
                                                <td>3star %</td><td>2star %</td><td>1star %</td><td>Satisfaction Index</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Cardiology, Service2</td>
                                                <td>12</td><td>10</td><td>12</td>
                                                <td>12</td><td>12</td><td>15</td>
                                                <td>15</td><td>4</td>
                                                <td>6</td><td>6</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology, Service2</td>
                                                <td>12</td><td>10</td><td>12</td>
                                                <td>12</td><td>12</td><td>15</td>
                                                <td>15</td><td>4</td>
                                                <td>6</td><td>6</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology, Service2</td>
                                                <td>12</td><td>10</td><td>12</td>
                                                <td>12</td><td>12</td><td>15</td>
                                                <td>15</td><td>4</td>
                                                <td>6</td><td>6</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology, Service2</td>
                                                <td>12</td><td>10</td><td>12</td>
                                                <td>12</td><td>12</td><td>15</td>
                                                <td>15</td><td>4</td>
                                                <td>6</td><td>6</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology, Service2</td>
                                                <td>12</td><td>10</td><td>12</td>
                                                <td>12</td><td>12</td><td>15</td>
                                                <td>15</td><td>4</td>
                                                <td>6</td><td>6</td>
                                            </tr>
                                            <tr>
                                                <td>Cardiology, Service2</td>
                                                <td>12</td><td>10</td><td>12</td>
                                                <td>12</td><td>12</td><td>15</td>
                                                <td>15</td><td>4</td>
                                                <td>6</td><td>6</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </PerfectScrollbar>
                            </div>
                        </Modal>
                    </div>}
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(FeedbackReport1));

