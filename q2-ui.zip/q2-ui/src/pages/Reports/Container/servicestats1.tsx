import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, Container, FormGroup, Input } from 'reactstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { MySelect } from '../../../helpers/helpersIndex';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import PerfectScrollbar from 'react-perfect-scrollbar';
import './reports.css';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class ServiceStats1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
        };
        this.applyCallback = this.applyCallback.bind(this);
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }

    deptOptions = [
        { label: "FASTTRACK", value: "FASTTRACK" },
        { label: "NORMAL_MEDICINE", value: "NORMAL_MEDICINE" },
        { label: "CONTROL_DRUG", value: "CONTROL_DRUG" },
        { label: "REGULAR_MEDICINE", value: "REGULAR_MEDICINE" },
        { label: "PRIORITY_SERVICE", value: "PRIORITY_SERVICE" },
        { label: "PRESCRIBED_MEDICINE", value: "PRESCRIBED_MEDICINE" },
        { label: "MANUAL_TOKEN_SERVICE", value: "MANUAL_TOKEN_SERVICE" },
        { label: "HIGH_PRIORITY_SERVICE", value: "HIGH_PRIORITY_SERVICE" },
        { label: "KIDS_SERVICE", value: "KIDS_SERVICE" },
        { label: "ADULT_SERVICE", value: "ADULT_SERVICE" },
    ];

    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true
    },  {
        dataField: 'service',
        text: 'Service Name',
        sort: true
    }, {
        dataField: 'checkin',
        text: 'Total Check-In',
        sort: true
    }, {
        dataField: 'served',
        text: 'Total Served',
        sort: true
    },{
        dataField: 'noJourney',
        text: 'Total No Journey',
        sort: true
    }, {
        dataField: 'priority',
        text: 'Total Priority',
        sort: true
    },{
        dataField: 'avgWaitTime',
        text: 'Avg Wait Time (mins)',
        sort: true
    }, {
        dataField: 'avgCareTime',
        text: 'Avg Care Time (mins)',
        sort: true
    }, {
        dataField: 'counters',
        text: 'Total Counters',
        sort: true
    }
    ];

    servicedata = [
        { date: '25-07-2020', service: 'FASTTRACK', checkin: 34, served: 24, noJourney: 10, avgWaitTime: '30', avgCareTime: "30", counters: '12',priority:4 },
        { date: '12-07-2020', service: 'NORMAL_MEDICINE', checkin: 30, served: 30,  noJourney: 0, avgWaitTime: '45', avgCareTime: "45", counters: '5',priority:5  },
        { date: '14-06-2020', service: 'CONTROL_DRUG', checkin: 36, served: 34, noJourney: 2, avgWaitTime: '24', avgCareTime: "24", counters: '6',priority:3  },
        { date: '10-05-2020', service: 'REGULAR_MEDICINE', checkin: 38, served: 30,  noJourney: 8, avgWaitTime: '31', avgCareTime: "31", counters: '13' ,priority:2 },
        { date: '04-07-2020', service: 'PRIORITY_SERVICE', checkin: 34, served: 34,  noJourney: 0, avgWaitTime: '54', avgCareTime: "54", counters: '7',priority:4  },
        { date: '26-07-2020', service: 'PRESCRIBED_MEDICINE', checkin: 28, served: 26,  noJourney: 2, avgWaitTime: '30', avgCareTime: "30", counters: '10' ,priority:5 },
        { date: '27-06-2020', service: 'MANUAL_TOKEN_SERVICE', checkin: 26, served: 23,  noJourney: 3, avgWaitTime: '45', avgCareTime: "45", counters: '6' ,priority:1 },
        { date: '18-05-2020', service: 'HIGH_PRIORITY_SERVICE', checkin: 29, served: 22,  noJourney: 7, avgWaitTime: '24', avgCareTime: "24", counters: '10' ,priority:4 },
        { date: '11-06-2020', service: 'KIDS_SERVICE', checkin: 18, served: 13, noJourney: 6, avgWaitTime: '31', avgCareTime: "31", counters: '7',priority:3  },
        { date: '26-06-2020', service: 'ADULT_SERVICE', checkin: 41, served: 34,  noJourney: 7, avgWaitTime: '54', avgCareTime: "54", counters: '5',priority:4  },
    ]

    options = {
        custom: true,
        totalSize: this.servicedata.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };

    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {
            "Today": [moment(start), moment(end)],
            "Last Week": [moment(start).subtract(7, "days"), moment(end)],
            "Last Month": [moment(start).subtract(30, "days"), moment(end)],
            "Last Year": [moment(start).subtract(365, "days"), moment(end)]
        }
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Service Report</h4>
                                    <Row className="reportform mb-2">
                                        <Col sm="2">
                                            <FormGroup>
                                                <MySelect
                                                    name="services"
                                                    options={this.deptOptions}
                                                    getOptionLabel={option => option.label}
                                                    getOptionValue={option => option.value}
                                                    defaultValue=''
                                                    placeholder="Select Service"
                                                />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    ranges={ranges}
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                    <Input
                                                        id="formControlsTextB"
                                                        className="calendarIcon"
                                                        type="text"
                                                        label="Text"
                                                        placeholder="Enter text"
                                                        value={value}
                                                        onChange={this.applyCallback}

                                                    />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>


                                        <Col sm="2">
                                            <button className="btn btn-submit" type="submit" onClick={() => this.showReportsData()}>
                                                Submit
                                            </button>
                                        </Col>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='date'
                                                                data={this.servicedata}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />
                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'servicestats-rglr' : 'servicestats-exp' }>

                                                                                    <BootstrapTable
                                                                                        classes="expandTable serviceStats"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                    />

                                                                                </div>
                                                                            </PerfectScrollbar>
                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage && <PaginationListStandalone
                                                                                    {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(ServiceStats1));

