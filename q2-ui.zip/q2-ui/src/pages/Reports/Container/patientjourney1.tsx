import * as React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../store/actions';
import { Row, Col, FormGroup, Input, Container } from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { Scrollbars } from 'react-custom-scrollbars';
import BootstrapTable from 'react-bootstrap-table-next';
import './reports.css';
import paginationFactory, { PaginationProvider, PaginationListStandalone } from 'react-bootstrap-table2-paginator';
import DateTimeRangeContainer from 'react-advanced-datetimerange-picker';
import moment from 'moment';
import ToolkitProvider, { ColumnToggle } from 'react-bootstrap-table2-toolkit';
import Modal from 'react-modal';

export interface IProps {
    activateAuthLayout: any;
}
const { ToggleList } = ColumnToggle;

class PatientJourney1 extends React.Component<any, any> {
    constructor(props) {
        super(props);
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start)

        this.state = {
            showReportsData: false,
            start: start,
            end: end,
            modalOpen: false,
        };
        this.applyCallback = this.applyCallback.bind(this);
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    applyCallback(startdate, enddate) {
        this.setState({
            start: startdate,
            end: enddate
        })
    }
    showReportsData = () => {
        this.setState({ showReportsData: true })
    }
    rowEvents = {
        onClick: () => {
            this.toggleModal()
        }
    }
    toggleModal() {
        this.setState({ modalOpen: true });
    }

    deptOptions = [
        { label: "Branch1", value: "Branch1" },
        { label: "Branch2", value: "Branch2" },
        { label: "Branch3", value: "Branch3" },
        { label: "Branch4", value: "Branch4" }
    ];
    columns = [{
        dataField: 'date',
        text: 'Date',
        sort: true
    }, {
        dataField: 'mrn',
        text: 'MRN',
        sort: true
    }, {
        dataField: 'patientname',
        text: 'Patient Name',
        sort: true
    }, {
        dataField: 'checkin',
        text: 'Checkin',
        sort: true
    }, {
        dataField: 'age',
        text: 'Age',
        sort: true
    }, {
        dataField: 'gender',
        text: 'Gender',
        sort: true
    }
        , {
        dataField: 'ssn',
        text: 'SSN',
        sort: true
    }, {
        dataField: 'vip',
        text: 'VIP',
        sort: true
    }, {
        dataField: 'waitingtime',
        text: 'Waiting Time',
        sort: true,

    }, {
        dataField: 'caretime',
        text: 'Care Time',
        sort: true
    }, {
        dataField: 'transactiontime',
        text: 'Transaction Time',
        sort: true
    }, {
        dataField: 'firstcalltime',
        text: 'First Call Time',
        sort: true
    },
    ];

    tknrepotsData = [
        { id: 1, date: '01-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "30", age: "20", gender: "Male", ssn: "123456", vip: 'Yes', waitingtime: '20 min', caretime: "30 min", transactiontime: '30 min', firstcalltime: '30 min' },
        { id: 2, date: '02-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "25", age: "22", gender: "Male", ssn: "123457", vip: 'Yes', waitingtime: '20 min', caretime: "25 min", transactiontime: '25 min', firstcalltime: '25 min' },
        { id: 3, date: '03-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "23", age: "34", gender: "Male", ssn: "123458", vip: 'No', waitingtime: '20 min', caretime: "23 min", transactiontime: '23 min', firstcalltime: '23 min' },
        { id: 4, date: '04-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "25", age: "45", gender: "Male", ssn: "123459", vip: 'No', waitingtime: '20 min', caretime: "25 min", transactiontime: '25 min', firstcalltime: '25 min' },
        { id: 5, date: '05-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "30", age: "31", gender: "Female", ssn: "123460", vip: 'No', waitingtime: '20 min', caretime: "30 min", transactiontime: '30 min', firstcalltime: '30 min' },
        { id: 6, date: '06-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "25", age: "32", gender: "Male", ssn: "123461", vip: 'No', waitingtime: '20 min', caretime: "25 min", transactiontime: '25 min', firstcalltime: '25 min' },
        { id: 7, date: '07-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "23", age: "26", gender: "Male", ssn: "123462", vip: 'Yes', waitingtime: '20 min', caretime: "23 min", transactiontime: '23 min', firstcalltime: '23 min' },
        { id: 8, date: '08-07-2020', mrn: '123456789123', patientname: "Vivek", checkin: "25", age: "25", gender: "Female", ssn: "123463", vip: 'No', waitingtime: '20 min', caretime: "25 min", transactiontime: '25 min', firstcalltime: '25 min' }
    ]

    options = {
        custom: true,
        totalSize: this.tknrepotsData.length,
        sizePerPage: 5,
        hideSizePerPage: true,
        hidePageListOnlyOnePage: true
    };
    render() {
        let now = new Date();
        let start = moment(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0));
        let end = moment(start).add(1, "days").subtract(1, "seconds");
        let ranges = {};
        let local = {
            "format": "DD-MM-YYYY",
            "sundayFirst": false
        }
        let value = `${this.state.start.format('DD-MM-YYYY')} - ${this.state.end.format('DD-MM-YYYY')}`;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout reportsscroll">
                        <div className="flexLayout-inner">
                            <Scrollbars>
                                <div className="reports mt-2">
                                    <h4>Patient Journey</h4>
                                    <Row className="reportform">
                                        <Col sm="2">
                                            <FormGroup>
                                                <div className="mrn-search form-group">
                                                    <Input type="text" className="form-control" placeholder="Search MRN" id="example-text-input" />
                                                    <i className="fa fa-search"></i>
                                                </div>
                                            </FormGroup>
                                        </Col>

                                        <Col sm="3" className="w-18">
                                            <FormGroup>
                                                <DateTimeRangeContainer
                                                    start={this.state.start}
                                                    end={this.state.end}
                                                    local={local}
                                                    ranges={ranges}
                                                    smartMode
                                                    applyCallback={this.applyCallback}
                                                >
                                                <Input
                                                    id="formControlsTextB"
                                                    className="calendarIcon"
                                                    type="text"
                                                    label="Text"
                                                    value={value}
                                                    placeholder="Enter text"
                                                    onChange={this.applyCallback}

                                                />
                                                </DateTimeRangeContainer>
                                            </FormGroup>
                                        </Col>
                                        <div className="ml-3">
                                            <button className="btn btn-submit" type="submit" onClick={this.showReportsData}>
                                                Submit
                                            </button>
                                        </div>
                                    </Row>

                                    {this.state.showReportsData &&
                                        <>
                                            <PaginationProvider pagination={paginationFactory(this.options)}>
                                                {
                                                    ({
                                                        paginationProps,
                                                        paginationTableProps
                                                    }) => (
                                                            <ToolkitProvider keyField='date'
                                                                data={this.tknrepotsData}
                                                                columns={this.columns}
                                                                columnToggle>
                                                                {
                                                                    props => (
                                                                        <div className="toggle-headers">
                                                                            <ToggleList {...props.columnToggleProps} />
                                                                            <PerfectScrollbar>
                                                                                <div className={ Object.values(props.baseProps.columnToggle.toggles).filter(x => x == true).length <= 7 ? 'pjourney-rglr' : 'pjourney-exp' }>
                                                                                    <BootstrapTable
                                                                                        classes="expandTable ptJourneyTable"
                                                                                        wrapperClasses=""
                                                                                        bordered={false}
                                                                                        defaultSortDirection="asc"
                                                                                        {...paginationTableProps}
                                                                                        {...props.baseProps}
                                                                                        rowEvents={this.rowEvents} />

                                                                                </div>
                                                                            </PerfectScrollbar>
                                                                            <div className="btn-export mt-3">
                                                                                <button className="btn mr-3" type="button">Export to PDF</button>
                                                                                <button className="btn" type="button">Export to CSV</button>
                                                                                {this.options.totalSize > this.options.sizePerPage &&
                                                                                    <PaginationListStandalone  {...paginationProps} />
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                            </ToolkitProvider>
                                                        )}
                                            </PaginationProvider>
                                        </>
                                    }
                                </div>
                            </Scrollbars>
                        </div>
                    </div>
                    {this.state.modalOpen && <div>
                        <Modal isOpen={this.state.modalOpen} ariaHideApp={false} className="expandModal feedbackexpand">
                            <Row>
                                <Col className="text-right">
                                    <button onClick={() => this.setState({ modalOpen: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </Col>
                            </Row>
                            <div>
                                <PerfectScrollbar style={{ maxHeight: "350px" }}>
                                    <table>
                                        <thead>
                                            <tr>
                                                <td>Service</td>
                                                <td>Room No</td>
                                                <td>Start time</td>
                                                <td>End time</td>
                                                <td>Served by</td>
                                                <td>Status</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Serive1</td>
                                                <td>12</td><td>10.30 am</td><td>11.30 am</td>
                                                <td>Dr.Prathap</td><td>Active</td>
                                            </tr>
                                            <tr>
                                                <td>Serive1</td>
                                                <td>12</td><td>10.30 am</td><td>11.30 am</td>
                                                <td>Dr.Prathap</td><td>Active</td>
                                            </tr>
                                            <tr>
                                                <td>Serive1</td>
                                                <td>12</td><td>10.30 am</td><td>11.30 am</td>
                                                <td>Dr.Prathap</td><td>Active</td>
                                            </tr>
                                            <tr>
                                                <td>Serive1</td>
                                                <td>12</td><td>10.30 am</td><td>11.30 am</td>
                                                <td>Dr.Prathap</td><td>Active</td>
                                            </tr>
                                            <tr>
                                                <td>Serive1</td>
                                                <td>12</td><td>10.30 am</td><td>11.30 am</td>
                                                <td>Dr.Prathap</td><td>Active</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </PerfectScrollbar>
                            </div>
                        </Modal>
                    </div>}
                </Container>
            </>
        );
    }
}
export default withRouter(connect(null, { activateAuthLayout })(PatientJourney1));

