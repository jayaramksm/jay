import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { activateAuthLayout, getEpsLgsTZonesRequest, setResetForEnterprise, cancelAllPendingEnterpriseRequests } from '../../../store/actions';
import { SuperParentContext } from './enterprisecontext';
import {
    EnterpriseAction,
    EnterpriseFilter,
    EnterpriseManager,
    EnterpriseView,
    LeftEnterpriseParent,
    RightEnterpriseParent,
    EnterpriseItem,
    EnterpriseAutoRefresh
} from './enterpriseindex';
import { Container, Row, Col } from 'reactstrap';
import './EnterpriseAdmin.css';
import { IEpState } from '../../../models/enterpriseAdminModel';
import { getAutoRefresing, getautoRefreshTime } from '../../../helpers/helpersIndex';

interface IProps {
    activateAuthLayout: any;
    getEpsLgsTZonesRequest: any;
    setResetForEnterprise: any;
    enterpriseLoad: boolean;
    cancelAllPendingEnterpriseRequests: any;
}
class EnterpriseAdmin extends React.PureComponent<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);

        this.state = {
            leftEnterpriseParent: {
                filterComponent: EnterpriseFilter,
                listComponent: EnterpriseManager,
                viewComponent: EnterpriseItem,
                actions: { add: true }
            },
            rightEnterpriseParent: {
                viewComponent: EnterpriseView,
                actionComponent: EnterpriseAction,
                actions: { edit: true, status: true }
            }
        };
    }

    componentDidMount() {
        console.log("EnterpriseAdmin=>", this.props);
        this.props.setResetForEnterprise();
        this.props.activateAuthLayout();
        if (this.props.enterpriseLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getEpsLgsTZonesRequest(!this.props.enterpriseLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getEpsLgsTZonesRequest(!this.props.enterpriseLoad, true);

    }
    componentWillUnmount() {
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.cancelAllPendingEnterpriseRequests();
        this.props.setResetForEnterprise();
    }
    render() {
        return (
            <>
                {getAutoRefresing() && <EnterpriseAutoRefresh />}
                <Container fluid className="h-100">
                    <Row className="adminentp h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftEnterpriseParent}>
                                <LeftEnterpriseParent />
                            </SuperParentContext.Provider>
                        </Col>

                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightEnterpriseParent}>
                                <RightEnterpriseParent />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>
            </>
        )
    }
}
const mapStatetoProps = state => {
    if (getAutoRefresing() && state.enterpriseAdminReducer && (state.enterpriseAdminReducer as IEpState).enterpriseData)
        return { enterpriseLoad: (state.enterpriseAdminReducer as IEpState).enterpriseData.length > 0 ? true : false };
    else
        return { enterpriseLoad: false };
}

export default withRouter(connect(mapStatetoProps, { activateAuthLayout, getEpsLgsTZonesRequest, setResetForEnterprise, cancelAllPendingEnterpriseRequests })(EnterpriseAdmin));