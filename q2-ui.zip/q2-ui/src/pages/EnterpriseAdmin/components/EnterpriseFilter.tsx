import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../container/EnterpriseAdmin.css';
import { Row, Col, UncontrolledTooltip } from 'reactstrap';
import { ParentContext } from '../container/enterprisecontext';
import { setEpActionRequestData, setEpSearchKey } from '../../../store/actions';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';

const EnterpriseFilter: React.FC = () => {
    const context: any = useContext(ParentContext);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const actionArea = useSelector(state => {
        if (state && state.enterpriseAdminReducer)
            return state.enterpriseAdminReducer.actionType === IOprationalActions.ADD;
        else return false;
    });
    const filterActions = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.enterpriseData)
            return state.enterpriseAdminReducer.enterpriseData.length > 0;
        else return false;
    });
    const addEnterprise = () => {
        if (actionArea !== IOprationalActions.ADD)
            dispatch(setEpActionRequestData(IOprationalActions.ADD, null, false));
    }
    const setSearch = (key) => {
        dispatch(setEpSearchKey(key));
    }
    return (
        <>
            <Row className="roleslist">
                <Col className="pr-0"><h6 className="m-0">{t('Enterprise.listOfEp')}</h6></Col>
                {context.add && <div className="align-right pl-2 pr-3 addupload">
                    <button className="btn btn-out-dashed" id="add" disabled={actionArea} onClick={addEnterprise}>{t('ActionNames.add')} &nbsp;<span className="addbtn">+</span></button>
                    {!actionArea && <UncontrolledTooltip color="primary" placement="right" target="add">
                        {t('Enterprise.addEp')}
                    </UncontrolledTooltip>}
                </div>}
            </Row>

            {filterActions &&
                <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                    <input type="text" className="form-control w-100" placeholder={t('Enterprise.search')} onChange={e => setSearch(e.target.value)} />
                    <i className="fa fa-search"></i>
                </div>}
        </>
    )
}
export default EnterpriseFilter;