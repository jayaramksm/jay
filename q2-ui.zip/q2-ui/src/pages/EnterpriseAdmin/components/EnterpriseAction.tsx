import React, { useRef, useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Card, CardBody, Row, Col, FormGroup, Label } from 'reactstrap';
import '../container/EnterpriseAdmin.css';
import { useTranslation } from 'react-i18next';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { IEnterpriseModel, IEpLanguage, IEpTimezone, ILicenseResponse, ILogoResponse } from '../../../models/enterpriseAdminModel';
import { controleContentValidate, customContentValidation, MySelect } from '../../../helpers/helpersIndex';
import { IOprationalActions, IAlertMessagedata } from '../../../models/utilitiesModel';
import { createOrEditEnterpriseRequest, uploadEpLicenseRequest, uploadEpLogoRequest, suspendOrEditEpAction, alertActionRequest } from '../../../store/actions';
// import logo from "../../../images/SSMC_logo.svg";
import { fromByteArray } from 'base64-js';

let convertBase64ImgLogo: any;

const EnterpriseAction: React.FC = () => {

    const [state, setState] = useState({
        uploadedFile: null,
        invalidFileExtensionError: '',
        uploadedLogo: null,
        invalidLogoExtensionError: ''
    } as any);
    const uploadLogoRef = useRef<any>(null);
    const uploadFileRef = useRef<any>(null);
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");

    const actionArea = useSelector(state => {
        if (state && state.enterpriseAdminReducer)
            return state.enterpriseAdminReducer.actionType;
        else return undefined;
    });

    const epActionData: IEnterpriseModel = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.actionData)
            return state.enterpriseAdminReducer.actionData;
        else return undefined;
    });

    const languageOptions = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.languagesData)
            return (state.enterpriseAdminReducer.languagesData as IEpLanguage[]).map(item => ({ value: item.id, label: item.language }));
        else return undefined;
    });

    const timeZoneOptions = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.timezonesData)
            return (state.enterpriseAdminReducer.timezonesData as IEpTimezone[]).map(item => ({ value: item.id, label: item.countryName }));
        else return undefined;
    });

    const licenseUploadedResponse: ILicenseResponse = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.licenseUploadResponse)
            return (state.enterpriseAdminReducer.licenseUploadResponse as ILicenseResponse);
        else return undefined;
    });

    const logoPath = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.logoUploadRespone)
            return (state.enterpriseAdminReducer.logoUploadRespone as ILogoResponse).filePath;
        else return '';
    });
    const logoData = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.logoUploadRespone)
            return (state.enterpriseAdminReducer.logoUploadRespone as ILogoResponse).logo;
        else return '';
    });
    console.log("EnterpriseAction_logoPath =>", logoPath, logoData);
    const initialValues = () => ({
        enterpriseId: epActionData ? epActionData.enterpriseId : 0,
        enterpriseNameEn: epActionData ? epActionData.enterpriseNameEn : '',
        enterpriseNameAr: epActionData ? epActionData.enterpriseNameAr : '',
        timeZoneId: epActionData ? (epActionData.timeZoneId ? timeZoneOptions.find(x => x.value === epActionData.timeZoneId) : '') : '',
        languageId: epActionData ? (epActionData.languageId ? languageOptions.find(x => x.value === epActionData.languageId) : '') : '',
    });
    const validationSchema = Yup.object().shape({
        enterpriseNameEn: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
        enterpriseNameAr: customContentValidation(t, t('controleErrors.required'), { patternType: 'arabicnumaricspacesp', message: 'arabicnumaricspace', spacialChar: null }, 50, 2),
        timeZoneId: controleContentValidate(t('controleErrors.required')).ensure().nullable(),
        languageId: controleContentValidate(t('controleErrors.required')).ensure().nullable()
    });

    const timeZoneSelection = (e, setFieldValue) => {
        setFieldValue('timeZoneId', e);
    }

    const languageSelection = (e, setFieldValue) => {
        setFieldValue('languageId', e);
    }

    const uploadLicense = (event) => {
        if (event.target) {
            let uploadedFile = event.target.files[0];

            if (uploadedFile) {
                let extension = (uploadedFile && uploadedFile.name as string).split('.').pop();
                if (extension !== 'l4j')
                    setState({ ...state, uploadedFile: null, invalidFileExtensionError: 'Please Select Only l4j files' });
                else if (extension === 'l4j')
                    setState({ ...state, invalidFileExtensionError: '', uploadedFile: uploadedFile });
            }
        }
    }

    const uploadEpLogo = (event) => {
        if (event.target) {
            let uploadedLogo = event.target.files[0];

            if (uploadedLogo) {
                let extension = (uploadedLogo && uploadedLogo.name as string).split('.').pop();

                if (extension === 'jpg' || extension === 'png')
                    setState({ ...state, invalidLogoExtensionError: '', uploadedLogo: uploadedLogo });
                else
                    setState({ ...state, uploadedLogo: null, invalidLogoExtensionError: 'Please Select Only Jpg files' });
            }
        }
    }

    const sendUploadedFile = () => {
        if (state.uploadedFile) {
            dispatch(uploadEpLicenseRequest(state.uploadedFile));
            cancelUploadedFile();
        }
    }

    const cancelUploadedFile = () => {
        if (uploadFileRef && uploadFileRef.current && uploadFileRef.current.value)
            uploadFileRef.current.value = '';
        setState({ ...state, uploadedFile: null, invalidFileExtensionError: '' });
    }

    const sendUploadedLogo = () => {
        if (state.uploadedLogo) {
            dispatch(uploadEpLogoRequest(state.uploadedLogo));
            cancelUploadedLogo();
        }
    }

    const cancelUploadedLogo = () => {
        if (uploadLogoRef && uploadLogoRef.current && uploadLogoRef.current.value)
            uploadLogoRef.current.value = '';
        setState({ ...state, uploadedLogo: null, invalidLogoExtensionError: '' });
    }

    const cancelEdit = () => {
        dispatch(suspendOrEditEpAction(actionArea === IOprationalActions.EDIT ? IOprationalActions.SELECT : IOprationalActions.UNSELECT));
    }

    if (logoData)
        convertBase64ImgLogo = fromByteArray(logoData);
    console.log("EnterpriseView =>useEffect ", convertBase64ImgLogo);
    useEffect(() => {
        return () => {
            if (convertBase64ImgLogo)
                convertBase64ImgLogo = undefined;
        }
    }, []);

    return (
        <>
        <div>
            <Card className="mb-2 ml-2">
                <CardBody>
                    <Formik
                        enableReinitialize
                        initialValues={initialValues()}
                        validationSchema={validationSchema}
                        onSubmit={(values) => {
                            if (actionArea === IOprationalActions.ADD && !licenseUploadedResponse) {
                                let alertMessageData: IAlertMessagedata = {
                                    message: t('Enterprise.uploadLicenceLabel'),
                                    status: false,
                                    tranId: Date.now()
                                }

                                dispatch(alertActionRequest(alertMessageData));
                            }
                            else {
                                values.languageId = values.languageId.value;
                                values.timeZoneId = values.timeZoneId.value;
                                dispatch(createOrEditEnterpriseRequest(actionArea, values, licenseUploadedResponse, logoPath, logoData));
                            }
                        }}
                    >
                        {({ errors, touched, values, dirty, setFieldTouched, setFieldValue }) => (
                            <Form>
                                <Row>
                                    <Col sm="12">
                                        <Row className="FormStyle">
                                            <Col sm="6">
                                                <div className="form-group">
                                                    <Field placeholder={t('Enterprise.enterpriseEngName')} name="enterpriseNameEn" className={'form-control ' + (errors.enterpriseNameEn && touched.enterpriseNameEn ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="enterpriseNameEn" component="div" className="invalid-feedback" />
                                                    <Label className="label">{t('Enterprise.enterpriseEngName')}</Label>
                                                </div>
                                            </Col>
                                            <Col className="text-right align-right" sm="6">
                                                <div className="form-group">
                                                    <Field placeholder={t('Enterprise.enterpriseArbName')} name="enterpriseNameAr" className={'form-control text-right ' + (errors.enterpriseNameAr && touched.enterpriseNameAr ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="enterpriseNameAr" component="div" className="invalid-feedback" />
                                                    <Label className="label">{t('Enterprise.enterpriseArbName')}</Label>
                                                </div>
                                            </Col>

                                        </Row>

                                        {/* {actionArea !== IOprationalActions.ADD && <Col sm="2" className="align-center" style={{ direction: 'rtl' }}>
                                                <Switch uncheckedIcon={<Offsymbol />}
                                                    checkedIcon={<OnSymbol />} onColor="#02a499"
                                                    onChange={() => { }} checked={false} />
                                            </Col>} */}
                                    </Col>
                                </Row>

                                <hr />

                                <Row>
                                    <Col sm="4">
                                        <div>
                                            <Label className="label">{t('Enterprise.timezone')}</Label>
                                            <MySelect
                                                name="timeZoneId"
                                                placeholder={t('Enterprise.selectTimezone')}
                                                value={values.timeZoneId}
                                                onChange={(e) => timeZoneSelection(e, setFieldValue)}
                                                options={timeZoneOptions}
                                                getOptionLabel={option => option.label}
                                                getOptionValue={option => option.value}
                                                onBlur={() => setFieldTouched('timeZoneId', true)}
                                                noOptionsMessage={() => t('Enterprise.noTimezones')}
                                            />
                                            {errors.timeZoneId && touched.timeZoneId && (
                                                <div className="error-msg">{errors.timeZoneId}</div>
                                            )}
                                        </div>
                                    </Col>
                                    <Col sm="4">
                                        <div>
                                            <Label className="label">{t('Enterprise.language')}</Label>
                                            <MySelect
                                                name="languageId"
                                                placeholder={t('Enterprise.selectLanguage')}
                                                value={values.languageId}
                                                onChange={(e) => languageSelection(e, setFieldValue)}
                                                options={languageOptions}
                                                getOptionLabel={option => option.label}
                                                getOptionValue={option => option.value}
                                                onBlur={() => setFieldTouched('languageId', true)}
                                                noOptionsMessage={() => t('Enterprise.noLanguages')}
                                            />
                                            {errors.languageId && touched.languageId && (
                                                <div className="error-msg">{errors.languageId}</div>
                                            )}
                                        </div>
                                    </Col>

                                </Row>

                                <hr />

                                <Row>
                                    <Col sm="4">
                                        <FormGroup className="upload-logo">
                                            <Label className="label">{t('Enterprise.uploadEpLogo')}</Label><br />

                                            {!state.uploadedLogo && <><label htmlFor="logo" className="btn btn-primary">{t('Enterprise.uploadLogo')}</label><br /><span>Eg: .png,.jpg</span>

                                                <input ref={uploadLogoRef} type="file" accept=".jpg,.png" onChange={e => uploadEpLogo(e)} id="logo" style={{ visibility: 'hidden' }} />
                                                {(logoData && logoData !== '') && <img src={"data:image;base64," + convertBase64ImgLogo} alt="logo" />}</>}

                                            {state.uploadedLogo && <span>{state.uploadedLogo['name']}</span>}
                                            {state.invalidLogoExtensionError && <span className="d-block error-msg mt-0">{state.invalidLogoExtensionError}</span>}
                                            {/* 
                                            <div className="mt-1 mb-1"><img src={logo} alt="logo" /></div> */}

                                            {state.uploadedLogo && <div className="mt-2">
                                                <button className="btn btn-success" onClick={sendUploadedLogo} disabled={(state.invalidLogoExtensionError !== '' || !state.uploadedLogo)}>
                                                    {t('Enterprise.uploadProceed')}
                                                </button>&nbsp;&nbsp;
                                                    <button className="btn btn-cancel" onClick={cancelUploadedLogo}>
                                                    {t('Enterprise.cancel')}
                                                </button>
                                            </div>}
                                        </FormGroup>
                                    </Col>
                                    <Col sm="4">
                                        <FormGroup>
                                            <Label className="label">{t('Enterprise.uploadLicence')}</Label><br />

                                            {!state.uploadedFile && <><label htmlFor="files" className="btn btn-primary">{t('Enterprise.browse')}</label><br /><span>Eg: .l4j</span>
                                                <input ref={uploadFileRef} type="file" accept=".l4j" onChange={e => uploadLicense(e)} id="files" style={{ visibility: 'hidden' }} /></>}

                                            {state.uploadedFile && <span>{state.uploadedFile['name']}</span>}
                                            {state.invalidFileExtensionError && <span className="d-block error-msg mt-0">{state.invalidFileExtensionError}</span>}

                                            {state.uploadedFile && <div className="mt-2">
                                                <button className="btn btn-success" onClick={sendUploadedFile} disabled={(state.invalidFileExtensionError !== '' || !state.uploadedFile)}>
                                                    {t('Enterprise.uploadProceed')}
                                                </button>&nbsp;&nbsp;
                    <button className="btn btn-cancel" onClick={cancelUploadedFile}>
                                                    {t('Enterprise.cancel')}
                                                </button>
                                            </div>}
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <hr />
                                {/* || actionArea === IOprationalActions.EDIT */}
                                {(licenseUploadedResponse) && <><Row>
                                    <Col>
                                        <table className="table">
                                            <tbody>
                                                <tr>
                                                    <th>{t('Enterprise.licenseNumber')}</th>
                                                    <th>{t('Enterprise.activationDate')}</th>
                                                    <th>{t('Enterprise.expiryDate')}</th>
                                                </tr>
                                                <tr className="blue">
                                                    <td>{licenseUploadedResponse ? licenseUploadedResponse.licneseNumber : (epActionData ? epActionData.licenseInfo.licneseNumber : '')}</td>
                                                    <td>{licenseUploadedResponse ? licenseUploadedResponse.licenseActivationDate : (epActionData ? epActionData.licenseInfo.licenseActivationDate : '')}</td>
                                                    <td>{licenseUploadedResponse ? licenseUploadedResponse.licenseExpireDate : (epActionData ? epActionData.licenseInfo.licenseExpireDate : '')}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </Col>
                                </Row>

                                    <Row>
                                        <Col>
                                            <table className="table">
                                                <tbody>
                                                    <tr>
                                                        <th>{t('Enterprise.noOfFacilities')}</th>
                                                        <th>{t('Enterprise.noOfBranches')}</th>
                                                        <th>{t('Enterprise.noOfDoctors')}</th>
                                                    </tr>
                                                    <tr>
                                                        <td className="green">{licenseUploadedResponse ? licenseUploadedResponse.noOfFacilities : (epActionData ? epActionData.licenseInfo.noOfFacilities : '')}</td>
                                                        <td className="green">{licenseUploadedResponse ? licenseUploadedResponse.noOfBranches : (epActionData ? epActionData.licenseInfo.noOfBranches : '')}</td>
                                                        <td className="green">{licenseUploadedResponse ? licenseUploadedResponse.noOfDoctors : (epActionData ? epActionData.licenseInfo.noOfDoctors : '')}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </Col>
                                    </Row></>}

                                <Row>
                                    <Col className="action">
                                        {!epActionData && <button type="submit" className="btn btn-primary" disabled={!(dirty)}>{t('ActionNames.save')}</button>}
                                        {epActionData && <button type="submit" className="btn btn-primary" disabled={!(!!licenseUploadedResponse || !!logoPath || dirty)}>{t('ActionNames.update')}</button>}
                                        <button type="button" className="btn btn-cancel ml-2" onClick={cancelEdit}>
                                            {t('ActionNames.cancel')}
                                        </button>
                                    </Col>
                                </Row>
                            </Form>
                        )}
                    </Formik>

                </CardBody>
            </Card>
            </div>
        </>
    )
}
export default EnterpriseAction;