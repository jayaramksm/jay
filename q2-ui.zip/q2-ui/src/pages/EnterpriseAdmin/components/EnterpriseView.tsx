import React, { useContext, useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, Card, CardBody, UncontrolledTooltip, Label } from 'reactstrap';
import Switch from "react-switch";
import '../container/EnterpriseAdmin.css';
import { ParentContext } from '../container/enterprisecontext';
import { IEnterpriseModel, IEpTimezone, IEpLanguage } from '../../../models/enterpriseAdminModel';
import { useTranslation } from 'react-i18next';
import { suspendOrEditEpAction, setEnterpriseActiveStatusRequest } from '../../../store/actions';
import { IOprationalActions, IStatusEnum } from '../../../models/utilitiesModel';
import { fromByteArray } from 'base64-js';

let convertBase64ImgLogo: any;

const EnterpriseView: React.FC = () => {
    const context: any = useContext(ParentContext);
    const [toggleState, setToggleState] = useState(true);
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");

    const epActionData: IEnterpriseModel = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.actionData)
            return state.enterpriseAdminReducer.actionData;
        else return undefined;
    });
    console.log("EnterpriseView =>1", epActionData);

    const timeZoneData = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.timezonesData)
            return (state.enterpriseAdminReducer.timezonesData as IEpTimezone[]);
        else return undefined;
    });

    const languagesData = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.languagesData)
            return (state.enterpriseAdminReducer.languagesData as IEpLanguage[]);
        else return undefined;
    });

    const editEp = () => {
        dispatch(suspendOrEditEpAction(IOprationalActions.EDIT));
    }

    if (epActionData.logo)
        convertBase64ImgLogo = fromByteArray(epActionData.logo);
    console.log("EnterpriseView =>useEffect ", convertBase64ImgLogo);
    useEffect(() => {
        return () => {
            if (convertBase64ImgLogo)
                convertBase64ImgLogo = undefined;
        }
    }, []);

    return (
        <>
            {epActionData &&
                <div>
                    <Card className="mb-2 ml-2">
                        <CardBody>
                            <Row>
                                <Col sm="12">
                                    <Row className="FormStyle">
                                        <Col sm="10">
                                            <Row>
                                                <Col sm="4">
                                                    <Label>{t('Enterprise.enterpriseEngName')}</Label>
                                                    <br />
                                                    <span>{epActionData.enterpriseNameEn}</span>
                                                </Col>
                                                <Col sm="4">
                                                    <Row className="align-right">
                                                        <Label>{t('Enterprise.enterpriseArbName')}</Label>
                                                    </Row>
                                                    <Row className="align-right">
                                                        <span>{epActionData.enterpriseNameAr}</span>
                                                    </Row>
                                                </Col>
                                                <Col>
                                                    <Label>{t('Enterprise.timezone')}</Label><br />
                                                    <span>{timeZoneData && timeZoneData.find(x => x.id === epActionData.timeZoneId)?.countryName}</span>
                                                </Col>
                                                <Col>
                                                    <Label>{t('Enterprise.language')}</Label><br />
                                                    <span>{languagesData && languagesData.find(x => x.id === epActionData.languageId)?.language}</span>
                                                </Col>
                                            </Row>
                                        </Col>
                                        {context.status && toggleState && <Col sm="2" className="align-center" style={{ direction: 'rtl' }}>
                                            <Switch
                                                uncheckedIcon={<Offsymbol />}
                                                checkedIcon={<OnSymbol />}
                                                onColor="#02a499"
                                                onChange={(e) => {
                                                    let updatedStatus = e === true ? IStatusEnum.NACTIVE : IStatusEnum.NINACTIVE;
                                                    const confirmMessage = t('Enterprise.confirmMessages.EC2').replace('{enterprise}', epActionData.enterpriseNameEn).replace('{status}', epActionData.isActive === IStatusEnum.NACTIVE ? t('ActionNames.deactivate') : t('ActionNames.activate'));
                                                    dispatch(setEnterpriseActiveStatusRequest(epActionData.enterpriseId, updatedStatus, false, confirmMessage));
                                                    setTimeout(() => {
                                                        setToggleState(false);
                                                        setToggleState(true);
                                                    }, 1000);
                                                }}
                                                checked={epActionData.isActive === IStatusEnum.NACTIVE ? true : false} />
                                        </Col>}
                                    </Row>
                                </Col>
                            </Row>

                            <hr />

                            <Row>
                                <Col sm="4" className="upload-logo">
                                    <span>{t('Enterprise.uploadEpLogo')}</span><br />
                                    {(epActionData.logo && epActionData.logo !== '' && epActionData.logo.length > 0) && <img alt="logo" src={"data:image;base64," + convertBase64ImgLogo} />}
                                    {!(epActionData.logo && epActionData.logo !== '' && epActionData.logo.length > 0) && <span> {t('Enterprise.noFoundForLogo')} </span>}
                                </Col>
                            </Row>

                            <hr />

                            {epActionData?.licenseInfo && <><Row>
                                <Col>
                                    <table className="table">
                                        <tbody>
                                            <tr>
                                                <th>{t('Enterprise.licenseNumber')}</th>
                                                <th>{t('Enterprise.activationDate')}</th>
                                                <th>{t('Enterprise.expiryDate')}</th>
                                            </tr>
                                            <tr className="blue">
                                                <td>{epActionData.licenseInfo.licneseNumber}</td>
                                                <td>{epActionData.licenseInfo.licenseActivationDate}</td>
                                                <td>{epActionData.licenseInfo.licenseExpireDate}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </Col>
                            </Row>

                                <Row>
                                    <Col>
                                        <table className="table">
                                            <tbody>
                                                <tr>
                                                    <th>{t('Enterprise.noOfFacilities')}</th>
                                                    <th>{t('Enterprise.noOfBranches')}</th>
                                                    <th>{t('Enterprise.noOfDoctors')}</th>
                                                </tr>
                                                <tr>
                                                    <td className="green">{epActionData.licenseInfo.noOfFacilities}</td>
                                                    <td className="green">{epActionData.licenseInfo.noOfBranches}</td>
                                                    <td className="orange">{epActionData.licenseInfo.noOfDoctors}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </Col>
                                </Row></>}

                            <Row>
                                <Col className="action">
                                    {(context.edit && epActionData.isActive === IStatusEnum.NACTIVE) && <>
                                        <i id="edit" className="ti-pencil-alt" onClick={editEp}></i>
                                        <UncontrolledTooltip color="primary" placement="top" target="edit">
                                            {t('ActionNames.edit')}
                                        </UncontrolledTooltip>
                                    </>}
                                    {/* <i className="ti-trash"></i> */}
                                    {/* <button type="button" className="btn btn-border">Cancel</button> */}
                                </Col>
                            </Row>

                        </CardBody>
                    </Card>
                </div>}
        </>
    )
}

const Offsymbol = props => {
    return (
        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
                fontSize: 12,
                color: "#fff",
                paddingRight: 2
            }} >
        </div>
    );
};

const OnSymbol = props => {
    return (
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: 12,
            color: "#fff",
            paddingRight: 2
        }}>
        </div>
    );
}
export default EnterpriseView;