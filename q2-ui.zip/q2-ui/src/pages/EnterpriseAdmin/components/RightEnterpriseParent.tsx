import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import '../container/EnterpriseAdmin.css';
import { SuperParentContext, ParentContext } from '../container/enterprisecontext';
import { IOprationalActions } from '../../../models/utilitiesModel';

const RightEnterpriseParent: React.FC = () => {
    const context: any = useContext(SuperParentContext);
    const actionArea = useSelector(state => {
        if (state && state.enterpriseAdminReducer)
            return state.enterpriseAdminReducer.actionType;
        else return undefined;
    });

    return (
        <>

            <div className="flexLayout-inner mb-0">

                {(actionArea === IOprationalActions.ADD || actionArea === IOprationalActions.EDIT) && <context.actionComponent />}
                {actionArea === IOprationalActions.SELECT && <ParentContext.Provider value={context.actions}>
                    <context.viewComponent />
                </ParentContext.Provider>}

            </div>

        </>
    )
}
export default RightEnterpriseParent;