import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../container/EnterpriseAdmin.css';
import { ChildContext } from '../container/enterprisecontext';
import { IEnterpriseModel, IEpState } from '../../../models/enterpriseAdminModel';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { setEpActionRequestData, suspendOrEditEpAction } from '../../../store/actions';

const EnterpriseItem: React.FC = () => {
    const context = useContext(ChildContext);
    const dispatch = useDispatch();
    let enterpriseData: IEnterpriseModel = useSelector(state => {
        if (state && state.enterpriseAdminReducer) {
            let data = state.enterpriseAdminReducer.enterpriseData as IEnterpriseModel[];
            let index = data.findIndex(x => x.enterpriseId === context);

            if (index !== -1)
                return state.enterpriseAdminReducer.enterpriseData[index];
            else return undefined;
        }
        else return undefined;
    });
    const selectedEp = useSelector(state => {
        if (state && state.enterpriseAdminReducer) {
            return (state.enterpriseAdminReducer as IEpState).actionData ?
                ((state.enterpriseAdminReducer as IEpState).actionData as IEnterpriseModel).enterpriseId === enterpriseData.enterpriseId : false;
        }
        else return false;
    })
    return (
        <>
            {enterpriseData &&
                <span className={'btn btn-sm ' + (enterpriseData.isActive ? 'active ' : 'inactive ') + (selectedEp ? 'activeList' : '')} onClick={() => dispatch(selectedEp ? suspendOrEditEpAction(IOprationalActions.UNSELECT) : setEpActionRequestData(IOprationalActions.SELECT, enterpriseData, false))}>
                    {enterpriseData.enterpriseNameEn}
                </span>
            }
        </>
    )
}
export default EnterpriseItem;