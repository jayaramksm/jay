import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import '../container/EnterpriseAdmin.css';
import { IEnterpriseModel } from '../../../models/enterpriseAdminModel';
import { useTranslation } from 'react-i18next';
import { Row, Col } from 'reactstrap';
// import * as _ from 'lodash';
import { ChildContext, ParentContext } from '../container/enterprisecontext';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { PaginationComponent } from '../../Utilities/PaginationComponent';

const EnterpriseManager: React.FC = () => {
    const context = useContext<any>(ParentContext);
    const { t } = useTranslation("translations");
    const pageSize = getEnvironment.listPageSize;
    const searchKey = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.enterpriseData) {
            if (state.enterpriseAdminReducer.searchKey)
                return state.enterpriseAdminReducer.searchKey;
            else
                return ''
        }
        else
            return ''

    });
    const enterpriseTData: IEnterpriseModel[] = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.enterpriseData) {
            // if (state.enterpriseAdminReducer.searchKey)
            //     searchKey = state.enterpriseAdminReducer.searchKey;

            let data = state.enterpriseAdminReducer.enterpriseData;
            // if (searchKey && searchKey != '') {
            //     data = data.filter(x => x.enterpriseNameEn.toLowerCase().startsWith(searchKey.toLowerCase()));
            // }
            // if (data.length > 0)
            //     data = _.map(data, y => _.pick(y, ['enterpriseId']));
            return data;
        }
        else return undefined;
    });
    const enterpriseData: IEnterpriseModel[] = (searchKey && searchKey !== '') ?
        enterpriseTData.filter(x => x.enterpriseNameEn.toLowerCase().startsWith(searchKey.toLowerCase())) : enterpriseTData;

    let enterpriseCount = useSelector(state => {
        if (state && state.enterpriseAdminReducer && state.enterpriseAdminReducer.enterpriseData)
            return state.enterpriseAdminReducer.enterpriseData.length;
        else return 0;
    });
    console.log('enterpriseCount => ', enterpriseCount);

    let pagesCount = Math.ceil((enterpriseData ? enterpriseData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }

    return (
        <>
            {enterpriseData && enterpriseData.length === 0 && searchKey && <span className="recdnotfound">{t('Enterprise.noResults')}</span>}
            {enterpriseData && enterpriseData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('Enterprise.noEps')}</span>}

            <div className="flexLayout">
                <div className="flexLayout-inner">
                    <Row>
                        <Col sm="12" className="actn-list">
                            {enterpriseData && enterpriseData.length > 0 && enterpriseData.slice(currentPage * pageSize,
                                (currentPage + 1) * pageSize).map((item, index) => (
                                    <ChildContext.Provider key={index} value={item.enterpriseId}>
                                        <context.viewComponent />
                                    </ChildContext.Provider>
                                ))}
                        </Col>
                    </Row>
                </div>
                <Row className=" lft-pagination">
                    {enterpriseData && enterpriseData.length > pageSize &&
                        <div className="pagination ml-3">
                            <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                        </div>
                    }
                </Row>
            </div>

        </>
    )
}
export default EnterpriseManager;