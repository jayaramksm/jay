import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getEpsLgsTZonesRequest } from '../../../store/actions';
import { IEpState } from '../../../models/enterpriseAdminModel';
import { useTranslation } from 'react-i18next';
import {UncontrolledTooltip} from 'reactstrap';

export const EnterpriseAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const refreshLoading = useSelector(state => {
        if (state && state.enterpriseAdminReducer)
            return (state.enterpriseAdminReducer as IEpState).refreshLoading;
        else
            return false;
    })
    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="Etooltip" onClick={() => dispatch(getEpsLgsTZonesRequest(true, true))}></i>
            <UncontrolledTooltip color="primary" placement="top" target="Etooltip">
             {t('ActionNames.autoRefresh')}    
             </UncontrolledTooltip></>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}