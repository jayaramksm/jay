import * as React from 'react';
import { activateAuthLayout, getLocationsRequest, cancelPendingLocationRequests, setResetForLocations } from '../../../store/actions';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import {
    LocationAddComponent,
    LocationAction,
    LocationView,
    ManagerParent,
    LocationItem,
    LocationAutoRefresh
} from './locationindex';
import { SuperParentContext } from './locationcontext';
import './location.css';
import { IActions } from '../../../models/utilitiesModel';
import { ILocationState } from '../../../models/locationsModel';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../helpers/helpersIndex';

export interface IProps {
    activateAuthLayout: any;
    getLocationsRequest: any;
    cancelPendingLocationRequests: any;
    setResetForLocations: any;
    locationsLoad: any;
    add: boolean;
    edit: boolean;
    status: boolean;
}
class Location extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props)
        this.state = {
            managerParent: {
                addComponent: LocationAddComponent,
                viewComponent: LocationView,
                actionComponent: LocationAction,
                itemComponent: LocationItem,
                actions: { add: this.props.add, edit: this.props.edit, status: this.props.status }
            }
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForLocations();
        if (this.props.locationsLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getLocationsRequest(!this.props.locationsLoad);
            }, getautoRefreshTime());
        }
        else
            this.props.getLocationsRequest(!this.props.locationsLoad);

    }

    componentWillUnmount() {
        this.props.cancelPendingLocationRequests();
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForLocations();
    }

    render() {
        return (
            <>
                {getAutoRefresing() && <LocationAutoRefresh />}
                <Container fluid className="h-100">
                    <SuperParentContext.Provider value={this.state.managerParent}>
                        <ManagerParent />
                    </SuperParentContext.Provider>
                </Container>
            </>
        );
    }
}
const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'status'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'location', defaultPrivilages);
    if (getAutoRefresing() && state.locationReducer && (state.locationReducer as ILocationState).locationsData)
        return {
            locationsLoad: (state.locationReducer as ILocationState).locationsData.length > 0 ? true : false,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            status: privileges.includes(IActions.STATUS)
        };
    else
        return {
            locationsLoad: false, loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            status: privileges.includes(IActions.STATUS)
        };
}
export default (connect(mapStatetoProps, { activateAuthLayout, getLocationsRequest, cancelPendingLocationRequests, setResetForLocations })(Location));