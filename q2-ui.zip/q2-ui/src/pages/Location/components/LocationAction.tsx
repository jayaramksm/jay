import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Collapse, Label, Card, CardBody } from 'reactstrap';
import { ChildContext } from '../container/locationcontext';
import '../container/location.css';
import { useTranslation } from 'react-i18next';
import { ILocation } from '../../../models/locationsModel';
import { createOrUpdateLocationRequest, setLocationActionId } from '../../../store/actions';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { customContentValidation } from '../../../helpers/helpersIndex';
import { IOprationalActions, IStatusEnum } from '../../../models/utilitiesModel';

const LocationAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context: ILocation = useContext<any>(ChildContext)?.data;

    let locationItemData: ILocation = useSelector(state => {
        if (state && state.locationReducer && state.locationReducer.locationsData) {
            let data = state.locationReducer.locationsData as ILocation[];
            let index = data?.findIndex(x => x.locationId === context.locationId);

            if (index !== -1)
                return state.locationReducer.locationsData[index] as ILocation;
            else return undefined;
        }
        else return undefined;
    });
    const actionType = useSelector(state => {
        if (state && state.locationReducer)
            return state.locationReducer.actionType ? state.locationReducer.actionType : IOprationalActions.UNSELECT;
        else return IOprationalActions.UNSELECT;
    });

    const getInitialValues = () => ({
        locationId: locationItemData ? locationItemData.locationId : 0,
        locationNameEn: locationItemData ? locationItemData.locationNameEn : '',
        locationNameAr: locationItemData ? locationItemData.locationNameAr : '',
        locationIdentfier: locationItemData ? locationItemData.locationIdentfier : '',
        locationAddress: locationItemData ? locationItemData.locationAddress : '',
        status: locationItemData ? locationItemData.status : IStatusEnum.NINACTIVE
    });
    const validationSchema = Yup.object().shape({
        locationNameEn: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
        locationNameAr: customContentValidation(t, t('controleErrors.required'), { patternType: 'arabicnumaricspacesp', message: 'arabicnumaricspace', spacialChar: null }, 50, 2),
        locationIdentfier: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 10, 2),
        locationAddress: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2)
    });

    const cancelEdit = () => dispatch(setLocationActionId(-1, 0));

    return (
        <>

            <div className={actionType !== IOprationalActions.ADD ? 'customCard' : ''}>
                <Card>
                    <CardBody>
                        <Collapse isOpen={true} className="CardColpsCnt" style={{ position: "absolute" }}>
                            <div style={{ marginBottom: "-50px" }}>
                                <div className="text-right mb-2" >
                                    <i className="ti-close pointer" onClick={cancelEdit}></i>
                                </div>
                                <Formik
                                    enableReinitialize
                                    initialValues={getInitialValues()}
                                    validationSchema={validationSchema}
                                    onSubmit={values => {
                                        dispatch(createOrUpdateLocationRequest(values));
                                    }}
                                >
                                    {({ errors, touched, dirty, setFieldValue }) => (
                                        <Form>
                                            <div className="form-group">
                                                <Label>{t('Location.locationEngName')}</Label>
                                                <Field placeholder={t('Location.locationEngName')} name="locationNameEn" type="text" className={'form-control ' + (errors.locationNameEn && touched.locationNameEn ? 'is-invalid' : '')} />
                                                <ErrorMessage name="locationNameEn" component='div' className="invalid-feedback" />
                                            </div>
                                            <div className="form-group text-right">
                                                <Label className="align-right">{t('Location.locationArbName')}</Label>
                                                <Field placeholder={t('Location.locationArbName')} name="locationNameAr" type="text" className={'form-control ' + (errors.locationNameAr && touched.locationNameAr ? 'is-invalid' : '')} />
                                                <ErrorMessage name="locationNameAr" component='div' className="invalid-feedback" />
                                            </div>
                                            <div className="form-group">
                                                <Label>{t('Location.locationPrefix')}</Label>
                                                <Field placeholder={t('Location.locationPrefix')} name="locationIdentfier" type="text" className={'form-control ' + (errors.locationIdentfier && touched.locationIdentfier ? 'is-invalid' : '')} />
                                                <ErrorMessage name="locationIdentfier" component='div' className="invalid-feedback" />
                                            </div>
                                            <div className="form-group">
                                                <Label>{t('Location.locationAddrs')}</Label>
                                                <Field as="textarea" placeholder={t('Location.locationAddrs')} name="locationAddress" type="text" className={'form-control ' + (errors.locationAddress && touched.locationAddress ? 'is-invalid' : '')} />
                                                <ErrorMessage name="locationAddress" component='div' className="invalid-feedback" />
                                            </div>

                                            <button type="submit" disabled={!(dirty)} className="btn btn-primary mb-5">
                                                {actionType === IOprationalActions.ADD ? t('ActionNames.save') : t('ActionNames.update')}
                                            </button>
                                        </Form>
                                    )}
                                </Formik>
                            </div>
                        </Collapse>
                    </CardBody>
                </Card>
            </div>
        </>
    )
}
export default React.memo(LocationAction);