import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getLocationsRequest } from '../../../store/actions';
import { ILocationState } from '../../../models/locationsModel';
import { useTranslation } from 'react-i18next';
import {UncontrolledTooltip} from 'reactstrap';
export const LocationAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const refreshLoading = useSelector(state => {
        if (state && state.locationReducer)
            return (state.locationReducer as ILocationState).refreshLoading;
        else
            return false;
    })
    return (
        <>
            <div className="pageReload"> {!refreshLoading && <><i className="ti-reload" id="Ltooltip" onClick={() => dispatch(getLocationsRequest(true))}></i>
            <UncontrolledTooltip color="primary" placement="top" target="Ltooltip">
             {t('ActionNames.autoRefresh')}    
             </UncontrolledTooltip>
             </>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}