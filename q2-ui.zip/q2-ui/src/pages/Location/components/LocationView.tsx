import React, { useContext, useState, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Label, Card, CardBody, UncontrolledTooltip } from 'reactstrap';
import { ChildContext } from '../container/locationcontext';
import '../container/location.css';
import { useTranslation } from 'react-i18next';
import Switch from "react-switch";
import { IOprationalActions, IStatusEnum } from '../../../models/utilitiesModel';
import { setLocationActionId, updateLocationStatusRequest } from '../../../store/actions';
import { ILocation } from '../../../models/locationsModel';

const LocationView: React.FC = () => {
    const tooltipRef = useRef<any>(null);
    const tooltipRef1 = useRef<any>(null);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const [collapse, setCollapse] = useState(false);
    const [toggleState, setToggleState] = useState(true);
    const context: ILocation = useContext<any>(ChildContext)?.data;
    const actions = useContext<any>(ChildContext)?.actions;

    let locationItemData: ILocation = useSelector(state => {
        if (state && state.locationReducer && state.locationReducer.locationsData) {
            let data = state.locationReducer.locationsData as ILocation[];
            let index = data?.findIndex(x => x.locationId === context.locationId);

            if (index !== -1)
                return state.locationReducer.locationsData[index] as ILocation;
            else return undefined;
        }
        else return undefined;
    });

    const locationStatus = useSelector(state => {
        if (state && state.locationReducer && state.locationReducer.locationsData) {
            let data = state.locationReducer.locationsData as ILocation[];
            let index = data?.findIndex(x => x.locationId === context.locationId);

            if (index !== -1)
                return (state.locationReducer.locationsData[index] as ILocation).status === IStatusEnum.NACTIVE ? true : false;
            else return false;
        }
        else return false;
    });
    console.log('locationStatus => ', locationStatus);


    const editLocation = () => dispatch(setLocationActionId(locationItemData.locationId, IOprationalActions.EDIT, false))

    useEffect(() => {
        const currentTooltip = tooltipRef.current;
        return () => {
            if (currentTooltip?.state?.isOpen)
                currentTooltip.toggle();
            if (currentTooltip?.state?.isOpen)
                currentTooltip.toggle();
        }
    });
    return (
        <>
            {locationItemData && <div className="customCard">
                <Card>
                    <CardBody className="colps">
                        <div className="align-right mb-2">
                            {(actions.edit && locationItemData.status === IStatusEnum.NACTIVE) && <>
                                <i id={"locationedit" + context.locationId} className="ti-pencil-alt mr-2 pointer" onClick={editLocation}></i>
                                <UncontrolledTooltip ref={tooltipRef} color="primary" placement="bottom" target={"locationedit" + context.locationId}>
                                    {t('ActionNames.edit')}
                                </UncontrolledTooltip>
                            </>}
                            {actions.status && toggleState && <Switch uncheckedIcon={<Offsymbol />}
                                checkedIcon={<OnSymbol />} onColor="#02a499"
                                onChange={(e) => {
                                    let updatedStatus = e === true ? IStatusEnum.NACTIVE : IStatusEnum.NINACTIVE;
                                    const confirmMessage = t('Location.confirmMessages.LC2').replace('{location}', locationItemData.locationNameEn).replace('{status}', locationItemData.status === IStatusEnum.NACTIVE ? t('ActionNames.deactivate') : t('ActionNames.activate'));
                                    dispatch(updateLocationStatusRequest(locationItemData.locationId, updatedStatus, false, confirmMessage));
                                    setTimeout(() => {
                                        setToggleState(false);
                                        setToggleState(true);
                                    }, 1000);
                                }}
                                checked={(locationItemData.status === IStatusEnum.NACTIVE ? true : false)} />
                            }
                        </div>
                        <div>
                            <div className="mb-2"><Label>{t('Location.locationEngName')}</Label><br />{locationItemData ? locationItemData.locationNameEn : ''}</div>
                            <div className="text-right"><Label>{t('Location.locationArbName')}</Label><br />{locationItemData ? locationItemData.locationNameAr : ''}</div>
                        </div>
                        <div className="cardFooter mt-2">
                            <button className="btn" onClick={() => setCollapse(!collapse)}>
                                <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                            </button>
                        </div>


                        <div className={`CardColpsCnt ${collapse ? 'show' : 'hide'}`} style={{ position: "absolute" }}>
                            <div style={{ marginBottom: "-25px" }}>
                                <div style={{ padding: '0px 15px 0px 15px' }}>
                                    <div className="align-right mb-2" style={{ paddingTop: "15px" }}>
                                        {(actions.edit && locationItemData.status === IStatusEnum.NACTIVE) && <>
                                            <i id={"clocationedit" + context.locationId} className="ti-pencil-alt mr-2 pointer" onClick={editLocation}></i>
                                            <UncontrolledTooltip ref={tooltipRef1} color="primary" placement="top" target={"clocationedit" + context.locationId}>
                                                {t('ActionNames.edit')}
                                            </UncontrolledTooltip>
                                        </>}

                                        {actions.status && toggleState && <Switch className="mb-0" uncheckedIcon={<Offsymbol />}
                                            checkedIcon={<OnSymbol />} onColor="#02a499"
                                            onChange={(e) => {
                                                let updatedStatus = e === true ? IStatusEnum.NACTIVE : IStatusEnum.NINACTIVE;
                                                const confirmMessage = t('Location.confirmMessages.LC2').replace('{location}', locationItemData.locationNameEn).replace('{status}', locationItemData.status === IStatusEnum.NACTIVE ? t('ActionNames.deactivate') : t('ActionNames.activate'));
                                                dispatch(updateLocationStatusRequest(locationItemData.locationId, updatedStatus, false, confirmMessage));
                                                setTimeout(() => {
                                                    setToggleState(false);
                                                    setToggleState(true);
                                                }, 1000);
                                            }}
                                            checked={(locationItemData.status === IStatusEnum.NACTIVE ? true : false)} />}
                                    </div>
                                    <div>
                                        <Label>{t('Location.locationEngName')}</Label>
                                        <div className="mb-0">{locationItemData ? locationItemData.locationNameEn : ''}</div>
                                    </div>
                                    <div>
                                        <Label className="align-right">{t('Location.locationArbName')}</Label>
                                        <div className="text-right mb-0">{locationItemData ? locationItemData.locationNameAr : ''}</div>
                                    </div>
                                    <div>
                                        <Label>{t('Location.locationPrefix')}</Label>
                                        <div className="mb-0">{locationItemData ? locationItemData.locationIdentfier : ''}</div>
                                    </div>
                                    <div>
                                        <Label>{t('Location.locationAddrs')}</Label>
                                        <div className="mb-0">{locationItemData ? locationItemData.locationAddress : ''}</div>
                                    </div>


                                    <div className="text-right viewfooter">
                                        <button className="btn mb-4" onClick={() => setCollapse(!collapse)}>
                                            <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </CardBody>
                </Card>
            </div>}
        </>
    )
}

const Offsymbol = () => {
    return (
        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
                fontSize: 12,
                color: "#fff",
                paddingRight: 2
            }} >
        </div>
    );
};

const OnSymbol = () => {
    return (
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
            fontSize: 12,
            color: "#fff",
            paddingRight: 2
        }}>
        </div>
    );
}
export default React.memo(LocationView);