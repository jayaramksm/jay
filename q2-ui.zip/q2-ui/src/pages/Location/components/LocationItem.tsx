import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext, ParentContext, ChildContext } from '../container/locationcontext';
import { ILocation } from '../../../models/locationsModel';

const LocationItem: React.FC = () => {
    const superContext = useContext<any>(SuperParentContext);
    const context: ILocation = useContext<any>(ParentContext)?.data;
    const actions = useContext<any>(ParentContext)?.actions;
    const isActionComponent = useSelector(state => {
        if (state && state.locationReducer && state.locationReducer.actionId)
            return state.locationReducer.actionId === context.locationId;
        else return false;
    });

    return (
        <>
            <ChildContext.Provider value={{ data: context, actions: actions }}>
                {isActionComponent ? <superContext.actionComponent /> : <superContext.viewComponent />}
            </ChildContext.Provider>
        </>
    )
}
export default React.memo(LocationItem);