import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext, ParentContext } from '../container/locationcontext';
import { Row } from 'reactstrap';
import { PaginationComponent } from '../../Utilities/PaginationComponent';
import { getEnvironment } from '../../../helpers/helpersIndex';
import '../container/location.css';
import { ILocation } from '../../../models/locationsModel';
import { useTranslation } from 'react-i18next';
// import { Scrollbars } from 'react-custom-scrollbars';

const ManagerParent: React.FC = () => {
    const { t } = useTranslation("translations");
    const [searchKey, setSearchKey] = useState('')
    const context = useContext<any>(SuperParentContext);
    const pageSize = getEnvironment.pageSize + (context?.actions?.add ? 0 : 1);

    const locationsTData: ILocation[] = useSelector(state => {
        if (state && state.locationReducer)
            return state.locationReducer.locationsData ? (state.locationReducer.locationsData as ILocation[]) : undefined;
        else return undefined;
    });

    let locationsData: ILocation[] = (searchKey && searchKey !== '') ?
        locationsTData.filter(x => x.locationNameEn.toLowerCase().startsWith(searchKey.toLowerCase())) : locationsTData;

    const locationsCount = useSelector(state => {
        if (state && state.locationReducer && state.locationReducer.locationsData)
            return state.locationReducer.locationsData.length;
        else return 0;
    });
    console.log('locationsCount => ', locationsCount);

    let pagesCount = Math.ceil((locationsData ? locationsData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }
    return (
        <>
            {locationsTData && locationsTData.length > 0 && <Row>
                <div className="app-search wi-30 p-0 form-group mb-0 pl-3">
                    <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={(e) => setSearchKey(e.target.value)} />
                    <i className="fa fa-search"></i>
                </div>
            </Row>}


            <div className="flexLayout pb-3 loclayout">
                <div className="flexLayout-inner">
                    <div className="pr-3  pb-3">

                        <Row className="mt-4 mx-0 lyt1-rgtclmn">
                            {context.actions.add && <div className="customCard addCustomCard">
                                <context.addComponent />
                            </div>}
                            {locationsData && locationsData.length > 0 && locationsData.slice(currentPage * pageSize,
                                (currentPage + 1) * pageSize)
                                .map((x) => {
                                    return (
                                        <ParentContext.Provider key={x.locationId} value={{ data: x, actions: context.actions }}>
                                            <context.itemComponent />
                                        </ParentContext.Provider>
                                    )
                                })
                            }
                            {locationsData && searchKey === '' && locationsData.length === 0 && <span className="align-center mb-4">{t('Location.noLocations')}</span>}
                            {locationsData && searchKey !== '' && locationsData.length === 0 && <span className="align-center mb-4">{t('Location.noSearchedLocations')}</span>}
                        </Row>
                    </div>
                </div>


                {locationsData && locationsData.length > pageSize && <Row className="justify-content-end rgt-pagination">
                    <div className="pagination mr-3 pt-3">
                        <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                    </div>
                </Row>}
            </div>
        </>
    )
}
export default React.memo(ManagerParent);