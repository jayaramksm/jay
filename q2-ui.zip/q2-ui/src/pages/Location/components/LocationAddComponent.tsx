import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Card, CardBody } from 'reactstrap';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import addIcon from '../../../images/icons/addicon.svg';
import { SuperParentContext, ChildContext } from '../container/locationcontext';
import { setLocationActionId } from '../../../store/actions';

const LocationAddComponent: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context = useContext<any>(SuperParentContext);
    const locationActionType = useSelector(state => {
        if (state && state.locationReducer)
            return state.locationReducer.actionType ? state.locationReducer.actionType : IOprationalActions.UNSELECT;
        else return IOprationalActions.UNSELECT;
    });

    return (
        <>
            {!(locationActionType === IOprationalActions.ADD) && context?.actions?.add && <Card onClick={() => dispatch(setLocationActionId(0, IOprationalActions.ADD, false))}>
                <CardBody>
                    <span>{t('Location.addLocation')} <img src={addIcon} alt="" /></span>
                </CardBody>
            </Card>}

            {(locationActionType === IOprationalActions.ADD) && <ChildContext.Provider value={{ data: { locationId: 0 }, action: context.actions }}>
                <context.actionComponent />
            </ChildContext.Provider>}
        </>
    )
}
export default React.memo(LocationAddComponent);