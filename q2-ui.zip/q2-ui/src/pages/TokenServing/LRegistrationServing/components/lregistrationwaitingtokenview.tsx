import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { FixedSizeList as List } from 'react-window';
import { ChiledContext } from '../container/lregistrationservingcontext';
import { ILRegistrationServingModel, ILRegistrationTokenDetails } from '../../../../models/lregistrationServingModel';
import '../../clerkserving.css';

const LRegistrationWaitingTokenView: React.FC = () => {
    const { t } = useTranslation("translations");
    const context = useContext(ChiledContext);

    const waitingTokens: ILRegistrationTokenDetails[] = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.waitingTokensData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.waitingTokensData;
        else return [];
    });
    const waitingTokensCount: number = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.waitingTokensData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.waitingTokensData.length;
        else return 0;
    });
    console.log("LRegistrationWatingTokenView =>", waitingTokens, waitingTokensCount);

    const TokenItem = ({ index, style }) => {
        return (
            <div style={style}>
                <context.tokenItem key={index} data={{ tokenId: waitingTokens[index].tokenId, queueType: 'W' }} />
            </div>
        )
    }

    return (
        <>
            {waitingTokens && waitingTokens.length === 0 && <span>{t('LRegistrationServing.noWaitingTFound')}</span>}

            {waitingTokens && waitingTokens.length > 0 &&
                <List
                    className="ClerkServ"
                    height={200}
                    itemCount={waitingTokens.length}
                    itemSize={75}
                    width="100%">
                    {TokenItem}
                </List>
            }

        </>
    )
}
export default React.memo(LRegistrationWaitingTokenView);