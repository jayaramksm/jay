import React, { useContext } from 'react'
import { useSelector } from 'react-redux';
import { SuperParentContext, ParentContext } from '../container/lregistrationservingcontext';
import { Row, Col } from 'reactstrap';
import { ILRegistrationServingModel } from '../../../../models/lregistrationServingModel';
import '../../clerkserving.css';

const LRegistrationTokenArea: React.FC = () => {
    const context = useContext(SuperParentContext);
    console.log("LRegistrationTokenArea_context => ", context);

    const selectedRoomExists: number = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.selectedRoom)
            return (state.lregistrationServingReducer as ILRegistrationServingModel).selectedRoom.roomId > 0;
        else return false;
    });

    return (
        <>
            {selectedRoomExists && <div className="PatientView">
                <Row >
                    <Col sm="8" className="NrsLft">
                        {context.parentTokenView &&
                            <ParentContext.Provider key='parentTokenView' value={{ tokenView: context.patientTokenView, journeyView: context.patientJourneyView, tokenPagination: context.tokenPagination, actions: context.actions }}>
                                <context.parentTokenView />
                            </ParentContext.Provider>
                        }
                    </Col>
                    <Col sm="4" className="NrsRgt pl-0">
                        {context.parentQueueView &&
                            <ParentContext.Provider key='parentQueueView' value={{ currentTokenView: context.currentTokenView, waitingTokenView: context.waitingTokenView, tokenItem: context.tokenItem }}>
                                <context.parentQueueView />
                            </ParentContext.Provider>
                        }
                    </Col>
                </Row>
            </div>}
        </>
    )
}

export default React.memo(LRegistrationTokenArea);