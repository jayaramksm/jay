import React, { useContext, useEffect } from 'react';
import { Card, CardBody, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { ParentContext, ChiledContext } from '../container/lregistrationservingcontext';
import classnames from 'classnames';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { interval } from 'rxjs';
import '../../clerkserving.css';
import { ILRegistrationServingModel } from '../../../../models/lregistrationServingModel';
import { getTokenServingInterval } from '../../../../helpers/helpersIndex';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';
import { setLRegistrationTabIndexRequest, setLRegistrationTokensDataRequest, setLRegistrationTokensDataRequestSuspend } from '../../../../store/actions';

let subscription;
const LRegistrationParentQueueView: React.FC = () => {
    const { t } = useTranslation("translations");
    const context = useContext(ParentContext);
    const dispatch = useDispatch();
    const getTabIndex = useSelector(state => {
        if (state && state.lregistrationServingReducer) {
            if ((state.lregistrationServingReducer as ILRegistrationServingModel).selectionTabIndex === ITabIndexEnum.WAITING)
                return ITabIndexEnum.WAITING;
            else return ITabIndexEnum.CURRENT;
        }
        else
            return ITabIndexEnum.CURRENT;
    });
    console.log("LRegistrationParentQueueView_context =>", context, getTabIndex);

    const selectedRoomId: number = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.selectedRoom)
            return (state.lregistrationServingReducer as ILRegistrationServingModel).selectedRoom.roomId;
        else return 0;
    });
    const setTabIndex = (tab) => {
        dispatch(setLRegistrationTabIndexRequest(tab, false));
    };

    useEffect(() => {
        subscription = interval(getTokenServingInterval() * 1000).subscribe(data => {
            if (selectedRoomId > 0) {
                dispatch(setLRegistrationTokensDataRequest(selectedRoomId));
            }
        });
        return () => {
            if (subscription) {
                subscription.unsubscribe();
                dispatch(setLRegistrationTokensDataRequestSuspend());
            }
        }
    }, [selectedRoomId, dispatch]);

    return (
        <>
            <Nav className="nav-tabs-custom">
                <NavItem>
                    <NavLink className={classnames({ active: getTabIndex === ITabIndexEnum.CURRENT })}
                        onClick={() => setTabIndex(ITabIndexEnum.CURRENT)}>
                        <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                        <span className="d-none d-sm-block">{t('LRegistrationServing.currentlyServing')}</span>
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink className={classnames({ active: getTabIndex === ITabIndexEnum.WAITING })}
                        onClick={() => setTabIndex(ITabIndexEnum.WAITING)}>
                        <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                        <span className="d-none d-sm-block">{t('LRegistrationServing.waitingQueue')}</span>
                    </NavLink>
                </NavItem>
            </Nav>

            <Card>
                <CardBody>
                    <TabContent activeTab={getTabIndex}>
                        <TabPane tabId={ITabIndexEnum.CURRENT}>
                            <ChiledContext.Provider value={{ tokenItem: context.tokenItem }}>
                                <context.currentTokenView />
                            </ChiledContext.Provider>
                        </TabPane>
                        <TabPane tabId={ITabIndexEnum.WAITING}>
                            <ChiledContext.Provider value={{ tokenItem: context.tokenItem }}>
                                <context.waitingTokenView />
                            </ChiledContext.Provider>
                        </TabPane>
                    </TabContent>
                </CardBody>
            </Card>
        </>
    )
}

export default React.memo(LRegistrationParentQueueView);