import React from 'react';
import { useTranslation } from 'react-i18next';
import { Table } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';
import { ILRegistrationServingModel } from '../../../../models/lregistrationServingModel';
import { setLRegistrationCurrentTokenIdRequestResponse } from '../../../../store/actions';
import '../../clerkserving.css';


const LRegistrationTokenItem: React.FC<any> = ({ data }) => {
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const getTabIndex: number = useSelector(state => state?.lregistrationServingReducer as ILRegistrationServingModel)?.selectionTabIndex;
    const getActionTokenId = useSelector(state => {
        if (state?.lregistrationServingReducer?.selectionActionArea?.actionTokenId)
            return state?.lregistrationServingReducer?.selectionActionArea?.actionTokenId;
        else
            return 0;
    });
    const tokenData = useSelector(state => {
        if (data.queueType === 'W') {
            if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.waitingTokensData)
                return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.waitingTokensData.find(x => x.tokenId === data.tokenId);
        }
        else if (data.queueType === 'S') {
            if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.servingTokensData)
                return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.servingTokensData.find(x => x.tokenId === data.tokenId);
        }
        return undefined;
    });
    console.log("LRegistrationTokenItem =>", data, getActionTokenId, tokenData);

    const setSelectedToken = (token) => {
        console.log("setSelectedToken =>", token);
        dispatch(setLRegistrationCurrentTokenIdRequestResponse(token.tokenId));
    }

    return (
        <>
            {tokenData && <div className={"ToknRecordTbl" + (getActionTokenId === tokenData.tokenId ? ' active' : '') + (tokenData.noShow === 1 ? ' noshow' : (tokenData.priority === 1 ? ' priority' : ''))} onClick={() => setSelectedToken(tokenData)}>
                <Table responsive>
                    <tbody>
                        <tr>
                            <td className="font-weight-bold"><div className="ellipsis">{tokenData.patientName}</div></td>
                            <td>{tokenData.tokenNo}</td>
                            {getTabIndex === ITabIndexEnum.CURRENT && <td>{tokenData.roomNumber}</td>}
                        </tr>
                        <tr className="textLignt">
                            <td>{t('LRegistrationServing.mrn')} - {tokenData.mrnNo}</td>
                            <td>{t('LRegistrationServing.token')}</td>
                            {getTabIndex === ITabIndexEnum.CURRENT && <td>{t('LRegistrationServing.roomDetail')}</td>}
                        </tr>
                    </tbody>
                </Table>
            </div>}
        </>
    )
}

export default React.memo(LRegistrationTokenItem);