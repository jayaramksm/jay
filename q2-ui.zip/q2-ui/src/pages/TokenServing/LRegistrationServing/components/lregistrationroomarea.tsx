import React from 'react';
import { Label, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { Formik, Form } from 'formik';
import { useTranslation } from 'react-i18next';
import { setLRegistrationMappedRoomToUserRequest } from '../../../../store/actions';
import { ILRegistrationServingModel, IRoom } from '../../../../models/lregistrationServingModel';
import '../../clerkserving.css';
import { MySelect } from '../../../../helpers/helpersIndex';

const LRegistrationRoomArea: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const roomsData: IRoom[] = useSelector(state => {
        if (state && state.lregistrationServingReducer && state?.lregistrationServingReducer?.roomsData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.roomsData;
        else return [];
    });
    console.log("roomsData", roomsData);

    const selectedRoom: IRoom = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.selectedRoom)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.selectedRoom;
        else return undefined;
    });
    let roomsMapData = roomsData.map((x: IRoom) => ({ value: x.roomId, label: x.roomNameEn + ':' + x.roomNo }));
    console.log("LRegistrationRoomArea =>", roomsData, selectedRoom, roomsMapData);

    const onRoomSelection = (e, setFieldValue) => {
        console.log("onRoomSelection =>", e);
        // setFieldValue('rooms', e);
        dispatch(setLRegistrationMappedRoomToUserRequest(e.value));
    }

    const patchRoom = () => {
        let index = roomsMapData?.findIndex(x => x.value === selectedRoom?.roomId);
        if (index !== -1)
            return { value: roomsMapData[index]?.value, label: roomsMapData[index]?.label }
        else return '';
    }

    return (
        <>
            <Col sm="3" className="pb-2 plft-16">
                <Formik
                    enableReinitialize
                    initialValues={{
                        rooms: patchRoom()
                    }}
                    onSubmit={(values) => {
                        console.log("onSubmit_Values =>", values);
                    }}
                >
                    {({ values, setFieldValue }) => (
                        <Form>
                            <Label>{t('LRegistrationServing.room')}</Label>
                            <MySelect
                                name="rooms"
                                placeholder={t('LRegistrationServing.selectRoom')}
                                value={values.rooms}
                                onChange={(e) => onRoomSelection(e, setFieldValue)}
                                options={roomsMapData ? roomsMapData : []}
                                getOptionLabel={option => option.label}
                                getOptionValue={option => option.value}
                                noOptionsMessage={() => t('LRegistrationServing.noRooms')}
                            />
                        </Form>
                    )}
                </Formik>
            </Col>
        </>
    )
}

export default React.memo(LRegistrationRoomArea);