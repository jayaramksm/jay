import React, { useContext } from 'react'
import { ParentContext, ChiledContext } from '../container/lregistrationservingcontext';
import { useSelector } from 'react-redux';
import { IServiceStatasticsDetail } from '../../../../models/utilityClientModel';
import { ILRegistrationServingModel } from '../../../../models/lregistrationServingModel';
import '../../clerkserving.css';
const LRegistrationStatsticsArea: React.FC = () => {
    const context = useContext(ParentContext);
    const serviceStatasticsData: IServiceStatasticsDetail[] = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.statasticsData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.statasticsData;
        else return [];
    });
    const serviceStatasticsDataCount: number = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.statasticsData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.statasticsData.length;
        else return 0;
    });


    console.log("LRegistrationStatsticsArea =>", serviceStatasticsData, context);



    return (
        <>
            {context.lregistrationStatstics && serviceStatasticsDataCount > 0 && serviceStatasticsData.map((x, index) => {
                return (
                    <ChiledContext.Provider key={index} value={x.name}>
                        <context.lregistrationStatstics />
                    </ChiledContext.Provider>
                )
            })}
        </>
    )
}

export default React.memo(LRegistrationStatsticsArea);