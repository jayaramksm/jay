import React, { useContext, useState } from 'react'
import { Row, Col, Collapse } from 'reactstrap';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { SuperParentContext, ParentContext } from '../container/lregistrationservingcontext';
import '../../clerkserving.css';
import { IRoom } from '../../../../models/lregistrationServingModel';

const LRegistrationParentStatsticsArea: React.FC = () => {
    const [collapse, setCollapse] = useState(true);
    const { t } = useTranslation("translations");
    const context = useContext(SuperParentContext);

    const selectedRoomId: number = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.selectedRoom)
            return (state.lregistrationServingReducer.selectedRoom as IRoom).roomId;
        else return 0;
    });
    console.log("LRegistrationParentStatsticsArea =>", selectedRoomId, context);

    return (
        <>
            {selectedRoomId > 0 && <><Row>
                <Col sm="6">
                    <div className="heading">
                        {t('LRegistrationServing.serviceDetails')}
                        <button className="btn ml-1" onClick={() => setCollapse(!collapse)}>
                            <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                        </button>
                    </div>
                </Col>
            </Row>
                <Collapse isOpen={collapse} >
                    <Row className="mb-3" style={{ justifyContent: "space-around" }}>
                        {collapse && <ParentContext.Provider value={context}>
                            <context.lregistrationStatsticsArea />
                        </ParentContext.Provider>}
                    </Row>
                </Collapse></>}
        </>
    )
}

export default React.memo(LRegistrationParentStatsticsArea);