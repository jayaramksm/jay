import React, { useContext } from 'react';
import { Row, Col, Card } from 'reactstrap';
import { useSelector } from 'react-redux';
import { ChiledContext } from '../container/lregistrationservingcontext';
import { IServiceStatasticsDetail } from '../../../../models/utilityClientModel';
import { ILRegistrationServingModel } from '../../../../models/lregistrationServingModel';
import '../../clerkserving.css';
import { useTranslation } from 'react-i18next';

export const LRegistrationStatstics: React.FC = () => {
    const { t } = useTranslation("translations");
    const context = useContext(ChiledContext);

    const statasticsData: IServiceStatasticsDetail[] = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.statasticsData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.statasticsData;
        else return [];
    });
    const statasticsDataCount: number = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.statasticsData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.statasticsData.length;
        else return 0;
    });
    const statasticsDetails = statasticsData?.find(x => x.name === context);
    console.log("detailedTitle=>", statasticsData, statasticsDetails, context, statasticsDataCount);

    return (
        <>
            <Col lg="" md="6" sm="6" xs="12">
                <Card className="widgets">
                    <Row>
                        <Col xs="6" style={{ paddingRight: 0 }}>
                            <h5>{t('LRegistrationServing.' + context)}</h5>
                        </Col>
                        <Col xs="6" className="widget-count">
                            <h2>{statasticsDetails?.count}{statasticsDetails?.timeFormat && <span style={{ fontSize: '18px' }}> {t('LRegistrationServing.min')}</span>}</h2>
                        </Col>
                    </Row>
                </Card>
            </Col>
        </>
    )
}

export default React.memo(LRegistrationStatstics);