import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { ChiledContext } from '../container/lregistrationservingcontext';
import { FixedSizeList as List } from 'react-window';
import '../../clerkserving.css';
import { ILRegistrationServingModel, ILRegistrationTokenDetails } from '../../../../models/lregistrationServingModel';

const LRegistrationCurrentServingView: React.FC = () => {
    const context = useContext(ChiledContext);
    const { t } = useTranslation("translations");
    const servingTokens: ILRegistrationTokenDetails[] = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.servingTokensData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.servingTokensData;
        else return [];
    });
    const servingTokensCount: number = useSelector(state => {
        if (state?.lregistrationServingReducer && state?.lregistrationServingReducer?.servingTokensData)
            return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.servingTokensData.length;
        else return 0;
    });
    console.log("LRegistrationCurrentServingView =>", servingTokens, servingTokensCount, context);

    const TokenItem = ({ index, style }) => {
        return (
            <div style={style}>
                <context.tokenItem key={index} data={{ tokenId: servingTokens[index].tokenId, queueType: 'S' }} />
            </div>
        )
    }

    return (
        <>
            {servingTokens && servingTokens.length === 0 && <span>{t('LRegistrationServing.noServingTFound')}</span>}

            {servingTokens && servingTokens.length > 0 &&
                <List
                    className="ClerkServ"
                    height={200}
                    itemCount={servingTokens.length}
                    itemSize={75}
                    width="100%">
                    {TokenItem}
                </List>
            }
        </>
    )
}

export default React.memo(LRegistrationCurrentServingView);