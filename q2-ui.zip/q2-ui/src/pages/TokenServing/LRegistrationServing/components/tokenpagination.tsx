import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { setLRegistrationCurrentTokenIdRequestResponse } from '../../../../store/actions';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';
import { ILRegistrationServingModel, ILRegistrationTokenDetails } from '../../../../models/lregistrationServingModel';
import '../../clerkserving.css';

const TokenPagination: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const getTokenData: ILRegistrationTokenDetails[] = useSelector(state => {
        if (state?.lregistrationServingReducer?.selectionActionArea?.actionTokenId) {
            if (state?.lregistrationServingReducer?.selectionTabIndex === ITabIndexEnum.WAITING) {
                return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.waitingTokensData ?
                    (state?.lregistrationServingReducer as ILRegistrationServingModel)?.waitingTokensData : [];
            }
            else if (state?.lregistrationServingReducer?.selectionTabIndex === ITabIndexEnum.CURRENT) {
                return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.servingTokensData ?
                    (state?.lregistrationServingReducer as ILRegistrationServingModel)?.servingTokensData : [];
            }
            else
                return [];
        }
        else
            return [];
    });
    const getActionTokenId = useSelector(state => {
        if (state?.lregistrationServingReducer?.selectionActionArea?.actionTokenId)
            return state?.lregistrationServingReducer?.selectionActionArea?.actionTokenId;
        else
            return 0;
    });
    const getActionTokenIndex = getTokenData.findIndex(x => x.tokenId === getActionTokenId);
    console.log("TokenPagination =>", getActionTokenId, getActionTokenIndex);


    const changetokenAction = (value) => {
        dispatch(setLRegistrationCurrentTokenIdRequestResponse(getTokenData[value].tokenId));
    }


    return (
        <>
            {getTokenData.length > 1 && <>
                <button type="button" className="btn btn-sm " disabled={getActionTokenIndex === 0} onClick={() => changetokenAction(getActionTokenIndex - 1)}>
                    <i className="ti-angle-left"></i>{t('ActionNames.back')}
                </button> |
                <button type="button" className="btn btn-sm " disabled={getActionTokenIndex >= getTokenData.length - 1} onClick={() => changetokenAction(getActionTokenIndex + 1)}>
                    {t('ActionNames.next')}
                    <i className="ti-angle-right"></i>
                </button>
            </>}
        </>
    )
}
export default React.memo(TokenPagination);