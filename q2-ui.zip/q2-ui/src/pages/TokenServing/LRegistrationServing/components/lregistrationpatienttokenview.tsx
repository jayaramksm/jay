import React, { useContext, useEffect, useRef } from 'react';
import { Row, Col, UncontrolledTooltip, Label } from 'reactstrap';
import priority from '../../../../images/priority.svg';
import priorityColor from '../../../../images/priority-color.svg';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { ChiledContext } from '../container/lregistrationservingcontext';
import { ILRegistrationServingModel, ILRegistrationTokenDetails } from '../../../../models/lregistrationServingModel';
import { setLRegistrationTokenActionTypeRequest, setLRegistrationTokenPriorityRequest } from '../../../../store/actions';
import { ITabIndexEnum, ITokenActionTypeEnum } from '../../../../models/utilityClientModel';
import '../../clerkserving.css';

const LRegistrationPatientTokenView: React.FC = () => {
    const highPRef = useRef<any>(null);
    const lowPRef = useRef<any>(null);
    const { t } = useTranslation("translations");
    const context = useContext(ChiledContext)?.actions;
    const dispatch = useDispatch();

    const getTabIndex: number = useSelector(state => state?.lregistrationServingReducer as ILRegistrationServingModel)?.selectionTabIndex;
    const getActionTokenData: ILRegistrationTokenDetails = useSelector(state => {
        if (state.lregistrationServingReducer.selectionActionArea && state.lregistrationServingReducer.selectionActionArea.actionTokenId) {
            if (state?.lregistrationServingReducer?.selectionTabIndex === ITabIndexEnum.WAITING) {
                return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.waitingTokensData ?
                    (state?.lregistrationServingReducer as ILRegistrationServingModel)?.waitingTokensData.find(x => x.tokenId === state?.lregistrationServingReducer?.selectionActionArea?.actionTokenId) : undefined;
            }
            else if (state?.lregistrationServingReducer?.selectionTabIndex === ITabIndexEnum.CURRENT) {
                return (state?.lregistrationServingReducer as ILRegistrationServingModel)?.servingTokensData ?
                    (state?.lregistrationServingReducer as ILRegistrationServingModel)?.servingTokensData.find(x => x.tokenId === state?.lregistrationServingReducer?.selectionActionArea?.actionTokenId) : undefined;
            }
            else
                return undefined
        }
        else
            return undefined;
    });
    console.log("LRegistrationPatientTokenView =>", getActionTokenData, context);

    const tokenAction = (tokenData: ILRegistrationTokenDetails, tokenActionType) => {
        console.log("tokenAction =>", tokenData, tokenActionType);
        let message;
        if (tokenActionType === ITokenActionTypeEnum.SERVING)
            message = t('LRegistrationServing.confirmMessages.LRSCM1').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.SERVED)
            message = t('LRegistrationServing.confirmMessages.LRSCM2').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.NOSHOW)
            message = t('LRegistrationServing.confirmMessages.LRSCM3').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.RECYCLE)
            message = t('LRegistrationServing.confirmMessages.LRSCM4').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.END)
            message = t('LRegistrationServing.confirmMessages.LRSCM2').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.RECALL)
            message = t('LRegistrationServing.confirmMessages.LRSCM7').replace('{token}', tokenData.tokenNo);
        dispatch(setLRegistrationTokenActionTypeRequest(tokenData, tokenActionType, message, false));
    }

    const changePriority = (tokenData, priority) => {
        let message = t('LRegistrationServing.confirmMessages.LRSCM6').replace('{token}', tokenData.tokenNo).replace('{priority}', priority);
        console.log("changePriority =>", priority, message);
        dispatch(setLRegistrationTokenPriorityRequest(tokenData, message, false));
    }

    useEffect(() => {
        const currentTooltipHigh = highPRef.current;
        const currentTooltipLow = lowPRef.current;
        return () => {
            if (currentTooltipHigh?.state?.isOpen)
                currentTooltipHigh.toggle();
            if (currentTooltipLow?.state?.isOpen)
                currentTooltipLow.toggle();
        }
    });

    return (
        <>
            {getActionTokenData && <>

                <Row>
                    {getActionTokenData?.patientName && <Col>
                        <span className="font-weight-bold">{getActionTokenData.patientName}</span>
                        <br />
                        <Label>{t('LRegistrationServing.patientname')}</Label>
                    </Col>}
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.mrnNo}</span><br />
                        <Label>{t('LRegistrationServing.mrn')}</Label>
                    </Col>
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.tokenNo}</span><br />
                        <Label>{t('LRegistrationServing.token')}</Label>
                    </Col>
                </Row>
                <hr />
                <Row>
                    {/* <Col>
                        <span className="font-weight-bold">{getActionTokenData.isVitalDone ? t('LRegistrationServing.completed') : t('LRegistrationServing.pending')}</span><br />
                        <Label>{t('LRegistrationServing.vitals')}</Label>
                    </Col> */}
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.appointmentTime}</span><br />
                        <Label>{t('LRegistrationServing.appointmentTime')}</Label>
                    </Col>
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.checkInTime}</span><br />
                        <Label>{t('LRegistrationServing.checkInTime')}</Label>
                    </Col>
                    {getTabIndex === ITabIndexEnum.WAITING && <Col>
                        <span className="font-weight-bold">{getActionTokenData.waitingTime}</span><br />
                        <Label>{t('LRegistrationServing.waitingTime')}</Label>
                    </Col>}
                </Row>


                <hr />

                <div className="QueActns">
                    <Row>
                        <Col sm="10">
                            <Row>
                                {/* <Col sm="4">
                                <FormGroup className="mb-0">
                                    <Label>Room</Label>
                                    <select className="form-control">
                                        <option>Select</option>
                                        <option>Nurse Sation - 04</option>
                                        <option>Waiting Room - 01</option>
                                        <option>Vaitals Room - 03</option>
                                        <option>Xray Room - 02</option>
                                        <option>Doctor Room - 04</option>
                                    </select>
                                </FormGroup>
                            </Col> */}
                                <Col sm="10">
                                    {context?.serve && getTabIndex === ITabIndexEnum.WAITING && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.SERVING)}><button type="button" className="btn btn-sm  btn-success">{t('ActionNames.serve')}</button></span>}
                                    {context?.end && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, getTabIndex === ITabIndexEnum.WAITING ? ITokenActionTypeEnum.END : ITokenActionTypeEnum.SERVED)}><button type="button" className="btn btn-sm  btn-outline-danger">{t('ActionNames.end')}</button></span>}
                                    {context?.noShow && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.NOSHOW)}><button type="button" className="btn btn-sm  btn-outline-danger">{t('ActionNames.noShow')}</button></span>}
                                    {context?.recycle && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.RECYCLE)}><button type="button" className="btn btn-sm btn-success">{t('ActionNames.recycle')}</button></span>}
                                    {context?.recall && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.RECALL)}><button type="button" className="btn btn-sm btn-success">{t('ActionNames.recall')}</button></span>}
                                </Col>
                            </Row>
                        </Col>
                        <Col className="align-right priority">
                            {getActionTokenData?.priority === 0 && <>
                                <img id="lowPriority" src={priority} alt="" onClick={() => changePriority(getActionTokenData, t('LRegistrationServing.highPriority'))} />
                                <UncontrolledTooltip ref={lowPRef} color="primary" placement="top" target="lowPriority">
                                    {t('LRegistrationServing.lowPriority')}
                                </UncontrolledTooltip>
                            </>}
                            {getActionTokenData?.priority === 1 && <>
                                <img id="highPriority" src={priorityColor} alt="" onClick={() => changePriority(getActionTokenData, t('LRegistrationServing.lowPriority'))} />
                                <UncontrolledTooltip ref={highPRef} color="primary" placement="top" target="highPriority">
                                    {t('LRegistrationServing.highPriority')}
                                </UncontrolledTooltip>
                            </>}
                        </Col>
                    </Row>
                </div>
            </>}
        </>
    )
}

export default React.memo(LRegistrationPatientTokenView);