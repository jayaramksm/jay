import * as React from 'react';
import '../../clerkserving.css';
import {
    Container, Row
} from 'reactstrap';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../../store/actions';
// import PerfectScrollbar from 'react-perfect-scrollbar';
import {
    LRegistrationCurrentServingView,
    LRegistrationParentQueueView,
    LRegistrationParentStatsticsArea,
    LRegistrationParentTokenView,
    LRegistrationPatientTokenView,
    LRegistrationRoomArea,
    LRegistrationStatstics,
    LRegistrationStatsticsArea,
    LRegistrationTokenArea,
    LRegistrationTokenItem,
    LRegistrationWaitingTokenView,
    TokenPagination,
    PatientTokenJourneyView
} from './lregistrationservingindex';
import { withTranslation } from 'react-i18next';
import { SuperParentContext } from './lregistrationservingcontext';
import { getLRegistrationRoomStatisticsDataRequest, setResetForLRegistration, cancelPendingLRegistrationServingRequests } from '../../../../store/actions';

interface IProps {
    profilePath: any;
    activateAuthLayout: any;
    t: any;
    history: any;
    getLRegistrationRoomStatisticsDataRequest: any;
    setResetForLRegistration: any;
    cancelPendingLRegistrationServingRequests: any;
}
class LRegistrationServing extends React.Component<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {
            statsticsComponent: { lregistrationStatstics: LRegistrationStatstics, lregistrationStatsticsArea: LRegistrationStatsticsArea },
            tokenAreaGrid: {
                parentTokenView: LRegistrationParentTokenView,
                parentQueueView: LRegistrationParentQueueView,
                patientTokenView: LRegistrationPatientTokenView,
                patientJourneyView: PatientTokenJourneyView,
                currentTokenView: LRegistrationCurrentServingView,
                waitingTokenView: LRegistrationWaitingTokenView,
                tokenItem: LRegistrationTokenItem,
                tokenPagination: TokenPagination,
                actions: { serve: true, end: true, noShow: true, recycle: true, recall: true }
            }
        };
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForLRegistration();
        this.props.getLRegistrationRoomStatisticsDataRequest(true);
    }
    componentWillUnmount() {
        this.props.setResetForLRegistration();
        this.props.cancelPendingLRegistrationServingRequests();
    }
    render() {
        return (
            <>
                <Container fluid className="h-100">
                    <div>
                        <div>
                            <Row>
                                <LRegistrationRoomArea />
                                {/* {this.props.profilePath && <Col className="mt-2 pt-4">
                                        <div className="btn btn-grey" onClick={() => this.props.history.push(this.props.profilePath)}>{this.props.t('UserProfileManagement.changeWorkspace')}</div>
                                    </Col>} */}
                            </Row>

                            <SuperParentContext.Provider value={this.state.statsticsComponent}>
                                <LRegistrationParentStatsticsArea />
                            </SuperParentContext.Provider>

                            <SuperParentContext.Provider value={this.state.tokenAreaGrid}>
                                <LRegistrationTokenArea />
                            </SuperParentContext.Provider>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(withTranslation("translations")(connect(null, { activateAuthLayout, getLRegistrationRoomStatisticsDataRequest, setResetForLRegistration, cancelPendingLRegistrationServingRequests })(LRegistrationServing)));