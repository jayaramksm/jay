import React, { useContext, useEffect, useRef } from 'react';
import { Row, Col, UncontrolledTooltip, Label } from 'reactstrap';
import priority from '../../../../images/priority.svg';
import priorityColor from '../../../../images/priority-color.svg';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { ILaboratoryServingModel, ILaboratoryTokens } from '../../../../models/laboratoryServingModel';
import { ChiledContext } from '../Container/laboratoryservingcontext';
import { setLaboratoryTokenActionTypeRequest } from '../../../../store/actions';
import '../../nurse.css';
import { setLaboratoryTokenPriorityRequest } from '../../../../store/actions';
import { ITabIndexEnum, ITokenActionTypeEnum } from '../../../../models/utilityClientModel';

const LaboratoryPatientTokenView: React.FC = () => {

    const highPRef = useRef<any>(null);
    const lowPRef = useRef<any>(null);
    const { t } = useTranslation("translations");
    const context = useContext(ChiledContext)?.actions;
    const dispatch = useDispatch();

    const getTabIndex: number = useSelector(state => state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectionTabIndex;
    const getActionTokenData: ILaboratoryTokens = useSelector(state => {
        if (state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId) {

            if (state?.laboratoryServingReducer?.selectionTabIndex === ITabIndexEnum.WAITING) {
                return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.waitingTokensData ?
                    (state?.laboratoryServingReducer as ILaboratoryServingModel)?.waitingTokensData.find(x => x.tokenId === state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId) : undefined;
            }
            else if (state?.laboratoryServingReducer?.selectionTabIndex === ITabIndexEnum.CURRENT) {
                return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servingTokensData ?
                    (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servingTokensData.find(x => x.tokenId === state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId) : undefined;
            }
            else
                return undefined
        }
        else
            return undefined;
    });
    console.log("LaboratoryPatientTokenView =>", getActionTokenData, context);

    const tokenAction = (tokenData: ILaboratoryTokens, tokenActionType) => {
        console.log("tokenAction =>", tokenData, tokenActionType);
        let message;
        if (tokenActionType === ITokenActionTypeEnum.SERVING)
            message = t('LaboratoryServing.confirmMessages.LSCM1').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.SERVED)
            message = t('LaboratoryServing.confirmMessages.LSCM2').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.NOSHOW)
            message = t('LaboratoryServing.confirmMessages.LSCM3').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.RECYCLE)
            message = t('LaboratoryServing.confirmMessages.LSCM4').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.END)
            message = t('LaboratoryServing.confirmMessages.LSCM2').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.RECALL)
            message = t('LaboratoryServing.confirmMessages.LSCM7').replace('{token}', tokenData.tokenNo);
        dispatch(setLaboratoryTokenActionTypeRequest(tokenData, tokenActionType, message, false));
    }

    const changePriority = (tokenData, priority) => {
        let message = t('LaboratoryServing.confirmMessages.LSCM6').replace('{token}', tokenData.tokenNo).replace('{priority}', priority);
        console.log("changePriority =>", message);
        dispatch(setLaboratoryTokenPriorityRequest(tokenData, message, false));
    }

    useEffect(() => {
        const currentTooltipHigh = highPRef.current;
        const currentTooltipLow = lowPRef.current;
        return () => {
            if (currentTooltipHigh?.state?.isOpen)
                currentTooltipHigh.toggle();
            if (currentTooltipLow?.state?.isOpen)
                currentTooltipLow.toggle();
        }
    });

    return (
        <>
            {getActionTokenData && <>
                <Row>
                    {getActionTokenData?.patientName && <Col>
                        <span className="font-weight-bold">{getActionTokenData.patientName}</span>
                        <br />
                        <Label>{t('LaboratoryServing.patientname')}</Label>
                    </Col>}
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.mrnNo}</span>
                        <br />
                        <Label>{t('LaboratoryServing.mrn')}</Label>
                    </Col>
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.tokenNo}</span>
                        <br />
                        <Label>{t('LaboratoryServing.token')}</Label>
                    </Col>

                </Row>
                <hr />
                <Row>
                    {/* <Col>
                        <span className="font-weight-bold">{getActionTokenData.isVitalDone ? t('LaboratoryServing.completed') : t('LaboratoryServing.pending')}</span>
                        <br />
                        <Label>{t('LaboratoryServing.vitals')}</Label>
                    </Col> */}
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.appointmentTime}</span>
                        <br />
                        <Label>{t('LaboratoryServing.appointmentTime')}</Label>
                    </Col>
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.checkInTime}</span>
                        <br />
                        <Label>{t('LaboratoryServing.checkInTime')}</Label>
                    </Col>
                    {getTabIndex === ITabIndexEnum.WAITING && <Col>
                        <span className="font-weight-bold">{getActionTokenData.waitingTime}</span>
                        <br />
                        <Label>{t('LaboratoryServing.waitingTime')}</Label>
                    </Col>}
                </Row>


                <hr />

                <div className="QueActns">
                    <Row>
                        <Col sm="10">
                            <Row>
                                {/* <Col sm="4">
                                <FormGroup className="mb-0">
                                    <Label>Room</Label>
                                    <select className="form-control">
                                        <option>Select</option>
                                        <option>Nurse Sation - 04</option>
                                        <option>Waiting Room - 01</option>
                                        <option>Vaitals Room - 03</option>
                                        <option>Xray Room - 02</option>
                                        <option>Doctor Room - 04</option>
                                    </select>
                                </FormGroup>
                            </Col> */}
                                <Col sm="10">
                                    {context?.serve && getTabIndex === ITabIndexEnum.WAITING && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.SERVING)}><button type="button" className="btn btn-sm  btn-success">{t('ActionNames.serve')}</button></span>}
                                    {context?.end && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, getTabIndex === ITabIndexEnum.WAITING ? ITokenActionTypeEnum.END : ITokenActionTypeEnum.SERVED)}><button type="button" className="btn btn-sm  btn-outline-danger">{t('ActionNames.end')}</button></span>}
                                    {context?.noShow && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.NOSHOW)}><button type="button" className="btn btn-sm  btn-outline-danger">{t('ActionNames.noShow')}</button></span>}
                                    {context?.recycle && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.RECYCLE)}><button type="button" className="btn btn-sm btn-success">{t('ActionNames.recycle')}</button></span>}
                                    {context?.recall && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.RECALL)}><button type="button" className="btn btn-sm btn-success">{t('ActionNames.recall')}</button></span>}
                                </Col>
                            </Row>
                        </Col>
                        <Col className="align-right priority">
                            {getActionTokenData?.priority === 0 && <>
                                <img id="lowPriority" src={priority} alt="" onClick={() => changePriority(getActionTokenData, t('LaboratoryServing.highPriority'))} />
                                <UncontrolledTooltip ref={lowPRef} color="primary" placement="top" target="lowPriority">
                                    {t('LaboratoryServing.lowPriority')}
                                </UncontrolledTooltip>
                            </>}
                            {getActionTokenData?.priority === 1 && <>
                                <img id="highPriority" src={priorityColor} alt="" onClick={() => changePriority(getActionTokenData, t('LaboratoryServing.lowPriority'))} />
                                <UncontrolledTooltip ref={highPRef} color="primary" placement="top" target="highPriority">
                                    {t('LaboratoryServing.highPriority')}
                                </UncontrolledTooltip>
                            </>}
                        </Col>
                    </Row>
                </div>
            </>}
        </>
    )
}

export default React.memo(LaboratoryPatientTokenView);