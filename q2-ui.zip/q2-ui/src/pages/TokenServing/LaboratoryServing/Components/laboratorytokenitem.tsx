import React from 'react';
import { useTranslation } from 'react-i18next';
import { Table } from 'reactstrap';
import { ILaboratoryServingModel } from '../../../../models/laboratoryServingModel';
import { setLaboratoryCurrentTokenIdRequestResponse } from '../../../../store/actions';
import { useSelector, useDispatch } from 'react-redux';
import '../../nurse.css';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';

const LaboratoryTokenItem: React.FC<any> = ({ data }) => {

    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const getTabIndex: number = useSelector(state => state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectionTabIndex;
    const getActionTokenId = useSelector(state => {
        if (state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId)
            return state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId;
        else
            return 0;
    });
    console.log("LaboratoryTokenItem =>", data, getActionTokenId);
    const tokenData = useSelector(state => {
        if (data.queueType === 'W') {
            if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.waitingTokensData)
                return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.waitingTokensData.find(x => x.tokenId === data.tokenId);
        }
        else if (data.queueType === 'S') {
            if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.servingTokensData)
                return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servingTokensData.find(x => x.tokenId === data.tokenId);
        }
        return undefined;
    });
    const setSelectedToken = (token) => {
        console.log("setSelectedToken =>", token);
        dispatch(setLaboratoryCurrentTokenIdRequestResponse(token.tokenId));
    }

    return (
        <>
            {tokenData && <div className={"ToknRecordTbl" + (getActionTokenId === tokenData.tokenId ? ' active' : '') + (tokenData.noShow === 1 ? ' noshow' : (tokenData.priority === 1 ? ' priority' : ''))} onClick={() => setSelectedToken(tokenData)}>
                <Table responsive>
                    <tbody>
                        <tr>
                            <td className="font-weight-bold"><div className="ellipsis">{tokenData.patientName}</div></td>
                            <td>{tokenData.tokenNo}</td>
                            {getTabIndex === ITabIndexEnum.CURRENT && <td>{tokenData.roomNumber}</td>}
                        </tr>
                        <tr className="textLignt">
                            <td>{t('LaboratoryServing.mrn')} - {tokenData.mrnNo}</td>
                            <td>{t('LaboratoryServing.token')}</td>
                            {getTabIndex === ITabIndexEnum.CURRENT && <td>{t('LaboratoryServing.roomDetail')}</td>}
                        </tr>
                    </tbody>
                </Table>
            </div>}
        </>
    )
}

export default React.memo(LaboratoryTokenItem);