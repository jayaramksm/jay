import React, { useState, useContext, useEffect } from 'react'
import { SuperParentContext, ParentContext } from '../Container/laboratoryservingcontext';
import { Row, Col, Modal, ModalBody, UncontrolledTooltip } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { ILaboratoryServingModel, IServicesWithCount } from '../../../../models/laboratoryServingModel';
import { withRouter } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import '../../nurse.css';
import { getTokenServingInterval } from '../../../../helpers/helpersIndex';
import { interval } from 'rxjs';
import { setLaboratoryServisesDataRequest } from '../../../../store/actions';

let subscription;
const LaboratoryServiceArea: React.FC = (props: any) => {

    const context = useContext(SuperParentContext);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch()

    const selectedRoom = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectedRoom)
            return true;
        else return false;
    });
    const ServicesTData: IServicesWithCount[] = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.servicesData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servicesData;
        else return [];
    });
    const ServicesDataCount: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.servicesData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servicesData.length;
        else return 0;
    });
    console.log("Lb_Serving_ServicesDataCount =>", ServicesDataCount);
    const selectServiceId = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectedServiceId)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectedServiceId;
        else return 0;
    });
    const ServicesData: IServicesWithCount[] = selectServiceId > 0 ? ServicesTData.filter(x => x.serviceId !== selectServiceId) : ServicesTData;
    const selectServiceData = selectServiceId > 0 ? ServicesTData.find(x => x.serviceId === selectServiceId) : undefined;

    console.log("LaboratoryServiceArea =>", selectedRoom, props, ServicesData, selectServiceId, selectServiceData);

    const [state, setstate] = useState({ modal_large: false });
    const removeBodyCss = () => {
        document.body.classList.add('no_padding');
    }
    const tog_large = () => {
        setstate(prevState => ({
            modal_large: !prevState.modal_large
        }));
        removeBodyCss();
    }

    // const changeDept = () => {
    //     console.log("changeDept =>", props, '/clientprofile');
    //     props.history.push('/clientprofile');
    // }

    useEffect(() => {
        if (subscription)
            subscription.unsubscribe();
        subscription = interval(getTokenServingInterval() * 1000).subscribe(data => {
            dispatch(setLaboratoryServisesDataRequest());
        });
        return () => {
            if (subscription)
                subscription.unsubscribe();
        }
    }, [dispatch]);

    return (
        <>
            <Row className="topSubmenu mb-2">
                <Col>
                    {selectedRoom && <>{selectServiceData && <div className="btn active btn-sm waves-effect" id={"serviceName" + selectServiceData.serviceId}><div className="Sellipsis">{selectServiceData.serviceNameEn}</div>
                    <UncontrolledTooltip color="primary" placement="top" target={"serviceName" + selectServiceData.serviceId}>
                    {selectServiceData.serviceNameEn}
                </UncontrolledTooltip>
                </div>}
                        {ServicesData.slice(0, selectServiceData ? 4 : 5).map((x, index) => {
                            return (<ParentContext.Provider key={index} value={{ data: x }} >
                                <context.serviceComponent />
                            </ParentContext.Provider>)
                        })}
                        {ServicesData.length > (selectServiceData ? 4 : 5) && < div className="btn  btn-sm waves-effect" onClick={tog_large}>{t('LaboratoryServing.otherServices')} &nbsp; <i className="fa fa-angle-down"></i></div>}
                    </>}
                    {/* {context.profilePath &&
                        <button className="btn btn-grey btn-sm" onClick={() => props.history.push(context.profilePath)}>{t('UserProfileManagement.changeWorkspace')}</button>
                    } */}
                </Col>

            </Row>

            {selectedRoom && <Modal className="modal-lg OtrServices" isOpen={state.modal_large} toggle={tog_large} >
                <div className="Clos">
                    <button style={{ marginTop: "10px" }} onClick={() => setstate({ modal_large: false })} type="button" className="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <ModalBody className="pt-0">
                    <h6>{t('LaboratoryServing.otherServices')}</h6>
                    <div className="topSubmenu">
                        {ServicesData.slice(selectServiceData ? 4 : 5, ServicesData.length).map((x, index) => {
                            return (<ParentContext.Provider key={index} value={{ data: x, callbackFn: tog_large }} >
                                <context.serviceComponent />
                            </ParentContext.Provider>)
                        })}
                    </div>
                </ModalBody>
            </Modal>}
        </>
    )
}

export default withRouter(React.memo(LaboratoryServiceArea));
