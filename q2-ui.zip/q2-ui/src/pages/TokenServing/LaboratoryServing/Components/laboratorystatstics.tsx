import React, { useContext } from 'react';
import { Row, Col, Card } from 'reactstrap';
import { useSelector } from 'react-redux';
import { ILaboratoryServingModel } from '../../../../models/laboratoryServingModel';
import '../../nurse.css';
import { ChiledContext } from '../Container/laboratoryservingcontext';
import { useTranslation } from 'react-i18next';
import { IServiceStatasticsDetail } from '../../../../models/utilityClientModel';

export const LaboratoryStatstics: React.FC = () => {

    const context = useContext(ChiledContext);
    const { t } = useTranslation("translations");
    const serviceStatasticsData: IServiceStatasticsDetail[] = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.statasticsData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.statasticsData;
        else return [];
    });
    const serviceStatasticsDataCount: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.statasticsData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.statasticsData.length;
        else return 0;
    });
    const stasticsDetails: IServiceStatasticsDetail | undefined = serviceStatasticsData.find(x => x.name === context);
    console.log("detailedTitle=>", serviceStatasticsData, stasticsDetails, context, serviceStatasticsDataCount);

    return (
        <>
            <Col lg="" md="6" sm="6" xs="12">
                <Card className="widgets">
                    <Row>
                        <Col xs="6" style={{ paddingRight: 0 }}>
                            <h5>{t('LaboratoryServing.' + context)}</h5>
                        </Col>
                        <Col xs="6" className="widget-count">
                            <h2> {stasticsDetails?.count} {stasticsDetails?.timeFormat && <span style={{ fontSize: '18px' }}> {t('LaboratoryServing.min')}</span>}</h2>
                        </Col>
                    </Row>
                </Card>
            </Col>
        </>
    )
}

export default React.memo(LaboratoryStatstics);