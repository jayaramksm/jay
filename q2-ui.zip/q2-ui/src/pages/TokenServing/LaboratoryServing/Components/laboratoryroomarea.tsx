import React from 'react';
import { Label } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { ILaboratoryServingModel, IRoom } from '../../../../models/laboratoryServingModel';
import { Formik, Form } from 'formik';
import { useTranslation } from 'react-i18next';
import { setLaboratoryMappedRoomToUserRequest } from '../../../../store/actions';
import '../../nurse.css';
import { MySelect } from '../../../../helpers/helpersIndex';

const LaboratoryRoomArea: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const roomsData: IRoom[] = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.roomsData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.roomsData;
        else return [];
    });
    const selectedRoom: IRoom = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectedRoom)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectedRoom;
        else return undefined;
    });
    let roomsMapData = roomsData.map((x: IRoom) => ({ value: x.roomId, label: x.roomNameEn + ':' + x.roomNo }));
    console.log("LaboratoryRoomArea =>", roomsData, selectedRoom, roomsMapData);

    const onRoomSelection = (e, setFieldValue) => {
        console.log("onRoomSelection =>", e);
        // setFieldValue('rooms', e);
        dispatch(setLaboratoryMappedRoomToUserRequest(e.value));
    }

    const patchRoom = () => {
        let index = roomsMapData?.findIndex(x => x.value === selectedRoom?.roomId);
        if (index !== -1)
            return { value: roomsMapData[index]?.value, label: roomsMapData[index]?.label }
        else return '';
    }

    return (
        <>
            <div className="w-20 pb-2 plft-1">
                <Formik
                    enableReinitialize
                    initialValues={{
                        rooms: patchRoom()
                    }}
                    onSubmit={(values) => {
                        console.log("onSubmit_Values =>", values);
                    }}
                >
                    {({ values, setFieldValue }) => (
                        <Form>
                            <Label>{t('LaboratoryServing.room')}</Label>
                            <MySelect
                                name="rooms"
                                placeholder={t('LaboratoryServing.selectRoom')}
                                value={values.rooms}
                                onChange={(e) => onRoomSelection(e, setFieldValue)}
                                options={roomsMapData ? roomsMapData : []}
                                getOptionLabel={option => option.label}
                                getOptionValue={option => option.value}
                                noOptionsMessage={() => t('LaboratoryServing.noRooms')}
                            />
                        </Form>
                    )}
                </Formik>
            </div>
        </>
    )
}

export default React.memo(LaboratoryRoomArea);