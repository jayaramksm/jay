import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { ILaboratoryServingModel, ILaboratoryTokens } from '../../../../models/laboratoryServingModel';
import { useTranslation } from 'react-i18next';
import { FixedSizeList as List } from 'react-window';
import { ChiledContext } from '../Container/laboratoryservingcontext';
import '../../nurse.css';

const LaboratoryWatingTokenView: React.FC = () => {

    const { t } = useTranslation("translations");
    const context = useContext(ChiledContext);

    const waitingTokens: ILaboratoryTokens[] = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.waitingTokensData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.waitingTokensData;
        else return [];
    });
    const waitingTokensCount: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.waitingTokensData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.waitingTokensData.length;
        else return 0;
    });
    console.log("LaboratoryWatingTokenView =>", waitingTokens, waitingTokensCount);

    const TokenItem = ({ index, style }) => {
        return (
            <div style={style}>
                <context.tokenItem key={index} data={{ tokenId: waitingTokens[index].tokenId, queueType: 'W' }} />
            </div>
        )
    }



    return (
        <>
            {waitingTokens && waitingTokens.length === 0 && <span>{t('LaboratoryServing.noWaitingTFound')}</span>}

            {waitingTokens && waitingTokens.length > 0 &&
                <List
                    className="nursServ"
                    height={175}
                    itemCount={waitingTokens.length}
                    itemSize={75}
                    width="100%">
                    {TokenItem}
                </List>
            }

        </>
    )
}

export default React.memo(LaboratoryWatingTokenView);