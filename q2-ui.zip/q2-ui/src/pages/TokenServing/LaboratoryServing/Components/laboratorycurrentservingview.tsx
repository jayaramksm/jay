import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { ILaboratoryServingModel, ILaboratoryTokens } from '../../../../models/laboratoryServingModel';
import { useTranslation } from 'react-i18next';
import { ChiledContext } from '../Container/laboratoryservingcontext';
import { FixedSizeList as List } from 'react-window';
import '../../nurse.css';

const LaboratoryCurrentServingView: React.FC = () => {

    const context = useContext(ChiledContext);
    const { t } = useTranslation("translations");
    const servingTokens: ILaboratoryTokens[] = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.servingTokensData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servingTokensData;
        else return [];
    });
    const servingTokensCount: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.servingTokensData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servingTokensData.length;
        else return 0;
    });
    console.log("LaboratoryCurrentServingView =>", servingTokens, servingTokensCount, context);

    const TokenItem = ({ index, style }) => {
        return (
            <div style={style}>
                <context.tokenItem key={index} data={{ tokenId: servingTokens[index].tokenId, queueType: 'S' }} />
            </div>
        )
    }

    return (
        <>
            {servingTokens && servingTokens.length === 0 && <span>{t('LaboratoryServing.noServingTFound')}</span>}

            {servingTokens && servingTokens.length > 0 &&
                <List
                    className="nursServ"
                    height={175}
                    itemCount={servingTokens.length}
                    itemSize={75}
                    width="100%">
                    {TokenItem}
                </List>
            }
        </>
    )
}

export default React.memo(LaboratoryCurrentServingView);