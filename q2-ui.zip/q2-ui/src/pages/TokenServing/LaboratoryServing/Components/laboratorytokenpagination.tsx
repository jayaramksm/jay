import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { ILaboratoryServingModel, ILaboratoryTokens } from '../../../../models/laboratoryServingModel';
import { useTranslation } from 'react-i18next';
import { setLaboratoryCurrentTokenIdRequestResponse } from '../../../../store/actions';
import '../../nurse.css';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';

const TokenPagination: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const getTokenData: ILaboratoryTokens[] = useSelector(state => {
        if (state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId) {

            if (state?.laboratoryServingReducer?.selectionTabIndex === ITabIndexEnum.WAITING) {
                return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.waitingTokensData ?
                    (state?.laboratoryServingReducer as ILaboratoryServingModel)?.waitingTokensData : [];
            }
            else if (state?.laboratoryServingReducer?.selectionTabIndex === ITabIndexEnum.CURRENT) {
                return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servingTokensData ?
                    (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servingTokensData : [];
            }
            else
                return []
        }
        else
            return [];
    });
    const getActionTokenId = useSelector(state => {
        if (state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId)
            return state?.laboratoryServingReducer?.selectionActionArea?.actionTokenId;
        else
            return 0;
    });
    const getActionTokenIndex = getTokenData.findIndex(x => x.tokenId === getActionTokenId);
    console.log("TokenPagination =>", getActionTokenId, getActionTokenIndex);


    const changetokenAction = (value) => {
        dispatch(setLaboratoryCurrentTokenIdRequestResponse(getTokenData[value].tokenId));
    }


    return (
        <>
            {getTokenData.length > 1 && <>
                <button type="button" className="btn btn-sm " disabled={getActionTokenIndex === 0} onClick={() => changetokenAction(getActionTokenIndex - 1)}>
                    <i className="ti-angle-left"></i>{t('ActionNames.back')}
                </button> |
                <button type="button" className="btn btn-sm " disabled={getActionTokenIndex >= getTokenData.length - 1} onClick={() => changetokenAction(getActionTokenIndex + 1)}>
                    {t('ActionNames.next')}
                    <i className="ti-angle-right"></i>
                </button>
            </>}
        </>
    )
}

export default React.memo(TokenPagination);