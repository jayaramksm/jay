import React, { useContext } from 'react'
import { Row, Col, Card, CardBody } from 'reactstrap';
import { ParentContext, ChiledContext } from '../Container/laboratoryservingcontext';
import { useSelector } from 'react-redux';
import { ILaboratoryServingModel } from '../../../../models/laboratoryServingModel';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';
import { useTranslation } from 'react-i18next';
import '../../nurse.css';
import PerfectScrollbar from 'react-perfect-scrollbar';

const LaboratoryParentTokenView: React.FC = () => {

    const { t } = useTranslation("translations");
    const context = useContext(ParentContext);
    console.log("LaboratoryParentTokenView_context =>", context);

    const selectionActionData = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectionActionArea)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectionActionArea;
        else return undefined;
    });

    const getPatientJourneyData = useSelector(state => {
        if (state?.laboratoryServingReducer?.selectionActionArea?.journeyData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectionActionArea?.journeyData
        else
            return undefined;
    });

    const isServingTab = useSelector(state => {
        if (state && state.laboratoryServingReducer && state.laboratoryServingReducer.selectionTabIndex)
            return (state.laboratoryServingReducer as ILaboratoryServingModel).selectionTabIndex === ITabIndexEnum.CURRENT;
        else return false;
    });

    return (
        <>
            {selectionActionData && <>
                <div className="nursCurServ">
                    <PerfectScrollbar>
                        <Row>
                            <Col sm="9">
                                <h6 className="heading">{isServingTab ? t('LaboratoryServing.patientinServing') : t('LaboratoryServing.patientinQueue')} / <span style={{ fontSize: "14px", fontWeight: 500 }}>Service name: Service1</span></h6>
                            </Col>

                            <Col sm="3" className="Qpgnation align-right">
                                {/* Back, Next Buttons */}
                                <context.tokenPagination />
                            </Col>
                        </Row>

                        <Card className="mt-1">
                            <CardBody>
                                <ChiledContext.Provider value={{ actions: context.actions }}>
                                    <context.tokenView />
                                </ChiledContext.Provider>
                            </CardBody>
                        </Card>

                        {(getPatientJourneyData) && <Card>
                            <CardBody>
                                <context.journeyView />
                            </CardBody>
                        </Card>}
                    </PerfectScrollbar>
                </div>
            </>}
        </>
    )
}

export default React.memo(LaboratoryParentTokenView);