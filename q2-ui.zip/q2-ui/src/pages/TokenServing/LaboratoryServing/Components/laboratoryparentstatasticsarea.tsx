import React, { useContext, useState } from 'react'
import { Row, Col, Collapse } from 'reactstrap';
import { SuperParentContext, ParentContext } from '../Container/laboratoryservingcontext';
import { useSelector } from 'react-redux';
import { ILaboratoryServingModel } from '../../../../models/laboratoryServingModel';
import { useTranslation } from 'react-i18next';
import '../../nurse.css';

const LaboratoryParentStatsticsArea: React.FC = () => {

    const [collapse, setCollapse] = useState(true);
    const { t } = useTranslation("translations");
    const context = useContext(SuperParentContext);

    const selectedServiceFlag: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectedServiceId)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectedServiceId > 0;
        else return false;
    });
    console.log("LaboratoryParentStatsticsArea =>", selectedServiceFlag, context);

    return (
        <>
            {selectedServiceFlag > 0 && <><Row>
                <Col sm="6">
                    <div className="heading">
                        {t('LaboratoryServing.serviceDetails')}
                        <button className="btn ml-1" onClick={() => setCollapse(!collapse)}>
                            <i className={collapse ? 'ti-angle-up' : 'ti-angle-down'}></i>
                        </button>
                    </div>
                </Col>
            </Row>
                <Collapse isOpen={collapse} >
                    <Row className="mb-3" style={{ justifyContent: "space-around" }}>
                        {collapse && <ParentContext.Provider value={context}>
                            <context.LaboratoryStatsticsArea />
                        </ParentContext.Provider>}
                    </Row>
                </Collapse></>}
        </>
    )
}

export default React.memo(LaboratoryParentStatsticsArea);