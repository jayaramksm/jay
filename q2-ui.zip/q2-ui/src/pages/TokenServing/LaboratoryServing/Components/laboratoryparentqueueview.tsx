import React, { useContext, useEffect } from 'react';
import { Card, CardBody, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import { ParentContext, ChiledContext } from '../Container/laboratoryservingcontext';
import classnames from 'classnames';
import { useSelector, useDispatch } from 'react-redux';
import { ILaboratoryServingModel } from '../../../../models/laboratoryServingModel';
import { setLaboratoryTabIndexRequest, setLaboratoryTokensDataRequest, setLaboratoryTokensDataRequestSuspend } from '../../../../store/actions';
import { useTranslation } from 'react-i18next';
import '../../nurse.css';
import { getTokenServingInterval } from '../../../../helpers/helpersIndex';
import { interval } from 'rxjs';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';

let subscription;
const LaboratoryParentQueueView: React.FC = () => {

    const { t } = useTranslation("translations");
    const context = useContext(ParentContext);
    const dispatch = useDispatch();
    const getTabIndex = useSelector(state => {
        if (state && state.laboratoryServingReducer) {
            if ((state.laboratoryServingReducer as ILaboratoryServingModel).selectionTabIndex === ITabIndexEnum.WAITING)
                return ITabIndexEnum.WAITING;
            else return ITabIndexEnum.CURRENT;
        }
        else
            return ITabIndexEnum.CURRENT;
    });
    console.log("LaboratoryParentQueueView_context =>", context, getTabIndex);
    const selectedServiceid: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectedServiceId)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectedServiceId;
        else return 0;
    });
    const setTabIndex = (tab) => {
        dispatch(setLaboratoryTabIndexRequest(tab, false));
    };

    useEffect(() => {
        subscription = interval(getTokenServingInterval() * 1000).subscribe(data => {
            if (selectedServiceid > 0) {
                dispatch(setLaboratoryTokensDataRequest(selectedServiceid));
            }
        });
        return () => {
            if (subscription) {
                subscription.unsubscribe();
                dispatch(setLaboratoryTokensDataRequestSuspend());
            }
        }
    }, [selectedServiceid, dispatch]);

    return (
        <>
            <Nav className="nav-tabs-custom">
                <NavItem>
                    <NavLink className={classnames({ active: getTabIndex === ITabIndexEnum.CURRENT })}
                        onClick={() => setTabIndex(ITabIndexEnum.CURRENT)}>
                        <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                        <span className="d-none d-sm-block">{t('LaboratoryServing.currentlyServing')}</span>
                    </NavLink>
                </NavItem>
                <NavItem>
                    <NavLink className={classnames({ active: getTabIndex === ITabIndexEnum.WAITING })}
                        onClick={() => setTabIndex(ITabIndexEnum.WAITING)}>
                        <span className="d-block d-sm-none"><i className="fas fa-user"></i></span>
                        <span className="d-none d-sm-block">{t('LaboratoryServing.waitingQueue')}</span>
                    </NavLink>
                </NavItem>
            </Nav>

            <Card>
                <CardBody>
                    <TabContent activeTab={getTabIndex}>
                        <TabPane tabId={ITabIndexEnum.CURRENT}>
                            <ChiledContext.Provider value={{ tokenItem: context.tokenItem }}>
                                <context.currentTokenView />
                            </ChiledContext.Provider>
                        </TabPane>
                        <TabPane tabId={ITabIndexEnum.WAITING}>
                            <ChiledContext.Provider value={{ tokenItem: context.tokenItem }}>
                                <context.waitingTokenView />
                            </ChiledContext.Provider>
                        </TabPane>
                    </TabContent>
                </CardBody>
            </Card>
        </>
    )
}

export default React.memo(LaboratoryParentQueueView);