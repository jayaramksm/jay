import React, { useContext } from 'react'
import { ParentContext } from '../Container/laboratoryservingcontext';
import { useSelector, useDispatch } from 'react-redux';
import { ILaboratoryServingModel, IServicesWithCount } from '../../../../models/laboratoryServingModel';
import { setLaboratorySelectServiceAndgetStastticsTokensDataRequest } from '../../../../store/actions';
import '../../nurse.css';
import { UncontrolledTooltip } from 'reactstrap';

const LaboratoryService: React.FC = () => {

    const context = useContext(ParentContext);
    const ServicesTData: IServicesWithCount[] = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.servicesData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.servicesData;
        else return [];
    });
    const contextData: IServicesWithCount | undefined = ServicesTData.length > 0 ? ServicesTData.find(x => x.serviceId === context.data.serviceId) : context.data;
    console.log("LaboratoryService_context =>", context);
    const dispatch = useDispatch();

    const setSelectedService = (service) => {
        console.log("setSelectedService =>", service);
        dispatch(setLaboratorySelectServiceAndgetStastticsTokensDataRequest(service, false));
        if (context.callbackFn)
            context.callbackFn();
    }

    return (
        <>
            {contextData && <div className="btn  btn-sm waves-effect" onClick={() => setSelectedService(contextData)}><div className="Sellipsis" id={"serviceName" + contextData.serviceId} >{contextData.serviceNameEn}
                <UncontrolledTooltip color="primary" placement="top" target={"serviceName" + contextData.serviceId}>
                    {contextData.serviceNameEn}
                </UncontrolledTooltip>
            </div>
                {contextData.count > 0 && <div className="count">{contextData.count}</div>}
            </div>}

        </>
    )
}

export default React.memo(LaboratoryService);