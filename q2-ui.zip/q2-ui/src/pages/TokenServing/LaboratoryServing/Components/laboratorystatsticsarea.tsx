import React, { useContext } from 'react'
import { ParentContext, ChiledContext } from '../Container/laboratoryservingcontext';
import { useSelector } from 'react-redux';
import { ILaboratoryServingModel } from '../../../../models/laboratoryServingModel';
import '../../nurse.css';
import { IServiceStatasticsDetail } from '../../../../models/utilityClientModel';
const LaboratoryStatsticsArea: React.FC = () => {

    const context = useContext(ParentContext);
    const serviceStatasticsData: IServiceStatasticsDetail[] = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.statasticsData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.statasticsData;
        else return [];
    });
    const serviceStatasticsDataCount: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.statasticsData)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.statasticsData.length;
        else return 0;
    });

    const selectedServiceid: number = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectedServiceId)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectedServiceId;
        else return 0;
    });
    console.log("LaboratoryStatsticsArea =>", serviceStatasticsData, selectedServiceid, context);


    return (
        <>
            {context.Laboratorystatstics && serviceStatasticsDataCount > 0 && serviceStatasticsData.map((x, index) => {
                return (
                    <ChiledContext.Provider key={index} value={x.name}>
                        <context.Laboratorystatstics />
                    </ChiledContext.Provider>
                )
            })}
        </>
    )
}

export default React.memo(LaboratoryStatsticsArea);