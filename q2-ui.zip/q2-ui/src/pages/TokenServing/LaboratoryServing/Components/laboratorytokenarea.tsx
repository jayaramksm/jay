import React, { useContext } from 'react'
import { useSelector } from 'react-redux';
import { SuperParentContext, ParentContext } from '../Container/laboratoryservingcontext';
import { Row, Col } from 'reactstrap';
import { ILaboratoryServingModel } from '../../../../models/laboratoryServingModel';
import '../../nurse.css';

const LaboratoryTokenArea: React.FC = () => {

    const context = useContext(SuperParentContext);
    console.log("LaboratoryTokenArea_context => ", context);
    const selectServiceFlag = useSelector(state => {
        if (state?.laboratoryServingReducer && state?.laboratoryServingReducer?.selectedServiceId)
            return (state?.laboratoryServingReducer as ILaboratoryServingModel)?.selectedServiceId > 0;
        else return false;
    });
    return (
        <>
            {selectServiceFlag && <div className="PatientView">
                <Row >
                    <Col sm="8" className="NrsLft">
                        {context.parentTokenView &&
                            <ParentContext.Provider key='parentTokenView' value={{ tokenView: context.patientTokenView, journeyView: context.patientJourneyView, tokenPagination: context.tokenPagination, actions: context.actions }}>
                                <context.parentTokenView />
                            </ParentContext.Provider>
                        }
                    </Col>

                    <Col sm="4" className="NrsRgt pl-0">
                        {context.parentQueueView &&
                            <ParentContext.Provider key='parentQueueView' value={{ currentTokenView: context.currentTokenView, waitingTokenView: context.watingTokenView, tokenItem: context.tokenItem }}>
                                <context.parentQueueView />
                            </ParentContext.Provider>
                        }
                    </Col>

                </Row>
            </div>}
        </>
    )
}

export default React.memo(LaboratoryTokenArea);