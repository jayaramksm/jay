import * as React from 'react';
import {
    activateAuthLayout,
    getLaboratoryRoomServicesDataRequest, setResetForLaboratoryServing, cancelPendingLaboratoryServingRequests
} from '../../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import { SuperParentContext } from './laboratoryservingcontext';
// import PerfectScrollbar from 'react-perfect-scrollbar';
import '../../nurse.css';
import {
    LaboratoryRoomArea,
    LaboratoryServiceArea, LaboratoryService, LaboratoryStatsticsArea, Laboratorystatstics,
    LaboratoryTokenArea, LaboratoryParentTokenView, LaboratoryParentQueueView, LaboratoryPatientTokenView, PatientTokenJourneyView,
    LaboratoryCurrentServingView, LaboratoryWatingTokenView, LaboratoryTokenItem, LaboratoryTokenPagination, LaboratoryParentStatsticsArea
} from './laboratoryservingindex';

export interface IProps {
    activateAuthLayout: any;
    getLaboratoryRoomServicesDataRequest: any;
    setResetForLaboratoryServing: any;
    cancelPendingLaboratoryServingRequests: any;
    profilePath: string;
}

class LaboratoryServingManager extends React.Component<IProps, any> {
    constructor(props) {
        super(props)
        this.state = {
            serviceComponent: LaboratoryService,
            statsticsComponent: { Laboratorystatstics: Laboratorystatstics, LaboratoryStatsticsArea: LaboratoryStatsticsArea },
            tokenAreaGrid: {
                parentTokenView: LaboratoryParentTokenView,
                parentQueueView: LaboratoryParentQueueView,
                patientTokenView: LaboratoryPatientTokenView,
                patientJourneyView: PatientTokenJourneyView,
                currentTokenView: LaboratoryCurrentServingView,
                watingTokenView: LaboratoryWatingTokenView,
                tokenItem: LaboratoryTokenItem,
                tokenPagination: LaboratoryTokenPagination,
                actions: { serve: true, end: true, noShow: true, recycle: true, recall: true }
            }
        }
    }
    componentDidMount() {
        console.log("LaboratoryServingManager_componentDidMount=>", this.props);
        this.props.activateAuthLayout();
        this.props.setResetForLaboratoryServing();
        this.props.getLaboratoryRoomServicesDataRequest(true);
    }
    componentWillUnmount() {
        this.props.setResetForLaboratoryServing();
        this.props.cancelPendingLaboratoryServingRequests();
    }

    render() {
        return (
            <>
                <Container fluid className="h-100">

                    <div>
                        <div>

                            <LaboratoryRoomArea />

                            <SuperParentContext.Provider value={{ serviceComponent: this.state.serviceComponent, profilePath: this.props.profilePath }}>
                                <LaboratoryServiceArea />
                            </SuperParentContext.Provider>

                            <SuperParentContext.Provider value={this.state.statsticsComponent}>
                                <LaboratoryParentStatsticsArea />
                            </SuperParentContext.Provider>

                            <SuperParentContext.Provider value={this.state.tokenAreaGrid}>
                                <LaboratoryTokenArea />
                            </SuperParentContext.Provider>

                        </div>
                    </div>
                </Container>
            </>
        )
    }
}

export default withRouter(connect(null, { activateAuthLayout, getLaboratoryRoomServicesDataRequest, setResetForLaboratoryServing, cancelPendingLaboratoryServingRequests })(LaboratoryServingManager));
