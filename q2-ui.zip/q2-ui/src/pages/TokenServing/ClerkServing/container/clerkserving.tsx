import * as React from 'react';
import '../../clerkserving.css';
import {
    Container, Row
} from 'reactstrap';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { activateAuthLayout } from '../../../../store/actions';
// import PerfectScrollbar from 'react-perfect-scrollbar';
import {
    ClerkCurrentServingView,
    ClerkParentQueueView,
    ClerkParentStatsticsArea,
    ClerkParentTokenView,
    ClerkPatientTokenView,
    ClerkRoomArea,
    ClerkStatstics,
    ClerkStatsticsArea,
    ClerkTokenArea,
    ClerkTokenItem,
    ClerkWaitingTokenView,
    TokenPagination,
    PatientTokenJourneyView
} from './clerkservingindex';
import { withTranslation } from 'react-i18next';
import { SuperParentContext } from './clerkservingcontext';
import { getClerkRoomStatisticsDataRequest, setResetForClerk, cancelPendingClerkServingRequests } from '../../../../store/actions';

interface IProps {
    profilePath: any;
    activateAuthLayout: any;
    t: any;
    history: any;
    getClerkRoomStatisticsDataRequest: any;
    setResetForClerk: any;
    cancelPendingClerkServingRequests: any;
}
class ClerkServing extends React.Component<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {
            statsticsComponent: { clerkStatstics: ClerkStatstics, clerkStatsticsArea: ClerkStatsticsArea },
            tokenAreaGrid: {
                parentTokenView: ClerkParentTokenView,
                parentQueueView: ClerkParentQueueView,
                patientTokenView: ClerkPatientTokenView,
                patientJourneyView: PatientTokenJourneyView,
                currentTokenView: ClerkCurrentServingView,
                waitingTokenView: ClerkWaitingTokenView,
                tokenItem: ClerkTokenItem,
                tokenPagination: TokenPagination,
                actions: { serve: true, end: true, noShow: true, recycle: true, recall: true }
            }
        };
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForClerk();
        this.props.getClerkRoomStatisticsDataRequest(true);
    }
    componentWillUnmount() {
        this.props.setResetForClerk();
        this.props.cancelPendingClerkServingRequests();
    }
    render() {
        return (
            <>
                <Container fluid className="h-100">
                    <div>
                        <div>
                            <Row>
                                <ClerkRoomArea />
                                {/* {this.props.profilePath && <Col className="mt-2 pt-4">
                                        <div className="btn btn-grey" onClick={() => this.props.history.push(this.props.profilePath)}>{this.props.t('UserProfileManagement.changeWorkspace')}</div>
                                    </Col>} */}
                            </Row>

                            <SuperParentContext.Provider value={this.state.statsticsComponent}>
                                <ClerkParentStatsticsArea />
                            </SuperParentContext.Provider>

                            <SuperParentContext.Provider value={this.state.tokenAreaGrid}>
                                <ClerkTokenArea />
                            </SuperParentContext.Provider>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
export default withRouter(withTranslation("translations")(connect(null, { activateAuthLayout, getClerkRoomStatisticsDataRequest, setResetForClerk, cancelPendingClerkServingRequests })(ClerkServing)));