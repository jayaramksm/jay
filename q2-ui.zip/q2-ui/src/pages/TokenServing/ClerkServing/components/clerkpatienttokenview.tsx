import React, { useContext, useEffect, useRef } from 'react';
import { Row, Col, UncontrolledTooltip, Label } from 'reactstrap';
import priority from '../../../../images/priority.svg';
import priorityColor from '../../../../images/priority-color.svg';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { ChiledContext } from '../container/clerkservingcontext';
import { IClerkServingModel, IClientTokenDetails } from '../../../../models/clerkServingModel';
import { setClerkTokenActionTypeRequest, setClerkTokenPriorityRequest } from '../../../../store/actions';
import { ITabIndexEnum, ITokenActionTypeEnum } from '../../../../models/utilityClientModel';
import '../../clerkserving.css';

const ClerkPatientTokenView: React.FC = () => {
    const highPRef = useRef<any>(null);
    const lowPRef = useRef<any>(null);
    const { t } = useTranslation("translations");
    const context = useContext(ChiledContext)?.actions;
    const dispatch = useDispatch();

    const getTabIndex: number = useSelector(state => state?.clerkServingReducer as IClerkServingModel)?.selectionTabIndex;
    const getActionTokenData: IClientTokenDetails = useSelector(state => {
        if (state.clerkServingReducer.selectionActionArea && state.clerkServingReducer.selectionActionArea.actionTokenId) {
            if (state?.clerkServingReducer?.selectionTabIndex === ITabIndexEnum.WAITING) {
                return (state?.clerkServingReducer as IClerkServingModel)?.waitingTokensData ?
                    (state?.clerkServingReducer as IClerkServingModel)?.waitingTokensData.find(x => x.tokenId === state?.clerkServingReducer?.selectionActionArea?.actionTokenId) : undefined;
            }
            else if (state?.clerkServingReducer?.selectionTabIndex === ITabIndexEnum.CURRENT) {
                return (state?.clerkServingReducer as IClerkServingModel)?.servingTokensData ?
                    (state?.clerkServingReducer as IClerkServingModel)?.servingTokensData.find(x => x.tokenId === state?.clerkServingReducer?.selectionActionArea?.actionTokenId) : undefined;
            }
            else
                return undefined
        }
        else
            return undefined;
    });
    console.log("ClerkPatientTokenView =>", getActionTokenData, context);

    const tokenAction = (tokenData: IClientTokenDetails, tokenActionType) => {
        console.log("tokenAction =>", tokenData, tokenActionType);
        let message;
        if (tokenActionType === ITokenActionTypeEnum.SERVING)
            message = t('ClerkServing.confirmMessages.CSCM1').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.SERVED)
            message = t('ClerkServing.confirmMessages.CSCM2').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.NOSHOW)
            message = t('ClerkServing.confirmMessages.CSCM3').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.RECYCLE)
            message = t('ClerkServing.confirmMessages.CSCM4').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.END)
            message = t('ClerkServing.confirmMessages.CSCM2').replace('{token}', tokenData.tokenNo);
        else if (tokenActionType === ITokenActionTypeEnum.RECALL)
            message = t('ClerkServing.confirmMessages.CSCM7').replace('{token}', tokenData.tokenNo);
        dispatch(setClerkTokenActionTypeRequest(tokenData, tokenActionType, message, false));
    }

    const changePriority = (tokenData, priority) => {
        let message = t('ClerkServing.confirmMessages.CSCM6').replace('{token}', tokenData.tokenNo).replace('{priority}', priority);
        console.log("changePriority =>", priority, message);
        dispatch(setClerkTokenPriorityRequest(tokenData, message, false));
    }

    useEffect(() => {
        const currentTooltipHigh = highPRef.current;
        const currentTooltipLow = lowPRef.current;
        return () => {
            if (currentTooltipHigh?.state?.isOpen)
                currentTooltipHigh.toggle();
            if (currentTooltipLow?.state?.isOpen)
                currentTooltipLow.toggle();
        }
    });

    return (
        <>
            {getActionTokenData && <>

                <Row>
                    {getActionTokenData?.patientName && <Col>
                        <span className="font-weight-bold">{getActionTokenData.patientName}</span>
                        <br />
                        <Label>{t('ClerkServing.patientname')}</Label>
                    </Col>}
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.mrnNo}</span><br />
                        <Label>{t('ClerkServing.mrn')}</Label>
                    </Col>
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.tokenNo}</span><br />
                        <Label>{t('ClerkServing.token')}</Label>
                    </Col>
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.doctorName}</span><br />
                        <Label>{t('ClerkServing.doctorName')}</Label>
                    </Col>
                </Row>
                <hr />
                <Row>
                    {/* <Col>
                        <span className="font-weight-bold">{getActionTokenData.isVitalDone ? t('ClerkServing.completed') : t('ClerkServing.pending')}</span><br />
                        <Label>{t('ClerkServing.vitals')}</Label>
                    </Col> */}
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.appointmentTime}</span><br />
                        <Label>{t('ClerkServing.appointmentTime')}</Label>
                    </Col>
                    <Col>
                        <span className="font-weight-bold">{getActionTokenData.checkInTime}</span><br />
                        <Label>{t('ClerkServing.checkInTime')}</Label>
                    </Col>
                    {getTabIndex === ITabIndexEnum.WAITING && <Col>
                        <span className="font-weight-bold">{getActionTokenData.waitingTime}</span><br />
                        <Label>{t('ClerkServing.waitingTime')}</Label>
                    </Col>}
                </Row>


                <hr />

                <div className="QueActns">
                    <Row>
                        <Col sm="10">
                            <Row>
                                {/* <Col sm="4">
                                <FormGroup className="mb-0">
                                    <Label>Room</Label>
                                    <select className="form-control">
                                        <option>Select</option>
                                        <option>Nurse Sation - 04</option>
                                        <option>Waiting Room - 01</option>
                                        <option>Vaitals Room - 03</option>
                                        <option>Xray Room - 02</option>
                                        <option>Doctor Room - 04</option>
                                    </select>
                                </FormGroup>
                            </Col> */}
                                <Col sm="10">
                                    {context?.serve && getTabIndex === ITabIndexEnum.WAITING && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.SERVING)}><button type="button" className="btn btn-sm  btn-success">{t('ActionNames.serve')}</button></span>}
                                    {context?.end && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, getTabIndex === ITabIndexEnum.WAITING ? ITokenActionTypeEnum.END : ITokenActionTypeEnum.SERVED)}><button type="button" className="btn btn-sm  btn-outline-danger">{t('ActionNames.end')}</button></span>}
                                    {context?.noShow && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.NOSHOW)}><button type="button" className="btn btn-sm  btn-outline-danger">{t('ActionNames.noShow')}</button></span>}
                                    {context?.recycle && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.RECYCLE)}><button type="button" className="btn btn-sm btn-success">{t('ActionNames.recycle')}</button></span>}
                                    {context?.recall && getTabIndex === ITabIndexEnum.CURRENT && <span className="nrsActn" onClick={() => tokenAction(getActionTokenData, ITokenActionTypeEnum.RECALL)}><button type="button" className="btn btn-sm btn-success">{t('ActionNames.recall')}</button></span>}
                                </Col>
                            </Row>
                        </Col>
                        <Col className="align-right priority">
                            {getActionTokenData?.priority === 0 && <>
                                <img id="lowPriority" src={priority} alt="" onClick={() => changePriority(getActionTokenData, t('ClerkServing.highPriority'))} />
                                <UncontrolledTooltip ref={lowPRef} color="primary" placement="top" target="lowPriority">
                                    {t('ClerkServing.lowPriority')}
                                </UncontrolledTooltip>
                            </>}
                            {getActionTokenData?.priority === 1 && <>
                                <img id="highPriority" src={priorityColor} alt="" onClick={() => changePriority(getActionTokenData, t('ClerkServing.lowPriority'))} />
                                <UncontrolledTooltip ref={highPRef} color="primary" placement="top" target="highPriority">
                                    {t('ClerkServing.highPriority')}
                                </UncontrolledTooltip>
                            </>}
                        </Col>
                    </Row>
                </div>
            </>}
        </>
    )
}

export default React.memo(ClerkPatientTokenView);