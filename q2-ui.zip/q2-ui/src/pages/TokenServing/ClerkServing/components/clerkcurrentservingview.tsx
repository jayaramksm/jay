import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { ChiledContext } from '../container/clerkservingcontext';
import { FixedSizeList as List } from 'react-window';
import '../../clerkserving.css';
import { IClerkServingModel, IClientTokenDetails } from '../../../../models/clerkServingModel';

const ClerkCurrentServingView: React.FC = () => {
    const context = useContext(ChiledContext);
    const { t } = useTranslation("translations");
    const servingTokens: IClientTokenDetails[] = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.servingTokensData)
            return (state?.clerkServingReducer as IClerkServingModel)?.servingTokensData;
        else return [];
    });
    const servingTokensCount: number = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.servingTokensData)
            return (state?.clerkServingReducer as IClerkServingModel)?.servingTokensData.length;
        else return 0;
    });
    console.log("ClerkCurrentServingView =>", servingTokens, servingTokensCount, context);

    const TokenItem = ({ index, style }) => {
        return (
            <div style={style}>
                <context.tokenItem key={index} data={{ tokenId: servingTokens[index].tokenId, queueType: 'S' }} />

            </div>
        )
    }

    return (
        <>
            {servingTokens && servingTokens.length === 0 && <span>{t('ClerkServing.noServingTFound')}</span>}

            {servingTokens && servingTokens.length > 0 &&
                <List
                    className="CurrntView ClerkServ"
                    height={175}
                    itemCount={servingTokens.length}
                    itemSize={75}
                    width="100%">
                    {TokenItem}
                </List>
            }
        </>
    )
}

export default React.memo(ClerkCurrentServingView);