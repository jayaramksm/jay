import React, { useContext } from 'react'
import { useSelector } from 'react-redux';
import { SuperParentContext, ParentContext } from '../container/clerkservingcontext';
import { Row, Col } from 'reactstrap';
import { IClerkServingModel } from '../../../../models/clerkServingModel';
import '../../clerkserving.css';

const ClerkTokenArea: React.FC = () => {
    const context = useContext(SuperParentContext);
    console.log("ClerkTokenArea_context => ", context);

    const selectedRoomExists: number = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.selectedRoom)
            return (state.clerkServingReducer as IClerkServingModel).selectedRoom.roomId > 0;
        else return false;
    });

    return (
        <>
            {selectedRoomExists && <div className="PatientView">
                <Row >
                    <Col sm="8" className="NrsLft">
                        {context.parentTokenView &&
                            <ParentContext.Provider key='parentTokenView' value={{ tokenView: context.patientTokenView, journeyView: context.patientJourneyView, tokenPagination: context.tokenPagination, actions: context.actions }}>
                                <context.parentTokenView />
                            </ParentContext.Provider>
                        }
                    </Col>
                    <Col sm="4" className="NrsRgt pl-0">
                        {context.parentQueueView &&
                            <ParentContext.Provider key='parentQueueView' value={{ currentTokenView: context.currentTokenView, waitingTokenView: context.waitingTokenView, tokenItem: context.tokenItem }}>
                                <context.parentQueueView />
                            </ParentContext.Provider>
                        }
                    </Col>
                </Row>
            </div>}
        </>
    )
}

export default React.memo(ClerkTokenArea);