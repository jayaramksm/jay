import React from 'react';
import { Label, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { Formik, Form } from 'formik';
import { useTranslation } from 'react-i18next';
import { setClerkMappedRoomToUserRequest } from '../../../../store/actions';
import { IClerkServingModel, IRoom } from '../../../../models/clerkServingModel';
import '../../clerkserving.css';
import { MySelect } from '../../../../helpers/helpersIndex';

const ClerkRoomArea: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const roomsData: IRoom[] = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.roomsData)
            return (state?.clerkServingReducer as IClerkServingModel)?.roomsData;
        else return [];
    });
    const selectedRoom: IRoom = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.selectedRoom)
            return (state?.clerkServingReducer as IClerkServingModel)?.selectedRoom;
        else return undefined;
    });
    let roomsMapData = roomsData.map((x: IRoom) => ({ value: x.roomId, label: x.roomNameEn + ':' + x.roomNo }));
    console.log("ClerkRoomArea =>", roomsData, selectedRoom, roomsMapData);

    const onRoomSelection = (e, setFieldValue) => {
        console.log("onRoomSelection =>", e);
        // setFieldValue('rooms', e);
        dispatch(setClerkMappedRoomToUserRequest(e.value));
    }

    const patchRoom = () => {
        let index = roomsMapData?.findIndex(x => x.value === selectedRoom?.roomId);
        if (index !== -1)
            return { value: roomsMapData[index]?.value, label: roomsMapData[index]?.label }
        else return '';
    }

    return (
        <>
            <Col sm="3" className="pb-2 plft-16">
                <Formik
                    enableReinitialize
                    initialValues={{
                        rooms: patchRoom()
                    }}
                    onSubmit={(values) => {
                        console.log("onSubmit_Values =>", values);
                    }}
                >
                    {({ values, setFieldValue }) => (
                        <Form>
                            <Label>{t('ClerkServing.room')}</Label>
                            <MySelect
                                name="rooms"
                                placeholder={t('ClerkServing.selectRoom')}
                                value={values.rooms}
                                onChange={(e) => onRoomSelection(e, setFieldValue)}
                                options={roomsMapData ? roomsMapData : []}
                                getOptionLabel={option => option.label}
                                getOptionValue={option => option.value}
                                noOptionsMessage={() => t('ClerkServing.noRooms')}
                            />
                        </Form>
                    )}
                </Formik>
            </Col>
        </>
    )
}

export default React.memo(ClerkRoomArea);