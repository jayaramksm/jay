import React, { useContext } from 'react'
import { ParentContext, ChiledContext } from '../container/clerkservingcontext';
import { useSelector } from 'react-redux';
// import { interval } from 'rxjs';
// import { getTokenServingInterval } from '../../../../helpers/helpersIndex';
// import { setClerkStatasticsDataRequest, setClerkStatasticsDataRequestSuspend } from '../../../../store/actions';
import { IServiceStatasticsDetail } from '../../../../models/utilityClientModel';
import { IClerkServingModel } from '../../../../models/clerkServingModel';
import '../../clerkserving.css';

// let subscription;
const ClerkStatsticsArea: React.FC = () => {
    const context = useContext(ParentContext);
    // const dispatch = useDispatch();
    const serviceStatasticsData: IServiceStatasticsDetail[] = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.statasticsData)
            return (state?.clerkServingReducer as IClerkServingModel)?.statasticsData;
        else return [];
    });
    const serviceStatasticsDataCount: number = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.statasticsData)
            return (state?.clerkServingReducer as IClerkServingModel)?.statasticsData.length;
        else return 0;
    });

    // const selectedRoomId: number = useSelector(state => {
    //     if (state?.clerkServingReducer && state?.clerkServingReducer?.selectedRoom)
    //         return (state.clerkServingReducer as IClerkServingModel).selectedRoom.roomId;
    //     else return 0;
    // });
    console.log("ClerkStatsticsArea =>", serviceStatasticsData, context);

    // useEffect(() => {
    //     subscription = interval(getTokenServingInterval() * 1000).subscribe(data => {
    //         if (selectedRoomId > 0) {
    //             dispatch(setClerkStatasticsDataRequest(selectedRoomId));
    //         }
    //     });
    //     return () => {
    //         if (subscription) {
    //             subscription.unsubscribe();
    //             dispatch(setClerkStatasticsDataRequestSuspend());
    //         }
    //     }
    // }, []);

    return (
        <>
            {context.clerkStatstics && serviceStatasticsDataCount > 0 && serviceStatasticsData.map((x, index) => {
                return (
                    <ChiledContext.Provider key={index} value={x.name}>
                        <context.clerkStatstics />
                    </ChiledContext.Provider>
                )
            })}
        </>
    )
}

export default React.memo(ClerkStatsticsArea);