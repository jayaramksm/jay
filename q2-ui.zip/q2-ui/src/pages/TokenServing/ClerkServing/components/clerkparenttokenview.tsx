import React, { useContext } from 'react'
import { Row, Col, Card, CardBody } from 'reactstrap';
import { ParentContext, ChiledContext } from '../container/clerkservingcontext';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import '../../clerkserving.css';
import { IClerkServingModel } from '../../../../models/clerkServingModel';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';
import PerfectScrollbar from 'react-perfect-scrollbar';

const ClerkParentTokenView: React.FC = () => {

    const { t } = useTranslation("translations");
    const context = useContext(ParentContext);
    console.log("ClerkParentTokenView_context =>", context);

    const selectionActionData = useSelector(state => {
        if (state?.clerkServingReducer && state?.clerkServingReducer?.selectionActionArea)
            return (state?.clerkServingReducer as IClerkServingModel)?.selectionActionArea;
        else return undefined;
    });

    const getPatientJourneyData = useSelector(state => {
        if (state?.clerkServingReducer?.selectionActionArea?.journeyData)
            return (state?.clerkServingReducer as IClerkServingModel)?.selectionActionArea?.journeyData;
        else
            return undefined;
    });

    const isServingTab = useSelector(state => {
        if (state && state.clerkServingReducer && state.clerkServingReducer.selectionTabIndex)
            return (state.clerkServingReducer as IClerkServingModel).selectionTabIndex === ITabIndexEnum.CURRENT;
        else return false;
    });

    return (
        <>
            {selectionActionData && <>
                <div className="ClerkCurServ">
                    <PerfectScrollbar>
                        <Row>
                            <Col sm="9">
                                <h6 className="heading">{isServingTab ? t('ClerkServing.patientinServing') : t('ClerkServing.patientinQueue')} / <span style={{ fontSize: "14px", fontWeight: 500 }}>Service name: Service1</span></h6>
                            </Col>

                            <Col sm="3" className="Qpgnation align-right">
                                {/* Back, Next Buttons */}
                                <context.tokenPagination />
                            </Col>
                        </Row>

                        <Card className="mt-1">
                            <CardBody>
                                <ChiledContext.Provider value={{ actions: context.actions }}>
                                    <context.tokenView />
                                </ChiledContext.Provider>
                            </CardBody>
                        </Card>

                        {(getPatientJourneyData) && <Card>
                            <CardBody>
                                <context.journeyView />
                            </CardBody>
                        </Card>}
                    </PerfectScrollbar>
                </div>
            </>}
        </>
    )
}

export default React.memo(ClerkParentTokenView);