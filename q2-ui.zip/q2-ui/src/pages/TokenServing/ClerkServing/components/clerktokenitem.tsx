import React from 'react';
import { useTranslation } from 'react-i18next';
import { Table } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import { ITabIndexEnum } from '../../../../models/utilityClientModel';
import { IClerkServingModel } from '../../../../models/clerkServingModel';
import { setClerkCurrentTokenIdRequestResponse } from '../../../../store/actions';
import '../../clerkserving.css';


const ClerkTokenItem: React.FC<any> = ({ data }) => {
    const dispatch = useDispatch();
    const { t } = useTranslation("translations");
    const getTabIndex: number = useSelector(state => state?.clerkServingReducer as IClerkServingModel)?.selectionTabIndex;
    const getActionTokenId = useSelector(state => {
        if (state?.clerkServingReducer?.selectionActionArea?.actionTokenId)
            return state?.clerkServingReducer?.selectionActionArea?.actionTokenId;
        else
            return 0;
    });
    const tokenData = useSelector(state => {
        if (data.queueType === 'W') {
            if (state?.clerkServingReducer && state?.clerkServingReducer?.waitingTokensData)
                return (state?.clerkServingReducer as IClerkServingModel)?.waitingTokensData.find(x => x.tokenId === data.tokenId);
        }
        else if (data.queueType === 'S') {
            if (state?.clerkServingReducer && state?.clerkServingReducer?.servingTokensData)
                return (state?.clerkServingReducer as IClerkServingModel)?.servingTokensData.find(x => x.tokenId === data.tokenId);
        }
        return undefined;
    });
    console.log("ClerkTokenItem =>", data, getActionTokenId, tokenData);

    const setSelectedToken = (token) => {
        console.log("setSelectedToken =>", token);
        dispatch(setClerkCurrentTokenIdRequestResponse(token.tokenId));
    }

    return (
        <>
            {tokenData && <div className={"ToknRecordTbl" + (getActionTokenId === tokenData.tokenId ? ' active' : '') + (tokenData.noShow === 1 ? ' noshow' : (tokenData.priority === 1 ? ' priority' : ''))} onClick={() => setSelectedToken(tokenData)}>
                <Table responsive>
                    <tbody>
                        <tr>
                            <td className="font-weight-bold"><div className="ellipsis">{tokenData.patientName}</div></td>
                            <td>{tokenData.tokenNo}</td>
                            <td><div className="dctrellipsis">{tokenData.doctorName}</div></td>
                            {getTabIndex === ITabIndexEnum.CURRENT && <td>{tokenData.roomNumber}</td>}
                        </tr>
                        <tr className="textLignt">
                            <td>{t('ClerkServing.mrn')} - {tokenData.mrnNo}</td>
                            <td>{t('ClerkServing.token')}</td>
                            <td>{t('ClerkServing.doctorName')}</td>
                            {getTabIndex === ITabIndexEnum.CURRENT && <td>{t('ClerkServing.roomDetail')}</td>}
                        </tr>
                    </tbody>
                </Table>
            </div>}
        </>
    )
}

export default React.memo(ClerkTokenItem);