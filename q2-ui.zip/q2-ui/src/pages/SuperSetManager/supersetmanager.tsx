import * as React from 'react';
import { activateAuthLayout } from '../../store/actions';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { checkAndReplacedTokenInfo, getApiServiceUrlByComponentAndMethod } from 'helpers/helpersIndex';

export interface IProps {
    activateAuthLayout: any;
    profilePath: string;
}
const component = 'SuperSet';
class SuperSetManager extends React.Component<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {
            superSetUrl: null
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        let userComponentAndMethod = getApiServiceUrlByComponentAndMethod(component, this.props.profilePath);
        if (userComponentAndMethod) {
            const { url } = checkAndReplacedTokenInfo(userComponentAndMethod?.url, undefined);
            this.setState({ superSetUrl: url });
        }
        console.log("SuperSetManager=>", this.props.profilePath, userComponentAndMethod);

    }



    render() {

        return (
            <>
                {this.state.superSetUrl &&
                    <iframe
                        width="100%"
                        height="100%"
                        seamless
                        frameBorder="0"
                        scrolling="yes"
                        src={this.state.superSetUrl}
                    ></iframe>
                }
            </>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout })(SuperSetManager));
