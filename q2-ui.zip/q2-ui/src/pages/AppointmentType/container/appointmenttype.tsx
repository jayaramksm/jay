import * as React from 'react';
import {
    activateAuthLayout, setResetForAppointmentTypes, getAppointmentTypesRequest,
    cancelPendingAppointmentTypeRequests
} from '../../../store/actions';
import { Col, Row, Container } from 'reactstrap';
import { connect } from 'react-redux';
import {
    LeftParentAppointmentType,
    RightParentAppointmentType,
    AppointmentTypeBulkUploadComponent,
    AppointmentTypeView,
    AppointmentTypeAction,
    AppointmentTypeItem,
    AppointmentTypeFilter,
    LocationSelectionAppType,
    AppointmentTypeManager,
    AppointmentTypeMapping,
    ParentAppointmentTypeMapping,
    AppointmentTypeAutoRefresh
} from './appointmenttypeindex';
import { SuperParentContext } from './appointmenttypeContestApi';
import './appointmenttype.css';
import { IRoleDesc, IActions } from '../../../models/utilitiesModel';
import { IAppointmentTypeState } from '../../../models/appointmentTypesModel';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../helpers/helpersIndex';

export interface IProps {
    activateAuthLayout: any;
    getAppointmentTypesRequest: any;
    cancelPendingAppointmentTypeRequests: any;
    privileges: any;
    setResetForAppointmentTypes: any;
    loginUserRolecode: string;
    appointmenttypesLoad: any;
    add: boolean;
    edit: boolean;
    delete: boolean;
    bulkUpload: boolean;
}
class AppointMentType extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);
        this.state = {
            leftParentAppointmentType: {
                locationView: props.loginUserRolecode === IRoleDesc.ENTERPRISEADMIN ? LocationSelectionAppType : null,
                filterComponent: AppointmentTypeFilter,
                listComponent: AppointmentTypeManager,
                viewComponent: AppointmentTypeItem,
                actions: { add: this.props.add, bulkUpload: this.props.bulkUpload }
            },
            rightParentAppointmentType: {
                viewComponent: AppointmentTypeView,
                actionComponent: AppointmentTypeAction,
                mappingComponent: AppointmentTypeMapping,
                parentmappingcomponent: ParentAppointmentTypeMapping,
                bulkuploadComponent: AppointmentTypeBulkUploadComponent,
                actions: { edit: this.props.edit, delete: this.props.delete }
            }
        };
    }
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForAppointmentTypes();

        if (this.props.appointmenttypesLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getAppointmentTypesRequest(!this.props.appointmenttypesLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getAppointmentTypesRequest(!this.props.appointmenttypesLoad, true);
    }

    componentWillUnmount() {
        this.props.cancelPendingAppointmentTypeRequests();
        if (this.setinterval)
            clearTimeout(this.setinterval);
        this.props.setResetForAppointmentTypes();
    }

    render() {
        return (
            <>
                {getAutoRefresing() && <AppointmentTypeAutoRefresh />}

                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftParentAppointmentType}>
                                <LeftParentAppointmentType />
                            </SuperParentContext.Provider>
                        </Col>
                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightParentAppointmentType}>
                                <RightParentAppointmentType />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>
            </>
        );
    }
}

const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete', 'bulk_insert'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'appttype', defaultPrivilages);
    if (getAutoRefresing() && state.appointmentTypeReducer && (state.appointmentTypeReducer as IAppointmentTypeState).appointmentTypesData)
        return {
            appointmenttypesLoad: (state.appointmentTypeReducer as IAppointmentTypeState).appointmentTypesData.length > 0 ? true : false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
    else
        return {
            appointmenttypesLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
}

export default connect(mapStatetoProps, { activateAuthLayout, getAppointmentTypesRequest, cancelPendingAppointmentTypeRequests, setResetForAppointmentTypes })(AppointMentType);