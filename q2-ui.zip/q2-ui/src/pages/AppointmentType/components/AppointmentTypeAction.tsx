import React from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { IAppointmentTypeState } from '../../../models/appointmentTypesModel';
import { IApptType } from '../../../models/servicesModel';
import { suspendOrEditAppointMentTYpesAction, createOrUpdateAppointmentTypeRequest } from '../../../store/actions';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import { CardBody, Card, Col, Row, FormGroup, Label } from 'reactstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { customContentValidation } from '../../../helpers/helpersIndex';
import * as Yup from 'yup';
import '../container/appointmenttype.css';

const AppointmentTypeAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const sessionData: ISessionstate = useSelector(state => {
        return state.SessionState
    });
    const appointmentTypeActionData = useSelector(state => {
        if ((state.appointmentTypeReducer))
            return (state.appointmentTypeReducer as IAppointmentTypeState) ?
                (state.appointmentTypeReducer).actionData : undefined
        else
            return undefined
    }) as IApptType;

    const actionType = useSelector(state => {
        if (state && state.appointmentTypeReducer && state.appointmentTypeReducer.actionType)
            return state.appointmentTypeReducer.actionType;
        else return 0;
    });


    const cancelEditFunction = () => {
        dispatch(suspendOrEditAppointMentTYpesAction(actionType === IOprationalActions.EDIT ? IOprationalActions.SELECT : 0));
    }
    return (
        <>
            {(actionType === IOprationalActions.ADD || actionType === IOprationalActions.EDIT) && <Card>
                <CardBody>
                    <Formik
                        enableReinitialize
                        initialValues={{
                            apptTypeId: appointmentTypeActionData ? appointmentTypeActionData.apptTypeId : 0,
                            apptType: appointmentTypeActionData ? appointmentTypeActionData.apptType : '',
                            apptCode: appointmentTypeActionData ? appointmentTypeActionData.apptCode : '',
                            locationId: appointmentTypeActionData ? appointmentTypeActionData.locationId : (sessionData ? sessionData.locationId : 0),

                        }}
                        validationSchema={Yup.object().shape({

                            apptType: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
                            apptCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: ':' }, 50, 2),
                            locationId: ''
                        })}
                        onSubmit={(values) => {
                            console.log("Values =>", values);

                            let appointmentType = {
                                apptTypeId: values.apptTypeId,
                                apptType: values.apptType,
                                apptCode: values.apptCode,
                                locationId: values.locationId
                            } as IApptType
                            console.log("Values =>", values, appointmentType);
                            dispatch(createOrUpdateAppointmentTypeRequest(appointmentType, t('AppointmentType.confirmMessages.AC3'), t('AppointmentType.confirmMessages.AC4')))

                        }}
                    >
                        {({ errors, touched, dirty }) => (
                            <Form>
                                <Row>
                                    <Col sm="12">

                                        <Row className="FormStyle">
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Field name="apptType" placeholder={t('AppointmentType.appointmentType')}
                                                        className={'form-control ' + (errors.apptType && touched.apptType ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="apptType" component="div" className="invalid-feedback" />
                                                    <Label>{t('AppointmentType.appointmentType')}</Label>
                                                </FormGroup>
                                            </Col>
                                            <Col sm="4">
                                                <FormGroup>
                                                    <Field name="apptCode" placeholder={t('AppointmentType.appointmentCode')}
                                                        className={'form-control ' + (errors.apptCode && touched.apptCode ? 'is-invalid' : '')} />
                                                    <ErrorMessage name="apptCode" component="div" className="invalid-feedback" />
                                                    <Label>{t('AppointmentType.appointmentCode')}</Label>
                                                </FormGroup>
                                            </Col>
                                        </Row>



                                        <hr />
                                        <Row className="align-center action">


                                            <Col className="text-right">

                                                <button type="submit" disabled={!(dirty)} className="btn btn-primary" >{actionType === IOprationalActions.EDIT ? t('ActionNames.update') : t('ActionNames.save')}</button>
                                                <button className="btn btn-cancel ml-3" onClick={cancelEditFunction}>Cancel</button>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>
                            </Form>
                        )}
                    </Formik>
                </CardBody>
            </Card>}
        </>

    )

}
export default React.memo(AppointmentTypeAction);