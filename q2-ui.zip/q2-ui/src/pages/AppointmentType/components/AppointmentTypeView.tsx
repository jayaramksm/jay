import * as React from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { useContext } from 'react';
import { ParentContext } from '../container/appointmenttypeContestApi';
import { Label, Card, CardBody, Row, Col, UncontrolledTooltip } from 'reactstrap';
import { deleteAppointmentTypeRequest, suspendOrEditAppointMentTYpesAction, fetchDoctorUsersToMapApptTypeRequest } from '../../../store/actions';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import '../container/appointmenttype.css'
import { IAppointmentTypeState } from '../../../models/appointmentTypesModel';
import { IApptType } from '../../../models/servicesModel';

const AppointmentTypeView: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const context: any = useContext(ParentContext);
    const appointmentTypeActionData = useSelector(state => {
        if ((state.appointmentTypeReducer))
            return (state.appointmentTypeReducer as IAppointmentTypeState) ?
                (state.appointmentTypeReducer).actionData : undefined
        else
            return undefined
    }) as IApptType;

    console.log("appointmentTypeActionData", appointmentTypeActionData);
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });

    const isMappingAction = useSelector(state => {
        if (state.appointmentTypeReducer && state.appointmentTypeReducer.actionType)
            return (state.appointmentTypeReducer).actionType === IOprationalActions.MAPPING;
        else return false;
    })
    const isSelectAction = useSelector(state => {
        if (state.appointmentTypeReducer && state.appointmentTypeReducer.actionType)
            return (state.appointmentTypeReducer).actionType === IOprationalActions.SELECT;
        else return false;
    })
    const editAppointmentType = () => {
        dispatch(suspendOrEditAppointMentTYpesAction(IOprationalActions.EDIT));
    }

    const deleteAppointmentType = (appointmentTypeData: IApptType) => {
        const message = t('AppointmentType.confirmMessages.AC2').replace('{apptype}', appointmentTypeData.apptType)
        dispatch(deleteAppointmentTypeRequest(IOprationalActions.DELETE, appointmentTypeData.apptTypeId, message, false));
    }
    const mappingDoctors = (medService) => {
        dispatch(fetchDoctorUsersToMapApptTypeRequest(medService));
    }
    const backToView = () => {
        dispatch(suspendOrEditAppointMentTYpesAction(isMappingAction ? IOprationalActions.SELECT : 0));
    }


    return (<>
        {(isSelectAction || isMappingAction) && appointmentTypeActionData && <Card>
            <CardBody>
                <Row>
                    <Col sm="12">
                        <Row className="viewmedsrc">
                            <Col sm="4">
                                <Label>{t('AppointmentType.appointmentType')}</Label>
                                <br />
                                <span>{appointmentTypeActionData.apptType}</span>
                            </Col>
                            <Col sm="3">
                                <Label>{t('AppointmentType.appointmentCode')}</Label><br />
                                <span>{appointmentTypeActionData.apptCode}</span>
                            </Col>
                        </Row>
                        <hr />
                        <Row className="align-center action">
                            {isMappingAction && <Col>
                                <i className="ti-arrow-left pl-0" onClick={backToView}></i>
                            </Col>}
                            <Col className="text-right">
                                {!isMappingAction && selectedLocationStatus && <>
                                    <i id="mapping" className="ti-link" onClick={() => { mappingDoctors(appointmentTypeActionData) }}></i>
                                    <UncontrolledTooltip color="primary" placement="top" target="mapping">
                                        {t('ActionNames.map')}
                                    </UncontrolledTooltip>
                                </>}
                                {context.edit && selectedLocationStatus && !isMappingAction && <>
                                    <i id="edit" className="ti-pencil-alt" onClick={() => editAppointmentType()}></i>
                                    <UncontrolledTooltip color="primary" placement="top" target="edit">
                                        {t('ActionNames.edit')}
                                    </UncontrolledTooltip>
                                </>}

                                {context.delete && selectedLocationStatus && !isMappingAction && <>
                                    <i id="delete" className="ti-trash" onClick={() => deleteAppointmentType(appointmentTypeActionData)}></i>
                                    <UncontrolledTooltip color="primary" placement="top" target="delete">
                                        {t('ActionNames.delete')}
                                    </UncontrolledTooltip>
                                </>}
                            </Col>
                        </Row>
                    </Col>
                </Row>
            </CardBody>
        </Card>}


    </>)
}
export default React.memo(AppointmentTypeView);