import * as React from 'react';
import {   changeLocationForAppType } from '../../../store/actions';
import { LocationSelectArea } from '../../../pages/Utilities/LocationSelectArea';
import '../container/appointmenttype.css'
 const LocationSelectionAppType: React.FC = () => {
 
    return (<>
        <LocationSelectArea locationCallBack={changeLocationForAppType} />
    
    </>)
}
export default React.memo(LocationSelectionAppType);