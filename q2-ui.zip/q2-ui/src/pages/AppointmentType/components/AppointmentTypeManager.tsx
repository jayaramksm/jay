import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import { Col, Row } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { ParentContext, ChildContext } from '../container/appointmenttypeContestApi';
import { IApptType } from '../../../models/servicesModel';
import { PaginationComponent } from '../../../pages/Utilities/PaginationComponent';
import '../container/appointmenttype.css';

import PerfectScrollbar from 'react-perfect-scrollbar';

export const AppointmentTypeManager: React.FC = () => {
    const { t } = useTranslation("translations");
    const context = useContext(ParentContext);
    const pageSize = getEnvironment.listPageSize;
    const searchKey = useSelector(state => {
        if (state && state.appointmentTypeReducer && state.appointmentTypeReducer.appointmentTypesData) {
            if (state.appointmentTypeReducer.searchKey)
                return state.appointmentTypeReducer.searchKey;
            else
                return ''
        }
        else
            return ''

    });
    const appointmentTypeTData: IApptType[] = useSelector(state => {
        if (state && state.appointmentTypeReducer && state.appointmentTypeReducer.appointmentTypesData) {
            return state.appointmentTypeReducer.appointmentTypesData;

        }
        else return undefined;
    });

    const appointmentTypesData: IApptType[] = (searchKey && searchKey !== '') ?
        appointmentTypeTData.filter(x => x.apptType.toLowerCase().startsWith(searchKey.toLowerCase())) : appointmentTypeTData;

    let appointmentTypesCount = useSelector(state => {
        if (state && state.appointmentTypeReducer && state.appointmentTypeReducer.appointmentTypesData)
            return state.appointmentTypeReducer.appointmentTypesData.length;
        else return 0;
    });
    console.log("appointmentTypesCount=>", appointmentTypesCount);

    let pagesCount = Math.ceil((appointmentTypesData ? appointmentTypesData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }
    return (<>
        {appointmentTypesData && appointmentTypesData.length === 0 && searchKey && <span className="recdnotfound">{t('AppointmentType.noAppointmentTypes')}</span>}
        {appointmentTypesData && appointmentTypesData.length === 0 && searchKey === '' && <span className="recdnotfound">{t('AppointmentType.noApptTypes')}</span>}
        <Row className="flexLayout-inner">
            <PerfectScrollbar>
                <Col sm="12" className="actn-list pt-1">
                    {appointmentTypesData && appointmentTypesData.length > 0 && appointmentTypesData.slice(currentPage * pageSize,
                        (currentPage + 1) * pageSize).map((item, index) => (
                            <ChildContext.Provider key={item.apptTypeId} value={item.apptTypeId}>
                                <context.viewComponent />
                            </ChildContext.Provider>
                        ))}
                </Col>
            </PerfectScrollbar>
        </Row>
        <Row className="lft-pagination">
            {appointmentTypesData && appointmentTypesData.length > pageSize &&
                <div className="pagination ml-4">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            }
        </Row>
    </>)
}


export default React.memo(AppointmentTypeManager);