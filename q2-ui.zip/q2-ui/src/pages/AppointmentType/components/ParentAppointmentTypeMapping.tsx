import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../container/appointmenttypeContestApi';
import { IOprationalActions } from '../../../models/utilitiesModel';

const ParentAppointmentTypeMapping :React.FC=()=>{
    const context: any = useContext(SuperParentContext);
    const isMappingAction=useSelector(state=>{
        if(state.appointmentTypeReducer && state.appointmentTypeReducer.actionType)
        return (state.appointmentTypeReducer).actionType===IOprationalActions.MAPPING; 
        else return false;
    })
    return(
        <>
              {isMappingAction && <context.mappingComponent />}

        </>
    )
}
export default React.memo(ParentAppointmentTypeMapping);
