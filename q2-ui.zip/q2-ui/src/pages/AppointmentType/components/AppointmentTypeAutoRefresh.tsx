import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {IAppointmentTypeState} from '../../../models/appointmentTypesModel'
import { getAppointmentTypesRequest } from '../../../store/actions';
import '../container/appointmenttype.css';
import {UncontrolledTooltip} from 'reactstrap';
import { useTranslation } from 'react-i18next';
const AppointmentTypeAutoRefresh: React.FC = () => {
    const { t } = useTranslation("translations");

    const dispatch = useDispatch();

    const refreshLoading = useSelector(state => {
        if (state && state.appointmentTypeReducer)
            return (state.appointmentTypeReducer as IAppointmentTypeState).refreshLoading
        else
            return false;
    })
    return (
        <>
            <div className="pageReload">  {!refreshLoading && 
            <><i className="ti-reload" id="APtooltip" onClick={() => dispatch(getAppointmentTypesRequest(true, true))}></i>
            <UncontrolledTooltip color="primary" placement="top" target="APtooltip">
                {t('ActionNames.autoRefresh')}    
            </UncontrolledTooltip>
                                          </>}
                {refreshLoading && <i className="ti-reload pgrlad-rfrsh" ></i>} </div>
        </>
    )
}
export default React.memo(AppointmentTypeAutoRefresh)