import React from 'react';
import '../container/appointmenttype.css';
import { useDispatch } from 'react-redux';
import { Col, Row, Card, CardBody, FormGroup, Label } from 'reactstrap';
import { useSelector } from 'react-redux';
import { IOprationalActions, ISessionstate, IUserDetails } from '../../../models/utilitiesModel';
import { IBulkUploadApptTypeData, IColumnsData } from '../../../models/appointmentTypesModel';
import { bulkUploadAppTypeSubmitActionRequest, suspendOrEditAppointMentTYpesAction } from '../../../store/appointmenttypes/actions';
import { defultContentValidate, customContentValidation, MySelect } from 'helpers/helpersIndex';
import { DownloadExcel, DownloadCsv } from '../../../helpers/helpersIndex';
import Papa from 'papaparse';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import * as _ from 'lodash';
import * as XLSX from 'xlsx';
import { useTranslation } from 'react-i18next';
import csv from '../../../images/csv.svg';
import xls from '../../../images/xls.svg';
import xlsx from '../../../images/xlsx.svg';
import info from '../../../images/info.svg';

const headerNames = {
    AppointmentType: "AppointmentType*",
    AppointmentCode: "AppointmentCode*",
    ResourceCode: "ResourceCode*"
}

const AppointmentTypeBulkUploadComponent: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const sampleData = [
        {
            [headerNames.AppointmentType]: '',
            [headerNames.AppointmentCode]: '',
            [headerNames.ResourceCode]: ''
        }
    ];

    const DownloadXlsRequest = () => {
        const res = DownloadExcel(null, '', sampleData, 'Appointment.xls', '')
        console.log('DownloadExcelRequest=>', res);
    }
    const DownloadExcelRequest = () => {
        const res = DownloadExcel(null, '', sampleData, 'Appointment.xlsx', '')
        console.log('DownloadExcelRequest=>', res);
    }
    const DownloadCsvRequest = () => {
        const res = DownloadCsv(null, '', sampleData, 'AppointmentType', '');
        console.log('DownloadCsvRequest=>', res);
    }

    const getColumnsPatch = (keysData, setFieldValue) => {

        let index: any = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.AppointmentType.toLowerCase());
        if (index !== -1)
            setFieldValue('apptType', keysData[index].value);

        const index1 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.AppointmentCode.toLowerCase());
        if (index1 !== -1)
            setFieldValue('apptCode', keysData[index1].value);

        const index2 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.ResourceCode.toLowerCase());
        if (index2 !== -1)
            setFieldValue('resourceCode', keysData[index2].value);

    }
    const validationSchema = {
        appointmentType: Yup.object().shape({
            apptType: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricallspecials', message: 'alphanumaricallspecials', spacialChar: null }, 50, 2),
            apptCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: ':' }, 50, 2),
            resourceCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: ':' }, 10, 2)
        })
    }

    const cancelEditFunction = () => {
        dispatch(suspendOrEditAppointMentTYpesAction(IOprationalActions.UNSELECT));
    }
    const sessionData: ISessionstate = useSelector(state => {
        return state.SessionState
    });
    const isBulkAction = useSelector(state => {
        if (state.appointmentTypeReducer && state.appointmentTypeReducer.actionType)
            return (state.appointmentTypeReducer).actionType === IOprationalActions.BULKUPLOAD;
        else return false;
    })

    const sheetSelection = (e, setFieldValue, values) => {
        setFieldValue('resourceCode', '');
        setFieldValue('apptCode', '');
        setFieldValue('apptType', '');
        let ind = values.excelSheetData.findIndex(x => x.viewValue === e.value);
        console.log("onSheetSelection==>", e, values, ind);

        if (ind !== -1) {
            setFieldValue('selectedSheet', e);
            setFieldValue('columnsData', []);
            let columndata = values.excelSheetData[ind].value;
            let keysData = (columndata[0] as any[]).filter(x => x);
            let papaColumnsData = keysData.map(x => ({ label: x, value: x }));
            setFieldValue('columnsData', keysData.map(x => ({ label: x, value: x })));
            setFieldValue('fileDataCount', columndata?.length - 1);
            getColumnsPatch(papaColumnsData, setFieldValue);
            console.log("keysData=>", keysData, columndata, values);
        }
        else {
            setFieldValue('selectedSheet', null);
            setFieldValue('columnsData', null);
        }
    }

    const uploadFile = (event, setFieldValue) => {

        if (event.target.value) {
            setFieldValue('resourceCode', '');
            setFieldValue('apptCode', '');
            setFieldValue('apptType', '');
            setFieldValue('excelSheetData', []);
            setFieldValue('sheetList', '');
            setFieldValue('fileName', '');
            setFieldValue('columnsData', '');
            setFieldValue('fileDataCount', '');
            setFieldValue('extension', '');
            setFieldValue('selectedSheet', '');
            const fileList: FileList = event.target.files;
            console.log("frmData=>1", event.target.files);
            if (fileList.length > 0) {
                const file: File = fileList[0];
                console.log("File", file);
                let extension = (file.name as string).split('.').pop();
                let fileSize = file.size / 1024 / 1024;
                console.log("File", file, fileSize);
                if (fileSize < 5) {
                    if (extension === "xlsx" || extension === "xls" || extension === "csv") {
                        setFieldValue('extension', extension);
                        setFieldValue('uploadedFile', fileList[0]);
                        setFieldValue('fileName', fileList[0].name);
                        if (extension === "xlsx" || extension === "xls") {
                            const reader: FileReader = new FileReader();
                            reader.onload = (e: any) => {
                                const arrayBuffer = e.target.result,
                                    data = new Uint8Array(arrayBuffer),
                                    arr = new Array();
                                for (let i = 0; i !== data.length; ++i) {
                                    arr[i] = String.fromCharCode(data[i]);
                                }
                                const bstr: string = arr.join('');
                                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
                                let excelSheetData: any = [];
                                let excelSheetList: any = [];
                                wb.SheetNames.forEach(element => {
                                    let wsname: string = element;
                                    let ws: XLSX.WorkSheet = wb.Sheets[wsname];
                                    let data1 = ((XLSX.utils.sheet_to_json(ws, { header: 1 })));
                                    data1 = data1.filter(z => (z as any[])?.length > 0)
                                    if (data1?.length > 1) {
                                        excelSheetList.push({ value: element, label: element });
                                        excelSheetData.push({ value: data1, viewValue: wsname })
                                    }
                                });
                                if (excelSheetData?.length === 0)
                                    setFieldValue('invalidFileExtensionError', t('controleErrors.selectValidFile'));
                                if (excelSheetList?.length === 1) {
                                    setFieldValue('sheetList', excelSheetList);
                                    setFieldValue('selectedSheet', excelSheetList[0]);
                                    let columndata = excelSheetData[0].value;
                                    let keysData = (columndata[0] as any[]).filter(x => x).map(x => ({ value: x, label: x }));
                                    setFieldValue('columnsData', keysData);
                                    setFieldValue('fileDataCount', excelSheetData[0].value.length - 1);
                                    getColumnsPatch(keysData, setFieldValue);
                                }
                                console.log('uploadFile_excelSheetData=>', excelSheetData);
                                setFieldValue('excelSheetData', excelSheetData);
                                setFieldValue('sheetList', excelSheetList);

                            }
                            reader.readAsArrayBuffer(event.target.files[0]);

                        }
                        else {
                            Papa.parse(file, {
                                delimiter: ',', header: true, newline: '\r\n',
                                beforeFirstChunk: (chunk: string) => {
                                    var rows = chunk.split(/\r\n|\r|\n/);
                                    let headings = rows[0].split(',');
                                    console.log("chunk=>", chunk, headings);
                                    let index3 = headings.findIndex(x => x === null || (x + '').trim() === "");
                                    if (index3 !== -1) {
                                        setFieldValue('invalidFileExtensionError', t('controleErrors.selectValidFile'));
                                        return "empty";
                                    }
                                    let index4 = _.uniq(_.filter(headings, (v, i, a) => a.findIndex(x => (v + '').trim() === (x + '').trim()) !== i));
                                    if (index4.length > 0) {
                                        setFieldValue('invalidFileExtensionError', t('controleErrors.selectValidFile'));
                                        return "duplicate";
                                    }
                                    return chunk
                                },
                                complete: (results) => {
                                    console.log("results=>", results);
                                    if (results.data.length > 0) {
                                        let _fileText = results.data;
                                        let keysData = Object.keys(_fileText[0]).filter(x => x !== '__parsed_extra');
                                        console.log("columns=>", _fileText, keysData);
                                        let index1 = keysData.findIndex(x => x === null);
                                        if (index1 !== -1) {
                                            setFieldValue('invalidFileExtensionError', t('controleErrors.selectValidFile'));
                                        }
                                        else {
                                            let papaColumnsData = keysData.map(x => ({ label: x, value: x }));
                                            setFieldValue('columnsData', keysData.map(x => ({ label: x, value: x })));
                                            setFieldValue("fileDataCount", _fileText?.length);
                                            setFieldValue('excelSheetData', _fileText)
                                            getColumnsPatch(papaColumnsData, setFieldValue);
                                        }
                                    }
                                }
                            });
                        }
                    }
                    else
                        setFieldValue('invalidFileExtensionError', t('controleErrors.selectValidFile'));

                    event.target.value = null;
                }
                else
                    setFieldValue('invalidFileExtensionError', t('controleErrors.maxFileSize'));

            }
        }
    }

    return (<>
        {isBulkAction && <Card>
            <CardBody>
                <Formik
                    enableReinitialize
                    initialValues={{
                        apptCode: '',
                        apptType: '',
                        locationId: sessionData?.locationId ? sessionData?.locationId : 0,
                        resourceCode: '',
                        excelSheetData: [],
                        columnsData: '',
                        invalidFileExtensionError: '',
                        uploadFile: '',
                        fileName: '',
                        sheetList: [],
                        selectedSheet: '',
                        fileDataCount: '',
                        extension: ''
                    }}
                    validationSchema={Yup.object().shape({
                        apptCode: defultContentValidate(t('controleErrors.required')),
                        apptType: defultContentValidate(t('controleErrors.required')),
                        resourceCode: defultContentValidate(t('controleErrors.required')),
                        fileName: defultContentValidate(t('controleErrors.uploadFile')),
                        selectedSheet: Yup.string().when('extension', {
                            is: val => (val === 'xls' || val === 'xlsx'),
                            then: defultContentValidate(t('controleErrors.required')),
                            otherwise: defultContentValidate('')
                        })
                    })}

                    onSubmit={(values) => {
                        console.log("Values =>", values);
                        let columnsData: IColumnsData = {
                            apptCode: values.apptCode,
                            apptType: values.apptType,
                            resourceCode: values.resourceCode
                        };
                        let extension = (values?.extension ? values.extension : '').toLowerCase();
                        let requestObj: IBulkUploadApptTypeData = {
                            locationId: +values.locationId,
                            mappedColumns: columnsData,
                            validationSchema: validationSchema.appointmentType,
                            extension: extension,
                            data: extension === "xlsx" || extension === "xls" ? (values.excelSheetData as any[]).find(x => x?.viewValue === (values.selectedSheet as any)?.value)?.value : values.excelSheetData,
                            translator: t
                        }
                        console.log("onSubmit_requestObj =>", requestObj);
                        dispatch(bulkUploadAppTypeSubmitActionRequest(requestObj));
                    }}
                >
                    {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                        <Form>
                            <Row>
                                <Col>
                                    <Row>


                                        <div className="pt-3 pl-3 mr-2">
                                            <label htmlFor="bulkUploadFile" className="btn btn-primary">{t('ActionNames.uploadFile')}</label>
                                            <input type="file" accept=".csv,.xls, .xlsx" onChange={e => uploadFile(e, setFieldValue)} onBlur={() => setFieldTouched('fileName', true)} id="bulkUploadFile" style={{ display: 'none' }} />
                                            {errors.fileName && touched.fileName && (
                                                <div className="error-msg">{errors.fileName}
                                                </div>
                                            )}
                                        </div>
                                        <div className="px-2 pt-3 fileNCount">
                                            {values.fileName && <div className="fileName">{values.fileName}</div>}
                                            {values.fileDataCount && <div>{t('ActionNames.count')}<span className="formatclr"> {values.fileDataCount}</span></div>}

                                        </div>
                                        {(values.fileName && values.invalidFileExtensionError === '') && <>
                                            {values.extension !== 'csv' && <Col sm="5"><div className="FormStyle">
                                                <FormGroup>
                                                    <Label>{t('UserManagement.sheetList')}</Label>
                                                    <MySelect
                                                        name="selectedSheet"
                                                        placeholder={t('UserManagement.selectSheetList')}
                                                        value={values.selectedSheet}
                                                        onChange={(e) => sheetSelection(e, setFieldValue, values)}
                                                        options={values.sheetList}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onBlur={() => setFieldTouched('selectedSheet', true)}
                                                    />
                                                    {errors.selectedSheet && touched.selectedSheet && (
                                                        <div className="error-msg">{errors.selectedSheet}
                                                        </div>
                                                    )}
                                                </FormGroup>
                                            </div>
                                            </Col>
                                            }</>}
                                    </Row>
                                    <div className="pt-2 pb-1 align-left"><img src={info} alt="" style={{ width: "17px" }} />&nbsp;<span className="formatclr">{t('ActionNames.format')} </span>{t('ActionNames.exFileFormat')}</div>
                                </Col>
                                <div className="px-3">
                                    <span>{t('ActionNames.samplefiles')}</span>
                                    <div className="mt-2">
                                        <img alt="" src={xls} className="pointer" style={{ width: '27px' }} onClick={DownloadXlsRequest} />
                                        <img alt="" src={xlsx} className="pointer" style={{ width: '29px', margin: '0 8px' }} onClick={DownloadExcelRequest} />
                                        <img alt="" src={csv} className="pointer" style={{ width: '25px' }} onClick={DownloadCsvRequest} />
                                    </div>
                                </div>
                            </Row>
                            <div className="pt-1">
                                {values.invalidFileExtensionError && <div className="file-errors">{values.invalidFileExtensionError}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.apptType && values.apptType === '' && <div className="file-errors">{t('AppointmentType.invalidAppointmentType')}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.apptCode && values.apptCode === '' && <div className="file-errors">{t('AppointmentType.invalidAppointmentCode')}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.resourceCode && values.resourceCode === '' && <div className="file-errors">{t('AppointmentType.invalidResourceCode')}</div>}
                            </div>
                            <div>
                                <ul className="pl-3 pt-2 instructions">
                                    <li>{t('AppointmentType.helperPonit1')}</li>
                                    <li>{t('AppointmentType.helperPonit2')}</li>
                                    <li>{t('AppointmentType.helperPonit3')}</li>
                                    <li>{t('AppointmentType.helperPonit4')}</li>
                                    <li>{t('AppointmentType.helperPonit5')}</li>
                                </ul>

                            </div>
                            <Row>
                                <Col className="action">
                                    <button type="submit" disabled={!(dirty)} className="btn btn-primary">{t('ActionNames.submit')}</button>
                                    <button type="button" className="btn btn-cancel ml-2" onClick={cancelEditFunction}>{t('ActionNames.cancel')}</button>
                                </Col>
                            </Row>

                        </Form>
                    )}
                </Formik>

            </CardBody>
        </Card>}
    </>)
}

export default React.memo(AppointmentTypeBulkUploadComponent);