import React, { useContext, useRef } from 'react';
import { useSelector } from 'react-redux';
import '../container/appointmenttype.css';
import { SuperParentContext, ParentContext } from '../container/appointmenttypeContestApi';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { IOprationalActions } from 'models/utilitiesModel';


const RightParentAppointmentType: React.FC = () => {
    const scrollbarRef = useRef<any>(null);
    const context: any = useContext(SuperParentContext);
    const isMappingAction = useSelector(state => {
        if (state && state.appointmentTypeReducer)
            return state.appointmentTypeReducer.actionType === IOprationalActions.MAPPING;
        else return false;
    });

    if (!isMappingAction) {
        if (scrollbarRef && scrollbarRef.current)
            scrollbarRef.current.scrollTop = 0;
    }

    return (
        <>
            <div className="flexLayout-inner">
                <PerfectScrollbar ref={scrollbarRef}>
                    <div className="pl-3">
                        <context.actionComponent />
                        <ParentContext.Provider value={context.actions}>
                            <context.viewComponent />
                        </ParentContext.Provider>
                        <context.parentmappingcomponent />
                        <context.bulkuploadComponent />
                    </div>
                </PerfectScrollbar >
            </div>

        </>


    )
}
export default React.memo(RightParentAppointmentType);