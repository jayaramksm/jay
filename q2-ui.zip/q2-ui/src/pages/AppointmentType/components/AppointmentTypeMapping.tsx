import React from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import { IUser } from '../../../models/appointmentTypesModel';
import * as _ from 'lodash';
import { mapAppointmentTypesRequest, suspendOrEditAppointMentTYpesAction } from '../../../store/actions';
import { IOprationalActions } from '../../../models/utilitiesModel';
import DualListBox from 'react-dual-listbox';
import { Col, Row } from 'reactstrap';
import '../container/appointmenttype.css';
import { Formik, Form } from 'formik';

const AppointmentTypeMapping: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const mappedUsersOfAppointmentType = useSelector(state => {
        if (state && state.appointmentTypeReducer && state.appointmentTypeReducer.actionData)
            return state.appointmentTypeReducer.actionData.users ? state.appointmentTypeReducer.actionData.users : [];
        else return [];
    });
    const existingMappedOptions = mappedUsersOfAppointmentType ? mappedUsersOfAppointmentType.map(x => x.userId) : [];

    console.log("existingMappedOptions in appttypes", existingMappedOptions);

    const usersData: IUser[] = useSelector(state => {
        if (state && state.appointmentTypeReducer)
            return state.appointmentTypeReducer.userData ? state.appointmentTypeReducer.userData : [] as IUser[];
        else return undefined;
    });

    const userssDataOptions = usersData ? usersData.map(item => ({ value: item.userId, label: item.userName })) : [];

    const cancelMapping = () => {
        dispatch(suspendOrEditAppointMentTYpesAction(IOprationalActions.SELECT));
    }
    return (
        <Formik
            enableReinitialize
            initialValues={{
                selected: existingMappedOptions ? existingMappedOptions : []

            }}

            onSubmit={(values) => {
                const mappedData: any = [];

                values.selected?.forEach(item => {
                    let data = _.omit(usersData.find(x => x.userId === item));
                    mappedData.push(data);
                });
                dispatch(mapAppointmentTypesRequest(mappedData));

            }}
        >
            {({ values, setFieldValue }) => (
                <Form>
                    <Row className="mb-3 text-center">
                        <Col>

                            <div className="apptype">{t('AppointmentType.resourseTypes')}</div>
                        </Col>
                        <Col className="align-right">
                            <div className="apptype">{t('AppointmentType.assignresourseTypes')}</div>
                        </Col>
                    </Row>
                    <DualListBox
                        name="selected"
                        options={userssDataOptions}
                        selected={values.selected}
                        onChange={(selectedValues) => {
                            setFieldValue('selected', selectedValues)
                        }}
                        preserveSelectOrder
                        showNoOptionsText
                        canFilter
                    />
                    <div className="text-right mt-5">
                        <button className="btn btn-primary" type="submit">
                            {t('ActionNames.save')}
                        </button>
                        <button className="btn btn-cancel ml-3" onClick={cancelMapping}>
                            {t('ActionNames.cancel')}
                        </button>
                    </div>
                </Form>
            )}
        </Formik>

    )

}
export default React.memo(AppointmentTypeMapping);