import * as React from 'react';
import '../container/appointmenttype.css';
import { useSelector, useDispatch } from 'react-redux';
import { useContext } from 'react';
import { ChildContext } from '../container/appointmenttypeContestApi';
import { IApptType, IAppointmentTypeState } from '../../../models/appointmentTypesModel';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { suspendOrEditAppointMentTYpesAction, setAppointmentTypeActionRequest } from '../../../store/actions';

 const AppointmentTypeItem: React.FC = () => {
    const context = useContext(ChildContext);
    const dispatch = useDispatch();
    let appointmentTypesData: IApptType = useSelector(state => {
        if (state && state.appointmentTypeReducer) {
            let data = state.appointmentTypeReducer.appointmentTypesData as IApptType[];
            let index = data.findIndex(x => x.apptTypeId === context);

            if (index !== -1)
                return state.appointmentTypeReducer.appointmentTypesData[index];
            else return undefined;
        }
        else return undefined;
    });
    const selectedAppointmentType = useSelector(state => {
        if (state && state.appointmentTypeReducer) {
            return (state.appointmentTypeReducer as IAppointmentTypeState).actionData ?
                ((state.appointmentTypeReducer as IAppointmentTypeState).actionData as IApptType).apptTypeId === appointmentTypesData.apptTypeId : false;
        }
        else return false;
    })

    return (
        <>
           {appointmentTypesData && 

<span className={'btn btn-sm ' + (selectedAppointmentType ? 'activeList' : '')}
    onClick={() => dispatch(selectedAppointmentType ? suspendOrEditAppointMentTYpesAction(0) : setAppointmentTypeActionRequest(IOprationalActions.SELECT, appointmentTypesData, false))}
>
    {appointmentTypesData.apptType}
</span>
}
        </>
    )
}
export default React.memo(AppointmentTypeItem);