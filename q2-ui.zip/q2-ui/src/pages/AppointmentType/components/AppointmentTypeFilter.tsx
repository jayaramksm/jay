import * as React from 'react';
import { Col, Row, UncontrolledTooltip } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { setAppointmentTypeSearchKey, setAppointmentTypeActionRequest } from '../../../store/actions';
import '../container/appointmenttype.css';
import { useContext } from 'react';
import { ParentContext } from '../container/appointmenttypeContestApi';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import uploadlogo from '../../../images/upload.svg'

const AppointmentTypeFilter: React.FC = () => {

    const context: any = useContext(ParentContext);
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const actionArea = useSelector(state => {
        if (state && state.appointmentTypeReducer && state.appointmentTypeReducer.actionType)
            return state.appointmentTypeReducer.actionType === IOprationalActions.ADD;
        else return false;
    });

    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const filterActions = useSelector(state => {
        if (state && state.appointmentTypeReducer && state.appointmentTypeReducer.appointmentTypesData)
            return state.appointmentTypeReducer.appointmentTypesData.length > 0;
        else return false;
    });
    const isBulkUpload = useSelector(state => {
        if (state && state.appointmentTypeReducer)
            return state.appointmentTypeReducer.actionType === IOprationalActions.BULKUPLOAD;
        else return false;
    });
    const addAppointmentType = () => {
        if (actionArea !== IOprationalActions.ADD)
            dispatch(setAppointmentTypeActionRequest(IOprationalActions.ADD, null, false));
    }
    const addBulkUpload = () => {
        dispatch(setAppointmentTypeActionRequest(IOprationalActions.BULKUPLOAD, null, false));
    }

    const setSearch = (key) => {
        dispatch(setAppointmentTypeSearchKey(key));
    }
    return (<>
        <Row className="roleslist">
            <Col className="pr-0"><h6 className="m-0">{t('AppointmentType.listOfAppointmentTypes')}</h6>
            </Col>
           
            {selectedLocationStatus &&
                <div className="align-right pr-3 addupload">
                    {context?.actions?.add && <button disabled={(actionArea)}
                        onClick={addAppointmentType} className="btn btn-out-dashed" id="add"> {t('ActionNames.add')} &nbsp; <span className="addbtn">+</span></button>}
                    {context.actions?.bulkUpload && selectedLocationStatus && <><button disabled={isBulkUpload} onClick={addBulkUpload} className="btn blkupload p-0 pl-2" id="upload"><img alt="" src={uploadlogo} /></button>
                        <UncontrolledTooltip color="primary" placement="top" target="upload">
                            {t('ActionNames.bulkupload')}
                        </UncontrolledTooltip> </>}
                    {!actionArea && context?.actions?.add && <UncontrolledTooltip color="primary" placement="top" target="add">
                        {t('AppointmentType.addAppointmentType')}
                    </UncontrolledTooltip>}
                </div>}
                
        </Row>
        {filterActions &&
            <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={e => setSearch(e.target.value)} />
                <i className="fa fa-search"></i>
            </div>}


    </>)
}
export default React.memo(AppointmentTypeFilter);
