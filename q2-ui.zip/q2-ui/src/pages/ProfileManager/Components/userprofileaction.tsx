import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, FormGroup, Label } from 'reactstrap';
import { useTranslation } from 'react-i18next';
import { IUserDetails, IOprationalActions } from '../../../models/utilitiesModel';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { customContentValidation, emailContentValidate } from '../../../helpers/helpersIndex';
import { updateUserProfileRequest, setUserProfileManagementAction } from '../../../store/actions';
import '../Container/userprofile.css';

const UserProfileAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const userProfileData: IUserDetails = useSelector(state => {
        if (state && state.SessionState && state.SessionState.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });
    console.log('userProfileData => ', userProfileData);

    const getInitialValues = () => ({
        firstName: userProfileData ? userProfileData.firstName : '',
        lastName: userProfileData ? userProfileData.lastName : '',
        contactNo: userProfileData ? userProfileData.contactNo : '',
        emailId: userProfileData ? userProfileData.emailId : ''
    });

    const validationSchema = Yup.object().shape({
        firstName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
        lastName: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaspacesp', message: 'alphaspace', spacialChar: null }, 50, 2),
        contactNo: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 15, 9),
        emailId: emailContentValidate(t('controleErrors.required'), { value: 3, message: t('controleErrors.min').replace('{min}', '3') }, { value: 50, message: t('controleErrors.max').replace('{max}', '50') }, t('controleErrors.emailInvalid'))
    });

    return (
        <>
            {userProfileData && (
                <Formik
                    enableReinitialize
                    initialValues={getInitialValues()}
                    validationSchema={validationSchema}
                    onSubmit={(values) => {
                        console.log('Values => ', values);
                        dispatch(updateUserProfileRequest(values));
                    }}
                >
                    {({ errors, touched, dirty }) => (
                        <Form>
                            <Row className="userprf">
                                <Col sm="9">
                                    <h6 className="mb-4">{t('UserProfileManagement.userDetails')}</h6>

                                    <Row>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label htmlFor="example-text-input">{t('UserProfileManagement.firstName')}</Label>
                                                <Field name="firstName" placeholder={t('UserProfileManagement.firstName')} className={'form-control ' + (errors.firstName && touched.firstName ? 'is-invalid' : '')} />
                                                <ErrorMessage name="firstName" component="div" className="invalid-feedback" />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label htmlFor="example-text-input1">{t('UserProfileManagement.lastName')}</Label>
                                                <Field name="lastName" placeholder={t('UserProfileManagement.lastName')} className={'form-control ' + (errors.lastName && touched.lastName ? 'is-invalid' : '')} />
                                                <ErrorMessage name="lastName" component="div" className="invalid-feedback" />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="4">
                                            <FormGroup>
                                                <Label htmlFor="example-text-input2">{t('UserProfileManagement.mobile')}</Label>
                                                <Field name="contactNo" placeholder={t('UserProfileManagement.mobile')} className={'form-control ' + (errors.contactNo && touched.contactNo ? 'is-invalid' : '')} />
                                                <ErrorMessage name="contactNo" component="div" className="invalid-feedback" />
                                            </FormGroup>
                                        </Col>
                                        <Col sm="4" className="mt-2">
                                            <FormGroup>
                                                <Label htmlFor="example-text-input3">{t('UserProfileManagement.email')}</Label>
                                                <Field name="emailId" placeholder={t('UserProfileManagement.email')} className={'form-control ' + (errors.emailId && touched.emailId ? 'is-invalid' : '')} />
                                                <ErrorMessage name="emailId" component="div" className="invalid-feedback" />
                                            </FormGroup>
                                        </Col>

                                    </Row>

                                    <hr />

                                    <div className="pt-3">
                                        <button type="submit" className="btn btn-primary" disabled={!(dirty)}>
                                            {t('ActionNames.save')}
                                        </button>
                                        <button type="button" className="btn btn-cancel ml-3" onClick={() => dispatch(setUserProfileManagementAction(IOprationalActions.SELECT))}>
                                            {t('ActionNames.cancel')}
                                        </button>
                                    </div>
                                </Col>
                            </Row>
                        </Form>
                    )}
                </Formik>
            )}
        </>
    )
}
export default React.memo(UserProfileAction);