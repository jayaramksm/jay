import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Col, Row, Card, CardBody } from 'reactstrap';
import user1 from '../../../images/user1.svg';
import user2 from '../../../images/user2.svg';
import email from '../../../images/email.svg';
// import language from '../../../images/language.svg';
import phone from '../../../images/phone.svg';
import '../Container/userprofile.css';
import { useTranslation } from 'react-i18next';
import { IOprationalActions, IUserDetails } from '../../../models/utilitiesModel';
import { setUserProfileManagementAction } from '../../../store/actions';

const UserProfileView: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const userProfileData: IUserDetails = useSelector(state => {
        if (state && state.SessionState && state.SessionState.userDto)
            return state.SessionState.userDto;
        else return undefined;
    });
    console.log('userProfileData => ', userProfileData);

    const editUserProfile = () => dispatch(setUserProfileManagementAction(IOprationalActions.EDIT));

    return (
        <>
            {userProfileData && <Row>
                <Col sm="7">
                    <Row className="prfname">
                        <Col sm="1"><img src={user2} alt="" /></Col>
                        <Col sm="4">
                            <span>{userProfileData.firstName} {userProfileData.lastName}</span>
                            <h6>{userProfileData.roles.roleName}</h6>
                        </Col>
                    </Row>
                    <hr />
                    <h6 className="pt-2">{t('UserProfileManagement.userDetails')}</h6>
                    <Row className="user">
                        <Col sm="4" className="mb-4">
                            <Card>
                                <CardBody>
                                    <div className="role"><img src={user1} alt="" /><span className="pt-1 pl-3">{t('UserProfileManagement.role')}</span></div>
                                    <span className="pt-4">{userProfileData.roles.roleName}</span>
                                </CardBody>
                            </Card>
                        </Col>
                        <Col sm="4" className="mb-4">
                            <Card>
                                <CardBody>
                                    <div className="role"><img src={phone} alt="" /><span className="pl-3">{t('UserProfileManagement.mobile')}</span></div>
                                    <span className="pt-4">{userProfileData.contactNo}</span>
                                </CardBody>
                            </Card>
                        </Col>
                        {/* <Col sm="4">
                        <Card>
                            <CardBody>
                                <div className="role"><img src={language} alt="" /><span className="pt-1 pl-3">Language</span></div>
                                <span className="pt-4">English</span>
                            </CardBody>
                        </Card>
                    </Col> */}
                    </Row>
                    <Card className="emailimg">
                        <CardBody>
                            <img src={email} alt="" /><span className="pl-3">{userProfileData.emailId}</span>
                        </CardBody>
                    </Card>
                    <div className="pb-4">
                    <button className="btn btn-primary" onClick={editUserProfile}>{t('UserProfileManagement.editProfile')}</button>
                    </div>
                </Col>
            </Row>}
        </>
    )
}
export default React.memo(UserProfileView);