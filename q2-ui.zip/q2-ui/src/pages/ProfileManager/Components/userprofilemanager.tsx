import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { SuperParentContext } from '../Container/userprofilecontext';
import { IOprationalActions } from '../../../models/utilitiesModel';

const UserProfileManager: React.FC = () => {
    const context = useContext(SuperParentContext);
    const isEditActionType = useSelector(state => {
        if (state && state.userProfileManagementReducer && state.userProfileManagementReducer.actionType)
            return state.userProfileManagementReducer.actionType === IOprationalActions.EDIT;
        else return false;
    });

    return (
        <>

            <div className="flexLayout">
                <div className="flexLayout-inner">
                    {isEditActionType && <context.actionComponent />}
                    {!isEditActionType && <context.viewComponent />}
                </div>
            </div>
        </>
    )
}
export default React.memo(UserProfileManager);