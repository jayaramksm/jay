import * as React from 'react';
import { activateAuthLayout, setResetForUpdateUserProfile } from '../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Container } from 'reactstrap';
import UserProfileAction from '../Components/userprofileaction';
import UserProfileManager from '../Components/userprofilemanager';
import UserProfileView from '../Components/userprofileview';
import { SuperParentContext } from './userprofilecontext';
import '../Container/userprofile.css';

interface IProps {
    activateAuthLayout: any;
    setResetForUpdateUserProfile: any;
}
class UserProfile extends React.Component<IProps, any> {
    constructor(props) {
        super(props)
        this.state = {
            viewComponent: UserProfileView,
            actionComponent: UserProfileAction
        }
    }
    componentDidMount() {
        this.props.activateAuthLayout();
    }
    componentWillUnmount() {
        this.props.setResetForUpdateUserProfile();
    }

    render() {

        return (
            <>
                <Container fluid className="h-100">

                    <SuperParentContext.Provider value={this.state}>
                        <UserProfileManager />
                    </SuperParentContext.Provider>

                </Container>
            </>
        );
    }
}

export default withRouter(connect(null, { activateAuthLayout, setResetForUpdateUserProfile })(UserProfile));
