import * as React from 'react';
import { Container } from 'reactstrap';
import { activateAuthLayout, changeUserProfilePasswordRequest, getGBPasswordPolicyDataRequest } from '../../../store/actions';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Col, Row, Label } from 'reactstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { withTranslation } from 'react-i18next';
import '../Container/userprofile.css';
import { customContentValidation, coustmizePasswordPattern } from '../../../helpers/helpersIndex';
import { IPasswordPolicy } from 'models/globalSettingsModel';

export interface IProps {
    activateAuthLayout: any;
    changeUserProfilePasswordRequest: any;
    getGBPasswordPolicyDataRequest: any;
    t: any;
    enable: boolean;
    password: string;
    history: any;
    passwordPolicyData: IPasswordPolicy;
}

class ChangePassword extends React.Component<IProps, any> {
    constructor(props) {
        super(props);
        this.state = {
            iscurrentPasswordText: false,
            isNewPasswordText: false,
            isRetypePasswordText: false
        }
    }

    t = this.props.t;
    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.getGBPasswordPolicyDataRequest();
        console.log("ChangePassword=>", this.props);

    }

    resetForm = (setValues, setTouched) => {
        let touchedValues = {
            currentPassword: false,
            newPassword: false,
            confirmPassword: false
        }
        let values = {
            currentPassword: this.props?.password ? this.props?.password : '',
            newPassword: '',
            confirmPassword: ''
        }
        setValues(values);
        setTouched(touchedValues);
        if (this.state.iscurrentPasswordText || this.state.isNewPasswordText || this.state.isRetypePasswordText)
            this.setState({
                iscurrentPasswordText: false,
                isNewPasswordText: false,
                isRetypePasswordText: false
            });
    }

    render() {
        const { iscurrentPasswordText, isNewPasswordText, isRetypePasswordText } = this.state;

        return (
            <>
                <Container fluid className="h-100">
                    <div className="flexLayout">
                        <div className="flexLayout-inner">
                            <Formik
                                enableReinitialize
                                initialValues={{
                                    currentPassword: this.props?.password ? this.props?.password : '',
                                    newPassword: '',
                                    confirmPassword: ''
                                }}
                                validationSchema={Yup.object().shape({
                                    currentPassword: customContentValidation(this.t, this.t('controleErrors.required')),
                                    newPassword: coustmizePasswordPattern(this.t, this.t('controleErrors.required'), {
                                        patternType: 'alphanumricwithoutspaceandallspecial', message: '#invalid#', spacialChar: null,
                                        replaceData: [
                                            { replaceKey: '{lowerChar}', replaceValue: this.props.passwordPolicyData.noOfLowerCaseLetters + '' },
                                            { replaceKey: '{capsChar}', replaceValue: this.props.passwordPolicyData.noOfUpperCaseLetters + '' },
                                            { replaceKey: '{alphabetics}', replaceValue: this.props.passwordPolicyData.numberOfAlphabets + '' },
                                            { replaceKey: '{numeric}', replaceValue: this.props.passwordPolicyData.numberOfNumerical + '' },
                                            { replaceKey: '{special}', replaceValue: this.props.passwordPolicyData.specialCharactersAllowed }
                                        ]
                                    }, this.props.passwordPolicyData.maximumLength, this.props.passwordPolicyData.minimumLength),
                                    confirmPassword: Yup.string().required(this.t('controleErrors.required')).when("newPassword", {
                                        is: val => (val && val.length > 0 ? true : false),
                                        then: Yup.string().oneOf(
                                            [Yup.ref("newPassword")],
                                            this.t('UserProfileManagement.passwordMismatch')
                                        ),
                                        otherWise: customContentValidation(this.t, this.t('controleErrors.required'))
                                    })
                                })}
                                onSubmit={(values, { resetForm }) => {
                                    console.log('Values => ', values);
                                    let requestData = {
                                        currentPassword: values.currentPassword,
                                        newPassword: values.newPassword
                                    }
                                    this.props.changeUserProfilePasswordRequest(requestData, this.props.history);
                                    resetForm();
                                }}
                            >
                                {({ errors, touched, dirty, setValues, setTouched }) => (
                                    <Form>
                                        <Row className="userprf">
                                            <Col sm="9">
                                                <h6 className="mb-4">{this.t('UserProfileManagement.passwordDetails')}</h6>

                                                <Row>
                                                    {!this.props?.password && <Col>
                                                        <div className="form-group eyepassword">
                                                            <Label htmlFor="example-text-input">{this.t('UserProfileManagement.currentPassword')}</Label>
                                                            <Field type={iscurrentPasswordText ? 'text' : 'password'} name="currentPassword" placeholder={this.t('UserProfileManagement.currentPassword')} className={'form-control ' + (errors.currentPassword && touched.currentPassword ? 'is-invalid' : '')} />
                                                            <i className={(!iscurrentPasswordText ? 'ti-eye' : 'ti-close')} onClick={() => this.setState({ iscurrentPasswordText: !iscurrentPasswordText })}></i>
                                                            <ErrorMessage name="currentPassword" component="div" className="invalid-feedback" />
                                                        </div>
                                                    </Col>}
                                                    <Col>
                                                        <div className="form-group eyepassword">
                                                            <Label htmlFor="example-text-input1">{this.t('UserProfileManagement.newPassword')}</Label>
                                                            <Field type={isNewPasswordText ? 'text' : 'password'} name="newPassword" onPaste={e => e.preventDefault()} placeholder={this.t('UserProfileManagement.newPassword')} className={'form-control ' + (errors.newPassword && touched.newPassword ? 'is-invalid' : '')} />
                                                            <i className={(!isNewPasswordText ? 'ti-eye' : 'ti-close')} onClick={() => this.setState({ isNewPasswordText: !isNewPasswordText })}></i>
                                                            {/* <ErrorMessage name="newPassword" component="div" className="invalid-feedback" /> */}
                                                            {errors.newPassword && touched.newPassword && (
                                                                <div className="error-msg">
                                                                    {errors.newPassword !== '#invalid#' && <span>{errors.newPassword}</span>}
                                                                    {errors.newPassword === '#invalid#' && <>
                                                                        {this.props.passwordPolicyData?.noOfUpperCaseLetters > 0 && <div>{(this.t('UserProfileManagement.passwordPatternUpper').replace('{number}', this.props.passwordPolicyData.noOfUpperCaseLetters + ''))}</div>}
                                                                        {this.props.passwordPolicyData?.noOfLowerCaseLetters > 0 && <div>{(this.t('UserProfileManagement.passwordPatternLower').replace('{number}', this.props.passwordPolicyData.noOfLowerCaseLetters + ''))}</div>}
                                                                        {this.props.passwordPolicyData?.numberOfAlphabets > 0 && <div>{(this.t('UserProfileManagement.passwordPatternAlphabetics').replace('{number}', this.props.passwordPolicyData.numberOfAlphabets + ''))}</div>}
                                                                        {this.props.passwordPolicyData?.numberOfNumerical > 0 && <div>{(this.t('UserProfileManagement.passwordPatternNumerics').replace('{number}', this.props.passwordPolicyData.numberOfNumerical + ''))}</div>}
                                                                        {this.props.passwordPolicyData?.specialCharactersAllowed !== '' && <div>{(this.t('UserProfileManagement.passwordPatternSpecial').replace('{special}', this.props.passwordPolicyData.specialCharactersAllowed + ''))}</div>}
                                                                        {!(this.props.passwordPolicyData?.specialCharactersAllowed !== '') && <div>{this.t('UserProfileManagement.notAllowedSpecials')}</div>}
                                                                    </>}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </Col>
                                                    <Col>
                                                        <div className="form-group eyepassword">
                                                            <Label htmlFor="example-text-input2">{this.t('UserProfileManagement.retypenewPassword')}</Label>
                                                            <Field type={isRetypePasswordText ? 'text' : 'password'} name="confirmPassword" onPaste={e => e.preventDefault()} placeholder={this.t('UserProfileManagement.retypenewPassword')} className={'form-control ' + (errors.confirmPassword && touched.confirmPassword ? 'is-invalid' : '')} />
                                                            <i className={(!isRetypePasswordText ? 'ti-eye' : 'ti-close')} onClick={() => this.setState({ isRetypePasswordText: !isRetypePasswordText })}></i>
                                                            <ErrorMessage name="confirmPassword" component="div" className="invalid-feedback" />
                                                        </div>
                                                    </Col>
                                                </Row>

                                                <hr />

                                                <div className="pt-3">
                                                    <button type="submit" className="btn btn-primary" disabled={!(dirty)}>
                                                        {this.t('ActionNames.save')}
                                                    </button>
                                                    <button type="button" className="btn btn-cancel ml-3" disabled={!(dirty)} onClick={() => this.resetForm(setValues, setTouched)}>
                                                        {this.t('ActionNames.cancel')}
                                                    </button>
                                                </div>
                                            </Col>
                                        </Row>
                                    </Form>
                                )}
                            </Formik>
                        </div>
                    </div>
                </Container>
            </>
        );
    }
}
const mapStatetoProps = state => {
    console.log("mapStatetoProps_changePassword =>", state, state?.globalSettingsReducer?.passwordPolicyData);
    const { enable, password } = state?.SessionState?.isDefultPasswordAuth ? state?.SessionState?.isDefultPasswordAuth : { enable: undefined, password: undefined };
    const passwordPolicyData: IPasswordPolicy = state?.globalSettingsReducer?.passwordPolicyData ? state?.globalSettingsReducer?.passwordPolicyData : { changePasswordatFirstLogin: false, maximumLength: 8, minimumLength: 6, noOfUpperCaseLetters: 1, noOfLowerCaseLetters: 1, numberOfNumerical: 1, numberOfAlphabets: 0, specialCharactersAllowed: '`~!@#$%^&*()_-+=|\\}{][";:/?.>,<' + "'", passwordValidityPeriod: 90 } as IPasswordPolicy;
    return { enable, password, passwordPolicyData };
}
export default withRouter(withTranslation("translations")(connect(mapStatetoProps, { activateAuthLayout, changeUserProfilePasswordRequest, getGBPasswordPolicyDataRequest })(ChangePassword)));
