import React from 'react';
import { connect } from 'react-redux';
import { Container, Row, Col } from 'reactstrap';
import { activateAuthLayout, getLocationsAndBranchesRequest, setResetForServices, cancelAllPendingServicesRequest } from '../../../store/actions';
import {
    ServiceBranchFilter,
    ServiceBranchItem,
    ServiceBranchList,
    ServiceBranchDetails,
    LeftServiceParent,
    RightServiceParent,
    ServiceAction,
    ServiceFilter,
    ServiceManagerParent,
    ServiceView,
    ServiceMapping,
    ServiceLocationSelection,
    ServiceDetails,
    ServiceManagerAndAction,
    ServiceAutoRefresh,
    ServiceBulkuploadComponent
} from './servicemanageindex';
import { IRoleDesc, IActions } from '../../../models/utilitiesModel';
import { getAutoRefresing, getautoRefreshTime, getModulePrivilages } from '../../../helpers/helpersIndex';
import { SuperParentContext } from './servicemanagecontext';
import { IBranchRoomModel } from '../../../models/branchRoomModel';

interface IProps {
    activateAuthLayout: any;
    getLocationsAndBranchesRequest: any;
    setResetForServices: any;
    serviceBranchesLoad: any;
    cancelAllPendingServicesRequest: any;
    loginUserRolecode: string;
    add: boolean;
    edit: boolean;
    delete: boolean;
    bulkUpload: boolean;
}
class ServiceManage extends React.Component<IProps, any> {
    setinterval;
    constructor(props) {
        super(props);

        this.state = {
            leftServiceParent: {
                locationSelectionComponent: props.loginUserRolecode === IRoleDesc.ENTERPRISEADMIN ? ServiceLocationSelection : null,
                listComponent: ServiceBranchList,
                filterComponent: ServiceBranchFilter,
                itemComponent: ServiceBranchItem
            },
            rightServiceParent: {
                managerAndActionComponent: ServiceManagerAndAction,
                managerComponent: ServiceManagerParent,
                branchAndServiceDetailsView: { branchDetailsComponent: ServiceBranchDetails, serviceDetailsComponent: ServiceDetails },
                filterComponent: ServiceFilter,
                viewComponent: ServiceView,
                actionComponent: ServiceAction,
                mappingComponent: ServiceMapping,
                BulkuploadServiceComponent: ServiceBulkuploadComponent,
                actions: { add: this.props.add, edit: this.props.edit, delete: this.props.delete, bulkUpload: this.props.bulkUpload }
            }
        }
    }

    componentDidMount() {
        this.props.activateAuthLayout();
        this.props.setResetForServices();

        if (this.props.serviceBranchesLoad) {
            this.setinterval = setTimeout(() => {
                this.props.getLocationsAndBranchesRequest(!this.props.serviceBranchesLoad, true);
            }, getautoRefreshTime());
        }
        else
            this.props.getLocationsAndBranchesRequest(!this.props.serviceBranchesLoad, true);
    }

    componentWillUnmount() {
        if (this.setinterval) {
            clearTimeout(this.setinterval);
        }
        this.props.cancelAllPendingServicesRequest();
        this.props.setResetForServices();
    }

    render() {
        return (
            <>
                {getAutoRefresing() && <ServiceAutoRefresh />}
                <Container fluid className="h-100">
                    <Row className="h-100">
                        <Col sm="4" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.leftServiceParent}>
                                <LeftServiceParent />
                            </SuperParentContext.Provider>
                        </Col>

                        <Col sm="8" className="flexLayout">
                            <SuperParentContext.Provider value={this.state.rightServiceParent}>
                                <RightServiceParent />
                            </SuperParentContext.Provider>
                        </Col>
                    </Row>
                </Container>
            </>
        )
    }
}
const mapStatetoProps = state => {
    let defaultPrivilages: string[] = ['create', 'edit', 'delete', 'bulk_insert'];
    const { loginUserRolecode, privileges } = getModulePrivilages(state?.SessionState?.userDto?.roles?.roleCode, state?.SessionState?.menuData, 'service', defaultPrivilages);

    if (getAutoRefresing() && state.branchAndRoomReducer && (state.branchAndRoomReducer as IBranchRoomModel).branchData)
        return {
            serviceBranchesLoad: (state.branchAndRoomReducer as IBranchRoomModel).branchData.length > 0 ? true : false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
    else
        return {
            serviceBranchesLoad: false,
            loginUserRolecode: loginUserRolecode,
            add: privileges.includes(IActions.CREATE),
            edit: privileges.includes(IActions.EDIT),
            delete: privileges.includes(IActions.DELETE),
            bulkUpload: privileges.includes(IActions.BULKUPLOAD)
        };
}
export default connect(mapStatetoProps, { activateAuthLayout, getLocationsAndBranchesRequest, setResetForServices, cancelAllPendingServicesRequest })(ServiceManage);