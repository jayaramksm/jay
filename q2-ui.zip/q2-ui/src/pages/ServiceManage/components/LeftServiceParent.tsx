import React, { useContext } from 'react';
import { SuperParentContext } from '../Container/servicemanagecontext';
import '../Container/servicemanage.css';

const LeftServiceParent: React.FC = () => {
    const context = useContext(SuperParentContext);

    return (
        <>
            {context.locationSelectionComponent && <context.locationSelectionComponent />}
            <context.listComponent />
        </>
    )
}
export default React.memo(LeftServiceParent);