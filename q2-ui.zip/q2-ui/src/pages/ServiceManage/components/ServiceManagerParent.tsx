import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Card, CardBody, Label, UncontrolledTooltip, Col } from 'reactstrap';
import addIcon from '../../../images/icons/addicon.svg';
import '../Container/servicemanage.css';
import { IService, IServiceType } from '../../../models/servicesModel';
import { IBranch, IBranchType } from '../../../models/branchRoomModel';
import { useTranslation } from 'react-i18next';
import { getEnvironment, getBranchTypeServingCategoryPriviliges } from '../../../helpers/helpersIndex';
import { setServicesCurrentPage, setServiceActionData, deleteServiceRequest, fetchApptTypesToMapRequest } from '../../../store/actions';
import { SuperParentContext } from '../Container/servicemanagecontext';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import { PaginationComponent } from '../../../pages/Utilities/PaginationComponent';
import '../Container/servicemanage.css'

const ServiceManagerParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const actions = useContext(SuperParentContext).actions;
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();

    const selectedBranchType: String = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData) {
            let data: IBranch[] = state.branchAndRoomReducer.branchData;
            let branchTypeId = data?.find((x: IBranch) => x.branchId === state?.serviceReducer?.branchActionData?.actionId)?.branchTypeId;
            if (branchTypeId)
                return (state?.branchAndRoomReducer?.branchTypesData as IBranchType[])?.find((x: IBranchType) => x.branchTypeId === branchTypeId)?.branchTypeCode;
            else
                return undefined;
        }
        else return undefined;
    });
    const isAppointmentTypeMapping = selectedBranchType ? getBranchTypeServingCategoryPriviliges(selectedBranchType)?.appointmentTypeMapping : false;
    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    const pageSize = getEnvironment.pageRightSize + 1;

    const servicesDataCount = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.servicesData)
            return state.serviceReducer.servicesData.length;
        else return 0;
    });
    console.log("servicesDataCount=>", servicesDataCount, selectedBranchType);

    const searchKey = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.serviceSearchKey)
            return state.serviceReducer.serviceSearchKey;
        else return '';
    });

    const servicesTData: IService[] = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.servicesData)
            return state.serviceReducer.servicesData as IService[];
        else return undefined;
    });

    const servicesData = (searchKey && searchKey !== '' && servicesTData) ?
        servicesTData.filter(x => x.serviceNameEn.toLowerCase().startsWith(searchKey.toLowerCase())) : servicesTData;

    let pagesCount = Math.ceil((servicesData ? servicesData.length : 0) / pageSize);

    let currentPage = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.servicesCurrentPage)
            return state.serviceReducer.servicesCurrentPage;
        else return 0;
    });

    if (currentPage >= pagesCount && pagesCount !== 0) {
        // dispatch(setServicesCurrentPage(0));
        currentPage = 0;
    }

    const handleClick = (e, index) => {
        e.preventDefault();
        dispatch(setServicesCurrentPage(index));
    }

    const showServiceDetails = (serviceData) => dispatch(setServiceActionData(IOprationalActions.SELECT, serviceData));
    const editService = (serviceData) => {
        console.log('editService => ', serviceData);
        dispatch(setServiceActionData(IOprationalActions.EDIT, serviceData));
    }
    const mapService = (serviceData) => dispatch(fetchApptTypesToMapRequest(serviceData));
    // const mapService = (serviceData) => dispatch(setServiceActionData(IOprationalActions.MAPPING, serviceData));
    const deleteService = (serviceId, serviceName) => {
        let deleteMsg = t('Services.confirmMessages.SC2').replace('{service}', serviceName);
        dispatch(deleteServiceRequest(serviceId, false, deleteMsg));
    }



    return (
        <>
            <Row>
                <context.filterComponent />
            </Row>

            <Row className="mt-4 serviceCard lyt2-rgtclmn mx-0">


                {servicesData && searchKey === '' && servicesData.length === 0 && <span>{t('Services.noServices')}</span>}
                {servicesData && searchKey !== '' && servicesData.length === 0 && <span>{t('Services.noServicesForSearch')}</span>}

                {servicesData && servicesData.length > 0 && servicesData.slice(currentPage * pageSize,
                    (currentPage + 1) * pageSize).map(item => (
                        <div className="customCard" key={item.serviceId}>
                            <Card>
                                <CardBody>
                                    <div className="align-right mb-2">
                                        {selectedLocationStatus && item.isDefault === IServiceType.NOTDEFAULT && isAppointmentTypeMapping && <>
                                            <i id="mapping" className="ti-link mr-2 pointer" onClick={() => mapService(item)}></i>
                                            <UncontrolledTooltip color="primary" placement="top" target="mapping">
                                                {t('ActionNames.map')}
                                            </UncontrolledTooltip>
                                        </>}
                                        {actions.edit && selectedLocationStatus && <>
                                            <i id="edit" className="ti-pencil-alt mr-2 pointer" onClick={() => editService(item)}></i>
                                            <UncontrolledTooltip color="primary" placement="top" target="edit">
                                                {t('ActionNames.edit')}
                                            </UncontrolledTooltip>
                                        </>}

                                        {actions.delete && selectedLocationStatus && item.isDefault === IServiceType.NOTDEFAULT && <>
                                            <i id="delete" className="ti-trash pointer" onClick={() => deleteService(item.serviceId, item.serviceNameEn)}></i>
                                            <UncontrolledTooltip color="primary" placement="top" target="delete">
                                                {t('ActionNames.delete')}
                                            </UncontrolledTooltip>
                                        </>}
                                    </div>
                                    <div className="pointer" onClick={() => showServiceDetails(item)}>
                                        <div className="mb-2"><Label>{t('Services.serviceEngName')}</Label><br />{item.serviceNameEn}</div>
                                        <div className="text-right"><Label>{t('Services.serviceArbName')}</Label><br />{item.serviceNameAr}</div>
                                    </div>
                                </CardBody>
                            </Card>
                        </div>
                    ))}
            </Row>

            {servicesData && servicesData.length > pageSize && <Row className="justify-content-end rgt-pagination mx-0">
                <div className="pagination mr-3 pt-3">
                    <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                </div>
            </Row>}
        </>
    )
}
export default React.memo(ServiceManagerParent);