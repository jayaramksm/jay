import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { Card, CardBody } from 'reactstrap';
import { SuperParentContext } from '../Container/servicemanagecontext';
import '../Container/servicemanage.css';
import { IBranch } from '../../../models/branchRoomModel';

const RightServiceParent: React.FC = () => {

    const context = useContext(SuperParentContext);
    const branchSelectionExists: IBranch = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.branchActionData)
            return state.serviceReducer.branchActionData ? true : false;
        else return false;
    });

    return (
        <>
            <div className="flexLayout-inner">
                <div className="pl-3 pr-3">

                    {branchSelectionExists && <><Card>
                        <CardBody className="px-0">
                            <div className="mx-0">
                                <context.branchAndServiceDetailsView.branchDetailsComponent />
                            </div>

                            <div className="mx-0">
                                <context.branchAndServiceDetailsView.serviceDetailsComponent />
                            </div>
                        </CardBody>
                    </Card>

                        <context.managerAndActionComponent /></>}

                </div>
            </div>

        </>


    )
}
export default React.memo(RightServiceParent);