import React from 'react';
import { Row, Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import DualListBox from 'react-dual-listbox';
import '../Container/servicemanage.css';
import { IApptType } from '../../../models/servicesModel';
import { useTranslation } from 'react-i18next';
import { suspendServiceActionType, mapServicesRequest } from '../../../store/actions';
import * as _ from 'lodash';
import { Formik, Form } from 'formik';

const ServiceMapping: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const mappedApptTypesOfService = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.serviceActionData)
            return state.serviceReducer.serviceActionData.actionData ? state.serviceReducer.serviceActionData.actionData.apptTypes : [];
        else return [];
    });
    const existingMappedOptions = mappedApptTypesOfService ? mappedApptTypesOfService.map(x => x.apptTypeId) : [];
    const apptTypesData: IApptType[] = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.apptTypesData)
            return state.serviceReducer.apptTypesData as IApptType[];
        else return undefined;
    });
    const apptTypesDataOptions = apptTypesData ? apptTypesData.map(item => ({ value: item.apptTypeId, label: item.apptType })) : [];

    const cancelMapping = () => dispatch(suspendServiceActionType());

    return (
        <Formik
            enableReinitialize
            initialValues={{ selected: existingMappedOptions }}
            onSubmit={(values) => {
                const mappedData: any = [];
                values.selected?.forEach(item => {
                    console.log('_item_ => ', item)
                    let data = _.omit(apptTypesData.find(x => x.apptTypeId === item), ['locationId', 'users']);
                    mappedData.push(data);
                });
                dispatch(mapServicesRequest(mappedData));
            }}
        >
            {({ values, setFieldValue }) => (
                <Form>
                    <Row className="mb-3 text-center p-0">
                        <Col>
                            <div className="apptype">{t('Services.serviceApptTypes')}</div>
                        </Col>
                        <Col className="align-right">
                            <div className="apptype">{t('Services.assignedApptTypes')}</div>
                        </Col>
                    </Row>

                    <DualListBox
                        name="selected"
                        canFilter
                        options={apptTypesDataOptions}
                        selected={values.selected}
                        onChange={(selectedValues) => {
                            setFieldValue('selected', selectedValues);
                        }}
                        // preserveSelectOrder
                        filterPlaceholder={t('Services.searchOptions')}
                        showNoOptionsText
                    />

                    <div className="text-right mt-5 mb-3">
                        <button className="btn btn-primary" type="submit">
                            {t('ActionNames.save')}
                        </button>
                        <button className="btn btn-cancel ml-3" onClick={cancelMapping}>
                            {t('ActionNames.cancel')}
                        </button>
                    </div>
                </Form>
            )}
        </Formik>
    )
}
export default React.memo(ServiceMapping);