import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, Label } from 'reactstrap';
import { IServiceAction } from '../../../models/servicesModel';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { useTranslation } from 'react-i18next';
import { suspendServiceActionType } from '../../../store/actions';

const ServiceDetails: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const serviceActionData: IServiceAction = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.serviceActionData)
            return state.serviceReducer.serviceActionData as IServiceAction;
        else return undefined;
    });
    const serviceActionType = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.serviceActionData)
            return state.serviceReducer.serviceActionData.actionType;
        else return 0;
    });
    const cancelMapping = () => dispatch(suspendServiceActionType());

    return (
        <>
            {serviceActionData && serviceActionData.actionData && serviceActionData.actionType === IOprationalActions.MAPPING &&
                <div>
                <hr/>
                    <Row className="mx-0">
                        <Col sm="12">
                            <Row className="FormStyle">
                                <Col>
                                    <span>{serviceActionData.actionData.serviceNameEn}</span>
                                    <br />
                                    <Label>{t('Services.serviceEngName')}</Label>
                                </Col>
                                <Col>
                                    <Row className="align-right mx-0">
                                        <span>{serviceActionData.actionData.serviceNameAr}</span>
                                    </Row>
                                    <Row className="align-right mx-0">
                                        <Label>{t('Services.serviceArbName')}</Label>
                                    </Row>
                                </Col>
                                <Col>
                                    <span>{serviceActionData.actionData.tokenPrefix}</span><br />
                                    <Label>{t('Services.servicePrefix')}</Label>
                                </Col>
                                <Col>
                                    <span>{serviceActionData.actionData.waitTimeAvg}</span><br />
                                    <Label>{t('Services.serviceLevelTime')}</Label>
                                </Col>
                                <Col></Col>
                            </Row>
                        </Col>
                    </Row>

                    <hr />

                    {serviceActionType === IOprationalActions.MAPPING && <div className="arrow ml-3"><i className="ti-arrow-left" onClick={cancelMapping}></i></div>}
                </div>
            }
        </>
    )
}
export default React.memo(ServiceDetails);