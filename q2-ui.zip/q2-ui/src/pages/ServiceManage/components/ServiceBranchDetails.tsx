import React from 'react';
import { useSelector } from 'react-redux';
import { Row, Col, Label } from 'reactstrap';
import '../Container/servicemanage.css';
import { IBranchAction } from '../../../models/servicesModel';
import { IBranch, IBranchType } from '../../../models/branchRoomModel';
import { useTranslation } from 'react-i18next';

const ServiceBranchDetails: React.FC = () => {
    const { t } = useTranslation("translations");
    const selectedBranchId = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.branchActionData && state.serviceReducer.branchActionData.actionId)
            return (state.serviceReducer.branchActionData as IBranchAction).actionId;
        else return 0;
    });

    let selectedBranchData: IBranch = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData) {
            let data: IBranch[] = state.branchAndRoomReducer.branchData;
            let index = data?.findIndex((x: IBranch) => x.branchId === selectedBranchId);

            if (index !== -1)
                return state.branchAndRoomReducer.branchData[index] as IBranch;
            else return undefined;
        }
        else return undefined;
    });
    const branchTypesData: IBranchType[] = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchTypesData)
            return state.branchAndRoomReducer.branchTypesData as IBranchType[];
        else return undefined;
    });

    return (
        <>
            {selectedBranchData && <Row className="FormStyle mx-0 service-row">
                <Col>
                    <Label>{t('Services.branchEngName')}</Label>
                    <br />
                    <span>{selectedBranchData.branchNameEn}</span>
                </Col>
                <Col>
                    <Row className="align-right">
                        <Label className="text-right">{t('Services.branchArbName')}</Label>
                    </Row>
                    <Row className="align-right">
                        <span>{selectedBranchData.branchNameAr}</span>
                    </Row>
                </Col>
                <Col>
                    <Label>{t('Services.branchPrefix')}</Label><br />
                    <span>{selectedBranchData.branchIdentifier}</span>
                </Col>
                <Col>
                    <Label>{t('Services.serviceLocation')}</Label><br />
                    <span>{selectedBranchData.serviceLocation}</span>
                </Col>
                <Col>
                    <Label>{t('Services.branchType')}</Label><br />
                    {branchTypesData && <span>{branchTypesData.find(x => x.branchTypeId === selectedBranchData.branchTypeId)?.branchTypeDisplay}</span>}
                </Col>
            </Row>

            }

        </>
    )
}
export default React.memo(ServiceBranchDetails);