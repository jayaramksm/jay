import React from 'react';
import { LocationSelectArea } from '../../Utilities/LocationSelectArea';
import { changeLocationForBranches } from '../../../store/actions';
import '../Container/servicemanage.css';

const ServiceLocationSelection: React.FC = () => {
    return <LocationSelectArea locationCallBack={changeLocationForBranches} />
}
export default React.memo(ServiceLocationSelection);