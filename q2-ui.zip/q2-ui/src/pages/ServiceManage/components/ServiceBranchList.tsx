import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';
import { Card, CardBody, Row, Col } from 'reactstrap';
import '../Container/servicemanage.css';
import { SuperParentContext, ParentContext } from '../Container/servicemanagecontext';
import { useTranslation } from 'react-i18next';
import { getEnvironment } from '../../../helpers/helpersIndex';
import { IBranch } from '../../../models/branchRoomModel';
import { PaginationComponent } from '../../Utilities/PaginationComponent';

const ServiceBranchList: React.FC = () => {

    const context = useContext<any>(SuperParentContext);
    const { t } = useTranslation("translations");
    const pageSize = getEnvironment.listPageSize;
    const searchKey = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.branchSearchKey)
            return state.serviceReducer.branchSearchKey;
        else return '';
    });
    const branchesTData: IBranch[] = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData) {
            return state.branchAndRoomReducer.branchData as IBranch[];
        }
        else return [];
    });
    const branchesData: IBranch[] = (searchKey && searchKey !== '') ?
        branchesTData.filter(x => x.branchNameEn.toLowerCase().startsWith(searchKey.toLowerCase())) : branchesTData;

    let pagesCount = Math.ceil((branchesData ? branchesData.length : 0) / pageSize);
    const [currentPage, setCurrentPage] = useState(0);

    if (currentPage >= pagesCount && pagesCount !== 0)
        setCurrentPage(0);

    const handleClick = (e, index) => {
        e.preventDefault();
        setCurrentPage(index)
    }

    return (
        <>


            <Card className="lft-card flexLayout mb-0">
                <div className="flex-headerfix px-3 pt-3">
                    <context.filterComponent />
                </div>
                <CardBody>
                    <div className="flexLayout">

                        {branchesData && branchesData.length === 0 && <div className="recdnotfound">
                            {searchKey && <span>{t('Services.noResults')}</span>}
                            {searchKey === '' && <span>{t('Services.noBranches')}</span>}
                        </div>}

                        <div className="flexLayout-inner layou1rgtColmn">
                            <Row >

                                <Col sm="12" className="actn-list">

                                    {branchesData && branchesData.length > 0 && branchesData.slice(currentPage * pageSize,
                                        (currentPage + 1) * pageSize).map(item => (
                                            <ParentContext.Provider key={item.branchId} value={item}>
                                                <context.itemComponent />
                                            </ParentContext.Provider>
                                        ))}
                                </Col>
                            </Row>
                        </div>
                        {branchesData && branchesData.length > pageSize && <Row className="lft-pagination">
                            <div className="pagination ml-4">
                                <PaginationComponent currentPage={currentPage} pagesCount={pagesCount} pageSize={pageSize} handleClick={handleClick} />
                            </div>
                        </Row>}
                    </div>
                </CardBody>
            </Card>

        </>
    )
}
export default React.memo(ServiceBranchList);