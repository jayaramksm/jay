import React from 'react';
import '../Container/servicemanage.css'
import Papa from 'papaparse';
import { useDispatch } from 'react-redux';
import { Col, Row, Card, CardBody, FormGroup, Label } from 'reactstrap';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import { controleContentValidate, customContentValidation, MySelect, defultContentValidate } from 'helpers/helpersIndex';
import { useTranslation } from 'react-i18next';
import * as _ from 'lodash';
import * as XLSX from 'xlsx';
import { bulkUploadServiceSubmitActionRequest, suspendServiceActionType } from '../../../store/actions';
import { IColumnsServiceData, IBulkUploadServiceData } from '../../../models/servicesModel';
import { DownloadExcel, DownloadCsv } from '../../../helpers/helpersIndex';
import csv from '../../../images/csv.svg';
import xls from '../../../images/xls.svg';
import xlsx from '../../../images/xlsx.svg';
import info from '../../../images/info.svg';

export interface optionsData {
    value: any;
    label: any;
}

const headerNames = {
    ServiceNameEn: "ServiceNameEn*",
    ServiceNameAr: "ServiceNameAr*",
    ServicePrefix: "ServicePrefix*",
    ServiceLevelTime: "ServiceLevelTime*",
    EarlyCheckin: "EarlyCheckin*",
    LateCheckin: "LateCheckin*",
    TokenStartSeries: "TokenStartSeries*",
    TokenEndSeries: "TokenEndSeries*",
    AppointmentType: "AppointmentType*"
}
const ServiceBulkuploadComponent: React.FC = () => {

    const { t } = useTranslation("translations");
    let dispatch = useDispatch();
    const sampleData = [
        {
            [headerNames.ServiceNameEn]: '',
            [headerNames.ServiceNameAr]: '',
            [headerNames.ServicePrefix]: '',
            [headerNames.ServiceLevelTime]: '',
            [headerNames.EarlyCheckin]: '',
            [headerNames.LateCheckin]: '',
            [headerNames.TokenStartSeries]: '',
            [headerNames.TokenEndSeries]: '',
            [headerNames.AppointmentType]: '',
        }
    ];
    console.log("ServiceBulkuploadComponent_sampleData =>", sampleData);
    const DownloadXlsRequest = () => {
        const res = DownloadExcel(null, '', sampleData, 'Service.xls', '')
        console.log('DownloadExcelRequest=>', res);
    }
    const DownloadExcelRequest = () => {
        const res = DownloadExcel(null, '', sampleData, 'Service.xlsx', '')
        console.log('DownloadExcelRequest=>', res);
    }
    const DownloadCsvRequest = () => {
        const res = DownloadCsv(null, '', sampleData, 'Service', '');
        console.log('DownloadCsvRequest=>', res);
    }

    const validationSchema = {
        service: Yup.object().shape({
            serviceNameEn: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
            serviceNameAr: customContentValidation(t, t('controleErrors.required'), { patternType: 'arabicnumaricspacesp', message: 'arabicnumaricspace', spacialChar: null }, 50, 2),
            tokenPrefix: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaCapitals', message: 'alphaCapitals', spacialChar: null }, 3, 1),
            waitTimeAvg: customContentValidation(t, t('controleErrors.required'), { patternType: 'onlyCoustomumbersAreAllowed', message: 'onlyCoustomumbersAreAllowedSp', spacialChar: '(5|10|20|30|40|50|60)' }, 2, 1),
            minCheckinTime: customContentValidation(t, t('controleErrors.required'), { patternType: 'onlyCoustomumbersAreAllowed', message: 'onlyCoustomumbersAreAllowedSp', spacialChar: '(5|10|20|30|40|50|60)' }, 2, 1),
            maxCheckinTime: customContentValidation(t, t('controleErrors.required'), { patternType: 'onlyCoustomumbersAreAllowed', message: 'onlyCoustomumbersAreAllowedSp', spacialChar: '(5|10|20|30|40|50|60)' }, 2, 1),
            startSeq: Yup.number().when('endSeq', (endSeq) => {
                if (endSeq)
                    return Yup.number().max(endSeq - 1, t('Services.minGreater')).required(t('controleErrors.required')).typeError(t('controleErrors.patterninvalid'));
                else return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 3)
            }),
            endSeq: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 3),
            apptCode: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumaricsp', message: 'alphanumaricsp', spacialChar: ':' }, 50, 2)
        })
    }

    const getColumnsPatch = (keysData, setFieldValue) => {
        let index: any = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.ServiceNameEn.toLowerCase());
        if (index !== -1)
            setFieldValue('serviceNameEn', keysData[index].value);

        const index1 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.ServiceNameAr.toLowerCase());
        if (index1 !== -1)
            setFieldValue('serviceNameAr', keysData[index1].value);

        const index2 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.ServicePrefix.toLowerCase());
        if (index2 !== -1)
            setFieldValue('tokenPrefix', keysData[index2].value);

        const index3 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.ServiceLevelTime.toLowerCase());
        if (index3 !== -1)
            setFieldValue('waitTimeAvg', keysData[index3].value);

        const index4 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.EarlyCheckin.toLowerCase());
        if (index4 !== -1)
            setFieldValue('minCheckinTime', keysData[index4].value);

        const index5 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.LateCheckin.toLowerCase());
        if (index5 !== -1)
            setFieldValue('maxCheckinTime', keysData[index5].value);

        const index6 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.TokenStartSeries.toLowerCase());

        if (index6 !== -1)
            setFieldValue('startSeq', keysData[index6].value);

        const index7 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.TokenEndSeries.toLowerCase());
        if (index7 !== -1)
            setFieldValue('endSeq', keysData[index7].value);

        const index8 = keysData.findIndex(x => (x.value + '').trim().toLowerCase() === headerNames.AppointmentType.toLowerCase());
        if (index8 !== -1)
            setFieldValue('apptCode', keysData[index8].value);

    }

    const sheetSelection = (e, setFieldValue, values) => {
        setFieldValue('serviceNameAr', '');
        setFieldValue('tokenPrefix', '');
        setFieldValue('serviceNameEn', '');
        setFieldValue('waitTimeAvg', '');
        setFieldValue('minCheckinTime', '');
        setFieldValue('maxCheckinTime', '');
        setFieldValue('startSeq', '');
        setFieldValue('endSeq', '');
        setFieldValue('apptCode', '');
        let ind = values.excelSheetData.findIndex(x => x.viewValue === e.value);
        console.log("onSheetSelection==>", e, values, ind);

        if (ind !== -1) {
            setFieldValue('selectedSheet', e);
            setFieldValue('columnsData', []);
            let columndata = values.excelSheetData[ind].value;
            let keysData = (columndata[0] as any[]).filter(x => x);
            let papaColumnsData = keysData.map(x => ({ label: x, value: x }));
            setFieldValue('columnsData', keysData.map(x => ({ label: x, value: x })));
            setFieldValue('fileDataCount', columndata?.length - 1);
            getColumnsPatch(papaColumnsData, setFieldValue);
            console.log("keysData=>", keysData, columndata, values);
        }
        else {
            setFieldValue('selectedSheet', null);
            setFieldValue('columnsData', null);
        }
    }

    const uploadFile = (event, setFieldValue) => {

        if (event.target.value) {
            setFieldValue('serviceNameAr', '');
            setFieldValue('tokenPrefix', '');
            setFieldValue('serviceNameEn', '');
            setFieldValue('waitTimeAvg', '');
            setFieldValue('minCheckinTime', '');
            setFieldValue('maxCheckinTime', '');
            setFieldValue('startSeq', '');
            setFieldValue('endSeq', '');
            setFieldValue('apptCode', '');
            setFieldValue('excelSheetData', []);
            setFieldValue('selectedSheet', '');
            setFieldValue('sheetList', '');
            setFieldValue('fileName', '');
            setFieldValue('columnsData', '');
            setFieldValue('fileDataCount', '');
            setFieldValue('extension', '');
            setFieldValue('invalidFileExtensionError', '');
            const fileList: FileList = event.target.files;
            console.log("frmData=>1", event.target.files);
            if (fileList.length > 0) {
                const file: File = fileList[0];
                console.log("File", file);
                let extension = (file.name as string).split('.').pop();
                let fileSize = file.size / 1024 / 1024;
                console.log("File", file, fileSize);
                if (fileSize < 5) {
                    if (extension === "xlsx" || extension === "xls" || extension === "csv") {
                        setFieldValue('extension', extension);
                        setFieldValue('uploadedFile', fileList[0]);
                        setFieldValue('fileName', fileList[0].name);
                        if (extension === "xlsx" || extension === "xls") {
                            const reader: FileReader = new FileReader();
                            reader.onload = (e: any) => {
                                const arrayBuffer = e.target.result,
                                    data = new Uint8Array(arrayBuffer),
                                    arr = new Array();
                                for (let i = 0; i !== data.length; ++i) {
                                    arr[i] = String.fromCharCode(data[i]);
                                }
                                const bstr: string = arr.join('');
                                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
                                let excelSheetData: any = [];
                                let excelSheetList: any = [];
                                wb.SheetNames.forEach(element => {
                                    let wsname: string = element;
                                    let ws: XLSX.WorkSheet = wb.Sheets[wsname];
                                    let data1 = ((XLSX.utils.sheet_to_json(ws, { header: 1 })));
                                    data1 = data1.filter(z => (z as any[])?.length > 0)
                                    if (data1?.length > 1) {
                                        excelSheetList.push({ value: element, label: element });
                                        excelSheetData.push({ value: data1, viewValue: wsname })
                                    }
                                });
                                if (excelSheetData?.length === 0)
                                    setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                if (excelSheetList?.length === 1) {
                                    setFieldValue('sheetList', excelSheetList);
                                    setFieldValue('selectedSheet', excelSheetList[0]);
                                    let columndata = excelSheetData[0].value;
                                    let keysData = (columndata[0] as any[]).filter(x => x).map(x => ({ value: x, label: x }));
                                    setFieldValue('columnsData', keysData);
                                    setFieldValue('fileDataCount', excelSheetData[0].value.length - 1);
                                    getColumnsPatch(keysData, setFieldValue);
                                }
                                console.log('uploadFile_excelSheetData=>', excelSheetData);
                                setFieldValue('excelSheetData', excelSheetData);
                                setFieldValue('sheetList', excelSheetList);
                            }
                            reader.readAsArrayBuffer(event.target.files[0]);
                        }
                        else {
                            Papa.parse(file, {
                                delimiter: ',', header: true, newline: '\r\n',
                                beforeFirstChunk: (chunk: string) => {
                                    var rows = chunk.split(/\r\n|\r|\n/);
                                    let headings = rows[0].split(',');
                                    console.log("chunk=>", chunk, headings);
                                    let index3 = headings.findIndex(x => x === null || (x + '').trim() === "");
                                    if (index3 !== -1) {
                                        setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                        return "empty";
                                    }
                                    let index4 = _.uniq(_.filter(headings, (v, i, a) => a.findIndex(x => (v + '').trim() === (x + '').trim()) !== i));
                                    if (index4.length > 0) {
                                        setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                        return "duplicate";
                                    }
                                    return chunk
                                },
                                complete: (results) => {
                                    console.log("results=>", results);

                                    if (results.data.length > 0) {
                                        let _fileText = results.data;
                                        let keysData = Object.keys(_fileText[0]).filter(x => x !== '__parsed_extra');
                                        console.log("columns=>", _fileText, keysData);
                                        // let columnsCount: number = keysData.length;
                                        let index1 = keysData.findIndex(x => x === null);
                                        if (index1 !== -1) {
                                            setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                                        }
                                        else {
                                            let papaColumnsData = keysData.map(x => ({ label: x, value: x }));
                                            setFieldValue('columnsData', keysData.map(x => ({ label: x, value: x })));
                                            setFieldValue('fileDataCount', _fileText?.length);
                                            setFieldValue('excelSheetData', _fileText);
                                            getColumnsPatch(papaColumnsData, setFieldValue);
                                        }
                                    }
                                }
                            });
                        }
                    }
                    else
                        setFieldValue('invalidFileExtensionError', t("controleErrors.selectValidFile"));
                    event.target.value = null;
                }
                else
                    setFieldValue('invalidFileExtensionError', t("controleErrors.maxFileSize"));
            }
        }
    }

    const cancelBuliUpload = () => {
        dispatch(suspendServiceActionType());
    }

    return (<>
        <Card>
            <CardBody>
                <Formik
                    enableReinitialize
                    initialValues={{
                        waitTimeAvg: '',
                        minCheckinTime: '',
                        serviceNameAr: '',
                        tokenPrefix: '',
                        maxCheckinTime: '',
                        serviceNameEn: '',
                        startSeq: '',
                        endSeq: '',
                        apptCode: '',
                        excelSheetData: [],
                        columnsData: '',
                        invalidFileExtensionError: '',
                        uploadFile: '',
                        fileName: '',
                        sheetList: [],
                        selectedSheet: '',
                        fileDataCount: '',
                        extension: ''
                    }}
                    validationSchema={Yup.object().shape({
                        serviceNameEn: controleContentValidate(t('controleErrors.required')),
                        serviceNameAr: controleContentValidate(t('controleErrors.required')),
                        tokenPrefix: controleContentValidate(t('controleErrors.required')),
                        waitTimeAvg: controleContentValidate(t('controleErrors.required')),
                        minCheckinTime: controleContentValidate(t('controleErrors.required')),
                        maxCheckinTime: controleContentValidate(t('controleErrors.required')),
                        startSeq: controleContentValidate(t('controleErrors.required')),
                        endSeq: controleContentValidate(t('controleErrors.required')),
                        apptCode: controleContentValidate(t('controleErrors.required')),
                        fileName: defultContentValidate(t("controleErrors.uploadFile")),
                        selectedSheet: Yup.string().when('extension', {
                            is: val => (val === 'xls' || val === 'xlsx'),
                            then: defultContentValidate(t('controleErrors.required')),
                            otherwise: defultContentValidate('')
                        })
                    })}
                    onSubmit={(values) => {
                        console.log("onSubmit_Values =>", values);
                        let columnsData: IColumnsServiceData = {
                            serviceNameAr: values.serviceNameAr,
                            serviceNameEn: values.serviceNameEn,
                            tokenPrefix: values.tokenPrefix,
                            minCheckinTime: values.minCheckinTime,
                            waitTimeAvg: values.waitTimeAvg,
                            maxCheckinTime: values.maxCheckinTime,
                            startSeq: values.startSeq,
                            endSeq: values.endSeq,
                            apptCode: values.apptCode
                        };
                        let extension = (values?.extension ? values.extension : '').toLowerCase();

                        let requestObj: IBulkUploadServiceData = {
                            mappedColumns: columnsData,
                            validationSchema: validationSchema.service,
                            extension: extension,
                            data: extension === "xlsx" || extension === "xls" ? (values.excelSheetData as any[]).find(x => x?.viewValue === (values.selectedSheet as any)?.value)?.value : values.excelSheetData,
                            translator: t
                        }
                        console.log("onSubmit_requestObj =>", requestObj);
                        dispatch(bulkUploadServiceSubmitActionRequest(requestObj));
                    }}
                >
                    {({ errors, touched, dirty, values, setFieldValue, setFieldTouched }) => (
                        <Form>
                            <Row>
                                <Col>
                                    <Row>
                                        <div className="pt-3 pl-3 mr-2">
                                            <label htmlFor="bulkUploadFile" className="btn btn-primary">{t('ActionNames.uploadFile')}</label>
                                            <input type="file" accept=".csv, .xls, .xlsx" onChange={e => uploadFile(e, setFieldValue)} onBlur={() => setFieldTouched('fileName', true)} id="bulkUploadFile" style={{ display: 'none' }} />
                                            {errors.fileName && touched.fileName && (
                                                <div className="error-msg">{errors.fileName}
                                                </div>
                                            )}
                                        </div>
                                        <div className="px-2 pt-3 fileNCount">
                                            {values.fileName && <div className="fileName">{values.fileName}</div>}
                                            {values.fileDataCount && <div>{t('ActionNames.count')} <span className="formatclr">{values.fileDataCount}</span></div>}

                                        </div>
                                        {(values.fileName && values.invalidFileExtensionError === '') && <>
                                            {values.extension !== 'csv' && <Col sm="5"><div className="FormStyle">
                                                <FormGroup>
                                                    <Label>{t('UserManagement.sheetList')}</Label>
                                                    <MySelect
                                                        name="selectedSheet"
                                                        placeholder={t('UserManagement.selectSheetList')}
                                                        value={values.selectedSheet}
                                                        onChange={(e) => sheetSelection(e, setFieldValue, values)}
                                                        options={values.sheetList}
                                                        getOptionLabel={option => option.label}
                                                        getOptionValue={option => option.value}
                                                        onBlur={() => setFieldTouched('selectedSheet', true)}
                                                    />
                                                    {errors.selectedSheet && touched.selectedSheet && (
                                                        <div className="error-msg">{errors.selectedSheet}
                                                        </div>
                                                    )}
                                                </FormGroup>
                                            </div>
                                            </Col>
                                            }</>}
                                    </Row>
                                    <div className="pt-2 pb-1 align-left"><img src={info} alt="" style={{ width: "17px" }} />&nbsp; <span className="formatclr">{t('ActionNames.format')}</span>{t('ActionNames.exFileFormat')}</div>
                                </Col>

                                <div className="px-3">
                                    <span>{t('ActionNames.samplefiles')}</span>
                                    <div className="mt-2">
                                        <img alt="" src={xls} className="pointer" style={{ width: '27px' }} onClick={DownloadXlsRequest} />
                                        <img alt="" src={xlsx} className="pointer" style={{ width: '29px', margin: '0 8px' }} onClick={DownloadExcelRequest} />
                                        <img alt="" src={csv} className="pointer" style={{ width: '25px' }} onClick={DownloadCsvRequest} />
                                    </div>
                                </div>
                            </Row>
                            <div className="pt-1">
                                {values.invalidFileExtensionError && <div className="file-errors">{values.invalidFileExtensionError}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.serviceNameEn && values.serviceNameEn === '' && <div className="file-errors">{t("Services.invalidServiceNameEn")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.serviceNameAr && values.serviceNameAr === '' && <div className="file-errors" >{t("Services.invalidServiceNameAr")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.tokenPrefix && values.tokenPrefix === '' && <div className="file-errors">{t("Services.invalidServicePrefix")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.waitTimeAvg && values.waitTimeAvg === '' && <div className="file-errors">{t("Services.invalidServiceLevelTime")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.minCheckinTime && values.minCheckinTime === '' && <div className="file-errors">{t("Services.invalidEarlyCheckin")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.maxCheckinTime && values.maxCheckinTime === '' && <div className="file-errors">{t("Services.invalidLateCheckin")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.startSeq && values.startSeq === '' && <div className="file-errors">{t("Services.invalidTokenStartSeries")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.endSeq && values.endSeq === '' && <div className="file-errors">{t("Services.invalidTokenEndSeries")}</div>}
                                {values.columnsData && !values.invalidFileExtensionError && errors.apptCode && values.apptCode === '' && <div className="file-errors">{t("Services.invalidAppointmentType")}</div>}
                            </div>

                            <div>
                                <ul className="pl-3 pt-2 instructions">
                                    <li>{t('Services.helperPonit1')}</li>
                                    <li>{t('Services.helperPonit2')}</li>
                                    <li>{t('Services.helperPonit3')}</li>
                                    <li>{t('Services.helperPonit4')}</li>
                                    <li>{t('Services.helperPonit5')}</li>
                                </ul>
                            </div>
                            <hr />
                            <Row>
                                <Col className="action">
                                    <button type="submit" disabled={!(dirty)} className="btn btn-primary">{t('ActionNames.submit')}</button>
                                    <button type="button" className="btn btn-cancel ml-2" onClick={cancelBuliUpload}>{t('ActionNames.cancel')}</button>
                                </Col>
                            </Row>
                        </Form>
                    )}
                </Formik>


            </CardBody>
        </Card>
    </>)
}
export default React.memo(ServiceBulkuploadComponent);