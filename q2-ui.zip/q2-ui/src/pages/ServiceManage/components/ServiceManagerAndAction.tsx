import React, { useContext } from 'react';
import { useSelector } from 'react-redux';
import { IServiceAction } from '../../../models/servicesModel';
import { IOprationalActions } from '../../../models/utilitiesModel';
import { SuperParentContext } from '../Container/servicemanagecontext';

const ServiceManagerAndAction: React.FC = () => {
    const context = useContext(SuperParentContext);
    const serviceActionType = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.serviceActionData)
            return (state.serviceReducer.serviceActionData as IServiceAction).actionType;
        else return 0;
    });

    return (
        <>
            {serviceActionType === IOprationalActions.SELECT && <context.viewComponent />}
            {(serviceActionType === IOprationalActions.ADD || serviceActionType === IOprationalActions.EDIT) && <context.actionComponent />}
            {(serviceActionType === IOprationalActions.BULKUPLOAD)&& <context.BulkuploadServiceComponent />}
            {serviceActionType === IOprationalActions.MAPPING && <context.mappingComponent />}

     {serviceActionType === 0 && <context.managerComponent />}
        </>
    )
}
export default React.memo(ServiceManagerAndAction);