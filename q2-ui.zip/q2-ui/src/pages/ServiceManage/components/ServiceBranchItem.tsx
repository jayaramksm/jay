import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { IServicesState, IBranchAction } from '../../../models/servicesModel';
import { ParentContext } from '../Container/servicemanagecontext';
import '../Container/servicemanage.css';
import { selectBranchRequest, suspendServicesBranchAction } from '../../../store/actions';
import { IOprationalActions } from '../../../models/utilitiesModel';

const ServiceBranchItem: React.FC = () => {
    const context = useContext(ParentContext);
    const dispatch = useDispatch();

    const selectedBranch = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.branchActionData)
            return ((state.serviceReducer as IServicesState).branchActionData as IBranchAction)?.actionId === context.branchId;
        else return false;
    });
    const selectBranch = () => dispatch(selectBranchRequest(IOprationalActions.SELECT, context.branchId, false));
    const reset = () => dispatch(suspendServicesBranchAction());

    return (
        <>
            {context &&
                <span className={'btn btn-sm ' + (selectedBranch ? 'activeList' : '')} onClick={selectedBranch ? reset : selectBranch}>
                    {context.branchNameEn}
                </span>
            }
        </>
    )
}
export default React.memo(ServiceBranchItem);