import React from 'react';
import { Col } from 'reactstrap';
import { useSelector, useDispatch } from 'react-redux';
import '../Container/servicemanage.css';
import { useTranslation } from 'react-i18next';
import { setBranchSearchKey } from '../../../store/actions';

const ServiceBranchFilter: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const setSearchkey = e => dispatch(setBranchSearchKey(e.target.value));

    const branchDataExists = useSelector(state => {
        if (state && state.branchAndRoomReducer && state.branchAndRoomReducer.branchData)
            return state.branchAndRoomReducer.branchData.length > 0;
        else return false;
    });

    return (
        <>
            <Col className="pl-0"><h6 className="m-0">{t('Services.branchList')}</h6></Col>
            {branchDataExists && <div className="app-search w-100 p-0 form-group mb-0 mt-3">
                <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={setSearchkey} />
                <i className="fa fa-search"></i>
            </div>}
        </>
    )
}
export default React.memo(ServiceBranchFilter);