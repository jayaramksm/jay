import React, { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import '../Container/servicemanage.css';
import { useTranslation } from 'react-i18next';
import { setServiceSearchKey, setServiceActionData } from '../../../store/actions';
import { UncontrolledTooltip, Col } from 'reactstrap';
import { IOprationalActions, ISessionstate } from '../../../models/utilitiesModel';
import uploadlogo from '../../../images/upload.svg';
import { SuperParentContext } from '../Container/servicemanagecontext';

const ServiceFilter: React.FC = () => {

    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const actions = useContext(SuperParentContext).actions;
    const setSearchkey = e => dispatch(setServiceSearchKey(e.target.value));

    const serviceDataExists = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.servicesData)
            return state.serviceReducer.servicesData.length > 0;
        else return false;
    });

    const selectedLocationStatus = useSelector(state => {
        if (state && state.SessionState && state.SessionState.selectedLocationStatus)
            return (state.SessionState as ISessionstate).selectedLocationStatus;
        else return false;
    });
    console.log("ServiceFilter =>", actions, serviceDataExists, selectedLocationStatus);

    const addService = () => {
        dispatch(setServiceActionData(IOprationalActions.ADD, null));
    }

    const addBulkUpload = () => {
        dispatch(setServiceActionData(IOprationalActions.BULKUPLOAD, null));
    }

    return (
        <>
            <Col>
                {serviceDataExists && <div className="app-search w-70 p-0 form-group mb-0 mt-1">
                    <input type="text" className="form-control w-100" placeholder={t('ActionNames.search')} onChange={setSearchkey} />
                    <i className="fa fa-search"></i>
                </div>}
            </Col>
            <Col sm="4">
                {selectedLocationStatus &&
                    <div className="align-right">
                        {actions.add && <div onClick={addService}>
                            <button className="btn btn-out-dashed" id="add">{t('ActionNames.add')}&nbsp;&nbsp;<span className="addbtn">+</span></button>
                        </div>}
                        {actions.bulkUpload && <div><button className="btn blkupload pl-2 pr-0" id="upload" onClick={addBulkUpload}>
                            <img alt="" src={uploadlogo} /></button>
                            <UncontrolledTooltip color="primary" placement="top" target="upload">
                                {t('ActionNames.bulkupload')}
                            </UncontrolledTooltip>
                        </div>}
                    </div>
                }
            </Col>
        </>
    )
}
export default React.memo(ServiceFilter);