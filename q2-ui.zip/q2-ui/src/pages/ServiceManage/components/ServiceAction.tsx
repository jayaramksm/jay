import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, Label } from 'reactstrap';
import '../Container/servicemanage.css';
import { useTranslation } from 'react-i18next';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { IService, IServiceAction } from '../../../models/servicesModel';
import { controleContentValidate, customContentValidation, MySelect } from '../../../helpers/helpersIndex';
import { suspendServiceActionType, createOrUpdateServiceRequest } from '../../../store/actions';

const checkInOptions = [
    { value: 5, label: '5 Min' },
    { value: 10, label: '10 Min' },
    { value: 20, label: '20 Min' },
    { value: 30, label: '30 Min' },
    { value: 40, label: '40 Min' },
    { value: 50, label: '50 Min' },
    { value: 60, label: '60 Min' },
];
const ServiceAction: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const serviceActionData: IService = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.serviceActionData)
            return (state.serviceReducer.serviceActionData as IServiceAction).actionData as IService;
        else return undefined;
    });
    const cancelAction = () => dispatch(suspendServiceActionType());

    const getInitialValues = () => ({
        serviceId: serviceActionData ? serviceActionData.serviceId : 0,
        serviceNameEn: serviceActionData ? serviceActionData.serviceNameEn : '',
        serviceNameAr: serviceActionData ? serviceActionData.serviceNameAr : '',
        tokenPrefix: serviceActionData ? serviceActionData.tokenPrefix : '',
        waitTimeAvg: serviceActionData ? (serviceActionData.waitTimeAvg ? checkInOptions.find(x => x.value === serviceActionData.waitTimeAvg) : '') : '',
        minCheckinTime: serviceActionData ? (serviceActionData.minCheckinTime ? checkInOptions.find(x => x.value === serviceActionData.minCheckinTime) : '') : checkInOptions.find(x => x.value === 30),
        maxCheckinTime: serviceActionData ? (serviceActionData.maxCheckinTime ? checkInOptions.find(x => x.value === serviceActionData.maxCheckinTime) : '') : checkInOptions.find(x => x.value === 30),
        startSeq: serviceActionData ? serviceActionData.startSeq : 1,
        endSeq: serviceActionData ? serviceActionData.endSeq : 100,
        isDefault: serviceActionData ? serviceActionData.isDefault : 0
    });

    const validationSchema = Yup.object().shape({
        serviceNameEn: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphanumericspacesp', message: 'alphanumericspace', spacialChar: null }, 50, 2),
        serviceNameAr: customContentValidation(t, t('controleErrors.required'), { patternType: 'arabicnumaricspacesp', message: 'arabicnumaricspace', spacialChar: null }, 50, 2),
        tokenPrefix: customContentValidation(t, t('controleErrors.required'), { patternType: 'alphaCapitals', message: 'alphaCapitals', spacialChar: null }, 3, 1),
        waitTimeAvg: controleContentValidate(t('controleErrors.required')),
        minCheckinTime: controleContentValidate(t('controleErrors.required')),
        maxCheckinTime: controleContentValidate(t('controleErrors.required')),
        startSeq: Yup.number().when('endSeq', (endSeq) => {
            if (endSeq)
                return Yup.number().max(endSeq - 1, t('Services.minGreater')).required(t('controleErrors.required')).typeError(t('controleErrors.patterninvalid'));
            else return customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 3)
        }),
        endSeq: customContentValidation(t, t('controleErrors.required'), { patternType: 'number', message: 'number', spacialChar: null }, 3)
    });

    const earlyCheckinSelection = (e, setFieldValue) => {
        setFieldValue('minCheckinTime', e);
    }
    const lateCheckinSelection = (e, setFieldValue) => {
        setFieldValue('maxCheckinTime', e);
    }
    const levelTimeSelection = (e, setFieldValue) => {
        setFieldValue('waitTimeAvg', e);
    }

    return (
        <>
            <div>
                <h6 className="serviceDetails py-2 pl-2 mb-3">{serviceActionData ? t('Services.serviceUpdate') : t('Services.serviceCreation')}</h6>
                <Formik
                    enableReinitialize
                    initialValues={getInitialValues()}
                    validationSchema={validationSchema}
                    onSubmit={(values: any) => {
                        let minCheckinTimeSelect = values.minCheckinTime;
                        let maxCheckinTimeSelect = values.maxCheckinTime;
                        let waitTimeSelect = values.waitTimeAvg;

                        let data = {
                            serviceId: values.serviceId,
                            serviceNameEn: values.serviceNameEn,
                            serviceNameAr: values.serviceNameAr,
                            tokenPrefix: values.tokenPrefix,
                            minCheckinTime: minCheckinTimeSelect.value,
                            maxCheckinTime: maxCheckinTimeSelect.value,
                            waitTimeAvg: waitTimeSelect.value,
                            startSeq: values.startSeq,
                            endSeq: values.endSeq,
                            isDefault: values.isDefault
                        }
                        dispatch(createOrUpdateServiceRequest(data, t('Services.confirmMessages.SC3'), t('Services.confirmMessages.SC4')));
                    }}
                >
                    {({ errors, values, touched, dirty, setFieldTouched, setFieldValue }) => (
                        <Form>
                            <Row className="mx-0 service-row">
                                <Col sm="3">
                                    <div className="form-group">
                                        <Label>{t('Services.serviceEngName')}</Label>
                                        <Field placeholder={t('Services.serviceEngName')} name="serviceNameEn" type="text" className={'form-control ' + (errors.serviceNameEn && touched.serviceNameEn ? 'is-invalid' : '')} />
                                        <ErrorMessage name="serviceNameEn" component='div' className="invalid-feedback" />
                                    </div>
                                </Col>
                                <Col sm="3">
                                    <div className="form-group text-right">
                                        <Label>{t('Services.serviceArbName')}</Label>
                                        <Field placeholder={t('Services.serviceArbName')} name="serviceNameAr" type="text" className={'form-control text-right ' + (errors.serviceNameAr && touched.serviceNameAr ? 'is-invalid' : '')} />
                                        <ErrorMessage name="serviceNameAr" component='div' className="invalid-feedback" />
                                    </div>
                                </Col>
                                <Col sm="3">
                                    <div className="form-group">
                                        <Label>{t('Services.servicePrefix')}</Label>
                                        <Field placeholder={t('Services.servicePrefix')} onChange={(e) => setFieldValue('tokenPrefix', e.target.value.toUpperCase())} name="tokenPrefix" type="text" className={'form-control ' + (errors.tokenPrefix && touched.tokenPrefix ? 'is-invalid' : '')} />
                                        <ErrorMessage name="tokenPrefix" component='div' className="invalid-feedback" />
                                    </div>
                                </Col>
                                <Col sm="3">
                                    <div className="form-group">
                                        <Label>{t('Services.serviceLevelTime')}</Label>
                                        <MySelect
                                            placeholder={t('Services.selectTime')}
                                            name="waitTimeAvg"
                                            value={values.waitTimeAvg}
                                            onChange={(e) => levelTimeSelection(e, setFieldValue)}
                                            options={checkInOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('waitTimeAvg', true)}
                                        />
                                        {errors.waitTimeAvg && touched.waitTimeAvg && (
                                            <div className="error-msg">{errors.waitTimeAvg}</div>
                                        )}


                                        {/* <Field placeholder={t('Services.serviceLevelTime')} name="waitTimeAvg" type="text" className={'form-control ' + (errors.waitTimeAvg && touched.waitTimeAvg ? 'is-invalid' : '')} />
                                        <ErrorMessage name="waitTimeAvg" component='div' className="invalid-feedback" /> */}
                                    </div>
                                </Col>
                            </Row>
                            <Row className="mx-0 service-row">
                                <Col sm="3">
                                    <div className="form-group">
                                        <Label>{t('Services.earlyCheckin')}</Label>
                                        <MySelect
                                            name="minCheckinTime"
                                            value={values.minCheckinTime}
                                            onChange={(e) => earlyCheckinSelection(e, setFieldValue)}
                                            options={checkInOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('minCheckinTime', true)}
                                        />
                                        {errors.minCheckinTime && touched.minCheckinTime && (
                                            <div className="error-msg">{errors.minCheckinTime}</div>
                                        )}

                                        {/* <Field placeholder={t('Services.earlyCheckin')} name="minCheckinTime" type="text" className={'form-control ' + (errors.minCheckinTime && touched.minCheckinTime ? 'is-invalid' : '')} />
                                        <ErrorMessage name="minCheckinTime" component='div' className="invalid-feedback" /> */}
                                    </div>
                                </Col>
                                <Col sm="3">
                                    <div className="form-group">
                                        <Label>{t('Services.lateCheckin')}</Label>
                                        <MySelect
                                            name="maxCheckinTime"
                                            value={values.maxCheckinTime}
                                            onChange={(e) => lateCheckinSelection(e, setFieldValue)}
                                            options={checkInOptions}
                                            getOptionLabel={option => option.label}
                                            getOptionValue={option => option.value}
                                            onBlur={() => setFieldTouched('maxCheckinTime', true)}
                                        />
                                        {errors.maxCheckinTime && touched.maxCheckinTime && (
                                            <div className="error-msg">{errors.maxCheckinTime}</div>
                                        )}

                                        {/* <Field placeholder={t('Services.lateCheckin')} name="maxCheckinTime" type="text" className={'form-control ' + (errors.maxCheckinTime && touched.maxCheckinTime ? 'is-invalid' : '')} />
                                        <ErrorMessage name="maxCheckinTime" component='div' className="invalid-feedback" /> */}
                                    </div>
                                </Col>
                                <Col sm="3">
                                    <div className="form-group">
                                        <Label>{t('Services.startTime')}</Label>
                                        <Field placeholder={t('Services.startTime')} name="startSeq" type="text" className={'form-control ' + (errors.startSeq && touched.startSeq ? 'is-invalid' : '')} />
                                        <ErrorMessage name="startSeq" component='div' className="invalid-feedback" />
                                    </div>
                                </Col>
                                <Col sm="3">
                                    <div className="form-group">
                                        <Label>{t('Services.endTime')}</Label>
                                        <Field placeholder={t('Services.endTime')} name="endSeq" type="text" className={'form-control ' + (errors.endSeq && touched.endSeq ? 'is-invalid' : '')} />
                                        <ErrorMessage name="endSeq" component='div' className="invalid-feedback" />
                                    </div>
                                </Col>
                            </Row>

                            <div className="text-right mb-3">
                                <button type="submit" disabled={!(dirty)} className="btn btn-primary">
                                    {serviceActionData ? t('ActionNames.update') : t('ActionNames.save')}
                                </button>
                                <button className="btn btn-cancel ml-3" onClick={cancelAction}>
                                    {t('ActionNames.cancel')}
                                </button>
                            </div>
                        </Form>
                    )}
                </Formik>
            </div>
        </>
    )
}
export default React.memo(ServiceAction);