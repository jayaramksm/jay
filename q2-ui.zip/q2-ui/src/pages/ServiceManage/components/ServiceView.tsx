import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Row, Col, Label } from 'reactstrap';
import '../Container/servicemanage.css';
import { IServiceAction, IService } from '../../../models/servicesModel';
import { useTranslation } from 'react-i18next';
import { suspendServiceActionType } from '../../../store/actions';

const ServiceView: React.FC = () => {
    const { t } = useTranslation("translations");
    const dispatch = useDispatch();
    const serviceActionData: IService = useSelector(state => {
        if (state && state.serviceReducer && state.serviceReducer.serviceActionData)
            return ((state.serviceReducer.serviceActionData as IServiceAction).actionData as IService);
        else return undefined;
    });
    const cancelView = () => dispatch(suspendServiceActionType());

    return (
        <>
            {serviceActionData && <div className="viewService">
                <h6 className="serviceDetails py-2 pl-2 mb-3">{t('Services.serviceDetails')}</h6>
                <Row className="mb-4 mx-0">
                    <Col sm="3">
                        <span className="d-block text-wrap">{serviceActionData.serviceNameEn}</span>
                        <Label>{t('Services.serviceEngName')}</Label>
                    </Col>
                    <Col sm="3">
                        <span className="text-right d-block text-wrap">{serviceActionData.serviceNameAr}</span>
                        <Label className="text-right d-block">{t('Services.serviceArbName')}</Label>
                    </Col>
                    <Col sm="3">
                        <span>{serviceActionData.tokenPrefix}</span><br />
                        <Label>{t('Services.servicePrefix')}</Label>
                    </Col>
                    <Col sm="3">
                        <span>{serviceActionData.waitTimeAvg}</span><br />
                        <Label>{t('Services.serviceLevelTime')}</Label>
                    </Col>
                </Row>
                <Row className="mb-3 mx-0">
                    <Col sm="3">
                        <span>{serviceActionData.minCheckinTime}</span><br />
                        <Label>{t('Services.earlyCheckin')}</Label>
                    </Col>
                    <Col sm="3">
                        <span>{serviceActionData.maxCheckinTime}</span><br />
                        <Label>{t('Services.lateCheckin')}</Label>
                    </Col>
                    <Col sm="3">
                        <span>{serviceActionData.startSeq}</span><br />
                        <Label>{t('Services.startTime')}</Label>
                    </Col>
                    <Col sm="3">
                        <span>{serviceActionData.endSeq}</span><br />
                        <Label>{t('Services.endTime')}</Label>
                    </Col>
                </Row>
                <div className="text-right">
                    <button className="btn btn-cancel ml-2" onClick={cancelView}>
                        {t('ActionNames.cancel')}
                    </button>
                </div>
            </div>}
        </>
    )
}
export default React.memo(ServiceView);