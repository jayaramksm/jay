import React, { useEffect } from 'react';
import * as d3 from "d3";
import * as _ from 'lodash';
// import * as d3 from "../pages/CareMap/node_modules/d3";
import '../css/chart.css';
import priorityImg from '../images/priority.svg';

export default function TreeChart(props) {

    var enable = true;
    useEffect(() => {
        drawChart();
    }, []);

    const drawChart = () => {
        let margin = { top: 20, right: 120, bottom: 20, left: 120 },
            width = 900 - margin.right - margin.left,
            height = 600 - margin.top - margin.bottom;

        let i = 0,
            duration = 750,
            root;

        let tree = d3.layout.tree().size([height, width]);
        let diagonal = d3.svg.diagonal().projection(function (d) { return [d.y, d.x]; });
        function zoom() {
            svg.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
        }
        let zoomListener = d3.behavior.zoom().scaleExtent([0.1, 3]).on("zoom", zoom);

        // append the svg object to the body of the page
        let svg = d3.select("#treechart").append("svg")
            .attr("width", width + margin.right + margin.left)
            .attr("height", height + margin.top + margin.bottom)
            .attr("class", "graph-svg-component")
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
            .call(zoomListener);



        (function () {
            let flare = props.jsonData;
            console.log('flare', props);
            root = flare;
            root.x0 = height / 2;
            root.y0 = 0;

            root.all_children = root.children;
            root.children.forEach(collapse);
            root.children.forEach(function (d) { d.hidden = false; });
            root.hidden = false;
            //console.log('root',root);
            // checkError(root);
            //centerNode(root);
            setParent(root);
            validateTime(root);
            update(root);
            props.onClick(root);
        })();

        function validateTime(d) {
            if (d.all_children) {
                d.all_children.forEach((child) => {
                    //&& child.name === 'H1'
                    if (child.level === 1) {

                        if (child.all_children) {
                            // console.log('child123  level1', child.name,child.level,child.deptType,child);
                            child.all_children.forEach((level2Node) => {
                                if (level2Node.deptType === undefined || level2Node.deptType === 4) {

                                    if (level2Node.all_children) {
                                        // console.log('child123 level2', level2Node.name,level2Node.deptType,level2Node);
                                        level2Node.all_children.forEach((level3Node) => {
                                            var servWaitTime = 0;
                                            var waitTime = 0;
                                            if (level3Node.all_children) {
                                                // console.log('child123 level3           ', level3Node.name, level3Node);
                                                var servingNodes = level3Node.all_children[0].all_children;
                                                if (servingNodes) {
                                                    //console.log('child123 servingNodes',servingNodes);
                                                    var serv = _.maxBy(servingNodes, function (s) {
                                                        return s.time;
                                                    });

                                                    level3Node.all_children[0].maxTime = serv ? serv.time : 0;
                                                    servWaitTime = serv.time;
                                                }
                                                var waitingNodes = level3Node.all_children[1].all_children;
                                                if (waitingNodes) {
                                                    var wait = _.maxBy(waitingNodes, function (w) {
                                                        return w.time;
                                                    });
                                                    level3Node.all_children[1].maxTime = wait ? wait.time : 0;
                                                    waitTime = wait.time;
                                                }

                                                var maxTime = servWaitTime >= waitTime ? servWaitTime : waitTime;
                                                level3Node.maxTime = maxTime;
                                                //console.log('child123  level3Node change', level3Node);
                                            } else {
                                                level3Node.maxTime = 0;
                                            }

                                        });
                                        var wait = _.maxBy(level2Node.all_children, function (w) {
                                            return w.maxTime;
                                        });

                                        level2Node.maxTime = wait.maxTime;

                                    } else {
                                        level2Node.maxTime = 0;
                                    }
                                    // console.log('child123 level2', level2Node.name,level2Node);

                                } else if (level2Node.deptType === 1 || level2Node.deptType === 2 || level2Node.deptType === 3) {

                                    if (level2Node.all_children) {
                                        //Pharmacy's,Laboratory's and Radiology's
                                        level2Node.all_children.forEach((level2SubNode) => {
                                            //Pharmacy-1,Pharmacy-2 like
                                            // console.log('child123 level2SubNode', level2SubNode.name,level2SubNode);
                                            if (level2SubNode.all_children) {
                                                level2SubNode.all_children.forEach((level3Node) => {
                                                    var servWaitTime = 0;
                                                    var waitTime = 0;
                                                    if (level3Node.all_children) {
                                                        var servingNodes = level3Node.all_children[0].all_children;
                                                        if (servingNodes) {
                                                            //console.log('child123 servingNodes',servingNodes);
                                                            var serv = _.maxBy(servingNodes, function (s) {
                                                                return s.time;
                                                            });

                                                            level3Node.all_children[0].maxTime = serv ? serv.time : 0;
                                                            servWaitTime = serv.time;
                                                        }

                                                        var waitingNodes = level3Node.all_children[1].all_children;
                                                        if (waitingNodes) {
                                                            var wait = _.maxBy(waitingNodes, function (w) {
                                                                return w.time;
                                                            });
                                                            level3Node.all_children[1].maxTime = wait ? wait.time : 0;
                                                            waitTime = wait.time;
                                                        }

                                                        var maxTime = servWaitTime >= waitTime ? servWaitTime : waitTime;
                                                        level3Node.maxTime = maxTime;
                                                        //console.log('child123  level3Node change', level3Node);
                                                    } else {
                                                        level3Node.maxTime = 0;
                                                    }


                                                });

                                                var wait = _.maxBy(level2SubNode.all_children, function (w) {
                                                    return w.maxTime;
                                                });

                                                level2SubNode.maxTime = wait.maxTime;

                                            } else {
                                                level2SubNode.maxTime = 0;
                                            }


                                        });
                                        var wait = _.maxBy(level2Node.all_children, function (w) {
                                            return w.maxTime;
                                        });

                                        level2Node.maxTime = wait.maxTime;
                                        console.log('child123 level2Node           ', level2Node.name, level2Node);

                                    } else {
                                        level2Node.maxTime = 0;
                                    }
                                }

                            });
                            var wait = _.maxBy(child.all_children, function (w) {
                                return w.maxTime;
                            });
                            child.maxTime = wait.maxTime;
                        } else {
                            child.maxTime = 0;
                        }
                        // console.log('child123 level2', child.name,child);
                    }

                });

            }
        }

        // function collapseAll() {
        //     root.children.forEach(collapse);
        //     collapse(root);
        //     update(root);
        // }

        // function expand(d) {
        //     var children = (d.children) ? d.children : d._children;
        //     if (d._children) {
        //         d.children = d._children;
        //         d._children = null;
        //     }
        //     if (children)
        //         children.forEach(expand);
        // }

        // function expandAll() {
        //     expand(root);
        //     update(root);
        // }


        function centerNode(source) {
            var scale = zoomListener.scale();
            var x = -source.y0;
            var y = -source.x0;
            x = x * scale + width / 2;
            if (source.depth === 1) {
                x = 70;
            }
            // if (source.level === 3) {
            //     x = 70;
            // }
            // if (source.level === 4) {
            //     x = 30;
            // }
            y = y * scale + height / 2;
            y = 0;
            console.log('center node', source.level, x)
            d3.select('g').transition()
                .duration(duration)
                .attr("transform", "translate(" + x + "," + y + ")scale(" + scale + ")");
            // zoomListener.scale(scale);
            // zoomListener.translate([x, y]);
        }

        // function childNodes(parentNode, childs) {
        //     childs.forEach(function (d) {
        //         if (d.class) {
        //             parentNode.class = d.class;
        //         }
        //         if (d._children) {
        //             childNodes(d, d._children);
        //         }
        //     });
        // }

        function collapse(d) {
            if (d.children) {
                d.all_children = d.children;
                d._children = d.children;
                d._children.forEach(collapse);
                // d._children.forEach(function(d1){d1.parent = d; collapse(d1);});
                d.children = null;
                d.hidden = enable;
            }
        }


        function getColor(node) {
            if (!node.time) {
                return "";
            }
            if (node.time <= 15) {
                return "green";
            } else if (node.time >= 16 && node.time <= 35) {
                return "#FFBF00";//Amber color
            } else {
                return "red";
            }
        }

        function getColorNew(time) {

            if (time <= 15) {
                return "green";
            } else if (time >= 16 && time <= 35) {
                return "#FFBF00";//Amber color
            } else {
                return "red";
            }
        }

        // function getBlinkClass(node) {
        //     if (node.time <= 15) {
        //         return "green";
        //     } else if (node.time >= 16 && node.time <= 35) {
        //         return "orange";
        //     } else {
        //         return "red";
        //     }

        // }

        function addRootNode(nodeEnter) {
            nodeEnter.filter(function (d) {
                return d.depth === 0;
            }).append("rect")
                .attr("x", -70)
                .attr("y", -15)
                .attr("rx", 10)
                .attr("ry", 10)
                .attr("width", 80)
                .attr("height", 30)
                .style({ "fill": "1f1c4f", "stroke": "1f1c4f" });

            nodeEnter.filter(function (d) {
                return d.depth === 0;
            }).append("circle")
                .attr("r", "10")
                .style("fill", function (d) { return "white" });
        }

        function getText(nodeData) {
            if (nodeData.level === 6) {
                return "MRN: " + nodeData.mrn;
            } else {
                return nodeData.name;
            }
        }

        function addLevel6TokenInfoText(groupNode) {
            groupNode.filter(function (d) {
                return d.level === 6;
            }).append("text")
                .attr('id', 'tokeninfo')
                .attr("x", 31)
                .attr("y", 20).text(function (d) {
                    return "Token: " + d.token + "";
                })
                .style({
                    "fill": "black", "font-size": 10, "font-weight": "bold"
                })
        }
        function addLevel6WaitTimeText(groupNode) {
            groupNode.filter(function (d) {
                return d.level === 6;
            }).append("text")
                .attr('id', 'waittime')
                .attr("x", 142)
                .attr("y", 5)
                .text(function (d) {
                    return d.time + " Min";
                })
                .style({
                    "fill": "black", "font-size": 14, "font-weight": "bold"
                })
        }
        function addQueueText(node) {
            node.filter(function (d) {
                return d.level === 6;
            })
                .append("tspan")
                // .attr("x", 20)
                //     .attr("y", 25)
                .text(" ")
                .append("tspan")
                .attr("x", 25)
                .attr("y", 12).text(function (d) {
                    return "Token: " + d.token + "";
                    // return " ";
                })
                .attr({
                    "font-size": 10,
                    // "font-style": "italic",
                })
                .style({
                    "font-weight": "bold",
                    "fill": "black"
                })
                .append("tspan")
                .attr("x", 142)
                .attr("y", 5)
                .text(function (d) {
                    // return "[" + d.time + " Min]";
                    return d.time + " Min";
                }).attr({
                    "font-size": 15,
                    // "font-style": "italic",
                }).style("fill", function (d) {
                    return "black";//getColor(d);
                });

            // node.filter(function (d) {
            //     return d.level === 6;
            // }).append("svg:image")
            // .attr('x', 200)
            // .attr('y', -12)
            // .attr('width', 20)
            // .attr('height', 24)
            // .attr("xlink:href", function(d){
            //     return  priorityImg
            // });

            // .append("tspan").attr("x", 200).attr('id','priority')
            //     .text(function(d){
            //         return d.priority === 1? "p":"";
            //     }).attr({
            //         "font-size": 10,
            //         "font-style": "italic",
            //     });

        }
        function addQueueTextInLevel4(node) {
            node.filter(function (d) {
                return d.level === 4;
            })
                .append("tspan")
                .attr("x", 17)
                .attr("y", 35)
                .text(function (d) {
                    console.log('addQueueTextInLevel4', d);
                    // var waitTime = 0;
                    // if (d.all_children) {
                    //     d.all_children.forEach(function (child) {
                    //         waitTime += child.time;
                    //     });
                    //     d.time = (waitTime / d.all_children.length).toFixed(2);
                    // }

                    // return "[Avg-" + d.time + " Min]";
                    if (d.maxTime) {
                        return "[Wait Time-" + d.maxTime + " Min]";
                    } else {
                        return "";
                    }

                }).style("fill", function (d) {
                    return getColorNew(d.maxTime);
                });
        }

        function setParent(rootNode) {
            if (rootNode.all_children) {
                rootNode.all_children.forEach((child) => {
                    child.parent = rootNode;
                    setParent(child);
                });
            }
        }

        function checkError(d) {
            if (d.all_children) {
                d.all_children.forEach((child) => {
                    child.parent = d;
                    if (child.level === 6 && child.time >= 35) {
                        d.class = "blinkred";
                        d.parent.class = "blinkred";
                        d.parent.parent.class = "blinkred";
                        d.parent.parent.parent.class = "blinkred";

                    } else {
                        checkError(child);
                    }
                });
            }
        }



        function update(source) {


            // Compute the new tree layout.
            var nodes = tree.nodes(root).filter(function (d) { return !d.hidden; }).reverse(),
                links = tree.links(nodes);

            // Normalize for fixed-depth.
            nodes.forEach(function (d) { d.y = d.depth * 130; });

            // Update the nodes…
            var node = svg.selectAll("g.node")
                .data(nodes.filter(function (d) { return !d.hidden; }), function (d) { return d.id || (d.id = ++i); });

            // Enter any new nodes at the parent's previous position.
            var nodeEnter = node.enter().append("g")
                .attr("class", "node")
                .attr("transform", function (d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
                .on("click", click);

            addRootNode(nodeEnter);


            nodeEnter.filter(function (d) {
                return d.level === 6;
            }).append("rect")
                .attr('id', 'select')
                .attr('x', 20)
                .attr('y', -18)
                .attr("rx", 10)
                .attr("ry", 10)
                .attr("width", function (d) {
                    return 220;
                })
                .attr("height", 50).style("stroke-width", "0")
                .style("stroke", "e4e4ed")
                .style('fill', "#e4e4ed")
                .style("text-align", "center");

            nodeEnter.filter(function (d) {
                return d.level === 6;
            }).append("svg:image")
                .attr('x', 195)
                .attr('y', -7)
                .attr('width', 14)
                .attr('height', 14)
                .attr("xlink:href", function (d) {
                    return priorityImg
                });


            var textNode = nodeEnter.append("text")
                .attr("x", function (d) {
                    return d.level === 6 ? 25 : 12;
                })
                .attr("y", function (d) {
                    return d.level === 6 ? -4 : 0;
                })
                // .attr("dy", ".35em")
                .attr("dy", function (d) {
                    return d.level === 6 ? "" : ".35em";
                })
                .attr("text-anchor", function (d) { return "start"; })
                .attr("font-weight", "bold")
                .text(function (d) {
                    return getText(d);
                });


            textNode.filter(function (d) {
                return d.level === 0;
            }).attr("fill", "white");




            addQueueTextInLevel4(textNode);
            addLevel6TokenInfoText(nodeEnter);
            addLevel6WaitTimeText(nodeEnter);
            // addQueueText(textNode);


            nodeEnter.filter(function (d) {
                return d.depth === 0;
            }).append("circle")
                .attr("r", "10")
                .style("fill", function (d) { return "white" });

            nodeEnter.filter(function (d) {
                return d.level !== 0 && d.level !== 6;
            })
                .append("circle")
                .attr("r", "10")
                .style("fill", function (d) { return d._children ? "lightsteelblue" : "#fff"; });


            nodeEnter.filter(function (d) {
                return d.level === 6;
            })
                // .append("rect")
                // .attr("x", -5)
                // .attr("y", -7)
                // .attr("width", '12')
                // .attr("height", '12')
                .append("circle")
                .attr("r", "8")
                .style(
                    {
                        fill: function (d) {
                            return getColor(d);
                        },
                        stroke: function (d) { return getColor(d); }
                    }
                );



            //Add count  
            nodeEnter.append('text')
                .attr('x', 0)
                .attr('y', 4)
                .attr('id', "count")
                .attr('fill', "white")
                .attr("text-anchor", "middle")
                .attr('cursor', 'pointer')
                .style('font-size', d => {

                    return "10px";

                })
                .text(function (d) {
                    var count = 0;

                    if (d.level === 3 && d.all_children) {
                        d.all_children.forEach(function (n) {
                            count += n.all_children ? n.all_children.length : 0;
                        });
                        return count;
                    }
                    if (d.children) return d.children.length;
                    else if (d._children) return d._children.length;
                }).filter(function (d) {
                    return d.level === 0;
                }).attr('fill', "#1f1c4f");


            // Transition nodes to their new position.
            var nodeUpdate = node.transition()
                .duration(duration)
                .attr("transform", function (d) {
                    if (d.level === 6) {
                        return "translate(" + d.y + "," + d.x + ")";
                    } else {
                        return "translate(" + d.y + "," + d.x + ")";
                    }

                });
            // console.log('nodeUpdate =>',node.select("circle"));

            // nodeUpdate[0].forEach((d)=>{
            //    // var text=d.select('text');
            //     console.log('nodeUpdate =>',d);
            // })

            // nodeUpdate.selectAll("text").attr("x",(d,i)=>{

            //     if(d.level === 4){
            //         console.log('text123 =>',d);
            //     }
            // });
            // var nn1=node.selectAll("#count");

            // nn1.forEach( (txt)=>{
            //     console.log('test',txt);

            // })
            nodeUpdate.select("#count").filter((d) => {
                return d.level === 4;
            }).text(function (d) {
                var count = 0;

                if (d.level === 3 && d.all_children) {
                    d.all_children.forEach(function (n) {
                        count += n.all_children ? n.all_children.length : 0;
                    });
                    return count;
                }
                console.log('test', d);
                if (d.children) return d.children.length;
                else if (d._children) return d._children.length;
            }).filter(function (d) {
                return d.level === 0;
            }).attr('fill', "#1f1c4f");

            nodeUpdate.select("#tokeninfo").filter((d) => {
                return d.level === 6;
            }).style('fill', (d) => {
                if (d.click) {
                    return "#FFFFFF";
                } else {
                    return "black";
                }

            });

            nodeUpdate.select("#waittime").filter((d) => {
                return d.level === 6;
            }).style('fill', (d) => {
                if (d.click) {
                    return "#FFFFFF";
                } else {
                    return "black";
                }

            });

            nodeUpdate.select("circle")
                .attr("r", (d) => {
                    return d.all_children ? 10 : 6;
                })
                .style("fill", function (d) {
                    if (d.level === 1 || d.level === 2 || d.level === 3 || d.level === 4) {
                        return d.all_children ? getColorNew(d.maxTime) : "#BCBDA8";
                    } else if (d.level === 6) {
                        return getColor(d);
                    }
                    // getColorCode(d);
                    //  return d.all_children ? getColorNew(d.maxTime) : getColorNew(d.maxTime);
                    // return d.all_children ? "#1f1c4f" : "#BCBDA8";
                })
                .attr("class", function (d) {
                    return d.class;
                });



            //nodeUpdate.select("text").select('tspan').remove();
            nodeUpdate.select('tspan')
                .attr("x", function (d) {

                    if (d.level !== 6) {
                        var xx = 15;
                        return d._children ? xx : -10;
                    }

                }).attr("y", function (d) {
                    //console.log('tspan', this.style.fill);
                    if (d.level !== 6) {
                        var yy = 30;
                        return d._children && d.depth ? yy : 45;
                    }
                }).style("fill", function (d) {

                    if (d.click) {
                        // console.log('color', this);
                        console.log('color d', d.name);
                        return "white";

                    }
                    else if (d.level === 6) {
                        // console.log('color 6', this,d.name);
                        return "black";
                    } else {
                        // console.log('color 6 1', this);
                        return this.style.fill
                    }

                });



            nodeUpdate.select('image').filter(function (d) {
                console.log('image', d.name, this);
                return d.level === 6;
            }).attr('visibility', function (d) {
                console.log('image');
                return d.priority === 0 ? "hidden" : "visible";
            });

            nodeUpdate.select('rect')
                .style('fill', function (d) {

                    if (d.click) {
                        return "#595866";
                    } else if (d.level === 6) {
                        return "#e4e4ed";
                    } else {
                        return "#1f1c4f"
                    }
                });

            nodeUpdate.select("text")
                .attr("x", function (d) {
                    if (d.level === 6) {
                        return 31;
                    }
                    var xx = -25;
                    return d.children ? xx : 12;
                }).attr("y", function (d) {
                    var yy = -20;
                    if (d.level === 6) {
                        return 5;
                    }
                    if (d.level === 2 || d.level === 4) {
                        yy = 20;
                    }
                    return d.children && d.depth ? yy : 0;
                })
                .attr("text-anchor", function (d) {
                    if (!d.depth) { return "end"; }
                }).style("fill", function (d) {
                    if (d.click) {
                        return "white";
                    }
                })
                .style("fill-opacity", 1);

            // nodeUpdate.select("text").text((d)=>{
            //     console.log('Text =>',d);

            // });

            // Transition exiting nodes to the paren;t's new position.
            var nodeExit = node.exit().transition()
                .duration(duration)
                .attr("transform", function (d) { return "translate(" + source.y + "," + source.x + ")"; })
                .remove();

            nodeExit.select("circle")
                .attr("r", 1e-6);


            nodeExit.select("text")
                .style("fill-opacity", 1e-6);

            // Update the links…
            var link = svg.selectAll("path.link")
                .data(links, function (d) { return d.target.id; });

            // Enter any new links at the parent's previous position.
            link.enter().insert("path", "g")
                .attr("class", "link")
                .attr("d", function (d) {
                    var o = { x: source.x0, y: source.y0 };
                    return diagonal({ source: o, target: o });
                }).style("stroke", function (d) {

                    if (d.target.level === 6) {
                        return getColor(d.target);
                    } else {
                        //     if(d.source.level === 0){
                        //         return  "#1f1c4f";
                        //     }else{
                        //     return getColorNew(d.target.maxTime);
                        //    }
                        //   return d.source.class && d.target.class ? "red" : "#1f1c4f";
                        return "#1f1c4f";
                    }
                    // return "1f1c4f";
                });

            // Transition links to their new position.
            link.transition()
                .duration(duration)
                .attr("d", diagonal);

            // Transition exiting nodes to the parent's new position.
            link.exit().transition()
                .duration(duration)
                .attr("d", function (d) {
                    var o = { x: source.x, y: source.y };
                    return diagonal({ source: o, target: o });
                })
                .remove();

            // Stash the old positions for transition.
            nodes.forEach(function (d) {
                console.log("test", d);
                d.x0 = d.x;
                d.y0 = d.y;
            });
        }

        function getColorCode(d) {
            console.log('color', d);
            d.all_children.forEach((d) => {


            })
        }


        // Toggle children on click.
        function click(d) {
            if (d.depth === 0) {
                return;
            }




            if (d.children) { d.children.forEach(function (d) { delete d.click }) };
            if (d._children) { d._children.forEach(function (d) { delete d.click }) };
            d.parent.children.forEach(function (d) { delete d.click });

            if (d.level === 6) {
                d.click = true;
            }

            if (d.children) {
                d._children = d.children;
                if (d.children.length === 1) {
                    d._children.forEach(function (n) {
                        n._children = n.all_children;
                        n.children = null;
                    });
                    d._children = d.all_children;
                }
                d.children = null;
                if (d._children) {
                    d._children.forEach(function (n) { n.hidden = enable; });

                    if (d.parent) {
                        d.parent.children = d.parent.all_children;
                        d.parent.children.forEach(function (n) {
                            n.hidden = false;
                        });
                    }
                }
            } else {
                if (d._children) {
                    d._children.forEach(function (n) {
                        n._children = n.all_children;
                        n.children = null;
                    });
                }
                d.children = d._children;
                d._children = null;
                if (d.children) {
                    d.children.forEach(function (n) { n.hidden = false; });

                    if (d.parent) {
                        if (enable) {
                            d.parent.children = [d,];
                        }
                        // d.parent.children = [d,];
                        d.parent.children.filter(function (n) { return n !== d; }).forEach(function (n) {
                            n.hidden = enable;
                        });
                    }
                }
            }

            if (d.level !== 6) {
                centerNode(d);
            }


            if (d.level === 4) {
                d.children = _.orderBy(d.children, 'time', 'desc');
                //    console.log('sort',d.children);
                //     d.children.sort(function(x, y){
                //         return d3.descending(x.time, y.time);
                //      })
                //     console.log('sort',d.children);
                //d3.sort()
                // checkError(d);
                //  console.log('click 2:',d);
            }

            if (d.level === 1 || d.level === 2 | d.level === 3) {

                if (d.children) {
                    d.children = _.orderBy(d.children, 'name', 'asc');
                } else {
                    d.parent.children = _.orderBy(d.parent.children, 'name', 'asc');
                }



            }

            update(d);
            props.onClick(d, click);
        }
    }
    return (
        <div className="container mt-3 crmp">
            <div className="left-div">
                <div id="treechart">
                </div>
            </div>
            <div className="right-div">
                <div className="right-top-div" id="userdetails">
                    <div className="timelinechart"> </div>
                    <div className="userdetailsCls" style={{ display: 'none' }}>
                    </div>
                    <div className="right-bottom-div" id="tables">
                    </div>
                </div>
            </div>
        </div>
    )
}