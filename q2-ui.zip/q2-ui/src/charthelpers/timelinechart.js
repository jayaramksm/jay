import React, { useEffect } from 'react';
import * as d3 from "d3";
import '../css/chart.css';
import * as timeline from "./d3-timeline";
import { Card, CardBody, CardHeader } from 'reactstrap';
import * as css from '../css/timelinechart.css';

export default function TimeLineChart(data) {

  useEffect(() => {
    drawChart();
  }, []);

  const drawChart = () => {
    console.log('TimeLineChart', data);
    var labelColorTestData = [
      {
        label: "Waiting",
        times: [{ "color": "red", "label": "20", "starting_time": Date.parse("2019-01-01T10:10:00"), "ending_time": Date.parse("2019-01-01T10:20:00") },
        { "color": "red", "label": "10", "starting_time": Date.parse("2019-01-01T10:50:00"), "ending_time": Date.parse("2019-01-01T11:00:00") }]
      },
      {
        label: "Vital",
        times: [{ "color": "orange", "label": "10", "starting_time": Date.parse("2019-01-01T10:20:00"), "ending_time": Date.parse("2019-01-01T10:30:00") },
        { "color": "orange", "label": "15", "starting_time": Date.parse("2019-01-01T10:35:00"), "ending_time": Date.parse("2019-01-01T10:50:00") }]
      },
      {
        label: "Doctor",
        times: [{ "color": "green", "label": "15", "starting_time": Date.parse("2019-01-01T11:30:00"), "ending_time": Date.parse("2019-01-01T11:45:00") }]
      },
      {
        label: "Laboratory",
        times: [{ "color": "blue", "label": "30", "starting_time": Date.parse("2019-01-01T11:00:00"), "ending_time": Date.parse("2019-01-01T11:30:00") }]
      },
      {
        label: "pharmacy",
        times: [{ "color": "8DFF33", "label": "20", "starting_time": Date.parse("2019-01-01T11:45:00"), "ending_time": Date.parse("2019-01-01T12:05:00") }]
      }
    ];
    var width = 450;
    var chart = d3.timeline()
      .stack() // toggles graph stacking
      .margin({ left: 70, right: 30, top: 0, bottom: 0 })
      .showTimeAxisTick()
     // .mouseover(onmouseOver)
     // .mouseout(onmouseOut)
      .tickFormat({
        format: function (d) { return d3.time.format("%H:%M")(d) },
        tickTime: d3.time.minutes,
        tickInterval: 15,
        tickSize: 15,
      });


    var svg = d3.select("#timeline6").append("svg").attr("width", width);
    svg.datum(labelColorTestData).call(chart);
  }

  function onmouseOver(d, i, datum, obj) {
    console.log('mouse over', obj);
    
    console.log('mouse over', d, i, datum);

    var tag = "";

   
      tag = "Task: Hello<br/>" +
        "Type:  Type <br/>" ;
    
    var output = document.getElementById("tag");

    var x = (obj.x.animVal.value + obj.width.animVal.value / 2)+15 + "px";
    var y = obj.y.animVal.value + 100 + "px";
    //var y = obj.y.animVal.value +  "px";
    console.log('mouse over x, y', x,y);

    output.innerHTML = tag;
    output.style.top = y;
    output.style.left = x;
    output.style.background=d.color;
   // output.style.borderBottomColor=d.color;
    //output.pseudoStyle("before","border-bottom-color",d.color);
    //output.style.addClass('someclass');
    //output.style.cssText('--myVar:'+ d.color);
    //console.log('style :',output.style.rules);
    output.style.display = "block";

    // alert('hi');
  }
  function onmouseOut(obj) {
    // console.log('mouse out',obj);
    // alert('hi');
    var output = document.getElementById("tag");
    output.style.display = "none";
  }
  return (
    <div >


      <Card className="viewcard" style={{ width: "95%" }}>
        <h6>Journey Map </h6>
        <CardBody style={{ paddingTop: "0px" }}>
          <div id="timeline6">
          </div>
          <div id="tag"></div>
        </CardBody>
      </Card>
    </div>

  )
}