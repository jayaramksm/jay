export interface IKioskModel {
    kioskData: IKiosk[];
    themsData: ITheme[];
    searchKey: string;
    searchBranchId: number;
    actionData: IKiosk;
    actionType: number;
    refreshLoading: boolean;
}



export interface IKiosk {
    branches: number[];
    kioskId: number;
    kioskIdentifier: string;
    kioskIp: string;
    kioskName: string;
    status: number;
    themeId: number;
}
export interface IBranch {
    branchId: number;
    branchIdentifier: string;
    branchNameAr: string;
    branchNameEn: string;
    branchTypeId: number;
    serviceLocation: string;
}
export interface ITheme {
    themeId: number;
    themeName: string;
    themeType: string;
}