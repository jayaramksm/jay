import { IAlertMessagedata } from "./utilitiesModel";

export enum IWaitingStatusEnum {
    VITAL = 'V-WAITING',
    NURSE = 'WAITING',
    REGISTRATION = 'R-WAITING',
    PHARMACY = 'PH-WAITING',
    LABORATORY = 'L-WAITING',
    RADIOLOGY = 'RG-WAITING',
    NONCLINICAL = 'NC-WAITING'
}
export enum ITokenActionTypeEnum {
    SERVING = 'SERVING',
    NOSHOW = 'NOSHOW',
    RECYCLE = 'RECYCLE',
    SERVED = 'SERVED',
    END = 'END',
    RECALL = 'RECALL'
}
export enum ITabIndexEnum {
    CURRENT = 1,
    WAITING = 2
}
export interface IServiceStatasticsDetail {
    count: number;
    name: string;
    timeFormat: boolean;
}
export interface IRoomMappedToUserResponse {
    roomMappedToUserStatus: boolean;
    alertMessageData: IAlertMessagedata;
}