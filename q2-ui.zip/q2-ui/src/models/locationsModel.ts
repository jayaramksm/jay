export interface ILocationState {
    locationsData: ILocation[];
    actionId: number;
    actionType: number;
    refreshLoading: boolean;
    searchKey: string;
}
export interface ILocationUtilityModel{
    locationsData:ILocation[],
    alertMessageData:any
}
export interface ILocation {
    locationAddress: string;
    locationId: number;
    locationIdentfier: string;
    locationNameAr: string;
    locationNameEn: string;
    status: number;
}