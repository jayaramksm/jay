export interface IClientProfileSettings {
    branchServicesData: IBranchService[];
    prevMappedServices: IPrevBranchServices;
}
export enum ISelectionArea {
    Branch = 1,
    Service = 2
}
export interface IBranchService {
    branchId: number;
    branchIdentifier: string;
    branchNameAr: string;
    branchNameEn: string;
    branchTypeId: number;
    isFloating: number;
    isRegistration: number;
    serviceLocation: string;
    services: IService[];
}
export interface IService {
    branchId: number;
    serviceId: number;
    serviceNameAr: string;
    serviceNameEn: string;
}

export interface IPrevBranchServices {
    branchId: number;
    services: IPrevService[];
}
export interface IPrevService {
    count?: number;
    serviceId: number;
    serviceNameAr: string;
    serviceNameEn: string;
}

