export interface IGlobalSettingsModel {
    activeDirectoryStatus: boolean | undefined;
    activeDirectoryData: IAdSettings[];
    smsData: ISmsSettings;
    smsStatus: boolean | undefined;
    smsQueryParamsData: IQueryParam;
    emailStatus: boolean | undefined;
    emailData: IEmail;
    passwordPolicyData: any;
    passwordPolicyStatus: boolean;
}
export interface IAdSettings {
    adPath: string;
    firstName: string;
    host: string;
    lastName: string;
    ldapTimeOut: number;
    loginId: string;
    mailId: string;
    maxUsers: number;
    mobileNo: string;
    password: string;
    port: number;
    userName: string;
}
export interface ISmsSettings {
    connectionName: string;
    host: string;
    method: string;
    path: string;
    queryParameters: any;
    typeOfApi: string;
}
export interface IQueryParam {
    queryParam: string;
    queryParamId: number;
}
export interface IEmail {
    emailAccount: string;
    password: string;
    port: number;
    serverIp: string;
    serverName: string;
    mailBoxType: string;
}
export interface IPasswordPolicy {
    changePasswordatFirstLogin: boolean;
    maximumLength: number;
    minimumLength: number;
    noOfLowerCaseLetters: number;
    noOfUpperCaseLetters: number;
    numberOfAlphabets: number;
    numberOfNumerical: number;
    passwordValidityPeriod: number;
    specialCharactersAllowed: string;
}