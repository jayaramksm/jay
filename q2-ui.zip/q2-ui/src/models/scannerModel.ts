export interface IScannerModel {
    scannerData: IScanner[],
    themesData: ITheme[],
    actionType: number;
    actionData: IScanner;
    searchKey: string;
    refreshLoading: boolean;
    searchBranch:number
}
export interface IScanner {
    branch: number;
    scannerId: number;
    scannerIdentifier: string;
    scannerIp: string;
    scannerName: string;
    status: number;
    themeId: number;
    
}
export interface ITheme {
    themeId: number;
    themeName: string;
    themeType: string;
}
