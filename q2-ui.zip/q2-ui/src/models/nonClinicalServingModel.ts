import { IServiceStatasticsDetail } from "./utilityClientModel";

export interface INCServingModel {
    roomsData: IRoom[];
    selectedRoom: IRoom;
    servicesData: IServicesWithCount[];
    selectedServiceId: number;
    statasticsData: IServiceStatasticsDetail[];
    waitingTokensData: INCTokens[];
    servingTokensData: INCTokens[];
    selectionTabIndex: number;
    selectionActionArea: ISelectionActionArea;
}


export interface ISelectionActionArea {
    actionTokenId: number;
    journeyData: any;
}

export interface IServicesWithCount {
    count: number;
    serviceId: number;
    serviceNameAr: string;
    serviceNameEn: string;
}

export interface IRoom {
    maxAllowedToken: number;
    roomId: number;
    roomNameAr: string;
    roomNameEn: string;
    roomNo: string;
}

export interface INCTokens {
    appointmentTime: string;
    checkInTime: string;
    doctorName: string;
    drId: number;
    isVitalDone: boolean;
    mrnNo: string;
    patientName: string;
    servingCallTime: string;
    tokenId: number;
    tokenNo: string;
    updatedOn: string;
    waitingTime: string;
    priority?: number,
    roomId?: number,
    roomNumber?: string,
    tranId: string;
    noShow?: number

}