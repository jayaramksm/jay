export interface IEpState {
    enterpriseData: IEnterpriseModel[];
    languagesData: IEpLanguage[];
    timezonesData: IEpTimezone[];
    searchKey: string;
    actionType: number;
    actionData: IEnterpriseModel;
    licenseUploadResponse: ILicenseResponse | null;
    logoUploadRespone: ILogoResponse | null;
    refreshLoading: boolean;
}

export interface IEnterpriseModel {
    enterpriseId: number;
    enterpriseNameAr: string;
    enterpriseNameEn: string;
    isActive: number;
    languageId: number;
    licenseFile: string;
    licenseInfo: IEpLicenseInfo;
    logoPath: string;
    timeZoneId: number;
    logo: string;
}

export interface IEpLicenseInfo {
    filePath: string;
    licenseActivationDate: string;
    licenseExpireDate: string;
    licneseNumber: string;
    messages: string;
    noOfBranches: string;
    noOfDoctors: string;
    noOfFacilities: string;
    status: boolean;
    statusCode: number;
}

export interface IEpLanguage {
    id: number;
    langCode: string;
    language: string;
}

export interface IEpTimezone {
    countryCode: string;
    countryName: string;
    gmtOffset: string;
    id: number;
    timeZone: string;
}

export interface ILicenseResponse {
    filePath: string;
    licenseActivationDate: string;
    licenseExpireDate: string;
    licneseNumber: string;
    messages: string;
    noOfBranches: number;
    noOfDoctors: number;
    noOfFacilities: number;
    status: boolean;
    statusCode: number;
}

export interface ILogoResponse {
    filePath: string;
    messages: string;
    status: boolean;
    statusCode: number;
    logo: string;
}

export interface ICreateEpModel {
    enterpriseNameAr: string;
    enterpriseNameEn: string;
    languageId: number;
    licenseFile: string;
    logoPath: string;
    timeZoneId: number;
    logo: string;
}

export interface IEnterpriseFormModel {
    enterpriseId: number;
    enterpriseNameEn: string;
    enterpriseNameAr: string;
    timeZoneId: number;
    languageId: number;
}