export interface IRManualTokenModel {
    mrnVerifyButtonStatus: boolean;
    generateTokenButtonStatus: boolean;
    mrnAppointmentsData: IRMrnAppointment[];
    serviceData: IRMTbranchData;
    doctorData: IROptionsData[];
    checkInModalData: IRMrnAppointment;
    templateData: IRTemplateData;
}

export interface IRTemplateData {
    templateOrg: string;
    templates: string[];
    mrnNo: string;
}

export interface IRMrnAppointment {
    firstName: string;
    lastName: string;
    mrnNO: string;
    serviceBookedId: number;
    serviceNameEn: string;
    status: string;
}

export interface IRGenerateManualToken {
    accompanyVisitors: number;
    appointmentTime: string;
    branchId: number;
    drId: number;
    firstName: string;
    lastName: string;
    mrnNo: string;
    serviceId: number;
}

export interface IRMTbranchData {
    branchId: number;
    branchName: string;
    services: IROptionsData[];
}

export interface IROptionsData {
    value: number;
    label: string;
}

export enum IRTokenStatus {
    CHECKIN = "SCHEDULED",
    REPRINT = "REPRINT"
}