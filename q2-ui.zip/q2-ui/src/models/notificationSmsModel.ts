export interface INotificationSMSModel {
    smsNotificationData: ISmsNotification[];
    triggerData: ITrigger[];
    actionData: ISmsNotification;
    actionType: number;
    refreshLoading: boolean;
    smsCurrentPage: number;
    smsTextContent: string | undefined;
}

export interface ISmsNotification {
    notificationSmsId: number;
    smsTxt: string;
    templateName: string;
    triggerId: number;
    status: number;
}

export interface ITrigger {
    params: IParam[];
    triggerCode: string;
    triggerId: number;
    triggerName: string;
}
export interface IParam {
    paramCode: string;
    paramId: number;
    paramName: string;
}