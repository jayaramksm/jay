export interface INCManualTokenModel {
    mrnVerifyButtonStatus: boolean;
    generateTokenButtonStatus: boolean;
    mrnAppointmentsData: INCMrnAppointment[];
    serviceData: INCMTbranchData;
    checkInModalData: INCMrnAppointment;
    templateData: INCTemplateData;
}

export interface INCTemplateData {
    templateOrg: string;
    templates: string[];
    mrnNo: string;
}

export interface INCMrnAppointment {
    firstName: string;
    lastName: string;
    mrnNO: string;
    serviceBookedId: number;
    serviceNameEn: string;
    status: string;
}

export interface INCGenerateManualToken {
    accompanyVisitors: number;
    appointmentTime: string;
    branchId: number;
    drId: number;
    firstName: string;
    lastName: string;
    mrnNo: string;
    serviceId: number;
}

export interface INCMTbranchData {
    branchId: number;
    branchName: string;
    services: INCOptionsData[];
}

export interface INCOptionsData {
    value: number;
    label: string;
}

export enum INCTokenStatus {
    CHECKIN = "SCHEDULED",
    REPRINT = "REPRINT"
}