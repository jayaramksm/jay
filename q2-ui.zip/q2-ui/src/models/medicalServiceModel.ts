export interface IMedicalServiceModel {
  medicalServiceData: IMedicalService[],
  actionType: number;
  actionData: IMedicalService;
  searchKey: string;
  refreshLoading: boolean;
  userData: IUser[]

}
export interface IUser {
  contactNo: string;
  emailId: string;
  enterpriseId: number;
  firstName: string;
  isActive: number;
  isFirstLogin: number;
  lastName: string;
  locationId: number;
  resourceCode: string;
  roleId: number;
  systemAccess: number;
  userId: number;
  userName: string;
  userType: string;
}
export interface IMedicalService {
  medServiceCode: string;
  medServiceId: number;
  medServiceName: string;
  users: IMedSerUser[];
}

export interface IMedSerUser {
  firstName: string;
  lastName: string;
  userId: number;
  userName: string;
}

export interface IMedicalBulkColumnsData {
  medServiceCode: string,
  medServiceName: string,
  resourceCode: string,
}
export interface IMedicalBulkUploadData {
  enterpriseId: number,
  locationId: number,
  mappedColumns: IMedicalBulkColumnsData,
  extension: string,
  data: any,
  translator: any,
  validationSchema: any,
}
export interface IBulkmedServices {
  medServiceCode: string,
  medServiceName: string,
  resourceCode: string,
  failureReason?: string;
}
export interface IBulkMedicalRequestObject {
  enterpriseId: number;
  locationId: number;
  medServices: IBulkmedServices[];
}