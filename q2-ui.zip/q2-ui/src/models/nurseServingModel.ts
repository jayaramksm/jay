import { IServiceStatasticsDetail } from "./utilityClientModel";

export interface INurseServingModel {
    roomsData: IRoom[];
    selectedRoom: IRoom;
    servicesData: IServicesWithCount[];
    selectedServiceId: number;
    statasticsData: IServiceStatasticsDetail[];
    waitingTokensData: INurseTokens[];
    servingTokensData: INurseTokens[];
    selectionTabIndex: number;
    selectionActionArea: ISelectionActionArea;
}

export interface ISelectionActionArea {
    actionTokenId: number;
    journeyData: any;
}


export interface IServicesWithCount {
    count: number;
    serviceId: number;
    serviceNameAr: string;
    serviceNameEn: string;
}

export interface IRoom {
    maxAllowedToken: number;
    roomId: number;
    roomNameAr: string;
    roomNameEn: string;
    roomNo: string;
}
export interface ServingToken {
    appointmentTime: string;
    checkInTime: string;
    doctorName: string;
    drId: number;
    isVitalDone: boolean;
    mrnNo: string;
    patientName: string;
    priority: number;
    roomId: number;
    roomNumber: string;
    servingCallTime: string;
    tokenId: number;
    tokenNo: string;
    tranId: string;
    waitingTime: number;
}

export interface INurseTokens {
    appointmentTime: string;
    checkInTime: string;
    doctorName: string;
    drId: number;
    isVitalDone: boolean;
    mrnNo: string;
    patientName: string;
    priority?: number;
    roomId?: number;
    roomNumber?: string;
    servingCallTime: string;
    tokenId: number;
    tokenNo: string;
    tranId: string;
    waitingTime: number;
    noShow?: number

}



