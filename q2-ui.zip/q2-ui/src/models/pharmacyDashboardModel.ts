export interface IPharmacyDashboardModel {
    waitTimeTrendsData: any;
    pharmacyServiceTypeData: any;
    patientServedByCounterData: any;
    serviceTypeByCounterData: any;
}