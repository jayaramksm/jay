import { IServiceStatasticsDetail } from "./utilityClientModel";

export interface IVitalServingModel {
    roomsData: IRoom[];
    selectedRoom: IRoom;
    servicesData: IServicesWithCount[];
    selectedServiceId: number;
    statasticsData: IServiceStatasticsDetail[];
    waitingTokensData: IVitalTokens[];
    servingTokensData: IVitalTokens[];
    selectionTabIndex: number;
    selectionActionArea: ISelectionActionArea;
}


export interface ISelectionActionArea {
    actionTokenId: number;
    journeyData: any;
}

export interface IServicesWithCount {
    count: number;
    serviceId: number;
    serviceNameAr: string;
    serviceNameEn: string;
}

export interface IRoom {
    maxAllowedToken: number;
    roomId: number;
    roomNameAr: string;
    roomNameEn: string;
    roomNo: string;
}

// export interface IServingTokens {
//     appointmentTime: string;
//     checkInTime: string;
//     doctorName: string;
//     drId: number;
//     isVitalDone: boolean;
//     mrnNo: string;
//     patientName: string;
//     servingCallTime: string;
//     tokenId: number;
//     tokenNo: string;
//     waitingTime: string;
// }

export interface IVitalTokens {
    appointmentTime: string;
    checkInTime: string;
    doctorName: string;
    drId: number;
    isVitalDone: boolean;
    mrnNo: string;
    patientName: string;
    servingCallTime: string;
    tokenId: number;
    tokenNo: string;
    waitingTime: number;
    priority?: number,
    roomId?: number,
    roomNumber?: string,
    tranId: string,
    noShow?: number

}
