export interface IPManualTokenModel {
    mrnVerifyButtonStatus: boolean;
    generateTokenButtonStatus: boolean;
    mrnAppointmentsData: IPMrnAppointment[];
    serviceData: IPMTbranchData;
    checkInModalData: IPMrnAppointment;
    templateData: IPTemplateData;
}

export interface IPTemplateData {
    templateOrg: string;
    templates: string[];
    mrnNo: string;
}

export interface IPMrnAppointment {
    firstName: string;
    lastName: string;
    mrnNO: string;
    serviceBookedId: number;
    serviceNameEn: string;
    status: string;
}

export interface IPGenerateManualToken {
    accompanyVisitors: number;
    appointmentTime: string;
    branchId: number;
    drId: number;
    firstName: string;
    lastName: string;
    mrnNo: string;
    serviceId: number;
}

export interface IPMTbranchData {
    branchId: number;
    branchName: string;
    services: IPOptionsData[];
}

export interface IPOptionsData {
    value: number;
    label: string;
}

export enum IPTokenStatus {
    CHECKIN = "SCHEDULED",
    REPRINT = "REPRINT"
}