export interface IServiceReportsModel {
    serviceReportsData: IServiceReportsData[],
    currentDate: string,
    serviceData: IServices[]
}
export interface IServiceReportsData {
    keyId?: number;
    avgCareTimeService: string;
    avgWaitimeService: string;
    serviceDate: string;
    serviceNameEn: string;
    totalCheckedInService: string;
    totalNoJourneyService: string;
    totalPriorityServedService: string;
    totalRoomsUsed: string;
    totalTokenServedService: string;
}

export interface IServices {
    avgCareTimeService: string;
    avgWaitimeService: string;
    branchId: number;
    branchNameAr: string;
    branchNameEn: string;
    locationId: number;
    locationNameAr: string;
    locationNameEn: string;
    percentageServiceUtilized: string;
    serviceCheckinThresold: string;
    serviceDate: string;
    serviceHours: string;
    serviceId: number;
    serviceIdleTime: string;
    serviceNameAr: string;
    serviceNameEn: string;
    sno: number;
    totalCheckedInService: string;
    totalDelayedToken: string;
    totalEarlyCheckinService: string;
    totalKioskCheckin: string;
    totalLateCheckinService: string;
    totalManualCheckin: string;
    totalNoJourneyService: string;
    totalNoShowService: string;
    totalPriorityServedService: string;
    totalRoomsUsed: string;
    totalServiceAppt: string;
    totalTokenServedService: string;
    updatedOn: string;
}