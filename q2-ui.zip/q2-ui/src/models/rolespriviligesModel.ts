export interface IRolesPriviligesModel {
    rolesData: IRole[];
    roleTypesData: IRoleType[];
    branchTypesData: IBranchType[];
    searchKey: string;
    actionData: IRole;
    actionType: number;
    defaultPermissions: IDefaultPermissions;
    storeDefaultPermissions: IDefaultPermissions[];
    refreshLoading: boolean;
}
export interface IDefaultPermissions {
    roleType: number;
    branchType: number;
    masterPermissionsData: IModuleDefaultPage[];
}
export interface IBranchType {
    branchTypeCode: string;
    branchTypeDisplay: string;
    branchTypeId: number;
}
export interface IModuleDefaultPage {
    icon: string;
    link: string;
    moduleId: number;
    moduleName: string;
    moduleType: string;
    sequenceNo: number;
    subModules: ISubModule[];
}

export interface ISubModule {
    branchType: number;
    icon: string;
    link: string;
    privileges: IPrivilege[];
    sequenceNo: number;
    subModuleId: number;
    subModuleName: string;
    readPermissionId: number;
}

export interface IPrivilege {
    permission: string;
    permissionId: number;
}

export interface IRole {
    branchType: number;
    isCustomRole: number;
    roleCode:string;
    permissions: number[];
    roleId: number;
    roleName: string;
    roleType: number;
}
export interface IRoleType {
    roleType: string;
    roleTypeCode: string;
    roleTypeId: number;
}

export interface IUserType {
    type: string;
    userTypeId: string;
}

export interface IAlertMessagedata {
    message: string;
    status: boolean;
    tranId: number;
    messageCode?: string;
}

export interface IRoleActionData {
    actionMode: number;
    roleData?: IRole;
}