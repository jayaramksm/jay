export interface IManualTokenModel {
    mrnVerifyButtonStatus: boolean;
    generateTokenButtonStatus: boolean;
    mrnAppointmentsData: IMrnAppointment[];
    serviceData: IMTbranchData;
    doctorData: IOptionsData[];
    checkInModalData: IMrnAppointment;
    templateData: ITemplateData;
}

export interface ITemplateData {
    templateOrg: string;
    templates: string[];
    mrnNo: string;
}

export interface IMrnAppointment {
    firstName: string;
    lastName: string;
    mrnNO: string;
    serviceBookedId: number;
    serviceNameEn: string;
    status: string;
}

export interface IGenerateManualToken {
    accompanyVisitors: number;
    appointmentTime: string;
    branchId: number;
    drId: number;
    firstName: string;
    lastName: string;
    mrnNo: string;
    serviceId: number;
}

export interface IMTbranchData {
    branchId: number;
    branchName: string;
    services: IOptionsData[];
}

export interface IOptionsData {
    value: number;
    label: string;
}

export enum ITokenStatus {
    CHECKIN = "SCHEDULED",
    REPRINT = "REPRINT"
}