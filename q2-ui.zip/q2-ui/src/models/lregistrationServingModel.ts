import { IServiceStatasticsDetail } from "./utilityClientModel";

export interface ILRegistrationServingModel {
    roomsData: IRoom[];
    selectedRoom: IRoom;
    statasticsData: IServiceStatasticsDetail[];
    waitingTokensData: ILRegistrationTokenDetails[];
    servingTokensData: ILRegistrationTokenDetails[];
    selectionTabIndex: number;
    selectionActionArea: ISelectionActionArea;
}

export interface IRoom {
    maxAllowedToken: number;
    roomId: number;
    roomNameAr: string;
    roomNameEn: string;
    roomNo: string;
}
export interface ILRegistrationTokenDetails {
    appointmentTime: string;
    checkInTime: string;
    doctorName: string;
    drId: number;
    isVitalDone: boolean;
    mrnNo: string;
    patientName: string;
    servingCallTime: string;
    tokenId: number;
    tokenNo: string;
    waitingTime: number;
    priority?: number,
    roomId?: number,
    roomNumber?: string,
    updatedOn: string;
    tranId: string,
    noShow?: number

}
export interface ISelectionActionArea {
    actionTokenId: number;
    journeyData: any;
}