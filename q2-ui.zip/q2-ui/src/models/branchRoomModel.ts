export interface IBranchRoomModel {
    branchData: IBranch[];
    branchTypesData: IBranchType[];
    roomGroupData: IRoom[];
    searchKey: string;
    actionData: IBranch;
    actionType: number;
    refreshLoading: boolean;
    selectRoomGroup: boolean;
    roomGroupActionType: number;
    roomGroupActionId: number;
    roomActionData: IRoom;
    roomGroupSearchKey: string;
    roomNoData: IRoomNo[];
    roomNoSearchKey: string;
    roomNoActionType: number;
    roomNoActionId: number;
    roomsCurrentPage: number;

}

export interface IBranch {
    branchId: number;
    branchIdentifier: string;
    branchNameAr: string;
    branchNameEn: string;
    branchTypeId: number;
    serviceLocation: string;
    isFloating: number;
    isRegistration: number;
    isVital: number;
}
export interface IBranchType {
    branchTypeCode: string;
    branchTypeDisplay: string;
    branchTypeId: number;
}

export interface IRoomNo {
    roomId: number;
    roomNo: string;
}

export interface IRoom {
    maxAllowedToken: number;
    roomMasterId: number;
    roomNameAr: string;
    roomNameEn: string;
}

export interface IBranchAndBranchTypesUtilityModel {
    branchesData: IBranch[];
    branchTypesData: IBranchType[];
    alertMessageData: any;
}

export interface IBranchServingCategory {
    branchTypeCode: string;
    registration: boolean;
    vitals: boolean;
    floating: boolean;
}


export interface IColumnsBranch {
    branchNameEn: string;
    branchNameAr: string;
    branchIdentifier: string;
    serviceLocation: string;
}

export interface IBulkUploadBranchData {
    branchTypeId: number;
    mappedColumns: IColumnsBranch;
    validationSchema: any;
    extension: string;
    data: any;
    translator: any;
    isFloating: number;
    isRegistration: number;
    isVital: number;
}

export interface IBulkBranch {
    branchIdentifier: string;
    branchNameAr: string;
    branchNameEn: string;
    serviceLocation: string;
    failureReason?: string;
}

export interface IBulkBranchUserRequestObject {
    branchTypeId: number;
    branches: IBulkBranch[];
    isFloating: number;
    isRegistration: number;
    isVital: number;
    locationId: number;
}


