export interface IJourneyMapModel {
    tokenData: ITokens;
    patientVisits: IPatientVisit[];
    journeyData: any;
    notificationData: INotifications;
    totalJourneyTime: number;
    patientName: string;
    mrnNo: number;
}

export interface ITokens {
    Appointment: string;
    AvgCareTime: string;
    AvgTransactionTime: string;
    AvgTransitTime: string;
    AvgWaitTime: string;
    TokenNo: string;
    mrnNo: string;
    patinetName: string;
    checkin: string;
}

export interface IPatientVisit {
    fName: string;
    lName: string;
    time: string;
}

export interface IJourneyData {
    category: string;
    startTime: string;
    endTime: string,
    careTime: number
}

export interface INotifications {
    sms: string;
    email: string;
    push: string;
    whatsp: string;
}