export interface IDashboardsModel {
    predictiveChartsData: any;
    dashboard: any;
    radiologyDashboard: any;
    labDashboard: any;
    pharmacyDashboard: any;
    billingDashboard: any;
    devicesDashboard: any;
    generalDashboard: any;
}