export interface IEnterpriseModel {
    enterpriseId: number;
    enterpriseEngName: string;
    enterpriseArbName: string;
}

// enterprise profile models
export interface IEnterpriseCreateOrUpdateModel {
    id?: number;
    enterpriseAddress: string;
    enterpriseArbName: string;
    enterpriseContact: string;
    enterpriseMail: string;
    enterpriseName: string;
    enterpriseWebsite: string;
    filePath: string;
    primaryContact: string;
    primaryDesignation: string;
    primaryMail: string;
    primaryMobile: string;
    primaryName: string;
    secondaryContact: string;
    secondaryDesignation: string;
    secondaryMail: string;
    secondaryMobile: string;
    secondaryName: string;
}
export interface IApiResponseModel {
    id?: number;
    messages: string;
    status: boolean;
    statusCode: number;
}

export interface IEnterpriseProfileModel {
    enterpriseProfileData: IEnterpriseProfileDetails,
    licenseDetailsData: null | ILicenseDetails,
    editProfile: boolean,
    clearFileSelection: boolean,
    alertMessage: IAlertMessagedata;
    enterpriseTranId: number;
    enterpriseUploadPath: string;
}
export interface IAlertMessagedata {
    message: string;
    status: boolean;
    tranId: number;
}

export interface IFileUploadState {
    uploadedFile: null | File,
    invalidFileExtensionError: null | string
}

export interface IEnterpriseProfileDetails {
    customer: string;
    enterpriseAddress: string;
    enterpriseArbName: string;
    enterpriseContact: string;
    enterpriseMail: string;
    enterpriseName: string;
    enterpriseWebsite: string;
    id: number;
    licenseAddedDate: string;
    licenseExpireDate: string;
    licneseNumber: string;
    primaryContact: string;
    primaryDesignation: string;
    primaryMail: string;
    primaryMobile: string;
    primaryName: string;
    secondaryContact: string;
    secondaryDesignation: string;
    secondaryMail: string;
    secondaryMobile: string;
    secondaryName: string;
    filePath: string;
}
export interface ILicenseDetails {
    licenseNumber: string,
    dateAdded: string,
    validity: string
}
export interface IFileUploadResponse {
    customer: string;
    filePath: string;
    licenseAddedDate: string;
    licenseExpireDate: string;
    licneseNumber: string;
    messages: string;
    status: boolean;
    statusCode: number;
}
export interface IUploadResponse {
    customer: string;
    filePath: string;
    licenseAddedDate: string;
    licenseExpireDate: string;
    licneseNumber: string;
}