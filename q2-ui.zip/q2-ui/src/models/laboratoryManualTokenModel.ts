export interface ILManualTokenModel {
    mrnVerifyButtonStatus: boolean;
    generateTokenButtonStatus: boolean;
    mrnAppointmentsData: ILMrnAppointment[];
    serviceData: ILMTbranchData;
    checkInModalData: ILMrnAppointment;
    templateData: ILTemplateData;
}

export interface ILTemplateData {
    templateOrg: string;
    templates: string[];
    mrnNo: string;
}

export interface ILMrnAppointment {
    firstName: string;
    lastName: string;
    mrnNO: string;
    serviceBookedId: number;
    serviceNameEn: string;
    status: string;
}

export interface ILGenerateManualToken {
    accompanyVisitors: number;
    appointmentTime: string;
    branchId: number;
    drId: number;
    firstName: string;
    lastName: string;
    mrnNo: string;
    serviceId: number;
}

export interface ILMTbranchData {
    branchId: number;
    branchName: string;
    services: ILOptionsData[];
}

export interface ILOptionsData {
    value: number;
    label: string;
}

export enum ILTokenStatus {
    CHECKIN = "SCHEDULED",
    REPRINT = "REPRINT"
}