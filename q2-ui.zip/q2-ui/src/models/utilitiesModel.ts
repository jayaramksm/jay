export enum IAPPModules {
    LOGINMODULE = 'Q20',
    ENTERPRISEMODULE = 'Q21',
    TOPOGRAPHYMODULE = 'Q22',
    BRANCHMODULE = 'Q23',
    DEPARTMENTMODULE = 'Q24',
    ROOMSMODULE = 'Q25',
    ROOMTYPEMODULE = 'Q26',
    USERMANAGEMENTMODULE = 'Q27',
    ROLESPRIVILIGESMODULE = 'Q28',
    LOCATIONSMODULE = 'Q29',
    APPOINTMENTTYPEMODULE = 'Q30',
    SERVICESMODULE = 'Q31',
    MEDICALSERVICEMODULE = 'Q32',
    SCANNERMODULE = 'Q33',
    KIOSKMODULE = 'Q34',
    DISPLAYBOARDMODULE = 'Q35',
    GLOBALSETTINGSMODULE = 'Q36',
    NOTIFICATIONEMAILMODULE = 'Q37',
    NOTIFICATIONSMSMODULE = 'Q38',
    USERPROFILEMANAGEMENTMODULE = 'Q39',
    CLIENTPROFILESETTINGS = 'Q40',
    VITALSERVING = 'Q41',
    NURSESERVING = 'Q42',
    MANUALTOKENMODULE = 'Q43',
    CLERKSERVING = 'Q44',
    PHARMACYSERVING = 'Q45',
    PREGISTRATIONSERVING = 'Q46',
    LABORATORYSERVING = 'Q47',
    LREGISTRATIONSERVING = 'Q48',
    RADIOLOGYSERVING = 'Q49',
    RREGISTRATIONSERVING = 'Q50',
    CAREMAP = 'Q51',
    JOURNEYMAP = 'Q52',
    DASHBOARDS = 'Q53',
    NONCLINICALSERVINGMODULE = 'Q54',
    NCREGISTRATIONSERVING = 'Q55',
    PHARMACYDASHBOARDMODULE = 'Q56',
    DEPARMENTREPORTS = 'Q57',
    SERVICEREPORTS = 'Q58',
    FORGETPASSWORDMODULE = 'Q59'
}
export enum ILogoutTypes {
    RELOGIN = 'relogin',
    LOGOUT = 'logout',
    LOGOUT404 = 'logout 404',
    LOGOUT403 = 'logout 403',
    LOGOUT440 = 'logout 440'
}
export enum IRoutePath {
    default = '/',
    timeOut = '/440',
    notAuthenticated = '/403',
    isAuthenticated = '1'
}
export enum IOprationalActions {
    UNSELECT = 0,
    ADD = 1,
    EDIT = 2,
    DELETE = 3,
    SELECT = 4,
    MAPPING = 5,
    BULKUPLOAD = 6
}
export enum IRoleDesc {
    SUPERADMIN = 'SA',
    ENTERPRISEADMIN = 'EA',
    DOCTOR = 'DR'
}
export enum IBranchTypeEnum {
    PHARMACY = "PH",
    LABORATORY = "LAB",
    RADIOLOGY = "RG",
    CLINICAL = "CL",
    NONCLINICAL = "NCL"
}
export enum IGlobalSettingsTypes {
    EMAIL = 'SMTP',
    SMS = 'SMS',
    ACTIVEDIRECTORY = 'LDAP',
    PASSWORDPOLICIES = "PASSWORDPOLICIES",
    HOLDCONFIGURATION = "HOLDCONFIGURATION"
}
export enum IRoleTypeEnum {
    ADMIN = 'AD',
    CLIENT = 'CL'
}
export enum IActions {
    CREATE = 'create',
    EDIT = 'edit',
    DELETE = 'delete',
    STATUS = 'status',
    BULKUPLOAD = 'bulk_insert'
}
export enum ICheckedEnums {
    NCHECKED = 1,
    NUNCHECKED = 0
}

export enum IStatusEnum {
    NACTIVE = 1,
    NINACTIVE = 0
}
export enum ILayoutType {
    AUTH = 'Auth',
    CLIENTAUTH = 'ClientAuth',
    NONAUTH = 'NonAuth',
    CARE = 'Care'
}
export interface IConfirmModel {
    title: string;
    subtitle?: string;
    transKey: string;
    replaceData?: IConfirmReplaceModal[];
    options: IConfirmOptions[];
}
export interface IConfirmReplaceModal {
    replaceKey: string;
    replaceValue: string;
}
export interface IConfirmOptions {
    title: string;
    function?: any;
    loading?: number;
    className?: string;
}
export interface IApiThrowResponse {
    status: boolean;
    statuscode: number,
    messages: string;
    data?: any;
    error?: any;
}
export interface Settings {
    sessionName;
    sessionTime;
    showMessagecode;
    autoRefresing;
    autoRefreshTime;
    tokenServingInterval;
    caremapPath;
    dashboardInterval;
    versionCheckInterval
}

export interface IBaseApiUrls {
    baseUrl: string;
    components: IApiUrls[];
}
export interface IApiUrls {
    apiUrl: string
    component: string;
    methods: IApiMethod[];
}

export interface IApiMethod {
    name: string;
    type: string;
    url: string;
}
export interface ISessionstate {
    token: any;
    menuData: IMenuModules[];
    loginTime: any,
    userDto: IUserDetails,
    locationId: number;
    selectedLocationStatus: boolean;
    language: string;
    isDefultPasswordAuth: IIsDefultPasswordAuth | undefined;
}
export interface IIsDefultPasswordAuth {
    enable: boolean;
    password: string;
    menuData: IMenuModules[];
}
export interface IMenuModules {
    icon: string;
    link: string;
    moduleId: number;
    moduleName: string;
    moduleType: string;
    sequenceNo: number;
    subModules: IMenuSubModule[];
}

export interface IMenuSubModule {
    branchType: number;
    icon: string;
    link: string;
    privileges: IMenuPrivilege[];
    sequenceNo: number;
    subModuleId: number;
    subModuleName: string;
}

export interface IMenuPrivilege {
    permission: string;
    permissionId: number;
}
export interface IEnterpriseShortModel {
    enterpriseId: number;
    enterpriseEngName: string;
    enterpriseArbName: string;

}


export interface IAlertMessagedata {
    message: string;
    messageCode?: string;
    transKey?: string;
    status: boolean;
    tranId: number;
    statusCode?: number;

}
export interface IUtilitiesState {
    locationId: number;
}
export interface IUserDetails {
    firstName: string;
    lastName: string;
    contactNo: string;
    emailId: string;
    enterprise: IEnterprise;
    isFirstLogin: number;
    location: ILocation;
    resourceCode: string;
    roles: IRoles;
    userId: number;
    userName: string;
    userType: string;
    isUserProfile: boolean;
}

export interface IRoles {
    enterpriseId: number;
    isCustomRole: number;
    roleCode: string;
    roleId: number;
    roleName: string;
    roleType: number;
}

export interface ILocation {
    locationAddress: string;
    locationId: number;
    locationIdentfier: string;
    locationNameAr: string;
    locationNameEn: string;
    status: number;
}

export interface IEnterprise {
    enterpriseId: number;
    enterpriseNameAr: string;
    enterpriseNameEn: string;
    isActive: number;
    languageId: number;
    licenseFile: string;
    licenseInfo: ILicenseInfo;
    logoPath: string;
    timeZoneId: number;
}

interface ILicenseInfo {
    filePath: string;
    licenseActivationDate: string;
    licenseExpireDate: string;
    licneseNumber: string;
    messages: string;
    noOfBranches: number;
    noOfDoctors: number;
    noOfFacilities: number;
    status: boolean;
    statusCode: number;
}

