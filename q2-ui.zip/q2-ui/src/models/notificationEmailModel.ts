export interface INotificationEmailModel {
    notificationEmailData: IEmailNotification[];
    triggerData: IEmailTrigger[];
    testModalData: string;
    actionType: number;
    actionData: IEmailNotification;
    refreshLoading: boolean;
    paginationIndex: number;
}

export interface IEmailNotification {
    mailBody: string;
    mailSubject: string;
    notificationMailId: number;
    templateName: string;
    tiggerId: number;
    status: number;
}

export interface IEmailTrigger {
    params: IEmailParam[];
    triggerCode: string;
    triggerId: number;
    triggerName: string;
}

export interface IEmailParam {
    paramCode: string;
    paramId: number;
    paramName: string;
}