export interface IUserManagmentModel {
    userData: IUser[],
    userTypeData: IUserType[],
    actionType: number;
    actionData: IUser;
    searchKey: string;
    searchEnterPrise: number;
    searchRole: number;
    searchStatus: number;
    refreshLoading: boolean;

}
export interface IUser {
    contactNo: string;
    emailId: string;
    enterpriseId: number;
    firstName: string;
    isActive: number;
    isFirstLogin: number;
    lastName: string;
    locationId: number;
    resourceCode: string;
    roleId: number;
    systemAccess: number;
    userId: number;
    userName: string;
    userType: string;
}

export interface IUserType {
    type: string;
    userTypeId: string;
}

export interface IRoles {
    enterpriseId: number;
    isCustomRole: number;
    roleCode: string;
    roleId: number;
    roleName: string;
    roleType: number;
}
export interface IColumnsData {
    firstName: string,
    userName: string,
    lastName: string,
    emailId: string,
    contactNo: string,
    resourceCode: string
}

export interface IBulkUploadData {
    enterpriseId: number,
    locationId: number,
    userType: string,
    selectedRole: IRoles,
    mappedColumns: IColumnsData,
    validationSchema: any,
    extension: string,
    data: any,
    translator: any
}
export interface IBulkUser {
    contactNo: string;
    emailId: string;
    firstName: string;
    lastName: string;
    resourceCode: string;
    userName: string;
    failureReason?: string;
}

export interface IBulkUserRequestObject {
    enterpriseId: number;
    locationId: number;
    roleCode: string;
    roleId: number;
    userType: string;
    users: IBulkUser[];
}