export interface ICareMapModel {
    breadcrumbData: IBreadcrumbData[];
    caremapData: any;
    currentNodeData: ICurrentNodeData;
    callbackFn: any;
}
export interface IBreadcrumbData {
    level: number;
    name: string;
    data: ICurrentNodeData;
}
export interface ICurrentNodeData {
    name: string;
    level: number;
    all_children: any[];
    _children: any[];
    hidden: boolean;
    id: number;
    class: string;
    depth: number;
    parent: ICurrentNodeData;
    mrn?: number;
    time?: number;
    token?: string;
    priority?: number;
    deptType?: number;
}
export enum ICareMapOperations {
    LOCATIONS = 0,
    BRANCHES = 1,
    DEPARTMENTS = 2,
    SERVICES = 3,
    TOKENLEVEL = 4,
    TOKEN = 6
}