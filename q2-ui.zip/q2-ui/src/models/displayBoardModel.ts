import { IService } from "./servicesModel";

export interface IDisplayModel {
    themesData: IDBTheme[];
    displayBoardsData: IDisplayBoard[];
    dbServicesData: IService[];
    actionType: number;
    actionData: IDisplayBoard;
    dbSearchKey: string;
    filterBranchId: number;
    refreshLoading: boolean;
    servicebrnchhData: ISeriviceBranchData[]
}
export interface ISeriviceBranchData {
    branchId: number,
    label: string,
    options: IServiceOption[]
}
export interface IServiceOption {
    label: string,
    value: number;
}
export interface IDBTheme {
    themeId: number;
    themeName: string;
    themeType: string;
}

export interface IDisplayBoard {
    branches: number[];
    displayId: number;
    displayIdentifier: string;
    displayName: string;
    services: number[];
    status: number;
    themeId: number;
    displayType: string
}