import { IServiceStatasticsDetail } from "./utilityClientModel";

export interface IPRegistrationServingModel {
    roomsData: IRoom[];
    selectedRoom: IRoom;
    statasticsData: IServiceStatasticsDetail[];
    waitingTokensData: IPRegistrationTokenDetails[];
    servingTokensData: IPRegistrationTokenDetails[];
    selectionTabIndex: number;
    selectionActionArea: ISelectionActionArea;
}

export interface IRoom {
    maxAllowedToken: number;
    roomId: number;
    roomNameAr: string;
    roomNameEn: string;
    roomNo: string;
}
export interface IPRegistrationTokenDetails {
    appointmentTime: string;
    checkInTime: string;
    doctorName: string;
    drId: number;
    isVitalDone: boolean;
    mrnNo: string;
    patientName: string;
    servingCallTime: string;
    tokenId: number;
    tokenNo: string;
    waitingTime: number;
    priority?: number,
    roomId?: number,
    roomNumber?: string,
    updatedOn: string;
    tranId: string,
    noShow: number

}
export interface ISelectionActionArea {
    actionTokenId: number;
    journeyData: any;
}