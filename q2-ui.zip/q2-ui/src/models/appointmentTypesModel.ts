export interface IAppointmentTypeState {
    appointmentTypesData: IApptType[];
    actionType: number;
    actionData: IApptType;
    searchKey: string;
    refreshLoading: boolean;
    userData: IUser[]
}
export interface IUser {
    contactNo: string;
    emailId: string;
    enterpriseId: number;
    firstName: string;
    isActive: number;
    isFirstLogin: number;
    lastName: string;
    locationId: number;
    resourceCode: string;
    roleId: number;
    systemAccess: number;
    userId: number;
    userName: string;
    userType: string;
}
export interface IApptType {
    apptCode: string;
    apptType: string;
    apptTypeId: number;
    locationId: number;
    users: IAppUser[];
}
export interface IAppUser {
    firstName: string;
    lastName: string;
    userId: number;
    userName: string;
}



export interface IBulkUploadApptTypeData {
    locationId: number,
    mappedColumns: IColumnsData,
    validationSchema: any,
    extension: string,
    data: any,
    translator: any
}

export interface IColumnsData {
    apptCode: string,
    apptType: string,
    resourceCode: string
}

export interface IBulkApptType {
    apptCode: string;
    apptType: string;
    resourceCode: string;
    failureReason?: string;
}


export interface IBulkApptTypeRequestObject {
    locationId: number;
    apptTypes: IApptTypes[]
}

export interface IApptTypes {
    apptCode: string,
    apptType: string

}