export interface IDepartmentReportsModel {
    departmentReportsData: IDepartmentReportsData[],
    currentDate: any
}
export interface IDepartmentReportsData {
    keyId?: number;
    avgCareTimeBranch: string;
    avgWaitimeBranch: string;
    branchDate: string;
    branchNameEn: string;
    totalCheckedInBranch: string;
    totalNoJourneyBranch: string;
    totalPriorityServedBranch: string;
    totalRoomsUsedBranch: string;
    totalTokenServedBranch: string;
}
