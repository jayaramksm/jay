export interface IServicesState {
    servicesData: IService[];
    apptTypesData: IApptType[];
    selectModule: string;
    branchActionData: IBranchAction;
    serviceActionData: IServiceAction;
    refreshLoading: boolean;
    branchSearchKey: string;
    serviceSearchKey: string;
    servicesCurrentPage: number;
}

export interface IBranchAction {
    actionType: number;
    actionId: number;
}

export interface IServiceAction {
    actionType: number;
    actionData: IService;
}

export interface IService {
    apptTypes: IServiceApptType[],
    branchId: number;
    endSeq: number;
    maxCheckinTime: number;
    minCheckinTime: number;
    serviceId: number;
    serviceNameAr: string;
    serviceNameEn: string;
    startSeq: number;
    tokenPrefix: string;
    waitTimeAvg: number;
    isDefault: number;
}

export interface IApptType {
    apptCode: string;
    apptType: string;
    apptTypeId: number;
    locationId: number;
    users: IApptTypeUser[];
}

export interface IApptTypeUser {
    firstName: string;
    lastName: string;
    userId: number;
    userName: string;
}

export interface IServiceApptType {
    apptCode: string;
    apptType: string;
    apptTypeId: number;
}

export enum IServiceType {
    DEFAULT = 1,
    NOTDEFAULT = 0
}



export interface IColumnsServiceData {
    waitTimeAvg: string,
    minCheckinTime: string,
    serviceNameAr: string,
    tokenPrefix: string,
    maxCheckinTime: string,
    serviceNameEn: string,
    startSeq: string,
    endSeq: string,
    apptCode: string
}

export interface IBulkUploadServiceData {
    mappedColumns: IColumnsServiceData,
    validationSchema: any,
    extension: string,
    data: any,
    translator: any
}

export interface IBulkServiceUser {
    apptCode: string;
    endSeq: number;
    maxCheckinTime: number;
    minCheckinTime: number;
    serviceNameAr: string;
    serviceNameEn: string;
    startSeq: number;
    tokenPrefix: string;
    waitTimeAvg: number;

}

export interface IBulkServiceUserRequestObject {
    branchId: number;
    bulkServiceDTO: IBulkServiceUser[];
    locationId: number;
}


